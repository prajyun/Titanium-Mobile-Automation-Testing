var REV_BANNERS = function(){
   var SHOW_BANNERS = false,	//Kisok boolean used to determine if app is Kiosk mode or not.
   IS_ANDROID = true,
   SCROLL_INTERVAL = 5000,
   SELECTED_BANNER_CODE = null,
   customBannerViewHeight = null,
   BANNERS_TO_SHOW = [],
   cfg = null,
   init = function(){
   	  cfg = null;
   	  cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  //Ti.API.debug('cfg: ' + JSON.stringify(cfg));
   	  
   	  var promos = null;
   	  promos = [];
   	  
   	  if(false && Ti.App.dev){
	   	  SHOW_BANNERS = true;
	   	  //SHOW_BANNERS = cfg.Show_Banners;		//THIS WILL NEED TO BE SENT FROM THE SERVER AMONGST A FEW MORE THINGS LIKE BANNER COUNT;
	   	  										//SAY BANNER COUNT = 3, THEN I KNOW TO LOOP THROUGH:  WEBSITEURL/1.PNG AND WEBSITEURL/2.PNG ETC...
	   	  										//OR THE URLS COULD BE APART OF THE BANNER OBJECT I RECEIVE SINCE ILL NEED AN OBJECT OF SORTS TO GET THE CPN CODE FOR SAID BANNER
	   	  										
	   	  var banner1 = {
	   	  	 code:'TEST1',
	   	  	 url:'https://picklemans.hungerrush.com/content/images/slides/ordertype/mobile/banner.png'
	   	  };
	   	  var banner2 = {
	   	  	 code:'',
	   	  	 url:'https://hungryhowies.hungerrush.com/content/images/slides/ordertype/mobile/banner.png'
	   	  };
	   	  var banner3 = {
	   	  	code:'TEST1',
	   	  	url:'https://freshbrothers.hungerrush.com/Content/Images/Advertise/ThinPep.png'
	   	  };
	   	  var test = cfg;
	   	  test.Banners = [];
	   	  
	   	  test.Banners.push(banner1);
	   	  test.Banners.push(banner2);
	   	  test.Banners.push(banner3);
	   	  cfg = test;
	   	  test = null;
	   	  //test.Banners.push(banner2);
	   }
	  else{
	   	 promos = JSON.parse(Ti.App.Properties.getString('promos', '{}'));
	   	 BANNERS_TO_SHOW = null;
	   	 BANNERS_TO_SHOW = [];
	   	 BANNERS_TO_SHOW = getBannersToShow(promos);
	   	 
	   	 if(BANNERS_TO_SHOW && BANNERS_TO_SHOW.length){
	   	 	SHOW_BANNERS = true;
	   	 }
	   	 else{
	   	 	SHOW_BANNERS = false;
	   	 }
	  }
   	  										
   },
   getBannersToShow = function(promos){
   	  var foundAds = []; 
   	  for(var i=0, iMax=promos&&promos.length?promos.length:0; i<iMax; i++){
   	  	 if(promos[i].Promo && (parseInt(promos[i].Promo.PromoType, 10) == 1)){//&& promos[i].Promo.PromoCode && promos[i].Promo.PromoCode.length){
   	  	 	foundAds.push(promos[i]);
   	  	 }
   	  }
   	  return foundAds;
   },
   showBanners = function(){
   	  Ti.API.debug('showBanners: ' + SHOW_BANNERS);
   	  return SHOW_BANNERS;
   },
   getDefaultBannerView = function(customPath){
   	  var bannerViewDict, productBannerDict;
   	  if(IS_ANDROID){
   	  	 bannerViewDict = {
	     	height:'35%',
	        width:Ti.UI.FILL,
	        clipViews:ro.isiOS ? true : null,
	     };
	     productBannerDict = {
	        height:Ti.UI.FILL,
	        width:Ti.UI.FILL,
	        image:Ti.App.websiteURL + 'content/images/slides/ordertype/mobile/' + (customPath&& customPath.length ? (customPath + '?t=' + new Date().getDay()) : 'banner.png?t=' + new Date().getDay()),
	     	defaultImage: '/images/defaultBanner.png'
	     };
   	  }
   	  else{
   	  	
   	  }
   	  
   	  //Ti.API.debug('new Date().getDay(): ' + (new Date().getDay()));
   	  
   	  var bannerView = Ti.UI.createScrollableView(bannerViewDict);
   	  bannerHolder = Ti.UI.createView({
   	  		height:Ti.UI.FILL,
	        width:Ti.UI.FILL
   	  });
   	  
      var productBanner = Ti.UI.createImageView(productBannerDict);
      bannerHolder.add(productBanner);
      bannerView.views = [bannerHolder];
      return bannerView;
   },
   getImageBanner = function(bannerObj){   	  
   	  var bannerDict = {
	   	  	height:Ti.UI.FILL,
	   	  	clipViews:ro.isiOS ? true : null,
	   	  	width:Ti.UI.FILL,
	   	  	//code:bannerObj.code && bannerObj.code.length ? bannerObj.code : ''
	   	  	code:bannerObj.Promo && bannerObj.Promo.PromoCode && bannerObj.Promo.PromoCode.length ? bannerObj.Promo.PromoCode : '' 
	   	 };
   	  var bannerImgDict = {
	   	  	 //image:bannerObj.url,
	   	  	 defaultImage: '/images/defaultBanner.png',
	   	  	 image:bannerObj.URL,
	   	  	 height:Ti.UI.SIZE,
	   	  	 width:Ti.UI.SIZE,
	   	  	 touchEnabled:false,
	   	  	 top:0
	  };   	  
   	  var banner = Ti.UI.createView(bannerDict);
   	  var bannerImg = Ti.UI.createImageView(bannerImgDict);
   	  banner.add(bannerImg);
   	  //Ti.API.debug('returning banner');
   	  return banner;
   },
   isImageBanner = function(banner){
   	Ti.API.debug('banner: ' + JSON.stringify(banner));
   	  //return ((banner.ContentType.toLowerCase() == ) && ());
   	  //return ((banner.ContentType.toLowerCase() == 'image/jpeg') || (banner.ContentType.toLowerCase() == 'image/png'));
   	  //return banner.ContentType.toLowerCase().includes('image');
   	  return banner.ContentType && banner.ContentType.length ? (banner.ContentType.toLowerCase().indexOf("image") !== -1) : 0;
   },
   getBannerView = function(defaultBanner){
   	  if(!SHOW_BANNERS){
   	  	if(defaultBanner && defaultBanner.length){
   	  		return false;//getDefaultBannerView(defaultBanner);
   	  	}
   	  	else{
   	  		return getDefaultBannerView();
   	  	}
   	  	 
   	  }
   	  
   	  var bannerViewDict = {
	     	 height:'200dp',
	         width:Ti.UI.FILL,
	         scrollingEnabled:false
	  };  	  
   	
   	  if(customBannerViewHeight && defaultBanner && defaultBanner.length){
   	  	bannerViewDict.height = customBannerViewHeight;
   	  }
   	  var bannerView = Ti.UI.createScrollableView(bannerViewDict);
   	  bannerView.addEventListener('click', function(e){
   	  	 //deb.ug(e, 'e');
   	  	 if(e.source.code && e.source.code.length){
   	  	 	Ti.API.debug('Code: ' + e.source.code);
   	  	 	SELECTED_BANNER_CODE = e.source.code;
   	  	 }
   	  	 else{
   	  	 	SELECTED_BANNER_CODE = null;
   	  	 	Ti.API.debug('No Code');
   	  	 }
   	  });
   	  
      var scrollViewData = [];
      for(var i=0, iMax=BANNERS_TO_SHOW && BANNERS_TO_SHOW.length ? BANNERS_TO_SHOW.length : 0; i<iMax; i++){
      	 if(isImageBanner(BANNERS_TO_SHOW[i])){
      	 	scrollViewData.push(getImageBanner(BANNERS_TO_SHOW[i]));
      	 }
      	 else{
      	 	
      	 }
      }
      bannerView.views = scrollViewData;
      if(BANNERS_TO_SHOW.length > 1){
	      setInterval(function(){
	      	 if(bannerView.getCurrentPage() == (bannerView.views.length-1)){
	      	 	bannerView.setCurrentPage(0);
	      	 }
	      	 else{
	      	 	bannerView.moveNext();
	      	 }
	      }, SCROLL_INTERVAL);
	  }
      //Ti.API.debug('returning bannerView');
      return bannerView;
   },
   getSelectedBannerCode = function(){
   	  var codeToUse = SELECTED_BANNER_CODE && SELECTED_BANNER_CODE.length ? SELECTED_BANNER_CODE : (Ti.App.Properties.getString("promoDigest", ""));
   	  SELECTED_BANNER_CODE = null;
   	  Ti.App.Properties.setString("promoDigest", "");
   	  return codeToUse;
   },
   setBannerHeight = function(bannerViewHeight){
   	  customBannerViewHeight = bannerViewHeight;
   };
   return {
   	  init: init,
   	  showBanners: showBanners,
   	  getBannerView: getBannerView,
   	  getSelectedBannerCode: getSelectedBannerCode,
   	  getDefaultBannerView: getDefaultBannerView,
   	  setBannerHeight: setBannerHeight
   };
}();
module.exports = REV_BANNERS;