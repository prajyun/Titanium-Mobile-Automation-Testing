var REV_KIOSK = function(){
   var IS_KIOSK = false,	//Kisok boolean used to determine if app is Kiosk mode or not. 
   
   setKioskBln = function(isKiosk){
   	  IS_KIOSK = isKiosk;
   },
   isKiosk = function(){
   	  return IS_KIOSK;
   },
   createKioskConfigView = function(_args){
      var forms = require('/revmobile/ui/forms');
      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
      var storeTblView;

      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
         name:'Kiosk Configuration',
         hid:'kioskConfigView',
         backgroundImage:ro.ui.properties.defaultPath + 'backgroundImg.png'
      }));

      var btnCancel = layoutHelper.getBackBtn('CANCEL');
      btnCancel.addEventListener('click', function(e){
         if(ro.ui.properties.isAndroid){
         	Ti.UI.Android.hideSoftKeyboard();
         }
         ro.ui.closeKioskConfig();
      });
      
      var kioskStoreNum = JSON.parse(Ti.App.Properties.getString('kConfig'));

      navBar.add(btnCancel);

      if(ro.ui.theme.bannerImg){
         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
         navBar.add(headerImg);
      }
      else{
         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Configure Kiosk'}));
         navBar.add(headerLbl);
      }
      
      // Tab Logic
      var kioskTabs = [], kioskTabView;
      
      function GetStoreLst(req){
         ro.dataservice.post(req, 'GetStores', function(response){
            if(response){
               if(response.Value){
                  if(response.Stores.length > 0){
                     Ti.API.debug('response: ' + JSON.stringify(response));
                     storeTblView = getStoreTable(response.Stores);
                     mainView.add(storeTblView);
                     ro.ui.hideLoader();
                  }
                  else{
                     ro.ui.hideLoader();
                     ro.ui.alert('defaultStore', 'No Stores found for this location.');
                  }
               }
               else{
                  ro.ui.hideLoader();
                  ro.ui.alert('defaultStore', response.Message + '\nCODE:500.');
               }
            }
            else{
               ro.ui.hideLoader();
               ro.ui.alert('default Store', 'Error occured. CODE:100.');
            }
         });
      }

       mainView.add(navBar);
       function populateStores(){
          var req = {};
          req.IsDelivery = false;
          req.RevKey = 'test';
          req.CompressResponse = false;
          //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
          
          if(Ti.Geolocation.locationServicesEnabled == false){
	         if(Ti.Platform.version[0] >= 6){
			   	Ti.Geolocation.requestLocationPermissions(null, function(e){
			       Ti.API.debug('e: ' + JSON.stringify(e));
			       //alert('hi');
			       if(e && e.success){
			          //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
                      Ti.Geolocation.getCurrentPosition(function(e){
                         if(!e.success || e.error){
                            ro.ui.alert('Geolocation Error');
                        	ro.ui.hideLoader();
                        	return;
                     	 }
                     	 req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
                     	 req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
                     	 GetStoreLst(req);
                  	  });
			      }
			      else{
			         ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
                  	 ro.ui.hideLoader();
			      }
			   });
			}
			else{
			   ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
                ro.ui.hideLoader();
		    }	
		}
		else{
		   Ti.Geolocation.getCurrentPosition(function(e){
		   	  if(!e.success || e.error){
		      	 ro.ui.alert('Geolocation Error');
	             ro.ui.hideLoader();
	             return;
	          }
	          req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
	          req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
	          GetStoreLst(req);
	       });
	    }
      }

       ro.app.GA.trackPageView(mainView.hid /*name*/);
       var postLayoutBln = false;
       mainView.addEventListener('postlayout', function(e){
          if(postLayoutBln){
             return;
          }
          ro.ui.showLoader();
          postLayoutBln = true;
          populateStores();
       });
       return mainView;
   },
   getKioskForm = function(e){
      var fields = [
         { title:'Store Number', type:'number', id:'storeNumber' }];
         
      return fields;
   },
   getKioskZipForm = function(){
      var fields = [
         { title:'Zip Code', type:'number', id:'zip' }];
         
      return fields;
   },
   kioskValidate = function(obj, isZip){
      var errorString = '';
      var passed = {
         value:0,
         issues:[]
      };
      var nameObj = {
         storeNumber:'Store Number',
         zip:'Zip Code'
      };
      
      var numberExp = new RegExp("^(\\d{1,10})$");
      var zipExp = new RegExp("^(\\d{5}-\\d{4}|\\d{5}|\\d{9})$|^([a-zA-Z]\\d[a-zA-Z] {0,1}\\d[a-zA-Z]\\d)$");
      for(var itm in obj){
         switch(itm){
            case "storeNumber":
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               else{
                  if(!numberExp.test(obj[itm])){
                     errorString += (nameObj[itm] + ' contain invalid characters.' + '\n');
                  }
               }
               break;
            case 'zip':
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               else{
                  if(!zipExp.test(obj[itm])){
                     errorString += (nameObj[itm] + ' contain invalid characters.' + '\n');
                  }
               }
               break;
         }
      }
      
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
   },
   resetOrderObj = function(){
      Ti.App.OrderObj = null;
      Ti.App.OrderObj = {};
      var test = Ti.App.OrderObj;
      
      test.OrdType = null;
      test.ordOnlineOptions = {
      	 IsDelivery:false
      };
      //test.ordOnlineOptions.IsDelivery = false;
      test.Customer = {};
      test.Items = [];
      Ti.App.OrderObj = test;
      /*Ti.App.OrderObj.OrdType = null;
      Ti.App.OrderObj.ordOnlineOptions = {
      	 IsDelivery:false
      };
      //Ti.App.OrderObj.ordOnlineOptions.IsDelivery = false;
      Ti.App.OrderObj.Customer = {};
      Ti.App.OrderObj.Items = [];*/
   },
   getBeginOrderView = function(){
   	var mainView = {};
      try{
         resetOrderObj();
         Ti.App.OrderHasBegun = false;
         //ro.ui.hideTabview();
         ro.ui.hideTabview();
         
         if(ro.app.Store){
            Ti.App.Properties.setList('creditcards', ro.app.Store.Configuration.CardTypes);
         }
         
         //STOP SERVICE HERE
         kioskTimerStop();
         //var layoutHelper = require('/revmobile/ui/sharedLayouts/mainView');      //Global module that makes different UI elements available (ie: Nav Left and Right buttons, submit buttons, mainView shell with navbar included)
        var mainView = layoutHelper.getMainView('beginOrderKiosk'/*hid*/, 'Order Type'/*Top Title*/, /*layoutHelper.getLogoutBtn()*/false/*right Button*/, null/*left button*/, true/*vertical or not*/);
        //mainView = Ti.UI.createView();
         //var mainView = ro.ui.layoutHelper.getMainView('beginOrderKiosk'/*hid*/, 'Order Type'/*Top Title*/, /*layoutHelper.getLogoutBtn()*/false/*right Button*/, null/*left button*/, true/*vertical or not*/);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('ordTypeView()-Exception: ' + ex); }
      }

      var ordTypeView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView,{
         height:Ti.UI.FILL,
         width:Ti.UI.FILL
      }));

	Ti.API.debug('here - mainView: ' + JSON.stringify(mainView));

      mainView.add(ordTypeView);
Ti.API.debug('222here - mainView: ' + JSON.stringify(mainView));
      try{
         var continueBtn = Ti.UI.createView({
            height:ro.ui.relY(50),
            width:'80%',
            left:'10%',
            backgroundColor:ro.ui.theme.beginNewOrderBackground,//btnTxtActive,
            borderColor:ro.ui.theme.beginNewOrderBorder,
            borderWidth:ro.ui.relX(1),
            borderRadius:ro.ui.relX(1)
         });
         continueBtn.add(Ti.UI.createLabel({
            text:'BEGIN NEW ORDER',
            font:{
               fontWeight:'bold',
               fontSize:ro.ui.scaleFont(20),
               fontFamily:ro.ui.fontFamily
            },
            shadowRadius:1,
            shadowColor:ro.ui.theme.loginGray,
            color:ro.ui.theme.beginNewOrderText
         }));
         continueBtn.addEventListener('click', function(e){
            //Go to Menu
            if(Ti.App.Properties.hasProperty('KioskLane')){
               Ti.App.Properties.removeProperty('KioskLane');
            }
            if(Ti.App.Properties.hasProperty('KioskPhone')){
               Ti.App.Properties.removeProperty('KioskPhone');
            }
            if(Ti.App.Properties.hasProperty('KioskName')){
               Ti.App.Properties.removeProperty('KioskName');
            }
            
            //START SERVICE HERE
            Ti.App.OrderHasBegun = true;
            kioskTimerReset();
            
            ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
            ro.ui.showTabview();
         });
         
         ordTypeView.add(continueBtn);
         return mainView;
      }
      catch(ex){
         Ti.API.debug('ordTypeView.js-Exception: ' + ex);
      }
   },
   getStoreTable = function(storeList){
      function addLabels(List, idx){
         var top = ro.ui.relY(25);
         var bottom = ro.ui.relY(18);

         for (var j=0; j<List.length; j++){
            data[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
               color:ro.ui.theme.contentsSmallTxt,
               text:List[j],
               top:top + (ro.ui.relY(16) * j),
               bottom:bottom - (ro.ui.relY(12) * j)
            })));
         };
         return;
      }

      var stores = [], data = [];
      stores = storeList;
      
      try{
         var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
            top:ro.ui.relY(55),
            layout:'vertical'
         }));
         var store, opened;
         
         for(var i=0; i<stores.length; i++){
            try{
               
               store = stores[i];
               opened = ro.utils.isOpen(store);

               data[i] = Ti.UI.createTableViewRow({
                  className:'storeSelection',
                  top:ro.ui.relY(5),
                  height:ro.ui.relY(60),
                  store:store,
                  isOpen:opened,
                  isMobile:store.IsMobile,
                  storeName:store.Name,
                  storeid:store.ID
               });
               var strNm = store.Name?store.Name.toUpperCase():'';

               data[i].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
                  text:strNm,
                  top:ro.ui.relY(5),
                  color:ro.ui.theme.contentsTextColor
               })));
               addLabels([store.Address, store.City + ', ' + store.State + ', ' + store.Zip], i);
               var hrsView = Ti.UI.createView(ro.ui.properties.hrsView);

               var milesLebl = Ti.UI.createLabel({
                  text:(store.Distance ? '[ ' + Math.round(store.Distance * 100) / 100 + ' miles' + ' ]' : '[ 0.00 miles]'),
                  right:0,
                  bottom:0,
                  height:ro.ui.relY(15),
                  textAlign:'right',
                  font:{
                     fontSize: ro.ui.scaleFontY(10, 15),
                     fontFamily:ro.ui.fontFamily
                  },
                  color:ro.ui.theme.contentsSmallTxt
               });

               hrsView.add(milesLebl);
               data[i].add(hrsView);
            }
            catch(ex){
               if(Ti.App.DEBUGBOOL) { Ti.API.debug('storeSelection.js-Exception: ' + ex); }
            }
         }
         
         var tableView1 = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
            data:data,
            separatorColor:ro.ui.theme.separatorColor,
            borderWidth:ro.ui.relX(1),
            minRowHeight:ro.ui.relY(40),
            top:0,
            backgroundColor:'#ffffff',
            left:ro.ui.relX(10),
            right:ro.ui.relX(10),
            borderColor:ro.ui.theme.loginGray,
            height:Ti.UI.SIZE
         }));
         tableView1.addEventListener('click', function(e){
            if(!e.row.isMobile){
               ro.ui.hideLoader();
               ro.ui.alert(e.row.storeName, 'The store doesn\'t allow mobile orders.');
               return;
            }
            var kConf = JSON.parse(Ti.App.Properties.getString('kConfig'));
            kConf.StoreNumber = e.row.storeid;
            Ti.App.Properties.setString('kConfig', JSON.stringify(kConf));
            ro.ui.closeKioskConfig();
         });
         var selectLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
            right:ro.ui.relX(10),
            left:ro.ui.relX(10),
            focusable:false
         }));
         selectLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
            text:'SELECT A STORE:',
            font:{
               fontSize:ro.ui.scaleFont(15, 0, 0),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            }
         })));
         view.add(selectLblView);
         view.add(tableView1);
         return view;
      }
      catch(ex){
         ro.ui.alert('storeSelection', 'Error occured.' + 'CODE 200');
      }
   },
   currService = null,
   kioskTimerStop = function(e){
   	  if(!ro.ui.properties.isAndroid){
   	  	Ti.API.debug('returning - kioskTimerStop');
   	  	return;
   	  }
      Ti.App.Properties.setBool('timerActive', false);
      if(currService !== null){
         currService.stop();
         currService = null;
      }
   },
   kioskTimerReset = function(e){
   	  if(!ro.ui.properties.isAndroid){
   	  	 Ti.API.debug('returning - kioskTimerReset');
   	  	 return;
   	  }
      Ti.App.Properties.setBool('timerActive', true);
      if(currService !== null){
         currService.stop();
         currService = null;
      }
      
      var intent = Titanium.Android.createServiceIntent({ url: 'kioskService.js' });
      // Service should run its code every 2 seconds.
      //intent.putExtra('interval', 120000);
      intent.putExtra('interval', 120000);
      
      // A message that the service should 'echo'
      intent.putExtra('message_to_echo', 'false');
      //intent.putExtra('should_execute_bool', false);
      
      var service = Titanium.Android.createService(intent);
      service.addEventListener('resume', function(e){
          //Titanium.API.info('Service code resumes, iteration ' + e.iteration);
      });
      service.addEventListener('pause', function(e){
          //Titanium.API.info('Service code pauses, iteration ' + e.iteration);
          /*if (e.iteration === 3) {
              Titanium.API.info('Service code has run 3 times, will now stop it.');
              service.stop();
          }*/
      });
      service.addEventListener('taskremoved', function(e){
          Titanium.API.info('taskremoved - - - Service code resumes, iteration ' + e.iteration);
      });
      currService = service;
      //Ti.API.debug('Starting service!');
      currService.start();
   },
   isKioskLoginValid = function(currentUsername){
      if(currentUsername.toLowerCase() != 'kiosk@ahbeetzkiosk.com' && currentUsername.toLowerCase() != 'kiosk@revention.com'){
         //Ti.API.debug('This user is not the kiosk admin user, instead it was:' + txtUname.value.toLowerCase());
         ro.ui.alert('Login Failed', 'Please enter the KIOSK credentials');
         return false;
      }
      else{
         return true;
      }
   };
   return {
      kioskTimerReset: kioskTimerReset,
      createKioskConfigView: createKioskConfigView,
      getBeginOrderView: getBeginOrderView,
      isKioskLoginValid: isKioskLoginValid,
      setKioskBln: setKioskBln,
      isKiosk: isKiosk
   };
}();
module.exports = REV_KIOSK;