var privacypolicy = function() {
    var privacy = {
            Docs: 0,
            PrivacyUrl: '',
            TermsUrl: '',
            DocsDate: '',
            CompanyName: '',
            AcceptedTermDate: '',
            ErrorString: 'Please make sure you have agreed to the Terms of Use and Privacy Policy.',
            Terms_Privacy_Policy : ''
        },
        pp_webView /*privacy policy webview*/ ,
        pp_webViewNeedsClear = false,
        needsRst = false,
        theView, policyView, linkView, isCombined = false, combinedObjList = [], combinedText = '',
        //_eventTwo,
        Init = function(Docs, PrivacyUrl, TermsUrl, DocsDate, CompanyName, acceptedTerm, termsPrivacyPolicy) {
            
            isCombined = false;
            combinedObjList = [];
            combinedText = '';
            if (!isNaN(parseInt(Docs, 10))) {
                privacy.Docs = parseInt(Docs, 10);
            }
            privacy.PrivacyUrl = PrivacyUrl ? PrivacyUrl : '';
            privacy.TermsUrl = TermsUrl ? TermsUrl : '';
            privacy.DocsDate = DocsDate;
            privacy.CompanyName = CompanyName ? CompanyName : '';
            privacy.AcceptedTermDate = acceptedTerm ? acceptedTerm : '';
            privacy.Terms_Privacy_Policy = termsPrivacyPolicy ? termsPrivacyPolicy : '';            
            if(termsPrivacyPolicy){
                isCombined = true;
                var tpp = privacy.Terms_Privacy_Policy;
                var tppStr = tpp.replace('[CompanyName]', privacy.CompanyName);
                var matches = tppStr.match(/\[.*?\]/gi);                                
                if(matches){
                    for(var i = 0; i < matches.length; i++){
                        if(matches[i].toString().includes('|')){
                            var splitStr = matches[i].toString().split('|');
                            if(splitStr.length > 0){
                                var obj = {};
                                obj.txt = splitStr[0].replace('[','');
                                obj.url = splitStr[1].replace(']','');                            
                                combinedObjList.push(obj);
                                tppStr = tppStr.replace(matches[i].toString(), obj.txt);
                            }
                        }
                    }
                }
              
                combinedText = tppStr;
            } 
        },
        isEnabled = function() {
            return (privacy.Docs > 0);
        },
        getPolicyLbl = function() {
            var policyText = '';
            if(isCombined){                
                policyText = combinedText;
            }else{
                switch (privacy.Docs) {
                    case 1:
                        policyText = 'I agree to ' + privacy.CompanyName + ' Terms of Use. I also agree to Revention\'s, Terms of Use and Privacy Policy.';
                        break;
                    case 2:
                        policyText = 'I agree to ' + privacy.CompanyName + ' Privacy Policy. I also agree to Revention\'s, Terms of Use and Privacy Policy.';
                        break;
                    case 3:
                        policyText = 'I agree to ' + privacy.CompanyName + ' Terms of Use and Privacy Policy. I also agree to Revention\'s, Terms of Use and Privacy Policy.';
                        break;
                    default:
                        break;
                }
            }
            return policyText;
        },
        checkDts = function() {
            var dtCheck = false;

            if (privacy.AcceptedTermDate && (privacy.AcceptedTermDate > privacy.DocsDate) && !ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                dtCheck = true;
            }

            return dtCheck;
        },
        getNewPolicyView = function(thisView) {
            theView = thisView;
            policyView = Ti.UI.createView({
                height: Ti.UI.FILL,
                width: ro.ui.properties.wideViewWidth,
                layout: 'horizontal',
                height: Ti.UI.SIZE,
                top: ro.ui.relX(10),
                bottom: ro.ui.relX(10)
            });

            var isChecked = checkDts();
            var lblColor = ro.ui.theme.privacyPolicyTxtLbl;
            var policyCheckbox = Ti.UI.createView({
                    //height:Ti.UI.FILL,
                    top: ro.ui.relX(10),
                    width: ro.ui.relX(20),
                    height: ro.ui.relY(20),
                    borderRadius: ro.ui.relX(10),
                    theValue: isChecked == true ? true : false,
                    borderColor: lblColor,
                    borderWidth: ro.ui.relX(2),
                    backgroundImage: isChecked ? "/images/switch_on.png" : null
                }),
                policyLbl = Ti.UI.createLabel({
                    text: '',
                    font: {
                        fontSize: ro.ui.scaleFont(15),
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.policyText
                    },
                    height: Ti.UI.SIZE,
                    width: Ti.UI.FILL,
                    color: lblColor,
                    left: ro.ui.relX(10),
                    top: ro.ui.relX(5)
                });
            policyCheckbox.addEventListener('click', function() {
                policyCheckbox.theValue = !policyCheckbox.theValue;

                policyCheckbox.backgroundImage = policyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_onFAKE.png";
            });
            policyLbl.addEventListener('click', function(e) {
                policyCheckbox.theValue = !policyCheckbox.theValue;

                policyCheckbox.backgroundImage = policyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_onFAKE.png";
            });

            policyLbl.text = getPolicyLbl();
            var leftVw, rightVw;
            leftVw = Ti.UI.createView({
                top: 0,
                left: 0,
                width: ro.ui.relX(40),
                height: Ti.UI.SIZE
            });

            rightVw = Ti.UI.createView({
                top: 0,
                left: 0,
                width: ro.ui.relX(274),
                layout: 'vertical',
                height: Ti.UI.SIZE
            });

            leftVw.add(policyCheckbox);
            rightVw.add(policyLbl);

            //policyView.add(leftVw);
            //policyView.add(rightVw);
            //policyView.add(policyCheckbox);
            //policyView.add(policyLbl);

            linkView = Ti.UI.createView({
                height: ro.ui.relY(25),
                width: Ti.UI.FILL
            });
            var linkLbl = Ti.UI.createLabel({
                text: 'View Terms of Use and Privacy Policy',
                font: {
                    fontSize: ro.ui.scaleFont(15),
                    //fontWeight:'bold',
                    fontFamily: ro.ui.fonts.policyText
                },
                color: '#eb0029',
                top: ro.ui.relY(5),
                left: ro.ui.relX(10)
            });

            linkLbl.addEventListener('click', function(e) {
                needsRst = true;
                privacyPopup();
            });
            rightVw.add(linkLbl);
            policyView.add(leftVw);
            policyView.add(rightVw);
            //linkView.add(linkLbl);
            fullView = Ti.UI.createView({
                height: Ti.UI.SIZE,//ro.ui.relY(120),
                layout: 'vertical',
                top: ro.ui.relY(15),
                width: ro.ui.displayCaps.platformWidth,
                backgroundColor: '#F2F2F2'
                //width: ro.ui.properties.wideViewWidth
            });
            fullView.add(policyView);
            //fullView.add(linkView);
            return fullView;
        },
        hasAccepted = function() {
            if (policyView.children[0].children[0].theValue != true) {
                ro.ui.alert('Error: ', privacy.ErrorString);
            }
            return ((policyView.children[0].children[0].theValue == true /*|| policyView.children[0].value == 1*/ ) ? true : false);
        },
        privacyPopup = function(_eOne, _eTwo) {
            var privacyAll = [];
            var privacyOptions = Ti.UI.createOptionDialog({
                options: null
            });
            var optionsView = Ti.UI.createView();
            var optionsTbl = Ti.UI.createTableView({
                height: Ti.UI.SIZE,
                width: Ti.UI.SIZE
            });
            var backObj = {
                txt: 'DONE'
            };
            if(isCombined){
                privacyAll = combinedObjList.concat(backObj);
            }else{
                var reventionTerms = {
                    txt: 'Terms of Use - Revention, Inc.',
                    url: 'http://revention.com/hungerrush/terms-of-use'
                };
                var reventionPrivacy = {
                    txt: 'Privacy Policy - Revention, Inc.',
                    url: 'http://revention.com/hungerrush/privacy-policy'
                };
    
                var partnerTerms = {
                    txt: 'Terms of Use - ' + privacy.CompanyName,
                    url: privacy.TermsUrl
                };
                var partnerPrivacy = {
                    txt: 'Privacy Policy - ' + privacy.CompanyName,
                    url: privacy.PrivacyUrl
                };                
    
                var privacyRevention = [reventionTerms, reventionPrivacy, backObj],
                    privacyPartner = [];
    
                switch (privacy.Docs) {
                    case 1:
                        privacyPartner.push(partnerTerms);
                        break;
                    case 2:
                        privacyPartner.push(partnerPrivacy);
                        break;
                    case 3:
                        privacyPartner.push(partnerTerms);
                        privacyPartner.push(partnerPrivacy);
                        break;
                    default:
                        break;
                }
                privacyAll = privacyPartner.concat(privacyRevention);
            }
            

            var tblData = [];
            var strList = [];
            for (var i = 0; i < privacyAll.length; i++) {
                if (ro.isiOS) {
                	strList.push(privacyAll[i].txt);
					
                } else {
                    var tblRow = Ti.UI.createTableViewRow({
                        height: ro.ui.relY(60),
                        width: Ti.UI.FILL,
                        selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                    });
                    var rowLbl = Ti.UI.createLabel({
                        text: privacyAll[i].txt,
                        font: {
                            fontWeight: 'bold',
                            fontSize: ro.ui.scaleFont(15),
                            fontFamily: ro.ui.fontFamily
                        },
                        color: ro.ui.theme.loginBtnWhite,
                        textAlign: 'center'
                    });
                    if (privacyAll[i].url) {
                        tblRow.url = privacyAll[i].url;
                        rowLbl.url = privacyAll[i].url;
                    }
                    tblRow.add(rowLbl);
                    tblData.push(tblRow);
                }
            }

            optionsTbl.data = tblData;
            optionsView.add(optionsTbl);
            optionsTbl.addEventListener('click', function(e) {
                privacyOptions.hide();
                if (!e.source.url) {
                    resetPolicyView();
                    return;
                }
				openWebView(e.source.url);
                
                if (_eOne) {
                    _eOne();
                }
            });
            var openWebView = function(url){
            	ro.ui.showLoader();
                theView.height = Ti.UI.FILL;
                pp_webViewNeedsClear = true;
                pp_webView = Ti.UI.createWebView({
                    height: Ti.UI.FILL,
                    width: Ti.UI.FILL,
                    borderRadius: 1,
                    url: url
                });
                pp_webView.addEventListener('postlayout', function(e) {
                    ro.ui.hideLoader();
                });
                //fullView.removeAllChildren();

                theView.add(pp_webView);	
            };
            privacyOptions.androidView = optionsView;           
          	privacyOptions.options = strList;
            privacyOptions.addEventListener('click', function(e) {
                if(ro.isiOS){
                	if(!privacyAll[e.index].url){
                		resetPolicyView();
                	} else {
                		openWebView(privacyAll[e.index].url);
                	}
                } else{
                	resetPolicyView();
                }
                
            });
            privacyOptions.show();
        },
        needsReset = function() {
            return needsRst == true ? true : false;
        },
        resetPolicyView = function() {
            needsRst = false;
            theView.height = ro.ui.relY(0);
            theView.removeAllChildren();
            //theView.add(policyView);
            //fullView.add(linkView);

            releaseWebview();
            /*if(_eventTwo){
            	_eventTwo();
            }*/
        },
        releaseWebview = function() {
            if (!pp_webViewNeedsClear || ro.isiOS) {
                return;
            }
            pp_webView.release();
            pp_webViewNeedsClear = false;
        };
    return {
        Init: Init,
        isEnabled: isEnabled,
        hasAccepted: hasAccepted,
        getNewPolicyView: getNewPolicyView,
        resetPolicyView: resetPolicyView,
        needsReset: needsReset,
        releaseWebview: releaseWebview
    };
}();
module.exports = privacypolicy;