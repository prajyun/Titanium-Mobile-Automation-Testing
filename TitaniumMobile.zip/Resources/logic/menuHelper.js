﻿
    exports.getGroups = function (menu, localDateTime) {
        var col = [];
        if(!menu){
           return col;
        }
        if (menu.AllowSubMenus) {
            var SubMenuIdx = -1;
            var subMenuName = '';
            if(menu.SubMenuTimes && menu.SubMenuTimes.length > 0) {
               //Ti.include('/logic/menuUtils.js');
               var menuUtils = require('logic/menuUtils');
                for (var i = 0; i < menu.SubMenuTimes.length; i++) {
                    var active = menu.SubMenuTimes[i].IsActive;
                    var weekdays = menu.SubMenuTimes[i].Weekdays;
                    var timeIdx = menu.SubMenuTimes[i].TimeIdx;
                    var startTime = menu.SubMenuTimes[i].StartTime;
                    var endTime = menu.SubMenuTimes[i].EndTime;
                    //Ti.include('/logic/menuUtils.js');
                    var weekdayValid = (weekdays == 0 || menuUtils.WeekdayValid(weekdays, localDateTime));
                    var timeValid = menuUtils.IsTimeValid(timeIdx, startTime, endTime, localDateTime);
                    if (active && weekdayValid && timeValid) {
                        subMenuName = menu.SubMenuTimes[i].SubmenuName;
                        break;
                    }
                }
            }

            if (subMenuName !== '' && menu.SubMenus && menu.SubMenus.length > 0) {
                for (var i = 0; i < menu.SubMenus.length; i++) {
                    if (menu.SubMenus[i].SubmenuName === subMenuName) {
                        SubMenuIdx = i;
                        break;
                    }
                }
            }

            if (SubMenuIdx > -1 && menu.SubMenus[SubMenuIdx].Grps && menu.SubMenus[SubMenuIdx].Grps.length > 0) {
                for (var i = 0; i < menu.SubMenus[SubMenuIdx].Grps.length; i++) {
                    var grp = menu.SubMenus[SubMenuIdx].Grps[i];
                    if(menu.Groups[grp.MenuGrpIdx].Items && menu.Groups[grp.MenuGrpIdx].Items.length){
                        col.push({
                            Name: menu.Groups[grp.MenuGrpIdx].Name,
                            ButtonName: menu.Groups[grp.MenuGrpIdx].ButtonName,
                            DisplayName: menu.Groups[grp.MenuGrpIdx].DisplayName,
                            HasImage: menu.Groups[grp.MenuGrpIdx].HasImage,
                            ImageSource: menu.Groups[grp.MenuGrpIdx].ImageSource
                        });
                    }
                }
                return col;
            }

        }

        for (var i = 0; i < menu.Groups.length; i++) {
            if(menu.Groups[i].Items && menu.Groups[i].Items.length){
                col.push({
                    Name: menu.Groups[i].Name,
                    ButtonName: menu.Groups[i].ButtonName,
                    DisplayName: menu.Groups[i].DisplayName,
                    HasImage: menu.Groups[i].HasImage,
                    ImageSource: menu.Groups[i].ImageSource
                });
            }
        }
        return col;
    };
    exports.getItemPrice = function (item, group, priceIdx) {
        var rtnStr = '';
        var low = 0;
        var high = 0;
        if (group.HasSizes && group.Sizes) {
            var szCol = getSizeCol(item, group, priceIdx);
            if (szCol.length > 0) {
                low = szCol[0].Price;
                high = szCol[0].Price;
                for (var i = 0; i < szCol.length; i++) {
                    if (szCol[i].Price > high) {
                        high = szCol[i].Price;
                    }
                    if (szCol[i].Price < low) {
                        low = szCol[i].Price;
                    }
                }
            }
        }
        else {
            var obj = getItemPriceNoSize(item, group, priceIdx);
            low = obj.Price;
            high = obj.Price;
        }

        if (item.HasPrefs && item.Prefs && item.Prefs.length > 0) {
            var pLow = 0;
            var pHigh = 0;
            for (var i = 0; i < item.Prefs.length; i++) {
                var pref = item.Prefs[i];
                if (pref.PrefMbrs && pref.PrefMbrs.length > 0) {
                    pLow = pref.PrefMbrs[0].Price;
                    pHigh = pref.PrefMbrs[0].Price;
                    for (var j = 0; j < pref.PrefMbrs.length; j++) {
                        if (pref.PrefMbrs[j].Price > pHigh) {
                            pHigh = pref.PrefMbrs[j].Price;
                        }
                        if (pref.PrefMbrs[j].Price < pLow) {
                            pLow = pref.PrefMbrs[j].Price;
                        }
                    }
                    low += pLow;
                    high += pHigh;
                }
            }
        }

        if (low == high) {
            rtnStr = '$' + (Math.round(low*100)/100).toFixed(2);
        }
        else {
            rtnStr = '$' + (Math.round(low * 100) / 100).toFixed(2) + ' - $' + (Math.round(high * 100) / 100).toFixed(2);
        }
        return rtnStr;
    };
    var getItemPriceNoSize = function (item, group, priceIdx) {
        var obj = { Price: item.Price, SecondItemPrice: 0, ThirdItemPrice: 0 };
        if (group.UseTieredPricing) {
            switch (priceIdx) {
                case 0:
                    if (item.TierObj.OT0Price != 0) {
                        obj.Price = item.TierObj.OT0Price;
                    }
                    obj.SecondItemPrice = item.TierObj.OT0Second;
                    obj.ThirdItemPrice = item.TierObj.OT0Third;
                    break;
                case 1:
                    if (item.TierObj.OT1Price != 0) {
                        obj.Price = item.TierObj.OT1Price;
                    }
                    obj.SecondItemPrice = item.TierObj.OT1Second;
                    obj.ThirdItemPrice = item.TierObj.OT1Third;
                    break;
                case 2:
                    if (item.TierObj.OT2Price != 0) {
                        obj.Price = item.TierObj.OT2Price;
                    }
                    obj.SecondItemPrice = item.TierObj.OT2Second;
                    obj.ThirdItemPrice = item.TierObj.OT2Third;
                    break;
            }
        }
        else {
            if (group.UseOrdTypePricing && priceIdx > 0) {
                if (priceIdx == 1 && item.OrdTypePrice1 != 0) {
                    obj.Price = item.OrdTypePrice1;
                }
                else if (priceIdx == 2 && item.OrdTypePrice2 != 0) {
                    obj.Price = item.OrdTypePrice2;
                }
            }
        }
        return obj;
    },
    getSizeCol = function (item, group, priceIdx) {
        var col = [];
        if (group.UseTieredPricing) {
            if (item.TierObj) {
                var TierSizeCol = null;
                switch (priceIdx) {
                    case 0:
                        TierSizeCol = item.TierObj.OT0Sizes;
                        break;
                    case 1:
                        TierSizeCol = item.TierObj.OT1Sizes;
                        break;
                    case 2:
                        TierSizeCol = item.TierObj.OT2Sizes;
                        break;
                }
                if (TierSizeCol && TierSizeCol != null) {
                    for (var i = 0; i < group.Sizes.length; i++) {
                        var price = -0.86;
                        var TierSize = null;
                        var ItemSize = null;
                        var grpSize = group.Sizes[i];
                        for (var j = 0; i < item.AvailableSizes.length; j++) {
                            if (item.AvailableSizes[j].Name == grpSize.Name) {
                                ItemSize = item.AvailableSizes[j];
                                price = item.AvailableSizes[j].Price;
                                break;
                            }
                        }
                        for (var j = 0; j < TierSizeCol.length; j++) {
                            if (TierSizeCol[j].Size == grpSize.Name && TierSizeCol[j].Price != -0.86) {
                                TierSize = TierSizeCol[j];
                                if (TierSizeCol[j].Price != 0) {
                                    price = TierSizeCol[j].Price;
                                }
                            }
                        }
                        if (TierSize != null && ItemSize != null) {
                            col.push({
                                Size: grpSize.Name,
                                ReceiptName: ItemSize.ReceiptName,
                                KitchenName: ItemSize.KitchenName,
                                ButtonName: ItemSize.ButtonName,
                                Price: price,
                                PairPrice: ItemSize.PairPrice,
                                ModValue: ItemSize.ModValue,
                                Mod2ndValue: ItemSize.Mod2ndValue,
                                SecondItemPrice: TierSize.SecondItemPrice,
                                OrdTypePrice1: ItemSize.OrdTypePrice1,
                                OrdTypePrice2: ItemSize.OrdTypePrice2,
                                OnlineDefault: grpSize.OnlineDefault,
                                ThirdItemPrice: TierSize.ThirdItemPrice,
                                PrepTimeSecs: grpSize.PrepTimeSecs,
                                ProdItmCnt: grpSize.ProdItmCnt
                            });
                        }
                    }
                }
            }
        }
        else {
            for (var i = 0; i < group.Sizes.length; i++) {
                var grpSize = group.Sizes[i];
                for (var j = 0; j < item.AvailableSizes.length; j++) {
                    var ItemSize = item.AvailableSizes[j];
                    if (ItemSize.Name == grpSize.Name) {
                        var ordTypePrice = ItemSize.Price;
                        if (group.UseOrdTypePricing && priceIdx == 1 && ItemSize.OrdTypePrice1 != 0) {
                            ordTypePrice = ItemSize.OrdTypePrice1;
                        }
                        else if (group.UseOrdTypePricing && priceIdx == 2 && ItemSize.OrdTypePrice2 != 0) {
                            ordTypePrice = ItemSize.OrdTypePrice2;
                        }
                        if (ordTypePrice != -0.86) {
                            col.push({
                                Size: grpSize.Name,
                                ReceiptName: ItemSize.ReceiptName,
                                KitchenName: ItemSize.KitchenName,
                                ButtonName: ItemSize.ButtonName,
                                Price: ordTypePrice,
                                PairPrice: ItemSize.PairPrice,
                                ModValue: ItemSize.ModValue,
                                Mod2ndValue: ItemSize.Mod2ndValue,
                                SecondItemPrice: ItemSize.SecondItemPrice,
                                OrdTypePrice1: ItemSize.OrdTypePrice1,
                                OrdTypePrice2: ItemSize.OrdTypePrice2,
                                OnlineDefault: grpSize.OnlineDefault,
                                ThirdItemPrice: 0,
                                PrepTimeSecs: grpSize.PrepTimeSecs,
                                ProdItmCnt: grpSize.ProdItmCnt
                            });
                        }
                        break;
                    }
                }
            }
        }
        return col;
    };
    