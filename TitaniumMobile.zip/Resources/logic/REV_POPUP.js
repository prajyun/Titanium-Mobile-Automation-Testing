var REV_POPUP = function(){
	var getpopup = function(ro){
	   var popup = function(_evt){
	   		var style; 
	   		//var osname = Ti.Platform.osname;
	   		//var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;
	   		/*if(isiOS){
	   			style = require('/styles/style');
	   		}
	   		else{
	   			style = $$;
	   		}*/
	   		style = ro.ui.properties;
	   	
	   	  	 var parentView = Ti.UI.createView(style.popupView);
		     var containerView = Ti.UI.createView(style.popupContainer);
			 var alertView = Ti.UI.createView(style.popupAlertView);
			 var shadowView = Ti.UI.createView(style.popupShadow);
			 containerView.add(shadowView);
			
			 var headerLbl = Ti.UI.createLabel(style.popupHdrLbl);
			 alertView.add(headerLbl);
			
			 var instructionsLbl = Ti.UI.createLabel(style.popupBodyLbl);
			 alertView.add(instructionsLbl);
			
			 var ok = Ti.UI.createButton(style.popupButton);
			 ok.addEventListener('click', function(e) {
					parentView.hide();
					_evt();
			 });
			 alertView.add(ok);
			
		 	 containerView.add(alertView);
			 parentView.add(containerView);
			 parentView.showAlert = function(ttl, msg){
				headerLbl.text = ttl;
				instructionsLbl.text = msg;
				parentView.show();
			 };
			 return parentView;
	    };
	    ro.popup = popup;
   };
   return {
       getpopup:getpopup
   };
}();
module.exports = REV_POPUP;