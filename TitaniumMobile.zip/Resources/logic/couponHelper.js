var cpnHelper = function(){
	var cpnhelper = function(ro){
		var cpnIdx,							//Coupon index in store object
			selectedCpn,					//Coupon from the store object
			 actualCpn,						//Unadulterated Coupon Object
			 isCoupon = false,			//Boolean - if using coupon navigation
			 currLoyaltyCode = null,
			 selCpnItmIdx,
			 selectedItemObj = {},
			 itemExists = -1,
			 itmGroupIdx,					//Group index in ro.app.Store.Menu.Groups
            itmIdx,
			 pickAny = [],
			 finalPickAny = [],
			 isPickAny = false,
			 reqAny = [],
			 finalReqAny = [],
			 isReqAny = false,
			 cpnItms = [],
			 isReqItemBool = false,
			 currPickIndex = 0,
			 currIsReq = false,
			 PA_szCol = [],
			 PA_specs = {
			    MenuGroup:[],
			    MenuItem:[],
			    MenuSize:[],
			    MenuStyle:[],
	          MenuStyles:[],
	          MenuSizes:[]
			 },
			 RA_specs = {
	          MenuGroup:[],
	          MenuItem:[],
	          MenuSize:[],
	          MenuStyle:[],
	          MenuStyles:[],
	          MenuSizes:[]
	       },
			 bogoDoneCol; 						//Item index in ro.app.Store.Menu.Groups[itmGroupIdx].Items
	
		var cpnHelper = {};
	
		
		cpnHelper.findItem = function(cpnKey) {

			pickAny = [];
			finalPickAny = [];
			isPickAny = false;
			reqAny = [];
			finalReqAny = [];
			isReqAny = false;
			cpnItms = [];
			isReqItemBool = false;
			currPickIndex = 0;
			currIsReq = false;
			PA_szCol = [];
			PA_specs = {
				MenuGroup : [],
				MenuItem : [],
				MenuSize : [],
				MenuStyle : [],
				MenuStyles : [],
				MenuSizes : []
			};
			RA_specs = {
				MenuGroup : [],
				MenuItem : [],
				MenuSize : [],
				MenuStyle : [],
				MenuStyles : [],
				MenuSizes : []
			};

			var newRows = [];
			cpnIdx = ro.utils.getMatchingIdx(cpnKey, ro.app.Store.Menu.Cpns, 'Key');			
			actualCpn = ro.app.Store.Menu.Cpns[cpnIdx];
			selectedCpn = JSON.parse(JSON.stringify(ro.app.Store.Menu.Cpns[cpnIdx]));
			//Ti.API.info('cpnIdx: ' + cpnIdx);
			//Ti.API.info('selectedCpn items length: ' + selectedCpn.Items.length);

			if (selectedCpn && selectedCpn.Items && selectedCpn.Items.length) {
				cpnItms = selectedCpn.Items;
			}

			createPickAnyGroup();
			createRequireAnyGroup();

			if (isPickAny == true || isReqAny == true) {

				getCpItms(cpnItms);

				//var nonSpecialItems = [];
				//var specialItemsExistsBln = false;
				var GetIndexes = function(item) {
					var returnIndexes = {
						ii : null,
						gi : null
					};

					var gridx = ro.utils.getMatchingIdx(item.MenuGroup, ro.app.Store.Menu.Groups, 'Name');
					returnIndexes.gi = gridx;
					if (item.MenuItem && item.MenuItem.length && item.MenuItem.toLowerCase() != "all") {
						var iidx = ro.utils.getMatchingIdx(item.MenuItem, ro.app.Store.Menu.Groups[gridx].Items, 'Name');
						returnIndexes.ii = iidx;
					}
					//Ti.API.debug('returnIndexes: ' + JSON.stringify(returnIndexes));
					return returnIndexes;
				};
				var fixSpecialCase = function(reqBool) {
					var ctr = 0,
					    img,
					    str;
					for (var i = 0; i < selectedCpn.Items.length; i++) {
						if (reqBool == selectedCpn.Items[i].IsRequired) {
							idxHolder = i;
							ctr++;
						}
					}
					if (ctr == 1) {
						var gridx = 0,
						    itidx = 0;
						var gridx = ro.utils.getMatchingIdx(selectedCpn.Items[idxHolder].MenuGroup, ro.app.Store.Menu.Groups, 'Name');
						var isItm = false;
						if (selectedCpn.Items[idxHolder].MenuItem.toLowerCase() == 'all') {
							img = ro.app.Store.Menu.Groups[gridx].ImageSource;
							str = 'Choose ' + (ro.app.Store.Menu.Groups[gridx].DisplayName ? ro.app.Store.Menu.Groups[gridx].DisplayName : ro.app.Store.Menu.Groups[gridx].Name);
						} else {
							itidx = ro.utils.getMatchingIdx(selectedCpn.Items[idxHolder].MenuItem, ro.app.Store.Menu.Groups[gridx].Items, 'Name');
							img = ro.app.Store.Menu.Groups[gridx].Items[itidx].ImageSource;
							str = 'Select ' + (ro.app.Store.Menu.Groups[gridx].Items[itidx].DisplayName ? ro.app.Store.Menu.Groups[gridx].Items[itidx].DisplayName : ro.app.Store.Menu.Groups[gridx].Items[itidx].Name);
							isItm = true;
						}
						return {
							img : img,
							str : str,
							isSpecial : true,
							isItem : isItm,
							gi : gridx,
							ii : itidx
						};
					} else {
						return {
							isSpecial : false
						};
					}
				};

				var specialItems = [];
				var pickCnt = 0,
				    reqCnt = 0,
				    specialCnt = 0;
				var reqArr = [],
				    pickArr = [],
				    specialArr = [];

				reqCnt = selectedCpn.RequireAnyCnt ? selectedCpn.RequireAnyCnt : 0;
				if (reqCnt) {
					var reqFix = {
						isSpecial : false
					};
					reqFix = fixSpecialCase(true);
				}

				pickCnt = selectedCpn.PickAnyCnt ? selectedCpn.PickAnyCnt : 0;
				if (pickCnt) {
					var pickFix = {
						isSpecial : false
					};
					pickFix = fixSpecialCase(false);
				} else {

					for (var j = 0,
					    jMax = selectedCpn.Items && selectedCpn.Items.length ? selectedCpn.Items.length : 0; j < jMax; j++) {
						if (!selectedCpn.Items[j].IsRequired) {
							//specialItemsExistsBln = true;
							specialItems.push(selectedCpn.Items[j]);
						}
					}
					specialCnt = specialItems && specialItems.length ? specialItems.length : 0;

					if (specialCnt) {
						var specialFix = {
							isSpecial : false
						};
						specialFix = fixSpecialCase(false);
						//Ti.API.debug('specialFix: ' + JSON.stringify(specialFix));
					}
				}                

				for (var i = 0; i < reqCnt; i++) {
					reqArr.push({
						MenuGroup : 'ReqAny',
						MenuItem : 'All',
						MenuStyle : selectedCpn.MenuStyle,
						MenuSize : selectedCpn.MenuSize,
						IsRequired : true,
						Name : 'Required Item',
						isSpecial : reqFix.isSpecial,
						img : reqFix.img || '',
						str : reqFix.str || '',
						isItem : reqFix.isItem,
						ii : reqFix.ii,
						gi : reqFix.gi
					});
				}
				for (var i = 0; i < pickCnt; i++) {
					pickArr.push({
						MenuGroup : 'PickAny',
						MenuItem : 'All',
						MenuStyle : selectedCpn.MenuStyle,
						MenuSize : selectedCpn.MenuSize,
						IsRequired : false,
						Name : 'Pick Any',
						isSpecial : pickFix.isSpecial,
						img : pickFix.img || '',
						str : pickFix.str || '',
						isItem : pickFix.isItem,
						ii : pickFix.ii,
						gi : pickFix.gi
					});
				}
				cpnItms = reqArr.concat(pickArr);

				if (specialCnt) {
					var theseIndexes = {};
					for (var i = 0; i < specialCnt; i++) {
						theseIndexes = {};
						//Ti.API.debug('specialItems['+i+']: ' + JSON.stringify(specialItems[i]));
						theseIndexes = GetIndexes(specialItems[i]);
						specialArr.push({
							MenuGroup : specialItems[i].MenuGroup,
							MenuItem : specialItems[i].MenuItem,

							MenuStyle : specialItems[i].MenuStyle,
							MenuSize : specialItems[i].MenuSize,

							IsRequired : false,
							Name : specialItems[i].Name || '',
							isSpecial : specialFix.isSpecial,
							img : specialItems[i].ImageSource || '',
							str : specialFix.str || '',

							isItem : (specialItems[i].MenuItem && specialItems[i].MenuItem.length && specialItems[i].MenuItem.toLowerCase() == "all" ? false : true),
							ii : theseIndexes.ii >= 0 ? theseIndexes.ii : null, //specialFix.ii,
							gi : theseIndexes.gi >= 0 ? theseIndexes.gi : null, //specialFix.gi

							isSpecialMulti : (specialItems[i].MenuItem && specialItems[i].MenuItem.length && specialItems[i].MenuItem.toLowerCase() == "all" ? false : true)
						});

					}
					selectedCpn.specialCnt = specialCnt;
					cpnItms = cpnItms.concat(specialArr);
				}

				/*if(specialItemsExistsBln){
				 //selectedCpn.SpecialItemsCnt = nonSpecialItems.length;
				 selectedCpn.PickAnyCnt = nonSpecialItems.length;

				 var otherArr = [];

				 //cpnItms = cpnItms.concat(nonSpecialItems);
				 }*/
			}

			//Ti.API.debug('cpnItms: ' + JSON.stringify(cpnItms));
			if (cpnItms) {

                for (_idx = 0; _idx < cpnItms.length; _idx++) {                    
					itmGroupIdx = ro.utils.getMatchingIdx(cpnItms[_idx].MenuGroup, ro.app.Store.Menu.Groups, 'Name');

					if (itmGroupIdx !== -1) {
						itmIdx = ro.utils.getMatchingIdx(cpnItms[_idx].MenuItem, ro.app.Store.Menu.Groups[itmGroupIdx].Items, 'Name');

						if (itmIdx === -1) {
							if (cpnItms[_idx].MenuItem.toLowerCase() != 'all') {
								continue;
								/*throw {
									alertPrompt : true
								};*/
							}
							else {
								thisItm = ro.app.Store.Menu.Groups[itmGroupIdx];
								thisItm.isItem = false;
							}
						} 
						else {
							thisItm = ro.app.Store.Menu.Groups[itmGroupIdx].Items[itmIdx];
							thisItm.isItem = true;
							thisItm.itmIdx = itmIdx;
						}
						thisItm.cpnDetails = cpnItms[_idx];
						thisItm.grpIdx = itmGroupIdx;
						newRows.push(thisItm);
					} 
					else {//PickAny and ReqAny block
						if (isPickAny == true || isReqAny == true) {
							var thisItm,
							    stepItm;
							if (cpnItms[_idx].IsRequired) {
								stepItm = Ti.App.Properties.getString('rq');
							} 
							else {
								stepItm = Ti.App.Properties.getString('nrq');
							}

							thisItm = {
								Name : cpnItms[_idx].Name,
								cpnDetails : cpnItms[_idx],
								grpIdx : itmGroupIdx,
								isItem : false,
								isPickAny : cpnItms[_idx].IsRequired ? false : true,
								isReqAny : cpnItms[_idx].IsRequired ? true : false
							};
							newRows.push(thisItm);
						} 
						else {
							if (selectedCpn.CpnScope == 2 && selectedCpn.Items && selectedCpn.Items.length == 1 && selectedCpn.Items[0].MenuGroup && selectedCpn.Items[0].MenuGroup.length && selectedCpn.Items[0].MenuGroup.toLowerCase() == 'all') {
								if (selectedCpn.Items[0].MenuItem && selectedCpn.Items[0].MenuItem.length) {
									var menuUtils = require('logic/menuUtils');
									if (selectedCpn.Items[0].MenuItem.toLowerCase() == 'all') {
										var theGroup = menuUtils.isCpnConfiguredProperly(selectedCpn, true);
										if (theGroup) {
											thisItm = theGroup;
											thisItm.isItem = false;
											thisItm.cpnDetails = cpnItms[_idx];
											thisItm.grpIdx = theGroup.itmGroupIdx;
											newRows.push(thisItm);
										}
									} 
									else {
										var theItemFound = menuUtils.isCpnConfiguredProperly(selectedCpn, false, true);
										if (theItemFound) {
											thisItm = theItemFound;
											thisItm.isItem = true;
											thisItm.itmIdx = theItemFound.itmIdx;
											thisItm.cpnDetails = cpnItms[_idx];
											thisItm.grpIdx = theItemFound.itmGroupIdx;
											newRows.push(thisItm);
										}
									}
								}
							}
							if (!newRows || !newRows.length) {
								throw {
									alertPrompt : true
								};
							}
						}
					}
				}//endFor
			}
			return newRows;
		}; 

	
	
		function testPickAny(ordItm){
			var passed = false;
			var grpsAndItmsPassed = false;
			var szPassed = false;
			var styPassed = false;
			var itemLen = PA_specs && PA_specs.MenuGroup && PA_specs.MenuGroup.length ? PA_specs.MenuGroup.length : 0;
			for(var i=0; i<PA_specs.MenuGroup.length; i++){
				szPassed = false;
				styPassed = false;
				grpsAnItmsPassed = false;
				if((PA_specs.MenuGroup[i] == ordItm.GroupName) && (PA_specs.MenuItem[i] == ordItm.Name)){
					grpsAndItmsPassed = true;
					if(PA_specs.MenuSize[i] == 'All'){
						szPassed = true;
					}
					else{
						if(PA_specs.MenuSizes[i] && PA_specs.MenuSizes[i].length){
							var newSzCl = PA_specs.MenuSizes[i].toString().split("__");
							for(var j=0; j<newSzCl.length; j++){
								if(ordItm.Size == newSzCl[j]){
									szPassed = true;
									break;
								}
							}
						}
					}
	
	
					if(PA_specs.MenuStyle[i] == 'All'){
						styPassed = true;
					}
					else{
						if(PA_specs.MenuStyles[i] && PA_specs.MenuStyles[i].length){
							var newStyCl = PA_specs.MenuStyles[i].toString().split("__");
							for(var j=0; j<newStyCl.length; j++){
								if(ordItm.Style == newStyCl[j]){
									styPassed = true;
									break;
								}
							}
						}
					}
					if(szPassed == true && styPassed == true && grpsAndItmsPassed == true){
						passed = true;
						break;
					}
					else{
						passed = false;
					}
				}
				else{
	
				}
			}
	
			return passed;
		};
		function testReqAny(ordItm){
			var passed = false;
			for(var i=0; i<RA_specs.MenuGroup.length; i++){
				if((RA_specs.MenuGroup[i] == ordItm.GroupName) && (RA_specs.MenuItem[i] == ordItm.Name) && ((RA_specs.MenuStyle[i] == ordItm.Style) || RA_specs.MenuStyle[i] == 'All') && ((RA_specs.MenuSize[i] == ordItm.Size) || RA_specs.MenuSize[i] == 'All')){
					passed = true;
					break;
				}
				else{
	
				}
			}
	
			return passed;
		};
		function getImageSource(GroupName, Name){
		   var gIndx = ro.utils.getMatchingIdx(GroupName, ro.app.Store.Menu.Groups, 'Name');
		   var iIndx = ro.utils.getMatchingIdx(Name, ro.app.Store.Menu.Groups[gIndx].Items, 'Name');
		   return ro.app.Store.Menu.Groups[gIndx].Items[iIndx].ImageSource;
		}
	
	
		function checkOrdObj(cpnItem, ordObjCopy, multiQual){			
			var isSelectedItem = false;
			var selectedItemReturnObj = {};
			var ordObjLength = ordObjCopy.length;
			var foundFlag = false;
			var tempChkArray = [];
            for (var ordObjIdx = 0; ordObjIdx < ordObjLength; ordObjIdx++){                
				var orderItem = ordObjCopy[ordObjIdx];				
				orderItem.orderObjItmIdx = ordObjIdx;
				//Single Item & Bogo Coupons have priority over Multi Item Coupons
				if ((orderItem.CpnApplied == 2 && selectedCpn.CpnScope == 3) || orderItem.BogoID || (orderItem.CpnObj && (orderItem.CpnObj.CpnScope == 2 || orderItem.CpnObj.CpnScope == 4)) || orderItem.tempCpnKey) {
					continue;
				}				
					
				if (orderItem.isSingleItemCpn) {
					Ti.API.info('nullifying a bad singleItemCpnBln!!!!!!');
					orderItem.isSingleItemCpn = null;
				}

				if ((orderItem.GroupName == cpnItem.MenuGroup) || cpnItem.MenuGroup == 'All') {

				}
				else {
					if (cpnItem.MenuGroup.toLowerCase() == 'pickany') {
						if (testPickAny(orderItem)) {
							orderItem.ImageSource = getImageSource(orderItem.GroupName, orderItem.Name);
							ordObjCopy.splice(ordObjIdx, 1);
							return {
								found: true,
								tempItem: orderItem
							};
						}
						else {
							continue;
						}
					}
					else if (cpnItem.MenuGroup.toLowerCase() == 'reqany') {
						if (testReqAny(orderItem)) {
							orderItem.ImageSource = getImageSource(orderItem.GroupName, orderItem.Name);
							ordObjCopy.splice(ordObjIdx, 1);
							return {
								found: true,
								tempItem: orderItem
							};
						}
						else {
							continue;
						}
					}
					else {
						continue;
					}
				}

				if ((orderItem.Name == cpnItem.MenuItem) || cpnItem.MenuItem == 'All') {

				}
				else {
					continue;
				}

				if ((orderItem.Size == cpnItem.MenuSize) || cpnItem.MenuSize == 'All') {

				}
				else {
					continue;
				}

				if ((orderItem.Style == cpnItem.MenuStyle) || cpnItem.MenuStyle == 'All') {

				}
				else {
					continue;
				}

				if (!multiQual) {



					if (parseInt(getSelectedCpn().CpnScope, 10) == 2) {
						isSelectedItem = true;
						if (selectedItemReturnObj.tempItem) {
							if (selectedItemReturnObj.tempItem.RollupPrice < orderItem.RollupPrice) {
								var test = selectedItemReturnObj;

								test = {
									singleItemCouponIdx: ordObjIdx,
									found: true,
									tempItem: orderItem
								};
								selectedItemReturnObj = test;
								test = null;
								Ti.API.info('if - selectedItemReturnObj: ' + selectedItemReturnObj);
							}
						}
						else {
							var test = selectedItemReturnObj;
							Ti.API.info('ordObjIdx: ' + ordObjIdx);
							test = {
								singleItemCouponIdx: ordObjIdx,
								found: true,
								tempItem: orderItem
							};
							selectedItemReturnObj = test;
							test = null;
							Ti.API.info('else - selectedItemReturnObj: ' + JSON.stringify(selectedItemReturnObj));
						}
						if ((ordObjIdx + 1) == ordObjLength) {
							Ti.API.info('returning selectedItemReturnObj: ' + selectedItemReturnObj);
							return selectedItemReturnObj;
						}
						/*return{
							singleItemCouponIdx:ordObjIdx,
							found:true,
							tempItem:orderItem
						};*/
						continue;
					}
					else {
						ordObjCopy.splice(ordObjIdx, 1);
						return {
							bogoIdx: orderItem.idx,
							found: true,
							tempItem: orderItem
						};
					}
				}
				if (!foundFlag) {
					foundFlag = true;
				}
				//orderItem.orderObjItmIdx = ordObjIdx;
				tempChkArray.push(orderItem);
				
	        }
	      
	      if(isSelectedItem){
	      	return selectedItemReturnObj;
	      }
	      
	      if(foundFlag){
	         var index = 0;
	         var RollupPrice = tempChkArray[index].RollupPrice;
	
	         if(tempChkArray.length > 1){
	         	for(var c=0; c<tempChkArray.length; c++){
	         		if(tempChkArray[c].RollupPrice <= RollupPrice){
	         			RollupPrice = tempChkArray[c].RollupPrice;
	         			index = c;
	         		}
	         	}
	         }
	        	return{
	            found:true,
	            tempItem:tempChkArray[index]
	         };
	      }
	      else{
	         return{
	            found:false,
	            tempItem:{},
	            orderObjItmIdx:-1
	         };
	      }
	   }
	   var setSingleItemCouponIdentifier = function(singleItemIdx){
	   	  var identifier = parseInt(((new Date().getTime()) / 1000), 10);
	   	  
	   	  
	   	  var test = Ti.App.OrderObj;
	   	  if(!test.Items || !test.Items.length){
	   	  	test.Items = [];
	   	  }
	   	  test.Items[singleItemIdx].singleItemIdentifier = identifier;
	   	  Ti.App.OrderObj = test;
	   	  test = null;
	   	  
	   	  //var testCpn = selectedCpn;
	   	  selectedCpn.singleItemIdentifier = identifier;
	   	//  selectedCpn = testCpn;
	   	  //testCpn = null;
	   };
	   var getSelectedItemIdx = function(){
	   	  
	   	  for(var i=0, iMax=Ti.App.OrderObj.Items.length; i<iMax; i++){
	   	  	
	   	  	 if(Ti.App.OrderObj.Items[i].hasOwnProperty('singleItemIdentifier') && Ti.App.OrderObj.Items[i].singleItemIdentifier){
	   	  	 	if(Ti.App.OrderObj.Items[i].singleItemIdentifier === selectedCpn.singleItemIdentifier){
	   	  	 		return i;
	   	  	 	}
	   	  	 	else{
	   	  	 		delete Ti.App.OrderObj.Items[i].singleItemIdentifier;
	   	  	 		//Ti.App.OrderObj.Items[i].singleItemIdentifier = null;
	   	  	 	}
	   	  	 	//Search the selected Cpn for the same identifier and if they match, return the itemIdx
	   	  	 }
	   	  	 else{
	   	  	 	Ti.API.debug('NO SINGLEITEMIDENTIFIER FOUND - Ti.App.OrderObj.Items['+i+']: ' + JSON.stringify(Ti.App.OrderObj.Items[i]));
	   	  	 }
	   	  }
	   	  return null;
	   };
		cpnHelper.checkCart = function(e){
            var ordObj = Ti.App.OrderObj && Ti.App.OrderObj.Items ? JSON.parse(JSON.stringify(Ti.App.OrderObj.Items)) : []; 
            //indexing the items so they can be referred properly in the original BOGO items list
            var ordObjLength = ordObj.length;
            for (var ordObjIdx = 0; ordObjIdx < ordObjLength; ordObjIdx++) {
                ordObj[ordObjIdx].idx = ordObjIdx;
            }
			var bogoIdxCol = [];
	
			var completedItems = [];
			var completeItemsCount = 0;
			var setSingleItemBln = false;
			var singleItemIdx = -1;
	
			for(var cpIdx=0; cpIdx<cpnItms.length; cpIdx++){
				//setSingleItemBln = false;
				var cpnItmIndex = checkOrdObj(cpnItms[cpIdx], ordObj, selectedCpn.MultiQualTtl?true:false);
	
				if(cpnItmIndex.found){
					if(false && selectedCpn.MultiQualTtl && selectedCpn.MultiQualTtl > (Ti.App.OrderObj.Subtotal - cpnItmIndex.tempItem.RollupPrice)){
						cpnItmIndex = {
							found:false,
							tempItem:{},
							orderObjItmIdx:-1
						};
					}
					else{
                        if (parseInt(selectedCpn.CpnScope, 10) === 4) {
                            var bogoLength = bogoIdxCol.length;
                            bogoIdxCol.push(cpnItmIndex.bogoIdx + bogoLength);
                            var tempOrdObj = Ti.App.OrderObj;
                            tempOrdObj.Items[cpnItmIndex.bogoIdx].BogoCpnKey = e.cpnKey;
                            tempOrdObj.Items[cpnItmIndex.bogoIdx].BogoReq = cpnItms[cpIdx].BogoReq;                            
							Ti.App.OrderObj = tempOrdObj;
						}
						if(parseInt(selectedCpn.CpnScope, 10) === 2){
							Ti.API.debug('cpnItmIndex: ' + JSON.stringify(cpnItmIndex));
							setSingleItemBln = true;
							singleItemIdx = cpnItmIndex.singleItemCouponIdx;
							//Ti.App.OrderObj.Items[cpnItmIndex.singleItemCouponIdx].isSingleItemCpn = true;
							//setSingleItemCouponIdentifier(cpnItmIndex.singleItemCouponIdx, ordObj);
						}
						completeItemsCount++;
					}
	
					completedItems.push(cpnItmIndex);
				}
				else{
					completedItems.push(cpnItmIndex);
				}
			}
			var allDone = false, bogoCol = false;
			if(isPickAny==true || isReqAny==true){
				var totalItemsNeeded = 0;
				if(selectedCpn.PickAnyCnt > 0){
					totalItemsNeeded+=selectedCpn.PickAnyCnt;
				}
				if(selectedCpn.RequireAnyCnt > 0){
					totalItemsNeeded+=selectedCpn.RequireAnyCnt;
				}
				if(!isNaN(selectedCpn.specialCnt) && selectedCpn.specialCnt > 0){
					totalItemsNeeded+=selectedCpn.specialCnt;
				}
	
				if(completeItemsCount === totalItemsNeeded){
					allDone = true;
				}
	
			}
			else if(completeItemsCount === cpnItms.length){
				allDone = true;
			}
	
			if(bogoIdxCol.length === cpnItms.length){
				bogoDoneCol = bogoIdxCol;
			}
			
			
			if(setSingleItemBln){
				setSingleItemCouponIdentifier(singleItemIdx);
			}
			return{
				completedItems:completedItems,
				allDone:allDone
			};
		};
		//cpnHelper.get
		cpnHelper.validateCpn = function(e, newIdx){
			var storeObj = ro.app.Store;
			var returnBool = true;
			if(!isNaN(newIdx)){
			   cpnIdx = newIdx;
			}
	
			//Jan 26, 2011 Coupon validation by order type
			if(storeObj.Menu.Cpns[cpnIdx].NoDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
				ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not available for delivery orders');
				returnBool = false;
			}
	
			var ordPctCpnFound = false;
			if(Ti.App.OrderObj.Cpns){
				if(Ti.App.OrderObj.Cpns.length>0 && storeObj.Menu.Cpns[cpnIdx].IsExclusive){
					ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
					returnBool = false;
				}
	
				for(var i=0; i<Ti.App.OrderObj.Cpns.length; i++){
					if(Ti.App.OrderObj.Cpns[i].IsExclusive){
						ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[i].Name + ' coupon. This is not valid with any other coupon.');
						returnBool = false;
					}
	
					if(Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[cpnIdx].Name){
						if(storeObj.Menu.Cpns[cpnIdx].CpnScope == 1){
							ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Cpns[i].Name + ' coupon has already been applied to your order.');
							returnBool = false;
						}
					}
	
					if(Ti.App.OrderObj.Cpns[i].CpnType == 2){
						if(parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2){
							ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
							returnBool = false;
						}
					}
				}
			}
			if(Ti.App.OrderObj.TempCpns){
                if(Ti.App.OrderObj.TempCpns.length>0 && storeObj.Menu.Cpns[cpnIdx].IsExclusive){
                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
                    returnBool = false;
                }
    
                for(var i=0; i<Ti.App.OrderObj.TempCpns.length; i++){
                    if(Ti.App.OrderObj.TempCpns[i].IsExclusive){
                        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.TempCpns[i].Name + ' coupon. This is not valid with any other coupon.');
                        returnBool = false;
                    }
    
                    if(Ti.App.OrderObj.TempCpns[i].Name == storeObj.Menu.Cpns[cpnIdx].Name){
                        if(storeObj.Menu.Cpns[cpnIdx].CpnScope == 1){
                            ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.TempCpns[i].Name + ' coupon has already been applied to your order.');
                            returnBool = false;
                        }
                    }
    
                    if(Ti.App.OrderObj.TempCpns[i].CpnType == 2){
                        if(parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2){
                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                            returnBool = false;
                        }
                    }
                }
            }
            if (Ti.App.OrderObj.Items) {
                for (var x = 0; x < Ti.App.OrderObj.Items.length; x++) {
                  if(Ti.App.OrderObj.Items[x].CpnObj){
                    if (storeObj.Menu.Cpns[cpnIdx].IsExclusive) {
                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
                        returnBool = false;
                    }
                                      
                    if (Ti.App.OrderObj.Items[x].CpnObj.IsExclusive) {
                        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon. This is not valid with any other coupon.');
                        returnBool = false;
                    }

                    if (Ti.App.OrderObj.Items[x].CpnObj.Name == storeObj.Menu.Cpns[cpnIdx].Name) {
                        if (storeObj.Menu.Cpns[cpnIdx].CpnScope == 1) {
                            ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon has already been applied to your order.');
                            returnBool = false;
                        }
                    }

                    if (Ti.App.OrderObj.Items[x].CpnObj.CpnType == 2) {
                        if (parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2) {
                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                            returnBool = false;
                        }
                    }
                  }
                    
                }                
            }
			return returnBool;
		};
		var validatePctCpn = function(pctCpnIdx, dontShowMessage){
	      var storeObj = ro.app.Store;
	      var returnBool = true;
	      /*if(!isNaN(newIdx)){
	         pctCpnIdx = newIdx;
	      }*/
	
	      //Jan 26, 2011 Coupon validation by order type
	      if(storeObj.Menu.Cpns[pctCpnIdx].NoDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	         if(!dontShowMessage){
	            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[pctCpnIdx].Name + ' coupon is not available for delivery orders');
	         }
	         returnBool = false;
	         return returnBool;
	      }
	
	      var ordPctCpnFound = false;
	      if(Ti.App.OrderObj.Cpns){
	         if(Ti.App.OrderObj.Cpns.length>0 && storeObj.Menu.Cpns[pctCpnIdx].IsExclusive){
	            if(!dontShowMessage){
	               ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[pctCpnIdx].Name + ' coupon is not valid with any other coupon.');
	            }
	            returnBool = false;
	            return returnBool;
	         }
	
	         for(var i=0; i<Ti.App.OrderObj.Cpns.length; i++){
	            if(Ti.App.OrderObj.Cpns[i].IsExclusive){
	               if(!dontShowMessage){
	                  ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[i].Name + ' coupon. This is not valid with any other coupon.');
	               }
	               returnBool = false;
	               return returnBool;
	            }
	
	            if(Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[pctCpnIdx].Name){
	               if(storeObj.Menu.Cpns[pctCpnIdx].CpnScope == 1){
	                  if(!dontShowMessage){
	                     ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Cpns[i].Name + ' coupon has already been applied to your order.');
	                  }
	                  returnBool = false;
	                  return returnBool;
	               }
	            }
	
	            if(Ti.App.OrderObj.Cpns[i].CpnType == 2){
	               if(parseInt(storeObj.Menu.Cpns[pctCpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[pctCpnIdx].CpnType, 10) == 2){
	                  if(!dontShowMessage){
	                     ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[pctCpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
	                  }
	                  returnBool = false;
	                  return returnBool;
	               }
	            }
	         }
	      }
	      return returnBool;
	   };
	   cpnHelper.validatePctCpn = validatePctCpn;
        cpnHelper.addCpn = function (valcode, addToTempCpn) {
            var menuUtils = require('logic/menuUtils');
            // Added this line to handle cases where the selectedCpns duplicate Items are removed to accomodate the walkthrough, which is causing errors in POS
            var actualCpnIdx = ro.utils.getMatchingIdx(selectedCpn.Key, ro.app.Store.Menu.Cpns, 'Key');
            var coupon = ro.app.Store.Menu.Cpns[actualCpnIdx];
            //var coupon = selectedCpn;
			var storeObj = ro.app.Store;	
			var cpnObj = {};
			var Ord = Ti.App.OrderObj;
			if(addToTempCpn){
			    if(!Ord.TempCpns){
			        Ord.TempCpns = [];
			    }
			}
			if(!Ord.Cpns){
				Ord.Cpns = [];
			}
			var theValcode = menuUtils.getTempValcode(coupon.Key);
			cpnObj.Key = coupon.Key;
			cpnObj.CpnValue = coupon.CpnValue;
			cpnObj.RcptName = coupon.RcptName;
			cpnObj.Name = coupon.Name;
			cpnObj.CpnScope = coupon.CpnScope;
			cpnObj.CpnType = coupon.CpnType;
			cpnObj.CpnPct = coupon.CpnPct;
			cpnObj.MinPrice = coupon.MinPrice?coupon.MinPrice:0;
			cpnObj.MaxValue = coupon.MaxValue?coupon.MaxValue:0;
			cpnObj.AdjItemPrice = coupon.AdjItemPrice;
			cpnObj.TaxType = coupon.TaxType;
			cpnObj.ReportGrp = coupon.ReportGrp;
			cpnObj.FreeDlvy = coupon.FreeDlvy;
			cpnObj.LeaveTax = coupon.LeaveTax;
			cpnObj.No2ndItm = coupon.No2ndItm;
			cpnObj.BeatClock = coupon.BeatClock;
			cpnObj.DlvyFeeIfZero = coupon.DlvyFeeIfZero;
			cpnObj.NoModDisc = coupon.NoModDisc;
			cpnObj.NoStyleDisc = coupon.NoStyleDisc;
			cpnObj.NoPrefDisc = coupon.NoPrefDisc;
			if(currLoyaltyCode){
				cpnObj.LoyaltyCode = currLoyaltyCode;
				cpnObj.LtyDiscountType = 1;
				Ti.API.info('valcode: ' + valcode);
				if(ro.app.Store.Configuration.CP_APIKEY && ro.app.Store.Configuration.CP_APIKEY.length && theValcode && theValcode.length>2){
                   var testCode = theValcode[0] + theValcode[1];
                   if(testCode.toLowerCase() != "hc" && testCode.toLowerCase() != "ew"){
                       cpnObj.LtyDiscountType = 3;
                   }
                }
				
			}
	
			var curDate = new Date();
			var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
			cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
			cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	
			if(coupon.ReqValCode){
			   
			   cpnObj.ValCode = theValcode;
			}
			cpnObj.IsExclusive = coupon.IsExclusive;
			cpnObj.MultiQualTtl = coupon.MultiQualTtl?coupon.MultiQualTtl:0;
			cpnObj.PickAnyCnt = coupon.PickAnyCnt?coupon.PickAnyCnt:0;
			cpnObj.RequireAnyCnt = coupon.RequireAnyCnt?coupon.RequireAnyCnt:0;
			cpnObj.RequiredItem = coupon.RequiredItem;
			cpnObj.MaxModValue = coupon.MaxModValue;            
			if(coupon.CpnScope >= 3){
				var cpnItmCol = [];
				for(var i=0; i<coupon.Items.length; i++){
					var cpnItmObj = {};
					cpnItmObj.MenuGroup = coupon.Items[i].MenuGroup;
					cpnItmObj.MenuItem = coupon.Items[i].MenuItem;
					cpnItmObj.MenuSize = coupon.Items[i].MenuSize;
                    cpnItmObj.MenuStyle = coupon.Items[i].MenuStyle;
                    cpnItmObj.MenuSizes = coupon.Items[i].MenuSizes;
                    cpnItmObj.MenuStyles = coupon.Items[i].MenuStyles;
					cpnItmObj.IsRequired = coupon.Items[i].IsRequired;	
					cpnItmObj.CpnKey = coupon.Key;
	            	cpnItmObj.MenuCpnItmKey = coupon.Items[i].MenuCpnItmKey;
	            	cpnItmObj.BogoReq = coupon.Items[i].BogoReq;
					cpnItmObj.MaxModValue = coupon.Items[i].MaxModValue;
					cpnItmObj.Surcharge = coupon.Items[i].Surcharge;
					cpnItmCol.push(cpnItmObj);
				}
				cpnObj.Items = cpnItmCol;
			}
			if(coupon.SingleUse){
	         cpnObj.SingleUseKey = coupon.Key;
	      }
	
            if (cpnObj.CpnScope == 4) {
	      	var items = [];
	      	var bogoIndexes = [];
	      	for(var bogoIdx=0; bogoIdx < Ord.Items.length; bogoIdx++){
	      		if(items && items.length == 2){
	      			break;
	      		}
	      		if(Ord.Items[bogoIdx].BogoCpnKey && (!Ord.Items[bogoIdx].CpnObj && !Ord.Items[bogoIdx].BogoID) && (coupon.Key === Ord.Items[bogoIdx].BogoCpnKey)){
	      			items.push(Ord.Items[bogoIdx]);
	      			bogoIndexes[items.length-1] = bogoIdx;
	      		}
	      	}
	
	         var bogoId = (new Date()).getTime() + '';
	         bogoId = bogoId.substring(bogoId.length - 9, bogoId.length - 1);
	         cpnObj.BogoID = bogoId;
	         var propToCompare = cpnObj.NoModDisc?'ActivePrice':'InclusivePrice';
	         // items correspond to the two items that are being added to cart
	         if(items && items.length == 2){	            
                 var boIdx = 0;
                 var goIdx = 1;
                 if (items[0].GroupName == items[1].GroupName) {
                     if (items[0][propToCompare] < items[1][propToCompare]) {
                         boIdx = 1;
                         goIdx = 0;
                     }
                 } else {
                     if (items[1].BogoReq) {
                         boIdx = 1;
                         goIdx = 0;
                     }
                 }	
	            items[boIdx].BogoID = bogoId;
	            items[goIdx].CpnObj = cpnObj;
	            var tempItms = Ord.Items;
	            tempItms[bogoIndexes[0]] = items[0];
	            tempItms[bogoIndexes[1]] = items[1];
	            Ord.Items = tempItms;
	         }
		   }
		   else{
		        //Add the cpn to regular order cpn collection
		      if(cpnObj.CpnScope == 2){
				var lyltyItemFound = false;
		      	 //Ti.API.info('cpnObj: ' + JSON.stringify(cpnObj));
		      	 /*Ti.API.debug('coupon: ' + JSON.stringify(coupon));
		      	 Ti.API.debug('Ti.App.OrderObj.Items: ' + JSON.stringify(Ti.App.OrderObj.Items));
		      	 Ti.API.debug('CpnScope == 2, maybe this is a special new coupon  ? ? ');*/
		      	 var selectedItemIndex = getSelectedItemIdx();
		      	 if(selectedItemIndex || selectedItemIndex === 0){					
					if(cpnObj.LoyaltyCode && cpnObj.LoyaltyCode != ""){									
						lyltyItemFound = true;
					}
					if(Ord.Items[selectedItemIndex].Qty && Ord.Items[selectedItemIndex].Qty > 1){
						Ord.Items[selectedItemIndex].Qty--;
						let itemCopy = JSON.parse(JSON.stringify(Ord.Items[selectedItemIndex]));
						Ord.Items[selectedItemIndex].Qty = 1;
						Ord.Items.splice(selectedItemIndex + 1, 0, itemCopy);
						itemCopy = null;
					}
		      	 	Ord.Items[selectedItemIndex].CpnObj = {};
		      	 	Ord.Items[selectedItemIndex].CpnObj = cpnObj;					
		      	 }
				  if (coupon.Items && coupon.Items.length && coupon.MultiQualTtl == 0) {					
					  for (i = 0, iMax = Ord.Items.length; i < iMax; i++) {						
						if(lyltyItemFound){
							break;
						  }   
						if (!Ord.Items[i].BogoID && !Ord.Items[i].hasOwnProperty('CpnObj')) {// || (Ord.Items[i].hasOwnProperty('CpnObj') && Object.entries(Ord.Items[i].CpnObj).length === 0)) {
							  var orderItem = Ord.Items[i];
							  for (j = 0; j < coupon.Items.length; j++) {
								  var cpnItem = coupon.Items[j];
								  if ((orderItem.GroupName == cpnItem.MenuGroup) || cpnItem.MenuGroup == 'All') {

								  }
								  else {
									  continue;
								  }

								  if ((orderItem.Name == cpnItem.MenuItem) || cpnItem.MenuItem == 'All') {

								  }
								  else {
									  continue;
								  }

								  if ((orderItem.Size == cpnItem.MenuSize) || cpnItem.MenuSize == 'All') {

								  }
								  else {
									  continue;
								  }

								  if ((orderItem.Style == cpnItem.MenuStyle) || cpnItem.MenuStyle == 'All') {

								  }
								  else {
									  continue;
								  }
								  if(cpnObj.LoyaltyCode && cpnObj.LoyaltyCode != ""){									
									lyltyItemFound = true;
								  } 
								  if(Ord.Items[i].Qty && Ord.Items[i].Qty > 1){
									Ord.Items[i].Qty--;
									let itemCopy = JSON.parse(JSON.stringify(Ord.Items[i]));
									Ord.Items[i].Qty = 1;
									Ord.Items.splice(i + 1, 0, itemCopy);
									itemCopy = null;
								  }
								  Ord.Items[i].CpnObj = {};
								  Ord.Items[i].CpnObj = cpnObj;								   
								  break;
							  }							  
						  }						  
					  }
				  }
		      }
		      else{
		          cpnObj.SelectedCoupon = coupon;
		          if(addToTempCpn){
		              //cpnObj.SelectedCoupon = coupon;
		              Ord.TempCpns.push(cpnObj);
		          }
		          else{
		              Ord.Cpns.push(cpnObj);
		          }
		      	 
		      }
            }
			Ti.API.info("Items: " + JSON.stringify(Ord.Items));            
			Ti.App.OrderObj = Ord;		
		};
		var addPctCpn = function(selectedPctCpn){
		  var menuUtils = require('logic/menuUtils');
	      var coupon = selectedPctCpn;
	      var storeObj = ro.app.Store;
	
	//Ti.API.debug('coupon: ' + JSON.stringify(coupon));
	
	      var cpnObj = {};
	      var Ord = Ti.App.OrderObj;
	      if(!Ord.Cpns){
	         Ord.Cpns = [];
	      }
	
	      cpnObj.CpnValue = coupon.CpnValue;
	      cpnObj.RcptName = coupon.RcptName;
	      cpnObj.Name = coupon.Name;
	      cpnObj.CpnScope = coupon.CpnScope;
	      cpnObj.CpnType = coupon.CpnType;
	      cpnObj.CpnPct = coupon.CpnPct;
	      cpnObj.MinPrice = coupon.MinPrice?coupon.MinPrice:0;
	      cpnObj.MaxValue = coupon.MaxValue?coupon.MaxValue:0;
	      cpnObj.AdjItemPrice = coupon.AdjItemPrice;
	      cpnObj.TaxType = coupon.TaxType;
	      cpnObj.ReportGrp = coupon.ReportGrp;
	      cpnObj.FreeDlvy = coupon.FreeDlvy;
	      cpnObj.LeaveTax = coupon.LeaveTax;
	      cpnObj.No2ndItm = coupon.No2ndItm;
	      cpnObj.BeatClock = coupon.BeatClock;
	      cpnObj.DlvyFeeIfZero = coupon.DlvyFeeIfZero;
	      cpnObj.NoModDisc = coupon.NoModDisc;
	      cpnObj.NoStyleDisc = coupon.NoStyleDisc;
		  cpnObj.NoPrefDisc = coupon.NoPrefDisc;
	
	      var curDate = new Date();
	      var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
	      cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	      cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	      //Ti.API.debug('cpnObj.TimeAppliedStr: ' + cpnObj.TimeAppliedStr);
	      //Ti.API.debug('cpnObj.TimeAppliedStr: ' + JSON.stringify(cpnObj.TimeAppliedStr));
	
	      if(coupon.ReqValCode){
	         var theValcode = menuUtils.getTempValcode(coupon.Key);
	         cpnObj.ValCode = theValcode;
	      }
	      cpnObj.IsExclusive = coupon.IsExclusive;
	      cpnObj.MultiQualTtl = coupon.MultiQualTtl?coupon.MultiQualTtl:0;
	      cpnObj.PickAnyCnt = coupon.PickAnyCnt?coupon.PickAnyCnt:0;
	      cpnObj.RequireAnyCnt = coupon.RequireAnyCnt?coupon.RequireAnyCnt:0;
	      cpnObj.RequiredItem = coupon.RequiredItem;
		  cpnObj.MaxModValue = coupon.MaxModValue;
	
	      if(coupon.CpnScope >= 3){
	         var cpnItmCol = [];
	         for(var i=0; i<coupon.Items.length; i++){
	            var cpnItmObj = {};
	            cpnItmObj.MenuGroup = coupon.Items[i].MenuGroup;
	            cpnItmObj.MenuItem = coupon.Items[i].MenuItem;
                cpnItmObj.MenuSize = coupon.Items[i].MenuSize;
                cpnItmObj.MenuSizes = coupon.Items[i].MenuSizes;
                cpnItmObj.MenuStyle = coupon.Items[i].MenuStyle;
                cpnItmObj.MenuStyles = coupon.Items[i].MenuStyles;
	            cpnItmObj.IsRequired = coupon.Items[i].IsRequired;	
	            cpnItmObj.CpnKey = coupon.Key;
	            cpnItmObj.MenuCpnItmKey = coupon.Items[i].MenuCpnItmKey;
	            cpnItmObj.BogoReq = coupon.Items[i].BogoReq;
				cpnItmObj.MaxModValue = coupon.Items[i].MaxModValue;
				cpnItmObj.Surcharge = coupon.Items[i].Surcharge;
	            cpnItmCol.push(cpnItmObj);
	         }
	         cpnObj.Items = cpnItmCol;
	      }
	      if(coupon.SingleUse){
	         cpnObj.SingleUseKey = coupon.Key;
	      }
	
	      if(cpnObj.CpnScope == 4){
	         var items = [];
	         var bogoIndexes = [];
	         for(var bogoIdx=0; bogoIdx < Ord.Items.length; bogoIdx++){
	            if(items && items.length == 2){
	               break;
	            }
	            if(Ord.Items[bogoIdx].BogoCpnKey && (!Ord.Items[bogoIdx].CpnObj && !Ord.Items[bogoIdx].BogoID) && (coupon.Key === Ord.Items[bogoIdx].BogoCpnKey)){
	               items.push(Ord.Items[bogoIdx]);
	               bogoIndexes[items.length-1] = bogoIdx;
	            }
	         }
	
	         var bogoId = (new Date()).getTime() + '';
	         bogoId = bogoId.substring(bogoId.length - 9, bogoId.length - 1);
	         cpnObj.BogoID = bogoId;
	         //var propToCompare = cpnObj.NoModDisc?'ActivePrice':'InclusivePrice';
	         // items correspond to the two items that are being added to cart
              if (items && items.length == 2) {
                  var boIdx = 0;
                  var goIdx = 1;
                  if (items[1].BogoReq) {
                      boIdx = 1;
                      goIdx = 0;
                  }
	            //

	            //if(items[0][propToCompare] < items[1][propToCompare]){
	            //   boIdx = 1;
	            //   goIdx = 0;
	            //}
	
	            items[boIdx].BogoID = bogoId;
	            items[goIdx].CpnObj = cpnObj;
	            Ord.Items[bogoIndexes[0]] = items[0];
	            Ord.Items[bogoIndexes[1]] = items[1];
	         }
	      }
	      else{
	           //Add the cpn to regular order cpn collection
	
	         Ord.Cpns.push(cpnObj);
	      }
	      Ti.App.OrderObj = Ord;
          Ti.API.info('Coupon Applied: ' + JSON.stringify(coupon));
	      ro.ui.alert('Success', coupon.Name + ' has been applied to your order!');
	   };
	   cpnHelper.addPctCpn = addPctCpn;
	   cpnHelper.addAutoCpns = function(storeObject){
	      Ti.API.debug('addAutoCpns() was called!');
	      var cpnsCol = storeObject.Menu.Cpns;
	      for(var i=0, iMax=cpnsCol.length; i<iMax; i++){
	         if(cpnsCol[i].AutoApply && cpnsCol[i].CpnScope === 1){
	            Ti.API.debug('cpnsCol['+i+']' + JSON.stringify(cpnsCol[i]));
	            if(validatePctCpn(i, true)){
	               addPctCpn(cpnsCol[i]);
	            }
	         }
	      }
	   };
	
	
		cpnHelper.setCpIdx = function(_idx){
			selCpnItmIdx = _idx;
		};
		var getCpIdx = function(){
			return selCpnItmIdx;
		};
		cpnHelper.getCpIdx = getCpIdx;
		cpnHelper.setCurrIsReq = function(reqBool){
            currIsReq = reqBool;
		};
		cpnHelper.setCurrPickIndex = function(_idx){
			currPickIndex = _idx;
		};
		cpnHelper.cpnSpecs = function(spec, pref){
		   if(isPickAnyCpn()){
	         var currPropertyCol = currIsReq ? RA_specs[spec] : PA_specs[spec];
	         if(currPropertyCol[currPickIndex] !== 'All'){
		         var currProp = currPropertyCol[currPickIndex].toString().split("__");
		         var returnCol = [];
		         for(var i=0; i<currProp.length; i++){
		         	returnCol.push(ro.utils.getMatchingIdx(currProp[i], pref, 'Name'));
		         }
		         return returnCol;
		      }
		      else{
		      	return -1;
		      }
		   }
	
			var cpnItem = cpnItms[getCpIdx()];
			if(cpnItem[spec] !== 'All'){
				return ro.utils.getMatchingIdx(cpnItem[spec], pref, 'Name');
			}
			else{
				return -1;
			}
		};
	
	
		cpnHelper.isCpn = function(){
			return isCoupon || false;
		};
		var resetCpnProperties = function(){
	
			//		PICKANY AND REQANY
			ro.utils.removeProp('SelectedCoupon');
			ro.utils.removeProp('nrq');
		   ro.utils.removeProp('rq');
			pickAny = [];
			finalPickAny = [];
			isPickAny = false;
			reqAny = [];
			finalReqAny = [];
			isReqAny = false;
			cpnItms = [];
			isReqItemBool = false;
			currPickIndex = null;
			currIsReq = false;
			PA_specs = {
	         MenuGroup:[],
	         MenuItem:[],
	         MenuSize:[],
	         MenuStyle:[],
	         MenuStyles:[],
	         MenuSizes:[]
	      };
	      RA_specs = {
	         MenuGroup:[],
	         MenuItem:[],
	         MenuSize:[],
	         MenuStyle:[],
	         MenuStyles:[],
	         MenuSizes:[]
	      };
			//		PICKANY AND REQANY
	
		};
		cpnHelper.setCpnBool = function(cpnBool, LoyaltyCode){
			isCoupon = cpnBool;
			
			currLoyaltyCode = LoyaltyCode || null;
			if(!cpnBool || cpnBool == false){
				resetCpnProperties();
				currLoyaltyCode = null;
			}
		};
	
	
		cpnHelper.chosenStyle = function(){
			try{
				if(selectedItemObj.Style && selectedItemObj.Style.length > 0){
					return selectedItemObj.Style;
				}
				else{
					return -1;
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('cpnHelper.chosenStyle()-Exception' + ex); }
			}
		};
		cpnHelper.chosenSize = function(){
            try {
				if(selectedItemObj.Size && selectedItemObj.Size.length > 0){
					return selectedItemObj.Size;
				}
				else{
					return -1;
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('cpnHelper.chosenSize()-Exception' + ex); }
			}
		};
		cpnHelper.chosenMods = function(modNm){
			try{
				if(selectedItemObj.Mods && selectedItemObj.Mods.length > 0){
					for(var i=0; i<selectedItemObj.Mods.length; i++){
						if(modNm === selectedItemObj.Mods[i].Name){
							return{
								isChosen:true,
								Qty:selectedItemObj.Mods[i].Qty,
								HalfStatus:selectedItemObj.Mods[i].HalfStatus,
								IsLite:selectedItemObj.Mods[i].IsLite
							};
						}
					}
				}
				return{
					isChosen:false
				};
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL) { Ti.API.debug('cpnHelper.chosenMods()-Exception' + ex); }
			}
		};
		cpnHelper.chosenPrefs = function(){
			try{
				if(selectedItemObj && selectedItemObj.Prefs && selectedItemObj.Prefs.length > 0){
					return selectedItemObj.Prefs;
				}
				else{
					return -1;
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('cpnHelper.chosenPrefs()-Exception' + ex); }
			}
		};
		cpnHelper.chosenItem = function(nm){
			try{
				if(nm === selectedItemObj.Name){
					return true;
				}
				return false;
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('cpnHelper.chosenItem()-Exception' + ex); }
			}
		};
		cpnHelper.setSelection = function(selectionObj){
			selectedItemObj = {
				Size:selectionObj.Size,
				//Style:selectionObj.StyleRcptName,
				Style:selectionObj.Style,
				Mods:selectionObj.Mods,
				Prefs:selectionObj.PrfMbrs,
				Name:selectionObj.RcptName,
				PreMods:selectionObj.PreMods,
				NoMods:selectionObj.NoMods
			};
		};
		cpnHelper.allMods = function(){
			return selectedItemObj.Mods || [];
		};
	    cpnHelper.getNoMods = function(modNm){
			var length = selectedItemObj.NoMods?selectedItemObj.NoMods.length:0;
	
			var foundNoMod = false;
			for(var i=0; i<length; i++){
				if(selectedItemObj.NoMods[i].Name === modNm){
					foundNoMod = selectedItemObj.NoMods[i];
					break;
				}
			}
			return foundNoMod;
		};
	
	
		cpnHelper.clearSelection = function(){
			selectedItemObj = {};
		};
		cpnHelper.setExistingItem = function(orderIdx){
			itemExists = orderIdx;
		};
		cpnHelper.existingItem = function(){
			return itemExists;
		};
		cpnHelper.getSelectedCpnNm = function(){
			return selectedCpn.Name;
		};
		cpnHelper.getItemIdx = function(choseItem){
			if(!Ti.App.OrderObj.Items){
				Ti.App.OrderObj.Items = [];
			}
			if(!choseItem.Mods){
				choseItem.Mods = [];
			}
			var ordItems = Ti.App.OrderObj.Items;
			for(var i=0; i<ordItems.length; i++){
				if(ordItems[i].CpnApplied === 2){
					continue;
				}
				else{
					if(ordItems[i].Name == choseItem.Name && ordItems[i].Size == choseItem.Size && ordItems[i].Style == choseItem.Style){
						if(!ordItems[i].Mods){
							ordItems[i].Mods = [];
						}
						var modLn = ordItems[i].Mods.length;
						var choseModLn = choseItem.Mods.length;
						var sameBool = true;
						if(modLn == choseModLn){
							for(var j=0; j<modLn; j++){
								if(ordItems[i].Mods[j].Name == choseItem.Mods[j].Name && ordItems[i].Mods[j].Qty == choseItem.Mods[j].Qty && ordItems[i].Mods[j].HalfStatus == choseItem.Mods[j].HalfStatus){
	
								}
								else{
									sameBool = false;
								}
							}
							if(sameBool){
								return i;
							}
						}
					}
				}
			}
			return -1;
		};
		cpnHelper.deleteItem = function(_idx){
			var temp = Ti.App.OrderObj;
			temp.Items.splice(_idx, 1);
			Ti.App.OrderObj = temp;
			//var func = new PricingFunctions();
			var priceEngine = require('logic/pricing');
	        var func = priceEngine.pricer();
			Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
			//ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
		};
		var getSelectedCpn = function(){
		   return selectedCpn;
		};
		cpnHelper.getSelectedCpn = getSelectedCpn;
	
	
		var createPickAnyGroup = function(){
			isPickAny = false;
			pickAny = [];
	
			if(selectedCpn.PickAnyCnt && selectedCpn.PickAnyCnt>0){
				isPickAny = true;
				var tempPickAny = [];
				if(!cpnItms || !cpnItms.length){
					cpnItms = [];
				}
				for(var i=0; i<cpnItms.length; i++){
					if(!cpnItms[i].IsRequired){
						//Ti.API.debug('pickany - cpnItms['+i+']: ' + JSON.stringify(cpnItms[i]));
						tempPickAny.push(cpnItms[i]);
					}
				}
	
				//pickAny = fixItemCol(tempPickAny);
	
				pickAny = tempPickAny;
			}
		};
		cpnHelper.getPickAnyGroup = function(){
			return pickAny;
		};
	
	
		var createRequireAnyGroup = function(){
			isReqAny = false;
			reqAny = [];
	
			if(selectedCpn.RequiredItem && selectedCpn.RequiredItem==true){
				isReqAny = true;
				if(!selectedCpn.RequireAnyCnt || selectedCpn.RequireAnyCnt == 0){
					selectedCpn.RequireAnyCnt = 1;
				}
			}
			if(isReqAny){
				var tempReqAny = [];
				if(!cpnItms || !cpnItms.length){
					cpnItms = [];
				}
				for(var i=0; i<cpnItms.length; i++){
					if(cpnItms[i].IsRequired){
						//Ti.API.debug('reqAny - cpnItms['+i+']: ' + JSON.stringify(cpnItms[i]));
						tempReqAny.push(cpnItms[i]);
					}
				}
				reqAny = tempReqAny;
			}
		};
		var getRequireAnyGroup = function(){
			return reqAny;
		};
	
	
        var getCpItms = function(itms){
			var getReqGrp = function(item){
				return (item.IsRequired&&item.IsRequired==true ? (item.MenuGroup.toLowerCase() + item.MenuStyle.toLowerCase() + item.MenuSize.toLowerCase()) : 'pickany');
			};
			var getItms = function(grpItms, item){
				var grp, sz, szsCol, sty, stysCol, isReq, bogoReq;
				grp = item.MenuGroup;
				sz = item.MenuSize;
				szsCol = item.MenuSizes;
				sty = item.MenuStyle;
				stysCol = item.MenuStyles;
				isReq = item.IsRequired;
				bogoReq = item.BogoReq;
	
				var grpItmsL = grpItms&&grpItms.length?grpItms.length:0;
				var returnArr = [];
				var currItem = [];
				var nm = '';
	
				for(var i=0; i<grpItmsL; i++){
					nm = grpItms[i].Name;
					currItem = [];
					currItem = grpItms[i];
					currItem.MenuGroup = grp;
					currItem.MenuItem = nm;
					currItem.MenuSize = sz;
					currItem.MenuSizes = szsCol;
					currItem.MenuStyle = sty;
					currItem.MenuStyles = stysCol;
					currItem.IsRequired = isReq;
					currItem.BogoReq = bogoReq;
	
	           	returnArr.push(currItem);
				}
				return returnArr;
			};
	
			var itmsL = itms&&itms.length?itms.length:0;
			var newItms = [];
			var tempNewItms = [];
	
			var tempObj = {
				req:[],
				non:[]
			};
			var tempStr = 'non';
			var rqItems = [];
            var pickItems = [];

	        // Removing duplicates from the items coz POS be like that
            var filterDuplicate = function (items, begin, end) {                
                if (begin >= end - 1) return;
                for (var i = end - 1; i > begin; i--) {
                    if (items[begin].MenuItem == items[i].MenuItem && items[begin].MenuGroup == items[i].MenuGroup && items[begin].MenuStyles == items[i].MenuStyles && items[begin].MenuSizes == items[i].MenuSizes && items[begin].IsRequired == items[i].IsRequired) {
                        items.splice(i, 1);
                    }
                }                
                filterDuplicate(items, begin + 1, items.length);
            }
            // Calling filter duplicate
            filterDuplicate(itms, 0, itms.length);            
			//var iCol = [];
			//var jTrack = [];
			//for(var i=0; i<itmsL; i++){
			//	var found = false;
			//	for(var j=itmsL-1; j>=0; j--){
			//		if(j==i){
			//			//Ti.API.debug('j==i');
			//			break;
			//		}
	        
			//		if(itms[i].MenuItem == itms[j].MenuItem && itms[i].MenuGroup == itms[j].MenuGroup && itms[i].MenuStyles == itms[j].MenuStyles && itms[i].MenuSizes == itms[j].MenuSizes && itms[i].IsRequired == itms[j].IsRequired){
			//			found = true;
			//			var locItm = itms[i];
			//			iCol.push(locItm);
			//			jTrack.push(j);
			//		}
			//	}
			//	if(!found){
			//		var skipNext = false;
			//		for(var k=0; k<jTrack.length; k++){
			//			if(jTrack[k] == i){
			//				skipNext = true;
			//			}
			//		}
	        
			//		if(!skipNext){
			//			iCol.push(itms[i]);
			//		}
			//	}
			//}
   //         itms = iCol;
            //Ti.API.info("itms: "+ JSON.stringify(itms));
            itmsL = itms && itms.length ? itms.length : 0;
			for(var i=0; i<itmsL; i++){
				tempNewItms = [];
				tempStr = itms[i].IsRequired&&itms[i].IsRequired==true ? 'req' : 'non';
                if(itms[i].MenuItem.toLowerCase() == "all"){
				   if(itms[i].MenuGroup.toLowerCase() == "all"){//This is a failsafe, i do not know if this is even a possible case.
				      continue;
				   }
				   var groupIdx = ro.utils.getMatchingIdx(itms[i].MenuGroup, ro.app.Store.Menu.Groups, 'Name');
				   if(groupIdx == -1){
					continue;
					}
                    tempNewItms = getItms(ro.app.Store.Menu.Groups[groupIdx].Items, itms[i]);

                    for(var j=0; j<tempNewItms.length; j++){
						tempObj[tempStr].push(tempNewItms[j]);
						var tmp = tempObj[tempStr];
	
	                    if(itms[i].IsRequired){
	                        rqItems.push(tempNewItms[j]);
	
	                       RA_specs.MenuGroup.push(tempNewItms[j].MenuGroup);
	                       RA_specs.MenuItem.push(tempNewItms[j].MenuItem);
	                       RA_specs.MenuSize.push(tempNewItms[j].MenuSize);
	                       RA_specs.MenuStyle.push(tempNewItms[j].MenuStyle);
	                       RA_specs.MenuSizes.push(tempNewItms[j].MenuSizes);
	                       RA_specs.MenuStyles.push(tempNewItms[j].MenuStyles);
	                    }
	                    else{
	                    	pickItems.push(tempNewItms[j]);
	
	   				        PA_specs.MenuGroup.push(tempNewItms[j].MenuGroup);
	   				        PA_specs.MenuItem.push(tempNewItms[j].MenuItem);
	   				        PA_specs.MenuSize.push(tempNewItms[j].MenuSize);
	   				        PA_specs.MenuStyle.push(tempNewItms[j].MenuStyle);
	   				        PA_specs.MenuSizes.push(tempNewItms[j].MenuSizes);
	   				        PA_specs.MenuStyles.push(tempNewItms[j].MenuStyles);
	   				    }
					}
				}
				else{
					var gIdx = ro.utils.getMatchingIdx(itms[i].MenuGroup, ro.app.Store.Menu.Groups, 'Name');
					var iIdx = ro.utils.getMatchingIdx(itms[i].MenuItem, ro.app.Store.Menu.Groups[gIdx].Items, 'Name');
	
					if(iIdx == -1){
						//throw {alertPrompt:true};
						continue;
					}
	
					itms[i].ImageSource = ro.app.Store.Menu.Groups[gIdx].Items[iIdx].ImageSource;
					itms[i].Name = ro.app.Store.Menu.Groups[gIdx].Items[iIdx].Name;
					itms[i].ReportGrp = ro.app.Store.Menu.Groups[gIdx].Items[iIdx].ReportGrp;
	
	            tempObj[tempStr].push(itms[i]);
                    
	            if(itms[i].IsRequired){
	            	rqItems.push(itms[i]);
	
	               RA_specs.MenuGroup.push(itms[i].MenuGroup);
	               RA_specs.MenuItem.push(itms[i].MenuItem);
	               RA_specs.MenuSize.push(itms[i].MenuSize);
	               RA_specs.MenuStyle.push(itms[i].MenuStyle);
	               RA_specs.MenuSizes.push(itms[i].MenuSizes);
	               RA_specs.MenuStyles.push(itms[i].MenuStyles);
	            }
	            else{
	            	pickItems.push(itms[i]);
	
	               PA_specs.MenuGroup.push(itms[i].MenuGroup);
	               PA_specs.MenuItem.push(itms[i].MenuItem);
	               PA_specs.MenuSize.push(itms[i].MenuSize);
	               PA_specs.MenuStyle.push(itms[i].MenuStyle);
                   PA_specs.MenuSizes.push(itms[i].MenuSizes);                    
	               PA_specs.MenuStyles.push(itms[i].MenuStyles);
	            }
				}
			}
			//Ti.API.info('rqItems: ' + JSON.stringify(rqItems));
            //Ti.API.info('pickItems: ' + JSON.stringify(pickItems));            
			Ti.App.Properties.setString('rq', JSON.stringify(rqItems));
			Ti.App.Properties.setString('nrq', JSON.stringify(pickItems));
		};
	
	
		var isPickAnyCpn = function(){
			return (isPickAny || isReqAny);
		};
		cpnHelper.isPickAnyCpn = isPickAnyCpn;
		var checkForSurcharge = function (cpnItem) {
			if (actualCpn && actualCpn.Items && actualCpn.Items.length > 0) {
				for (i = 0; i < actualCpn.Items.length; i++) {
					if (cpnItem.MenuGroup == actualCpn.Items[i].MenuGroup &&
						(actualCpn.Items[i].MenuItem == 'All' || cpnItem.MenuItem == actualCpn.Items[i].MenuItem) &&
						cpnItem.MenuSizes == actualCpn.Items[i].MenuSizes &&
						cpnItem.MenuStyles == actualCpn.Items[i].MenuStyles &&
						cpnItem.IsRequired == actualCpn.Items[i].IsRequired &&
						(actualCpn.Items[i].Surcharge && actualCpn.Items[i].Surcharge > 0)
					) {
						return true;
                    }						
				}
            }
			return false;
		};
		cpnHelper.getPickAnyItems = function(){
			if(!pickAny || !pickAny.length){
				pickAny = [];
			}
			var gIdx, iIdx;
			var returnItms = [];
			var tmpItm = {};
			var pickAnyTempCol = JSON.parse(Ti.App.Properties.getString('nrq'));
			//if(pickAnyTempCol && pickAnyTempCol.length){
			//	if(pickAnyTempCol.length >= pickAny.length){
					pickAny = pickAnyTempCol;
				//}
            //}
			for(var i=0; i<pickAny.length; i++){
				gIdx = ro.utils.getMatchingIdx(pickAny[i].MenuGroup, ro.app.Store.Menu.Groups, 'Name');
				iIdx = ro.utils.getMatchingIdx(pickAny[i].MenuItem, ro.app.Store.Menu.Groups[gIdx].Items, 'Name');
	 			tmpItm = JSON.parse(JSON.stringify(ro.app.Store.Menu.Groups[gIdx].Items[iIdx]));
				tmpItm.PickAnyIdx = iIdx;
				tmpItm.PickAnyGrpIdx = gIdx;
				tmpItm.PickSize = pickAny[i].MenuSize;
				tmpItm.hasSurcharge = checkForSurcharge(pickAny[i]);
				//Ti.API.info("COmparision obj: " + pickAny[i].MenuGroup + " : " + pickAny[i].MenuItem + " : " + pickAny[i].MenuSizes + " : " + pickAny[i].MenuStyles);
				//Ti.API.info("hasSurcharge : " + tmpItm.ReceiptName + " : " + tmpItm.hasSurcharge);
				returnItms.push(tmpItm);
			}
			Ti.API.info("getPickAnyItems length: " + returnItms.length);
            finalPickAny = returnItms;
			return returnItms;
		};
        cpnHelper.getRequireAnyItems = function () {            
			if(!reqAny || !reqAny.length){
				reqAny = [];
			}
			var gIdx, iIdx;
			var returnItms = [];
			var tmpItm = {};
			var reqAnyTempCol = JSON.parse(Ti.App.Properties.getString('rq'));
            //Ti.API.info("req Any Temp Col: " + JSON.stringify(reqAnyTempCol));
			//if(reqAnyTempCol && reqAnyTempCol.length){
			//	if(reqAnyTempCol.length >= reqAny.length){
					reqAny = reqAnyTempCol;
			//	}
			//}
			for(var i=0; i<reqAny.length; i++){
				gIdx = ro.utils.getMatchingIdx(reqAny[i].MenuGroup, ro.app.Store.Menu.Groups, 'Name');
				iIdx = ro.utils.getMatchingIdx(reqAny[i].MenuItem, ro.app.Store.Menu.Groups[gIdx].Items, 'Name');
	
				tmpItm = JSON.parse(JSON.stringify(ro.app.Store.Menu.Groups[gIdx].Items[iIdx]));
				tmpItm.PickAnyIdx = iIdx;
				tmpItm.PickAnyGrpIdx = gIdx;
				tmpItm.PickSize = reqAny[i].MenuSize;
				tmpItm.hasSurcharge = checkForSurcharge(reqAny[i]);
				//Ti.API.info("COmparision obj: " + reqAny[i].MenuGroup + " : " + reqAny[i].MenuItem + " : " + reqAny[i].MenuSizes + " : " + reqAny[i].MenuStyles);
				//Ti.API.info("hasSurcharge : " + tmpItm.ReceiptName + " : " + tmpItm.hasSurcharge);
				returnItms.push(tmpItm);
			}
			Ti.API.info("getRequireAnyItems length: " + returnItms.length);
			finalReqAny = returnItms;
			return returnItms;
        };      
        cpnHelper.IsSizeValid = function (grpName, itmObj) {
            if (cpnHelper.isCpn()) {
                //var CpnItemSize;
                if (selectedCpn.Items) {
                    for (var x = 0, xMax = selectedCpn.Items.length; x < xMax; x++) {
                        if (grpName == selectedCpn.Items[x].MenuGroup && (selectedCpn.Items[x].MenuItem == "All" || selectedCpn.Items[x].MenuItem == itmObj.Name)) {
                            if (!selectedCpn.Items[x].MenuSizes.includes("All")) {
                                //CpnItemSizes = selectedCpn.Items[x].MenuSize;
                                for (i = 0; i < itmObj.AvailableSizes.length; i++) {
                                    if (selectedCpn.Items[x].MenuSizes.toLowerCase().includes(itmObj.AvailableSizes[i].Name.toLowerCase())) return true;
                                }
                                return false;
                            }
                        }
                    }                  
                    
                }
            }            
            return true;           
        };       
        cpnHelper.getActualIdx = function(pickAnyIndex, isReq){
			currPickIndex = pickAnyIndex;
			currIsReq = isReq;
			var returnIdx = isReq ? finalReqAny[pickAnyIndex].PickAnyIdx : finalPickAny[pickAnyIndex].PickAnyIdx;
			return returnIdx;
		};
        cpnHelper.getPickSize = function(){            
            var returnIdx = currIsReq ? RA_specs.MenuSizes[currPickIndex] : PA_specs.MenuSizes[currPickIndex];            
			return returnIdx;
        };
        cpnHelper.getItemSize = function (grpName, itmName) {
            for (var i = 0, iMax = selectedCpn.Items.length; i < iMax; i++) {
                if (selectedCpn.Items[i].MenuGroup == grpName && selectedCpn.Items[i].IsRequired == currIsReq) {
                    if (selectedCpn.Items[i].MenuItem == "All" || selectedCpn.Items[i].MenuItem == itmName) {
                        return selectedCpn.Items[i].MenuSizes;
                    }
                }
            }
            return "All";
        };
		cpnHelper.getPickStyle = function(){
			var returnIdx = currIsReq ? RA_specs.MenuStyles[currPickIndex] : PA_specs.MenuStyles[currPickIndex];
			return returnIdx;
		};
		cpnHelper.setReqBool = function(theBool){
			isReqItemBool = theBool;
		};
		
			ro.cpnHelper = cpnHelper;

		
		/*return {
			findItem:findItem,
			checkCart:checkCart,
			validateCpn:validateCpn,
			validatePctCpn:validatePctCpn,
			addCpn:addCpn,
			addPctCpn:addPctCpn,
			addAutoCpns:addAutoCpns,
			getCpIdx:getCpIdx,
			setCpIdx:setCpIdx,
			cpnSpecs:cpnSpecs,
			chosenStyle:chosenStyle,
			chosenSize:chosenSize,
			chosenMods:chosenMods,
			chosenPrefs:chosenPrefs,
			chosenItem:chosenItem,
			setSelection:setSelection,
			clearSelection:clearSelection,
			isCpn:isCpn,
			setCpnBool:setCpnBool,
			setExistingItem:setExistingItem,
			existingItem:existingItem,
			getSelectedCpnNm:getSelectedCpnNm,
			allMods:allMods,
			getNoMods:getNoMods,
			getItemIdx:getItemIdx,
			deleteItem:deleteItem,
			getSelectedCpn:getSelectedCpn,
			isPickAnyCpn:isPickAnyCpn,
			getPickAnyItems:getPickAnyItems,
			getRequireAnyItems:getRequireAnyItems,
			getPickAnyGroup:getPickAnyGroup,
			getActualIdx:getActualIdx,
			setReqBool:setReqBool,
			getPickSize:getPickSize,
			getPickStyle:getPickStyle,
			setCurrIsReq:setCurrIsReq,
			setCurrPickIndex:setCurrPickIndex
		};*/
	};
	return {
		cpnhelper:cpnhelper
	};
}();
module.exports = cpnHelper;