var COUPONS = function(){
	var coupons = function(){
		var cpns = {};
	
		function sortCoupons(cpn1,cpn2){
			if(cpn1.MenuItem!='All' && cpn2.MenuItem=='All'){
				return -1;
			}
			else if(cpn1.MenuItem=='All' && cpn2.MenuItem!='All'){
				return 1;
			}
				return 0;
		}
		
		cpns.ValidateMultiCoupons = function(cpnItems,minPrice,activePrice,noModDisc,timeIdx,sTime,eTime){

			var blnFound=false;
			var blnApplies=false;
			var itmPrice= 0;
			var i,j,k;
			var Ord;
		
		
		
		
			cpnItems.sort(sortCoupons);
		
			if (Ti.App.ItemsSplit){
				Ord = Ti.App.SplitOrder;
			}
			else{
				Ord = Ti.App.OrderObj;
			}
			for (i=0;i<Ord.Items.length;i++){
				if (Ord.Items[i].CpnApplied ==1){
					Ord.Items[i].CpnApplied =0;
				}
			}// end for
		
			for (i=0;i<cpnItems.length;i++){
				blnFound = false;
				for (j=0;j<Ord.Items.length;j++){
					blnApplies = false;
					if (Ord.Items[j].SplitNum == Ord.CurSplit){
						if (Ord.Items[j].CpnApplied==0 && !Ord.Items[j].AdjObj && !Ord.Items[j].CpnObj){
		
							blnApplies = true;
							if (cpnItems[i].MenuGroup != "All"){
								if (cpnItems[i].MenuGroup != Ord.Items[j].GroupName){
									blnApplies = false;
								}
							}// end if
		
							if (cpnItems[i].MenuItem != "All"){
								if (cpnItems[i].MenuItem != Ord.Items[j].Name){
									blnApplies= false;
								}
							}// end if
		
							if (cpnItems[i].MenuSize != "All"){
								if (cpnItems[i].MenuSize != Ord.Items[j].Size){
									blnApplies = false;
								}
							}// end if
		
							if (cpnItems[i].MenuStyle != "All"){
								 if (cpnItems[i].MenuStyle != Ord.Items[j].Style){
								 	blnApplies = false;
								 }
							}// end if
		
							if (timeIdx > 0){
								if (Ord.Items[j].OrdItemKey != 0){
									 //Ti.include('/logic/menuUtils.js');
									 var menuUtils = require('logic/menuUtils');
									 if(!menuUtils.IsTimeValid(timeIdx, sTime, eTime, Ord.Items[j].TimeStamp)){
									 	blnApplies = false;
									 }
		
								}
							}// end if
		
						}// end if
					}// end if
		
					if (blnApplies){
						itmPrice += Ord.Items[j].ActivePrice;
						if (!noModDisc){
							if (Ord.Items[j].PrfMbrs !=null){
								for (k=0;k<Ord.Items[j].PrfMbrs.length;k++){
									itmPrice += Ord.Items[j].PrfMbrs[k].ActivePrice;
								}// end for
							}// end if
		
							if (Ord.Items[j].Mods !=null){
								for (k=0;k<Ord.Items[j].Mods.length;k++){
									itmPrice += Ord.Items[j].Mods[k].ActivePrice;
								}// end for
							}// end if
						}// end if
		
						blnFound = true;
						Ord.Items[j].CpnApplied = 1;
		
						/*if(isPick || isReq){
							if(cpnItems[i].IsRequired){
								reqCounter++;
							}
							else{
								pickCounter++;
							}
		
							if(reqCounter === cpn.RequireAnyCnt && pickCounter === cpn.PickAnyCnt){
								return blnFound;
							}
		
						}*/
		
		
						break;
					}// end if
				}// end for
		
				if (!blnFound){
					break;
				}// end if
			}// end for
		
			if (blnFound){
				if (minPrice>itmPrice){
					blnFound=false;
				}
				else if (minPrice > (itmPrice-activePrice)){
					activePrice = itmPrice-minPrice; //Byref
				}
			}// end if
			return blnFound;
		};
		return cpns;
	};
	return {
		coupons:coupons
	};
}();
module.exports = COUPONS;