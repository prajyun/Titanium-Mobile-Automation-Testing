var MultiplePmtHelper = function(){
	
	var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	var getDollarFormat = function(number){
		return (Math.round(number * 100) / 100);
	};
   var osname = Ti.Platform.osname;
   var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;
   if(isiOS){
   
   }
   else{
   
   }
   
   var totalValue = {
		text : ''
   };
   		
   var curTotalLbl;

    var refreshTotal = function () {
        var tip = tip ? parseFloat(tip) : 0.00;
        var totalTip = Ti.App.OrderObj.Tip ? parseFloat(Ti.App.OrderObj.Tip) : 0.00;
        totalValue.text = '$' + (Ti.App.OrderObj.ActiveTotal + totalTip + tip).toFixed(2);
    };

   var getCurrentBalanceDue = function(){
	   	  //var MultiplePmtHelper = require('logic/MultiplePmtHelper');
	   	  var ccTip = 0.00;
	   	  var totalTip = Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip : 0.00;
	   	  if(cfg && cfg.AllowCCTips){
               ccTip = CC_TIPS.getTip();
             }
          //Ti.API.info("CCTip: "+ccTip);
          var currentBalanceDue = Ti.App.OrderObj.ActiveTotal + totalTip;// + ccTip;
	   	  var multiPmts = GetMultiPmts();
	   	  //Ti.API.debug('multiPmts: ' + JSON.stringify(multiPmts));
	   	  for(var i=0, iMax=multiPmts.MultiPmts && multiPmts.MultiPmts.length ? multiPmts.MultiPmts.length : 0; i<iMax; i++){
	   	  	 currentBalanceDue -= (multiPmts.MultiPmts[i].PaymentAmt + (multiPmts.MultiPmts[i].Tip ? multiPmts.MultiPmts[i].Tip: 0.00));
	   	  }
	   	  
	   	  return getDollarFormat(currentBalanceDue).toFixed(2);
	  }; 
   var GetBalanceDue = function(asNumber, tip){
   	  var mp = GetMultiPmts();   	  
   	  if(!mp || !mp.DoMultiPmts || !mp.MultiPmts || !mp.MultiPmts.length) 
   	  		return parseFloat(getDollarFormat(Ti.App.OrderObj.ActiveTotal + (tip ? tip : 0)).toFixed(2));
   	  
   	  /*for(var i=0, iMax=mp.MultiPmts.length; i<iMax; i++){
   	  	 
   	  }*/
   	 var totalTip = Ti.App.OrderObj.Tip ? parseFloat(Ti.App.OrderObj.Tip) : 0;
   	 var tip = tip? tip:0;
   	 var balDue = getDollarFormat(Ti.App.OrderObj.ActiveTotal + totalTip + tip);
   	 for(var i=0, iMax=mp.MultiPmts.length; i<iMax; i++){
   	     balDue -= getDollarFormat(mp.MultiPmts[i].PaymentAmt + (mp.MultiPmts[i].Tip ? mp.MultiPmts[i].Tip: 0.00));
   	  }
   	  /*var balDue = mp.MultiPmts.reduce(function(balanceDue, mpObj){
   	  	var returnses;
   	  	if(balanceDue && balanceDue.PaymentAmt){
   	  		returnses = getDollarFormat(balanceDue.PaymentAmt) - getDollarFormat(mpObj.PaymentAmt + mpObj.Tip ? mpObj.Tip : 0.00);
   	  	}
   	  	else{
   	  		returnses = getDollarFormat(balanceDue) - getDollarFormat(mpObj.PaymentAmt + mpObj.Tip ? mpObj.Tip : 0.00);
   	  	}
   	  	
   	  	return returnses;
   	  }, getDollarFormat(Ti.App.OrderObj.ActiveTotal + totalTip /*+ tip));*/
   	  //Ti.API.info("balDue: "+balDue);
   	  return asNumber ? getDollarFormat(balDue) : getDollarFormat(balDue).toFixed(2);
   };
   var updateTotals = function(tip){
   		var mp = GetMultiPmts();
   		var isMultiPay = mp.DoMultiPmts;
        //this code is to clear the order tip if for some reasons the submit order fails and the customer switches between payments
        if(!isMultiPay && Ti.App.OrderObj.Tip && Ti.App.OrderObj.Tip > 0){
        		var test = Ti.App.OrderObj;
		  		test.Tip = 0.0;
            	Ti.App.OrderObj = test;
                test = null;
        }
   		var tip = tip && !isMultiPay? parseFloat(tip):0.00; // you add ccTip passed here only for single payment; for multi use only the OrderObj.Tip to calc total
   		var totalTip = isMultiPay && Ti.App.OrderObj.Tip ? parseFloat(Ti.App.OrderObj.Tip) : 0.00;
   		totalValue.text = '$'+ (Ti.App.OrderObj.ActiveTotal + totalTip + tip).toFixed(2);
   		//Ti.API.info("Ti.App.OrderObj.ActiveTotal: "+Ti.App.OrderObj.ActiveTotal);
   		//Ti.API.info("totalTip: "+ totalTip);
   		//Ti.API.info("tip: "+ tip);
   		
   		if(isMultiPay){
   			curTotalLbl.text = "Balance Due: $" + parseFloat(GetBalanceDue(false, tip)).toFixed(2);
		   }
   };
   var IsPaymentValid = function(){
   	  var mp = GetMultiPmts();
   	  if(!mp || !mp.DoMultiPmts || !mp.MultiPmts || !mp.MultiPmts.length) return false;
   	  
   	 /* var oldSumPmts = mp.MultiPmts.reduce(function(total, mpObj){
   	  	var returnses;
   	  	if(total && total.PaymentAmt){
   	  		returnses = getDollarFormat(total.PaymentAmt) + getDollarFormat(mpObj.PaymentAmt);
   	  	}
   	  	else{
   	  		returnses = getDollarFormat(total) + getDollarFormat(mpObj.PaymentAmt);
   	  	}
   	  	
   	  	return returnses;
   	  }, 0.00);*/
   	  
   	  var sumPmts = 0;
   	  for(var i=0, iMax=mp.MultiPmts.length; i<iMax; i++){
   	     sumPmts += getDollarFormat(mp.MultiPmts[i].PaymentAmt);// + (mp.MultiPmts[i].Tip ? mp.MultiPmts[i].Tip: 0.00));
   	  }
   	  var totalTip = parseFloat(Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip : 0);
   	  return getDollarFormat(Ti.App.OrderObj.ActiveTotal/* + totalTip*/).toFixed(2) == getDollarFormat(sumPmts).toFixed(2);
   };
   var getMultiPaymentObject = function(currObj){
   	  var multiPmtObj = {
   	  	 PaymentAmt:Ti.App.OrderObj.ActiveTotal,
   	  	 PaymentType:Ti.App.OrderObj.DisplayOrdPayment,
   	  	 CardInfo:Ti.App.OrderObj.DisplayOrdPayment,
   	  	 Tip:Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip : (Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.CCInfo && (Ti.App.OrderObj.ordOnlineOptions.CCInfo.Tip ?  Ti.App.OrderObj.ordOnlineOptions.CCInfo.Tip : 0))
   	  	 //payAmt
   	  };
   	  
   	  if(currObj){
   	  	
   	  }
   	  
   	  return multiPmtObj;
   };
   var SaveMultiPmts = function(multiPmts){
	  	/*if(allowMultiPmts){
	  		Ti.App.Properties.setString("MultiPmts", JSON.stringify(multiPmts));
	  	}
	  	else{
	  		var defaultMultiPmts = {DoMultiPmts:false, MultiPmts:[]};
	  		Ti.App.Properties.setString("MultiPmts", JSON.stringify(defaultMultiPmts));
	  	}*/
	  	if(multiPmts && multiPmts.DoMultiPmts){
	  		Ti.App.Properties.setString("MultiPmts", JSON.stringify(multiPmts));
	  	}
	  	else{
	  		var defaultMultiPmts = {DoMultiPmts:false, MultiPmts:[]};
	  		Ti.App.Properties.setString("MultiPmts", JSON.stringify(defaultMultiPmts));
	  	}
	 },
   GetMultiPmts = function(){
   	  //var multiPmts = {DoMultiPmts:false, MultiPmts:[]};
   	    /*var defaultMultiPmts = {DoMultiPmts:false, MultiPmts:[]};
   	    defaultMultiPmts.MultiPmts.push({
   	    	PaymentAmt:5.00
   	    });
   	    defaultMultiPmts.MultiPmts.push({
   	    	PaymentAmt:7.71
   	    });
   	    defaultMultiPmts.MultiPmts.push({
   	    	PaymentAmt:7.99
   	    });
	 	return defaultMultiPmts;*/
	  return JSON.parse(Ti.App.Properties.getString('MultiPmts'));
   },
   GetCCInfoCol = function(){
   	var mp = JSON.parse(Ti.App.Properties.getString('MultiPmts')).MultiPmts;
   	 /*return JSON.parse(Ti.App.Properties.getString('MultiPmts')).MultiPmts.reduce(function(pmt){
   	 	Ti.API.debug('pmt: ' + JSON.stringify(pmt));
   	 	return pmt.IsCredOrGift;
   	 });*/
   	var returnPmts = [];
   	  for(var i=0, iMax=mp && mp.length ? mp.length : 0; i<iMax; i++){
   	  	if(mp[i].IsCredOrGift)
   	  		returnPmts.push(mp[i]);
   	  }
   	  return returnPmts;
   },
   GetView = function(useOrderObjPmt, _deleteCb){
   		var mp = GetMultiPmts();
   	    //if(!mp || !mp.DoMultiPmts || !mp.MultiPmts || !mp.MultiPmts.length) return false;
	   	
	   	var MultiPmtView = Ti.UI.createView(/*ro.combine(ro.ui.properties.hdrViewMargins, */{
	        layout:'vertical',
	        height:Ti.UI.SIZE,
	        //top:ro.ui.relY(15),
	        //left:ro.ui.relX(30),	//remove left and right
	        //right:ro.ui.relX(30),
	        //backgroundColor:'#eeece6',
	        visible:false
	     });//);
	     
	     var MultiPmtLblsView = Ti.UI.createView({
	     	top:ro.ui.relY(10),
	     	height:Ti.UI.SIZE,
	     	width:Ti.UI.FILL,
	     	layout:'vertical'
	     });
	     var Reprint = function(){
	     	var mPmts = GetMultiPmts();
	     	if(mPmts){
	     		mPmts = mPmts.MultiPmts;
	     	}
	     	else{
	     		mPmts = [];
	     	}
	     	
	     	if(useOrderObjPmt){//Bad Verbage - this is currently a function to return the payment in the correct format when NOT using multiple payments
	     		mPmts = [];
	     		mPmts.push(getMultiPaymentObject());
	     	}
	     	
	     	var deleteItem = function(e){
	     		var payControl = require('controls/paymentControl');
	     		//Ti.API.info('e: ' + JSON.stringify(e));
		   	  if(e.source.clearPayBln){
		   	  	useOrderObjPmt = false;
		   	  	payControl.clearPaymentInfo();
		   	  	//ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
		   	  }
		   	  else{
		   	  	 var multiPmts = GetMultiPmts();
		   	  	 var pmt = multiPmts.MultiPmts[e.source.multiPmtIdx];
		   	  	 var temp = Ti.App.OrderObj;
			   	 temp.Tip = temp.Tip ? parseFloat((temp.Tip - pmt.Tip).toFixed(2)) : 0.00;
			   	 Ti.App.OrderObj = temp;
			   	 
			   	 multiPmts.MultiPmts.splice(e.source.multiPmtIdx, 1);
			   	 if(!multiPmts.MultiPmts || !multiPmts.MultiPmts.length){
			   	 	multiPmts.MultiPmts = [];
			   	 	payControl.clearPaymentInfo();
			   	 	//ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
			   	 	//multiPmts.DoMultiPmts = false;
			   	 }
			   	 //Ti.API.debug('multiPmtsRIGHTBEFORE I SAVE AFTER REMOVING ONE: ' + JSON.stringify(multiPmts));
			   	 SaveMultiPmts(multiPmts);
		   	  }
		   	  Reprint();
		   	  if(_deleteCb){
		   	  	_deleteCb();
		   	  }
		   };
	     	MultiPmtLblsView.removeAllChildren();
	     	var totalTips = 0;
	     	for(var i=0, iMax=mPmts.length; i<iMax; i++){
	     		var btnDelete = Ti.UI.createButton({
			         right:ro.ui.relX(8),
			         backgroundImage:'/images/clearBtn.png',//ro.ui.properties.defaultPath + 'delete.png',
			         height:ro.ui.relX(19),
			         width:ro.ui.relX(19),
			         //type:'item',
			         //itmIndex:count,
        		     bubbleParent:false,
        		     multiPmtIdx:i,
        		     clearPayBln:useOrderObjPmt//only true so that the old way of taking payment gets cleared when neccesary
			      });
			      btnDelete.addEventListener('click', deleteItem);
	     		
	     		var MultiPmtRow = Ti.UI.createView({
	     			//layout:'horizontal',
	     			height: Ti.UI.SIZE,
	     			width:Ti.UI.FILL,
	     			top: ro.ui.relY(8),
	     			bottom: ro.ui.relY(8),
	     			left: ro.ui.relX(13),
	     			right: ro.ui.relX(13),
	     			
	     			borderWidth: ro.ui.relX(2),
	     			borderColor: '#e4e4e4',
	     			borderRadius: ro.ui.relX(8)
	     		});
	     		var paymentType = mPmts[i] && mPmts[i].CardInfo && mPmts[i].CardInfo.length ? mPmts[i].CardInfo.toUpperCase() : "Need to add payment type";
	     		
	     		
	     			var pmtDisp ;
	     			if(mPmts[i] && mPmts[i].CardInfo && mPmts[i].CardInfo.length && mPmts[i].CardInfo != "CASH"){
	     				var cardNumber = mPmts[i].OLCardNum;
	     				pmtDisp = paymentType + " - *** "+ cardNumber.substring(cardNumber.length - 4, cardNumber.length);   
	     			}else{
	     				pmtDisp = "CASH";
	     			}     		
	     		
	     			var priceTxt = "$" + getDollarFormat(mPmts[i].PaymentAmt + (mPmts[i].Tip ? mPmts[i].Tip : 0.00)).toFixed(2);
	     			
	     		
	     		
	     		
	     		var paymentDisplay = paymentType + "- *** "+ +"   -   $" + getDollarFormat(mPmts[i].PaymentAmt).toFixed(2) + " " + (mPmts[i].Tip && mPmts[i].Tip > 0  ? ("   -   Tip: $" + getDollarFormat(mPmts[i].Tip).toFixed(2)) : "");

	     		MultiPmtRow.add(Ti.UI.createLabel({
	     			width:Ti.UI.SIZE,
	     			height: Ti.UI.SIZE,
	     			left: ro.ui.relX(12),
	     			//borderWidth: ro.ui.relY(10),
	     			top: ro.ui.relY(15),
	     			bottom: ro.ui.relY(13),
	     			
	     			//height:ro.ui.relX(20),
	     			text: pmtDisp,
	     			color:'#393839',
	     			textAlign:'left',
	     			font:{
	     				fontFamily:ro.ui.fonts.textFields,
	     				fontSize:ro.ui.scaleFont(18)
	     			}
	     		}));
	     		MultiPmtRow.add(Ti.UI.createLabel({
	     			width:Ti.UI.SIZE,
	     			height: Ti.UI.SIZE,
	     			right: ro.ui.relX(30),
	     			top: ro.ui.relY(15),
	     			bottom: ro.ui.relY(13),
	     			
	     			//height:ro.ui.relX(20),
	     			//borderWidth: ro.ui.relY(10),
	     			text: priceTxt,
	     			color:'#393839',
	     			textAlign:'left',
	     			font:{
	     				fontFamily:ro.ui.fonts.textFields,
	     				fontSize:ro.ui.scaleFont(15)
	     			}
	     		}));
	     		MultiPmtRow.add(btnDelete);
	     		MultiPmtLblsView.add(MultiPmtRow);
	     	}
	     	curTotalLbl.text = "Balance Due: $" + GetBalanceDue();
	     	totalValue.text = '$'+ (Ti.App.OrderObj.ActiveTotal + (Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip: 0.00)).toFixed(2);
	     	/*if(totalTips){
	     		TipLbl.text = "Tips: $" + getDollarFormat(totalTips).toFixed(2);
	     		TipLbl.height = ro.ui.relY(30);
	     		TipLbl.visible = true;
	     		
	     		
	     		OverallTotalLbl.text = "Total: $" + (GetBalanceDue(true) + getDollarFormat(totalTips));
	     		OverallTotalLbl.height = ro.ui.relY(30);
	     		OverallTotalLbl.visible = true;
	     	}
	     	else{
	     		
	     		TipLbl.visible = false;
	     		TipLbl.height = 0;
	     		TipLbl.text = "";
	     		OverallTotalLbl.visible = false;
	     		OverallTotalLbl.height = 0;
	     		OverallTotalLbl.text = "";
	     	}*/
	     };
	     
	     MultiPmtView.Reprint = Reprint;
	     var MultiPmtsTotalView = Ti.UI.createView({
	     	height:Ti.UI.SIZE,
	     	width:Ti.UI.FILL,
	     	layout:'vertical'
	     });
	     var balDue = GetBalanceDue();
	     curTotalLbl = Ti.UI.createLabel({
	     	height:mp && mp.DoMultiPmts ? ro.ui.relY(30) : 0,
	     	text:"Balance Due: " + balDue,
	     	top: ro.ui.relY(5),
	     	bottom: ro.ui.relY(8),
	     	//text:'20.00',
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#eb0029',
	     	font:{
	     		fontFamily:ro.ui.fontFamily,
	     		fontWeight:'bold',
	     		fontSize:ro.ui.scaleFont(18)
	     	},
	     	visible:mp && mp.DoMultiPmts
	     });
	     var totalLbl = Ti.UI.createLabel({
	     	height:ro.ui.relY(30),
	     	text:"Order Total: " + Ti.App.OrderObj.ActiveTotal.toFixed(2),
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#393839',
	     	font:{
	     		fontFamily:ro.ui.fontFamily,
	     		fontWeight:'bold',
	     		fontSize:ro.ui.scaleFont(14)
	     	},
	     	top: ro.ui.relY(5)
	     });
	     totalOnlyLbl = Ti.UI.createLabel({
                    text: 'Total ',
                    //top: top,
                    height:ro.ui.relY(35),
                    color: ro.ui.theme.backgroundpngTxt,
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(25 * 1.25) 
                    },
                    width: Ti.UI.SIZE
                });
                
         totalValue = Ti.UI.createLabel({
                    text: '$'+Ti.App.OrderObj.ActiveTotal.toFixed(2),
                    color: ro.ui.theme.minorColor,
                    height:ro.ui.relY(35),
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(25 * 1.25) 
                    },
                    width: Ti.UI.SIZE
                });
         var totalHolder = Ti.UI.createView({
         	layout: 'horizontal',
         	height: ro.ui.relY(45),
         	width: Ti.UI.SIZE
         });
         totalHolder.add(totalOnlyLbl);
         totalHolder.add(totalValue);
	     MultiPmtsTotalView.add(curTotalLbl);
	     //MultiPmtsTotalView.add(totalLbl);
	     MultiPmtsTotalView.add(totalHolder);
	     var TipLbl = Ti.UI.createLabel({
	     	height:0,
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#393839',
	     	visible:false,
	     	font:{
	     		fontFamily:ro.ui.fontFamily,
	     		fontWeight:'bold',
	     		fontSize:ro.ui.scaleFont(14)
	     	}
	     });
	     //MultiPmtsTotalView.add(TipLbl);
	     var OverallTotalLbl = Ti.UI.createLabel({
	     	height:0,
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#393839',
	     	visible:false,
	     	font:{
	     		fontFamily:ro.ui.fontFamily,
	     		fontWeight:'bold',
	     		fontSize:ro.ui.scaleFont(14)
	     	}
	     });
	     //MultiPmtsTotalView.add(OverallTotalLbl);
	     
	     
		 MultiPmtView.add(MultiPmtLblsView);
		 MultiPmtView.add(MultiPmtsTotalView);
		 //if(!isiOS){
		 	MultiPmtView.Reprint();
		 //}
		 
		 MultiPmtView.ToggleLabelVis = function(newVis){
		 	curTotalLbl.visible = newVis;
		 	curTotalLbl.height = newVis ? ro.ui.relY(30) : 0;		 	
		 };
		 //MultiPmtView.borderColor = 'green';
		 //MultiPmtView.borderWidth = 2;
		 return MultiPmtView;
   };
   
   return {
      SaveMultiPmts: SaveMultiPmts,
      GetMultiPmts: GetMultiPmts,
      GetView: GetView, 
      IsPaymentValid: IsPaymentValid,
      GetCCInfoCol: GetCCInfoCol,
      getDollarFormat : getDollarFormat,
      getCurrentBalanceDue: getCurrentBalanceDue,
      updateTotals: updateTotals,
      refreshTotal: refreshTotal
   };
}();
module.exports = MultiplePmtHelper;