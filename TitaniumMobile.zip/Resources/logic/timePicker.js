exports.formDateTime = function(futureTimePicker, populatePicker) {
	var boundaries;
	var storeObj = ro.app.Store;
	var hrArray = [];
	var minArray = [];
	var dayArray = [];
	var isDelivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
	var deferTime;
	var interval = storeObj.Configuration.DeferInt < 59 ? storeObj.Configuration.DeferInt : 5;

	for (var i = 0; i < storeObj.Menu.OnlineOptions.OrdTypes.length; i++) {
		if (isDelivery === storeObj.Menu.OnlineOptions.OrdTypes[i].IsDelivery) {
			deferTime = storeObj.Menu.OnlineOptions.OrdTypes[i].DeferPrepMin;
			break;
		}
	}

	function getTm(d) {
		var hour,
		    min;
		if (d.getUTCHours() < 10) {
			hour = '0' + d.getUTCHours();
		} else
			hour = d.getUTCHours();

		if (d.getUTCMinutes() < 10) {
			min = '0' + d.getUTCMinutes();
		} else
			min = d.getUTCMinutes();

		return hour + ':' + min;
	}

	//var mmt = require('classes/momentjs');
	function createDateObj(d, today) {
		//Ti.API.debug('createDateObj');
		var obj = {},
		    closeHr,
		    closeMin,
		    openHr,
		    openMin,
		    openTime;
		var curDate = new Date();
		var Week = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
		var Month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
		
		for (var i = 0; i < storeObj.Hours.length; i++) {
			if (storeObj.Hours[i].IsDelivery === isDelivery && storeObj.Hours[i].DayOfWeek === Week[d.getUTCDay()]) {
				if (today && getTm(d) < storeObj.Hours[i].Open){
					today = false;
				}
					
				if (storeObj.Hours[i].Closed){
					//Ti.API.debug('returning null');
					return null;
				}
				//Ti.API.debug('didnt return null');
				if (isHoliday(d, storeObj.Holidays)) {
					//Ti.API.debug('TIMEPICKER.ISHOLIDAY IS TRUE');
					if (isClosedAllDay(d)) {
						return null;
					}
					if (isClosedAlready(d)) {
						return null;
					}
				}
				closeHr = storeObj.Hours[i].Open > storeObj.Hours[i].Close ? addDay(storeObj.Hours[i].Close).split(':')[0] : storeObj.Hours[i].Close.split(':')[0];
				closeMin = storeObj.Hours[i].Close.split(':')[1];
				openTime = actualOpen((today && getTm(d) > storeObj.Hours[i].Open) ? getTm(d) : storeObj.Hours[i].Open);

				openHr = openTime.split(':')[0];
				openMin = openTime.split(':')[1];
				if (closeHr + ':' + closeMin <= openHr + ':' + openMin){
					return null;
				}
					
				obj.disp = Month[d.getUTCMonth()] + ' ' + d.getUTCDate();
				d.setSeconds(0);
				obj.date = d;

				break;
			}
		}

		for (var i = 0; i < hrArray.length; i++) {
			if (hrArray[i].val >= openHr) {
				obj.minHrIndex = i;
				break;
			}
		}

		for (var i = hrArray.length - 1; i >= 0; i--) {
			if (hrArray[i].val <= closeHr) {
				obj.maxHrIndex = i;
				break;
			}
		}

		for (var i = 0; i < minArray.length; i++) {
			if (minArray[i] >= openMin) {
				obj.minMinIndex = i;
				break;
			}
		}

		for (var i = minArray.length - 1; i >= 0; i--) {
			if (minArray[i] <= closeMin) {
				obj.maxMinIndex = i;
				break;
			}
		}
		return obj;
	}

	function addDay(a) {
		var aArray = a.split(':');

		var hr = parseInt(aArray[0], 10) + 24;
		hr = hr.toString();
		return hr + ':' + aArray[1];

	}

	function actualOpen(a) {
		var aArray = a.split(':');
		var hours = parseInt(deferTime / 60, 10);
		var min = deferTime % 60;

		var hr = parseInt(aArray[0], 10) + hours;
		var mn = parseInt(aArray[1], 10) + min;

		// Rounding off to nearest valid time according to DeferInterval
		if (mn % interval) {
			mn = mn + interval - (mn % interval);
		}

		if (mn >= 60) {
			mn -= 60;
			hr++;
		}

		hr = hr < 10 ? '0' + hr : hr;
		mn = mn < 10 ? '0' + mn : mn;

		return hr.toString() + ':' + mn.toString();
	}

	function displayTime(dateIndex, hrIndex, minIndex) {
			
		var hr = hrArray[hrIndex].disp.split(' ')[0];
		var min = minArray[minIndex].toString() + ' ' + hrArray[hrIndex].disp.split(' ')[1];
		return dayArray[dateIndex].disp + ', ' + hr + ':' + min;
	}

	function isHoliday(selectedDate, holidays) {
		try{
			var mmt = require('classes/momentjs');
			//Ti.API.info('selectedDate: ' + JSON.stringify(selectedDate));
			//Ti.API.info('holidays: ' + JSON.stringify(holidays));
			if (!holidays || !holidays.length) {
				return false;
			}
	
			var currSelDate = mmt(selectedDate).format('MM-DD-YYYY');
			//Ti.API.info('currSelDate:' + currSelDate);
			for (var i = 0, iMax = holidays.length; i < iMax; i++) {
				var currHoliday = mmt(holidays[i].Date).format('MM-DD-YYYY');
				if (currHoliday === currSelDate) {
					//Ti.API.debug('returning true for isHoliday');
					return true;
				}
			}
			return false;
		}
		catch(ex){
			Ti.API.info('failed in isHoliday: ' + ex);
			return false;
		}
	}

	var getBoundaries = function(holiday) {
		var minMin = getTime(holiday.Open_Time, false, true);
		var maxMin = getTime(holiday.Close_Time, false, true);
		var minHr = getTime(holiday.Open_Time);
		var maxHr = getTime(holiday.Close_Time);
		var minTime = getTime(holiday.Open_Time, true);
		minHr = getMinHrAfterDefer(minTime);
		minMin = getMinMinAfterDefer(minTime);
		var returnObj = {
			minHrIndex : (minHr),
			minMinIndex : (minMin / 5),
			maxHrIndex : (maxHr),
			maxMinIndex : (maxMin / 5)
		};

		return returnObj;
	};
	var getTimeWithDefer = function(timeStr, fullStringBln, minutesBln) {

	};
	function getTime(timeStr, fullStringBln, minutesBln) {
		timeStr = timeStr + '';

		var newHour,
		    newMinute;
		var hrLength = 2;
		var prependBln = false;
		if (timeStr.length === 5) {
			prependBln = true;
			hrLength = 1;
		}

		newHour = prependBln ? '0' + timeStr.slice(0, hrLength) : timeStr.slice(0, hrLength);
		newMinute = timeStr.slice(hrLength, hrLength + 2);
		var returnTimeStr = (newHour + ':' + newMinute);
		return fullStringBln ? returnTimeStr : minutesBln ? parseInt(newMinute, 10) : parseInt(newHour, 10);
	}

	var getHolidayBoundaries = function(selectedDate, holidays) {
		var holidayBoundaries = [];
		if (!holidays || !holidays.length) {
			return false;
		}
		var mmt = require('classes/momentjs');
		var currSelDate = mmt(selectedDate).format('MM-DD-YYYY');

		for (var i = 0,
		    iMax = holidays.length; i < iMax; i++) {
			var boundaryCol = {};
			var currHoliday = mmt(holidays[i].Date).format('MM-DD-YYYY');
			if (currHoliday === currSelDate) {
				boundaryCol = getBoundaries(holidays[i]);
				holidayBoundaries.push(getBoundaries(holidays[i]));
			}
		}
		return holidayBoundaries;
	};
	var checkIfNextValidTime = function(bndry, storeTime) {
		var mmt = require('classes/momentjs');
		var strTm = mmt(storeTime).utc().format('HH:mm');
		strTm = mmt(strTm, 'HH:mm');
		var bdryTm = mmt((bndry.minHrIndex + ':' + bndry.minMinIndex * 5), 'HH:mm').format('HH:mm');
		bdryTm = mmt(bdryTm, 'HH:mm');
		if (strTm.isBefore(bdryTm)) {
			return true;
		} else {
			return false;
		}
	};
	var getEarliestBoundaryHr = function(theBoundaries) {
		var earliestBoundaryIndex = 0;
		for (var i = 0,
		    iMax = theBoundaries.length; i < iMax; i++) {
			var bdry = theBoundaries[i];
			if (bdry.minHrIndex < theBoundaries[earliestBoundaryIndex].minHrIndex) {
				earliestBoundaryIndex = i;
			}
		}
		return earliestBoundaryIndex;
	};

	var getLatestBoundaryHr = function(theBoundaries) {
		var latestBoundaryIndex = 0;
		for (var i = 0,
		    iMax = theBoundaries.length; i < iMax; i++) {
			var bdry = theBoundaries[i];
			if (bdry.maxHrIndex > theBoundaries[latestBoundaryIndex].maxHrIndex) {
				latestBoundaryIndex = i;
			}
		}
		return latestBoundaryIndex;
	};
	var getMinHrAfterDefer = function(time) {
		var mmt = require('classes/momentjs');
		var defTm;
		var storeObj = ro.app.Store;
		for (var i = 0; i < storeObj.Menu.OnlineOptions.OrdTypes.length; i++) {
			if (isDelivery === storeObj.Menu.OnlineOptions.OrdTypes[i].IsDelivery) {
				defTm = storeObj.Menu.OnlineOptions.OrdTypes[i].DeferPrepMin;
				break;
			}
		}
		var timeMoment = mmt(time, 'HH:mm');
		var newTime = mmt(timeMoment).add(parseInt(defTm, 10), 'minutes');
		return newTime.format('HH');
	};
	var getMinMinAfterDefer = function(time) {
		var mmt = require('classes/momentjs');
		var defTm;
		var storeObj = ro.app.Store;
		for (var i = 0; i < storeObj.Menu.OnlineOptions.OrdTypes.length; i++) {
			if (isDelivery === storeObj.Menu.OnlineOptions.OrdTypes[i].IsDelivery) {
				defTm = storeObj.Menu.OnlineOptions.OrdTypes[i].DeferPrepMin;
				break;
			}
		}
		var timeMoment = mmt(time, 'HH:mm');
		var newTime = mmt(timeMoment).add(parseInt(defTm, 10), 'minutes');
		return newTime.format('mm');
	};

	function isClosedAllDay(currDay) {
		var mmt = require('classes/momentjs');
		var storeObj = ro.app.Store;
		var holidayCol = storeObj.Holidays;
		var currDate = mmt(currDay).format('MM-DD-YYYY');
		for (var i = 0,
		    iMax = holidayCol.length; i < iMax; i++) {
			var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
			if (currDate == currHoliday) {

				if (holidayCol[i].Closed_All_Day) {
					return true;
				}
			}
		}
		return false;
	}

	function isClosedAlready(currDay) {
		//Ti.API.debug('currDay: ' + currDay);
		var mmt = require('classes/momentjs');
		var storeObj = ro.app.Store;
		var holidayCol = storeObj.Holidays;
		var currDate = mmt(currDay).format('MM-DD-YYYY');
		var totalTodayHolidays = 0,
		    isAfterCtr = 0;
		for (var i = 0,
		    iMax = holidayCol.length; i < iMax; i++) {
			//Ti.API.debug('holidayCol[i].Date: ' + holidayCol[i].Date);
			var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
			if (currDate == currHoliday) {
				totalTodayHolidays++;
				var currTm = mmt(currDay).utc().format('HH:mm');
				//Ti.API.debug('currTm: ' + currTm);
				currTm = mmt(currTm, 'HH:mm');
				//Ti.API.debug('currTm: ' + currTm);
				//var maxMin = getTime(holiday.Close_Time, true);
				//var maxHr = getTime(holiday.Close_Time, true);
				var maxTime = getTime(holidayCol[i].Close_Time, true);
				//Ti.API.debug('maxTime: ' + maxTime);
				maxTime = getMaxTimeAfterDefer(maxTime);
				//Ti.API.debug('maxTime: ' + maxTime);
				//Ti.API.debug('minMin-beforeDefer: ' + minMin);
				//Ti.API.debug('minHr-beforeDefer: ' + minHr);
				//var minTime = getTime(holiday.Open_Time, true);
				//minHr = getMinHrAfterDefer(minTime);
				//minMin = getMinMinAfterDefer(minTime);
				if (currTm.isAfter(maxTime)) {
					isAfterCtr++;
				}
			}
		}
		if (isAfterCtr === totalTodayHolidays) {
			//Ti.API.debug('isAfterCtr === totalTodayHolidays');
			return true;
		}
		return false;
	}

	function getMaxTimeAfterDefer(time) {
		var mmt = require('classes/momentjs');
		var defTm;
		var storeObj = ro.app.Store;
		for (var i = 0; i < storeObj.Menu.OnlineOptions.OrdTypes.length; i++) {
			if (isDelivery === storeObj.Menu.OnlineOptions.OrdTypes[i].IsDelivery) {
				defTm = storeObj.Menu.OnlineOptions.OrdTypes[i].DeferPrepMin;
				break;
			}
		}
		//Ti.API.debug('defTm-getMinHrAfterDefer: ' + defTm);
		var timeMoment = mmt(time, 'HH:mm');
		//Ti.API.debug('timeMoment: ' + timeMoment);
		var newTime = mmt(timeMoment).add(parseInt(defTm, 10), 'minutes');
		//Ti.API.debug('newTime: ' + newTime.format('mm'));
		return newTime;
	}

	//Setting Minutes Array

	for (var i = 0; i < 60; i += interval) {
		var min = i < 10 ? '0' + i : i;
		minArray.push(min);
	}

	// Setting Hours Array
	var Open = "24:00";
	var Close = "00:00";

	for (var i = 0; i < storeObj.Hours.length; i++) {

		if (storeObj.Hours[i].IsDelivery === isDelivery && !storeObj.Hours[i].Closed) {

			var storeClose = storeObj.Hours[i].Close < storeObj.Hours[i].Open ? addDay(storeObj.Hours[i].Close) : storeObj.Hours[i].Close;

			if (storeObj.Hours[i].Open < Open) {

				Open = storeObj.Hours[i].Open;
			}
			if (storeClose > Close) {

				Close = storeClose;
			}
		}

	}

	Open = actualOpen(Open);
	var openHour = Open.split(':');
	openHour = parseInt(openHour[0], 10);
	var closeHour = Close.split(':');
	closeHour = parseInt(closeHour[0], 10);

	openHour = 0;
	//closeHour =
	for (var i = openHour; i <= closeHour; i++) {
		var hr = {};
		hr.val = i;
		if (i > 24) {
			hr.disp = i - 24 + ' am';
		} else if (i === 24) {
			hr.disp = '12 am';
		} else if (i > 12 && i < 24) {
			hr.disp = i - 12 + ' pm';
		} else if (i === 12) {
			hr.disp = '12 pm';
		} else if (i === 0) {
			hr.disp = '12 am';
		} else {
			hr.disp = i + ' am';
		}
		hrArray.push(hr);
	}

	//Setting Day Array
	var count = 0;
	var maxCount = 7;
	var Time;
	if(Ti.App.TimeAtDefStore == null){
		Time = new Date();
	}
	else{
		Time = new Date(Ti.App.TimeAtDefStore);
	}
	
	//Ti.API.debug('Time: ' + JSON.stringify(Time));
	//Ti.API.debug('Ti.App.TimeAtDefStore: ' + JSON.stringify(Ti.App.TimeAtDefStore));
	var TimeAtDefaultStore = (Time.getFullYear()) ? Ti.App.TimeAtDefStore : new Date();

	if (!Time.getFullYear()) {
		TimeAtDefaultStore.setMinutes(TimeAtDefaultStore.getMinutes() - TimeAtDefaultStore.getTimezoneOffset());
	}
	//storeObj.ISDEFAULTSTORE
	//Ti.API.debug('ISDEFAULTSTORE: ' + storeObj.ISDEFAULTSTORE);
	var curDay = new Date(!ro.REV_GUEST_ORDER.getIsGuestOrder() && storeObj.ISDEFAULTSTORE ? TimeAtDefaultStore : storeObj.TimeAtStore);

	if (storeObj.Configuration.AllowSameDayDefer) {

		var dateObj = createDateObj(curDay, true);

		if (dateObj) {
			dayArray.push(dateObj);
			maxCount = 6;
		}
	}
	if (storeObj.Configuration.AllowFutureOrders) {
		var i = 1;
		var j = 1;
		while (j <= maxCount) {
			var date = new Date(curDay);
			date.setUTCDate(curDay.getUTCDate() + i);
			var dateObj = createDateObj(date, false);
			if (dateObj) {
				dayArray.push(dateObj);
				j++;
			}
			i++;
		}
	}
	
	//Ti.API.debug('about to add Event ');
	futureTimePicker.addEventListener('change', function(e) {
		//return;
		//Ti.API.info('futureTimePicker.getSelectedRow(0): ' + JSON.stringify(futureTimePicker.getSelectedRow(0)));
		//Ti.API.info('storeObj: ' + JSON.stringify(storeObj));
		//Ti.API.info('e.columnIndex:' + e.columnIndex);
		
		//var a = futureTimePicker.getSelectedRow(0);
		//Ti.API.info('a: ' + JSON.stringify(a));
		
		
		try{
			var selectedRow = e.source.getSelectedRow(0);
			if(!selectedRow){
				selectedRow = {};
				//Ti.API.info('there is no selectedRow');
			}
			var selectedRow2 = e.source.getSelectedRow(1);
			if(!selectedRow2){
				selectedRow2 = {};
				//Ti.API.info('there is no selectedRow2');
			}
			
		}
		catch(ex){
			Ti.API.info('ex: ' + ex);
			return;
		}
		
		/*var selectedRow3 = e.source.getSelectedRow(2);
		if(!selectedRow3){
			selectedRow3 = {};
			Ti.API.info('there is no selectedRow3');
		}*/
		
		//Ti.API.info('b: ' + JSON.stringify(b));
		
		
		if (isHoliday(selectedRow.obj.date, storeObj.Holidays)) {
			if (e.columnIndex === 0) {
				boundaries = getHolidayBoundaries(selectedRow.obj.date, storeObj.Holidays);
				var outOfBoundsCounter = 0;
				for (var i = 0, iMax = boundaries.length; i < iMax; i++) {

					if (selectedRow2.id === boundaries[i].minHrIndex) {
						futureTimePicker.setSelectedRow(2, boundaries[i].minMinIndex, true);
						break;
					} else if (selectedRow2.id === boundaries[i].maxHrIndex) {
						futureTimePicker.setSelectedRow(2, boundaries[i].maxMinIndex, true);
						break;
					} else if (selectedRow2.id < boundaries[i].minHrIndex || selectedRow2.id > boundaries[i].maxHrIndex) {
						outOfBoundsCounter++;
					}
				}
				if (outOfBoundsCounter === boundaries.length) {
					for (var i = 0,
					    iMax = boundaries.length; i < iMax; i++) {
						if (checkIfNextValidTime(boundaries[i], storeObj.TimeAtStore)) {
							futureTimePicker.setSelectedRow(1, boundaries[i].minHrIndex, true);
							futureTimePicker.setSelectedRow(2, boundaries[i].minMinIndex, true);
							break;
						}
					}
				}
			}
			if (e.columnIndex === 1) {
				var lessThanMinHrBln = 0;
				var greaterThanMaxHrBln = 0;
				for (var i = 0,
				    iMax = boundaries.length; i < iMax; i++) {
					if (e.rowIndex === boundaries[i].minHrIndex) {
						futureTimePicker.setSelectedRow(2, boundaries[i].minMinIndex, true);
						break;
					} else if (e.rowIndex === boundaries[i].maxHrIndex) {
						futureTimePicker.setSelectedRow(2, boundaries[i].maxMinIndex, true);
						break;
					} else if (e.rowIndex < boundaries[i].minHrIndex) {
						lessThanMinHrBln++;
					} else if (e.rowIndex > boundaries[i].maxHrIndex) {
						greaterThanMaxHrBln++;
					}
				}
				if (lessThanMinHrBln == boundaries.length) {
					var earliestBoundaryIndex = getEarliestBoundaryHr(boundaries);
					futureTimePicker.setSelectedRow(1, boundaries[0].minHrIndex, true);
				} else if (greaterThanMaxHrBln == boundaries.length) {
					var latestBoundaryIndex = getLatestBoundaryHr(boundaries);
					futureTimePicker.setSelectedRow(1, boundaries[boundaries.length - 1].maxHrIndex, true);
				} else if ((greaterThanMaxHrBln + lessThanMinHrBln) == boundaries.length) {
					for (var i = 0,
					    iMax = boundaries.length; i < iMax; i++) {
						if (checkIfNextValidTime(boundaries[i], storeObj.TimeAtStore)) {
							//Ti.API.debug('This is the next valid time-hourchange: ' + JSON.stringify(boundaries[i]));
							futureTimePicker.setSelectedRow(1, boundaries[i].minHrIndex, true);
							break;
						}
					}
				}
			}
			if (e.columnIndex === 2) {
				for (var i = 0,
				    iMax = boundaries.length; i < iMax; i++) {
					if (boundaries[i].minHrIndex === selectedRow2.id) {
						if (e.rowIndex < boundaries[i].minMinIndex) {
							futureTimePicker.setSelectedRow(2, boundaries[i].minMinIndex, true);
						}
						break;
					}
					if (boundaries[i].maxHrIndex === selectedRow2.id) {
						if (e.rowIndex > boundaries[i].maxMinIndex) {
							futureTimePicker.setSelectedRow(2, boundaries[i].maxMinIndex, true);
						}
						break;
					}
				}
			}
		} 
		else {
			if (e.columnIndex === 0) {
				//Ti.API.info('e.rowIndex: ' + e.rowIndex);
				//Ti.API.info('dayArray[e.rowIndex]: ' + JSON.stringify(dayArray[e.rowIndex]));
				boundaries = dayArray[e.rowIndex];
				if (selectedRow2.id < boundaries.minHrIndex || selectedRow2.id > boundaries.maxHrIndex) {

					futureTimePicker.setSelectedRow(1, boundaries.minHrIndex, true);
					futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
				} else if (selectedRow2.id === boundaries.minHrIndex) {
					futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
				} else if (selectedRow2.id === boundaries.maxHrIndex) {
					futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
				}
			}
			if (e.columnIndex === 1) {
				//Ti.API.debug('futureTimePicker.getSelectedRow(0).rowIndex: ' + futureTimePicker.getSelectedRow(0).rowIndex);
				//Ti.API.debug('futureTimePicker.getSelectedRow(0): ' + JSON.stringify(futureTimePicker.getSelectedRow(0)));
				boundaries = dayArray[selectedRow.id];
				//Ti.API.debug('boundaries: ' + JSON.stringify(boundaries));
				
				if (e.rowIndex < boundaries.minHrIndex) {
					futureTimePicker.setSelectedRow(1, boundaries.minHrIndex, true);
				}
				if (e.rowIndex > boundaries.maxHrIndex) {
					futureTimePicker.setSelectedRow(1, boundaries.maxHrIndex, true);
				}
				if (e.rowIndex === boundaries.minHrIndex) {
					futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
				}
				if (e.rowIndex === boundaries.maxHrIndex) {
					futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
				}
			}
			if (e.columnIndex === 2) {
				//Ti.API.debug('futureTimePicker.getSelectedRow(0).rowIndex: ' + futureTimePicker.getSelectedRow(0).rowIndex);
				//Ti.API.debug('futureTimePicker.getSelectedRow(0): ' + JSON.stringify(futureTimePicker.getSelectedRow(0)));
				boundaries = dayArray[selectedRow.id];
				//Ti.API.debug('boundaries: ' + JSON.stringify(boundaries));
				
				if (e.rowIndex < boundaries.minMinIndex && boundaries.minHrIndex === selectedRow2.id) {
					futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
				}
				if (e.rowIndex > boundaries.maxMinIndex && boundaries.maxHrIndex === selectedRow2.id) {
					futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
				}
			}
		}
		//futureTime.setText(displayTime(futureTimePicker.getSelectedRow(0).id, futureTimePicker.getSelectedRow(1).id, futureTimePicker.getSelectedRow(2).id));
	}); 

	
	/*if(boundaries){
		Ti.API.debug('boundaries: ' + JSON.stringify(boundaries));
		populatePicker(dayArray, hrArray, minArray, boundaries);
	}
	else{*/
		populatePicker(dayArray, hrArray, minArray);
	//}
	
};

//var isHoliday

