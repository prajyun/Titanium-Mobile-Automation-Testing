﻿//var menuUtils = function () {
	 var gModsHash = [];
    var xmlDateToJavascriptDate = function (xmlDate) {
       return new Date(xmlDate);
    };
    var WeekdayValid = function (wdays, effectiveDate) {
        try {
            var retCode = false;
            var weekday = effectiveDate.getDay() + 1;
            switch (weekday) {
                case 1:
                    if (wdays & 1) {
                        retCode = true;
                    }
                    break;
                case 2:
                    if (wdays & 2) {
                        retCode = true;
                    }
                    break;
                case 3:
                    if (wdays & 4) {
                        retCode = true;
                    }
                    break;
                case 4:
                    if (wdays & 8) {
                        retCode = true;
                    }
                    break;
                case 5:
                    if (wdays & 16) {
                        retCode = true;
                    }
                    break;
                case 6:
                    if (wdays & 32) {
                        retCode = true;
                    }
                    break;
                case 7:
                    if (wdays & 64) {
                        retCode = true;
                    }
                    break;
            }
            return retCode;
        }
        catch (e) {
            return false;
        }

    };
    exports.WeekdayValid = WeekdayValid;
    var IsTimeValid = function (tIdx, sTime, eTime, LocalDateTime) {
        try {
            //sTime = sTime + (tz < 0 ? "-" : "+") + ((tz > 9 || tz < -9) ? "" : "0") + (Math.abs(tz)).toString() + ":00";
            //eTime = eTime + (tz < 0 ? "-" : "+") + ((tz > 9 || tz < -9) ? "" : "0") + (Math.abs(tz)).toString() + ":00";

            sTime = xmlDateToJavascriptDate(sTime);
            eTime = xmlDateToJavascriptDate(eTime);
            var sHour, eHour;
                sHour = sTime.getHours();
                eHour = eTime.getHours();
            
            var retCode = false;
            var iHour = LocalDateTime.getHours();
            var iMinute = LocalDateTime.getMinutes();

            switch (tIdx) {
                case 1:
                    if (iHour > sHour) {
                        retCode = true;
                    }
                    else {
                        if (iHour == sHour) {
                            if (iMinute >= sTime.getMinutes()) {
                                retCode = true;
                            }
                            else {
                                retCode = false;
                            }
                        }
                        else {
                            if (iHour < 5) {
                                retCode = true;
                            }
                            else {
                                retCode = false;
                            }
                        }
                    }
                    break;
                case 2:
                    if (iHour > eHour) {
                        retCode = false;
                    }
                    else {
                        if (iHour == eHour) {
                            if (iMinute <= eTime.getMinutes()) {
                                retCode = true;
                            }
                            else {
                                retCode = false;
                            }
                        }
                        else {
                            if (iHour < 5) {
                                retCode = false;
                            }
                            else {
                                retCode = true;
                            }
                        }
                    }
                    break;
                case 3:
                case 4:
                    var blnStart = false;
                    var blnEnd = false;
                    if (iHour > sHour) {
                        blnStart = true;
                    }
                    else {
                        if (iHour == sHour) {
                            if (iMinute >= sTime.getMinutes()) {
                                blnStart = true;
                            }
                            else {
                                blnStart = false;
                            }
                        }
                        else {
                            blnStart = false;
                        }
                    }
                    if (iHour > eHour) {
                        blnEnd = false;
                    }
                    else {
                        if (iHour == eHour) {
                            if (iMinute <= eTime.getMinutes()) {
                                blnEnd = true;
                            }
                            else {
                                blnEnd = false;
                            }
                        }
                        else {
                            blnEnd = true;
                        }
                    }
                    if (tIdx == 3) {
                        if (blnStart && blnEnd) {
                            retCode = true;
                        }
                    }
                    else {
                        if (blnStart || blnEnd) {
                            retCode = true;
                        }
                    }
                    break;
            }
            return retCode;
        }
        catch(e){
            return false;
        }

    };
    exports.IsTimeValid = IsTimeValid;
    var getStoreTime = function (timeZone) {
        var curDate, UTCTime;
        if (ro.app.Store.TimeAtStore) {
            curDate = new Date(ro.app.Store.TimeAtStore);
            UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
            return new Date(UTCTime);
        }
        else if (timeZone) {
            curDate = new Date();
            UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
            return new Date(UTCTime + (timeZone * 3600000));
        }
        else {
            return new Date();
        }
    };
    exports.getStoreTime = getStoreTime;
    var sortPrefs = function(selectedItem){
    	 try{
    	 	 var thisPref;
	       for(var i=0; i<selectedItem.Prefs.length; i++){
		     	 var prefsData = [];
				 for(var j=0; j<selectedItem.Prefs[i].PrefMbrs.length; j++){
				 	 thisPref = selectedItem.Prefs[i].PrefMbrs[j];
				 	 thisPref.prefIndex = i;
				    prefsData.push(thisPref);
					 //prefName:selectedItem.Prefs[i].PrefMbrs[j].Name,
					 //prefIndex:i
					 /*if(selectedItem.Prefs[i].DefaultMember == selectedItem.Prefs[i].PrefMbrs[j].Name){
				 		setPrefs(selectedItem.Prefs[i].PrefMbrs[j].Name, i);
				    }*/
				 }
		    }
		    return prefsData;
		 }
		 catch(ex){
			 ro.ui.alert('prefs loop',ex);
		 }
    }.
    getReqMods = function(isReq){
    	try{
			var grpModLngth = group.Mods.length;
			var selItemReqModLngth = itemSelected.ReqMods.length;
			var modCatLngth = Menu.ModCategories.length;
		}
		catch(ex){
			if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('LoopLimiters: ' + ex); }
		}

		var reqBool;
		var reqModsData = [];
		for(var i=0; i<selItemReqModLngth; i++){
			for(var j=0; j<grpModLngth; j++){
				reqBool = null;
				reqBool = (group.Mods[j].ModCatKey == itemSelected.ReqMods[i]);
				if(reqBool && isReq){
					reqModsData.push(group.Mods[j]);
				}
				else if(!reqBool && !isReq){
					reqModsData.push(group.Mods[j]);
				}
			}
		}
		return reqModsData;
    };
    exports.enhanceStoreObj = function(store){
    	store.sorted = {
    		sortPrefs:function(item){
    			return sortPrefs(item);
    		},
    		sortReqMods:function(isReq){
    			return getReqMods(isReq);
    		}
    	};
    };
    exports.isModValid = function(mod, size){
		var valid = true;
		var itemSelected = ro.app.itemSelected;
		var group = ro.app.group;
		if(itemSelected && itemSelected.ReqMods){
			var reqModCatKey;
			for(var i=0; i<itemSelected.ReqMods.length; i++){
				reqModCatKey = !isNaN(itemSelected.ReqMods[i].Key) ? itemSelected.ReqMods[i].Key : itemSelected.ReqMods[i];

				if(mod.ModCatKey == reqModCatKey){
					valid = false;
					break;
				}
			}
		}

		if(valid){
			if(itemSelected.ExcldMods){
				for(var i=0; i<itemSelected.ExcldMods.length; i++){
					if(itemSelected.ExcldMods[i] == mod.Name){
						valid = false;
						break;
					}
				}
			}
		}

		if(valid && size && size !== null && mod.Sizes){
			valid = false; // Making it false since the service does not include the sizes with -0.86
			for(var i=0; i<mod.Sizes.length; i++){
				if(mod.Sizes[i].Name === size){
					var price = mod.Sizes[i].Price;
					if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
						switch(Ti.App.OrderObj.OrdTypePriceIdx){
							case 1:
								price = mod.Sizes[i].OrdTypePrice1;
								break;
							case 2:
								price = mod.Sizes[i].OrdTypePrice2;
								break;
						}
					}
					valid = (price !== -0.86);
					break;
				}
			}
		}
		return valid;
	};
	//if(menuUtils.straightToCart(menuUtils.getGrp(grpName), menuUtils.getItm(itmName))){
	exports.getGrp = function(grpName, menu){
		var grps = menu.Groups;
		for(var i=0, iMax=grps && grps.length ? grps.length : 0; i<iMax; i++){
			if(grps[i].Name == grpName){
				return grps[i];
			}
		}
	};
	exports.getGrpIdx = function(grpName, menu){
		var grps = menu.Groups;
		for(var i=0, iMax=grps && grps.length ? grps.length : 0; i<iMax; i++){
			if(grps[i].Name == grpName){
				return i;
			}
		}
	};
	exports.getItm = function(itmName, grp){
		var itms = grp.Items;
		//Ti.API.debug('itmName: ' + itmName);
		for(var i=0, iMax=itms && itms.length ? itms.length : 0; i<iMax; i++){
			//Ti.API.debug('itms['+i+']: ' + JSON.stringify(itms[i]));
			//Ti.API.debug('itms['+i+'].Name: ' + itms[i].Name);
			if(itms[i].Name == itmName){
				return itms[i];
			}
		}
	};
    exports.straightToCart = function(grp, itm){
    	var returnBool = false, group = grp ? grp : ro.app.group, itemSelected = itm ? itm : ro.app.itemSelected;
    	if(!group.HasStyles && !group.HasSizes && !itemSelected.HasPrefs && !(itemSelected.HasReqMods && (itemSelected.ReqMods && itemSelected.ReqMods.length > 0) && (group.Mods && group.Mods.length > 0)) && !group.HasMods){
    		returnBool = true;
    	}
    	return returnBool;
    };
    exports.addToCart = function(Store, itemObj, goToMenuBool){//This makes the item not editable from cart.
    	try{
    			var Menu = Store.Menu;
 			var obj = Ti.App.OrderObj;
 			if(!obj.Items){
 				obj.Items = [];
 			}
 			
 			var test = itemObj;
 			test.noEdit = true;
 			itemObj = test;
 			
 			obj.Items.push(itemObj);
 			
 			test = null;
 			//obj.Items[obj.Items.length-1].noEdit = true;	//This makes the item not editable from cart.
 			
 			Ti.App.OrderObj = obj;
			//var func = new PricingFunctions();
			var priceEngine = require('logic/pricing');
	        var func = priceEngine.pricer();
			Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, Menu, Ti.App.OrderObj.OrdTypePriceIdx, (Store.Surcharges || []));
			//ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
			
			if(goToMenuBool){
			    if (Ti.App.newMenu) {
                    ro.ui.ordShowNext({
                        showing: 'itemsView'
                    });
                }
                else {
                    ro.ui.ordShowNext({
                        showing: 'itemDetails'
                    });
                }
			}
			else{
			    ro.ui.showCart(true);
			}
			
			/*if(e.index === 1){
				ro.ui.showLoader();
				ro.ui.showCart();
				ro.ui.hideLoader();
			}
			else if(e.index === 0){
				if(Ti.App.newMenu){
					ro.ui.ordShowNext({showing:'itemsView'});
				}
				else{
					ro.ui.ordShowNext({showing:'itemDetails'});
				}
			}*/
		}
		catch(ex){
			ro.ui.hideLoader();
			ro.ui.alert('Error', 'CODE:102');
		}
    };
    exports.hasValidCpnCode = function(Menu){
    	 try{
    	 	 var cpnLength = (Menu && Menu.Cpns) ? Menu.Cpns.length : 0, currentCpn;
	    	 for(var i=0; i<cpnLength; i++){
	    	    currentCpn = Menu.Cpns[i];

	    	    if(currentCpn && currentCpn.ReqValCode){
	    	    	 return true;
	    	    }
	    	 }
	    }
	    catch(ex){
	    	Ti.API.debug('menuUtils.hasValidCpnCode()-Exception: ' + ex);
	    }
    	 return false;
    };
    exports.hasDispCoupons = function(ordTyp){
       
         //GUEST ORDERS
         var isGuest = false;
         if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
            isGuest = true;
         }
         //GUEST ORDERS
         
         var timeAtStore = getStoreTime(ro.app.Store.TimeZone);
       
			var j, k, CpnIdx, blnVis, deliveryType, curDate, UTCTime, startDt, ExpirDt;
		   var BtnIdx = 0;
		   var curOrdType = Ti.App.OrderObj.OrdType;
		   var cpnLngth = ro.app.Store.Menu.Cpns.length;

			var returnBool = false;

        for(CpnIdx = 0; CpnIdx < cpnLngth; CpnIdx++){
				if(!ro.app.Store.Menu.Cpns[CpnIdx].ReqValCode || ro.app.Store.Menu.Cpns[CpnIdx].VCSupress ){//&& parseInt(ro.app.Store.Menu.Cpns[CpnIdx].CpnScope, 10) != 1){
					blnVis = false;
					curDate = new Date();
		         UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);

					if(ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All'){
						blnVis = true;
						if(ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER'){
							blnVis = false;
							continue;
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].CpnScope === 3){
							if(!ro.app.Store.Menu.Cpns[CpnIdx].Items){
								blnVis = false;
								continue;
							}
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true){// && isGuest){
                     ////deb.ug(ro.app.Store.Menu.Cpns[CpnIdx], 'ro.app.Store.Menu.Cpns[CpnIdx]');
                     if(isGuest){
                        blnVis = false;
                        continue;
                     }
                     else{
                        var rs = ro.db.getCustObj(Ti.App.Username);
                        if(!rs){
                           rs = {};
                        }
                        if(!rs.CpnUsage){
                           rs.CpnUsage = [];
                        }
                        else{
                           rs.CpnUsage = rs.CpnUsage.split("-");
                        }
                        var shouldContinue = false;
                        for(var cpnUsageIdx = 0, cpnUsageMax=rs.CpnUsage.length; cpnUsageIdx < cpnUsageMax; cpnUsageIdx++){
                           Ti.API.debug('rs.CpnUsage['+cpnUsageIdx+']: ' + rs.CpnUsage[cpnUsageIdx]);
                           if(ro.app.Store.Menu.Cpns[CpnIdx].Key == rs.CpnUsage[cpnUsageIdx]){
                              blnVis = false;
                              shouldContinue = true;
                              break;                  
                           }
                        }
                        /*if(Ti.App.CpnUsageString && Ti.App.CpnUsageString.length){
                           for(var cpnLg=0; cpnLg<Ti.App.CpnUsageString.length; cpnLg++){
                              if(Ti.App.CpnUsageString[cpnLg] == ro.app.Store.Menu.Cpns[CpnIdx].Key){
                                 blnVis = false;
                                 shouldContinue = true;
                                 break;                                 
                              }
                           }
                        }*/
                        if(shouldContinue){
                           Ti.API.debug('continuing due to already having used this single use cpn...IT SHOULD NOT SHOW UP IN CPN LIST');
                           continue;
                        }
                     }
                  }
				
                        if (ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes && ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
                            for(var exclOrdIdx = 0; exclOrdIdx < ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; exclOrdIdx++){
                                if(Ti.App.OrderObj.OrdType == ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
                                    blnVis = false;
                                    continue;
                                }
                            }
                        }

						if(ro.app.Store.Menu.Cpns[CpnIdx].HasStartDt){
							startDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].StartDtStr);
							if (startDt.getTime() > timeAtStore.getTime()) {
								blnVis = false;
								continue;
							}
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].HasExpirDt){
                            ExpirDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].ExpirDtStr);
                            var StoreDate = new Date(timeAtStore);
                            ExpirDt.setHours(0, 0, 0, 0);
                            StoreDate.setHours(0, 0, 0, 0);
                            if (ExpirDt.getTime() < StoreDate.getTime()) {
                                blnVis = false;
                                continue;
                            }                            
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays > 0){
							if(blnVis==true){
							   if(!WeekdayValid(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays, timeAtStore)){
									blnVis=false;
									continue;
								}
							}
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx > 0){
                            if (blnVis == true) {
								//if(!IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTime, ro.app.Store.Menu.Cpns[CpnIdx].EndTime, timeAtStore)){
								if(!IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTimeStr, ro.app.Store.Menu.Cpns[CpnIdx].EndTimeStr, timeAtStore)){
                                    blnVis = false;
   									continue;
   								}
								//}
							}
						}
						if(ro.app.Store.Menu.Cpns[CpnIdx].HasExcldOrdType){
							if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes){
								for(j=0;j<ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length;j++){
									if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[j] == curOrdType){
										blnVis=false;
										continue;
									}
								}
							}
						}
						if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
							if(ro.app.Store.Menu.Cpns[CpnIdx].NoDelivery){
								blnVis = false;
								continue;
							}
						}
						if(blnVis){
							//Coupons.push(ro.app.Store.Menu.Cpns[CpnIdx]);
							returnBool = true;
						}
					}
				}
			}
			return returnBool;
		};
    
    exports.testCpnCode = function(cpnCode, goToGrpsBool, isEwomBool, LoyaltyCode, _LtyBadgeCb, goToCartHome) {
    try {
        Ti.API.info('cpnCode: ' + cpnCode);
        var coupon,
            alertTitle,
            cpnFound = false,
            alertMessage = 'No coupon found.';
        var tempMultiQualCpn,
            tempMultiQualCpnBln = false;
        var storeObj = ro.app.Store;
        if (cpnCode && cpnCode.length > 0) {
            if (storeObj.Menu.Cpns) {
                for (var i = 0; i < storeObj.Menu.Cpns.length; i++) {
                    if (storeObj.Menu.Cpns[i].ReqValCode) {
                        //Ti.API.debug('storeObj.Menu.Cpns[i].ValCodes: ' + JSON.stringify(storeObj.Menu.Cpns[i].ValCodes));
                        for (var j = 0, jMax = (storeObj.Menu.Cpns[i].ValCodes && storeObj.Menu.Cpns[i].ValCodes.length ? storeObj.Menu.Cpns[i].ValCodes.length : 0); j < jMax; j++) {
                            if (cpnCode.toUpperCase() == storeObj.Menu.Cpns[i].ValCodes[j].toUpperCase()) {
                                cpnFound = true;

                                if (storeObj.Menu.Cpns[i].NoDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {                                    
                                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' coupon is not available for delivery orders');
                                    return;
                                }

                                if (storeObj.Menu.Cpns[i].ExcldOrdTypes && storeObj.Menu.Cpns[i].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
                                    for(var exclOrdIdx = 0; exclOrdIdx < storeObj.Menu.Cpns[i].ExcldOrdTypes.length; exclOrdIdx++){
                                        if(Ti.App.OrderObj.OrdType == storeObj.Menu.Cpns[i].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
                                            var ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.OrdType, storeObj.Menu.OnlineOptions.OrdTypes, 'OrdType');
                                            var ordName = storeObj.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName ? storeObj.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName : Ti.App.OrderObj.OrdType;
                                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' coupon is not available for ' + ordName + ' orders');
                                            return;
                                        }
                                    }
                                }

                                if (storeObj.Menu.Cpns[i].ConfirmLoyalty && !isEwomBool) {
                                    ro.ui.alert(alertTitle, alertMessage);
                                    return;
                                }

                                var storeTime = getStoreTime(storeObj.TimeZone);
                                if (storeObj.Menu.Cpns[i].HasStartDt) {
                                    var startDt = new Date(storeObj.Menu.Cpns[i].StartDtStr);
                                    if (startDt.getTime() > storeTime.getTime()) {
                                        ro.ui.alert('Coupon Not Valid', 'This coupon is not valid at this time.');
                                        return;
                                    }
                                }
                                if (storeObj.Menu.Cpns[i].HasExpirDt) {
                                    var ExpirDt = new Date(storeObj.Menu.Cpns[i].ExpirDtStr);
                                    var StoreDate = new Date(storeTime);
                                    ExpirDt.setHours(0, 0, 0, 0);
                                    StoreDate.setHours(0, 0, 0, 0);
                                    if (ExpirDt.getTime() < StoreDate.getTime()) {
                                        ro.ui.alert('Coupon Not Valid', 'This coupon is not valid at this time.');
                                        return;
                                    }                                    
                                }

                                if (storeObj.Menu.Cpns[i].MultiQualTtl) {
                                    if (Ti.App.OrderObj && Ti.App.OrderObj.Cpns) {
                                        var ordCpns = Ti.App.OrderObj.Cpns;
                                        var ordCpnLen = ordCpns.length || 0;
                                        for (var a = 0; a < ordCpnLen; a++) {
                                            if (ordCpns[a].MultiQualTtl && ordCpns[a].MultiQualTtl > 0) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' is not valid with other qualifying amount coupons.');
                                                //use the i index here because you want to display the coupon name of the coupon that is trying to be added not the coupon from the cart already
                                                return;
                                            }
                                        }
                                    }

                                    if (Ti.App.OrderObj && Ti.App.OrderObj.TempCpns) {
                                        var ordCpns = Ti.App.OrderObj.TempCpns;
                                        var ordCpnLen = ordCpns.length || 0;
                                        for (var a = 0; a < ordCpnLen; a++) {
                                            if (ordCpns[a].MultiQualTtl && ordCpns[a].MultiQualTtl > 0) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' is not valid with other qualifying amount coupons.');
                                                //use the i index here because you want to display the coupon name of the coupon that is trying to be added not the coupon from the cart already
                                                return;
                                            }
                                        }
                                    }

                                    var currentSubtotal = Ti.App.OrderObj.Subtotal || 0;
                                    var cpnMinPrice = storeObj.Menu.Cpns[i].MultiQualTtl;
                                    if (currentSubtotal < cpnMinPrice) {
                                        tempMultiQualCpnBln = true;
                                        tempMultiQualCpn = storeObj.Menu.Cpns[i];
                                        //ro.ui.alert('Coupon Not Valid', 'You must have a minimum of $' + cpnMinPrice + ' in your cart prior to applying this coupon.');
                                        // return;
                                    }
                                }

                                if (storeObj.Menu.Cpns[i].SingleUse == true) {
                                    if (Ti.App.CpnUsageString && Ti.App.CpnUsageString.length) {
                                        for (var cpnLg = 0; cpnLg < Ti.App.CpnUsageString.length; cpnLg++) {
                                            if (Ti.App.CpnUsageString[cpnLg] == storeObj.Menu.Cpns[i].Key) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied to a past order.');
                                                return;
                                            }
                                        }
                                    }
                                }
                                if (Ti.App.OrderObj.Cpns) {
                                    if (Ti.App.OrderObj.Cpns.length > 0 && storeObj.Menu.Cpns[i].IsExclusive) {
                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' coupon is not valid with any other coupon.');
                                        return;
                                    }
                                    for (var idx = 0; idx < Ti.App.OrderObj.Cpns.length; idx++) {
                                        if (Ti.App.OrderObj.Cpns[idx].IsExclusive) {
                                            ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[idx].Name + ' coupon. This is not valid with any other coupon.');
                                            return;
                                        }
                                        if (storeObj.Menu.Cpns[i].SingleUse) {
                                            if (Ti.App.OrderObj.Cpns[idx].Name == storeObj.Menu.Cpns[i].Name) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied.');
                                                return;
                                            }
                                        }
                                    }
                                }

                                if (Ti.App.OrderObj.Items) {
                                    for (var x = 0; x < Ti.App.OrderObj.Items.length; x++) {
                                        if (Ti.App.OrderObj.Items[x].CpnObj) {
                                            if (storeObj.Menu.Cpns[i].IsExclusive) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' coupon is not valid with any other coupon.');
                                                return;
                                            }                                            
                                            if (Ti.App.OrderObj.Items[x].CpnObj.IsExclusive) {
                                                ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon. This is not valid with any other coupon.');
                                                return;
                                            }
                                            if (storeObj.Menu.Cpns[i].SingleUse) {
                                                if (Ti.App.OrderObj.Items[x].CpnObj.Name == storeObj.Menu.Cpns[i].Name) {
                                                   ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied.');
                                                   return;
                                                }
                                            }                                            
                                        }
                                    }                                    
                                }

                                switch(parseInt(storeObj.Menu.Cpns[i].CpnScope, 10)) {
                                    case 1:
                                        if (Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length > 0) {
                                            for (var idx = 0; idx < Ti.App.OrderObj.Cpns.length; idx++) {
                                                if (Ti.App.OrderObj.Cpns[idx].Name == storeObj.Menu.Cpns[i].Name) {
                                                    ro.ui.alert('Coupon Not Valid', 'Your cart already has this coupon. It can only be applied once.');
                                                    ro.ui.hideLoader();
                                                    return;
                                                }

                                                if (Ti.App.OrderObj.Cpns[idx].CpnType == 2 && storeObj.Menu.Cpns[i].CpnType == 2) {
                                                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                                    ro.ui.hideLoader();
                                                    return;
                                                }
                                            }
                                        }

                                        if (storeObj.Menu.Cpns[i].MinPrice > 0) {
                                            var dcSubTot = 0;
                                            if (Ti.App.OrderObj.Cpns) {
                                                for (var k = 0; k < Ti.App.OrderObj.Cpns.length; k++) {
                                                    if (Ti.App.OrderObj.Cpns[k].MinPrice > 0) {
                                                        cpnFound = false;
                                                        break;
                                                    }
                                                }
                                            }
                                            dcSubTot = Ti.App.OrderObj.Subtotal;

                                            if (dcSubTot < storeObj.Menu.Cpns[i].MinPrice) {
                                                cpnFound = false;
                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                alertMessage = 'This coupon cannot be applied. Minimum order amount is: $' + storeObj.Menu.Cpns[i].MinPrice.toFixed(2);
                                                Ti.API.info('Min Order cpn ' + storeObj.Menu.Cpns[i]);
                                                break;
                                            }
                                        }
                                        break;
                                    case 2:
                                        break;
                                    case 3:
                                        if (!storeObj.Menu.Cpns[i].Items) {
                                            cpnFound = false;
                                            break;
                                        }
                                        else {
                                            if (storeObj.Menu.Cpns[i].Items.length > 0) {
                                                var sTime = new Date();
                                                sTime.setHours(0, 0);
                                                var eTime = sTime;
                                                
                                                if(!isCpnConfiguredProperly(storeObj.Menu.Cpns[i])){
                                                	   ro.ui.alert('Invalid Coupon. ', 'The store has not configured this coupon properly.');
                                                    ro.ui.hideLoader();
                                                    return;
                                                }
                                                
                                                /*if(!ro.coupons.ValidateMultiCoupons(storeObj.Menu.Cpns[i].Items, 0, 0, false, 0, sTime, eTime)){
                                                 cpnFound = false;
                                                 alertTitle = storeObj.Menu.Cpns[i].Name;
                                                 alertMessage = 'Please add the required items to apply the coupon.';
                                                 break;
                                                 }*/
                                            }
                                            else {
                                                cpnFound = false;
                                                break;
                                            }
                                        }
                                        break;
                                    case 4:
                                        if (storeObj.Menu.Cpns[i].SingleUse == true) {
                                            if (Ti.App.OrderObj.Items) {
                                                for (var itmLg = 0; itmLg < Ti.App.OrderObj.Items.length; itmLg++) {
                                                    if (Ti.App.OrderObj.Items[itmLg].CpnObj && Ti.App.OrderObj.Items[itmLg].CpnObj.SingleUseKey && (Ti.App.OrderObj.Items[itmLg].CpnObj.SingleUseKey == storeObj.Menu.Cpns[i].Key)) {
                                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied.');
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        break;
                                }
                                var curDate = new Date();
                                var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
                                var timeAtStore = getStoreTime(storeObj.TimeZone);

                                if (storeObj.Menu.Cpns[i].Weekdays > 0) {
                                    if (cpnFound == true) {
                                        if (!WeekdayValid(storeObj.Menu.Cpns[i].Weekdays, timeAtStore)) {
                                            var weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                                            cpnFound = false;
                                            alertTitle = storeObj.Menu.Cpns[i].Name;
                                            alertMessage = 'This coupon is not valid on ' + weekDay[timeAtStore.getDay()] + '.';
                                            break;
                                        }
                                    }
                                }

                                if (storeObj.Menu.Cpns[i].TimeIdx > 0) {
                                    if (cpnFound == true) {
                                        //if (!IsTimeValid(storeObj.Menu.Cpns[i].TimeIdx, storeObj.Menu.Cpns[i].StartTime, storeObj.Menu.Cpns[i].EndTime, timeAtStore)) {
                                            if (!IsTimeValid(storeObj.Menu.Cpns[i].TimeIdx, storeObj.Menu.Cpns[i].StartTimeStr, storeObj.Menu.Cpns[i].EndTimeStr, timeAtStore)) {
                                                cpnFound = false;
                                                var sTime = xmlDateToJavascriptDate(storeObj.Menu.Cpns[i].StartTimeStr);
                                                var eTime = xmlDateToJavascriptDate(storeObj.Menu.Cpns[i].EndTimeStr);
                                                var startTime = ro.utils.getFormattedTime(sTime);
                                                var endTime = ro.utils.getFormattedTime(eTime);
                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                alertMessage = 'This coupon is only valid between ' + startTime + '-' + endTime + '.';
                                                break;
                                            }
                                        //}
                                    }
                                }

                                if (storeObj.Menu.Cpns[i].HasExcldOrdType) {
                                    if (storeObj.Menu.Cpns[i].ExcldOrdTypes) {
                                        for (var l = 0; l < storeObj.Menu.Cpns[i].ExcldOrdTypes.length; l++) {
                                            if (storeObj.Menu.Cpns[i].ExcldOrdTypes[l] == curOrdType) {
                                                cpnFound = false;
                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                alertMessage = 'The coupon is not valid for ' + curOrdType + ' order type.';
                                                break;
                                            }
                                        }
                                    }
                                }
                                coupon = storeObj.Menu.Cpns[i];
                                break;
                            }
                        }// End for j (valcodes)

                        if (cpnFound) {
                            break;
                        }
                    } // End if ReqValCode
                } // End for i
            }
        }

        if (cpnFound) {
            saveTempValcode(cpnCode, coupon.Key);
            if (parseInt(coupon.CpnScope, 10) == 1) {
                addCoupon(coupon, cpnCode, LoyaltyCode, goToCartHome);
                //Ti.API.info('Coupon Applied: ' + JSON.stringify(storeObj.Menu.Cpns[i]));
                var msg = storeObj.Menu.Cpns[i].Name + ' has been applied to your order!';
                if (LoyaltyCode && LoyaltyCode.length && _LtyBadgeCb) {
                    _LtyBadgeCb(msg);
                }
                else {
					ro.ui.alert('Coupon Applied.', msg);
                }
                ro.ui.hideLoader();
                return;
            }
            try {
                ro.cpnHelper.setCpnBool(true, LoyaltyCode);
                ro.utils.removeProp('SelectedCoupon');
                ro.utils.removeProp('nrq');
                ro.utils.removeProp('rq');
                Ti.API.info('Goto groups bool' + goToGrpsBool);
                if (goToGrpsBool) {                    
                    ro.ui.ordShowNext({
                        addView: true,
                        showing: 'cpnSelView',
                        cpnKey: coupon.Key,
                        cpnValcode: cpnCode,
                        backToGrps: goToGrpsBool
                    });                
                } else {                    
                    ro.App.cpnCodeMode.Flg = true;
                    ro.App.cpnCodeMode.Key = storeObj.Menu.Cpns[i].Key;
                    ro.App.cpnCodeMode.LoyaltyCode = LoyaltyCode;
                    ro.ui.cartShowNext({
                        showing: 'Cart'
                    });
                }
            }
            catch(ex) {
                Ti.API.debug('APPLY_COUPON()-Exception: ' + ex);
                ro.ui.hideLoader();
            }
        }
        else {
            ro.ui.alert(alertTitle, alertMessage);
            ro.ui.hideLoader();
            return;
        }
    }
    catch(ex) {
        Ti.API.info('menuUtils.testCpnCode()-Exception: ' + ex);
        Ti.API.info('APPLY_COUPON-end-Exception: ' + ex);
        ro.ui.alert('Coupons', 'CODE AC100');
    }
}; 

    var addCoupon = function(coupon, valcode, LoyaltyCode, goToCartHome){
      var cpnObj = {};
      var Ord = Ti.App.OrderObj;
      if(!Ord.Cpns){
         Ord.Cpns = [];
      }

	  if(LoyaltyCode){	  	 
	  	 cpnObj.LoyaltyCode = LoyaltyCode;
	  	 cpnObj.LtyDiscountType = 1;
	  	 if(ro.app.Store.Configuration.CP_APIKEY && ro.app.Store.Configuration.CP_APIKEY.length){
	  	     var testDigits = LoyaltyCode[0] + LoyaltyCode[1];
	  	     if(testDigits.toLowerCase() != "hc" && testDigits.toLowerCase() != "ew"){
	  	         cpnObj.LtyDiscountType = 3;
	  	     }
	  	 }
	  }
      cpnObj.CpnValue = coupon.CpnValue;
      cpnObj.RcptName = coupon.RcptName;
      cpnObj.Name = coupon.Name;
      cpnObj.CpnScope = coupon.CpnScope;
      cpnObj.CpnType = coupon.CpnType;
      cpnObj.CpnPct = coupon.CpnPct;
      cpnObj.MinPrice = coupon.MinPrice?coupon.MinPrice:0;
      cpnObj.MaxValue = coupon.MaxValue?coupon.MaxValue:0;
      cpnObj.AdjItemPrice = coupon.AdjItemPrice;
      cpnObj.TaxType = coupon.TaxType;
      cpnObj.ReportGrp = coupon.ReportGrp;
      cpnObj.FreeDlvy = coupon.FreeDlvy;
      cpnObj.LeaveTax = coupon.LeaveTax;
      cpnObj.No2ndItm = coupon.No2ndItm;
      cpnObj.BeatClock = coupon.BeatClock;
      cpnObj.DlvyFeeIfZero = coupon.DlvyFeeIfZero;
      cpnObj.NoModDisc = coupon.NoModDisc;
      cpnObj.NoStyleDisc = coupon.NoStyleDisc;
	  cpnObj.NoPrefDisc = coupon.NoPrefDisc;
	  
      var curDate = new Date();
      var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
      cpnObj.TimeApplied = new Date(UTCTime + (ro.app.Store.TimeZone * 3600000));
      cpnObj.TimeAppliedStr = new Date(UTCTime + (ro.app.Store.TimeZone * 3600000));

      if(coupon.ReqValCode){
         cpnObj.ValCode = valcode;
      }
      //cpnObj.IsExclusive = coupon.IsExclusive;
      //cpnObj.MultiQualTtl = coupon.MultiQualTtl?coupon.MultiQualTtl:0;
      cpnObj.IsExclusive = coupon.IsExclusive;
      cpnObj.MultiQualTtl = coupon.MultiQualTtl?coupon.MultiQualTtl:0;
      cpnObj.PickAnyCnt = coupon.PickAnyCnt?coupon.PickAnyCnt:0;
      cpnObj.RequireAnyCnt = coupon.RequireAnyCnt?coupon.RequireAnyCnt:0;
      cpnObj.RequiredItem = coupon.RequiredItem;
      cpnObj.MaxModValue = coupon.MaxModValue;

      if(coupon.CpnScope >= 3){
         var cpnItmCol = [];
         for(var i=0; i<coupon.Items.length; i++){
            var cpnItmObj = {};
            cpnItmObj.MenuGroup = coupon.Items[i].MenuGroup;
            cpnItmObj.MenuItem = coupon.Items[i].MenuItem;
            cpnItmObj.MenuSize = coupon.Items[i].MenuSize;
            cpnItmObj.MenuSizes = coupon.Items[i].MenuSizes;
            cpnItmObj.MenuStyle = coupon.Items[i].MenuStyle;
            cpnItmObj.MenuStyles = coupon.Items[i].MenuStyles;
            cpnItmObj.IsRequired = coupon.Items[i].IsRequired;
            cpnItmObj.CpnKey = coupon.Key;
            cpnItmObj.MenuCpnItmKey = coupon.Items[i].MenuCpnItmKey;
            cpnItmObj.BogoReq = coupon.Items[i].BogoReq;
            cpnItmObj.MaxModValue = coupon.Items[i].MaxModValue;
            cpnItmObj.Surcharge = coupon.Items[i].Surcharge;
            cpnItmCol.push(cpnItmObj);
         }
         cpnObj.Items = cpnItmCol;
      }
      if(coupon.SingleUse){
         cpnObj.SingleUseKey = coupon.Key;
      }
      Ord.Cpns.push(cpnObj);
      Ti.App.OrderObj = Ord;        
        if (goToCartHome) {
            ro.ui.cartShowNext({ showing: 'Coupons', reprice: true });
        } else {
            ro.ui.showCart();
            if (typeof ro.ui.reloadCart === "function") {
                ro.ui.reloadCart();
            }            
            if (typeof ro.ui.reprintTicket === "function") {
                ro.ui.reprintTicket();
            }
        }
      /*if(ro.app.isDemo){
         ro.ui.reloadCartDemo();
         ro.ui.demoCartShowNext({ showing:'Coupons', reprice:true });
      }
      else{
         ro.ui.reloadCart();
         ro.ui.cartShowNext({ showing:'Coupons', reprice:true });
      }*/
   };
    exports.addCoupon = addCoupon;
    exports.getModsHash = function(shouldDo){

    	if(!shouldDo && gModsHash.length){
    		return gModsHash;
    	}
    	gModsHash = [];

    	var gMods = group.Mods ? group.Mods : [];
		//var mdCategories = ro.app.Store.Menu.ModCategories ? ro.app.Store.Menu.ModCategories : [];
		var isReqModBool = false;
		for(var i=0; i<gMods.length; i++){
			isReqModBool = false;
			//Ti.API.debug('gMods['+i+'].ModCatKey: ' + gMods[i].ModCatKey);
			/*var itmSelReqMdLength = itemSelected.HasReqMods && itemSelected.ReqMods && itemSelected.ReqMods.length ? itemSelected.ReqMods.length : 0;
			for(var j=0; j<itmSelReqMdLength; j++){
				var thisKey = !isNaN(itemSelected.ReqMods[j].Key) ? itemSelected.ReqMods[j].Key : itemSelected.ReqMods[j];
				if(thisKey == gMods[i].ModCatKey){
					isReqModBool = true;
					break;
				}
			}
			if(isReqModBool){
				Ti.API.debug('found a req mod');
				continue;
			}*/

			if(!gModsHash[gMods[i].ModCatKey] || !gModsHash[gMods[i].ModCatKey].length){
				gModsHash[gMods[i].ModCatKey] = [];
			}
			//if(gModsHash[])
			gModsHash[gMods[i].ModCatKey].push(gMods[i]);
		}


		//for(var props in gModsHash){
			//Ti.API.debug('gModsHas['+props+']: ' + JSON.stringify(gModsHash[props]));
			//mdCategories[props]
		//}
		//Ti.API.debug('gModsHash.length: ' + JSON.stringify(gModsHash.length));
		return gModsHash;
   };
    exports.formItmDesc = function(Itm, grpIndx){
    		var group = ro.app.Store.Menu.Groups[grpIndx];
    		var curSelectedGroup = group.Name;


      	var rtnDesc = "";
      	if(Itm.ItemDesc){
      	   rtnDesc = Itm.ItemDesc;
      	}
      	else{
      		var preModsFound = false;
      		if(Itm.PreMods){
      			if(Itm.PreMods.length > 0){
      				if(curSelectedGroup == "Pizza"){
      			 		rtnDesc += "Our " + Itm.ReceiptName + " is topped with ";
      				}
      				else{
      					rtnDesc += Itm.ReceiptName + " is served with ";
      				}

      				for(var i=0; i<Itm.PreMods.length; i++){
      					if(group.Mods){
      						for(var j=0; j<group.Mods.length; j++){
      							if(Itm.PreMods[i].Name == group.Mods[j].Name){
      								preModsFound = true;
      								rtnDesc += group.Mods[j].ReceiptName;
      								if(i != Itm.PreMods.length-1){
      									rtnDesc += ", ";
      								}
      							}
      						}
      					}
      				}

      				if(preModsFound){
      					rtnDesc += ".";
      				}
      				else{
      					rtnDesc = "";
      				}
      			}
      		}
      	}
      	var rtnObj = {};
      	rtnObj.description = rtnDesc;
      	rtnObj.txtObj = null;
      	return rtnObj;
     };
    var saveTempValcode = function(ValCode, CpnKey){
         Ti.API.debug('ValCode: ' + ValCode);
         Ti.API.debug('CpnKey: ' + CpnKey);
         var valcodeObj = {
            cpnKey: CpnKey,
            valCode: ValCode
         };
         
         Ti.App.Properties.setString('ValCode', JSON.stringify(valcodeObj));
      };
    exports.saveTempValcode = saveTempValcode;
    exports.getTempValcode = function(cpnKey){
	     var valcodeObj = JSON.parse(Ti.App.Properties.getString('ValCode'));
	     if(!valcodeObj){
	        valcodeObj = {};
	     }
	     if(valcodeObj.cpnKey && valcodeObj.cpnKey === cpnKey){
	        ro.utils.removeProp('ValCode');
	        return valcodeObj.valCode;
	     }
	     else{
	        Ti.API.debug('Missing Valcode for CpnKey: ' + valcodeObj.cpnKey);
	        return "";
	     }
    };
    exports.foundReqMods = function(ItemReqMods, ItemSel, grpMods, Menu){
      	 //if(!ItemReqMods) ItemReqMods
      	 var modCatIdx = !isNaN(ItemReqMods.Key) ? ro.utils.getMatchingIdx(ItemReqMods.Key, Menu.ModCategories, 'Key') : ro.utils.getMatchingIdx(ItemReqMods, Menu.ModCategories, 'Key');
      	 //Ti.API.debug('modCatIdx: ' + modCatIdx);
      	 var ExcldMods = ItemSel.ExcldMods || [];
      	 for(var i=0, iMax=grpMods.length; i<iMax; i++){
      	 	var grpMod = grpMods[i];
      	 	////Ti.API.debug('grpMod.modCatKey: ' + grpMod.modCatKey);
      	 	////Ti.API.debug('modCatIdx: ' + modCatIdx);
      	 	////Ti.API.debug('Menu.ModCategories['+modCatIdx+']: ' + JSON.stringify(Menu.ModCategories[modCatIdx]));
      	 	if(grpMod.ModCatKey == Menu.ModCategories[modCatIdx].Key){
      	 		//Ti.API.debug('grpMod.Name: ' + grpMod.Name);
      	 		var isExcluded = false;
      	 		for(var j=0,jMax=ExcldMods&&ExcldMods.length?ExcldMods.length:0; j<jMax; j++){
      	 			//Ti.API.debug('ExcldMods['+j+']: ' + ExcldMods[j]);
      	 			
      	 			if(ExcldMods[j] == grpMod.Name){
      	 				isExcluded = true;
      	 				break;	
      	 			}
      	 		}
      	 		if(!isExcluded){
      	 			return true;
      	 		}
      	 	}
      	 }
      	 return false;
    };
    var isSizeOutOfStock = function(group, selItem, selStyle, selSize){
        if(!group || !group.OOStockItems || !group.OOStockItems.length) return false;
        return group.OOStockItems.indexOf(selItem + "__" + selStyle + "__" + selSize) !== -1;
    };
    exports.isSizeOutOfStock = isSizeOutOfStock;
    exports.decimalizeInt = function (val) {
        if (!isNaN(val)) {
            val = parseInt(val, 10);
            if (isNaN(val)) {
                val = '0';
            }
            else {
                val = val.toString();
            }            
        }
        if (val && val.length) {
            if (val.length === 1) {
                val = '0.0' + val;
            }
            else if (val.length === 2) {
                val = '0.' + val;
            }
            else {
                var lastTwoIdx = (val.length - 2);
                val = val.slice(0, lastTwoIdx) + "." + val.slice(lastTwoIdx);
            }            
        }
        return val;
    };
    function findGroups(grpName) {
    		var returnGroups = [];
    		if(grpName && grpName.length && grpName.toLowerCase() == 'all'){
    			return ro.app.Store.Menu.Groups;
    		}
        for (var i = 0, iMax = ro.app.Store.Menu.Groups.length; i < iMax; i++) {
            if (ro.app.Store.Menu.Groups[i].Name == grpName) {
                returnGroups.push(ro.app.Store.Menu.Groups[i]);
                return returnGroups;
            }
        }
        return false;
    }

    function findMenuItem(grp, itemName) {
    		if(!grp || !grp.Items || !grp.Items.length) return false;
    		
        for (var i = 0, iMax = grp.Items.length; i < iMax; i++) {
            if (grp.Items[i].Name == itemName) {
            		var returnItem = grp.Items[i];
            		returnItem.itmIdx = i;
                return returnItem;
            }
        }
        return false;
    }
    function findMatchingSize(grp, sizeName){
    		if(!grp || !grp.Sizes || !grp.Sizes.length) return false;
    		
    		for(var i=0, iMax=grp.Sizes.length; i<iMax; i++){
    			if(grp.Sizes[i].Name.toLowerCase() == sizeName.toLowerCase()){
    				return grp.Sizes[i];
    			}
    		}
    		return false;
    }
    function findMatchingStyle(grp, styleName){
    		if(!grp || !grp.Styles || !grp.Styles.length) return false;
    		
    		for(var i=0, iMax=grp.Styles.length; i<iMax; i++){
    			if(grp.Styles[i].Name.toLowerCase() == styleName.toLowerCase()){
    				return grp.Styles[i];
    			}
    		}
    		return false;
    }
var isCpnConfiguredProperly = function (theCpn, returnTheFoundGroup, returnTheItm) {
    var cpnIdx = ro.utils.getMatchingIdx(theCpn.Key, ro.app.Store.Menu.Cpns, 'Key');
    Ti.API.info("cpnIdx: " + cpnIdx);
        if (theCpn && theCpn.Items && theCpn.Items.length) {
            var isPickAnyCpn = false;
            var pickAnyCnt = 0;
            var reqAnyCnt = 0;
            if (theCpn.PickAnyCnt > 0 || theCpn.RequireAnyCnt > 0) {
                isPickAnyCpn = true;
            }
            for (i = theCpn.Items.length - 1; i >= 0; i--) {
                var cpnItem = theCpn.Items[i];
                if ((!cpnItem.MenuGroup || !cpnItem.MenuGroup.length) || (!cpnItem.MenuItem || !cpnItem.MenuItem.length) || (!cpnItem.MenuSize || !cpnItem.MenuSize.length) || (!cpnItem.MenuStyle || !cpnItem.MenuStyle.length)) {
                    Ti.API.info('One of the cpnItem properties was missing or blank');
                    return false;
                }
                var grps = findGroups(cpnItem.MenuGroup);
                if (!grps) {
                    if (cpnItem.MenuGroup.toLowerCase() == 'all') {

                    }
                    Ti.API.info('Did not find matching group for cpnItem');
                    return false;
                }
                var didFind = false;
                for (j = 0, jMax = grps.length; j < jMax; j++) {
                    if (cpnItem.MenuItem.toLowerCase() == 'all') {
                        if (!grps[j].Items || !grps[j].Items.length) {
                            Ti.API.info('MenuItem = all and but there were no items in the matching group');
                            //return false;
                            continue;
                        }
                    }
                    else {
                        var itm = findMenuItem(grps[j], cpnItem.MenuItem);
                        if (!itm) {
                            Ti.API.info('Did not find the matching item for cpnItem');
                            continue;
                        }
                    }

                    if (cpnItem.MenuSize.toLowerCase() == 'all') {
                        if (grps[j].HasSizes && (!grps[j].Sizes || !grps[j].Sizes.length)) {
                            Ti.API.info('MenuSize = all and but there were no sizes in the matching group');
                            continue;
                        }
                    }
                    else {
                        var sz = findMatchingSize(grps[j], cpnItem.MenuSize);
                        if (!sz) {
                            Ti.API.info('Did not find the matching sz for cpnItem');
                            continue;
                        }
                        var OOSStyle = "None";
                        if (grps[j].HasStyles && cpnItem.MenuStyle.toLowerCase() != 'all') {
                            OOSStyle = cpnItem.MenuStyle;
                        }
                        if (isSizeOutOfStock(grps[j], cpnItem.MenuItem, OOSStyle, cpnItem.MenuSize)) {
                            Ti.API.info('Matching sz is out of stock for cpnItem');
                            continue;
                        }
                    }
                    if (cpnItem.MenuStyle.toLowerCase() == 'all') {
                        if (grps[j].HasStyles && (!grps[j].Styles || !grps[j].Styles.length)) {
                            Ti.API.info('MenuStyle = all and but there were no styles in the matching group');
                            continue;
                        }
                    }
                    else {
                        var style = findMatchingStyle(grps[j], cpnItem.MenuStyle);
                        if (!style) {
                            Ti.API.info('Did not find the matching style for cpnItem');
                            continue;
                        }
                    }
                    if (returnTheFoundGroup) {
                        var returnGrp = grps[j];
                        returnGrp.itmGroupIdx = j;
                        return returnGrp;
                    }
                    else if (returnTheItm) {
                        var returnItm = itm;
                        returnItm.itmGroupIdx = j;
                        returnItm.itmIdx = itm.itmIdx;
                        return returnItm;
                    }
                    didFind = true;
                    break;
                }
                if (isPickAnyCpn) {
                    if (didFind) {
                        if (cpnItem.IsRequired) {
                            reqAnyCnt++;
                        } else {
                            pickAnyCnt++;
                        }                       
                    } else {
                        if ((cpnItem.IsRequired && theCpn.RequireAnyCnt == 0) || (!cpnItem.IsRequired && theCpn.PickAnyCnt == 0)) {
                            return false;
                        }
                        if (cpnIdx >= 0) {
                            ro.app.Store.Menu.Cpns[cpnIdx].Items.splice(i, 1);
                        }                        
                    }
                } else {
                    if (!didFind) {
                        return false;
                    }
                }
            }
            if (isPickAnyCpn) {
                if (pickAnyCnt >= theCpn.PickAnyCnt && reqAnyCnt >= theCpn.RequireAnyCnt) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return true;    
    };
	exports.isCpnConfiguredProperly = isCpnConfiguredProperly;