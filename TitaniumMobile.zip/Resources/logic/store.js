var storeUtils = function () {
      var getGroup = function(){

      };
    return {
    	 getGroup: getGroup
    };
}();