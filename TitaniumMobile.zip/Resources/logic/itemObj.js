var ITEMOBJ = function(){
	var itemobj = function(ro){
		
		var itemObj;
		var returnObj = {};
        var itemSelected, Menu, group;
        var StyleIndex;
        var SizeName;
		
		returnObj.InitializeItemObj = function(){
			// set ItemObj
			////Ti.API.debug('Menu: ' + JSON.stringify(Menu));
			////Ti.API.debug('group: ' + JSON.stringify(group));
			////Ti.API.debug('itemSelected: ' + JSON.stringify(itemSelected));
			if(!Menu){
				Menu = ro.app.Store.Menu;
				////Ti.API.debug('insideMenu: ' + JSON.stringify(Menu));
			}
			if(!group){
				group = ro.app.group;
				////Ti.API.debug('insidegroup: ' + JSON.stringify(group));
			}
			if(!itemSelected){
				itemSelected = ro.app.itemSelected;
				////Ti.API.debug('insideitemSelected: ' + JSON.stringify(itemSelected));
			}
		
			itemObj={};
            Init(itemSelected);			
		};

        function Init(item) {
            itemObj.Menu = Menu.Name;
            itemObj.GroupName = group.Name;
            itemObj.Name = item.Name;
            itemObj.RcptName = item.ReceiptName;
            itemObj.OrigPrice = 0;
            itemObj.KtchName = item.KitchenName;
            itemObj.Qty = 1;
            itemObj.TaxType = item.TaxType;
            itemObj.DlvReminder = item.DlvReminder;
            itemObj.NoDisc = item.NoDisc;
            itemObj.KtchPrtCat = item.KtchPrtCat;
            itemObj.ReportGrp = item.ReportGrp;
            itemObj.PSModCnt = 0;
            itemObj.SplitNum = 0;
            itemObj.CpnApplied = 0;
            if (item.PreMods) {
                itemObj.PreMods = item.PreMods;
            }
            if (group.AllowStdMods) {
                if (item.UseStdMods) {
                    itemObj.UseStdMods = true;
                    if (item.PreMods) {
                        for (var i = 0; i < item.PreMods.length; i++) {
                            if (item.PreMods[i].NoStdMod) {
                                itemObj.PSModCnt += 1;
                            }
                        }
                    }
                }
            }

            itemObj.Seq = item.hasOwnProperty("Seq") ? item.Seq : item.ChngFlg;
            itemObj.GrpSeq = group.PrintSeq;
            itemObj.HasReqMods = item.HasReqMods;
            itemObj.SecondItemApplies = item.SecondItemApplies;
            itemObj.DisplayPS = item.DisplayPS;
            if (item.RedPrint) {
                itemObj.RedPrint = true;
            }
        }        

		function SetTierPrice(price0,price1,price2){
			itemObj.OrigPrice = price0;
			itemObj.ActivePrice = itemObj.OrigPrice;
			if (itemObj.SecondItemApplies){
				itemObj.Orig2ndPrice = price1;
				itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
				itemObj.Orig3rdPrice = price2;
				itemObj.Active3rdPrice = itemObj.Orig3rdPrice;
			}
		}
		
		function SetTierPrice(size,tierSzCol){
			for (var i=0;i<tierSzCol.length;i++){
				if (tierSzCol[i].Size == size){
					itemObj.OrigPrice = tierSzCol[i].Price;
					itemObj.ActivePrice = itemObj.OrigPrice;
		
					if (itemObj.SecondItemApplies){
						itemObj.Orig2ndPrice = tierSzCol[i].SecondItemPrice;
						itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
						itemObj.Orig3rdPrice = tierSzCol[i].ThirdItemPrice;
						itemObj.Active3rdPrice = itemObj.Orig3rdPrice;
					}
					break;
				}
			}
		}        

        returnObj.getSize = function () {
            return SizeName;
        };

        returnObj.ResetItem = function (itm) {// this is used for Suggestive sell of items
            Ti.API.info("old Item from the suggSeller: " + JSON.stringify(itemObj));
            Ti.API.info("new item: " + JSON.stringify(itm));
            var oldPreMods;
            if (itemObj && itemObj.PreMods && itemObj.PreMods.length) {
                oldPreMods = itemObj.PreMods;
            }                      

            Init(itm);
            itemSelected.AvailableSizes = itm.AvailableSizes;            
            //clearing old mods which might be in the preMods of the new item
            if (itemObj && itemObj.Mods && itemObj.Mods.length && itm && itm.PreMods && itm.PreMods.length) {
                for (var i = itemObj.Mods.length - 1; i >= 0; i--) {
                    for (var j = 0; j < itm.PreMods.length; j++) {
                        if (itemObj.Mods[i].Name == itm.PreMods[j].Name && itemObj.Mods[i].Qty === 1 && !itemObj.Mods[i].IsLite) {
                            itemObj.Mods.splice(i, 1);
                            break;
                        }
                    }
                }
            }
            //adding old premods which might not be in the new items premods
            if (oldPreMods) {
                for (var i = 0; i < oldPreMods.length; i++) {                    
                    var found = false;
                    if (itemObj.PreMods && itemObj.PreMods.length) {
                        //Checking if the preMods are in Mods array which happens in case of any changes to preMods, need to preserve those changes in the new item and not reset it
                        if (itemObj.Mods && itemObj.Mods.length) {
                            for (var k = 0; k < itemObj.Mods.length; k++) {
                                if (oldPreMods[i].Name == itemObj.Mods[k].Name) {
                                    found = true;
                                    break;
                                }
                            }
                        }
                        if (!found) {
                            for (var j = 0; j < itemObj.PreMods.length; j++) {
                                if (oldPreMods[i].Name == itemObj.PreMods[j].Name) {
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (!found) {
                        //Should we really add this preMod
                        var reallyFound = true;
                        if (itemObj && itemObj.NoMods && itemObj.NoMods.length) {
                            // Now lets first clean the oldPreMods to exclude the NoMods
                            for (var x = 0; x < itemObj.NoMods.length; x++) {                                
                                if (itemObj.NoMods[x].Name == oldPreMods[i].Name) {
                                    itemObj.NoMods.splice(x, 1);
                                    reallyFound = false;
                                    break;
                                }
                            }
                        }
                        if (reallyFound) {
                            if (!itemObj.Mods) itemObj.Mods = [];
                            returnObj.setMods(oldPreMods[i].Name, 0, false, 1);
                        }                        
                    }
                    
                }
            }
            //now we need to clear the Excluded Mods from the new items mods list
            if (itemObj && itemObj.Mods && itemObj.Mods.length && itm && itm.ExcldMods && itm.ExcldMods.length) {
                for (var i = itemObj.Mods.length - 1; i >= 0; i--) {
                    for (var j = 0; j < itm.ExcldMods.length; j++) {
                        if (itemObj.Mods[i].Name == itm.ExcldMods[j]) {
                            itemObj.Mods.splice(i, 1);
                            break;
                        }
                    }
                }
            }
            if (StyleIndex) returnObj.setStyles(StyleIndex);
            if (SizeName) returnObj.setSizes(SizeName);            
        };

		returnObj.setSizes = function(name){
            Ti.API.info('setSizes() - ' + name);
            SizeName = name;
			var index;
			for (var i=0; i<itemSelected.AvailableSizes.length;i++){
				if (itemSelected.AvailableSizes[i].Name == name){
					index = i;
					break;
				}
            }            
			itemObj.Size = itemSelected.AvailableSizes[index].Name;
			itemObj.SizeRcptName = itemSelected.AvailableSizes[index].ReceiptName;
			itemObj.SizeKtchName = itemSelected.AvailableSizes[index].KitchenName;
		
			//************** BWW **************************
			if (itemSelected.HasProdItm){
				itemObj.KDSProdItmName = itemSelected.ProdItmName;
				if (!isNaN(itemSelected.AvailableSizes[index].ProdItmCnt)){
					itemObj.KDSProdItmCnt = itemSelected.AvailableSizes[index].ProdItmCnt;
				}
			}
			if (itemSelected.HasPrepTime && !isNaN(itemSelected.AvailableSizes[index].PrepTimeSecs)){
				itemObj.KDSPrepTimeSecs = itemSelected.AvailableSizes[index].PrepTimeSecs;
			}
			//**********************************************
		
			if (group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx>0){
				switch (Ti.App.OrderObj.OrdTypePriceIdx){
					case 1:
						itemObj.OrigPrice = itemSelected.AvailableSizes[index].OrdTypePrice1;
						break;
					case 2:
						itemObj.OrigPrice = itemSelected.AvailableSizes[index].OrdTypePrice2;
						break;
				}
			}
			else{
				itemObj.OrigPrice = itemSelected.AvailableSizes[index].Price;
				//Ti.API.debug('itemObj.OrigPrice: ' + itemObj.OrigPrice);
			}
		
			itemObj.ActivePrice = itemObj.OrigPrice;
			itemObj.Orig2ndPrice = itemSelected.AvailableSizes[index].SecondItemPrice;
			itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
			itemObj.PairPrice = itemSelected.AvailableSizes[index].PairPrice;
			itemObj.ModValue = itemSelected.AvailableSizes[index].ModValue;
			itemObj.Mod2ndValue = itemSelected.AvailableSizes[index].Mod2ndValue;
            itemObj.SzSeq = itemSelected.AvailableSizes[index].hasOwnProperty("SzSeq") ? item.Seq : index+1;
		
			if (group.UseTieredPricing){
				switch (Ti.App.OrderObj.OrdTypePriceIdx){
					case 0:
						SetTierPrice(itemObj.Size,itemSelected.TierObj.OT0Sizes);
						break;
					case 1:
						SetTierPrice(itemObj.Size,itemSelected.TierObj.OT1Sizes);
						break;
					case 2:
						SetTierPrice(itemObj.Size,itemSelected.TierObj.OT2Sizes);
						break;
				}
			}
			//Ti.API.debug('itemObj-setSizes(): ' + JSON.stringify(itemObj));
		
		};
		
		returnObj.setNoSizes = function(){
			/*if(!Menu){
				var Menu = ro.app.Store.Menu;
			}*/
			if(!group){
				var group = ro.app.group;
			}
			if(!itemSelected){
				var itemSelected = ro.app.itemSelected;
			}
			itemObj.Size ='None';
			itemObj.SzSeq = 0;
			itemObj.PairPrice = itemSelected.PairPrice;
			itemObj.Mod2ndValue = itemSelected.Mod2ndValue;
			itemObj.ModValue = itemSelected.ModValue;
		
			switch (group.UseTieredPricing){
				case true:
					switch (Ti.App.OrderObj.OrdTypePriceIdx){
						case 0:
							SetTierPrice(itemSelected.TierObj.OT0Price,itemSelected.TierObj.OT0Second,itemSelected.TierObj.OT0Third);
							break;
						case 1:
							SetTierPrice(itemSelected.TierObj.OT1Price,itemSelected.TierObj.OT1Second,itemSelected.TierObj.OT1Third);
							break;
						case 2:
							SetTierPrice(itemSelected.TierObj.OT2Price,itemSelected.TierObj.OT2Second,itemSelected.TierObj.OT2Third);
							break;
					}
					break;
				case false:
					if (group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx>0){
						switch (Ti.App.OrderObj.OrdTypePriceIdx){
							case 1:
								itemObj.OrigPrice = itemSelected.OrdTypePrice1;
								break;
							case 2:
								itemObj.OrigPrice = itemSelected.OrdTypePrice2;
								break;
		
						}
					}
					else{
						itemObj.OrigPrice = itemSelected.Price;
					}
					itemObj.ActivePrice = itemObj.OrigPrice;
					itemObj.Orig2ndPrice = itemSelected.SecondItemPrice;
					itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
			}
			//************** BWW **************************
			if (itemSelected.HasProdItm){
				itemObj.KDSProdItmName = itemSelected.ProdItmName;
				if (!isNaN(itemSelected.ProdItmCnt)){
					itemObj.KDSProdItmCnt = itemSelected.ProdItmCnt;
				}
			}
			if (itemSelected.HasPrepTime && !isNaN(itemSelected.PrepTimeSecs)){
				itemObj.KDSPrepTimeSecs = itemSelected.PrepTimeSecs;
			}
			//**********************************************
		
		};
		returnObj.unsetSizes = function(){
			/*itemObj.Size
			itemObj.SizeRcptName
			itemObj.SizeKtchName
			itemObj.OrigPrice
			itemObj.ActivePrice
			itemObj.Orig2ndPrice
			itemObj.Active2ndPrice
			itemObj.Orig3rdPrice
			itemObj.Active3rdPrice
		
			itemObj.PairPrice
			itemObj.ModValue
			itemObj.Mod2ndValue
			itemObj.SzSeq*/
		
			var propsCol = ['Size', 'SizeRcptName', 'SizeKtchName', 'OrigPrice', 'ActivePrice', 'Orig2ndPrice', 'Active2ndPrice', 'Orig3rdPrice', 'Active3rdPrice', 'PairPrice', 'ModValue', 'Mod2ndValue', 'SzSeq'];
			ro.utils.removeObjProp(itemObj, propsCol);
		
		};
		
		returnObj.setStyles = function(index){
            Ti.API.debug('setStyles(' + index + '): ');
            StyleIndex = index;
			itemObj.Style = group.Styles[index].Name;
			itemObj.StyleRcptName = group.Styles[index].ReceiptName;
			itemObj.StyleKtchName = group.Styles[index].KitchenName;
			if (itemSelected.HasSizes){
				//Ti.API.debug('itemSelected.HasSizes: ');
				for (var i=0;i<group.Styles[index].Sizes.length;i++){
					if (group.Styles[index].Sizes[i].Name==itemObj.Size){
						itemObj.OrigPrice += group.Styles[index].Sizes[i].Price;
						itemObj.StylePrice = group.Styles[index].Sizes[i].Price;
						itemObj.ActivePrice = itemObj.OrigPrice;
						itemObj.Orig2ndPrice += group.Styles[index].Sizes[i].SecondItemPrice;
						itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
						if(group.UseTieredPricing && itemObj.SecondItemApplies && group.SecondStyle){
							itemObj.Orig2ndPrice+= group.Styles[index].Sizes[i].Price;
							itemObj.Orig3rdPrice+= group.Styles[index].Sizes[i].Price;
						}
						break;
					}
				}
			}
			else{
				itemObj.OrigPrice += group.Styles[index].Price;
				itemObj.StylePrice = group.Styles[index].Price;
				itemObj.ActivePrice = itemObj.OrigPrice;
				if(group.UseTieredPricing && itemObj.SecondItemApplies && group.SecondStyle){
					itemObj.Orig2ndPrice+= group.Styles[index].Price;
					itemObj.Orig3rdPrice+= group.Styles[index].Price;
				}
			}
			//Ti.API.debug('itemObj-setStyles(): ' + JSON.stringify(itemObj));
		};
		returnObj.unsetStyles = function(index){
				//Ti.API.debug('UNSETStyles('+index+'): ');
			/*itemObj.Style = group.Styles[index].Name;
			itemObj.StyleRcptName = group.Styles[index].ReceiptName;
			itemObj.StyleKtchName = group.Styles[index].KitchenName;
			itemObj.OrigPrice += group.Styles[index].Sizes[i].Price;
			itemObj.ActivePrice = itemObj.OrigPrice;
			itemObj.Orig2ndPrice += group.Styles[index].Sizes[i].SecondItemPrice;
			itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
			itemObj.Orig3rdPrice+= group.Styles[index].Sizes[i].Price;*/
		
			var propsCol = ['Style', 'StyleRcptName', 'StyleKtchName', 'OrigPrice', 'ActivePrice', 'Orig2ndPrice', 'Active2ndPrice', 'Orig3rdPrice'];
			ro.utils.removeObjProp(itemObj, propsCol);
		};
		
		function RemoveMod(mod){
			var modLngth = 0;
			/*if(itemObj.Mods){
				modLngth = itemObj.Mods.length;
			}*/
			if(!itemObj.Mods){
				itemObj.Mods = [];
			}
			for (var i=0;i<itemObj.Mods.length;i++){
				if (itemObj.Mods[i].Name == mod){
					//Ti.API.debug('itemObj.Mods[i]: ' + JSON.stringify(itemObj.Mods[i]));
					itemObj.Mods.splice(i,1);
					break;
				}
			}
		
		}
		
		function RemoveNoMod(mod){
			if(!itemObj.NoMods){
				itemObj.NoMods = [];
			}
			for (var i=0;i<itemObj.NoMods.length;i++){
				if (itemObj.NoMods[i].Name==mod){
					itemObj.NoMods.splice(i,1);
					break;
				}
			}
		}
		
		function RemoveReqMod(mod){
			for (var i=0;i<itemObj.ReqMods.length;i++){
				if (itemObj.ReqMods[i].Name==mod){
					itemObj.ReqMods.splice(i,1);
					break;
				}
			}
		}
		
		function getNoSubCredit(name){
			var rtnBool = false;
			if (itemSelected.PreMods) {
				for (var i = 0; i < itemSelected.PreMods.length; i++) {
					if (itemSelected.PreMods[i].Name == name) {
						rtnBool = true;
						break;
					}
				}
			}
			return rtnBool;
		}
		
		function getMod(mod){
			var rtnMod;
			for (var i=0;i<group.Mods.length;i++){
				if (group.Mods[i].Name==mod){
					rtnMod = group.Mods[i];
					break;
				}
			}
			if (itemSelected && itemSelected.PreMods && itemSelected.PreMods.length>0){
				for (var i=0; i< itemSelected.PreMods.length; i++){
					if (itemSelected.PreMods[i].Name == mod){
						rtnMod.NoSubCredit = itemSelected.PreMods[i].NoSubCredit;
						break;
					}
				}
			}
			return rtnMod;
		}
		
		returnObj.setMods = function(name,index,isPreselected,qty){
            Ti.API.info("setMod: " + name);
			if(!itemObj.Mods || !itemObj.Mods.length){
				itemObj.Mods = [];
			}
			if(!itemObj.NoMods || !itemObj.NoMods.length){
				itemObj.NoMods = [];
			}
			
			//Ti.API.info('Name: ' + name + ' - HalfOptn: ' + index + ' - IsPreselected: ' + isPreselected + ' - Qty: ' + qty);
			var ordModObj={};
			var noModObj = {};
			var selMod = getMod(name);
			ordModObj.Name = selMod.Name;
			ordModObj.RcptName = selMod.ReceiptName;
			ordModObj.NoSubCredit = selMod.NoSubCredit;
			ordModObj.HalfStatus = index;
			ordModObj.IsPreSel = isPreselected;
			ordModObj.OrigPrice=selMod.Price;
			ordModObj.Orig2ndPrice = selMod.SecondItemPrice;
			ordModObj.Qty=!qty ? 1 : qty;
			ordModObj.NoKtchDisp = (selMod.NoKtchDisp && selMod.NoKtchDisp==true) ? selMod.NoKtchDisp : false;
			ordModObj.IsLite=!qty ? true : false;            
		
			if(group.AllowHalf){
				if(isPreselected){
					RemoveMod(name);
					RemoveNoMod(name);
					//if(qty==2){
					if(qty > 1 || qty == 0){
						itemObj.Mods.push(ordModObj);
					}
		
					if(index >0 && index <3){
						noModObj.Name = selMod.Name;
						noModObj.RcptName = selMod.ReceiptName;
						noModObj.NoSubCredit = ordModObj.NoSubCredit;
						noModObj.IsPreSel = isPreselected;
						noModObj.OrigPrice=selMod.Price;
						noModObj.Orig2ndPrice = selMod.SecondItemPrice;
						noModObj.Qty=1;
						noModObj.HalfStatus=(index==1?2:1);
						Ti.API.debug('noModObj: ' + JSON.stringify(noModObj));
						itemObj.NoMods.push(noModObj);
					}
		
					if(index==3){
						ordModObj.Qty=1;
						ordModObj.HalfStatus = 0;
						itemObj.NoMods.push(ordModObj);
					}
				}
				else{
					RemoveMod(name);
					if(index !=3){
						itemObj.Mods.push(ordModObj);
					}
				}
			}
			else{
				if(isPreselected){
					RemoveMod(name);
					RemoveNoMod(name);
					if(qty>1 || qty==0){
					//if(qty==2){
						itemObj.Mods.push(ordModObj);
					}
					if(index==1){
						ordModObj.Qty=1;
						ordModObj.HalfStatus=0;
						itemObj.NoMods.push(ordModObj);
					}
				}
				else{
					RemoveMod(name);
					if(index!=1){
						itemObj.Mods.push(ordModObj);
					}
				}
			}
			//Ti.API.info('itemObj-setMods()-AFTER: ' + JSON.stringify(itemObj));
		};
		
		returnObj.ModPropFill = function(ModCol){
		
			for (var i=0;i<ModCol.length;i++){
				var selMod = getMod(ModCol[i].Name);
				ModCol[i].TaxType = selMod.TaxType;
				ModCol[i].KtchName = selMod.KitchenName;
				ModCol[i].DlvReminder = selMod.DlvReminder;
				ModCol[i].ModCatKey = selMod.ModCatKey;
				ModCol[i].PriceApplies = selMod.PriceApplies;
				ModCol[i].ReportGrp = selMod.ReportGrp;
				ModCol[i].NoStdMod = selMod.NoStdMod;
				ModCol[i].seq = selMod.PosPage;
		
				if (itemObj.Size != 'None'){
					for (var j=0;j<selMod.Sizes.length;j++){
						if (selMod.Sizes[j].Name == itemObj.Size) {
							ModCol[i].OrigPrice = selMod.Sizes[j].Price;
							ModCol[i].Orig2ndPrice = selMod.Sizes[j].SecondItemPrice;
							ModCol[i].HalfPrice = selMod.Sizes[j].HalfPrice;
							break;
						}
					}
				}
				else{
					ModCol[i].OrigPrice=selMod.Price;
					ModCol[i].Orig2ndPrice = selMod.SecondItemPrice;
					ModCol[i].HalfPrice = selMod.HalfPrice;
				}
				if (ModCol[i].RcptName==''){
					ModCol.splice(i,1);
				}
			}
		};
		
		function setReqMods(name,index,isPreselected,qty){
			var ordModObj={};
			var noModObj = {};
			var selMod = getMod(name);
			ordModObj.Name = selMod.Name;
			ordModObj.RcptName = selMod.ReceiptName;
			ordModObj.NoSubCredit = selMod.NoSubCredit;
			ordModObj.HalfStatus = index;
			ordModObj.IsPreSel = isPreselected;
			ordModObj.Qty=qty;
			if (group.AllowHalf){
					if (isPreselected){
						RemoveMod(name);
						RemoveNoMod(name);
						if (qty==2){
							itemObj.Mods.push(ordModObj);
						}
						if (index >0 && index <3){
							noModObj.Name = selMod.Name;
							noModObj.RcptName = selMod.ReceiptName;
							noModObj.NoSubCredit = ordModObj.NoSubCredit;
							noModObj.IsPreSel = isPreselected;
							noModObj.OrigPrice=selMod.Price;
							noModObj.Orig2ndPrice = selMod.SecondItemPrice;
							noModObj.Qty=1;
							noModObj.HalfStatus=(index==1?2:1);
							itemObj.NoMods.push(noModObj);
						}
						if (index==3){
							ordModObj.Qty=1;
							itemObj.NoMods.push(ordModObj);
						}
					}
					else{
						RemoveMod(name);
						if (index !=3){
							itemObj.Mods.push(ordModObj);
						}
		
					}
				}
				else{
					if (isPreselected){
						RemoveMod(name);
						RemoveNoMod(name);
						if (qty==2){
							itemObj.Mods.push(ordModObj);
						}
						if (index==1){
							ordModObj.Qty=1;
							itemObj.NoMods.push(ordModObj);
						}
					}
					else{
						RemoveMod(name);
						if(index!=1){
							itemObj.Mods.push(ordModObj);
						}
					}
				}
		}
		
		returnObj.setPrefs = function(name,index){
			try{
				if(!itemObj.PrfMbrs || !itemObj.PrfMbrs.length) itemObj.PrfMbrs = [];
				//Ti.API.debug('name: '+ name);
				//Ti.API.debug('index: '+ index);
				/*if(!itemSelected){
					Ti.API.debug('ro.app.itemSelected: ' + JSON.stringify(ro.app.itemSelected));
					itemSelected = ro.app.itemSelected;
				}*/
		
				var ordPrfMbrObj={};
				var selectedPref;
				var i;
				var itemPrfMbrLength = (itemSelected && itemSelected.Prefs && itemSelected.Prefs[index].PrefMbrs) ? itemSelected.Prefs[index].PrefMbrs.length : 0;
				for(i=0; i<itemPrfMbrLength; i++){
					if(itemSelected.Prefs[index].PrefMbrs[i].Name == name){
						selectedPref = itemSelected.Prefs[index].PrefMbrs[i];
						break;
					}
				}
		        ordPrfMbrObj.PrefIndex = index;
				ordPrfMbrObj.Name = selectedPref.Name;
				ordPrfMbrObj.RcptName = selectedPref.ReceiptName;
				ordPrfMbrObj.KtchName = selectedPref.KitchenName;
				ordPrfMbrObj.ReportGrp = selectedPref.ReportGrp;
				ordPrfMbrObj.OrigPrice = selectedPref.Price;
				ordPrfMbrObj.ActivePrice = ordPrfMbrObj.OrigPrice;
				ordPrfMbrObj.PrefName = itemSelected.Prefs[index].Name;
				ordPrfMbrObj.IsDefault = (itemSelected.Prefs[index].DefaultMember && (itemSelected.Prefs[index].DefaultMember == selectedPref.Name)) ? true : false;
				if (Menu.hasOwnProperty("ShowDefaultPref")) {
					ordPrfMbrObj.ShowDefault = Menu.ShowDefaultPref ? true : false;
                }
				ordPrfMbrObj.PrefSource = 1;
				ordPrfMbrObj.TaxType = selectedPref.TaxType;
				ordPrfMbrObj.Mods = [];
				ordPrfMbrObj.NoMods = [];
				
				ordPrfMbrObj.UseMods = selectedPref.UseMods;
				ordPrfMbrObj.ModGrpName = selectedPref.ModGrpName;
				ordPrfMbrObj.UsePSMods = selectedPref.UsePSMods;
				ordPrfMbrObj.PSItmName = selectedPref.PSItmName;
				ordPrfMbrObj.ModSize = selectedPref.ModSize && selectedPref.ModSize.length ? selectedPref.ModSize : "None";
		
				//******************* BWW *******************
				if(selectedPref.RedPrint){
					ordPrfMbrObj.RedPrint=true;
				}
				if(selectedPref.HasProdItm){
					ordPrfMbrObj.KDSProdItmName = selectedPref.ProdItmName;
					if(!isNaN(selectedPref.ProdItmCnt)){
						ordPrfMbrObj.KDSProdItmCnt = selectedPref.ProdItmCnt;
					}
				}
				if(selectedPref.HasPrepTime){
					if(!isNaN(selectedPref.PrepTimeSecs)){
						ordPrfMbrObj.KDSPrepTimeSecs = selectedPref.PrepTimeSecs;
					}
				}
				if(selectedPref.NoQtyPrice){
					ordPrfMbrObj.NoQtyPrice = true;
				}
				if(selectedPref.NoKtchDisp){
					ordPrfMbrObj.NoKtchDisp = true;
				}
				if(selectedPref.UniqueKtchPrtCat){
					ordPrfMbrObj.UniqueKtchPrtCat = selectedPref.UniqueKtchPrtCat;
				}
				if(selectedPref.KtchPrtCat){
					ordPrfMbrObj.KtchPrtCat = selectedPref.KtchPrtCat;
				}
				//*******************************************
		
				var itemObjPrfMbrLngth = (itemObj && itemObj.PrfMbrs) ? itemObj.PrfMbrs.length : 0;
				//for(i=0; i<itemObj.PrfMbrs.length; i++){
				for(i=0; i<itemObjPrfMbrLngth; i++){
					if(itemObj.PrfMbrs[i].PrefName == ordPrfMbrObj.PrefName){
						itemObj.PrfMbrs.splice(i,1);
						break;
					}
				}
				itemObj.PrfMbrs.push(ordPrfMbrObj);
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('itemObj.js-setPrefs()-Exception: ' + ex); }
			}
		};
		returnObj.unsetPrefs = function(index){
			var prefLen = itemObj.PrfMbrs && itemObj.PrfMbrs.length ? itemObj.PrfMbrs.length : 0;
			for(var i=0; i<prefLen; i++){
				for(var j=0; j<itemSelected.Prefs[index].PrefMbrs.length; j++){
					if(itemObj.PrfMbrs[i].Name === itemSelected.Prefs[index].PrefMbrs[j].Name){
						itemObj.PrfMbrs.splice(i, 1);
						return;
					}
				}
			}
		};
		returnObj.chkPrefs = function(){
			try{
				var returnObj = {
					foundError:false,
					Message:""
				};
				var prefFound = false;
				var prefString = '';
				var itmSelPrefLngth = itemSelected.Prefs?itemSelected.Prefs.length:0;
			   var itmObjPrfmbrsLngth, returnBool = 0;
				for(var i=0; i<itmSelPrefLngth; i++){
					prefFound = false;
					if(itemObj.PrfMbrs){
					   itmObjPrfmbrsLngth = itemObj.PrfMbrs?itemObj.PrfMbrs.length:0;
						for(var j=0; j<itmObjPrfmbrsLngth; j++){
							if(itemSelected.Prefs[i].Name == itemObj.PrfMbrs[j].PrefName){
								prefFound = true;
								break;
							}
						}
					}
					
					if(!prefFound){
						prefString += 'Please select ' + itemSelected.Prefs[i].Name + '\n';
						returnBool++;
					}
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('itemObj.js-chkPrefs()-Exception: ' + ex); }
			}
			finally{
				if(returnBool){
					returnObj.foundError = true;
					returnObj.Message = prefString;
				}
				return returnObj;
			}
		};
		
		function RemovePrefMod(mod, pIdx){
			
			for (var i=0;i<itemObj.PrfMbrs[pIdx].Mods.length;i++){
				if (itemObj.PrfMbrs[pIdx].Mods[i].Name == mod){
					itemObj.PrfMbrs[pIdx].Mods.splice(i,1);
					break;
				}
			}
			
			
		}
		
		function RemovePrefNoMod(mod, pIdx){
			for (var i=0;i<itemObj.PrfMbrs[pIdx].NoMods.length;i++){
				if (itemObj.PrfMbrs[pIdx].NoMods[i].Name==mod){
					itemObj.PrfMbrs[pIdx].NoMods.splice(i,1);
					break;
				}
			}
		}
		function getPrefMod(mod, prefMods){
			var rtnMod;
			for (var i=0;i<prefMods.length;i++){
				if (prefMods[i].Name==mod){
					rtnMod = prefMods[i];
					break;
				}
			}
			//Ti.API.debug('rtnMod: ' + rtnMod);
			return rtnMod;
		}
		returnObj.setPrefMods = function(name,index,isPreselected,qty, prefModGrp, prefModName){
			   var prefModIdx, prefModSize, ModValue = 0;
			   for(var i=0, iMax=itemObj.PrfMbrs && itemObj.PrfMbrs.length ? itemObj.PrfMbrs.length : 0; i<iMax; i++){
			   	  if(itemObj.PrfMbrs[i].Name == prefModName){
					 prefModSize = itemObj.PrfMbrs[i].ModSize ? itemObj.PrfMbrs[i].ModSize : null;
			   	  	 prefModIdx = i;						  
			   	  	 break;
			   	  }
			   }
			   //Setting ModValue for PrefMods
			   if(itemObj.PrfMbrs[prefModIdx].UseMods &&
					itemObj.PrfMbrs[prefModIdx].ModGrpName &&
					itemObj.PrfMbrs[prefModIdx].ModGrpName != '' &&
					itemObj.PrfMbrs[prefModIdx].UsePSMods && 
					itemObj.PrfMbrs[prefModIdx].PSItmName && 
					itemObj.PrfMbrs[prefModIdx].PSItmName != '' &&
					prefModSize && prefModSize.toLowerCase() != 'none'){
						var gridx = ro.utils.getMatchingIdx(itemObj.PrfMbrs[prefModIdx].ModGrpName, ro.app.Store.Menu.Groups, 'Name');				
						var iidx = ro.utils.getMatchingIdx(itemObj.PrfMbrs[prefModIdx].PSItmName, ro.app.Store.Menu.Groups[gridx].Items, 'Name');
						if(ro.app.Store.Menu.Groups[gridx].Items[iidx].AvailableSizes && ro.app.Store.Menu.Groups[gridx].Items[iidx].AvailableSizes.length){
							var sidx = ro.utils.getMatchingIdx(prefModSize, ro.app.Store.Menu.Groups[gridx].Items[iidx].AvailableSizes, 'Name');						
							ModValue = ro.app.Store.Menu.Groups[gridx].Items[iidx].AvailableSizes[sidx].ModValue;
						}						
				}				
				itemObj.PrfMbrs[prefModIdx].ModValue = ModValue;
			   //End Code for setting ModValue;
			   var prefMods = prefModGrp.Mods;
			   // alert(name+ ' '+ index+ ' '+ qty);
				var ordModObj={};
				var noModObj = {};
				var selMod = getPrefMod(name, prefMods);
				ordModObj.Name = selMod.Name;
				ordModObj.RcptName = selMod.ReceiptName;
				ordModObj.NoSubCredit = selMod.NoSubCredit;//getNoSubCredit(name);
				ordModObj.HalfStatus = index;
				ordModObj.IsPreSel = isPreselected;
				ordModObj.OrigPrice=selMod.Price;
				ordModObj.Orig2ndPrice = selMod.SecondItemPrice;
				ordModObj.Qty=qty;
				ordModObj.NoKtchDisp = (selMod.NoKtchDisp && selMod.NoKtchDisp==true) ? selMod.NoKtchDisp : false;
				ordModObj.IsLite=!qty ? true : false;
				
				//for (var i=0;i<ModCol.length;i++){
                    //var selMod = getMod(ModCol[i].Name);
                    ordModObj.TaxType = selMod.TaxType;
                    ordModObj.KtchName = selMod.KitchenName;
                    ordModObj.DlvReminder = selMod.DlvReminder;
                    ordModObj.ModCatKey = selMod.ModCatKey;
                    ordModObj.PriceApplies = selMod.PriceApplies;
                    ordModObj.ReportGrp = selMod.ReportGrp;
                    ordModObj.NoStdMod = selMod.NoStdMod;
                    ordModObj.seq = selMod.PosPage;
                    if (prefModSize && prefModSize != 'None'){
                        for (var j=0; j<selMod.Sizes.length; j++){
                            if (selMod.Sizes[j].Name == prefModSize) {
                                ordModObj.OrigPrice = selMod.Sizes[j].Price;
                                ordModObj.Orig2ndPrice = selMod.Sizes[j].SecondItemPrice;
                                ordModObj.HalfPrice = selMod.Sizes[j].HalfPrice;
                                break;
                            }
                        }
                    }
                    else{
                        ordModObj.OrigPrice=selMod.Price;
                        ordModObj.Orig2ndPrice = selMod.SecondItemPrice;
                        ordModObj.HalfPrice = selMod.HalfPrice;
                    }
                    if (ordModObj.RcptName==''){
                        //ModCol.splice(i,1);
                        return;
                    }
                //}
				//
				
				if (prefModGrp.AllowHalf){
					if (isPreselected){
						//RemoveMod(name);
						RemovePrefMod(name, prefModIdx);
						//RemoveNoMod(name);
						RemovePrefNoMod(name, prefModIdx);
						//if (qty==2){
						if (qty>1 || qty==0){
							//itemObj.Mods.push(ordModObj);
							/*if(!itemObj.PrfMbrs[prefModIdx].Mods){
								itemObj.PrfMbrs[prefModIdx].Mods = [];
							}*/
							itemObj.PrfMbrs[prefModIdx].Mods.push(ordModObj);
						}
					
						if (index >0 && index <3){						
							
							noModObj.Name = selMod.Name;
							noModObj.RcptName = selMod.ReceiptName;
							noModObj.NoSubCredit = ordModObj.NoSubCredit;//selMod.NoSubCredit;
							noModObj.IsPreSel = isPreselected;
							noModObj.OrigPrice=selMod.Price;
							noModObj.Orig2ndPrice = selMod.SecondItemPrice;
							noModObj.Qty=1;
							noModObj.HalfStatus=(index==1?2:1);
							
							//itemObj.NoMods.push(noModObj);
							/*if(!itemObj.PrfMbrs[prefModIdx].NoMods){
								itemObj.PrfMbrs[prefModIdx].NoMods = [];
							}*/
							itemObj.PrfMbrs[prefModIdx].NoMods.push(noModObj);
							//itemObj.NoMods.push(noModObj);
						}
						
						if (index==3){
							ordModObj.Qty=1;
							ordModObj.HalfStatus=0;
							//itemObj.NoMods.push(ordModObj);
							itemObj.PrfMbrs[prefModIdx].NoMods.push(ordModObj);
						}
					}
					else{
						//RemoveMod(name);
						RemovePrefMod(name, prefModIdx);
						if (index !=3){					
							//itemObj.Mods.push(ordModObj);
							itemObj.PrfMbrs[prefModIdx].Mods.push(ordModObj);	
						}
					
					}	
				}
				else{
					if (isPreselected){
						//RemoveMod(name);
						RemovePrefMod(name, prefModIdx);
						//RemoveNoMod(name);
						RemovePrefNoMod(name, prefModIdx);
						//if (qty==2){
						if (qty>1 || qty==0){
							//itemObj.Mods.push(ordModObj);
							itemObj.PrfMbrs[prefModIdx].Mods.push(ordModObj);	
						}
						if (index==1){
							ordModObj.Qty=1;
							ordModObj.HalfStatus=0;
							//itemObj.NoMods.push(ordModObj);
							itemObj.PrfMbrs[prefModIdx].NoMods.push(ordModObj);	
						}
					}
					else{
						//RemoveMod(name);
						RemovePrefMod(name, prefModIdx);
						if(index!=1){
							//itemObj.Mods.push(ordModObj);
							itemObj.PrfMbrs[prefModIdx].Mods.push(ordModObj);
						}
					}
				}
				
		};
		returnObj.getItemObj = function(){
			return itemObj;
		};
		
		ro.itemObj = returnObj;
	};
	return {
		itemobj:itemobj
	};
}();
module.exports = ITEMOBJ;

