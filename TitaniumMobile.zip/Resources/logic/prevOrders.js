var PREVORDERS = function(){
	var prevorders = function(ro){
		ro.prevOrders = function () {
		    var addToCart = function (ord, menu,ordObj) {
		        if (!ord || !ord.LastOrdItemCol || ord.LastOrdItemCol.length === 0) {
		            return false;
		        }
		        if (!menu || !menu.Groups || menu.Groups.length === 0) {
		            return false;
		        }
		        //var test = ordObj;
		        
		        var cnt = ord.LastOrdItemCol.length;
		        if (!ordObj.Items){
		        	ordObj.Items=[];
		        }
		        for (var i = 0; i < ord.LastOrdItemCol.length; i++) {
		            var itemObj = {};
		            if (!isLastOrdItemValid(itemObj, ord.LastOrdItemCol[i], menu,ordObj.OrdTypePriceIdx)) {
		            	return false;
		            }
		            ordObj.Items.push(itemObj);
		            cnt--;
		        }
				if(cnt === 0){
					Ti.App.OrderObj = ordObj;
				}
		        return (cnt===0);
		    },
		    fillItmRcptNames = function(ordCol,menu){
		    	if (!ordCol || ordCol.length === 0){
		    		return;
		    	}
		    	for (var i=0;i<ordCol.length;i++){
		    		if (ordCol[i].LastOrdItemCol && ordCol[i].LastOrdItemCol.length > 0){
		    			for (var j=0;j<ordCol[i].LastOrdItemCol.length;j++){
		
		    			    var group;
		    				 if(menu && menu.Groups){
		    				    group = getGroup(menu.Groups, ordCol[i].LastOrdItemCol[j].GroupName) || 0;
		    				 }
		
		        			 if (!group || group === null) {
		        			 	ordCol[i].LastOrdItemCol[j].RcptName = ordCol[i].LastOrdItemCol[j].ItemName;
		            			continue;
		        			 }
		
		        			 var item;
		        			 if(group && group.Items){
		        			    item = getItem(group.Items, ordCol[i].LastOrdItemCol[j].ItemName) || 0;
		        			 }
		
		        			 if (!item || item === null) {
		        			 	ordCol[i].LastOrdItemCol[j].RcptName = ordCol[i].LastOrdItemCol[j].ItemName;
		            			continue;
		        			 }
		        			ordCol[i].LastOrdItemCol[j].RcptName = item.ReceiptName;
		
		    			}
		    		}
		    	}
		    },
		     months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		    getDateDiffStr = function (dt) {
		        if (dt) {
		            var dt1 = new Date();
		            var diff = Math.abs(dt1 - dt) / 1000 / 60;
		            var hours = diff / 60;
		            var days = hours / 24;
		
		            var monthName = months[dt.getMonth()];
		            var date = dt.getDate();
		            var year = dt.getFullYear();
		
		            if (days >= 365) {
		                return ('on ' + monthName + ' ' + date + ', ' + year);
		            }
		            if (days >= 7) {
		                return ('on ' + monthName + ' ' + date);
		            }
		            if (days >= 2) {
		                return (days + ' days ago');
		            }
		            if (days < 2 && days >= 1) {
		                return 'yesterday';
		            }
		            if (hours >= 2) {
		                return (hours + ' hours ago');
		            }
		            if (hours >= 60) {
		                return 'more than an hour ago';
		            }
		            if (diff >= 5) {
		                return (diff + '  minutes ago');
		            }
		            if (diff >= 1) {
		                return 'a few minutes ago';
		            }
		        }
		        return 'less than a minute ago';
		    },
		    getOrdItemMods = function (Mods) {
		        var res = null;
		        if (Mods && Mods.length > 0) {
		            res = [];
		            for (var i = 0; i < Mods.length; i++) {
		                res.push({
		                    Qty: Mods[i].Qty,
		                    ModName: Mods[i].Name,
		                    HalfStatus: Mods[i].HalfStatus
		                });
		            }
		        }
		        return res;
			},
			getPreMods = function (GrpName, ItemName) {
				var res = null;
				if (ro.app.Store) {
					for (i = 0; i < ro.app.Store.Menu.Groups.length; i++) {
						if (ro.app.Store.Menu.Groups[i].Name == GrpName) {
							for (j = 0; j < ro.app.Store.Menu.Groups[i].Items.length; j++) {
								if (ro.app.Store.Menu.Groups[i].Items[j].Name == ItemName) {
									if (ro.app.Store.Menu.Groups[i].Items[j].PreMods && ro.app.Store.Menu.Groups[i].Items[j].PreMods.length > 0) {
										var Mods = ro.app.Store.Menu.Groups[i].Items[j].PreMods;
										res = [];
										for (var k = 0; k < Mods.length; k++) {
											res.push({
												NoSubCredit: Mods[k].NoSubCredit,
												Name: Mods[k].Name,
											});
										}
									}
									break;
                                }
                            }
							break;
                        }
                    }
				}
				return res;
			},
		    getOrdPrefs = function (prefs) {
		        var res = null;
		        if (prefs && prefs.length > 0) {
		            res = [];
		            for (var i = 0; i < prefs.length; i++) {
		                res.push({
		                    PrfMbrName: prefs[i].Name,
		                    PrefName: prefs[i].PrefName,
		                    PrefSource: prefs[i].PrefSource
		                });
		            }
		        }
		        return res;
		    },
		    getPrevOrd = function (orderObj, ordId, dt, storeId,name, custObj) {
		        var obj = {
		            Ord_ID: ordId,
		            OrdType: orderObj.OrdType,
		            Name: name,
		            TimeStamp: dt,
		            LastOrdItemCol: [],
		            TimeString: getDateDiffStr(dt),
		            Business_ID: storeId,
		            Customer: {}
		        };
		        if(custObj){
		        	obj.Customer = custObj;
		        }
		        for (var i = 0; i < orderObj.Items.length; i++) {
		        	var sz = orderObj.Items[i].Size && orderObj.Items[i].Size.length>0 ?orderObj.Items[i].Size:'None';
		        	var st = orderObj.Items[i].Style && orderObj.Items[i].Style.length>0 ?orderObj.Items[i].Style:'None';
		            obj.LastOrdItemCol.push({
		                Qty: orderObj.Items[i].Qty,
		                GroupName: orderObj.Items[i].GroupName,
		                ItemName: orderObj.Items[i].Name,
		                SizeName: sz,
		                StyleName: st,
		                Mods: getOrdItemMods(orderObj.Items[i].Mods),
		                NoMods: getOrdItemMods(orderObj.Items[i].NoMods),
						PrfMbrs: getOrdPrefs(orderObj.Items[i].PrfMbrs),
						PreMods: getPreMods(orderObj.Items[i].GroupName, orderObj.Items[i].Name)
		            });
		        }
		        return obj;
		    },
		    getGroup = function (Groups, name) {
		        var res = null;
		        for (var i = 0; i < Groups.length; i++) {
		            if (Groups[i].Name === name) {
		                res = Groups[i];
		                break;
		            }
		        }
		        return res;
		    },
		    getItem = function (Items, itmName) {
		        var res = null;
		        for (var i = 0; i < Items.length; i++) {
		            if (Items[i].Name === itmName) {
		                res = Items[i];
		                break;
		            }
		        }
		        return res;
		    },
		    isLastOrdItemValid = function (itemObj, lastOrdItem, menu, ordTypePriceIdx) {
		        if (!lastOrdItem) {
		            return false;
		        }
		        var group = getGroup(menu.Groups, lastOrdItem.GroupName);
		        if (!group || group === null) {
		            return false;
		        }
		        var item = getItem(group.Items, lastOrdItem.ItemName);
		        if (!item || item === null) {
		            return false;
				}
				
				//Checking if particular combination is Out Of Stock				
				if (lastOrdItem.StyleName && lastOrdItem.SizeName) {
					var menuUtils = require('logic/menuUtils');
					if (menuUtils.isSizeOutOfStock(group, item.Name, lastOrdItem.StyleName, lastOrdItem.SizeName)) {
						return false;
					}
				}
		
		        initItemObj(itemObj,menu.Name,group,item);
		        return isSizeValid(itemObj,item,lastOrdItem.SizeName, group.UseTieredPricing, group.UseOrdTypePricing, ordTypePriceIdx) &&
		               isStyleValid(itemObj,group.Styles, lastOrdItem.StyleName, lastOrdItem.SizeName, group.SecondStyle, group.UseTieredPricing) &&
		        	   isReqModsValid(itemObj, group.Mods, item.ReqMods, lastOrdItem.Mods) &&
					   isModsValid(itemObj, group.Mods, lastOrdItem.Mods, item.PreMods) &&
		               isNoModsValid(itemObj, group.Mods, lastOrdItem.NoMods, item.PreMods) &&
		               isPrefsValid(itemObj, item.Prefs, lastOrdItem.PrfMbrs);
		
		    },
		    isSizeValid = function (itemObj, item, size, useTieredPricing, useOrdTypePricing, ordTypePriceIdx) {
		        if ((!item.AvailableSizes || item.AvailableSizes.length === 0) && (!size || size.toLowerCase() === 'none')) {
		            setNoSize(itemObj, item, useTieredPricing, useOrdTypePricing, ordTypePriceIdx);
		            return true;
		        }
		        if ((!item.AvailableSizes || item.AvailableSizes.length === 0) && size && size.toLowerCase() !== 'none') {
		            return false;
		        }
		        if (item.AvailableSizes && item.AvailableSizes.length > 0 && (!size || size.toLowerCase() === 'none')) {
		            return false;
		        }
		        var found = false;
		        for (var i = 0; i < item.AvailableSizes.length; i++) {
		            if (item.AvailableSizes[i].Name === size) {
		                found = true;
		                setSize(itemObj, item, useTieredPricing, useOrdTypePricing, ordTypePriceIdx, i);
		                break;
		            }
		        }
		        return found;
		    },
		    isStyleValid = function (itemObj, Styles, style, size, secondStyle, useTieredPricing) {
		        if ((!Styles || Styles.length === 0) && (!style || style.toLowerCase() === 'none')) {
		            return true;
		        }
		        if ((!Styles || Styles.length === 0) && style && style.toLowerCase() !== 'none') {
		            return false;
		        }
		        if (Styles && Styles.length > 0 && (!style || style.toLowerCase() === 'none')) {
		            return false;
		        }
		        var found = false;				

		        for (var i = 0; i < Styles.length; i++) {
		            if (Styles[i].Name === style) {
		                found = true;
		                if (size && size.toLowerCase() !== 'none') {
		                    var szFound = false;
		                    for (var j = 0; j < Styles[i].Sizes.length; j++) {
		                        if (Styles[i].Sizes[j].Name === size) {
		                            szFound = true;
		                            setStyles(itemObj, Styles[i], true, useTieredPricing, secondStyle);
		                            break;
		                        }
		                    }
		                    found = szFound;
		                }
		                else {
		                    setStyles(itemObj, Styles[i], false, useTieredPricing, secondStyle);
		                }
		                break;
		            }
		        }
		        return found;
		    },
		    isReqModsValid = function (itemObj, menuMods, reqMods, ordMods) {
		        if (!reqMods || reqMods.length === 0) {
		            return true;
		        }
		        if (!ordMods || ordMods.length === 0) {
		            return false;
		        }
		        var cnt = reqMods.length;
		        for (var i = 0; i < reqMods.length; i++) {
		            var found = false;
		            var reqModsKey = !isNaN(reqMods[i].Key)?reqMods[i].Key:reqMods[i];
		            for (var j = 0; j < menuMods.length; j++) {
		                if (menuMods[j].ModCatKey === reqModsKey) {
		                    for (var k = 0; k < ordMods.length; k++) {
		                        if (ordMods[k].ModName === menuMods[j].Name) {
		                            found = true;
		                            break;
		                        }
		                    }
		                }
		                if (found) {
		                    cnt--;
		                    break;
		                }
		            }
		        }
		        return (cnt===0);
				},
			isModsValid = function (itemObj, Mods, ordMods, preMods) {
				if ((!Mods || Mods.length === 0) && ordMods && ordMods.length > 0) {
					return false;
				}
				if (!ordMods || ordMods.length === 0) {
					return true;
				}
				var cnt = ordMods.length;
				for (var i = 0; i < ordMods.length; i++) {
					var found = false;
					var preFound = false;
					if (preMods) {
						for (var k = 0; k < preMods.length; k++) {
							if (preMods[k].Name === ordMods[i].ModName) {
								preFound = true;
								break;
							}
						}
					}
					
					for (var j = 0; j < Mods.length; j++) {
						if (Mods[j].Name === ordMods[i].ModName) {
							found = true;
							setMods(itemObj, Mods[j], ordMods[i], true, preFound);
							cnt--;
							break;
						}
					}
					

					if (!found) {
						break;
					}
				}
				return (cnt === 0);
			},
		    isNoModsValid = function (itemObj, Mods, ordMods, preMods) {
		        if ((!Mods || Mods.length === 0) && ordMods && ordMods.length > 0) {
		            return false;
		        }
		        if (!ordMods || ordMods.length === 0) {
		            return true;
		        }
		        var cnt = ordMods.length;
		        for (var i = 0; i < ordMods.length; i++) {
		            var found = false;
		            var preFound = true;
		            if (preMods) {
		                preFound = false;
		                for (var k = 0; k < preMods.length; k++) {
		                    if (preMods[k].Name === ordMods[i].ModName) {
		                        preFound = true;
		                        break;
		                    }
		                }
		            }
		            if (preFound) {
		                for (var j = 0; j < Mods.length; j++) {
		                    if (Mods[j].Name === ordMods[i].ModName) {
		                        found = true;
		                        setMods(itemObj, Mods[j], ordMods[i], false, false);
		                        cnt--;
		                        break;
		                    }
		                }
		            }
		
		            if (!found) {
		                break;
		            }
		        }
		        return (cnt === 0);
		    },
		    isPrefsValid = function (itemObj, Prefs, ordPrefs){
		        if ((!Prefs || Prefs.length === 0) && (ordPrefs && ordPrefs.length > 0)) {
		            return false;
		        }
		        if ((Prefs && Prefs.length > 0) && (!ordPrefs || ordPrefs.length === 0)) {
		            return false;
		        }
		        if (Prefs && ordPrefs && Prefs.length !== ordPrefs.length) {
		            return false;
		        }
		        if ((!Prefs || Prefs.length === 0) && (!ordPrefs || ordPrefs.length === 0)){
		        	return true;
		        }
		        var valid = true;
		        for (var i = 0; i < ordPrefs.length; i++) {
		            var found = false;
		            for (var j = 0; j < Prefs.length; j++) {
		                if (Prefs[j].Name === ordPrefs[i].PrefName) {
		                    if (!Prefs[j].PrefMbrs) {
		                        break;
		                    }
		                    for (var k = 0; k < Prefs[j].PrefMbrs.length; k++) {
		                        if (Prefs[j].PrefMbrs[k].Name === ordPrefs[i].PrfMbrName) {
		                            found = true;
		                            setPrefs(itemObj, Prefs[j].PrefMbrs[k], Prefs[j].Name);
		                            break;
		                        }
		                    }
		                    break;
		                }
		            }
		            if (!found) {
		                valid = false;
		                break;
		            }
		        }
		        return valid;
		    },
		    setTierPrice = function (itemObj, price0, price1, price2) {
		        itemObj.OrigPrice = price0;
		        itemObj.ActivePrice = itemObj.OrigPrice;
		        if (itemObj.SecondItemApplies) {
		            itemObj.Orig2ndPrice = price1;
		            itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
		            itemObj.Orig3rdPrice = price2;
		            itemObj.Active3rdPrice = itemObj.Orig3rdPrice;
		        }
		    },
		    setTierPrice = function (itemObj, tierSzCol) {
		        for (var i = 0; i < tierSzCol.length; i++) {
		            if (tierSzCol[i].Size == itemObj.Size) {
		                itemObj.OrigPrice = tierSzCol[i].Price;
		                itemObj.ActivePrice = itemObj.OrigPrice;
		
		                if (itemObj.SecondItemApplies) {
		                    itemObj.Orig2ndPrice = tierSzCol[i].SecondItemPrice;
		                    itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
		                    itemObj.Orig3rdPrice = tierSzCol[i].ThirdItemPrice;
		                    itemObj.Active3rdPrice = itemObj.Orig3rdPrice;
		                }
		                break;
		            }
		        }
		    },
		    setSize = function (itemObj, item, useTieredPricing, useOrdTypePricing, ordTypePriceIdx, i) {
		        itemObj.Size = item.AvailableSizes[i].Name;
		        itemObj.SizeRcptName = item.AvailableSizes[i].ReceiptName;
		        itemObj.SizeKtchName = item.AvailableSizes[i].KitchenName;
		        if (useOrdTypePricing && ordTypePriceIdx > 0) {
		            switch (ordTypePriceIdx) {
		                case 1:
		                    itemObj.OrigPrice = item.AvailableSizes[i].OrdTypePrice1;
		                    break;
		                case 2:
		                    itemObj.OrigPrice = item.AvailableSizes[i].OrdTypePrice2;
		                    break;
		            }
		        }
		        else {
		            itemObj.OrigPrice = item.AvailableSizes[i].Price;
		        }
		
		        itemObj.ActivePrice = itemObj.OrigPrice;
		        itemObj.Orig2ndPrice = item.AvailableSizes[i].SecondItemPrice;
		        itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
		        itemObj.PairPrice = item.AvailableSizes[i].PairPrice;
		        itemObj.ModValue = item.AvailableSizes[i].ModValue;
		        itemObj.Mod2ndValue = item.AvailableSizes[i].Mod2ndValue;
		        itemObj.SzSeq = i + 1;
		
		        if (useTieredPricing) {
		            switch (ordTypePriceIdx) {
		                case 0:
		                    setTierPrice(itemObj, item.TierObj.OT0Sizes);
		                    break;
		                case 1:
		                    setTierPrice(itemObj, item.TierObj.OT1Sizes);
		                    break;
		                case 2:
		                    setTierPrice(itemObj, item.TierObj.OT2Sizes);
		                    break;
		            }
		        }
		        //************** BWW **************************
				if (item.HasProdItm){
					itemObj.KDSProdItmName = item.ProdItmName;
					if (!isNaN(item.AvailableSizes[i].ProdItmCnt)){
						itemObj.KDSProdItmCnt = item.AvailableSizes[i].ProdItmCnt;
					}
				}
				if (item.HasPrepTime && !isNaN(item.AvailableSizes[i].PrepTimeSecs)){
					itemObj.KDSPrepTimeSecs = item.AvailableSizes[i].PrepTimeSecs;
				}
				//**********************************************
		    },
		    setNoSize = function (itemObj, item, useTieredPricing, useOrdTypePricing, ordTypePriceIdx) {
		        itemObj.Size = 'None';
		        itemObj.SzSeq = 0;
		        itemObj.PairPrice = item.PairPrice;
		        itemObj.Mod2ndValue = item.Mod2ndValue;
		        itemObj.ModValue = item.ModValue;
		
		        switch (useTieredPricing) {
		            case true:
		                switch (ordTypePriceIdx) {
		                    case 0:
		                        setTierPrice(itemObj, item.TierObj.OT0Price, item.TierObj.OT0Second, item.TierObj.OT0Third);
		                        break;
		                    case 1:
		                        setTierPrice(itemObj, item.TierObj.OT1Price, item.TierObj.OT1Second, item.TierObj.OT1Third);
		                        break;
		                    case 2:
		                        setTierPrice(itemObj, item.TierObj.OT2Price, item.TierObj.OT2Second, item.TierObj.OT2Third);
		                        break;
		                }
		                break;
		            case false:
		                if (useOrdTypePricing && ordTypePriceIdx > 0) {
		                    switch (ordTypePriceIdx) {
		                        case 1:
		                            itemObj.OrigPrice = item.OrdTypePrice1;
		                            break;
		                        case 2:
		                            itemObj.OrigPrice = item.OrdTypePrice2;
		                            break;
		
		                    }
		                }
		                else {
		                    itemObj.OrigPrice = item.Price;
		                }
		                itemObj.ActivePrice = itemObj.OrigPrice;
		                itemObj.Orig2ndPrice = item.SecondItemPrice;
		                itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
		        }
		        //************** BWW **************************
				if (item.HasProdItm){
					itemObj.KDSProdItmName = item.ProdItmName;
					if (!isNaN(item.ProdItmCnt)){
						itemObj.KDSProdItmCnt = item.ProdItmCnt;
					}
				}
				if (item.HasPrepTime && !isNaN(item.PrepTimeSecs)){
					itemObj.KDSPrepTimeSecs = item.PrepTimeSecs;
				}
				//**********************************************
		    },
		    setStyles = function (itemObj, Style, hasSizes, useTieredPricing, secondStyle) {
		        itemObj.Style = Style.Name;
		        itemObj.StyleRcptName = Style.ReceiptName;
		        itemObj.StyleKtchName = Style.KitchenName;
		        if (hasSizes) {
		            for (var i = 0; i < Style.Sizes.length; i++) {
		                if (Style.Sizes[i].Name == itemObj.Size) {
		                    itemObj.OrigPrice += Style.Sizes[i].Price;
		                    itemObj.ActivePrice = itemObj.OrigPrice;
		                    itemObj.Orig2ndPrice += Style.Sizes[i].SecondItemPrice;
		                    itemObj.Active2ndPrice = itemObj.Orig2ndPrice;
		                    if (useTieredPricing && itemObj.SecondItemApplies && secondStyle) {
		                        itemObj.Orig2ndPrice += Style.Sizes[i].Price;
		                        itemObj.Orig3rdPrice += Style.Sizes[i].Price;
		                    }
		                    break;
		                }
		            }
		        }
		        else {
		            itemObj.OrigPrice += Style.Price;
		            itemObj.ActivePrice = itemObj.OrigPrice;
		            if (useTieredPricing && itemObj.SecondItemApplies && secondStyle) {
		                itemObj.Orig2ndPrice += Style.Price;
		                itemObj.Orig3rdPrice += Style.Price;
		            }
		        }
		
		    },
		    setMods = function (itemObj, mod, ordMod, isMod, isPreSel) {
		        if (mod.ReceiptName == '') {
		            return;
		        }
		        var ordModObj = {};
		        ordModObj.Name = mod.Name;
		        ordModObj.RcptName = mod.ReceiptName;
		        ordModObj.NoSubCredit = mod.NoSubCredit;
		        ordModObj.HalfStatus = ordMod.HalfStatus;
				ordModObj.IsPreSel = isPreSel;
		        ordModObj.OrigPrice = mod.Price;
		        ordModObj.Orig2ndPrice = mod.SecondItemPrice;
		        ordModObj.Qty = ordMod.Qty;
		
		        ordModObj.TaxType = mod.TaxType;
		        ordModObj.KtchName = mod.KitchenName;
		        ordModObj.DlvReminder = mod.DlvReminder;
		        ordModObj.ModCatKey = mod.ModCatKey;
		        ordModObj.PriceApplies = mod.PriceApplies;
		        ordModObj.ReportGrp = mod.ReportGrp;
		        ordModObj.NoStdMod = mod.NoStdMod;
		        ordModObj.seq = mod.PosPage;
		
		        if(itemObj.Size != 'None'){
		            for(var j=0; j<mod.Sizes.length; j++){
		                if(mod.Sizes[j].Name == itemObj.Size){
		                    ordModObj.OrigPrice = mod.Sizes[j].Price;
		                    ordModObj.Orig2ndPrice = mod.Sizes[j].SecondItemPrice;
		                    ordModObj.HalfPrice = mod.Sizes[j].HalfPrice;
		                    break;
		                }
		            }
		        }
		        else{
		            ordModObj.OrigPrice = mod.Price;
		            ordModObj.Orig2ndPrice = mod.SecondItemPrice;
		            ordModObj.HalfPrice = mod.HalfPrice;
		        }
		
		        if (isMod) {
		            if (!itemObj.Mods) {
		                itemObj.Mods = [];
		            }
		            itemObj.Mods.push(ordModObj);
		        }
		        else{
		            if(!itemObj.NoMods){
		                itemObj.NoMods = [];
		            }
		            itemObj.NoMods.push(ordModObj);
		        }
		    },
		    setPrefs = function (itemObj, Pref, PrefName) {
		        if (!itemObj.PrfMbrs) {
		            itemObj.PrfMbrs = [];
		        }
		        var ordPrfMbrObj = {};
		        ordPrfMbrObj.Name = Pref.Name;
		        ordPrfMbrObj.RcptName = Pref.ReceiptName;
		        ordPrfMbrObj.KtchName = Pref.KitchenName;
		        ordPrfMbrObj.ReportGrp = Pref.ReportGrp;
		        ordPrfMbrObj.OrigPrice = Pref.Price;
		        ordPrfMbrObj.ActivePrice = ordPrfMbrObj.OrigPrice;
		        ordPrfMbrObj.PrefName = PrefName;
		        ordPrfMbrObj.PrefSource = 1;
		        ordPrfMbrObj.TaxType = Pref.TaxType;
		
		        //******************* BWW *******************
		
				if (Pref.RedPrint){
					ordPrfMbrObj.RedPrint=true;
				}
				if (Pref.HasProdItm){
					ordPrfMbrObj.KDSProdItmName = Pref.ProdItmName;
					if (!isNaN(Pref.ProdItmCnt)){
						ordPrfMbrObj.KDSProdItmCnt = Pref.ProdItmCnt;
					}
				}
				if (Pref.HasPrepTime){
					if (!isNaN(Pref.PrepTimeSecs)){
						ordPrfMbrObj.KDSPrepTimeSecs = Pref.PrepTimeSecs;
					}
				}
				if (Pref.NoQtyPrice){
					ordPrfMbrObj.NoQtyPrice = true;
				}
				if (Pref.NoKtchDisp){
					ordPrfMbrObj.NoKtchDisp = true;
				}
				if (Pref.UniqueKtchPrtCat){
					ordPrfMbrObj.UniqueKtchPrtCat = Pref.UniqueKtchPrtCat;
				}
				if (Pref.KtchPrtCat){
					ordPrfMbrObj.KtchPrtCat = Pref.KtchPrtCat;
				}
		
				//*******************************************
		        itemObj.PrfMbrs.push(ordPrfMbrObj);
		    },
		    initItemObj = function (itemObj, menuName, group, item) {
		        itemObj.Menu = menuName;
		        itemObj.GroupName = group.Name;
		        itemObj.Name = item.Name;
		        itemObj.RcptName = item.ReceiptName;
		        itemObj.OrigPrice = 0;
		        itemObj.KtchName = item.KitchenName;
		        itemObj.Qty = 1;
		        itemObj.TaxType = item.TaxType;
		        itemObj.DlvReminder = item.DlvReminder;
		        itemObj.NoDisc = item.NoDisc;
		        itemObj.KtchPrtCat = item.KtchPrtCat;
		        itemObj.ReportGrp = item.ReportGrp;
		        itemObj.PSModCnt = 0;
		        itemObj.SplitNum = 0;
		        itemObj.CpnApplied = 0;
				if (item.PreMods && item.PreMods.length) {
					itemObj.PreMods = item.PreMods;
                }
		        if (group.AllowStdMods) {
		            if (item.UseStdMods) {
		                itemObj.UseStdMods = true;
		                if (item.PreMods) {
		                    for (var i = 0; i < item.PreMods.length; i++) {
		                        if (item.PreMods[i].NoStdMod) {
		                            itemObj.PSModCnt += 1;
		                        }
		                    }
		                }
		            }
		        }
		
		        itemObj.Seq = item.ChngFlg;
		        itemObj.GrpSeq = group.PrintSeq;
		        itemObj.HasReqMods = item.HasReqMods;
		        itemObj.SecondItemApplies = item.SecondItemApplies;
		        itemObj.DisplayPS = item.DisplayPS;
		        if(item.RedPrint){
		        	itemObj.RedPrint=true;
		        }
		    };
		    return {
		        addToCart: addToCart,
		        fillItmRcptNames: fillItmRcptNames,
		        getPrevOrd: getPrevOrd,
		        getDateDiffStr: getDateDiffStr
		    };
		}();
		
	};
	return {
		prevorders:prevorders
	};
}();
module.exports = PREVORDERS;