
var CreditCardPatterns = [/^(4\d{12})|(4\d{15})$/, 
                  	  /^(5[1-5]\d{14})|(2[2-7]\d{14})$/, 
                  	/(^(6011)\d{12}$)|(^(65)\d{14}$)/, 
                  	 /^3[47]\d{13}$/];
                  	 
/*var LikelyCreditCardPatterns = [
					/^(4\d{0,15})$/,
                  	  /^5[1-5]\d{0,14}$/, 
                  	/(^(6011)\d{0,12}$)|(^(65)\d{0,14}$)/, 
                  	 /^3[47]\d{0,13}$/];*/
var LikelyCreditCardPatterns = [
					/^(4\d{0,15})$/,
                  	  /^(5\d{0,15})|(2\d{0,15})$/, 
                  	/^6\d{0,15}$/, 
                  	 /^3\d{0,14}$/];
var cardNumberStr;

var CreditCardTypes =  {Invalid:-1,VISA:0,MC:1,DISC:2,AMEX:3};
var CreditCardNames = ['invalid','visa','mc','disc','amex'];

exports.FindLikelyPattern = function(cardNum){
	  for(var i=0, iMax = LikelyCreditCardPatterns.length;i<iMax;i++){
	  	if(LikelyCreditCardPatterns[i].test(cardNum)){
	  		//Ti.API.debug('i');
			return CreditCardNames[++i];
		}
	  }
	  return -1;
};

function FindPattern(){
	  for(i=0;i<CreditCardPatterns.length;i++){
	  	if(CreditCardPatterns[i].test(cardNumberStr)){
			return i;
		}
	  }
	  return -1;
}

function ValidateCC(cardNumber){
	var CardType = CreditCardTypes.Invalid;
	var exp = /[^\d]/g;
	cardNumber = cardNumber.replace(/[^\d]/g,"");
	cardNumberStr = cardNumber;
	CardType = FindPattern();
	if(CardType == parseInt(CreditCardTypes.Invalid,10)){
		cardNumberStr = '';
		return CreditCardNames[0];
	}
	var Digits = cardNumberStr;
	cardNumberStr = '';
	var Digit;
	var Sum = 0;
	var Alt = false;
	for(j=Digits.length-1;j>=0;j--){
		Digit = parseInt(Digits.charAt(j),10);
		if(Alt){
			Digit *= 2;
			if(Digit > 9){
				Digit -= 9;
			}
		}
		Sum += Digit;
		Alt = !Alt;
	}
	if((Sum%10) == 0){
		return CreditCardNames[++CardType];
	}
	else{
		return CreditCardNames[0];
	}
}

function isCardAccepted(cardType){
	var cardAcceptedBln = false;
	var acceptedCards = ['VISA', 'MC', 'AMEX', 'DISC'];
	
	if(ro.app.Store){
		acceptedCards = ro.app.Store.Configuration.CardTypes && ro.app.Store.Configuration.CardTypes.length ? ro.app.Store.Configuration.CardTypes : acceptedCards;
	}
	else{
		var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
		if(!cfg){
			//cfg = {};
			acceptedCards = ['VISA', 'MC', 'AMEX', 'DISC'];
		}
		else{
			acceptedCards = cfg.CardTypes && cfg.CardTypes.length ? cfg.CardTypes : acceptedCards;
		}
	}
	
	for(var i=0, iMax=acceptedCards.length; i<iMax; i++){
		if(cardType.toLowerCase() == acceptedCards[i].toLowerCase()){
			cardAcceptedBln = true;
			break;
		}
	}
	return cardAcceptedBln;
}
exports.isCardAccepted = isCardAccepted;
exports.ValidateCC = ValidateCC;