var priceEngine = function(){
	var pricer = function(){
		function PricingFunctions() {
		
		    this.Ord = {};
		    this.Menu = {};
		    this.obj = {};
		
		    function secondFunction(test) {
		        test.IsLastModPrice = true;
		
		        for (var i = 0; i < ord.Items.length; i++) {
		            ord.Items[i].Price += i;
		            ord.Items[i].newItem = 'strValue';
		        }
		        ord.Items.push({ Qty: 3, Price: 20 });
		    }
		
		    function thirdFunction(price) {
		        price += 1;
		    }
		
		    this.RepriceOrderTest = function (obj, menu) {
		        this.IsLastModPrice = false;
		        ord = obj;
		        if (ord.Items == null) {
		            ord.Items = [];
		        }
		        secondFunction(this);
		        //Ti.API.debug('LastModPrice: ' + this.IsLastModPrice);
		        //thirdFunction(ord.Items[0].Price);
		    };
		
		    function GetMostExpensiveHalf(itemObj) {
		        var hasHalf = false;
		        var retCode = 0;
		        var i = 0;
		
		        if (itemObj.IsHalf) {
		            hasHalf = true;
		        }
		        else {
		            if (itemObj.Mods != null) {
		                for (i = 0; i < itemObj.Mods.length; i++) {
		                    if (itemObj.Mods[i].HalfStatus > 0) {
		                        hasHalf = true;
		                        break;
		                    }// end if
		                }// end for
		            }// end if
		        }// end if
		
		        if (hasHalf) {
		            var H1 = 0;
		            var H2 = 0;
		            var H1Mod = 0;
		            var H2Mod = 0;
		            var H1ModApplies = 0;
		            var H2ModApplies = 0;
		            var H1NoMod = 0;
		            var H2NoMod = 0;
		            if (itemObj.IsHalf) {
		                H1 = itemObj.OrigPrice;
		                H2 = itemObj.H2OrigPrice;
		            }// end if
		
		            if (itemObj.NoMods != null) {
		                for (i = 0; i < itemObj.NoMods.length; i++) {
		                    switch (itemObj.NoMods[i].HalfStatus) {
		                        case 1:
		                            H1NoMod += itemObj.NoMods[i].OrigPrice;
		                            break;
		                        case 2:
		                            H2NoMod += itemObj.NoMods[i].OrigPrice;
		                    }// end switch
		                }// end for
		            }// end if
		
		            if (itemObj.Mods != null) {
		                for (i = 0; i < itemObj.Mods.length; i++) {
		                    if (itemObj.Mods[i].HalfStatus > 0) {
		                        switch (itemObj.Mods[i].HalfStatus) {
		                            case 1:
		                                if (itemObj.Mods[i].PriceApplies) {
		                                    H1ModApplies += itemObj.Mods[i].OrigPrice * itemObj.Mods[i].Qty;
		                                }
		                                else {
		                                    H1Mod += itemObj.Mods[i].OrigPrice * itemObj.Mods[i].Qty;
		                                }
		                                break;
		                            case 2:
		                                if (itemObj.Mods[i].PriceApplies) {
		                                    H2ModApplies += itemObj.Mods[i].OrigPrice * itemObj.Mods[i].Qty;
		                                }
		                                else {
		                                    H2Mod += itemObj.Mods[i].OrigPrice * itemObj.Mods[i].Qty;
		                                }
		                                break;
		
		                        }// end switch
		                    }
		                    else {
		
		                    }// end if
		                }// end for
		            }// end if
		
		            if (H1NoMod > H1Mod) {
		                H1Mod = 0;
		            }
		            else {
		                H1Mod -= H1NoMod;
		            }
		            if (H2NoMod > H2Mod) {
		                H2Mod = 0;
		            }
		            else {
		                H2Mod -= H2NoMod;
		            }
		            H1 += (H1Mod + H1ModApplies);
		            H2 += (H2Mod + H2ModApplies);
		            if (H2 > H1) {
		                retCode = 2;
		            }
		            if (retCode == 0) {
		                if (itemObj.IsHalf) {
		                    retCode = 1;
		                }
		            }// end if
		
		        }// end if
		
		        return retCode;
		
		    }// end function
		
		
		    function AddTax(taxType, amt) {
		        //Ti.API.debug('TAX TYPE*******: ' + taxType);
		        //Ti.API.debug('ACtive Price*******: ' + amt);
		        var timeIdx = 0;
		        var blnFound = false;
		        var i;
		
		        if (Ord.Taxes == null) {
		            Ord.Taxes = [];
		        }// end if
		
		        for (i = 0; i < Ord.Taxes.length; i++) {
		            if (Ord.Taxes[i].TaxName == taxType) {
		                blnFound = true;
		                taxIdx = i;
		                break;
		            }// end if
		        }// end for
		
		        //Ti.API.debug('FOUND Tax In Ord*******: ' + blnFound);
		        //Ti.API.debug('Menu Tax Length:******** '+    Menu.TaxTypes.length);
		
		        if (!blnFound) {
		            if (Menu.TaxTypes != null) {
		                for (i = 0; i < Menu.TaxTypes.length; i++) {
		                    //Ti.API.debug('Menu TaxType************:' + Menu.TaxTypes[i].TaxName);
		                    if (Menu.TaxTypes[i].TaxName == taxType) {
		                        blnFound = true;
		                        var ordTaxObj = {};
		                        ordTaxObj.TaxName = taxType;
		                        ordTaxObj.TaxRate = Menu.TaxTypes[i].TaxRate;
		                        ordTaxObj.TaxIncluded = Menu.TaxTypes[i].TaxIncluded;
		                        ordTaxObj.Roundup = Menu.TaxTypes[i].RoundUp;
		                        Ord.Taxes.push(ordTaxObj);
		                        taxIdx = Ord.Taxes.length - 1;
		                    }// end if
		                }// end for
		            }// end if
		        }// end if
		
		        if (!blnFound) {
		            return false;
		        }
		
		        // added
		        if (!Ord.Taxes[taxIdx].Amount) {
		            Ord.Taxes[taxIdx].Amount = 0;
		        }
                Ord.Taxes[taxIdx].Amount += amt;

                if (Ord.Taxes[taxIdx].Amount < 0) {
                    Ord.Taxes[taxIdx].Amount = 0;
                }
		
		        return true;
		    }// end function
		
		    function CalculateTax() {
		        var dcTax = 0;
		        var splitNum = Ord.CurSplit;
		        var i, j;
		
		        if (Ord.Taxes != null) {
		            for (i = 0; i < Ord.Taxes.length; i++) {
		                for (j = 0; j < Menu.TaxTypes.length; j++) {
		                    if (Ord.Taxes[i].TaxName == Menu.TaxTypes[j].TaxName) {
		                        if (Menu.TaxTypes[j].UseOrdTypes) {
		                            var strOT = Ord.OrdType;
		                            for (var k = 0; k < Menu.TaxTypes[j].OrdTypes.length ; k++) {
		                                if (strOT == Menu.TaxTypes[j].OrdTypes[k].OrdType) {
		                                    Ord.Taxes[i].TaxRate = Menu.TaxTypes[j].OrdTypes[k].TaxRate;
		                                    break;
		                                }// end if
		                            }// end for
		                        }// end if
		                        break;
		                    }// end if
		                }// end for
		
		                if (Ord.Taxes[i].TaxIncluded) {
		                    Ord.Taxes[i].TaxableAmt = Math.round(Ord.Taxes[i].Amount * 100 / (1 + Ord.Taxes[i].TaxRate)) / 100;
		                }
		                else {
		                    Ord.Taxes[i].TaxableAmt = Ord.Taxes[i].Amount;
		                }
		
		
		                if (Ord.TaxExempt) {
		                    for (j = 0; j < Menu.TaxTypes.length; j++) {
		                        if (Menu.TaxTypes[j].TaxName == Ord.Taxes[i].TaxName) {
		                            if (Menu.TaxTypes[j].ExemptApplies) {
		                                Ord.Taxes[i].TaxAmt = 0;
		                                Ord.Taxes[i].TaxExempt = true;
		                                Ord.Taxes[i].TaxNum = Ord.TaxNum;
		                            }
		                            else {
		                                if (Ord.Taxes[i].RoundUp) {
		                                    Ord.Taxes[i].TaxAmt = Math.round(((Ord.Taxes[i].TaxableAmt * Ord.Taxes[i].TaxRate) + 0.0049) * 100) / 100;
		                                }
		                                else {
		                                    Ord.Taxes[i].TaxAmt = Math.round(Ord.Taxes[i].taxableAmt * Ord.Taxes[i].TaxRate * 100) / 100;
		                                }
		                                if (!Ord.Taxes[i].TaxIncluded) {
		                                    dcTax += Ord.Taxes[i].TaxAmt;
		                                }
		                            }// end if
		                            break;
		                        }// end if
		                    }// end for
		                }
		                else {
		                    //Ti.API.debug('Ord Tax Exempt undefined/false: dcTax: '+ dcTax);
		                    if (Ord.Taxes[i].RoundUp) {
		                        Ord.Taxes[i].TaxAmt = Math.round(((Ord.Taxes[i].TaxableAmt * Ord.Taxes[i].TaxRate) + 0.0049) * 100) / 100;
		                    }
		                    else {
		                        Ord.Taxes[i].TaxAmt = Math.round(Ord.Taxes[i].TaxableAmt * Ord.Taxes[i].TaxRate * 100) / 100;
		                    }
		
		                    if (!Ord.Taxes[i].TaxIncluded) {
		                        dcTax += Ord.Taxes[i].TaxAmt;
		                    }
		                }//end if
		            }// end for
		        }// end if
		        //Ti.API.debug('Ord Taxes: ********'+ dcTax);
		        Ord.Tax = dcTax;
		        return dcTax;
		    }// end function
		
		    function Set2ndItmPrice() {
		
		        var lastSizeIdx = 0;
		        var blnAllSizes = false;
		        var CurSize = "";
		        var CurGrp = "";
		        var CurIdx = 0;
		        var SecondCol = [];
		        var inserted = false;
		        var diffSum = 0;
		        var diffAmt = 0;
		        var IsSecond = false;
		        var IsThird = false;
		        var Unique3rdPrice = false;
		        var remainder = 0;
		        var SecondItemUnit = 2;
		        var i, j, k, l;
		        var SecondObj;
		        var useRollup;
		
		        for (i = 0; i < Menu.Groups.length; i++) {
		            Unique3rdPrice = false;
		            if (Menu.Groups[i].Allow2ndItem) {
		                SecondItemUnit = Menu.Groups[i].SecondItemUnit;
		                if (SecondItemUnit > 2) {
		                    if (Ord.OrdType.length > 0) {
		                        for (j = 0; j < Menu.OnlineOptions.OrdTypes.length; j++) {
		                            if (Menu.OnlineOptions.OrdTypes[j].OrdType == Ord.OrdType) {
		                                if (Menu.OnlineOptions.OrdTypes[j].No3rdItmPrice) {
		                                    SecondItemUnit = 2;
		                                }
		                            }// end if
		                        }// end for
		                    }// end if
		                }// end if
		
		                if (Menu.Groups[i].UseTieredPricing) {
		                    if (Menu.Groups[i].Unique3rdItmPrice && SecondItemUnit == 3) {
		                        Unique3rdPrice = true;
		                    }
		                }// end if
		
		                CurGrp = Menu.Groups[i].Name;
		                if (Menu.Groups[i].HasSizes) {
		                    if (Menu.Groups[i].SecondBySize) {
		                        if (Menu.Groups[i].Sizes.length > 1) {
		                            lastSizeIdx = Menu.Groups[i].Sizes.length - 1;
		                        }
		                        else {
		                            blnAllSizes = true;
		                            lastSizeIdx = 0;
		                        }// end if
		                    }
		                    else {
		                        blnAllSizes = true;
		                        lastSizeIdx = 0;
		                    }// end if
		                }
		                else {
		                    blnAllSizes = true;
		                    lastSizeIdx = 0;
		                }// end if
		
		                for (j = 0; j <= lastSizeIdx; j++) {
		                    SecondCol = [];
		                    if (blnAllSizes) {
		                        CurSize = "None";
		                    }
		                    else {
		                        CurSize = Menu.Groups[i].Sizes[j].Name;
		                    }
		
		                    for (k = 0; k < Ord.Items.length; k++) {
		                        if (Ord.Items[k].SecondItemActive) {
		                            if (Ord.Items[k].GroupName == CurGrp) {
		                                if (blnAllSizes || Ord.Items[k].Size == CurSize) {
		                                    if (Menu.UsePairsPricing) {
		                                        if (Ord.Items[k].InclusivePrice > 0) {
		                                            SecondObj = {};
		                                            SecondObj.InclusivePrice = Ord.Items[k].InclusivePrice;
		                                            SecondObj.SecondItemPrice = Ord.Items[k].Orig2ndPrice;
		                                            SecondObj.PairPrice = Ord.Items[k].PairPrice;
		                                            SecondObj.ItmIdx = k;
		                                            inserted = false;
		                                            for (l = 0; l < SecondCol.length; l++) {
		                                                if (SecondCol[l].PairPrice < SecondObj.PairPrice) {
		                                                    //SecondCol[l] = SecondObj;
		                                                    SecondCol.splice(l, 0, SecondObj);
		                                                    inserted = true;
		                                                    break;
		                                                }// end if
		                                            }// end for
		
		                                            if (!inserted) {
		                                                SecondCol.push(SecondObj);
		                                            }
		                                        }// end if
		                                    }
		                                    else {
		                                        if (Ord.Items[k].InclusivePrice >= Ord.Items[k].Orig2ndPrice) {
		                                            SecondObj = {};
		                                            SecondObj.InclusivePrice = Ord.Items[k].InclusivePrice;
		                                            SecondObj.SecondItemPrice = Ord.Items[k].Orig2ndPrice;
		                                            SecondObj.ItmIdx = k;
		                                            inserted = false;
		                                            for (l = 0; l < SecondCol.length; l++) {
		                                                if (SecondCol[l].InclusivePrice < SecondObj.InclusivePrice) {
		                                                    //SecondCol[l]=SecondObj;
		                                                    SecondCol.splice(l, 0, SecondObj);
		                                                    inserted = true;
		                                                    break;
		                                                }// end if
		                                            }// end for
		
		                                            if (!inserted) {
		                                                SecondCol.push(SecondObj);
		                                            }
		                                        }// end if
		                                    }// end if
		                                }// end if
		                            }// end if
		                        }// end if
		                    }// end for
		
		                    if (SecondCol.length > 1) {
		                        useRollup = false;
		                        for (k = 0; k < SecondCol.length; k++) {
		                            IsSecond = false;
		                            IsThird = false;
		                            if (Menu.Groups[i].SecondHouseEdge && !Menu.UsePairsPricing) {
		                                if (k >= (SecondCol.length / Menu.Groups[i].SecondItemUnit)) {
		                                    IsSecond = true;
		                                }
		                            }
		                            else {
		                                if (Unique3rdPrice) {
		                                    remainder = k % 3;
		                                    switch (remainder) {
		                                        case 0:
		                                            break;
		                                        case 1:
		                                            IsSecond = true;
		                                            break;
		                                        case 2:
		                                            IsThird = true;
		                                            break;
		                                    }// end switch
		                                }
		                                else {
		                                    if (k % SecondItemUnit != 0) {
		                                        IsSecond = true;
		                                    }
		                                }// end if
		                            }// end if
		
		                            if (IsSecond) {
		                                CurIdx = SecondCol[k].ItmIdx;
		                                diffAmt = Ord.Items[CurIdx].ActivePrice - Ord.Items[CurIdx].Active2ndPrice;
		                                diffSum += diffAmt;
		                                Ord.Items[CurIdx].ActivePrice = Ord.Items[CurIdx].Active2ndPrice;
		                                Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Display2ndPrice;
		                                Ord.Items[CurIdx].IsPaired = true;
		                                useRollup = Ord.Items[CurIdx].UseRollup;
		                                if (useRollup) {
		                                    Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Rollup2ndPrice;
		                                }
		
		                                if (Ord.Items[CurIdx].TaxType != "None") {
		                                    if (diffAmt != 0) {
		                                        AddTax(Ord.Items[CurIdx].TaxType, -diffAmt);
		                                    }
		                                }// end if
		
		                                if (Ord.Items[CurIdx].PrfMbrs != null) {
		                                    for (l = 0; l < Ord.Items[CurIdx].PrfMbrs.length; l++) {
		                                        diffAmt = Ord.Items[CurIdx].PrfMbrs[l].ActivePrice - Ord.Items[CurIdx].PrfMbrs[l].Active2ndPrice;
		                                        diffSum += diffAmt;
		                                        Ord.Items[CurIdx].PrfMbrs[l].ActivePrice = Ord.Items[CurIdx].PrfMbrs[l].Active2ndPrice;
		                                        Ord.Items[CurIdx].PrfMbrs[l].DisplayPrice = Ord.Items[CurIdx].PrfMbrs[l].Display2ndPrice;
		                                        if (useRollup) {
		                                            Ord.Items[CurIdx].PrfMbrs[l].DisplayPrice = 0;
		                                        }
		                                        if (Ord.Items[CurIdx].PrfMbrs[l].TaxType != "None") {
		                                            if (diffAmt != 0) {
		                                                AddTax(Ord.Items[CurIdx].PrfMbrs[l].TaxType, -diffAmt);
		                                            }
		                                        }// end if
		                                    }// end for
		                                }// end if
		
		                                if (Ord.Items[CurIdx].Mods != null) {
		                                    for (l = 0; l < Ord.Items[CurIdx].Mods.length; l++) {
		                                        diffAmt = Ord.Items[CurIdx].Mods[l].ActivePrice - Ord.Items[CurIdx].Mods[l].Active2ndPrice;
		                                        diffSum += diffAmt;
		                                        Ord.Items[CurIdx].Mods[l].ActivePrice = Ord.Items[CurIdx].Mods[l].Active2ndPrice;
		                                        Ord.Items[CurIdx].Mods[l].DisplayPrice = Ord.Items[CurIdx].Mods[l].Display2ndPrice;
		                                        if (useRollup) {
		                                            Ord.Items[CurIdx].Mods[l].DisplayPrice = 0;
		                                        }
		                                        if (Ord.Items[CurIdx].Mods[l].TaxType != "None") {
		                                            if (diffAmt != 0) {
		                                                AddTax(Ord.Items[CurIdx].Mods[l].TaxType, -diffAmt);
		                                            }
		                                        }// end if
		                                    }// end for
		                                }// end if
		
		                            }
		                            else if (IsThird) {
		                                CurIdx = SecondCol[k].ItmIdx;
		                                diffAmt = Ord.Items[CurIdx].ActivePrice - Ord.Items[CurIdx].Active3rdPrice;
		                                diffSum += diffAmt;
		                                Ord.Items[CurIdx].ActivePrice = Ord.Items[CurIdx].Active3rdPrice;
		                                Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Display3rdPrice;
		                                Ord.Items[CurIdx].IsPaired = true;
		                                useRollup = Ord.Items[CurIdx].UseRollup;
		                                if (useRollup) {
		                                    Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Rollup3rdPrice;
		                                }
		
		                                if (Ord.Items[CurIdx].TaxType != "None") {
		                                    if (diffAmt != 0) {
		                                        if (!AddTax(Ord.Items[CurIdx].TaxType, -diffAmt)) {
		                                            AddTax(Ord.Items[CurIdx].TaxType, -diffAmt);
		                                        }
		                                    }
		                                }// end if
		
		                                if (Ord.Items[CurIdx].PrfMbrs != null) {
		                                    for (l = 0; l < Ord.Items[CurIdx].PrfMbrs.length; l++) {
		                                        diffAmt = Ord.Items[CurIdx].PrfMbrs[l].ActivePrice - Ord.Items[CurIdx].PrfMbrs[l].Active2ndPrice;
		                                        diffSum += diffAmt;
		                                        Ord.Items[CurIdx].PrfMbrs[l].ActivePrice = Ord.Items[CurIdx].PrfMbrs[l].Active2ndPrice;
		                                        Ord.Items[CurIdx].PrfMbrs[l].DisplayPrice = Ord.Items[CurIdx].PrfMbrs[l].Display2ndPrice;
		                                        if (useRollup) {
		                                            Ord.Items[CurIdx].PrfMbrs[l].DisplayPrice = 0;
		                                        }
		                                        if (Ord.Items[CurIdx].PrfMbrs[l].TaxType != "None") {
		                                            if (diffAmt != 0) {
		                                                if (!AddTax(Ord.Items[CurIdx].TaxType, -diffAmt)) {
		                                                    AddTax(Ord.Items[CurIdx].PrfMbrs[l].TaxType, -diffAmt);
		                                                }
		                                            }
		                                        }// end if
		                                    }// end for
		                                }// end if
		
		                                if (Ord.Items[CurIdx].Mods != null) {
		                                    for (l = 0; l < Ord.Items[CurIdx].Mods.length; l++) {
		                                        diffAmt = Ord.Items[CurIdx].Mods[l].ActivePrice - Ord.Items[CurIdx].Mods[l].Active2ndPrice;
		                                        diffSum += diffAmt;
		                                        Ord.Items[CurIdx].Mods[l].ActivePrice = Ord.Items[CurIdx].Mods[l].Active2ndPrice;
		                                        Ord.Items[CurIdx].Mods[l].DisplayPrice = Ord.Items[CurIdx].Mods[l].Display2ndPrice;
		                                        if (useRollup) {
		                                            Ord.Items[CurIdx].Mods[l].DisplayPrice = 0;
		                                        }
		                                        if (Ord.Items[CurIdx].Mods[l].TaxType != "None") {
		                                            if (diffAmt != 0) {
		                                                if (!AddTax(Ord.Items[CurIdx].TaxType, -diffAmt)) {
		                                                    AddTax(Ord.Items[CurIdx].Mods[l].TaxType, -diffAmt);
		                                                }
		                                            }
		                                        }// end if
		                                    }// end for
		                                }// end if
		
		                            }
		                            else {
		                                //Ti.API.debug('Use PairsPricing ********' + Menu.UsePairsPricing);
		                                if (Menu.UsePairsPricing) {
		                                    if (k <= SecondCol.length - Menu.Groups[i].SecondItemUnit) {
		                                        CurIdx = SecondCol[k].ItmIdx;
		                                        diffAmt = Ord.Items[CurIdx].ActivePrice - Ord.Items[CurIdx].ActivePairPrice;
		                                        diffSum += diffAmt;
		                                        Ord.Items[CurIdx].ActivePrice = Ord.Items[CurIdx].ActivePairPrice;
		                                        Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].DisplayPairPrice;
		                                        useRollup = Ord.Items[CurIdx].UseRollup;
		                                        Ord.Items[CurIdx].IsPaired = true;
		                                        if (useRollup) {
		                                            Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].RollupPairPrice;
		                                        }                                       
		                                        if (Ord.Items[CurIdx].TaxType != "None") {
		                                            if (diffAmt != 0) {
		                                                AddTax(Ord.Items[CurIdx].TaxType, -diffAmt);
		                                            }
		                                        }// end if
		                                    }// end if
		                                }// end if
		                            }// end if
		                        }// end for
		                    }// end if
		                }// end for
		            }// end if
		        }// end for
		
		        if (Menu.UsePairsPricing) {
		            SecondCol = [];
		            for (k = 0; k < Ord.Items.length; k++) {
		                if (Ord.Items[k].SecondItemActive && !Ord.Items[k].IsPaired) {
		                    if (Ord.Items[k].InclusivePrice > 0) {
		                        SecondObj = {};
		                        SecondObj.InclusivePrice = Ord.Items[k].InclusivePrice;
		                        SecondObj.SecondItemPrice = Ord.Items[k].Orig2ndPrice;
		                        SecondObj.PairPrice = Ord.Items[k].PairPrice;
		                        SecondObj.ItmIdx = k;
		                        SecondObj.SprRow = Ord.Items[k].SprRow;
		                        inserted = false;
		                        for (l = 0; l < SecondCol.length; l++) {
		                            if (SecondCol[l].PairPrice < SecondObj.PairPrice) {
		                                //SecondCol[l]=SecondObj;
		                                SecondCol.splice(l, 0, SecondObj);
		                                inserted = true;
		                                break;
		                            }// end if
		                        }// end for
		
		                        if (!inserted) {
		                            SecondCol.push(SecondObj);
		                        }
		                    }// end if
		                }// end if
		            }// end for
		
		            if (SecondCol.length > 1) {
		                useRollup = false;
		                for (k = 0; k < SecondCol.length; k++) {
		                    if (k % Menu.Groups[0].SecondItemUnit != 0) {
		                        CurIdx = SecondCol[k].ItmIdx;
		                        diffAmt = Ord.Items[CurIdx].ActivePrice - Ord.Items[CurIdx].Active2ndPrice;
		                        diffSum += diffAmt;
		                        Ord.Items[CurIdx].ActivePrice = Ord.Items[CurIdx].Active2ndPrice;
		                        Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Display2ndPrice;
		                        Ord.Items[CurIdx].IsPaired = true;
		                        useRollup = Ord.Items[CurIdx].UseRollup;
		                        if (useRollup) {
		                            Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].Rollup2ndPrice;
		                        }
		                        if (Ord.Items[CurIdx].taxType != "None") {
		                            if (diffAmt != 0) {
		                                AddTax(Ord.Items[CurIdx].TaxType, -diffAmt);
		                            }
		                        }// end if
		                    }
		                    else {
		                        if (k <= SecondCol.length - Menu.Groups[0].SecondItemUnit) {
		                            CurIdx = SecondCol[k].ItmIdx;
		                            diffAmt = Ord.Items[CurIdx].ActivePrice - Ord.Items[CurIdx].ActivePairPrice;
		                            diffSum += diffAmt;
		                            Ord.Items[CurIdx].ActivePrice = Ord.Items[CurIdx].ActivePairPrice;
		                            Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].DisplayPairPrice;
		                            Ord.Items[CurIdx].IsPaired = true;
		                            useRollup = Ord.Items[CurIdx].UseRollup;
		                            if (useRollup) {
		                                Ord.Items[CurIdx].DisplayPrice = Ord.Items[CurIdx].RollupPairPrice;
		                            }
		                            if (Ord.Items[CurIdx].taxType != "None") {
		                                if (diffAmt != 0) {
		                                    AddTax(Ord.Items[CurIdx].TaxType, -diffAmt);
		                                }
		                            }// end if
		
		                        }
		                    }// end if
		                }// end for
		            }// end if
		        }// end if
		
		        return diffSum;
		    }// end function
		
		    function SetDlvyFee(subtotal, freeDlvy, dlvyFeeIfZero, dlvyType, curOTIdx) {
		        var isPct = false;
		        var curDlvyPct = 0;
		        var totFee = 0;
		        var unitFee = 0;
		        var returnAmt = 0;
		        var taxType = "";
		
		        if (curOTIdx >= 0) {
		            //Ti.API.debug('DELIVERY FEE TYPE: ' + Menu.OnlineOptions.DelivOpts.DeliveryFeeType);
		            if (dlvyType) {
		                if (Menu.OnlineOptions.DelivOpts) {
		                    if (Menu.OnlineOptions.DelivOpts.DeliveryFee) {
		                        switch (parseInt(Menu.OnlineOptions.DelivOpts.DeliveryFeeType, 10)) {
		                            case 1:
		                                //Ti.API.debug('TOTAL FEE CALC ');
		                                if (Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
		                                    totFee = Menu.OnlineOptions.DelivOpts.DeliveryFeeVal;
		
		                                }
		                                break;
		                            case 2:
		                                if (Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
		                                    totFee = 0;
		                                    isPct = true;
		                                    curDlvyPct = Menu.OnlineOptions.DelivOpts.DeliveryFeeVal;
		                                }
		                        }// end switch
		
		                        if (Menu.OnlineOptions.DelivOpts.AddDelFee && !isNaN(Menu.OnlineOptions.DelivOpts.AddDelFee)) {
		                            totFee += Menu.OnlineOptions.DelivOpts.AddDelFee;
		                        }
		                        if (totFee > 0 || isPct) {
		                            if (Menu.OnlineOptions.DelivOpts.DeliveryFeeTaxType.toUpperCase() == "NONE") {
		                                Ord.DlvyFeeTxbl = false;
		                            }
		                            else {
		                                Ord.DlvyFeeTxbl = true;
		                                taxType = Menu.OnlineOptions.DelivOpts.DeliveryFeeTaxType;
		                            }
		
		                        }// end if
		
		                        if (freeDlvy) {
		                            totFee = 0;
		                            isPct = false;
		                        }// end if
		                    }// end if
		
		                    if (subtotal > 0 || dlvyFeeIfZero) {
		                        if (isPct) {
		                            unitFee = Math.round(subtotal * curDlvyPct * 100) / 100;
		                        }
		                        Ord.DlvyFee = totFee + unitFee;
		                        returnAmt = Ord.DlvyFee;
		                        if (Ord.DlvyFeeTxbl) {
		                            if (!AddTax(taxType, Ord.DlvyFee)) {
		                            }// end if
		                        }// end if
		                    }
		                    else {
		                        Ord.DlvyFee = 0;
		                        returnAmt = 0;
		                    }// end if
		                }// end if
		            }// end if
		            else {
		                Ord.DlvyFee = 0;
		            }
		        }// end if
		        return returnAmt;
		    }// end function
		
		    function GetStdModPrice(modEffCnt, ItmGrpIdx, ItmSzIdx, obj) {
		        var modPrice = 0;
		        //var i;
		        //Ti.API.debug('Menu -StdModPrice: '+ JSON.stringify(Menu.Groups[ItmGrpIdx]));
		        Ti.API.debug('Menu -StdModPrice: '+ JSON.stringify(Menu.Groups[ItmGrpIdx].StdMods));
		        Ti.API.debug('ItmSzIdx: '+ ItmSzIdx);
		        Ti.API.debug('REF: '+ obj.IsLastModPrice);
		        Ti.API.debug('modEffCnt: '+ modEffCnt);
		        if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		            for (var i = 0, iMax = Menu.Groups[ItmGrpIdx].StdMods.length; i < iMax; i++) {
		                if (Menu.Groups[ItmGrpIdx].StdMods[i].FromCnt > modEffCnt) {
		                    break;
		                }
		                else {
		                    if (ItmSzIdx < 0) {
		                        modPrice = Menu.Groups[ItmGrpIdx].StdMods[i].Price;
		                    }
		                    else {
		                        modPrice = Menu.Groups[ItmGrpIdx].StdMods[i].Sizes[ItmSzIdx].Price;
		                    }
		                    if (i == Menu.Groups[ItmGrpIdx].StdMods.length - 1) {
		                        obj.IsLastModPrice = true; // byref
		                    }
		                }// end if
		            }// end for
		        }// end if
		        //Ti.API.debug('REF2: '+ obj.IsLastModPrice);
		        return modPrice;
		    }// end function
		
		    function GetItemOrdTypePrice(ordItmIdx, grpIdx, itemIdx, half2Idx, sizeIdx, styleIdx, otpIdx, useTier, secondStyle) {
		        var dcPrice = 0;
		        var dcH2Price = 0;
		        var surcharge = 0;
		        var itmSizeIdx = -1;
		        var half2SizeIdx = -1;
		        var i;
		        //Ti.API.debug('Menu -ItemOrdTypePrice: '+ JSON.stringify(Menu.Groups[grpIdx].Items[itemIdx]));
		        for (i = 0; i < Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes.length; i++) {
		            if (Menu.Groups[grpIdx].Sizes[sizeIdx].Name == Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes[i].Name) {
		                itmSizeIdx = i;
		                break;
		            }
		        }
		        if (half2Idx >= 0) {
		            for (i = 0; i < Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes.length; i++) {
		                if (Menu.Groups[grpIdx].Sizes[sizeIdx].Name == Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[i].Name) {
		                    half2SizeIdx = i;
		                    break;
		                }
		            }
		        }
		
		
		        if (useTier) {
		            var dc2ndPrice = 0;
		            var dc3rdPrice = 0;
		            var dcH2SecondPrice = 0;
		            var dcH2ThirdPrice = 0;
		            if (sizeIdx >= 0) {
		                switch (parseInt(otpIdx, 10)) {
		                    case 0:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].SecondItemPrice;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].ThirdItemPrice;
		                        break;
		                    case 1:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].SecondItemPrice;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].ThirdItemPrice;
		                        break;
		                    case 2:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].SecondItemPrice;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].ThirdItemPrice;
		                        break;
		
		                }// end switch
		
		                if (hald2Idx >= 0) {
		                    switch (parseInt(otpIdx, 10)) {
		                        case 0:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].SecondItemPrice;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Sizes[sizeIdx].ThirdItemPrice;
		                            break;
		                        case 1:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].SecondItemPrice;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Sizes[sizeIdx].ThirdItemPrice;
		                            break;
		                        case 2:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].SecondItemPrice;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Sizes[sizeIdx].ThirdItemPrice;
		                            break;
		
		                    }// end switch
		                }// end if
		            }
		            else {
		                switch (parseInt(otpIdx, 10)) {
		                    case 0:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Second;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Third;
		                        break;
		                    case 1:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Second;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Third;
		                        break;
		                    case 2:
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Price;
		                        dc2ndPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Second;
		                        dc3rdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Third;
		                        break;
		
		                }// end switch
		
		                if (half2Idx >= 0) {
		                    switch (parseInt(otpIdx, 10)) {
		                        case 0:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Second;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT0Third;
		                            break;
		                        case 1:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Second;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT1Third;
		                            break;
		                        case 2:
		                            dcH2Price = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Price;
		                            dcH2SecondPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Second;
		                            dcH2ThirdPrice = Menu.Groups[grpIdx].Items[itemIdx].TierObj.OT2Third;
		                            break;
		                    }// end switch
		
		                }// end if
		
		            }// end if
		
		            if (styleIdx >= 0) {
		                if (Menu.Groups[grpIdx].Styles[styleIdx].Sizes != null) {
		                    if (sizeIdx >= 0) {
		                        surcharge = Menu.Groups[grpIdx].Styles[styleIdx].Sizes[sizeIdx].Price;
		                    }
		
		                }
		                else {
		                    surcharge = Menu.Groups[grpIdx].Styles[styleIdx].Price;
		                }// end if
		            }// end if
		
		            dcPrice += surcharge;
		            dc2ndPrice += surcharge;
		            dc3rdPrice += surcharge;
		
		            if (hald2Idx >= 0) {
		                if (secondStyle) {
		                    dcH2Price += surcharge;
		                    dcH2SecondPrice += surcharge;
		                    dcH2ThirdPrice += surcharge;
		                }// end if
		
		                if (!Menu.Groups[grpIdx].MostExpensiveHalf) {
		                    dcPrice = Math.round((dcPrice + dcH2Price) * 100 / 2) / 100;
		                }
		            }// end if
		
		            Ord.Items[ordItmIdx].OrigPrice = dcPrice;
		            Ord.Items[ordItmIdx].ActivePrice = dcPrice;
		            Ord.Items[ordItmIdx].Orig2ndPrice = dc2ndPrice;
		            Ord.Items[ordItmIdx].Orig3rdPrice = dc3rdPrice;
		            Ord.Items[ordItmIdx].H2OrigPrice = dcH2Price;
		            Ord.Items[ordItmIdx].H2Orig2ndPrice = dcH2SecondPrice;
		            Ord.Items[ordItmIdx].H2Orig3rdPrice = dcH2ThirdPrice;
		        }
		        else {
		            if (sizeIdx >= 0) {
		                dcPrice = Menu.Groups[grpIdx].Items[itmIdx].AvailableSizes[itmSizeIdx].Price;
		                if (otpIdx == 1) {
		                    if (Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes[itmSizeIdx].OrdTypePrice1 > 0) {
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes[itmSizeIdx].OrdTypePrice1;
		                    }
		                }// end if
		
		                if (otpIdx == 2) {
		                    if (Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes[itmSizeIdx].OrdTypePrice2 > 0) {
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].AvailableSizes[itmSizeIdx].OrdTypePrice2;
		                    }
		                }// end if
		
		                if (half2Idx >= 0) {
		                    dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[half2SizeIdx].Price;
		                    if (otpIdx == 1) {
		                        if (Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[half2SizeIdx].OrdTypePrice1 > 0) {
		                            dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[half2SizeIdx].OrdTypePrice1;
		                        }
		                    }// end if
		
		                    if (otpIdx == 2) {
		                        if (Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[half2SizeIdx].OrdTypePrice2 > 0) {
		                            dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].AvailableSizes[half2SizeIdx].OrdTypePrice2;
		                        }
		                    }// end if
		                }// end if
		            }
		            else {
		                dcPrice = Menu.Groups[grpIdx].Items[itemIdx].Price;
		                if (otpIdx == 1) {
		                    if (Menu.Groups[grpIdx].Items[itemIdx].OrdTypePrice1 > 0) {
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].OrdTypePrice1;
		                    }
		                }// end if
		
		                if (otpIdx == 2) {
		                    if (Menu.Groups[grpIdx].Items[itemIdx].OrdTypePrice2 > 0) {
		                        dcPrice = Menu.Groups[grpIdx].Items[itemIdx].OrdTypePrice2;
		                    }
		                }// end if
		
		                if (half2Idx >= 0) {
		                    dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].Price;
		                    if (otpIdx == 1) {
		                        if (Menu.Groups[grpIdx].Items[half2Idx].OrdTypePrice1 > 0) {
		                            dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].OrdTypePrice1;
		                        }
		                    }// end if
		
		                    if (otpIdx == 2) {
		                        if (Menu.Groups[grpIdx].Items[half2Idx].OrdTypePrice2 > 0) {
		                            dcH2Price = Menu.Groups[grpIdx].Items[half2Idx].OrdTypePrice2;
		                        }
		                    }// end if
		                }// end if
		            }// end if
		
		            if (styleIdx >= 0) {
		                if (Menu.Groups[grpIdx].Styles[styleIdx].Sizes != null) {
		                    if (sizeIdx >= 0) {
		                        surcharge = Menu.Groups[grpIdx].Styles[styleIdx].Sizes[sizeIdx].Price;
		                    }
		                }
		                else {
		                    surcharge = Menu.Groups[grpIdx].Styles[styleIdx].Price;
		                }// end if
		            }// end if
		
		            dcPrice += surcharge;
		            if (half2Idx >= 0) {
		                dcH2Price += surcharge;
		                if (!Menu.Groups[grpIdx].MostExpensiveHalf) {
		                    dcPrice = Math.round((dcPrice_dcH2Price) * 100 / 2) / 100;
		                }
		            }
		
		            Ord.Items[ordItmIdx].OrigPrice = dcPrice;
		            Ord.Items[ordItmIdx].ActivePrice = dcPrice;
		            Ord.Items[ordItmIdx].H2OrigPrice = dcH2Price;
		
		        }// end if
		        return true;
		    }// end function
		
		    function UpdateOrdTypePrices(otpIdx) {
		        var grpIdx = 0;
		        var itmIdx = 0;
		        var hald2idx = 0;
		        var szIdx = 0;
		        var styIdx = 0;
		        var useTier = false;
		        var secondStyle = false;
		        var i, j;
		
		        //Ti.API.debug('Update Ord Type Prices: '+ Ord.Items.length);
		        for (i = 0; i < Ord.Items.length; i++) {
		            grpIdx = -1;
		            itmIdx = -1;
		            half2idx = -1;
		            szIdx = -1;
		            styIdx = -1;
		            for (j = 0; j < Menu.Groups.length; j++) {
		                if (Menu.Groups[j].Name == Ord.Items[i].GroupName) {
		                    grpIdx = j;
		                    break;
		                }// end if
		            }// end for
		
		            if (grpIdx >= 0) {
		                if (Menu.Groups[grpIdx].UseOrdTypePricing) {
		                    useTier = Menu.Groups[grpIdx].UseTieredPricing;
		                    secondStyle = Menu.Groups[grpIdx].SecondStyle;
		                    for (j = 0; j < Menu.Groups[grpIdx].Items.length; j++) {
		                        if (Menu.Groups[grpIdx].Items[j].Name == Ord.Items[i].Name) {
		                            itmIdx = j;
		                            break;
		                        }// end if
		                    }// end for
		
		                    if (Ord.Items[i].IsHalf) {
		                        for (j = 0; j < Menu.Groups[grpIdx].Items.length; j++) {
		                            if (Menu.Groups[grpIdx].Items[j].Name == Ord.Items[i].Half2Name) {
		                                half2idx = j;
		                                break;
		                            }// end if
		                        }// end for
		                    }// end if
		                }// end if
		            }// end if
		
		            if (itmIdx >= 0) {
		                if (!Menu.Groups[grpIdx].Items[itmIdx].OpenPrice) {
		                    if (Ord.Items[i].Size != null) {
		                        if (Ord.Items[i].Size.toUpperCase() != "NONE") {
		                            for (j = 0; j < Menu.Groups[grpIdx].Sizes.length; j++) {
		                                if (Menu.Groups[grpIdx].Sizes[j].Name == Ord.Items[i].Size) {
		                                    szIdx = j;
		                                    break;
		                                }// end if
		                            }// end for
		                        }// end if
		                    }// end if
		
		                    if (Ord.Items[i].Style != null) {
		                        if (Ord.Items[i].Style.toUpperCase() != "NONE") {
		                            for (j = 0; j < Menu.Groups[grpIdx].Styles.length; j++) {
		                                if (Menu.Groups[grpIdx].Styles[j].Name == Ord.Items[i].Style) {
		                                    styIdx = j;
		                                    break;
		                                }// end if
		                            }// end for
		                        }// end if
		                    }// end if
		
		                    GetItemOrdTypePrice(i, grpIdx, itmIdx, half2idx, szIdx, otpIdx, useTier, secondStyle);
		                }// end if
		            }// end if
		        }// end for
		        Ord.OrdTypePriceIdx = otpIdx;
		    }// end function
		
            function ValidateMultiCpnPickAny(Cpn) {                
                if (!Cpn.Items || Cpn.Items.length == 0) {
                    return false;
                }
                var blnFound = false;
                var iFound = 0;
                var blnApplies = false;
                var i, j;
                var itmPrice = 0.00;
                var aryIdx = [];
                var aryPrice = [];
                var iCpnItmFound = 0;
                var iFoundIdx = 0;
                var iHighest = 0;
				var curPrice = 0.00;
				var Surcharge = 0.00;

                //First, clear temporary CpnApplied Flags
                for (i = 0; i < Ord.Items.length; i++) {
                    if (Ord.Items[i].CpnApplied == 1) {
						Ord.Items[i].CpnApplied = 0;						
						Ord.Items[i].CpnItemMaxModValue = 0;
						Ord.Items[i].CpnItemKey = 0;
						Ord.Items[i].CpnKey = 0;
						Ord.Items[i].CpnItemSurcharge = 0;
                    }// End If
                }//End for

                //Check for Required Items
                if (Cpn.RequiredItem) {
                    if (Cpn.RequireAnyCnt > 0) {
                        if (!ValidateMultiCpnReqAny(Cpn)) {
                            return false;
                        }
                    }// End If
                    else {
                        if (!ValidateMultiCpnRequired(Cpn)) {
                            return false;
                        }
                    }// End Else
                }// End If

                blnFound = false;
                for (i = 0; i < Cpn.Items.length; i++) {
                    if (!Cpn.Items[i].IsRequired) {
                        if (iFoundIdx < 0) {
                            iFoundIdx = 0;
                        }
                        while (iFoundIdx >= 0) {
                            iFoundIdx = -1;
                            for (j = 0; j < Ord.Items.length; j++) {
                                blnApplies = false;
                                if (Ord.Items[j].CpnApplied == 0 && !Ord.Items[j].AdjObj && !Ord.Items[j].CpnObj && (!Ord.Items[j].BogoID || Ord.Items[j].BogoID == 0)) {
                                    blnApplies = IsValidItem(Ord.Items[j], Cpn.Items[i].MenuGroup, Cpn.Items[i].MenuItem, Cpn.Items[i].MenuSize, Cpn.Items[i].MenuStyle, Cpn.Items[i].MenuSizes, Cpn.Items[i].MenuStyles);

                                }// end if
                                if (blnApplies) {
                                    var curItemPrice = GetItemPriceForCpn(Ord.Items[j], Cpn.NoModDisc, Cpn.NoPrefDisc, Cpn.NoStyleDisc, Cpn.Items[i].MaxModValue);
                                    if (iFoundIdx >= 0) {
                                        //Looking for highest price
                                        var maxItemPrice = Ord.Items[iFoundIdx].ItemPriceForCpn;
                                        if (curItemPrice > maxItemPrice) {
                                            iFoundIdx = j;
                                        }
                                    }
                                    else {
                                        iFoundIdx = j;
                                    }
                                }// end if
                            }// End For
                            if (iFoundIdx >= 0) {
                                Ord.Items[iFoundIdx].CpnApplied = 3;
                                Ord.Items[iFoundIdx].CpnItemMaxModValue = Cpn.Items[i].MaxModValue;
                                Ord.Items[iFoundIdx].CpnItemKey = Cpn.Items[i].MenuCpnItmKey;
								Ord.Items[iFoundIdx].CpnKey = Cpn.Items[i].CpnKey;
								Ord.Items[iFoundIdx].CpnItemSurcharge = Cpn.Items[i].Surcharge;
                                iCpnItmFound++;
                            }
                        }// End While
                    }// End If
                }//End For

                if (iCpnItmFound > Cpn.PickAnyCnt) {
                    blnFound = true;
                    iFound = 1;
                    for (i = 0; i < Ord.Items.length; i++) {
                        if (Ord.Items[i].CpnApplied == 3) {
                            aryIdx[iFound] = i;
                            aryPrice[iFound] = Ord.Items[i].ItemPriceForCpn;
                            iFound += 1;
                        }// End If
                    }// End For
                    for (i = 1; i <= Cpn.PickAnyCnt; i++) {
                        iHighest = 1;
                        curPrice = 0.00;
                        for (j = 1; j <= iCpnItmFound; j++) {
                            if (aryPrice[j] > curPrice) {
                                iHighest = j;
                                curPrice = aryPrice[j];
                            }// End If
                        }// End For
                        Ord.Items[aryIdx[iHighest]].CpnApplied = 1;
                        aryPrice[iHighest] = 0.00;
                    }// End For
                }// End If
                else if (iCpnItmFound == Cpn.PickAnyCnt) {
                    blnFound = true;
                    for (i = 0; i < Ord.Items.length; i++) {
                        if (Ord.Items[i].CpnApplied == 3) {
                            Ord.Items[i].CpnApplied = 1;
                        }// End If
                    }// End For
                }// End Else If

                for (i = 0; i < Ord.Items.length; i++) {
                    if (Ord.Items[i].CpnApplied == 3) {
                        if (parseInt(Cpn.CpnType, 10) == 6 && iCpnItmFound >= Cpn.PickAnyCnt) {
                            Ord.Items[i].CpnApplied = 1;
                        }
                        else {
                            Ord.Items[i].CpnApplied = 0;
                            Ord.Items[i].CpnItemMaxModValue = 0;
                            Ord.Items[i].CpnItemKey = 0;
							Ord.Items[i].CpnKey = 0;
							Ord.Items[i].CpnItemSurcharge = 0;
                        }
                    }// End If
                }// End For

                if (blnFound) {
                    for (i = 0; i < Ord.Items.length; i++) {
                        if (Ord.Items[i].CpnApplied == 1) {
							itmPrice += (Ord.Items[i].ItemPriceForCpn ? Ord.Items[i].ItemPriceForCpn : 0);
							Surcharge += (Ord.Items[i].CpnItemSurcharge ? Ord.Items[i].CpnItemSurcharge : 0);
                        }// End If
                    }// End For

                    if (Cpn.MinPrice > itmPrice) {
                        blnFound = false;
                    }
                    else if (Cpn.MinPrice > (itmPrice - Cpn.CpnActiveValue)) {
                        Cpn.CpnActiveValue = itmPrice - Cpn.MinPrice;
                    }
                    else {
                        if (Cpn.CpnActiveValue > itmPrice) {
                            Cpn.CpnActiveValue = itmPrice;
                        }
					}
					if (Cpn.CpnActiveValue > Surcharge) {
						Cpn.CpnActiveValue -= Surcharge;
					}
					else {
						Cpn.CpnActiveValue = 0;
					}
                }// End If

                return blnFound;                
		    }
		
		    function ValidateMultiCpnReqAny(Cpn) {
		        var blnFound = false;
		        var blnApplies = false;
		        var iFound = 0;
		        var aryIdx = [];
		        var aryPrice = [];
		        var iCpnItmFound = 0;
		        var iFoundIdx = 0;
		        var iLowest = 0;
		        var curPrice = 0.00;
                var i, j;               
		        for (i = 0; i < Cpn.Items.length; i++) {
		            if (Cpn.Items[i].IsRequired) {
		                if (iFoundIdx < 0) {
		                    iFoundIdx = 0;
		                }
		                while (iFoundIdx >= 0) {
		                    iFoundIdx = -1;
		                    for (j = 0; j < Ord.Items.length; j++) {
                                blnApplies = false;                                
		                        if (Ord.Items[j].CpnApplied == 0 && !Ord.Items[j].AdjObj && !Ord.Items[j].CpnObj && (!Ord.Items[j].BogoID || Ord.Items[j].BogoID == 0)) {
                                    blnApplies = IsValidItem(Ord.Items[j], Cpn.Items[i].MenuGroup, Cpn.Items[i].MenuItem, Cpn.Items[i].MenuSize, Cpn.Items[i].MenuStyle, Cpn.Items[i].MenuSizes, Cpn.Items[i].MenuStyles);
		
		                        }// end if
                                if (blnApplies) {
                                    var curItemPrice = GetItemPriceForCpn(Ord.Items[j], Cpn.NoModDisc, Cpn.NoPrefDisc, Cpn.NoStyleDisc, Cpn.Items[i].MaxModValue);                                    
                                    if (iFoundIdx >= 0) {
                                        //Looking for highest price
                                        var minItemPrice = Ord.Items[iFoundIdx].ItemPriceForCpn;
                                        if (curItemPrice < minItemPrice) {
                                            iFoundIdx = j;
                                        }
                                    }
                                    else {
                                        iFoundIdx = j;
                                    }
		                        }// end if
		
		                    }// end for
		                    if (iFoundIdx >= 0) {
								Ord.Items[iFoundIdx].CpnApplied = 3;
								Ord.Items[iFoundIdx].CpnItemKey = Cpn.Items[i].MenuCpnItmKey;
								Ord.Items[iFoundIdx].CpnKey = Cpn.Items[i].CpnKey;
		                        iCpnItmFound++;
		                    }
		                }// end while
		            }// end if
		        }// end for
		
		        if (iCpnItmFound > Cpn.RequireAnyCnt) {
		            blnFound = true;
		            iFound = 1;
		            for (i = 0; i < Ord.Items.length; i++) {
		                if (Ord.Items[i].CpnApplied == 3) {
		                    aryIdx[iFound] = i;
                            aryPrice[iFound] = Ord.Items[i].ItemPriceForCpn;
		                    iFound += 1;
		                }// End If
		            }// End For
		            for (i = 1; i <= Cpn.RequireAnyCnt; i++) {
		                iLowest = 1;
		                curPrice = 0.00;
		                for (j = 1; j <= iCpnItmFound; j++) {
		                    if (aryPrice[j] > curPrice) {
		                        iLowest = j;
		                        curPrice = aryPrice[j];
		                    }// End If
		                }// End For
						Ord.Items[aryIdx[iLowest]].CpnApplied = 1;
		                aryPrice[iLowest] = 0.00;
		            }// End For
		        }// End If
		        else if (iCpnItmFound == Cpn.RequireAnyCnt) {
		            blnFound = true;
		            for (i = 0; i < Ord.Items.length; i++) {
		                if (Ord.Items[i].CpnApplied == 3) {
							Ord.Items[i].CpnApplied = 1;
		                }// End If
		            }// End For
		        }// End Else If
		
		        for (i = 0; i < Ord.Items.length; i++) {
		            if (Ord.Items[i].CpnApplied == 3) {
						Ord.Items[i].CpnApplied = 0;
						Ord.Items[i].CpnItemKey = 0;
						Ord.Items[i].CpnKey = 0;
		            }// End If
		        }// End For
		        return blnFound;
		    }
		
		    function ValidateMultiCpnRequired(Cpn) {
		        var blnFound = false;
		        var blnApplies = false;
		        var i, j;
		        if (!Cpn.Items || Cpn.Items.length == 0) {
		            return false;
		        }
		
		        for (i = 0; i < Cpn.Items.length; i++) {
		            if (Cpn.Items[i].IsRequired) {
		                blnFound = false;
		                for (j = 0; j < Ord.Items.length; j++) {
		                    blnApplies = false;
		                    if (Ord.Items[j].CpnApplied == 0 && !Ord.Items[j].AdjObj && !Ord.Items[j].CpnObj && (!Ord.Items[j].BogoID || Ord.Items[j].BogoID == 0)) {
                                blnApplies = IsValidItem(Ord.Items[j], Cpn.Items[i].MenuGroup, Cpn.Items[i].MenuItem, Cpn.Items[i].MenuSize, Cpn.Items[i].MenuStyle, Cpn.Items[i].MenuSizes, Cpn.Items[i].MenuStyles);
		                    }// End If
		                    if (blnApplies) {
		                        blnFound = true;
								Ord.Items[j].CpnApplied = 1;
								Ord.Items[j].CpnItemKey = Cpn.Items[i].MenuCpnItmKey;
								Ord.Items[j].CpnKey = Cpn.Items[i].CpnKey;
		                        break;
		                    }// End If
		                }// End For
		                if (!blnFound) {
		                    break;
		                }//End if
		            }//End If
		        }// End For
		
		        if (!blnFound) {
		            for (i = 0; i < Ord.Items.length; i++) {
		                if (Ord.Items[i].CpnApplied == 1) {
							Ord.Items[i].CpnApplied = 0;
							Ord.Items[i].CpnItemKey = 0;
							Ord.Items[i].CpnKey = 0;
		                }// End If
		            }// End For
		        }
		        return blnFound;
		    }
		
		    function IsValidItem(itemObj, menuGroup, menuItem, menuSize, menuStyle, menuSizes, menuStyles) {
		        var validGroup, validItem, validSize, validStyle;
		        validGroup = (menuGroup == "All" ? true : (itemObj.GroupName == menuGroup));
		        validItem = (menuItem == "All" ? true : (itemObj.Name == menuItem));
				validSize = (menuSize == "All" ? true : (itemObj.Size == menuSize));// || (menuSizes.includes("All") ? true : (menuSizes.includes(itemObj.Size)));
				validStyle = (menuStyle == "All" ? true : (itemObj.Style == menuStyle));// || (menuStyles.includes("All") ? true : (menuStyles.includes(itemObj.Style)));
		
		        return validGroup && validItem && validSize && validStyle;
            }

            function GetItemPriceForCpn(itemObj, noModDisc, noPrefDisc, noStyleDisc, maxModValue) {
                var iPrice = itemObj.ActivePrice;
                if (noStyleDisc && itemObj.StylePrice > 0) {
                    iPrice -= itemObj.StylePrice;
                }
                if (!noPrefDisc) {
                    iPrice += itemObj.PrefPrice;
                }
                if (!noModDisc) {
                    if (itemObj.Mods && itemObj.Mods.length > 0) {
                        var totalModPrice = 0;
                        for (var k = 0; k < itemObj.Mods.length; k++) {
                            if (maxModValue > -1) {
                                if (totalModPrice < maxModValue) {
                                    var diff = maxModValue - totalModPrice;
                                    if (itemObj.Mods[k].ActivePrice < diff) {
                                        diff = itemObj.Mods[k].ActivePrice;
                                    }
                                    iPrice += diff;
                                    totalModPrice += diff;
                                }
                                else {
                                    break;
                                }
                            }
                            else {
                                iPrice += itemObj.Mods[k].ActivePrice;
                            }
                        }
                    }
                }
                itemObj.ItemPriceForCpn = iPrice;
                return iPrice;
            }
		
		    function ValidateMultiCpn(Cpn, timeIdx) {
		        var blnFound = false;
		        var blnApplies = false;
				var itmPrice = 0.00;
				var Surcharge = 0.00;
		        var i, j, k;
		
		        for (i = 0; i < Ord.Items.length; i++) {
		            if (Ord.Items[i].CpnApplied == 1) {
						Ord.Items[i].CpnApplied = 0;
						Ord.Items[i].CpnItemSurcharge = 0;
						Ord.Items[i].CpnItemKey = 0;
						Ord.Items[i].CpnKey = 0;
		            }
		        }// end for
		        //Ti.API.debug('Cpn Items: '+ Cpn.Items);
		
		        if (Cpn.RequiredItem) {
		            if (Cpn.RequireAnyCnt > 0) {
		                //ValidateMultiCpnReqAny
		                if (!ValidateMultiCpnReqAny(Cpn)) {
		                    return false;
		                }
		            }
		            else {
		                //ValidateMultiCpnRequired
		                if (!ValidateMultiCpnRequired(Cpn)) {
		                    return false;
		                }
		            }
		        }
		        for (i = 0; i < Cpn.Items.length; i++) {
		            if (Cpn.Items[i].IsRequired) {
		                continue;
		            }
		            blnFound = false;
		            var minIdx = -1;
                    var minItmPrice = 0.00;
                    var totalModPrice = 0.00;
		            for (j = 0; j < Ord.Items.length; j++) {
		                blnApplies = false;
						if (Ord.Items[j].CpnApplied == 0 && !Ord.Items[j].AdjObj && !Ord.Items[j].CpnObj && (!Ord.Items[j].BogoID || Ord.Items[j].BogoID == 0)) {
                            blnApplies = IsValidItem(Ord.Items[j], Cpn.Items[i].MenuGroup, Cpn.Items[i].MenuItem, Cpn.Items[i].MenuSize, Cpn.Items[i].MenuStyle, Cpn.Items[i].MenuSizes, Cpn.Items[i].MenuStyles);
		                    if (timeIdx > 0) {
		                        if (Ord.Items[j].OrdItemKey != 0) {
		                            blnApplies = false;
		                        }
		                    }// end if
		                }
		
		                if (blnApplies) {
		                    var iPrice = GetItemPriceForCpn(Ord.Items[j], Cpn.NoModDisc, Cpn.NoPrefDisc, Cpn.NoStyleDisc, Cpn.Items[i].MaxModValue);		                  
		                    if (minIdx == -1) {
		                        minIdx = j;
		                        minItmPrice = iPrice;
		                    }// End If
		                    else {
		                        if (iPrice < minItmPrice) {
		                            minIdx = j;
		                            minItmPrice = iPrice;
		                        }
		                    }// End Else
		                    blnFound = true;
		                    if (!Cpn.MultiQualTtl || Cpn.MultiQualTtl == 0) {
		                        //Ti.API.debug('Cpn Applied For: ' + Ord.Items[j].Name +'-'+ j);
		                        break;
		                    }
		                }// end if
		            }// end for
		
		            if (!blnFound) {
		                break;
		            }// end if
		            else {
						Ord.Items[minIdx].CpnApplied = 1;
						Ord.Items[minIdx].CpnItemKey = Cpn.Items[i].MenuCpnItmKey;
						Ord.Items[minIdx].CpnKey = Cpn.Items[i].CpnKey;
						Ord.Items[minIdx].CpnItemSurcharge = Cpn.Items[i].Surcharge ? Cpn.Items[i].Surcharge : 0;
						itmPrice += minItmPrice;
						Surcharge += Ord.Items[minIdx].CpnItemSurcharge;
		            }
		        }// end for
		
		        if (blnFound) {
                    if (Cpn.MinPrice > itmPrice) {
                        blnFound = false;
                    }
                    else if (Cpn.MinPrice > (itmPrice - Cpn.CpnActiveValue)) {
                        Cpn.CpnActiveValue = itmPrice - Cpn.MinPrice; //Byref
                    }
                    else {
                        if (Cpn.CpnActiveValue > itmPrice) {
                            Cpn.CpnActiveValue = itmPrice;
                        }
					}					
					if (Cpn.CpnActiveValue > Surcharge) {
						Cpn.CpnActiveValue -= Surcharge;
					}
					else {
						Cpn.CpnActiveValue = 0;
                    }
		        }// end if
		
		        return blnFound;
		    }// end function
		
		    function RemoveMultiCpn(rcptName, cpnIdx) {
                Ord.Cpns.splice(cpnIdx, 1);
                if (!Ord.RemovedCpns) {
                    Ord.RemovedCpns = [];
                }
                Ord.RemovedCpns.push(rcptName);
		        return true;
		    }// end function
		
		    Object.prototype.clone = function () {
		        var newObj = (this instanceof Array) ? [] : {};
		        var i;
		        for (i in this) {
		            if (i == 'clone') {
		                continue;
		            }
		            if (this[i] && typeof this[i] == "object") {
		                newObj[i] = this[i].clone();
		            }
		            else {
		                newObj[i] = this[i];
		            }
		        }
		        return newObj;
		    };
		
		    function SplitItems() {
		        var temp = [];
		        for (var j = 0; j < Ord.Items.length; j++) {
		            if (Ord.Items[j].Qty > 1) {
		                for (var k = 0; k < Ord.Items[j].Qty; k++) {
		                    Ord.Items[j].tag = Ord.Items[j].Name + j;
		                    //var itm = ;
		                    temp.push(Ord.Items[j].clone());
		                }
		            }
		            else {
		                Ord.Items[j].tag = 'single';
		                temp.push(Ord.Items[j].clone());
		            }
		        }
		        for (var n = 0; n < temp.length; n++) {
		            temp[n].Qty = 1;
		        }
		
		        Ord.Items = temp;
		
		    }
		
		    function JoinItems() {
		
		        //var test = Ti.App.OrderObj;
		        Ti.App.SplitOrder = Ord.clone();
		        var tempCol = [];
		        for (var i = 0; i < Ord.Items.length; i++) {
		            var found = false;
		            if (Ord.Items[i].tag != 'single') {
		                for (var j = 0; j < tempCol.length; j++) {
		                    if (tempCol[j].tag == Ord.Items[i].tag) {
		                        tempCol[j].Qty++;
		                        found = true;
		                        break;
		                    }
		                }
		                if (!found) {
		                    tempCol.push(Ord.Items[i]);
		                }
		            }
		            else {
		                tempCol.push(Ord.Items[i]);
		            }
		        }
		        for (var k = 0; k < tempCol.length; k++) {
		            delete tempCol[k].tag;
		        }
		        Ord.Items = tempCol;
		        //Ti.App.OrderObj = test;
		        //Ti.API.debug('SPLIT ITEMS: ' + Ti.App.SplitOrder.Items.length);
		        //Ti.API.debug('JOIN ITEMS: ' + Ord.Items.length);
		
		    }
		
		    function getPropsForItemCpn(idx) {
		        var props = {
		            CpnActiveValue: 'CpnActiveValue',
		            ActivePrice: 'ActivePrice',
		            curCpnValue: 'curCpnValue',
		            cumCpnAmt: 'cumCpnAmt',
		            CpnAmt: 'CpnAmt',
		            cpnModMin: 'cpnModMin',
		            dcExactAdj: 'dcExactAdj',
		            adjAmt: 'adjAmt',
		            dcCpnDiff: 'dcCpnDiff',
		            curItmPrice: 'curItmPrice',
		            DisplayPrice: 'DisplayPrice',
                    RollupPrice: 'RollupPrice',
                    CurModValue: 'curModValue'
		        };
		        if (idx == 2) { // pair price
		            props.CpnActiveValue = 'ActivePairValue';
		            props.ActivePrice = 'ActivePairPrice';
		            props.CpnAmt = 'CpnPairAmt';
		            props.curCpnValue = 'curCpnPairValue';
		            props.dcCpnDiff = 'dcCpnPairDiff';
		            props.curItmPrice = 'curItmPairPrice';
		            props.DisplayPrice = 'DisplayPairPrice';
                    props.RollupPrice = 'RollupPairPrice';
                    props.CurModValue = 'curMod2ndValue';
		        }
		        else if (idx == 3) { // 2nd item
		            props.CpnActiveValue = 'Active2ndValue';
		            props.ActivePrice = 'Active2ndPrice';
		            props.CpnAmt = 'Cpn2ndAmt';
		            props.curCpnValue = 'curCpn2ndValue';
		            props.dcCpnDiff = 'dcCpn2ndDiff';
		            props.curItmPrice = 'curItm2ndPrice';
		            props.cpnModMin = 'cpnMod2ndMin';
		            props.DisplayPrice = 'Display2ndPrice';
                    props.RollupPrice = 'Rollup2ndPrice';
                    props.CurModValue = 'curMod2ndValue';
		        }
		        else if (idx == 4) {//3rd item
		            props.CpnActiveValue = 'Active3rdValue';
		            props.ActivePrice = 'Active3rdPrice';
		            props.CpnAmt = 'Cpn3rdAmt';
		            props.curCpnValue = 'curCpn3rdValue';
		            props.dcCpnDiff = 'dcCpn3rdDiff';
		            props.curItmPrice = 'curItm3rdPrice';
		            props.cpnModMin = 'cpnMod2ndMin';
		            props.DisplayPrice = 'Display3rdPrice';
                    props.RollupPrice = 'Rollup3rdPrice';
                    props.CurModValue = 'curMod2ndValue';
		        }
		        return props;
		    }
		
		    function setItemCoupon(ItemObj, idx, rtn) {
		
		        var props = getPropsForItemCpn(idx);
		
		        ItemObj.CpnObj[props.CpnActiveValue] = 0;
		        rtn[props.curCpnValue] = ItemObj.CpnObj.CpnValue;
		        var ActualPrice = ItemObj[props.ActivePrice];
		        if (idx == 1 && ItemObj.StylePrice > 0 && ItemObj.CpnObj.NoStyleDisc) {
		            ActualPrice -= ItemObj.StylePrice;
		        }
		
                if (ItemObj.CpnObj.CpnType == 1 || ItemObj.CpnObj.CpnType == 6) {//Amount Off or AdjItem
		            if (ActualPrice >= ItemObj.CpnObj.MinPrice) {
		                if (ActualPrice - ItemObj.CpnObj.MinPrice > rtn[props.curCpnValue]) {
		                    ItemObj.CpnObj[props.CpnActiveValue] = rtn[props.curCpnValue];
		                    if (idx == 1) {
		                        rtn[props.cumCpnAmt] += rtn[props.curCpnValue];
		                    }
		                    ItemObj[props.CpnAmt] = rtn[props.curCpnValue];
		                    ItemObj[props.ActivePrice] -= rtn[props.curCpnValue];
		                    rtn[props.curCpnValue] = 0;
		                }
		                else {
		                  //Ti.API.debug('item active price: '+ItemObj[props.ActivePrice]);
		                  //Ti.API.debug('cpn minprice: '+ItemObj.CpnObj.MinPrice);                   
		                    ItemObj.CpnObj[props.CpnActiveValue] = ActualPrice - ItemObj.CpnObj.MinPrice;
		                    
		                    ItemObj[props.CpnAmt] = ItemObj.CpnObj[props.CpnActiveValue];
		                    ItemObj[props.ActivePrice] = ItemObj.CpnObj.MinPrice;
		                    if (idx == 1) {
		                        rtn[props.cumCpnAmt] += ItemObj[props.CpnAmt];
		                        if (ItemObj.StylePrice > 0 && ItemObj.CpnObj.NoStyleDisc) {
                                    ItemObj[props.ActivePrice] += ItemObj.StylePrice;
                                }
		                    }
		                    
		                    rtn[props.curCpnValue] -= ItemObj[props.CpnAmt];
		                    
		                }// End If
		                if (idx !== 2) {
		                    rtn[props.cpnModMin] = 0;
		                }
		            }
		            else {
		                if (idx !== 2) {
		                    rtn[props.cpnModMin] = ItemObj.CpnObj.MinPrice - ActualPrice;
		                }
		            }// End If
		           
		        }
		        else if (ItemObj.CpnObj.CpnType == 2) { // Pct Off
		            rtn[props.dcExactAdj] = ActualPrice * ItemObj.CpnObj.CpnPct - 0.0001;
		            rtn[props.adjAmt] = Math.round(rtn[props.dcExactAdj]  * 100) / 100;
		            if (ItemObj.CpnObj.MaxValue > 0 && rtn[props.adjAmt] > ItemObj.CpnObj.MaxValue) {
		                rtn[props.adjAmt] = ItemObj.CpnObj.MaxValue;
		            }
		            else {
		                rtn[props.dcCpnDiff] += (rtn[props.adjAmt] - rtn[props.dcExactAdj]) * 100;
		            }
		            ItemObj.CpnObj[props.CpnActiveValue] = rtn[props.adjAmt];
		            ItemObj[props.ActivePrice] -= rtn[props.adjAmt];
		            if (idx == 1) {
		                rtn[props.cumCpnAmt] += rtn[props.adjAmt];
		            }
		            ItemObj[props.CpnAmt] = rtn[props.adjAmt];
		        }
		        else if (ItemObj.CpnObj.CpnType == 3) {// Set Price
		            if (ActualPrice >= rtn[props.curCpnValue]) {
		                //bug
		                ItemObj[props.CpnAmt] = ActualPrice - rtn[props.curCpnValue];
		                ItemObj.CpnObj[props.CpnActiveValue] = ItemObj[props.CpnAmt];
		                if (idx == 1) {
		                    rtn[props.cumCpnAmt] += ItemObj[props.CpnAmt];
		                }
		                ItemObj[props.ActivePrice] = rtn[props.curCpnValue];
		                rtn[props.curItmPrice] = rtn[props.curCpnValue];
		            }
		            else {
		                rtn[props.curItmPrice] = ItemObj[props.ActivePrice];
		                ItemObj[props.CpnAmt] = 0;
		                ItemObj.CpnObj[props.CpnActiveValue] = 0;
		            }
				}
				if (idx == 1 && ItemObj.CpnItemSurcharge > 0) {					
					rtn[props.curCpnValue] -= ItemObj.CpnItemSurcharge;
					ItemObj.CpnObj[props.CpnActiveValue] -= ItemObj.CpnItemSurcharge;
					ItemObj[props.ActivePrice] += ItemObj.CpnItemSurcharge;
				} 
		        if (ItemObj.CpnObj.AdjItemPrice) {
		            ItemObj[props.DisplayPrice] = ItemObj[props.ActivePrice];
		        }
		        if (ItemObj.UseRollup) {
		            ItemObj[props.RollupPrice] = ItemObj[props.ActivePrice];
		        }
		    }
		
		    function setItemCpnPrefsMods(ItemObj, idx, rtn, obj, isMod) {
		        if ((isMod && !ItemObj.CpnObj.NoModDisc) || (!isMod && !ItemObj.CpnObj.NoPrefDisc)) {
		            var pctFactor = (isMod ? 0.98 : 1.0);           
                    var props = getPropsForItemCpn(idx);
                    var ActualPrice = obj[props.ActivePrice];
                    if (isMod && ItemObj.CpnObj.MaxModValue > -1) {
                        if (rtn[props.CurModValue] >= ItemObj.CpnObj.MaxModValue) {
                            ActualPrice = 0;
                        }
                        else {
                            var diff = ItemObj.CpnObj.MaxModValue - rtn[props.CurModValue];
                            if (obj[props.ActivePrice] < diff) {
                                diff = obj[props.ActivePrice];
                            }
                            ActualPrice = diff;
                            rtn[props.CurModValue] += diff;
                        }
                    }
                    if (ItemObj.CpnObj.CpnType == 1 || ItemObj.CpnObj.CpnType == 6) {// Amount Off or AdjItem
		                //Ti.API.debug('ModCpnValue: '+rtn[props.curCpnValue]);
		                if (rtn[props.curCpnValue] > 0) {
		                    if (ActualPrice >= rtn[props.cpnModMin]) {
		                        if (ActualPrice - rtn[props.cpnModMin] > rtn[props.curCpnValue]) {
		                            if (idx == 1) {
		                               ItemObj.CpnObj[props.CpnActiveValue] += rtn[props.curCpnValue];
		                            }
		                            obj[props.CpnAmt] = rtn[props.curCpnValue];
		                            if (idx == 1) {
		                                rtn[props.cumCpnAmt] += obj[props.CpnAmt];
		                            }
		                            obj[props.ActivePrice] -= rtn[props.curCpnValue];
		                            rtn[props.curCpnValue] = 0;
		                           
		                        }
		                        else {
		                            ItemObj.CpnObj[props.CpnActiveValue] += ActualPrice - rtn[props.cpnModMin];
		                            obj[props.CpnAmt] = ActualPrice - rtn[props.cpnModMin];
		                            if (idx == 1) {
		                                rtn[props.cumCpnAmt] += obj[props.CpnAmt];
		                            }
                                    obj[props.ActivePrice] -= obj[props.CpnAmt];
		                            rtn[props.curCpnValue] -= obj[props.CpnAmt];
		                        }// End If
		                        rtn[props.cpnModMin] = 0;
		                    }
		                    else {
		                        rtn[props.cpnModMin] -= ActualPrice;
		                    }
		                }// End If
		            }// End If
		            else if (ItemObj.CpnObj.CpnType == 2) {// Pct Off
                        rtn[props.dcExactAdj] = ActualPrice * ItemObj.CpnObj.CpnPct;
		                rtn[props.adjAmt] = Math.round(rtn[props.dcExactAdj] * 100) / 100;
		                rtn[props.dcCpnDiff] += (rtn[props.adjAmt] - rtn[props.dcExactAdj]) * 100;
		                if (Math.abs(rtn[props.dcCpnDiff]) >= pctFactor) {
		                    rtn[props.adjAmt] -= parseInt(rtn[props.dcCpnDiff], 10) / 100;
		                    rtn[props.dcCpnDiff] -= parseInt(rtn[props.dcCpnDiff], 10);
		                }
		                if (ItemObj.CpnObj.MaxValue > 0) {
		                    if (ItemObj.CpnObj[props.CpnActiveValue] + rtn[props.adjAmt] > ItemObj.CpnObj.MaxValue) {
		                        rtn[props.adjAmt] = ItemObj.CpnObj.MaxValue - ItemObj.CpnObj[props.CpnActiveValue];
		                    }
		                }
		                ItemObj.CpnObj[props.CpnActiveValue] += rtn[props.adjAmt];
		                obj[props.ActivePrice] -= rtn[props.adjAmt];
		                if (idx == 1) {
		                    rtn[props.cumCpnAmt] += rtn[props.adjAmt];
		                }
		                obj[props.CpnAmt] = rtn[props.adjAmt];
		            }
		            else if (ItemObj.CpnObj.CpnType == 3) {// Set Price
		                if (rtn[props.curItmPrice] == rtn[props.curCpnValue]) {
                            obj[props.CpnAmt] = ActualPrice;
		                    ItemObj.CpnObj[props.CpnActiveValue] += obj[props.CpnAmt];
		                    if (idx == 1) {
		                        rtn[props.cumCpnAmt] += obj[props.CpnAmt];
		                    }
		                    obj[props.ActivePrice] = 0;
		                }
		                else {
                            if (ActualPrice > rtn[props.curCpnValue] - rtn[props.curItmPrice]) {
                                obj[props.CpnAmt] = ActualPrice - (rtn[props.curCpnValue] - rtn[props.curItmPrice]);
		                        ItemObj.CpnObj[props.CpnActiveValue] += obj[props.CpnAmt];
		                        if (idx == 1) {
		                            rtn[props.cumCpnAmt] += obj[props.CpnAmt];
		                        }
		                        obj[props.ActivePrice] = rtn[props.curCpnValue] - rtn[props.curItmPrice];
		                        rtn[props.curItmPrice] = rtn[props.curCpnValue];
		                    }
		                    else {
		                        rtn[props.curItmPrice] += obj[props.ActivePrice];
		                    }// End If
		                }
		            }
		            if (ItemObj.CpnObj.AdjItemPrice) {
		                obj[props.DisplayPrice] = obj[props.ActivePrice];
		            }
		            //ItemObj[props.RollupPrice] = Math.round((ItemObj[props.RollupPrice] + obj[props.ActivePrice]) * 100) / 100;
		            //if (ItemObj.UseRollup) {
		            //    obj[props.DisplayPrice] = 0;
		            //}
		        }// End If
		
		    }

		    function initSurcharges(subTotal, sysSurcharges) {
		        Ord.Surcharges = [];
		        if (sysSurcharges && sysSurcharges.length > 0){		           
		            for (var i = 0; i < sysSurcharges.length; i++){
						if(sysSurcharges[i].BusinessSurchargePayments && sysSurcharges[i].BusinessSurchargePayments.length){
							var PaySurchargeFound = false;
							if(Ord.PaymentsList && Ord.PaymentsList.length > 0){
								for(var j = 0; j < sysSurcharges[i].BusinessSurchargePayments.length; j++){
									for(var k = 0; k < Ord.PaymentsList.length; k++){									
										if(sysSurcharges[i].BusinessSurchargePayments[j].PaymentType &&
											Ord.PaymentsList[k]	&& 
											sysSurcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase() == Ord.PaymentsList[k].toLowerCase()){
												//Found matching payment from Ord break out of Payments list loop
												PaySurchargeFound = true;
												break;
										}
									}
									//break out of Surcharge payment types loop as we already found a matching surcharge payment type
									if(PaySurchargeFound){
										break;
									}
								}								
							}
							//If this surcharge is not valid for available payment types then do not add it to surcharges and continue the loop 
							if(!PaySurchargeFound){	
								continue;
							}
						}
						// Confirmed that a Surcharge can be either Payment Type or Order Type but not both. So writing a new check for Order Type surcharges
						else if(sysSurcharges[i].BusinessSurchargeOrderType && sysSurcharges[i].BusinessSurchargeOrderType.length){
							var foundOrdType = false;
							for(var x = 0; x < sysSurcharges[i].BusinessSurchargeOrderType.length; x++){
								if(sysSurcharges[i].BusinessSurchargeOrderType[x].OrderType && 
									sysSurcharges[i].BusinessSurchargeOrderType[x].OrderType != "" &&
									Ord.OrdType && Ord.OrdType != "" &&
									sysSurcharges[i].BusinessSurchargeOrderType[x].OrderType == Ord.OrdType){
										foundOrdType = true;
										break;
								}
							}
							// If no corresponding Order Type is found then move on ignoring this Surcharge
							if(!foundOrdType){	
								continue;
							}
						}
		                var sc = {};
						sc.ItemType = "Surcharge";
						sc.ItemTypeByte = 2;
		                sc.PriceType = sysSurcharges[i].PriceType;
		                if (sc.PriceType == 1 || ((typeof sc.PriceType == "string") && (sc.PriceType.length && sc.PriceType.toLowerCase() == "percent"))){
		                    sc.OrigPrice = (sysSurcharges[i].Price / 100);
		                    sc.ActivePrice = Math.round((sc.OrigPrice * subTotal) * 100) / 100;
		                    sc.DisplayPrice = sc.ActivePrice;
		                }
		                else{
		                    sc.OrigPrice = sysSurcharges[i].Price;
		                    sc.DisplayPrice = sc.OrigPrice;
		                    sc.ActivePrice = sc.OrigPrice;
		                }
		                sc.GroupName = "";
		                sc.Name = sysSurcharges[i].SCName;
		                sc.RcptName = sysSurcharges[i].RcptName;
		                sc.KtchName = sysSurcharges[i].KtchName;
		                sc.KtchPrtCat = "None";
		                sc.NoDisc = true;
		                sc.Qty = 1;
		                sc.ReportGrp = sysSurcharges[i].RptGrp;
		                sc.Size = "None";
		                sc.Style = "None";
		                sc.Status = 2;
		                sc.SplitNum = 0;
		                sc.TaxType = sysSurcharges[i].TaxType;
		                Ord.Surcharges.push(sc);
		            }
		        }
		    }

            function CheckForMultiAdjItemCpn() {                
                var AdjCpn = null;
                if (Ord.Cpns) {
                    for (i = Ord.Cpns.length - 1; i >= 0; i--) {
                        if (parseInt(Ord.Cpns[i].CpnType, 10) == 6 && Ord.Cpns[i].PickAnyCnt && Ord.Cpns[i].PickAnyCnt > 0) {                            
                            AdjCpn = Ord.Cpns[i].clone();                            
                            Ord.Cpns.splice(i, 1);
                        }
                    }
                }
                if (AdjCpn) {
                    ValidateMultiCpnPickAny(AdjCpn);
                    setAdjCoupon(AdjCpn);
                }
                else {
                    var AdjCpnCol = [];
                    for (i = 0; i < Ord.Items.length; i++) {
                        if (Ord.Items[i].CpnObj && parseInt(Ord.Items[i].CpnObj.CpnType, 10) == 6 && Ord.Items[i].CpnObj.PickAnyCnt && Ord.Items[i].CpnObj.PickAnyCnt > 0) {
                            var cpnFoundInAdjCpnCol = false;
                            for (j = 0; j < AdjCpnCol.length; j++) {
                                if (AdjCpnCol[j].Name == Ord.Items[i].CpnObj.Name) {
                                    cpnFoundInAdjCpnCol = true;
                                    break;
                                }
                            }
                            if (!cpnFoundInAdjCpnCol) {                                
                                AdjCpnCol.push(Ord.Items[i].CpnObj.clone());                                
                            }
                            Ord.Items[i].CpnObj = null;
                            Ord.Items[i].CpnApplied = 0;
                        }
                    }
                    for (k = 0; k < AdjCpnCol.length; k++) {
                        ValidateMultiCpnPickAny(AdjCpnCol[k]);
                        setAdjCoupon(AdjCpnCol[k]);
                    }
                }                
            };

            // This is the setItemCoupon function in the main Pricing Engine, need to rename as there is already a setItemCoupon function
            function setAdjCoupon(cpnObj) {
                for (i = 0; i < Ord.Items.length; i++) {
                    if (Ord.Items[i].CpnApplied == 1) {
                        Ord.Items[i].CpnObj = cpnObj.clone();
                        Ord.Items[i].CpnObj.MaxModValue = Ord.Items[i].CpnItemMaxModValue;
                        Ord.Items[i].CpnKey = cpnObj.Key;
                    }
                }
            };

            this.Split = function (ord) {
		        Ord = ord;
		        SplitItems();
		        return Ord;
		    };
		
		    this.Join = function (ord) {
		        Ord = ord;
		        JoinItems();
		        return Ord;
		    };
		
		    this.RepriceOrder = function RepriceOrder(ord, menu, curOrdTypePriceIdx, surcharges) {
		        var row = -1;
		        var dcSubTotal = 0;
		        var dcGrat = 0;
		        var dcDlvyFee = 0;
		        var dcTax = 0;
		        var dcTotal = 0;
		        var blnSkip = false;
		        var iItemQty = 0;
		        var iModQty = 0;
		        //var OrdAdjType = Cnst.AdjType.None;
		        var blnItmAdj = false;
		        var blnItmCpn = false;
		        var CpnType;
		        var grpName = "";
		        var HalfSortIdx = 0;
		        var dcPortion = 0;
		        var dcPortion2nd = 0;
		        var Offset = 0;
		        var Offset2nd = 0;
		        //var ShowDlvyFee  = DlvyFeeDisplay.No;
		        var SecondApplies = false;
		        var Cnt2ndItm = 0;
		        var deliveryType = false;
		        var hasDlvyFee = false;
		        var strItemDesc = "";
		        var useRollup = false;
		        var mostExpHalf = 0;
		        var ItmGrpIdx = 0;
		        var ItmSzIdx = 0;
		        var UseStd = false;
		        var PSRmvCnt = 0;
		        //var obj = {"IsLastModPrice":false};
		        //obj.IsLastModPrice=false;
		        var obj = { "IsLastModPrice": false };
		        //this.IsLastModPrice=false;
		        var lastModPrice = 0;
		        var modEffCnt = 0;
		        var modStdCnt = 0;
		        var roundup = false;
		        var roundupRmv = 0;
		        var roundupNet = 0;
		        var UseHalfPrice = false;
		        var leaveTax = false;
		        var freeDlvy = false;
		        var dlvyFeeIfZero = false;
		        var curOTIdx = -1;
		        var UseTier = false;
		        var Unique3rd = false;
                var Tier2ndStdMods = false;
                var curPortion = 0;
		        var i, j, k, l;
		        Ord = ord;
		        Menu = menu;
		        var localVars = {
		            curCpnValue: 0,
		            cumCpnAmt: 0,
		            cpnModMin: 0,
		            dcExactAdj: 0,
		            adjAmt: 0,
		            curItmPrice: 0,
		            curCpnPairValue: 0,
		            curItmPairPrice: 0,
		            curItm2ndPrice: 0,
		            curCpn2ndValue: 0,
		            cpnMod2ndMin: 0,
		            curCpn3rdValue: 0,
		            curItm3rdPrice: 0,
		            dcCpnDiff: 0,
		            dcCpn2ndDiff: 0,
		            dcCpn3rdDiff : 0,
                    dcCpnPairDiff: 0,
                    curModValue: 0,
                    curMod2ndValue: 0
                };
                var CreditRmvdPresel = false;
		        //var obj={};
                Ord.RemovedCpns = [];
		        if (Ord.Items == null) {
		            //Ti.API.debug('Items NULL-Pricing');
		            Ord.Items = []; // new OrdItemCol;
                }
                CheckForMultiAdjItemCpn();                
		        if (Ord.Taxes) {
		            for (i = 0; i < Ord.Taxes.length; i++) {
		                Ord.Taxes[i].Amount = 0;
		                Ord.Taxes[i].TaxableAmt = 0;
		                Ord.Taxes[i].TaxAmt = 0;
		            }
		        }
		
		        if (Ord.OrdTypePriceIdx != curOrdTypePriceIdx) {
		            if (Ord.ActiveTotal == 0) {
		                Ord.OrdTypePriceIdx = curOrdTypePriceIdx;
		            }
		            else {
		                UpdateOrdTypePrices(curOrdTypePriceIdx);
		            }
		        }
		
		        if (Ord.OrdType != "") {
		            if (Menu.OnlineOptions.OrdTypes) {
		                for (i = 0; i < Menu.OnlineOptions.OrdTypes.length; i++) {
		                    if (Menu.OnlineOptions.OrdTypes[i].OrdType == Ord.OrdType) {
		                        curOTIdx = i;
		                        deliveryType = Menu.OnlineOptions.OrdTypes[i].IsDelivery;
		                        if (Ord.ordOnlineOptions == null) {
		                            Ord.ordOnlineOptions = {}; //new OrdOnlineOptions;
		                        }
		                        Ord.ordOnlineOptions.IsDelivery = Menu.OnlineOptions.OrdTypes[i].IsDelivery;
		                        hasDlvyFee = Menu.OnlineOptions.OrdTypes[i].DeliveryChgApplies;
		                        break;
		                    }
		                }
		            }
		        }
		
		        if (Ti.App.ItemsSplit) {
		            SplitItems();
		            //Ti.API.debug('SPLIT');
                }
		        //Ti.API.debug('Function Items Length: '+ Ord.Items.length);
		        //Ti.API.debug('Items Length: ' + Ord.Items.length);
		        //Ti.API.debug('First Item Price: ' + Ord.Items[0].ActivePrice);
		        for (i = 0; i < Ord.Items.length; i++) {
		        	
		        	/*if(Ord.Items[i].isSingleItemCpn && !Ord.Items[i].hasOwnProperty('CpnObj')){
		        		Ti.API.debug('nullifying a bad singleItemCpnBln!!!!!! ----- PRICING');
		        		Ord.Items[i].isSingleItemCpn = null;
		        	}*/
		        	
		            Ord.Items[i].CpnApplied = 0;
		            Ord.Items[i].AdjAmt = 0;
		            Ord.Items[i].CpnAmt = 0;
		            Ord.Items[i].InclusivePrice = 0;
		            Ord.Items[i].PrefPrice = 0.00;
		            useRollup = Ord.Items[i].UseRollup;
		            Ord.Items[i].RollupPrice = 0;
		            roundupRmv = 0;
		            roundupNet = 0;
		            UseTier = false;
		            Unique3rd = false;
		            iItemQty = Ord.Items[i].Qty;
		            Ord.Items[i].NoModValue = Ord.Items[i].ModValue * iItemQty;
		
		            if (iItemQty == 1) {
		                SecondApplies = Ord.Items[i].SecondItemApplies;
		                Ord.Items[i].SecondItemActive = Ord.Items[i].SecondItemApplies;
		                if (Ord.Items[i].CpnObj) {
		                    if (Ord.Items[i].CpnObj.No2ndItm) {
		                        SecondApplies = false;
		                        Ord.Items[i].SecondItemActive = false;
		                    }
		                }
		            }
		            else {
		                SecondApplies = false;
		                Ord.Items[i].SecondItemActive = false;
		            }
		            if (SecondApplies) {
		                Cnt2ndItm += 1;
		                Ord.Items[i].Rollup2ndPrice = 0;
		                Ord.Items[i].RollupPairPrice = 0;
		                Ord.Items[i].Cpn2ndApplied = 0;
		                Ord.Items[i].Cpn2ndAmt = 0;
		                Ord.Items[i].CpnPairAmt = 0;
		                Ord.Items[i].NoMod2ndValue = Ord.Items[i].Mod2ndValue;
		                Ord.Items[i].IsPaired = false;
		            }
		            Ord.Items[i].InclusivePrice += Ord.Items[i].OrigPrice;
		            grpName = Ord.Items[i].GroupName;
		            mostExpHalf = 0;
		            roundup = false;
		
		            // Check for most expensive half and AutoQty
		            for (j = 0; j < Menu.Groups.length; j++) {
		                if (Menu.Groups[j].Name == grpName) {
		                    ItmGrpIdx = j;
		                    if (Menu.Groups[j].MostExpensiveHalf) {
		                        mostExpHalf = -1;
                            }
                            CreditRmvdPresel = (useRollup ? false : Menu.Groups[j].CreditRmvdPresel);                            
		                    UseTier = Menu.Groups[j].useTieredPricing;
		                    if (UseTier) {
		                        if (SecondApplies) {
		                            Tier2ndStdMods = Menu.Groups[j].SecondMods;
		                            Unique3rd = Menu.Groups[j].Unique3rdItmPrice;
		                        }
		                    }
		                    break;
		                }
		            }
		            roundup = Menu.Groups[ItmGrpIdx].RoundupHalf;
		            if (mostExpHalf < 0 && roundup == true) {
		                if (Ord.Items[i].IsHalf) {
		                    roundup = false;
		                }
		                else {
		                    mostExpHalf = 0;
		                }
		            }
		            if (mostExpHalf < 0) {
		                mostExpHalf = GetMostExpensiveHalf(Ord.Items[i]);
		            }
		
		            UseHalfPrice = Menu.Groups[ItmGrpIdx].SetHalfModPrice;
		            UseStd = Ord.Items[i].UseStdMods;
		            if (UseStd) {
		                ItmSzIdx = -1;
		                if (Ord.Items[i].Size != "None") {
		                    var szName = Ord.Items[i].Size;
		                    if (Menu.Groups[ItmGrpIdx].Sizes != null) {
		                        for (j = 0; j < Menu.Groups[ItmGrpIdx].Sizes.length; j++) {
		                            if (Menu.Groups[ItmGrpIdx].Sizes[j].Name == szName) {
		                                ItmSzIdx = j;
		                                break;
		                            }
		                        }
		                    }
		                }
		            }
		            if (Ord.Items[i].CpnObj != null) {
		                blnItmCpn = true;
		                localVars.dcCpnDiff = 0;
		                localVars.dcCpn2ndDiff = 0;
		                localVars.dcCpn3rdDiff = 0;
		                localVars.dcCpnPairDiff = 0;
		                CpnType = Ord.Items[i].CpnObj.CpnType;
		            }
		            else {
		                blnItmCpn = false;
		            }
		            Ord.Items[i].ActivePrice = Ord.Items[i].OrigPrice * iItemQty;
		
		            if (mostExpHalf > 1 && Ord.Items[i].IsHalf) {
		                Ord.Items[i].ActivePrice = Ord.Items[i].H2OrigPrice * iItemQty;
		                Ord.Items[i].NoModValue = Ord.Items[i].H2ModValue * iItemQty;
		                //Ti.API.debug('No Mod Value After*******' + Ord.Items[i].NoModValue);
		            }
		
		            Ord.Items[i].DisplayPrice = Ord.Items[i].ActivePrice;
		            Ord.Items[i].RollupPrice = Ord.Items[i].ActivePrice;
		
		            if (blnItmCpn) {						
						freeDlvy = Ord.Items[i].CpnObj.FreeDlvy;
						dlvyFeeIfZero = Ord.Items[i].CpnObj.DlvyFeeIfZero;
		                setItemCoupon(Ord.Items[i], 1, localVars);
		            }// End If
		
		            if (SecondApplies) {
		                if (Menu.UsePairsPricing) {
		                    Ord.Items[i].ActivePairPrice = Ord.Items[i].PairPrice;
		                    Ord.Items[i].DisplayPairPrice = Ord.Items[i].ActivePairPrice;
		                    if (blnItmCpn) {
		                        setItemCoupon(Ord.Items[i], 2, localVars);
		                    }
		                    //if (useRollup) {
		                    //    Ord.Items[i].RollupPairPrice = Ord.Items[i].ActivePairPrice;
		                    //}
		                }
		                else {
		                    Ord.Items[i].Active2ndPrice = Ord.Items[i].Orig2ndPrice;
		                    if (mostExpHalf < 1 && Ord.Items[i].IsHalf) {
		                        Ord.Items[i].NoMod2ndValue = Ord.Items[i].H2Mod2ndValue;
		                    }
		
		                    Ord.Items[i].Display2ndPrice = Ord.Items[i].Active2ndPrice;
		
		                    if (blnItmCpn) {
		                        setItemCoupon(Ord.Items[i], 3, localVars);
		                    }
		                    //if (useRollup) {
		                    //    Ord.Items[i].Rollup2ndPrice = Ord.Items[i].Active2ndPrice;
		                    //}
		                    if (Unique3rd) {
		                        Ord.Items[i].Active3rdPrice = Ord.Items[i].Orig3rdPrice;
		                        if (mostExpHalf > 1 && Ord.Items[i].IsHalf) {
		                            Ord.Items[i].Active3rdPrice = Ord.Items[i].H2Orig3rdPrice;
		                            Ord.Items[i].NoMod2ndValue = Ord.Items[i].H2Mod2ndValue;
		                        }
		
		                        Ord.Items[i].Display3rdPrice = Ord.Items[i].Active3rdPrice;
		
		                        if (blnItmCpn) {
		                            setItemCoupon(Ord.Items[i], 4, localVars);
		                        }
		                        //if (useRollup) {
		                        //    Ord.Items[i].Rollup3rdPrice = Ord.Items[i].Active3rdPrice;
		                        //}
		                    }
		                }
		            }
		
		            dcSubTotal += Ord.Items[i].ActivePrice;
		            //Ti.API.debug('Item Name: '+ Ord.Items[i].RcptName);
		            //Ti.API.debug('Active Price:****** '+ Ord.Items[i].ActivePrice);
		            //Ti.API.debug('Items Price SubTotal:****** '+ dcSubTotal);
		
		            if (Ord.Items[i].TaxType != "None") {
		                AddTax(Ord.Items[i].TaxType, Ord.Items[i].ActivePrice);
		            }
		
		            if (Ord.Items[i].PrfMbrs != null) {
		                for (j = 0; j < Ord.Items[i].PrfMbrs.length; j++) {
		                    Ord.Items[i].PrfMbrs[j].DisplayPrice = 0;
		                    blnSkip = false;
		
		                    if (!blnSkip) {
		                        if (Ord.Items[i].PrfMbrs[j].OrigPrice > 0) {
		                            //Ord.Items[i].PrfMbrs[j].ActivePrice = Ord.Items[i].PrfMbrs[j].OrigPrice * iItemQty;
		                            if (!Ord.Items[i].PrfMbrs[j].NoQtyPrice) {
		                                Ord.Items[i].PrfMbrs[j].ActivePrice = Math.round(Ord.Items[i].PrfMbrs[j].OrigPrice * iItemQty * 100) / 100;
		                            }
		                            Ord.Items[i].PrfMbrs[j].DisplayPrice = Ord.Items[i].PrfMbrs[j].ActivePrice;
                                    Ord.Items[i].InclusivePrice = Math.round((Ord.Items[i].InclusivePrice + Ord.Items[i].PrfMbrs[j].ActivePrice) * 100) / 100;
                                    Ord.Items[i].PrefPrice = Math.round((Ord.Items[i].PrefPrice + Ord.Items[i].PrfMbrs[j].ActivePrice) * 100) / 100;
		
		                            if (blnItmCpn) {
		                                setItemCpnPrefsMods(Ord.Items[i], 1, localVars, Ord.Items[i].PrfMbrs[j]);
		                            }
		                            Ord.Items[i].RollupPrice = Math.round((Ord.Items[i].RollupPrice + Ord.Items[i].PrfMbrs[j].ActivePrice) * 100) / 100;
		                            if (useRollup) {
		                                Ord.Items[i].PrfMbrs[j].DisplayPrice = 0;
		                            }
		                            if (SecondApplies) {
		                                Ord.Items[i].PrfMbrs[j].Orig2ndPrice = 0;
		                                Ord.Items[i].PrfMbrs[j].Active2ndPrice = Ord.Items[i].PrfMbrs[j].Orig2ndPrice;
		                                Ord.Items[i].PrfMbrs[j].Display2ndPrice = Ord.Items[i].PrfMbrs[j].Active2ndPrice;
		
		                                if (blnItmCpn) {
		                                    setItemCpnPrefsMods(Ord.Items[i], 3, localVars, Ord.Items[i].PrfMbrs[j]);
		                                }
		                                if (useRollup) {
		                                    //Ord.Items[i].Rollup2ndPrice += Ord.Items[i].PrfMbrs[j].Active2ndPrice;
		                                    Ord.Items[i].Rollup2ndPrice = Math.round((Ord.Items[i].Rollup2ndPrice + Ord.Items[i].PrfMbrs[j].Active2ndPrice) * 100) / 100;
		                                    Ord.Items[i].PrfMbrs[j].Display2ndPrice = 0;
		                                }
		                            }
		                        }
		                        else {
		                            Ord.Items[i].PrfMbrs[j].Orig2ndPrice = 0;
		                            Ord.Items[i].PrfMbrs[j].Active2ndPrice = Ord.Items[i].PrfMbrs[j].Orig2ndPrice;
		                            Ord.Items[i].PrfMbrs[j].Display2ndPrice = Ord.Items[i].PrfMbrs[j].Active2ndPrice;
		                        }
		
		                        dcSubTotal += Ord.Items[i].PrfMbrs[j].ActivePrice;
		
		                        if (Ord.Items[i].PrfMbrs[j].TaxType != "None") {
		                            AddTax(Ord.Items[i].PrfMbrs[j].TaxType, Ord.Items[i].PrfMbrs[j].ActivePrice);
		                        }
                            }

                            // Preference Mods
                            Ord.Items[i].PrfMbrs[j].NoModValue = Ord.Items[i].PrfMbrs[j].ModValue;
                            Ord.Items[i].PrfMbrs[j].NoMod2ndValue = 0;
                            if (Ord.Items[i].PrfMbrs[j].NoMods) {
                                for (k = 0; k < Ord.Items[i].PrfMbrs[j].NoMods.length; k++) {
                                    Ord.Items[i].PrfMbrs[j].NoMods[k].Roundup = false;
                                    row++;
                                    if (!Ord.Items[i].PrfMbrs[j].NoMods[k].OrigPrice) {
                                        roundupRmv--;
                                    }
                                    if (!Ord.Items[i].PrfMbrs[j].NoMods[k].NoStdMod && !Ord.Items[i].PrfMbrs[j].NoMods[k].NoSubCredit) {
                                        PSRmvCnt -= 1;
                                    }
                                    //whole
                                    dcPortion = Ord.Items[i].PrfMbrs[j].NoMods[k].OrigPrice;
                                    if (SecondApplies && !Ord.Items[i].PrfMbrs[j].NoMods[k].NoSubCredit) {
                                        Ord.Items[i].PrfMbrs[j].NoMod2ndValue += Ord.Items[i].PrfMbrs[j].NoMods[k].Orig2ndPrice;
                                    }
                                    if (!UseStd && !Ord.Items[i].PrfMbrs[j].NoMods[k].NoSubCredit) {
                                        Ord.Items[i].PrfMbrs[j].NoModValue += dcPortion * iItemQty;
                                    }
                                }
                            } // Pref No Mods

                            if (Ord.Items[i].PrfMbrs[j].Mods) {
                                localVars.curModValue = 0;
                                localVars.curMod2ndValue = 0;
                                for (k = 0; k < Ord.Items[i].PrfMbrs[j].Mods.length; k++) {
                                    if (UseStd && !Ord.Items[i].PrfMbrs[j].Mods[k].NoStdMod) {
                                        curPortion = 0;
                                        iModQty = Ord.Items[i].PrfMbrs[j].Mods[k].Qty;
                                        //whole
                                        if (PSRmvCnt < 0) {
                                            if (iModQty > 1) {
                                                if (Ord.Items[i].PrfMbrs[j].Mods[k].IsPreSel) {
                                                    iModQty -= 1;
                                                }
                                                dcPortion = 0;
                                                for (l = 1; l <= iModQty; l++) {
                                                    if (PSRmvCnt == -0.5) {
                                                        modStdCnt += 1;
                                                        Offset = -Offset;
                                                        curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);
                                                        lastModPrice = curPortion;
                                                        PSRmvCnt = 0;
                                                        if (Ord.Items[i].PrfMbrs[j].Mods[k].Roundup) {
                                                            dcPortion = curPortion;
                                                        }
                                                        else {
                                                            dcPortion = Math.round((curPortion + Offset) * 100 / 2) / 100;
                                                        }
                                                    }
                                                    else if (PSRmvCnt < 0) {
                                                        PSRmvCnt += 1;
                                                    }
                                                    else {
                                                        modStdCnt += 1;
                                                        if (!obj.IsLastModPrice) {
                                                            curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);
                                                            lastModPrice = curPortion;
                                                        }
                                                        else {
                                                            curPortion = lastModPrice;
                                                        }
                                                        dcPortion += curPortion;
                                                    }
                                                }
                                            } //iModQty > 1
                                            else {
                                                if (PSRmvCnt == 0.5) {
                                                    modStdCnt += 1;
                                                    Offset = -Offset;
                                                    curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);
                                                    lastModPrice = curPortion;
                                                    PSRmvCnt = 0;
                                                    if (Ord.Items[i].PrfMbrs[j].Mods[k].Roundup) {
                                                        dcPortion = curPortion;
                                                    }
                                                    else {
                                                        dcPortion = Math.round((curPortion + Offset) * 100 / 2) / 100;
                                                    }
                                                }
                                                else {
                                                    dcPortion = 0;
                                                    PSRmvCnt += 1;
                                                }
                                            } //iModQty <=1
                                        } // PSRmvCnt < 0
                                        else {
                                            if (iModQty > 1) {
                                                if (Ord.Items[i].PrfMbrs[j].Mods[k].IsPreSel) {
                                                    iModQty -= 1;
                                                }
                                                dcPortion = 0;
                                                for (l = 1; l <= iModQty; l++) {
                                                    modStdCnt += 1;
                                                    if (!obj.IsLastModPrice) {
                                                        curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);
                                                        lastModPrice = curPortion;
                                                        dcPortion += curPortion;
                                                    }
                                                    else {
                                                        dcPortion = lastModPrice;
                                                    }
                                                }
                                            } // iModQty > 1
                                            else {
                                                modStdCnt += 1;
                                                if (!obj.IsLastModPrice) {
                                                    dcPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);
                                                    lastModPrice = dcPortion;
                                                }
                                                else {
                                                    dcPortion = lastModPrice;
                                                }
                                            }//iModQty <= 1
                                        } // PSRmvCnt >= 0
                                        Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice = dcPortion * iItemQty;
                                    } // StdMod
                                    else {
                                        dcPortion = Ord.Items[i].PrfMbrs[j].Mods[k].OrigPrice;
                                        if (SecondApplies) {
                                            dcPortion2nd = Ord.Items[i].PrfMbrs[j].Mods[k].Orig2ndPrice;
                                        }
                                        iModQty = Ord.Items[i].PrfMbrs[j].Mods[k].Qty;
                                        if (Ord.Items[i].PrfMbrs[j].Mods[k].IsPreSel) {
                                            //No charge for first presel
                                            dcPortion = dcPortion * (iModQty - 1);
                                            if (SecondApplies) {
                                                dcPortion2nd = dcPortion2nd * (iModQty - 1);
                                            }
                                        }
                                        else {
                                            dcPortion = dcPortion * iModQty;
                                            if (SecondApplies) {
                                                dcPortion2nd = dcPortion2nd * iModQty;
                                            }
                                        }
                                        Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice = dcPortion * iItemQty;
                                        if (SecondApplies) {
                                            Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice = dcPortion2nd;
                                            if (Ord.Items[i].PrfMbrs[j].NoMod2ndValue > 0) {
                                                if (!Ord.Items[i].PrfMbrs[j].Mods[k].PriceApplies) {
                                                    if (Ord.Items[i].PrfMbrs[j].NoMod2ndValue >= Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice) {
                                                        Ord.Items[i].PrfMbrs[j].NoMod2ndValue -= Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice;
                                                        Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice = 0;
                                                    }
                                                    else {
                                                        Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice -= Ord.Items[i].PrfMbrs[j].NoMod2ndValue;
                                                        Ord.Items[i].PrfMbrs[j].NoMod2ndValue = 0;
                                                    }
                                                }
                                            }
                                            Ord.Items[i].PrfMbrs[j].Mods[k].Display2ndPrice = Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice;
                                        }// SecondApplies

                                        if (Ord.Items[i].PrfMbrs[j].NoModValue > 0) {
                                            if (!Ord.Items[i].PrfMbrs[j].Mods[k].PriceApplies) {
                                                if (Ord.Items[i].PrfMbrs[j].Mods[k].Roundup && Ord.Items[i].PrfMbrs[j].Mods[k].HalfStatus == 0) {
                                                    if (Ord.Items[i].PrfMbrs[j].NoModValue <= Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice) {
                                                        Ord.Items[i].PrfMbrs[j].NoModValue = 0;
                                                    }
                                                }
                                                else {
                                                    if (Ord.Items[i].PrfMbrs[j].NoModValue >= Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice) {
                                                        Ord.Items[i].PrfMbrs[j].NoModValue -= Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice;
                                                        Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice = 0;
                                                    }
                                                    else {
                                                        Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice -= Ord.Items[i].PrfMbrs[j].NoModValue;
                                                        Ord.Items[i].PrfMbrs[j].NoModValue = 0;
                                                    }
                                                }
                                            }
                                        }// NodMOdValue > 0

                                    }// No StdMod
                                    Ord.Items[i].PrfMbrs[j].Mods[k].DisplayPrice = Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice;
                                    Ord.Items[i].InclusivePrice += Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice;

                                    if (blnItmCpn) {
                                        setItemCpnPrefsMods(Ord.Items[i], 1, localVars, Ord.Items[i].PrfMbrs[j].Mods[k], true);
                                    }
                                    Ord.Items[i].RollupPrice = Math.round((Ord.Items[i].RollupPrice + Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice) * 100) / 100;
                                    if (useRollup) {
                                        Ord.Items[i].PrfMbrs[j].Mods[k].DisplayPrice = 0;
                                    }
                                    if (SecondApplies) {
                                        if (blnItmCpn) {
                                            setItemCpnPrefsMods(Ord.Items[i], 3, localVars, Ord.Items[i].PrfMbrs[j].Mods[k], true);
                                        }
                                        if (useRollup) {
                                            Ord.Items[i].Rollup2ndPrice = Math.round((Ord.Items[i].Rollup2ndPrice + Ord.Items[i].PrfMbrs[j].Mods[k].Active2ndPrice) * 100) / 100;
                                            Ord.Items[i].PrfMbrs[j].Mods[k].Display2ndPrice = 0;
                                        }
                                    }

                                    dcSubTotal += Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice;
                                    if (Ord.Items[i].PrfMbrs[j].Mods[k].TaxType != 'None') {
                                        AddTax(Ord.Items[i].PrfMbrs[j].Mods[k].TaxType, Ord.Items[i].PrfMbrs[j].Mods[k].ActivePrice);
                                    }
                                } // End for
                            } // End If
                            // Pref Mods
		
		                }
		            }
		
		            PSRmvCnt = 0;
		            //Ti.API.debug('*** Ord.NoMods length: '+ Ord.Items[i].NoMods.length);
		            if (Ord.Items[i].NoMods) {
		                Offset = -0.001;
		                //Ti.API.debug('*** Inside No Mods: ');
		                for (HalfSortIdx = 0; HalfSortIdx < 3; HalfSortIdx++) {
		                    for (j = 0; j < Ord.Items[i].NoMods.length; j++) {
		                        //Ti.API.debug('*** HalfStatus: '+ Ord.Items[i].NoMods[j].HalfStatus);
		                        Ord.Items[i].NoMods[j].Roundup = false;
		                        if (Ord.Items[i].NoMods[j].HalfStatus == HalfSortIdx) {
		                            //Ti.API.debug(' ***********Inside No MODS');
		                            row += 1;
		                            if (HalfSortIdx > 0) {
		                                if (Ord.Items[i].NoMods[j].OrigPrice > 0 && !Ord.Items[i].NoMods[j].NoSubCredit) {
		                                    roundupRmv -= 0.5;
		                                }
		                                if (!Ord.Items[i].NoMods[j].NoStdMod && !Ord.Items[i].NoMods[j].NoSubCredit) {
		                                    PSRmvCnt -= 0.5;
		                                }
		                                if (mostExpHalf > 0) {
		                                    if (HalfSortIdx == mostExpHalf) {
		                                        dcPortion = Ord.Items[i].NoMods[j].OrigPrice;
                                                if (SecondApplies && !Ord.Items[i].NoMods[j].NoSubCredit) {
                                                    if (CreditRmvdPresel) {
                                                        Ord.Items[i].Rmvd2ndPrice = Ord.Items[i].NoMods[j].Orig2ndPrice;
                                                    }
                                                    else {
                                                        Ord.Items[i].NoMod2ndValue += Ord.Items[i].NoMods[j].Orig2ndPrice;
                                                    }
		                                            
		                                        }
		
		                                    }
		                                    else {
		                                        dcPortion = 0;
		                                    }
		                                }
		                                else {
		                                    if (Ord.Items[i].NoMods[j].HalfPrice > 0 && UseHalfPrice) {
		                                        dcPortion = Ord.Items[i].NoMods[j].HalfPrice;
		                                    }
		                                    else {
		                                        Offset = -Offset;
		                                        dcPortion = Math.round((Ord.Items[i].NoMods[j].OrigPrice + Offset) * 100 / 2) / 100;
                                                if (SecondApplies && !Ord.Items[i].NoMods[j].NoSubCredit) {
                                                    if (CreditRmvdPresel) {
                                                        Ord.Items[i].Rmvd2ndPrice = Math.round((Ord.Items[i].NoMods[j].Orig2ndPrice + Offset) * 100 / 2) / 100;
                                                    }
                                                    else {
                                                        Ord.Items[i].NoMod2ndValue += Math.round((Ord.Items[i].NoMods[j].Orig2ndPrice + Offset) * 100 / 2) / 100;
                                                    }
		                                            //Ord.Items[i].NoMod2ndValue += Math.round((Ord.Items[i].NoMods[j].Orig2ndPrice + Offset) * 100 / 2) / 100;
		                                        }
		                                    }
		                                }
		                            }
		                            else {
		                                if (Ord.Items[i].NoMods[j].OrigPrice <= 0) {
		                                    roundupRmv -= 1;
		                                }
		                                if (!Ord.Items[i].NoMods[j].NoStdMod && !Ord.Items[i].NoMods[j].NoSubCredit) {
		                                    PSRmvCnt -= 1;
		                                }
		                                dcPortion = Ord.Items[i].NoMods[j].OrigPrice;
                                        if (SecondApplies && !Ord.Items[i].NoMods[j].NoSubCredit) {
                                            if (CreditRmvdPresel) {
                                                Ord.Items[i].Rmvd2ndPrice = Ord.Items[i].NoMods[j].Orig2ndPrice;
                                            }
                                            else {
                                                Ord.Items[i].NoMod2ndValue += Ord.Items[i].NoMods[j].Orig2ndPrice;
                                            }
		                                    //Ord.Items[i].NoMod2ndValue += Ord.Items[i].NoMods[j].Orig2ndPrice;
		                                }
		                            }
		                            if (!UseStd && !Ord.Items[i].NoMods[j].NoSubCredit) {
		                                //Ti.API.debug('Inside corrected: NoModValue: '+ Ord.Items[i].NoModValue);
                                        if (CreditRmvdPresel) {
                                            Ord.Items[i].NoMods[j].RmvdPrice = (iItemQty == 0 ? dcPortion : (dcPortion * iItemQty));
                                            Ord.Items[i].NoMods[j].ActivePrice = - Ord.Items[i].NoMods[j].RmvdPrice;
                                        }
                                        else {
                                            Ord.Items[i].NoModValue += (iItemQty == 0 ? dcPortion : (dcPortion * iItemQty));
                                        }
		                                //Ord.Items[i].NoModValue += dcPortion * iItemQty;
		                                //Ti.API.debug('Inside corrected: NoModValue: '+ dcPortion * iItemQty);
                                    }
                                    Ord.Items[i].NoMods[j].DisplayPrice = Ord.Items[i].NoMods[j].ActivePrice;
		                        }
		                    }
		                }
		            }
		
		            if (UseStd) {
		                //IsLastModPrice = false;
		                obj.IsLastModPrice = false;
		                Ti.API.debug('Ord.Items[i]: ' + JSON.stringify(Ord.Items[i]));
		                Ti.API.debug('**** ' + Ord.Items[i].PSModCnt + ' ****');
		                modStdCnt = Ord.Items[i].PSModCnt;
		            }
		
		            //Mods
		            if (Ord.Items[i].Mods != null) {
		                if (roundup) {
		                    var oddRmv = false;
		                    if (roundupRmv % 1 != 0) {
		                        oddRmv = true;
		                    }
		                    roundupNet = roundupRmv;
		
		                    for (j = 0; j < Ord.Items[i].Mods.length; j++) {
		                        Ord.Items[i].Mods[j].Roundup = false;
		                        if (!Ord.Items[i].Mods[j].PriceApplies && Ord.Items[i].Mods[j].OrigPrice > 0) {
		                            if (Ord.Items[i].Mods[j].HalfStatus > 0) {
		                                roundupNet += (0.5 * Ord.Items[i].Mods[j].Qty);
		                            }
		                            else {
		                                roundupNet += Ord.Items[i].Mods[j].Qty;
		                            }
		                        }//end if
		                    }//end for
		                    if (roundupNet > 0) {
		                        if (roundupNet % 1 != 0) {
		                            var halfFound = false;
		                            if (oddRmv) {
		                                for (HalfSortIdx = 2; HalfSortIdx >= 1; HalfSortIdx--) {
		                                    for (j = Ord.Items[i].Mods.length - 1; j >= 0; j--) {
		                                        if (Ord.Items[i].Mods[j].HalfStatus == HalfSortIdx) {
		                                            if (Ord.Items[i].Mods[j].OrigPrice > 0) {
		                                                Ord.Items[i].Mods[j].Roundup = true;
		                                                halfFound = true;
		                                                break;
		                                            } // end if
		                                        }// end if
		                                    } // end for
		                                    if (halfFound) {
		                                        break;
		                                    }
		                                }// end for
		
		                                if (!halfFound) {
		                                    var RoundupIdx = 0.5 - roundupRmv;
		                                    var ColIdx = 0;
		                                    for (j = 0; j < Ord.Items[i].Mods.length; j++) {
		                                        if (Ord.Items[i].Mods[j].HalfStatus == 0) {
		                                            if (Ord.Items[i].Mods[j].OrigPrice > 0) {
		                                                ColIdx += 1;
		                                                if (ColIdx == RoundupIdx) {
		                                                    Ord.Items[i].Mods[j].Roundup = true;
		                                                    break;
		                                                }// end if
		                                            }// end if
		                                        }// end if
		                                    }// end for
		                                }// end if
		
		                            }
		                            else {
		                                for (HalfSortIdx = 2; HalfSortIdx >= 1; HalfSortIdx--) {
		                                    for (j = Ord.Items[i].Mods.length - 1; j >= 0; j--) {
		                                        if (Ord.Items[i].Mods[j].HalfStatus == HalfSortIdx) {
		                                            if (Ord.Items[i].Mods[j].OrigPrice > 0) {
		                                                Ord.Items[i].Mods[j].Roundup = true;
		                                                halfFound = true;
		                                                break;
		                                            }// end if
		                                        } // end if
		                                    }// end for
		                                    if (halfFound) {
		                                        break;
		                                    }
		                                }// end for
		                            } // end if
		                        } // end if
		                    } // end if
		                } //end if
		
		                Offset = -0.001;
		                Offset2nd = -0.001;
                        for (HalfSortIdx = 0; HalfSortIdx < 3; HalfSortIdx++) {
                            localVars.curModValue = 0;
                            localVars.curMod2ndValue = 0;
		                    for (j = 0; j < Ord.Items[i].Mods.length; j++) {
		                        if (Ord.Items[i].Mods[j].IsPreSel && Ord.Items[i].Mods[j].IsLite) {
		                            Ord.Items[i].Mods[j].NoStdMod = true;
		                            Ord.Items[i].Mods[j].OrigPrice = 0;
		                            Ord.Items[i].Mods[j].Orig2ndPrice = 0;
		                            Ord.Items[i].Mods[j].ActivePrice = 0;
		                            Ord.Items[i].Mods[j].Active2ndPrice = 0;
		                            Ord.Items[i].Mods[j].HalfPrice = 0;
		                        }
		                        if (Ord.Items[i].Mods[j].HalfStatus == HalfSortIdx) {
		                            Ord.Items[i].Mods[j].CpnAmt = 0;
		                            Ti.API.debug('UseStd: ' + UseStd);
		                            Ti.API.debug('Ord.Items[i].Mods[j].Name - NoStdMod: ' + Ord.Items[i].Mods[j].NoStdMod);
		                            if (UseStd && !Ord.Items[i].Mods[j].NoStdMod) {
		                                curPortion = 0;
		                                iModQty = Ord.Items[i].Mods[j].Qty;
		                                if (HalfSortIdx > 0) {
		                                    if (PSRmvCnt < 0) {
		                                        if (iModQty > 1) {
		                                            if (Ord.Items[i].Mods[j].Roundup) {
		                                                iModQty += 1;
		                                            }
		                                            if (Ord.Items[i].Mods[j].IsPreSel) {
		                                                iModQty -= 1;
		                                            }
		                                            dcPortion = 0;
		                                            for (k = 1; k <= iModQty; k++) {
		                                                if (PSRmvCnt < 0) {
		                                                    PSRmvCnt += 0.5;
		                                                }
		                                                else {
		                                                    Offset = -Offset;
		                                                    modStdCnt += 0.5;
		                                                    if (modStdCnt % 1 == 0) {
		                                                        modEffCnt = modStdCnt;
		                                                    }
		                                                    else {
		                                                        modEffCnt = modStdCnt + 0.5;
		                                                    }
		                                                    //if (!IsLastModPrice){
		                                                    if (!obj.IsLastModPrice) {
		                                                        if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                            curPortion = GetStdModPrice(modEffCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                            dcPortion += Math.round((curPortion + Offset) * 100 / 2) / 100;
		                                                            lastModPrice = curPortion;
		                                                        }// end if
		                                                    } // end if
		                                                    else {
		                                                        dcPortion += Math.round((lastModPrice + Offset) * 100 / 2) / 100;
		                                                    }
		                                                }// end if
		                                            }// end for
		                                        }// end if
		                                        else {
		                                            dcPortion = 0;
		                                            PSRmvCnt += 0.5;
		                                        }
		                                    }// end if
		                                    else {
		                                        if (iModQty > 1) {
		                                            if (Ord.Items[i].Mods[j].Roundup) {
		                                                iModQty += 1;
		                                            }
		                                            if (Ord.Items[i].Mods[j].IsPreSel) {
		                                                iModQty -= 1;
		                                            }
		                                            dcPortion = 0;
		                                            for (k = 1; k <= iModQty; k++) {
		                                                Offset = -Offset;
		                                                modStdCnt += 0.5;
		                                                if (modStdCnt % 1 == 0) {
		                                                    modEffCnt = modStdCnt;
		                                                }
		                                                else {
		                                                    modEffCnt = modStdCnt + 0.5;
		                                                }
		                                                //if (!IsLastModPrice){
		                                                if (!obj.IsLastModPrice) {
		                                                    if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                        curPortion = GetStdModPrice(modEffCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                        dcPortion += Math.round((curPortion + Offset) * 100 / 2) / 100;
		                                                        lastModPrice = curPortion;
		                                                    }// end if
		                                                }// end if
		                                                else {
		                                                    dcPortion += Math.round((lastModPrice + Offset) * 100 / 2) / 100;
		                                                }
		                                            }// end for
		                                        }// end if
		                                        else {
		                                            Offset = -Offset;
		                                            modStdCnt += 0.5;
		                                            if (modStdCnt % 1 == 0) {
		                                                modEffCnt = modStdCnt;
		                                            }
		                                            else {
		                                                modEffCnt = modStdCnt + 0.5;
		                                            }
		                                            //if (!IsLastModPrice){
		                                            if (!obj.IsLastModPrice) {
		                                                if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                    curPortion = GetStdModPrice(modEffCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                }
		                                                if (Ord.Items[i].Mods[j].Roundup) {
		                                                    dcPortion = curPortion;
		                                                }
		                                                else {
		                                                    dcPortion = Math.round((curPortion + Offset) * 100 / 2) / 100;
		                                                }
		
		                                                lastModPrice = curPortion;
		                                            }// end if
		                                            else {
		                                                if (Ord.Items[i].Mods[j].Roundup) {
		                                                    dcPortion = lastModPrice;
		                                                }
		                                                else {
		                                                    dcPortion = Math.round((lastModPrice + Offset) * 100 / 2) / 100;
		                                                }
		                                            }
		                                        }
		
		                                    }
		                                }
		                                else {
		                                    if (PSRmvCnt < 0) {
		                                    	Ti.API.debug('PSRmvCnt: ' + PSRmvCnt);
		                                        if (iModQty > 1) {
		                                        	Ti.API.debug('iModQty: ' + iModQty);
		                                            if (Ord.Items[i].Mods[j].IsPreSel) {
		                                                iModQty -= 1;
		                                            }
		                                            dcPortion = 0;
		                                            for (k = 1; k <= iModQty; k++) {
		                                                if (PSRmvCnt == -0.5) {
		                                                    modStdCnt += 1;
		                                                    Offset = -Offset;
		                                                    if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                    	Ti.API.debug('modStdCnt: ' + modStdCnt);
		                                                        curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                        lastModPrice = curPortion;
		                                                        PSRmvCnt = 0;
		                                                    }// end if
		                                                    if (Ord.Items[i].Mods[j].Roundup) {
		                                                        dcPortion = curPortion;
		                                                    }
		                                                    else {
		                                                        dcPortion = Math.round((curPortion + Offset) * 100 / 2) / 100;
		                                                    }
		
		                                                }// end if
		                                                else if (PSRmvCnt < 0) {
		                                                	Ti.API.debug('2-PSRmvCnt: ' + PSRmvCnt);
		                                                    PSRmvCnt += 1;
		                                                }
		                                                else {
		                                                    modStdCnt += 1;
		                                                    //if (!IsLastModPrice){
		                                                    if (!obj.IsLastModPrice) {
		                                                        if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                        	Ti.API.debug('2-modStdCnt: ' + modStdCnt);
		                                                            curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                            lastModPrice = dcPortion;
		                                                        }
		                                                    }// end if
		                                                    else {
		                                                        curPortion = lastModPrice;
		                                                    }
		                                                    dcPortion += curPortion;
		                                                }
		                                            }// end for
		                                        }
		                                        else {
		                                        	Ti.API.debug('ELSE - iModQty: ' + iModQty);
		                                            if (PSRmvCnt == -0.5) {
		                                                modStdCnt += 1;
		                                                Offset = -Offset;
		                                                if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                    curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                    lastModPrice = curPortion;
		                                                    PSRmvCnt = 0;
		                                                }
		                                                if (Ord.Items[i].Mods[j].Roundup) {
		                                                    dcPortion = curPortion;
		                                                }
		                                                else {
		                                                    dcPortion = Math.round((curPortion + Offset) * 100 / 2) / 100;
		                                                }
		                                            }
		                                            else {
		                                                dcPortion = 0;
		                                                PSRmvCnt += 1;
		                                            }
		                                        }
		                                    }// end if
		                                    else {
		                                    	Ti.API.debug('ELSE - PSRmvCnt: ' + PSRmvCnt);
		                                        if (iModQty > 1) {
		                                        	Ti.API.debug('ifif - iModQty: ' + iModQty);
		                                            if (Ord.Items[i].Mods[j].IsPreSel) {
		                                                iModQty -= 1;
		                                                Ti.API.debug('ififif - iModQty: ' + iModQty);
		                                            }
		                                            dcPortion = 0;
		                                            for (k = 1; k <= iModQty; k++) {
		                                                modStdCnt += 1;
		                                                //if (!IsLastModPrice){
		                                                if (!obj.IsLastModPrice) {
		                                                    if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                        curPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                        lastModPrice = curPortion;
		                                                        dcPortion += curPortion;
		                                                    }
		                                                }
		                                                else {
		                                                    dcPortion += lastModPrice;
		                                                }
		                                            } // end for
		                                        }// end if
		                                        else {
		                                            modStdCnt += 1;
		                                            //if (!IsLastModPrice){
		                                            if (!obj.IsLastModPrice) {
		                                                if (Menu.Groups[ItmGrpIdx].StdMods != null) {
		                                                    dcPortion = GetStdModPrice(modStdCnt, ItmGrpIdx, ItmSzIdx, obj);//IsLastModPrice
		                                                    lastModPrice = dcPortion;
		                                                }
		                                            }
		                                            else {
		                                                dcPortion = lastModPrice;
		                                            }
		                                        }
		                                    }
		                                }
		
		                                Ord.Items[i].Mods[j].ActivePrice = dcPortion * iItemQty;
		                                if (UseTier) {
		                                    if (Tier2ndStdMods) {
		                                        Ord.Items[i].Mods[j].Active2ndPrice = Ord.Items[i].Mods[j].ActivePrice;
		                                        Ord.Items[i].Mods[j].Display2ndPrice = Ord.Items[i].Mods[j].Active2ndPrice;
		                                    }
		                                }
		                                iModQty = Ord.Items[i].Mods[j].Qty;
		                            }// end if
		                            else {// Standard Mod Pricing not used.
		                                if (HalfSortIdx > 0) {
		                                    iModQty = Ord.Items[i].Mods[j].Qty;
		                                    if (iModQty > 1) {
		                                        var iChgQty = iModQty;
		                                        if (Ord.Items[i].Mods[j].IsPreSel) {
		                                            iChgQty = iModQty - 1;
		                                        }
		                                        if (mostExpHalf > 0) {
		                                            if (mostExpHalf == HalfSortIdx) {
		                                                dcPortion = Ord.Items[i].Mods[j].OrigPrice * iChgQty;
		                                                if (SecondApplies) {
		                                                    dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice * iChgQty;
		                                                }
		                                            }// end if
		                                            else {
		                                                dcPortion = 0;
		                                                dcPortion2nd = 0;
		                                            }
		                                        }//end if
		                                        else {
		                                            if (Ord.Items[i].Mods[j].Roundup) {
		                                                iChgQty += 1;
		                                            }
		                                            if (iChgQty % 2 == 0) {
		                                                if (Ord.Items[i].Mods[j].HalfPrice > 0 && UseHalfPrice) {
		                                                    dcPortion = Ord.Items[i].Mods[j].HalfPrice * iChgQty;
		                                                }
		                                                else {
		                                                    dcPortion = Ord.Items[i].Mods[j].OrigPrice * (iChgQty / 2);
		                                                    if (SecondApplies) {
		                                                        dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice * (iChgQty / 2);
		                                                    }
		                                                }
		
		                                            }// end if
		                                            else {
		                                                if (Ord.Items[i].Mods[j].HalfPrice > 0 && UseHalfPrice) {
		                                                    dcPortion = Ord.Items[i].Mods[j].HalfPrice * iChgQty;
		                                                }
		                                                else {
		                                                    Offset = -Offset;
		                                                    if (iChgQty > 1) {
		                                                        dcPortion = Ord.Items[i].Mods[j].OrigPrice * ((iChgQty - 1) / 2);
		                                                        dcPortion += Math.round((Ord.Items[i].Mods[j].OrigPrice + Offset) * 100 / 2) / 100;
		                                                    }//end if
		                                                    else {
		                                                        dcPortion = Math.round((Ord.Items[i].Mods[j].OrigPrice + Offset) * 100 / 2) / 100;
		                                                    }
		                                                    if (SecondApplies) {
		                                                        Offset2nd = -Offset2nd;
		                                                        if (iChgQty > 1) {
		                                                            dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice * ((iChgQty - 1) / 2);
		                                                            dcPortion2nd += Math.round((Ord.Items[i].Mods[j].Orig2ndPrice + Offset2nd) * 100 / 2) / 100;
		                                                        }// end if
		                                                        else {
		                                                            dcPortion2nd = Math.round((Ord.Items[i].Mods[j].Orig2ndPrice + Offset2nd) * 100 / 2) / 100;
		                                                        }
		                                                    }
		                                                }
		                                            }
		                                        }
		                                    }// end if
		                                    else {
		                                        if (Ord.Items[i].Mods[j].OrigPrice != 0) {
		                                            if (mostExpHalf > 0) {
		                                                if (mostExpHalf == HalfSortIdx) {
		                                                    dcPortion = Ord.Items[i].Mods[j].OrigPrice;
		                                                    if (SecondApplies) {
		                                                        dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice;
		                                                    }
		                                                }// end if
		                                                else {
		                                                    dcPortion = 0;
		                                                    dcPortion2nd = 0;
		                                                }
		                                            }// end if
		                                            else {
		                                                if (Ord.Items[i].Mods[j].Roundup) {
		                                                    dcPortion = Ord.Items[i].Mods[j].OrigPrice;
		                                                    if (SecondApplies) {
		                                                        dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice;
		                                                    }
		                                                }
		                                                else {
		                                                    if (Ord.Items[i].Mods[j].HalfPrice > 0 && UseHalfPrice) {
		                                                        dcPortion = Ord.Items[i].Mods[j].HalfPrice;
		                                                    }
		                                                    else {
		                                                        Offset = -Offset;
		                                                        dcPortion = Math.round((Ord.Items[i].Mods[j].OrigPrice + Offset) * 100 / 2) / 100;
		                                                        if (SecondApplies) {
		                                                            Offset2nd = -Offset2nd;
		                                                            dcPortion2nd = Math.round((Ord.Items[i].Mods[j].Orig2ndPrice + Offset2nd) * 100 / 2) / 100;
		                                                        }
		                                                    }
		                                                }
		                                            }
		                                        }// end if
		                                        else {
		                                            dcPortion = 0;
		                                            dcPortion2nd = 0;
		                                        }
		                                    }
		                                }// end if
		                                else {
		                                    //Ti.API.debug('No Std Mods & HalfSortIdx =0 : '+ HalfSortIdx);
		                                    //Ti.API.debug('OrigPrice: '+ Ord.Items[i].Mods[j].OrigPrice);
		                                    //Ti.API.debug('SecondApplies: '+ SecondApplies);
		
		                                    dcPortion = Ord.Items[i].Mods[j].OrigPrice;
		                                    if (SecondApplies) {
		                                        dcPortion2nd = Ord.Items[i].Mods[j].Orig2ndPrice;
		                                    }
		                                    iModQty = Ord.Items[i].Mods[j].Qty;
		                                    var preSelHalf = 2;
		                                    if (mostExpHalf > 0) {
		
		                                    }// end if
		                                    if (Ord.Items[i].Mods[j].IsPreSel) {
		                                        dcPortion = dcPortion * (iModQty - 1);
		                                        if (SecondApplies) {
		                                            dcPortion2nd = dcPortion2nd * (iModQty - 1);
		                                        }
		                                    }// end if
		                                    else {
		                                        dcPortion = dcPortion * iModQty;
		                                        if (SecondApplies) {
		                                            dcPortion2nd = dcPortion2nd * iModQty;
		                                        }
		                                    }
		                                }
		                                //Ti.API.debug('dcPortion: '+ dcPortion);
		                                //Ti.API.debug('iItemQty: '+ iItemQty);
		
		                                Ord.Items[i].Mods[j].ActivePrice = dcPortion * iItemQty;
		                                if (SecondApplies) {
		                                    Ord.Items[i].Mods[j].Active2ndPrice = dcPortion2nd;
		                                    if (Ord.Items[i].NoMod2ndValue > 0) {
		                                        if (!Ord.Items[i].Mods[j].PriceApplies) {
		                                            if (Ord.Items[i].Mods[j].Roundup && Ord.Items[i].Mods[j].HalfStatus == 0) {
		                                                if (Ord.Items[i].NoMod2ndvalue <= Ord.Items[i].Mods[j].Active2ndPrice) {
		                                                    Ord.Items[i].NoMod2ndvalue = 0;
		                                                }
		                                            }// end if
		                                            else {
		                                                if (Ord.Items[i].NoMod2ndValue >= Ord.Items[i].Mods[j].Active2ndPrice) {
		                                                    //Ord.Items[i].NoMod2ndValue -= Ord.Items[i].Mods[j].Active2ndPrice;
		                                                    Ord.Items[i].NoMod2ndValue = Math.round((Ord.Items[i].NoMod2ndValue - Ord.Items[i].Mods[j].Active2ndPrice) * 100) / 100;
		                                                    Ord.Items[i].Mods[j].Active2ndPrice = 0;
		                                                }
		                                                else {
		                                                    //Ord.Items[i].Mods[j].Active2ndPrice -= Ord.Items[i].NoMod2ndValue;
		                                                    Ord.Items[i].Mods[j].Active2ndPrice = Math.round((Ord.Items[i].Mods[j].Active2ndPrice - Ord.Items[i].NoMod2ndValue) * 100) / 100;
		                                                    Ord.Items[i].NoMod2ndValue = 0;
		                                                }
		                                            }
		                                        }// end if
		                                    }// end if
		                                    Ord.Items[i].Mods[j].Display2ndPrice = Ord.Items[i].Mods[j].Active2ndPrice;
		                                }// end if
		
		                                if (Ord.Items[i].NoModValue > 0) {
		                                    if (!Ord.Items[i].Mods[j].PriceApplies) {
		                                        if (Ord.Items[i].Mods[j].Roundup && Ord.Items[i].Mods[j].HalfStatus == 0) {
		                                            if (Ord.Items[i].NoModValue <= Ord.Items[i].Mods[j].ActivePrice) {
		                                                Ord.Items[i].NoModValue = 0;
		                                            }
		                                        }// end if
		                                        else {
		                                            if (Ord.Items[i].NoModValue >= Ord.Items[i].Mods[j].ActivePrice) {
		                                                Ord.Items[i].NoModValue = Math.round((Ord.Items[i].NoModValue - Ord.Items[i].Mods[j].ActivePrice) * 100) / 100;
		                                                //Ord.Items[i].NoModValue -= Ord.Items[i].Mods[j].ActivePrice;
		                                                Ord.Items[i].Mods[j].ActivePrice = 0;
		                                                //Ti.API.debug('******** No Mod Value' + + Ord.Items[i].NoModValue);
		                                            }
		                                            else {
		                                                //Ord.Items[i].Mods[j].ActivePrice -= Ord.Items[i].NoModValue;
		                                                Ord.Items[i].Mods[j].ActivePrice = Math.round((Ord.Items[i].Mods[j].ActivePrice - Ord.Items[i].NoModValue) * 100) / 100;
		                                                Ord.Items[i].NoModValue = 0;
		                                            }
		                                        }
		                                    }//end if
		                                }// end if
		                            }// end if
		
		                            Ord.Items[i].Mods[j].DisplayPrice = Ord.Items[i].Mods[j].ActivePrice;
		                            Ord.Items[i].InclusivePrice = Math.round((Ord.Items[i].InclusivePrice + Ord.Items[i].Mods[j].ActivePrice) * 100) / 100;
		
		                            if (blnItmCpn) {
		                                setItemCpnPrefsMods(Ord.Items[i], 1, localVars, Ord.Items[i].Mods[j], true);
		                            }
		                            Ord.Items[i].RollupPrice = Math.round((Ord.Items[i].RollupPrice + Ord.Items[i].Mods[j].ActivePrice) * 100) / 100;
		                            if (useRollup) {
		                                Ord.Items[i].Mods[j].DisplayPrice = 0;
		                            }
		                            if (SecondApplies) {
		                                if (blnItmCpn) {
		                                    setItemCpnPrefsMods(Ord.Items[i], 3, localVars, Ord.Items[i].Mods[j], true);
		                                }
		                                if (useRollup) {
		                                    Ord.Items[i].Rollup2ndPrice = Math.round((Ord.Items[i].Rollup2ndPrice + Ord.Items[i].Mods[j].Active2ndPrice) * 100) / 100;
		                                    Ord.Items[i].Mods[j].Display2ndPrice = 0;
		                                }
		                            }// end if
		
		                            dcSubTotal += Ord.Items[i].Mods[j].ActivePrice;
		                            //Ti.API.debug(Ord.Items[i].Mods[j].Name + ': '+ Ord.Items[i].Mods[j].ActivePrice  + ' , SubTotal: ' + dcSubTotal);
		                            if (Ord.Items[i].Mods[j].TaxType != "None") {
		                                AddTax(Ord.Items[i].Mods[j].TaxType, Ord.Items[i].Mods[j].ActivePrice);
		                            }
		                        }// end if
		                    }// end for
		                }//end for
		            } // end if
		            ////////////////
		
		            if (useRollup) {
		                Ord.Items[i].DisplayPrice = Ord.Items[i].RollupPrice;
		            }
		
		
		        }// end for
		
		        if (Cnt2ndItm > 1) {
		            dcSubTotal -= Set2ndItmPrice();
		        }
		
		
		        if (Ord.Cpns) {
		            //Validate PickAny
		            for (i = Ord.Cpns.length - 1; i >= 0 ; i--) {
		                if (parseInt(Ord.Cpns[i].CpnScope, 10) == 3 && Ord.Cpns[i].PickAnyCnt && Ord.Cpns[i].PickAnyCnt > 0) {
		                    Ord.Cpns[i].CpnActiveValue = Ord.Cpns[i].CpnValue;
		                    if (ValidateMultiCpnPickAny(Ord.Cpns[i])) {
		                        for (j = 0; j < Ord.Items.length; j++) {
		                            if (Ord.Items[j].CpnApplied == 1) {
		                                Ord.Items[j].CpnApplied = 2;
		                            }
		                            //Ti.API.debug('********* CpnApplied For: ' + Ord.Items[j].Name + ' : ' + Ord.Items[j].CpnApplied);
		                        }// end for
		                        if (Ord.Cpns[i].FreeDlvy) {
		                            freeDlvy = true;
		                        }
		                        if (Ord.Cpns[i].DlvyFeeIfZero) {
		                            dlvyFeeIfZero = true;
		                        }
		                    }
		                    else {
		                        RemoveMultiCpn(Ord.Cpns[i].RcptName, i);
		                    }
		                }
		            }
		            //Validate Multi Item Cpns
		            for (i = Ord.Cpns.length -1; i >=0 ; i--) {
		                //Multi Item Cpn
		                if (parseInt(Ord.Cpns[i].CpnScope, 10) == 3 && (!Ord.Cpns[i].PickAnyCnt || Ord.Cpns[i].PickAnyCnt == 0)) {
		                    Ord.Cpns[i].CpnActiveValue = Ord.Cpns[i].CpnValue;
		                    if (ValidateMultiCpn(Ord.Cpns[i], 0)) {
		                        var remCpn = false;
		                        if (Ord.Cpns[i].MultiQualTtl > 0) {
		                            var deduction = 0;
		                            var itmIdx = 0;
		                            for (itmIdx = 0; itmIdx < Ord.Items.length; itmIdx++) {
		                                if (Ord.Items[itmIdx].CpnApplied == 1) {
		                                    deduction += Ord.Items[itmIdx].RollupPrice;
		                                }
		                            }
		                            remCpn = ((dcSubTotal-deduction) < Ord.Cpns[i].MultiQualTtl);
		                        }
		                        if (!remCpn) {
		                            for (j = 0; j < Ord.Items.length; j++) {
		                                if (Ord.Items[j].CpnApplied == 1) {
		                                    Ord.Items[j].CpnApplied = 2;
		                                }
		                                //Ti.API.debug('********* CpnApplied For: ' + Ord.Items[j].Name + ' : ' + Ord.Items[j].CpnApplied);
		                            }// end for
		                            if (Ord.Cpns[i].FreeDlvy) {
		                                freeDlvy = true;
		                            }
		                            if (Ord.Cpns[i].DlvyFeeIfZero) {
		                                dlvyFeeIfZero = true;
		                            }
		                        }
		                        else {
		                            RemoveMultiCpn(Ord.Cpns[i].RcptName, i);
		                        }
		                    }
		                    else {
		                        //Ti.API.debug('COUPON DELETING');
		                        RemoveMultiCpn(Ord.Cpns[i].RcptName, i);
		                    }
		                }// end if
		            }// end for
		            if (Ord.Cpns.length == 0) {
		                Ord.Cpns = null;
		            }
		        }// end if
		
		        if (Ord.Cpns) {
                    for (i = Ord.Cpns.length-1; i >=0; i--) {
		                switch (parseInt(Ord.Cpns[i].CpnType, 10)) {
		                    case 1:
                            case 4:
                            case 6:
                                //Amt off or Rewards or AdjItem
		                        if (parseInt(Ord.Cpns[i].CpnScope, 10) == 3) {
		                            localVars.curCpnValue = Ord.Cpns[i].CpnActiveValue;		                            
		                        }
		                        else {
		                           if (Ord.Cpns[i].CpnValue > dcSubTotal) {
		                               localVars.curCpnValue = dcSubTotal;
		                           }
		                           else {
		                               localVars.curCpnValue = Ord.Cpns[i].CpnValue;
		                           }
		                        }
		                        break;
		                        //PctOff
		                    case 2:
		                        var dcNoDisc = 0;
		                        for (j = 0; j < Ord.Items.length; j++) {
		                            if (Ord.Items[j].NoDisc) {
		                                dcNoDisc += Ord.Items[j].RollupPrice;
		                            }
		                        }// end for
		                        localVars.curCpnValue = Math.round((dcSubTotal - dcNoDisc - 0.001) * Ord.Cpns[i].CpnPct * 100) / 100;
		                        if (Ord.Cpns[i].MaxValue > 0 && localVars.curCpnValue > Ord.Cpns[i].MaxValue) {
		                            localVars.curCpnValue = Ord.Cpns[i].MaxValue;
		                        }
		                }// end switch

                        Ord.Cpns[i].CpnActiveValue = Math.round(localVars.curCpnValue * 100) / 100;
                        var isRemoved = false;
                        if (Ord.Cpns[i].CpnScope == 1 || (Ord.Cpns[i].CpnScope == 3 && Ord.Cpns[i].MultiQualTtl > 0))
                        {
                            if (dcSubTotal < Ord.Cpns[i].MinPrice) {
                                isRemoved = true;
                                RemoveMultiCpn(Ord.Cpns[i].RcptName, i);
                            }
                        }
                        if (!isRemoved) {
                            localVars.cumCpnAmt += localVars.curCpnValue;
                            if (Ord.Cpns[i].FreeDlvy) {
                                freeDlvy = true;
                            }
                            if (Ord.Cpns[i].DlvyFeeIfZero) {
                                dlvyFeeIfZero = true;
                            }
                            dcSubTotal -= localVars.curCpnValue;
                            if (Ord.Cpns[i].TaxType != "None") {
                                if (localVars.curCpnValue != 0) {
                                    AddTax(Ord.Cpns[i].TaxType, -localVars.curCpnValue);
                                }
                            }// end if
                        }		                
		            }//end for
		        }// end if
		
		        dcDlvyFee = SetDlvyFee(dcSubTotal, freeDlvy, dlvyFeeIfZero, hasDlvyFee, curOTIdx);
		        initSurcharges(dcSubTotal, surcharges);
		        var dcSurcharge = 0;
		        if (Ord.Surcharges && Ord.Surcharges.length > 0) {		            
		            for (i = 0; i < Ord.Surcharges.length; i++) {
		                dcSurcharge += Ord.Surcharges[i].ActivePrice;
		                if (Ord.Surcharges[i].TaxType !== "None") {
		                    if (Ord.Surcharges[i].ActivePrice > 0) {
		                        AddTax(Ord.Surcharges[i].TaxType, Ord.Surcharges[i].ActivePrice);
		                    }
		                }
		            }
		        }
		        //Ti.API.debug('delivery fee :' + dcDlvyFee);
		        dcTax = CalculateTax();
		
		        dcTotal = Math.round((dcSubTotal + dcGrat + dcTax + dcDlvyFee + dcSurcharge) * 100) / 100;
		        Ord.OrigTotal = Math.round((dcSubTotal + localVars.cumCpnAmt) * 100) / 100;
		        Ord.CpnAmt = localVars.cumCpnAmt;
		        Ord.Subtotal = Math.round(dcSubTotal * 100) / 100;
		        Ord.Tax = dcTax;
		        Ord.ActiveTotal = dcTotal;
		        Ord.TempDlvyFee = dcDlvyFee;
		        //Ti.API.debug('SubTotal: '+ dcSubTotal);
		        //Ti.API.debug('dcGrat: '+ dcGrat);
		        //Ti.API.debug('Tax: '+ dcTax);
		        //Ti.API.debug('Dlvy Fee: '+ dcDlvyFee);
		        //Ti.API.debug('Orig Total: '+ Ord.OrigTotal);
		        //Ti.API.debug('Active Total: '+ Ord.ActiveTotal);
		        //Ti.API.debug('OrderObj :'+ JSON.stringify(Ord));
		        if (Ti.App.ItemsSplit) {
		            //Ti.API.debug('JOIN');
		            JoinItems();
		        }
		        ro.updateCartCount(Ord.Items && Ord.Items.length ? Ord.Items.length : 0);
		        return Ord;
		    };
		
		};
		return new PricingFunctions();
	};
	return{
		pricer:pricer
	};
}();
module.exports = priceEngine;