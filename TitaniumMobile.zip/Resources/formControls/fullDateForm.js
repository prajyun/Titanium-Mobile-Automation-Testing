var DATEFORM = function(){
	var dateForm = function(ro){
		var storeObj, datePicker, hourPicker, minutePicker, delivery, open, close, currentDay, sameDay, hrInfo, hrCol, dtCol, minCol, presetVals, deferPrepTm, dispLbl, colArrObj = [];
		var MONTHS_LIST = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	   ro.getFullDateForm = function(){
		   var col1, col2, col3;
	
		   delivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
	
		   try{
		   	storeObj = ro.app.Store;
		   	//Ti.API.debug('storeObj.Hours: ' + JSON.stringify(storeObj.Hours));
		   	//Ti.API.debug('ro.app.Store.Holidays: ' + JSON.stringify(ro.app.Store.Holidays));
		   }
		   catch(ex){
		   	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('ro.app.Store-Exception: ' + ex); }
		   }
	
		   sameDay = storeObj.Configuration.AllowSameDayDefer;
		   deferPrepTm = deferMin();
		   //Ti.API.debug('deferPrepTm: ' + deferPrepTm);
	
			var pickerView = Ti.UI.createView({
				layout:'vertical',
				height:Ti.UI.SIZE,
				width:(ro.ui.properties.plWidth-ro.ui.relX(20)),
				top:ro.ui.relY(5),
				visible:false
			});
	
			var datePckr = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.SIZE,
				layout:'vertical'
			});
	
			datePckr.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         //text:'Future Order Date:',
	         text:'FUTURE DATE',
	         font:{
	            fontSize:ro.ui.scaleFont(12.5, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.futureOrderTxt
	     	})));
	
	
			var timeView = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.SIZE,
				top:ro.ui.relY(15),
				layout:'vertical'
			});
			timeView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         //text:'Future Order Time:',
	         text:'FUTURE TIME:',
	         font:{
	            fontSize:ro.ui.scaleFont(12.5, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.futureOrderTxt
	      })));
	
			var dispView = Ti.UI.createView({
				height:ro.ui.relY(40),
				width:Ti.UI.SIZE,
				left:ro.ui.relX(15),
				top:ro.ui.relY(1),
				visible:false
			});
			dispLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:'',
	         left:ro.ui.relX(0),
	         font:{
	            fontSize:ro.ui.scaleFont(9.5, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.separatorColor
	      }));
			dispView.add(dispLbl);
	
			/*var submitBtn = Ti.UI.createButton(ro.combine(ro.ui.properties.submitBtn, {title:'Choose & Continue'}));
			submitBtn.addEventListener('click', function(e){
				try{
					var datePickRow, hourPickRow, minPickRow;
					datePickRow = datePicker.getSelectedRow(0);
					hourPickRow = hourPicker.getSelectedRow(0);
					minPickRow = minutePicker.getSelectedRow(0);
	
	      		var savedData = {
		      		dateRow:datePickRow.index,
		      		hourRow:hourPickRow.index,
		      		minuteRow:minPickRow.index,
		      		displayTxt:dispLbl.text
		      	};
		      	ro.utils.setStrProp('futureOrder', savedData);
	
		      	payControl.setFutureOrder({
		      		DeferPrepMin:deferPrepTm,
		      		storeTmFuture:convertToStoreTm({
		      			year:colArrObj[datePickRow.index].Value.year,
			      		month:colArrObj[datePickRow.index].Value.month,
			      		day:colArrObj[datePickRow.index].Value.day,
			      		hours:colArrObj[datePickRow.index].Hours[hourPickRow.index].milValue,
			      		minutes:colArrObj[datePickRow.index].Hours[hourPickRow.index].Min[minPickRow.index].Value
		      		})
		      	});
	
		      	if(Ti.App.atPayScrn === true){
						ro.ui.cartShowNext({ addView:true, showing:'paymentScreen' });
					}
					else{
						ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
					}
		      }
		      catch(ex){
		      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('submitBtnEvent-Exception: ' + ex); }
		      }
			});*/
	
			var otherPckr = Ti.UI.createView({
				layout:'horizontal',
				height:Ti.UI.SIZE,
				width:Ti.UI.SIZE
			});
	      datePicker = Ti.UI.createPicker({
	         width:'70%',
	         height:ro.ui.relY(40),
	         borderRadius:ro.ui.relX(3),
	         backgroundColor:ro.ui.theme.pickerColor
	      });
	      hourPicker = Ti.UI.createPicker({
	         width:'34%',
	         height:ro.ui.relY(40),
	         borderRadius:ro.ui.relX(3),
	         backgroundColor:ro.ui.theme.pickerColor
	      });
	      minutePicker = Ti.UI.createPicker({
	         width:'34%',
	         height:ro.ui.relY(40),
	         borderRadius:ro.ui.relX(3),
	         backgroundColor:ro.ui.theme.pickerColor
	      });
	
	      if(Ti.App.Properties.hasProperty('DefaultStore')){
	      	if(Ti.App.TimeAtDefStore && Ti.App.TimeAtDefStore !== null){
	      		storeObj.TimeAtStore = Ti.App.TimeAtDefStore;
	      	}
	      }
			var date = new Date(storeObj.TimeAtStore);
	
			function createMins(e){
				try{
		   		var timeObj = deferHour(deferPrepTm, e.curDy, e.index);
		   		
		   		
		   		/*if((timeObj.minute + deferPrepTm) > 59 && e.curDy != 0 && e.index == 0){
		   		   return false;
		   		}*/
		   		
		   		var beginMin = 0;
		   		if(e.index === 0){
		   			beginMin = timeObj.minute;
		   		}
		   		if(e.newBeginMin){
		   		   beginMin = e.newBeginMin;
		   		}
	
		   		var defMin = storeObj.Configuration.DeferInt || 5;
		   		var indexx = 0, minsArr = [];
	
					if(beginMin < 0){//	this is a filler fix for minute picker showing negative numbers
						if(e.index !==0){
							beginMin = 0;
						}
						else{
							beginMin = ((beginMin)/(-1));
						}
					}
					var minLim = e.minuteLimit;
					var finalBeginMin = beginMin;
					if(e.holiday){
					   //Ti.API.debug('e.hour: ' + e.hour);
					  // Ti.API.debug('e.today: ' + e.today);
					  // Ti.API.debug('minLim: ' + minLim);
					   minLim = holidayFixCloseMinute(minLim, e.hour, e.today);
					   finalBeginMin = holidayFixOpenMinute(beginMin, e.hour, e.today, deferPrepTm);
					   
					   if(finalBeginMin > 55){
					      //return [];
					      return finalBeginMin>60 ? roundMins(finalBeginMin-60) : [];
					   }
					  // Ti.API.debug('minLim-AfterFix: ' + minLim);
					   if(e.curDy === 0 && e.index === 0){
	                  //beginMin = holidayFixOpenMinute();
	                //  Ti.API.debug('beginMin: ' + beginMin);
	               }
					}
	
		   		for(var i=finalBeginMin; i<minLim; i+=defMin){
			         if(i<10){
			         	minsArr.push({
			         		Display:'0'+i,
			         		Value:i
			         	});
			         }
			         else{
			         	minsArr.push({
			         		Display:i,
			         		Value:i
			         	});
			         }
			         indexx++;
		      	}
		      	/*if((beginMin == minLim) && (minsArr.length === 0)){
		      	   minsArr.push({
	                  Display:'00',
	                  Value:0
	               });
		      	}*/
		      	if(minsArr.length === 0){
		      		minsArr.push({
		         		Display:'00',
		         		Value:0
		         	});
		      	}
		      	Ti.API.debug('minsArr: ' + JSON.stringify(minsArr));
		      	return minsArr;
		      	
		      }
		      catch(ex){
		      	if(Ti.App.DEBUGBOOL) { Ti.API.debug('createMins()-Exception: ' + ex); }
		      }
			}
			function createHrs(e, isHoliday, currDayObj){
				try{
			      var currentRow = e.index;
			      
			      var origOpn = fixHour(open)[1];
			      //Ti.API.debug('origOpn: ' + origOpn);
			      //Ti.API.debug('BEFORE-open: ' + open);
			      open = deferHour(deferPrepTm, currentRow, 0).timeString;
			      //Ti.API.debug('open: ' + open);
	
			   	var opnArr = fixHour(open);
			   	//Ti.API.debug('opnArr: ' + opnArr);
			   	
			   	var clsHrArr = fixHour(close);
			   	var opn = opnArr[0];
			   	
			   	var clsHr = clsHrArr[0];
					var hrsArr = [], toMin;
	
					if(isHoliday){
					   opn = holidayFixOpenHour(opn, currDayObj);
	   				clsHr = holidayFixCloseHour(clsHr, currDayObj);
	            }
	
			   	if(clsHr < opn){
		   			clsHr += 24;
		   		}
		   		var thisBeginMin = null;
		   		var indexx = 0, hrTxt;
			      for(var openCtr = opn; openCtr<=clsHr; openCtr++){
			      	hrTxt = formatHrTxt(openCtr);
			      	toMin = {
			      	   today:currDayObj,
			      	   holiday:isHoliday,
			         	hour:openCtr,
			         	minuteLimit:(openCtr===clsHr)?clsHrArr[1]:60,
			         	index:indexx,
			         	curDy:e.index,
			         	dispHr:hrTxt.tm,
			         	dayInd:hrTxt.dayInd
			      	};
			      	if(!isHoliday){
			      	   var mns = createMins(toMin);
			      	   if(!mns){
			      	      continue;
			      	   }
	   		      	hrsArr.push({
	   		      		Display:hrTxt.title,
	   		      		Value:hrTxt.tm,
	   		      		milValue:hrTxt.milTm,
	   		      		Min:mns,
	   		      		dayInd:hrTxt.dayInd
	   		      	});
	   		      	indexx++;
	   		      }
	   		      else{
	   		         if(isValidHolidayHour(hrTxt.milTm, currDayObj)){
	   		            if(thisBeginMin !== null){
	   		               toMin.newBeginMin = thisBeginMin;
	   		               thisBeginMin = null;
	   		            }
	   		            var mns = createMins(toMin);
	   		            if(!isNaN(mns)){
	   		               thisBeginMin = mns;
	   		               if(openCtr==clsHr){
	   		                  thisBeginMin = null;
	   		               }
	   		               continue;
	   		            }
	                     else if(!mns || !mns.length){
	                        continue;
	                     }
	   		            hrsArr.push({
	   		               //holiday:true,
	   		               //theBeginMin:thisBeginMin,
	                        Display:hrTxt.title,
	                        Value:hrTxt.tm,
	                        milValue:hrTxt.milTm,
	                        Min:mns,//createMins(toMin),
	                        dayInd:hrTxt.dayInd
	                     });
	                     indexx++;
	   		         }
	   		         else{
	   		            Ti.API.debug('hrTxt.milTm was not within the holiday hours: ' + hrTxt.milTm);
	   		         }
	   		      }
			         //indexx++;
			      }
			      Ti.API.debug('hrsArr: ' + JSON.stringify(hrsArr));
			      return hrsArr;
			   }
			   catch(ex){
			   	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('createHrs()-Exception: ' + ex); }
			   }
			}
			function createColumns(){
		      var finalDate = 7, beginDate = 0, msDay = 86400000, d, weekday, month, today, day, year, dayNum, toHrs, extraDays = 0;
	
		      if(storeObj.Configuration.AllowFutureOrders !== true){
		      	finalDate = 1;
		      }
		      
		      if(sameDay !== true){
		      	beginDate = 1;
		      	if(finalDate !== 1){
		      		extraDays++;
		      	}
		      }
	
		      var excludeToday = 0;
		      var isHolidayBln = false;
	
		      for(var i=beginDate; i<(finalDate + extraDays); i++){
	
		      	d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	
		         dayNum = d.getDay();
		         currentDay = dayNum;
		         open = getOpenTime(i);
			   	close = getCloseTime(i);
	
	            var skipTodayBln = false;
	
			   	if(Ti.App.futureOnly && i === 0){
			   		var clsshr = close.substring(0, close.lastIndexOf(':'));
			   		var opnhr = open.substring(0, open.lastIndexOf(':'));
			   		if(clsshr < opnhr){
			   			clsshr+=24;
			   		}
	
		      		if(d.getUTCHours() > clsshr){
	                  if(isHoliday(d)){
	                     if(skipTodayHoliday(deferPrepTm, i, d)){
	                        excludeToday = 1;
	                        d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	                        dayNum = d.getDay();
	                        currentDay = dayNum;
	                        open = getOpenTime();
	                        close = getCloseTime();
	                     }
	                  }
	                  else{
	                     excludeToday = 1;
	                     d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	                     dayNum = d.getDay();
	                     currentDay = dayNum;
	                     open = getOpenTime();
	                     close = getCloseTime();
	                  }
		      		}
		      	}
		      	
		         if(open === close){
		         	if(finalDate !== 1){
		         		extraDays++;
		         	}
		         	continue;
		         }
		         if(i === beginDate){
		         	if(skipToday(deferPrepTm, close, open, i)){
		         		if(finalDate !== 1){
			         		extraDays++;
			         	}
		         		skipTodayBln = true;
		         		if(isHoliday(d)){
		         		   if(skipTodayHoliday(deferPrepTm, i, d)){
		         		      continue;
		         		   }
		         		}
		         		else{
		         		   continue;
		         		}
		         	}
		         	else{
		         	   if(isHoliday(d)){
	                     if(skipTodayHoliday(deferPrepTm, i, d)){
	                        if(finalDate !== 1){
	                           extraDays++;
	                        }
	                        continue;
	                     }
	                  }
		         	}
		         }
		         isHolidayBln = false;
		         if(isHoliday(d)){
	   	         if(isClosedAllDay(d)){
	   	            if(finalDate !== 1){
	                     extraDays++;
	                  }
	                  continue;
	   	         }
	   	         isHolidayBln = true;
	   	      }
	
		         day = d.getDate();
		         weekday = d.getUTCDay();
		         month = d.getMonth();
		         year = d.getFullYear();
		         today = MONTHS_LIST[month] + ' ' + day + ', ' + year;
	
		         toHrs = {
			         currDay:day,
			         currMonthNum:month,
			         currMonth:MONTHS_LIST[month],
			         currYear:year,
			         day:dayNum,
			         index:i
			      };
			      var theHours = createHrs(toHrs, isHolidayBln, d);
			      if(isHolidayBln){
			         if(!theHours || !theHours.length){
			            continue;
			         }
			      }
		         colArrObj.push({
			   		Display:today,
			   		Value:{
			   			year:year,
			   			month:month,
			   			day:day
			   		},
			   		Hours:theHours
			   	});
		      }
			}
	
	     	createColumns();
	     	//getDates();
	
	     	function initDt(){
	     		dtCol = Ti.UI.createPickerColumn();
	     		for(var i=0, j=colArrObj.length; i<j; i++){
	     			dtCol.addRow(Ti.UI.createPickerRow({
		            title:colArrObj[i].Display,
		            index:i
		         }));
	     		}
	     		datePicker.add([dtCol]);
	     	}
	     	function initHr(dt){
	     		hrCol = Ti.UI.createPickerColumn();
	     		for(var i=0, j=colArrObj[dt].Hours.length; i<j; i++){
	     			hrCol.addRow(Ti.UI.createPickerRow({
			            title:colArrObj[dt].Hours[i].Display,
			            index:i,
			            dtIdx:dt
			         }));
	     		}
	     		hourPicker.add([hrCol]);
	     	}
	     	function initMin(dt, hr){
	     		minCol = Ti.UI.createPickerColumn();
	     		try{
	        		for(var i=0, j=colArrObj[dt].Hours[hr].Min.length; i<j; i++){
	        			minCol.addRow(Ti.UI.createPickerRow({
			            title:colArrObj[dt].Hours[hr].Min[i].Display,
			            index:i,
			            dtIdx:dt,
			            hrIdx:hr
		         	}));
	        		}
	        	}
	        	catch(ex){
	        	   Ti.API.debug('initMin() - ex: ' + ex);
	        	}
	     		minutePicker.add([minCol]);
	     	}
	
	     	function getPickers(){
	     		var preVal = JSON.parse(Ti.App.Properties.getString('futureOrder')), preDtRow = 0, preHrRow = 0;
	
	     		if(preVal){
	     			preDtRow = preVal.dateRow;
	     			preHrRow = preVal.hourRow;
	     		}
	
	     		initDt();
	     		initHr(preDtRow);
	     		initMin(preDtRow, preHrRow);
	     		presetVals = JSON.parse(Ti.App.Properties.getString('futureOrder'));
	     	}
	     	getPickers();
	
	     	function addListeners(){
	     		datePicker.addEventListener('change', function(e){
		     		hourPicker.remove(hrCol);
		     		minutePicker.remove(minCol);
		     		initHr(e.row.index);
		     		initMin((e.row.index>6)?6:e.row.index, 0);
		     	});
		     	hourPicker.addEventListener('change', function(e){
		     		minutePicker.remove(minCol);
		     		initMin((e.row.dtIdx>6)?6:e.row.dtIdx, e.row.index);
		     	});
		     	minutePicker.addEventListener('change', function(e){
		     		try{
		     			dispLbl.text = changeDateDisplay(colArrObj, e.row) + ' at ' + colArrObj[e.row.dtIdx].Hours[e.row.hrIdx].Value + ':' + e.row.title + '' + colArrObj[e.row.dtIdx].Hours[e.row.hrIdx].dayInd;
		     		}
		     		catch(ex){
		     			if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('minutePickerEvent-Exception: ' + ex); }
		     		}
		     		ro.ui.hideLoader();
		     	});
		     	//datePicker.removeEventListener('click', addListeners);
		     	//hourPicker.removeEventListener('click', addListeners);
		     	//minutePicker.removeEventListener('click', addListeners);
		   }
	
	      try{
	     	   if(presetVals){
	     			dispLbl.text = changeDateDisplay(colArrObj, presetVals) + ' at ' + colArrObj[presetVals.dateRow].Hours[presetVals.hourRow].Value + ':' + colArrObj[presetVals.dateRow].Hours[presetVals.hourRow].Min[presetVals.minuteRow].Display + '' + colArrObj[presetVals.dateRow].Hours[presetVals.hourRow].dayInd;
	     	   }
	     	   else{
	     		  dispLbl.text = colArrObj[0].Display + ' at ' + colArrObj[0].Hours[0].Value + ':' + colArrObj[0].Hours[0].Min[0].Display + '' + colArrObj[0].Hours[0].dayInd;
	     	   }
	     	}
	      catch(ex){
	         if(Ti.App.DEBUGBOOL) { Ti.API.debug('presetVals-Exception: ' + ex); }
	      }
	
	     	/*datePicker.addEventListener('click', addListeners);
	     	hourPicker.addEventListener('click', addListeners);
	     	minutePicker.addEventListener('click', addListeners);*/
	     	addListeners();
	
	     	if(Ti.App.atPayScrn){
	     		if(presetVals){
	     			ro.ui.showLoader();
	     			datePicker.setSelectedRow(0, presetVals.dateRow, false);
	  				hourPicker.setSelectedRow(0, presetVals.hourRow, false);
	  				minutePicker.setSelectedRow(0, presetVals.minuteRow, false);
	  				presetVals.dateRow = -1;
	     		}
	     	}
	
	     	datePckr.add(datePicker);
	      otherPckr.add(hourPicker);
	      otherPckr.add(Ti.UI.createView({
	      	width:'2%',
	      	height:ro.ui.relY(1)
	      }));
	      otherPckr.add(minutePicker);
	      timeView.add(otherPckr);
	
	     	pickerView.add(datePckr);
		   pickerView.add(timeView);
	
	      return {
	      	Pick:pickerView,
	      	Display:dispView
	      };
	   };
	   ro.resetPickers = function(){
	   	try{
		   	datePicker.setSelectedRow(0, 0, false);
		   	hourPicker.setSelectedRow(0, 0, false);
		   	minutePicker.setSelectedRow(0, 0, false);
		   }
		   catch(ex){
		   	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('dateForm.resetPickers()-Exception: ' + ex); }
		   }
	   };
	   ro.submitClick = function(){
	   	try{
				var datePickRow, hourPickRow, minPickRow;
				datePickRow = datePicker.getSelectedRow(0);
				hourPickRow = hourPicker.getSelectedRow(0);
				minPickRow = minutePicker.getSelectedRow(0);
	
	   		var savedData = {
	      		dateRow:datePickRow.index,
	      		hourRow:hourPickRow.index,
	      		minuteRow:minPickRow.index,
	      		displayTxt:dispLbl.text
	      	};
	      	ro.utils.setStrProp('futureOrder', savedData);
			
			var payControl = require("controls/paymentControl");
			
	      	payControl.setFutureOrder({
	      		DeferPrepMin:deferPrepTm,
	      		storeTmFuture:convertToStoreTm({
	      			year:colArrObj[datePickRow.index].Value.year,
		      		month:colArrObj[datePickRow.index].Value.month,
		      		day:colArrObj[datePickRow.index].Value.day,
		      		hours:colArrObj[datePickRow.index].Hours[hourPickRow.index].milValue,
		      		minutes:colArrObj[datePickRow.index].Hours[hourPickRow.index].Min[minPickRow.index].Value
	      		})
	      	});
	
	      	if(Ti.App.atPayScrn === true){
					ro.ui.cartShowNext({ addView:true, showing:'paymentScreen' });
				}
				else{
					if(Ti.App.RepeatLastOrder){
					   ro.ui.ordShowNext({addView:true, showing:'itemsView'});
					}
					else{
					   ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
					}
				}
	      }
	      catch(ex){
	      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('submitBtnEvent-Exception: ' + ex); }
	      }
	   };
	   var getDates = function(){
	      var finalDate = 7, beginDate = 0, msDay = 86400000, d, weekday, month, today, day, year, dayNum, toHrs, extraDays = 0;
	
	      if(storeObj.Configuration.AllowFutureOrders !== true){
	         finalDate = 1;
	      }
	      //Ti.API.debug('sameDay: ' + sameDay);
	      if(sameDay !== true){
	         
	         beginDate = 1;
	         if(finalDate !== 1){
	            extraDays++;
	         }
	      }
	
	      var excludeToday = 0;
	
	      for(var i=beginDate; i<(finalDate + extraDays); i++){
	
	         d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	         //Ti.API.debug('new Date('+d+').toUTCString(): ' + (new Date(d).toUTCString()));
	
	         dayNum = d.getDay();
	         currentDay = dayNum;
	         open = getOpenTime(i);
	         close = getCloseTime(i);
	
	         var skipTodayBln = false;
	
	         if(Ti.App.futureOnly && i === 0){
	            var clsshr = close.substring(0, close.lastIndexOf(':'));
	            var opnhr = open.substring(0, open.lastIndexOf(':'));
	            if(clsshr < opnhr){
	               clsshr+=24;
	            }
	
	            if(d.getUTCHours() > clsshr){
	               if(isHoliday(d)){
	                  //Ti.API.debug('skipTodayHoliday is called');
	                  if(skipTodayHoliday(deferPrepTm, i, d)){
	                     //continue;
	                     //Ti.API.debug('skipTodayHoliday IS TRUE');
	                     excludeToday = 1;
	                     d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	                     dayNum = d.getDay();
	                     currentDay = dayNum;
	                     open = getOpenTime();
	                     close = getCloseTime();
	                  }
	               }
	               else{
	                  //Ti.API.debug('elseContinued');
	                  excludeToday = 1;
	                  d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	                  dayNum = d.getDay();
	                  currentDay = dayNum;
	                  open = getOpenTime();
	                  close = getCloseTime();
	                  //continue;
	               }
	               /*excludeToday = 1;
	               d = new Date(date.getTime() + (msDay * (i+excludeToday)));
	               dayNum = d.getDay();
	               currentDay = dayNum;
	               open = getOpenTime();
	               close = getCloseTime();*/
	            }
	         }
	         
	         if(i === beginDate){
	            //Ti.API.debug('open: ' + open);
	            //Ti.API.debug('close: ' + close);
	            //Ti.API.debug();
	            //Ti.API.debug();
	            //Ti.API.debug();
	         }
	         
	         if(open === close){
	            if(finalDate !== 1){
	               extraDays++;
	            }
	            continue;
	         }
	         if(i === beginDate){
	            if(skipToday(deferPrepTm, close, open, i)){
	               if(finalDate !== 1){
	                  extraDays++;
	               }
	               //continue;
	               skipTodayBln = true;
	               if(isHoliday(d)){
	                  //Ti.API.debug('skipTodayHoliday');
	                  if(skipTodayHoliday(deferPrepTm, i, d)){
	                     continue;
	                  }
	               }
	               else{
	                  //Ti.API.debug('elseContinued');
	                  continue;
	               }
	            }
	         }
	         var isHolidayBln = false;
	         if(isHoliday(d)){
	            if(isClosedAllDay(d)){
	               //Ti.API.debug('it was a closed all day');
	               if(finalDate !== 1){
	                  extraDays++;
	               }
	               continue;
	            }
	            isHolidayBln = true;
	         }
	
	         day = d.getDate();
	         weekday = d.getUTCDay();
	         month = d.getMonth();
	         year = d.getFullYear();
	         today = MONTHS_LIST[month] + ' ' + day + ', ' + year;
	
	         /*toHrs = {
	            currDay:day,
	            currMonthNum:month,
	            currMonth:MONTHS_LIST[month],
	            currYear:year,
	            day:dayNum,
	            index:i
	         };*/
	         colArrObj.push({
	            Display:today,
	            Value:{
	               year:year,
	               month:month,
	               day:day
	            }//,
	            //Hours:createHrs(toHrs, isHolidayBln, d)
	         });
	      }
	   };
	   var getTime = function(timeStr, fullStringBln, minutesBln){
	      timeStr = timeStr + '';
	      
	      var newHour, newMinute;
	      var hrLength = 2;
	      var prependBln = false;
	      if(timeStr.length === 5){
	         prependBln = true;
	         hrLength = 1;
	      }
	      
	      newHour = prependBln ? '0' + timeStr.slice(0, hrLength) : timeStr.slice(0, hrLength);
	      newMinute = timeStr.slice(hrLength, hrLength+2);
	      var returnTimeStr = (newHour+':'+newMinute);
	      
	      return fullStringBln ? returnTimeStr : minutesBln ? parseInt(newMinute, 10) : parseInt(newHour,10);
	   };
	   function isValidHolidayHour(hourToCheck, currDay){
	      var mmt = require('classes/momentjs');
	      var isValidHour = false;
	      var holidayCol = ro.app.Store.Holidays;
	      var currDate = mmt(currDay).format('MM-DD-YYYY');
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         if(mmt(currDate).isSame(currHoliday)){
	            var holidayOpenTime, holidayCloseTime;
	            holidayOpenTime = getTime(holidayCol[i].Open_Time);
	            holidayCloseTime = getTime(holidayCol[i].Close_Time);
	            if((hourToCheck >= holidayOpenTime) && ((hourToCheck < holidayCloseTime) || ((hourToCheck == holidayCloseTime) && getTime(holidayCol[i].Close_Time, false, true) > 0))){
	               if(mmt.utc(currDay).format('HH') > hourToCheck){
	                  continue;
	               }
	               isValidHour = true;
	               break;
	            }
	         }
	      }
	      return isValidHour;
	   }
	   function isHoliday(currDay){
	      var isHolidayBln = false;
	      
	      var mmt = require('classes/momentjs');
	      var holidayCol = ro.app.Store.Holidays;
	      if(!holidayCol || !holidayCol.length){
	         return false;
	      }
	      
	      var currDate = mmt(currDay).format('MM-DD-YYYY');
	      
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         if(mmt(currDate).isSame(currHoliday)){
	            isHolidayBln = true;
	            break;
	         }
	      }
	      return isHolidayBln;
	   }
	   function isClosedAllDay(currDay){
	      var mmt = require('classes/momentjs');
	      var holidayCol = ro.app.Store.Holidays;
	      var currDate = mmt(currDay).format('MM-DD-YYYY');
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         if(mmt(currDate).isSame(currHoliday)){
	            if(holidayCol[i].Closed_All_Day){
	               return true;
	            }
	         }
	      }
	      return false;
	   }
	   function skipTodayHoliday(deferTime, extraDay, currDay){
	      var skipTodayHolidayBln = true;
	      
	      var mmt = require('classes/momentjs');
	      var currDate = mmt(currDay).format('MM-DD-YYYY');
	      var holidayCol = ro.app.Store.Holidays;
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         var holidayOpen = null, holidayClose = null;
	         if(mmt(currDate).isSame(currHoliday)){
	            holidayOpen = getTime(holidayCol[i].Open_Time, true);
	            holidayClose = getTime(holidayCol[i].Close_Time, true);
	            if(!skipToday(deferTime, holidayClose, holidayOpen, extraDay)){
	               skipTodayHolidayBln = false;
	               break;
	            }
	         }
	      }
	      return skipTodayHolidayBln;
	   }
	   function skipToday(deferTime, closeTime, openTime, extraDay){
	   	var totHr, numHrs, strTm, strHr, strMn, totMn, clsHour, opnHour;
	   	var msDay = 86400000;
	   	strTm = new Date(storeObj.TimeAtStore);
	      strTm = new Date(strTm.getTime() + (msDay * extraDay));
	   	strHr = strTm.getUTCHours();
	   	strMn = strTm.getUTCMinutes();
	   	totMn = strMn + deferTime;
	
	   	clsHour = parseInt(fixHour(closeTime), 10);
	   	opnHour = parseInt(fixHour(openTime), 10);
	
	   	if(clsHour < opnHour){
	   		clsHour += 24;
	   	}
	   	
	   	if(extraDay > 0){
	         return false;
	      }
	
	   	if(totMn >= 60){
	   		numHrs = parseInt((totMn / 60).toFixed(), 10);
	   		totHr = strHr + numHrs;
	   		totMn -= (numHrs*60);
	   	}
	   	else{
	   		totHr = strHr;
	   	}
	
	   	if(totHr >= clsHour){
	   		if(totHr > clsHour){
	   			return true;
	   		}
	   		else{
	   			var closingMinutes = fixMins(closeTime);
		   		if(totMn > closingMinutes){
		   			return true;
		   		}
		   		else{
		   			return false;
		   		}
		   	}
	   	}
	   	else{
	   		return false;
	   	}
	   }
	   function roundMins(minToRound){
	      minToRound = parseInt(minToRound, 10);
	      while((minToRound%5) !== 0){
	         minToRound++;
	      }
	      return minToRound;
	   }
	   function deferHour(deferTime, currDt, currHr){
	   	try{
	   		var currStrTime = {
			   	hour:null,
			   	minute:null,
			   	timeString:null
			   },
			   strTm, numHrs;
	
	   		strTm = new Date(storeObj.TimeAtStore);
	   		currStrTime.hour = parseInt(strTm.getUTCHours(), 10);
	   		currStrTime.minute = parseInt(strTm.getUTCMinutes(), 10);
	
	   		if(currDt !== 0 && currHr === 0){
	   		   var opnTime = getOpenTime().split(":");
	   		   currStrTime.hour = opnTime[0];
	   			currStrTime.minute = parseInt(getOpenTime().substring(getOpenTime().lastIndexOf(':')+1), 10);
	   		}
	
	   		if(Ti.App.futureOnly && currDt === 0 && currHr === 0){
	   			var oTime = getOpenTime().split(":");
	   			//Ti.API.debug('oTime: ' + oTime);
	   			//Ti.API.debug('typeof-oTime: ' + (typeof oTime));
	   			currStrTime.hour = parseInt(oTime[0], 10);
	   			//currStrTime.hour = oTime[0];
	   			//Ti.API.debug('parsed-currStrTime.hour: ' + currStrTime.hour);
	   			currStrTime.minute = parseInt(oTime[1], 10);
	   			//Ti.API.debug('parsed-currStrTime.minute: ' + currStrTime.minute);
	   			//Ti.API.debug('currStrTime.hour: ' + oTime[0]);
	   			//Ti.API.debug('currStrTime.minute: ' + oTime[1]);
	   		}
	
	   		while((currStrTime.minute % 5) !== 0){
	   			currStrTime.minute++;
	   		}
	   		currStrTime.minute += deferTime;
	
	   		if(currStrTime.minute >= 60){
	   			numHrs = parseInt((currStrTime.minute / 60), 10);
	   			currStrTime.hour += numHrs;
	   			currStrTime.minute -= (numHrs*60);
	   		}
	   		currStrTime.timeString = currStrTime.hour+':'+currStrTime.minute;
	   		return currStrTime;
	   	}
	   	catch(ex){
	   		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('deferHour()-Exception: ' + ex); }
	   	}
	   }
	   function deferMin(){
	   	try{
	   		return storeObj.Menu.OnlineOptions.OrdTypes[ro.utils.getMatchingIdx(delivery, storeObj.Menu.OnlineOptions.OrdTypes, 'IsDelivery')].DeferPrepMin;
	   	}
	   	catch(e){
	   		return delivery?45:30;//Returns default 45-delivery or 30-pickup if loop fails to return.
	   	}
	   }
	   function getOpenTime(extraDay){
	   	return storeObj.Hours[(delivery)?currentDay:currentDay+7].Open;
	   }
	   function getCloseTime(extraDay){
	   	return storeObj.Hours[(delivery)?currentDay:currentDay+7].Close;
	   }
	   function isTodayClosed(){
		return storeObj.Hours[(delivery)?currentDay:currentDay+7].Closed;
	   }
	   function changeDateDisplay(colArrObj, dtObj){
	   	try{
	   		if(dtObj.dtIdx || dtObj.dtIdx === 0){
	   			dtObj.dateRow = dtObj.dtIdx;
	   		}
	
	   		if(dtObj.hrIdx || dtObj.hrIdx === 0){
	   			dtObj.hourRow = dtObj.hrIdx;
	   		}
	
		   	if(colArrObj[dtObj.dateRow].Hours[dtObj.hourRow].milValue >= 24){
		   		if((dtObj.dateRow+1) === colArrObj.length){
		   			return MONTHS_LIST[colArrObj[dtObj.dateRow].Value.month] + ' ' + (colArrObj[dtObj.dateRow].Value.day+1) + ', ' + colArrObj[dtObj.dateRow].Value.year;
		   		}
		   		else{
		   			return colArrObj[dtObj.dateRow+1].Display;
		   		}
		   	}
		   	else{
		   		return colArrObj[dtObj.dateRow].Display;
		   	}
		   }
		   catch(ex){
		   	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('changeDateDisplay()-Exception: ' + ex); }
		   }
	   }
	   function convertToStoreTm(e){
	   	var curDate = new Date(e.year, e.month, e.day, e.hours, e.minutes, 0, 0);
	      var finalDate = new Date(curDate.getTime() - (curDate.getTimezoneOffset()*60000));
	   	return finalDate;
	   }
	   function holidayFixOpenMinute(minLim, currentHr, today, timeToDefer){
	      var returnMin = minLim;
	      var mmt = require('classes/momentjs');
	      var currDate = mmt(today).format('MM-DD-YYYY');
	      var holidayCol = ro.app.Store.Holidays;
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         var holidayCloseHour = null, holidayOpenMin = null;
	         if(mmt(currDate).isSame(currHoliday)){
	            holidayOpenHour = getTime(holidayCol[i].Open_Time);
	            holidayOpenMin = getTime(holidayCol[i].Open_Time, false, true);
	            
	            if(holidayOpenHour == currentHr){
	               if((holidayOpenMin+parseInt(timeToDefer,10)) > (minLim)){
	                  returnMin = holidayOpenMin + parseInt(timeToDefer,10);
	                  break;
	               }
	            }
	         }
	      }
	      return returnMin;
	   }
	   function holidayFixCloseMinute(minLim, currentHr, today){
	      var returnMin = minLim;
	      var mmt = require('classes/momentjs');
	      var currDate = mmt(today).format('MM-DD-YYYY');
	      var holidayCol = ro.app.Store.Holidays;
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         var holidayCloseHour = null, holidayCloseMin = null;
	         if(mmt(currDate).isSame(currHoliday)){
	            holidayCloseHour = getTime(holidayCol[i].Close_Time);
	            holidayCloseMin = getTime(holidayCol[i].Close_Time, false, true);
	            
	            if(holidayCloseHour == currentHr){
	               if(holidayCloseMin < minLim){
	                  returnMin = holidayCloseMin;
	                  break;
	               }
	            }
	         }
	      }
	      return returnMin;
	   }
	   function holidayFixOpenHour(hourToFix, today){
	      var returnHour = hourToFix;
	      var mmt = require('classes/momentjs');
	      var currDate = mmt(today).format('MM-DD-YYYY');
	      var holidayCol = ro.app.Store.Holidays;
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         var holidayOpen = null, holidayClose = null;
	         if(mmt(currDate).isSame(currHoliday)){
	            holidayOpen = getTime(holidayCol[i].Open_Time);
	            returnHour = holidayOpen;
	            break;
	         }
	      }
	      return returnHour;
	   }
	   function holidayFixCloseHour(hourToFix, today){
	      //Ti.API.debug('today - holidayFixCloseHour: ' + JSON.stringify(today));
	      var returnHour = hourToFix;
	      var tempHourToFix = hourToFix;
	      var mmt = require('classes/momentjs');
	      var currDate = mmt(today).format('MM-DD-YYYY');
	      var holidayCol = ro.app.Store.Holidays;
	      for(var i=0, iMax=holidayCol.length; i<iMax; i++){
	         var currHoliday = mmt(holidayCol[i].Date).format('MM-DD-YYYY');
	         var holidayOpen = null, holidayClose = null;
	         if(mmt(currDate).isSame(currHoliday)){
	            /*holidayOpen = getTime(holidayCol[i].Open_Time, true);
	            if(holidayOpen < hourToFix){
	               hourToFix = holidayOpen;
	            }*/
	            holidayClose = getTime(holidayCol[i].Close_Time);
	            //returnHour = holidayClose;
	            if(holidayClose > tempHourToFix){
	               tempHourToFix = holidayClose;
	               returnHour = holidayClose;
	            }
	         }
	      }
	      return returnHour;
	   }
	   function fixHour(hrs){
	      //Ti.API.debug('hrs: ' + hrs);
	   	var hr = hrs.split(":");
	   	if(parseInt(hr[0], 10) < 10){
	   		hr[0] = parseInt(hr[0].slice(-1), 10);
	   	}
	   	else{
	   		hr[0] = parseInt(hr[0], 10);
	   	}
	   	return hr;
	   }
	   function fixMins(hrs){
	   	var hr = hrs.split(":");
	   	return parseInt(hr[1], 10);
	   }
	   function formatHrTxt(opnHr){
	   	var hrTitle = {
	   		title:'',
	   		tm:null,
	   		dayInd:'',
	   		milTm:opnHr
	   	};
	   	if(opnHr < 12){
	   		hrTitle.title = opnHr + ' am';
	   		hrTitle.tm = opnHr;
	   		hrTitle.dayInd = 'am';
	   	}
	   	else if(opnHr < 24){
	   		if(opnHr === 12){
	   			hrTitle.title = opnHr + ' pm';
	   			hrTitle.tm = opnHr;
	   			hrTitle.dayInd = 'pm';
	   		}
	   		else{
	   			hrTitle.title = (opnHr-12) + ' pm';
	   			hrTitle.tm = (opnHr-12);
	   			hrTitle.dayInd = 'pm';
	   		}
	   	}
	   	else{
	   		if(opnHr === 24){
	   			hrTitle.title = (opnHr-12) + ' am';
	   			hrTitle.tm = (opnHr-12);
	   			hrTitle.dayInd = 'am';
	   		}
	   		else{
	   			hrTitle.title = (opnHr-24) + ' am';
	   			hrTitle.tm = (opnHr-24);
	   			hrTitle.dayInd = 'am';
	   		}
	   	}
	   	return hrTitle;
	   }
	   var skipHour = function(deferPrpTm, currentMins){
	      
	      if((parseInt(currentMins,10) + parseInt(deferPrpTm,10)) > 59){
	         //Ti.API.debug('deferPrpTm: ' + deferPrpTm);
	         //Ti.API.debug('currentMins: ' + currentMins);
	         //Ti.API.debug('skipping hour');
	         return true;
	      }
	      return false;
	   };
	   ro.toFuture = function(thisStore){
	   	try{
		   	if(!thisStore || !thisStore.Configuration){
		   		return false;
		   	}
		   	if(thisStore.Configuration.AllowFutureOrders){
		   		return true;
		   	}
		   	if(thisStore.Configuration.AllowSameDayDefer){
		   		storeObj = thisStore;
		   		if(Ti.App.Properties.hasProperty('DefaultStore')){
		      		if(Ti.App.TimeAtDefStore && Ti.App.TimeAtDefStore !== null){
		      			storeObj.TimeAtStore = Ti.App.TimeAtDefStore;
		      		}
		      	}
				var date = new Date(storeObj.TimeAtStore);
		      	var d = new Date(date.getTime());
		        var dayNum = d.getDay();
		         currentDay = dayNum;
		   		 delivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
				if(isTodayClosed() || (isHoliday(d) && isClosedAllDay(d))){
					return false;
				}					
		   		if(!skipToday(deferMin(), getCloseTime(), getOpenTime()) || (isHoliday(d) && !skipTodayHoliday(deferMin(), 0, d))){
		   			return true;
		   		}
		   	}
		   	return false;
		   }
		   catch(ex){
		   		Ti.API.info('dateControl.toFuture()-Exception: ' + ex); 
		   }
	   };
	   ro.storeStatus = function(status, roAppStore, sameDay, futureDay, allowDefer){	   	
	   	try{
		   	if(roAppStore === null && allowDefer === null){
		   		return {
		   			futureBool:false
		   		};
		   	}
	
		   	var img, lbl, futBool;
		   	futBool = ( (allowDefer!==null) ? allowDefer : (sameDay || futureDay) ? true : false ) ;
		   	if(futBool === true && allowDefer === null){
		   		futBool = ro.toFuture(roAppStore);
		   	}
	
		   	if(status){
		   		img = ro.ui.properties.defaultPath + 'green@2x.png';
		   		lbl = 'OPEN';
		   	}
		   	else if(futBool){
		   		img = ro.ui.properties.defaultPath + 'orange@2x.png';
		   		lbl = 'FUTURE';
		   	}
		   	else{
		   		img = ro.ui.properties.defaultPath + 'red@2x.png';
		   		lbl = 'CLOSED';
		   	}
		   	return {
		   		image:img,
		   		label:lbl,
		   		futureBool:futBool
		   	};
		   }
		   catch(ex){ 
			   Ti.API.info('dateControl.storeStatus()-Exception: ' + ex); 
		   }
	   };
	   return ro;
	};
	return {
		dateForm:dateForm
	};
}();
module.exports = DATEFORM;