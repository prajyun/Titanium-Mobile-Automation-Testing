//var profileForm = (function(){
   exports.getProForm = function(){
      var titles = Ti.App.Properties.getList('titles');
      var fields = [
         { title:'Title', type:'picker', id:'title', data:titles },
         { title:'First Name', type:'text', id:'firstname', isReq: true},
         { title:'Last Name', type:'text', id:'lastname', isReq: true },
         { title:'Phone', type:'phone', id:'phone', isReq: true },
         { title:'Extension', type:'number', id:'extension'}];
         fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   //return ro;
//})();