var resetPassword = (function(){
   exports.getResetPasswordForm = function(e){
   	var fields = [ { title:'Email', type:'email', id:'UserName' } ];
   	if(e === 1){
   		fields = [
   			{ title:'Reset Code', type:'text', id:'Code', isReq: true },
   			{ title:'Email', type:'email', id:'UserName', isReq: true },
   			{ title:'New Password', type:'password', id:'newpass', isReq: true },
         	{ title:'Verify New Password', type:'password', id:'verifynewpass', isReq: true }];
   	}
   	fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   exports.getNewPasswordForm = function(e){
   	var fields = [
   		{ title:'New Password', type:'password', id:'newpass', isReq: true },
        { title:'Verify New Password', type:'password', id:'verifynewpass', isReq: true }
    ];
   	fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
   	return fields;
   };
   //return ro;
})();