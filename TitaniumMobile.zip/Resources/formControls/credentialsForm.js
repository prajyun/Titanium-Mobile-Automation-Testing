//var credentialsForm = (function(){
   exports.getUserForm = function(){
      fields = [
         { title:'New Email', type:'email', id:'email', isReq: true },
         { title:'Password', type:'password', id:'password', isReq: true },
         { title:'Verify New Password', type:'password', id:'verifynewpass', isReq: true }];
         fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   
   exports.getUpdateUsernameForm = function(){
      fields = [
         { title:'New Email', type:'email', id:'email' },
         { title:'Password', type:'password', id:'password' }];
         fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   
   exports.getUpdatePasswordForm = function(){
      fields = [
         { title:'Current Password', type:'password', id:'password' },
         { title:'New Password', type:'password', id:'newpass' },
         { title:'Verify New Password', type:'password', id:'verifynewpass' }];
         fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   
   //return ro;
//})();