exports.getGuestOrderForm = function(e){
  var fields = [
     { title:'Email', type:'email', id:'email', isReq: true },
     { title:'First Name', type:'text', id:'firstname', isReq: true },
     { title:'Last Name', type:'text', id:'lastname', isReq: true },
     { title:'Phone', type:'phone', id:'phone', isReq: true }
  ];
  fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
  return fields;
};