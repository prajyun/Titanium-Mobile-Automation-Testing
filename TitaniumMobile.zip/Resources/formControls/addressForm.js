//var addressForm = (function(){
	var mapStates = function(states){
		return states.slice(0).map(function(state){
		    return state.StateAbbreviation;
		});
	};
	var mapCountrys = function(states){
		return states.slice(0).map(function(state){
		    return state.CountryCode;
		});
	};
	
   exports.getAddrForm = function(e){
      var states = mapStates(Ti.App.Properties.getList('states'));
      var countries = mapCountrys(Ti.App.Properties.getList('states'));
      var types = Ti.App.Properties.getList('addrTypes');
      
      if(e && e.guest){
         var fields = [
            { title:'City', type:'text', id:'city', isReq: true},
            { title:'State', type:'picker', id:'state', data:states, countryData:countries},
            { title:'- OR -', type:'lbl', id:'lbl' },
            { title:'Zip Code', type:'text', id:'zip', isReq: true}];
            fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
         return fields;
      }
      else{      
         var fields = [
            { title:'Location Name', type:'text', id:'label', charLimit:25, defaultValue:'My House', isReq: true},
            { title:'Address Type', type:'picker', id:'addrtype', data:types },
            { title:'Unit #', type:'text', id:'unitnum', charLimit:10, cantEdit:true, defaultValue:'N/A', isReq: true},
            { title:'Unit Name', type:'text', id:'unitname', cantEdit:true, defaultValue:'N/A', isReq: true },
            { title:'Street Address', type:'text', id:'stnumname', isReq: true},
            { title:'City', type:'text', id:'city', isReq: true },
            { title:'State', type:'picker', id:'state', data:states, countryData:countries, isReq: true },
            { title:'Zip Code', type:'text', id:'zip', isReq: true }];
   
            if(e && e != null){
            	if(e.save){
            		fields.push(
            			{ title:'Would you like to add this New Address to your account?', type:'checkbox', id:'addrSave' }
            		);
            	}
            }
            
            fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
         return fields;
      }
   };
   //return ro;
//})();