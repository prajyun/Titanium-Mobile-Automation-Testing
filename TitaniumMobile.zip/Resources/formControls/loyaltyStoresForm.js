//var profileForm = (function(){
   exports.getForm = function(formData){
      var fields = [
         { title:'Loyalty Store', type:'picker', id:'ltystore', data:formData }];
         //{ title:'First Name', type:'text', id:'firstname' },
         //{ title:'Last Name', type:'text', id:'lastname' },
         //{ title:'Phone', type:'phone', id:'phone' },
         //{ title:'Extension', type:'number', id:'extension' }];
         fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      return fields;
   };
   //return ro;
//})();