//var levelupGcForm = (function(){
   exports.getLevelupGcForm = function(){
      var fields = [
         { title:'Recipient\'s Email Address', type:'email', id:'email', isReq: true },
         { title:'Recipient\'s First Name', type:'text', id:'firstname', isReq: true },
         { title:'Dollar Value ($)', type:'number', id:'dollarAmt', isReq: true },
         { title:'Message', type:'spclInst', id:'levelupGcMessage', isReq: true }
      ];
      return fields;
   };
   //return ro;
//})();