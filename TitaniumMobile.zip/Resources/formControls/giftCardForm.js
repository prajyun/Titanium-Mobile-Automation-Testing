
   exports.getGcForm = function(_args){
      var fields = [{ title:'Gift Card Number', type:'number', id:'giftCardNum', isReq: true }];
      if(_args && _args.ShowAmountField){
      	fields.push({ title:'Amount', type:'decimal', id:'payAmt', isReq: true });
      }
       fields[fields.length - 1].returnKeyType = Ti.UI.RETURNKEY_DONE;       
      return fields;
   };