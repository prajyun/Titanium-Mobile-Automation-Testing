	exports.getCCForm = function(_args){
      var creditCards = Ti.App.Properties.getList('creditcards', ['VISA', 'MC', 'AMEX', 'DISC']);
      var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      var yearList = [], fields = [];
      var curDate = new Date();
      //var billingObject;
      //Ti.API.debug('creditCards: ' + JSON.stringify(creditCards));
      //Ti.API.debug('creditCards: ' + JSON.stringify());
      if(ro.app.Store){
      	 //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
      	 creditCards = ro.app.Store.Configuration && ro.app.Store.Configuration.CardTypes && ro.app.Store.Configuration.CardTypes.length ? ro.app.Store.Configuration.CardTypes : creditCards;
      }
      else{
      	 var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
      	 if(!cfg){
      	 	//cfg = {};
      	 }
      	 else{
      	 	//Ti.API.debug('cfg: ' + JSON.stringify(cfg));
      	 	creditCards = cfg.CardTypes && cfg.CardTypes.length ? cfg.CardTypes : creditCards;
      	 }
      }
      
      /*if(ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.VerifyBilling){
      	if(ro.app.Store.Configuration.VerifyBilling === 1){
      		billingObject = { title:'Billing Zip Code', type:'number', id:'BillingZip' };
      	}
      	else if(ro.app.Store.Configuration.VerifyBilling === 2){
      		billingObject = { title:'Billing Street Name', type:'text', id:'BillingStreet' };
      	}
      }*/
     
      
      
      
      
      for(var i=0; i<10; i++){
         yearList[i] = curDate.getFullYear() + i;
      }
      
      if(_args.save){
         fields = [
            //{ title:'Type', type:'picker', id:'ccType', data:creditCards },
            { title:'Accepted Cards', type:'cardImages', id:'ccAccepted', data:creditCards },
            { title:'Number', type:'number', id:'ccNum' },
            { title:'Name', type:'text', id:'ccName' },
            { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList},
            { title:'Expiry Year', type:'picker', id:'expYear', data:yearList},
            //{ type:'expirationCol', data:[ { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList}, { title:'Expiry Year', type:'picker', id:'expYear', data:yearList}] },
            { title:'CVV', type:'number', id:'cvvNum' },
            { title:'Save Card', type:'checkbox', id:'ccSave' }];
      }
      else{
         if(_args.noneDefault){
            fields = [
               //{ title:'Type', type:'picker', id:'ccType', data:creditCards },
               { title:'Accepted Cards', type:'cardImages', id:'ccAccepted', data:creditCards },
               { title:'Number', type:'number', id:'ccNum', isReq: true },
               { title:'Name', type:'text', id:'ccName', isReq: true },
               { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList},
               { title:'Expiry Year', type:'picker', id:'expYear', data:yearList},
               //{ type:'expirationCol', data:[ { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList}, { title:'Expiry Year', type:'picker', id:'expYear', data:yearList}] },
               { title:'CVV', type:'number', id:'cvvNum', isReq: true }];
         }
         else{
            fields = [
               //{ title:'Type', type:'picker', id:'ccType', data:creditCards },
               { title:'Accepted Cards', type:'cardImages', id:'ccAccepted', data:creditCards },
               { title:'Number', type:'number', id:'ccNum', isReq: true },
               { title:'Name', type:'text', id:'ccName', isReq: true },
               { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList},
               { title:'Expiry Year', type:'picker', id:'expYear', data:yearList},
               //{ type:'expirationCol', data:[ { title:'Expiry Month', type:'picker', id:'expMonth', data:monthList}, { title:'Expiry Year', type:'picker', id:'expYear', data:yearList}] },
               { title:'CVV', type:'number', id:'cvvNum', isReq: true }];
               //{ title:'Would you like to save this new card for future use?', type:'checkbox', id:'ccDefault' }];
         }
      }
      
      if(_args.billingFlag === 1){
      	fields.splice(6, 0, { title:'Billing Zip Code', type:'number', id:'BillingZip', isReq: true });
      }
      else if(_args.billingFlag === 2){
      	fields.splice(6, 0, { title:'Billing St.', type:'text', id:'BillingStreet', isReq: true });
      }
	  
	  if(_args.ShowAmountField){
	  	if(_args.IsSavedCard){
	  		fields = [];
	  	}
	  	
	  	fields.push({ title:'Amount', type:'decimal', id:'payAmt', isReq: true });
	  }
      curDate = null;
      
      if(fields[fields.length-1].id == 'ccDefault' || fields[fields.length-1].id == 'ccSave') {
      	fields[fields.length-2].returnKeyType = Ti.UI.RETURNKEY_DONE;
      }
      else{
      	fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
      }
      
      return fields;
   };
   //return ro;