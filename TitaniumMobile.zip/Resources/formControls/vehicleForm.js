exports.getVhclForm = function(e){   
    if (e.formType == 1) {
        var fields = [
            { title: 'Name', type: 'text', id: 'vehicleName', charLimit: 50, isReq: true },
            { title: 'Vehicle Make', type: 'text', id: 'make', charLimit: 50, isReq: true },
            { title: 'Vehicle Model', type: 'text', id: 'model', charLimit: 50, isReq: true },
            { title: 'Color', type: 'text', id: 'color', charLimit: 50, isReq: true },
            { title: 'Vehicle Features', type: 'spclInst', id: 'features', charLimit: 100 }
        ];
    } else if (e.formType == 2) {
        var fields = [
            { title: 'Vehicle Make', type: 'text', id: 'make', charLimit: 50, isReq: true },
            { title: 'Vehicle Model', type: 'text', id: 'model', charLimit: 50, isReq: true },
            { title: 'Color', type: 'text', id: 'color', charLimit: 50, isReq: true },
            { title: 'Vehicle Features', type: 'spclInst', id: 'features', charLimit: 100 },
            { title: 'Save vehicle information for future use?', type: 'checkbox', id: 'vhclSave', chopTop: true },
            { title: 'Name', type: 'text', id: 'vehicleName', charLimit: 50, hideField: true, isReq: true }
        ];
    } else if (e.formType == 3) {
        var fields = [
            { title: 'Vehicle Make', type: 'text', id: 'make', charLimit: 50, isReq: true },
            { title: 'Vehicle Model', type: 'text', id: 'model', charLimit: 50, isReq: true },
            { title: 'Color', type: 'text', id: 'color', charLimit: 50, isReq: true },
            { title: 'Vehicle Features', type: 'spclInst', id: 'features', charLimit: 100 }            
        ];
    }
   fields[fields.length-1].returnKeyType = Ti.UI.RETURNKEY_DONE;
   return fields;   
};
