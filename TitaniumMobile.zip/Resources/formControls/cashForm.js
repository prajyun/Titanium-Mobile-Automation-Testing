//var cashForm = (function(){
   exports.getCashForm = function(_args){
      var fields = [];
      if(_args.ShowAmountField){
	  	fields.push({ title:'Amount', type:'number', id:'payAmt', isReq: true });
	  }
      return fields;
   };
  // return ro;
//})();