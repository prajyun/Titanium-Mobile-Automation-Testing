﻿
/*Example
   * var geo = require('geo');

   * Call google API to geocode the address and then pass the result geo module
   * This module will return an array of well formatted address

   * var addresses = geo.parseResults(results, true);
   *   The above API accepts two arguments
   *   1. Google geocoding results
   *   2. Flag indicating whether the address should be an exact match.
   *      You should always set this to true in order to get an exact match

   * Each address object has the following properties:
   *        StNumber: Street Number
   *        Street: Street Name
   *        City: City
   *        State: State
   *        Zip: Zipcode
   *        Address: Formatted address (StNum + StName),
   *        Lat: Latitude
   *        Lon: Longitude
*/
//var geo = function () {
    var stripVowelAccent = function (str) {
        var rExps = [{ re: /[\xC0-\xC6]/g, ch: 'A' },
                     { re: /[\xE0-\xE6]/g, ch: 'a' },
                     { re: /[\xC8-\xCB]/g, ch: 'E' },
                     { re: /[\xE8-\xEB]/g, ch: 'e' },
                     { re: /[\xCC-\xCF]/g, ch: 'I' },
                     { re: /[\xEC-\xEF]/g, ch: 'i' },
                     { re: /[\xD2-\xD6]/g, ch: 'O' },
                     { re: /[\xF2-\xF6]/g, ch: 'o' },
                     { re: /[\xD9-\xDC]/g, ch: 'U' },
                     { re: /[\xF9-\xFC]/g, ch: 'u' },
                     { re: /[\xD1]/g, ch: 'N' },
                     { re: /[\xF1]/g, ch: 'n' },
                     { re: /[,]/g, ch: '' },
                     { re: /[\x60]/g, ch: '\'' }];
        for (var i = 0, len = rExps.length; i < len; i++) {
            str = str.replace(rExps[i].re, rExps[i].ch);
        }
        return str;
    },
    getName = function (addressCol, names, longName, maxlength) {
         var i, j, k;
         if (addressCol != null && names) {
             for (i = 0; i < names.length; i++) {
                 for (j = 0; j < addressCol.length; j++) {
                     for (k = 0; k < addressCol[j].types.length; k++) {
                         if (addressCol[j].types[k] == names[i]) {
                             var name = longName ? addressCol[j].long_name : addressCol[j].short_name;
                             if (maxlength && name.length > maxlength) {
                                 if (longName) {
                                     name = addressCol[j].short_name;
                                 }
                                 else {
                                     name = name.substr(0, maxlength);
                                 }
                             }
                             return stripVowelAccent(name);
                         }
                     }
                 }
             }
         }
         return "";
     },
    getObj = function (addressResult, allowLongName) {
    	  Ti.API.debug('addressResult: ' + JSON.stringify(addressResult));
        return {
            StNumber: getName(addressResult.address_components, ['street_number']),
            Street: getName(addressResult.address_components, ["route"], allowLongName, 35),
            City: getName(addressResult.address_components, ["locality", "sublocality", "neighborhood", "administrative_area_level_3"], false, 25),
            State: getName(addressResult.address_components, ["administrative_area_level_1"]),
            Zip: getName(addressResult.address_components, ["postal_code"]),
            Address: addressResult.formatted_address,
            Lat: addressResult.geometry.location.lat,
            Lon: addressResult.geometry.location.lng
        };
    },
    parseResults = function (result, exactMatch, allowLongName) {
        var markers = [];
        if (result) {
            for (var i = 0; i < result.length; i++) {
                if (!exactMatch || (result[i].types && result[i].types.length > 0 && (result[i].types.indexOf("street_address") > -1
                                                                                        || result[i].types.indexOf("premise") > -1
                                                                                        || result[i].types.indexOf("route") > -1
                                                                                        || result[i].types.indexOf("subpremise") > -1
                                                                                        || result[i].types.indexOf("floor") > -1
                                                                                        || result[i].types.indexOf("point_of_interest") > -1
                                                                                        || result[i].types.indexOf("parking") > -1
                                                                                        || result[i].types.indexOf("room") > -1
                                                                                        || (allowPostalCodeAccuracy && result[i].types.indexOf("postal_code") > -1))
                )) {
                    var obj = getObj(result[i], allowLongName);
                    markers.push(obj);
                }
            }
        }
        Ti.API.debug('markers: ' + JSON.stringify(markers));
        return markers;
    };
    exports.displayList = function(addresses, callBack){
    	 var theOptionsDialog = Ti.UI.createOptionDialog({
    	 	 title:'DID YOU MEAN?',
    	 	 buttonNames:['CANCEL']
    	 });

    	 theOptionsDialog.addEventListener('click', function(e){
    	 	 if(e.button){
    	 	 	 ro.ui.hideLoader();
    	 	 	 return;
    	 	 }
    	 	 callBack(e.index);
    	 });

    	 var opts = [];
    	 for(var i=0, max=addresses.length; i<max; i++){
    	 	Ti.API.debug('addresses[i]: ' + JSON.stringify(addresses[i]));
    	 	 opts.push(addresses[i].Address);
    	 	 //opts.push(addresses[i].StNumber + ' ' + addresses[i].Street + '\n' + addresses[i].City + ', ' + addresses[i].State + ' ' + addresses[i].Zip);
    	 }
    	 theOptionsDialog.options = opts;
    	 theOptionsDialog.show();
    };
    /*return {
        parseResults: parseResults,
        displayList: displayList
    };
}();

module.exports = geo;*/