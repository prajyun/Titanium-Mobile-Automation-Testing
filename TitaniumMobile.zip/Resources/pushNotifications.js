﻿var PN = function () {
    var pushNotifications = function (ro) {
        var registerDevice = function (token) {
            Ti.API.info("Register Device called");
            var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));

            Ti.API.info('savedTokenObj : ' + JSON.stringify(savedTokenObj));
            Ti.API.info('Device ID: ' + Ti.Platform.id);
            Ti.API.info('Token: ' + token);

            if (!token) {
                Ti.API.info("Token has not been passed");
                if (savedTokenObj && savedTokenObj.token) {
                    token = savedTokenObj.token;
                } else {
                    Ti.API.info("Returned from Register Device");
                    return;
                }
            }            
            var Email = null;
            var defaultCustomer = ro.db.getDefaultCustomer();

            if (Ti.App.Username) {
                Email = Ti.App.Username;
            } else if (defaultCustomer) {
                Email = defaultCustomer.Email;
            } 
            
            if (savedTokenObj && savedTokenObj.token === token && savedTokenObj.email === Email) {
                Ti.API.info("Token has already been regitered");
            } else {                
                var obj = {};
                obj.DeviceID = Ti.Platform.id;
                obj.DeviceToken = token;
                obj.DeviceType = ro.isiOS ? 1 : 2;
                obj.Email = Email;
                ro.dataservice.registerDevice(obj, function (response) {
                    Ti.API.info("Register Response: " + JSON.stringify(response));
                    if (response.Success) {
                        var tokenObj = {};
                        tokenObj.token = token;
                        tokenObj.email = Email;
                        Ti.App.Properties.setString('PushNotificationTokenObj', JSON.stringify(tokenObj));
                        Ti.API.info("Token Registered");
                    } else {
                        Ti.API.info("Token Registeration Failed : " + response.Message);
                    }
                });
            }
        };
        var notifications = {};
        notifications.init = function () {
            try {
                if (ro.isiOS) {

                    // Wait for user settings to be registered before registering for push notifications
                    Ti.App.iOS.addEventListener('usernotificationsettings', function registerForPush() {

                        // Remove event listener once registered for push notifications
                        Ti.App.iOS.removeEventListener('usernotificationsettings', registerForPush);

                        Ti.Network.registerForPushNotifications({
                            success: deviceTokenSuccess,
                            error: deviceTokenError,
                            callback: receivePush
                        });
                    });

                    // Register notification types to use
                    Ti.App.iOS.registerUserNotificationSettings({
                        types: [
                            Ti.App.iOS.USER_NOTIFICATION_TYPE_ALERT,
                            Ti.App.iOS.USER_NOTIFICATION_TYPE_SOUND,
                            Ti.App.iOS.USER_NOTIFICATION_TYPE_BADGE
                        ]
                    });

                    // Process incoming push notifications
                    function receivePush(e) {
                        if (e.data && e.data.promocode && e.data.promocode != '') {
                            Ti.App.Properties.setString('promoDigest', e.data.promocode);
                        } //alert('Received push: ' + JSON.stringify(e));
                    }
                    // Save the device token for subsequent API calls
                    function deviceTokenSuccess(e) {
                        registerDevice(e.deviceToken);
                        Ti.API.info("Device Token: " + e.deviceToken);
                        Ti.API.info("Device Id: " + Ti.Platform.id);
                    }

                    function deviceTokenError(e) {
                        Ti.API.info('Failed to register for push notifications! ' + e.error);
                    }
                } else {

                    // Import core module
                    var core = require('firebase.core');

                    // Configure core module (required for all Firebase modules).
                    core.configure();

                    // Important: The cloud messaging module has to imported after (!) the configure()
                    // method of the core module is called
                    var fcm = require('firebase.cloudmessaging');

                    // Called when the Firebase token is registered or refreshed.
                    fcm.addEventListener('didRefreshRegistrationToken', function registerForPush(e) {
                        fcm.removeEventListener('didRefreshRegistrationToken', registerForPush);
                        registerDevice(e.fcmToken);
                    });

                    fcm.registerForPushNotifications();
                    if (fcm.lastData && fcm.lastData.promocode && fcm.lastData.promocode != '') {
                        Ti.App.Properties.setString('promoDigest', fcm.lastData.promocode);
                    }
                    Ti.API.info("Last data: " + JSON.stringify(fcm.lastData));
                    // Check if token is already available.
                    if (fcm.fcmToken) {
                        Ti.API.info('FCM-Token', fcm.fcmToken);
                    } else {
                        Ti.API.info('Token is empty. Waiting for the token callback ...');
                    }
                }
            } catch (ex) {
                Ti.API.info('PN.init()-Exception: ' + ex);
            }
        };
        notifications.registerDevice = registerDevice;
        ro.PN = notifications;
    };
    return {
        pushNotifications: pushNotifications
    };
}();
module.exports = PN;