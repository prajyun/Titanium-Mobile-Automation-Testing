///<reference path="~/Scripts/Titanium-vsdoc.js"/>
/*
Copyright (c) 2008 notmasteryet

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/

/* generic readers */

var base64alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    /* RFC 4648 */
function Base64Reader(base64) {
            this.position = 0;
            this.base64 = base64;
            this.bits = 0;
            this.bitsLength = 0;
            this.readByte = function () {
                if (this.bitsLength == 0) {
                    var tailBits = 0;
                    while (this.position < this.base64.length && this.bitsLength < 24) {
                        var ch = this.base64.charAt(this.position);
                        ++this.position;
                        if (ch > " ") {
                            var index = base64alphabet.indexOf(ch);
                            if (index < 0) {
                                throw "Invalid character";
                            }
                            if (index < 64) {
                                if (tailBits > 0) {
                                    throw "Invalid encoding (padding)";
                                }
                                this.bits = (this.bits << 6) | index;
                            }
                            else {
                                if (this.bitsLenght < 8) {
                                    throw "Invalid encoding (extra)";
                                }
                                this.bits <<= 6;
                                tailBits += 6;
                            }
                            this.bitsLength += 6;
                        }
                    }

                    if (this.position >= this.base64.length) {
                        if (this.bitsLength == 0) {
                            return -1;
                        }
                        else if (this.bitsLength < 24) {
                            throw "Invalid encoding (end)";
                        }
                    }

                    if (tailBits == 6) {
                        tailBits = 8;
                    }
                    else if (tailBits == 12) {
                        tailBits = 16;
                    }
                    this.bits = this.bits >> tailBits;
                    this.bitsLength -= tailBits;
                }

                this.bitsLength -= 8;
                var code = (this.bits >> this.bitsLength) & 0xFF;
                //Ti.API.debug('Code: '+code);
                return code;
            };
    }

    function BitReader(reader) {
            this.bitsLength = 0;
            this.bits = 0;
            this.reader = reader;
            this.readBit = function () {
                if (this.bitsLength == 0) {

                    var nextByte = this.reader.readByte();
                    if (nextByte < 0) {
                        throw "Unexpected end of stream";
                    }
                    this.bits = nextByte;
                    this.bitsLength = 8;
                }

                var bit = (this.bits & 1) != 0;
                this.bits >>= 1;
                --this.bitsLength;
                return bit;
            };
            this.align = function () {
                this.bitsLength = 0;
            };
            this.readLSB = function (length) {
                var data = 0;
                for (var i = 0; i < length; ++i) {
                    if (this.readBit()) {
                        data |= 1 << i;
                    }
                }
                return data;
            };
            this.readMSB = function (length) {
                var data = 0;
                for (var i = 0; i < length; ++i) {
                    if (this.readBit()) {
                        data = (data << 1) | 1;
                    }
                    else {
                        data <<= 1;
                    }
                }
                return data;
            };
    }

    /* text readers */

    function TextReader(translator) {
        Ti.API.debug('entered TextReader' + new Date());
            this.translator = translator;
            this.unreads = new Array(0);
            this.readChar = function () {
                if (this.unreads.length > 0) {
                    return this.unreads.pop();
                }
                else {
                    return translator.readChar();
                }
            };
            this.unreadChar = function (ch) {
                this.unreads.push(ch);
            };
            this.readToEnd = function () {
                var slarge = "";
                var s = "";
                var ch = this.readChar();
                while (ch != null) {
                    s += ch;
                    if (s.length > 1000) {
                        slarge += s;
                        s = "";
                    }
                    ch = this.readChar();
                }
                Ti.API.debug('out of textreader ' + new Date());
                return slarge + s;
            };
            this.readLine = function () {
                var s = "";
                var ch = this.readChar();
                if (ch == null) {
                    return null;
                }

                while (ch != "\r" && ch != "\n") {
                    s += ch;
                    ch = this.readChar();
                    if (ch == null) {
                        return s;
                    }
                }
                if (ch == "\r") {
                    ch = this.readChar();
                    if (ch != null && ch != "\n") {
                        this.unreadChar(ch);
                    }
                }
                return s;
            };
    }

    function DefaultTranslator(reader) {
        this.reader = reader;
        this.readChar = function () {
            var code = reader.readByte();
            return code < 0 ? null : String.fromCharCode(code);
        };
    }

    /* RFC 2781 */
    function UnicodeTranslator(reader) {
        this.reader = reader;
        this.bomState = 0;
        this.readChar = function () {
            var b1 = reader.readByte();
            if (b1 < 0) {
                return null;
            }
            var b2 = reader.readByte();
            if (b2 < 0) {
                throw "Incomplete unicode character";
            }
            if (this.bomState == 0 && b1 + b2 == 509) {
                this.bomState = b2 == 254 ? 1 : 2;

                b1 = reader.readByte();
                if (b1 < 0) {
                    return null;
                }
                b2 = reader.readByte();
                if (b2 < 0) {
                    throw "Incomplete unicode character";
                }
            }
            else {
                this.bomState = 1;
            }

            var code = this.bomState == 1 ? (b2 << 8 | b1) : (b1 << 8 | b2);
            return String.fromCharCode(code);
        };
    }

    /* RFC 2279 */
    function Utf8Translator(reader) {
        this.reader = reader;
        this.waitBom = true;
        this.pendingChar = null;
        this.readChar = function () {
            var ch = null;
            do {
                if (this.pendingChar != null) {
                    ch = this.pendingChar;
                    this.pendingChar = null;
                }
                else {
                    var b1 = this.reader.readByte();
                    if (b1 < 0) {
                        return null;
                    }

                    if ((b1 & 0x80) == 0) {
                        ch = String.fromCharCode(b1);
                    }
                    else {
                        var currentPrefix = 0xC0;
                        var validBits = 5;
                        do {
                            var mask = currentPrefix >> 1 | 0x80;
                            if ((b1 & mask) == currentPrefix) {
                                break;
                            }
                            currentPrefix = currentPrefix >> 1 | 0x80;
                            --validBits;
                        } while (validBits >= 0);
                        if (validBits > 0) {
                            var code = (b1 & ((1 << validBits) - 1));
                            for (var i = 5; i >= validBits; --i) {
                                var bi = this.reader.readByte();
                                if ((bi & 0xC0) != 0x80) {
                                    throw "Invalid sequence character";
                                }
                                code = (code << 6) | (bi & 0x3F);
                            }
                            if (code <= 0xFFFF) {
                                if (code == 0xFEFF && this.waitBom) {
                                    ch = null;
                                }
                                else {
                                    ch = String.fromCharCode(code);
                                }
                            }
                            else {
                                var v = code - 0x10000;
                                var w1 = 0xD800 | ((v >> 10) & 0x3FF);
                                var w2 = 0xDC00 | (v & 0x3FF);
                                this.pendingChar = String.fromCharCode(w2);
                                ch = String.fromCharCode(w1);
                            }
                        }
                        else {
                            throw "Invalid character";
                        }
                    }
                }
                this.waitBom = false;
            } while (ch == null);
            return ch;
        };
    }

    /* inflate stuff - RFC 1950 */

    var staticCodes, staticDistances;

    var encodedLengthStart = [3, 4, 5, 6, 7, 8, 9, 10,
        11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99,
        115, 131, 163, 195, 227, 258];

    var encodedLengthAdditionalBits = [0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];

    var encodedDistanceStart = [1, 2, 3, 4, 5, 7, 9,
        13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049,
        3073, 4097, 6145, 8193, 12289, 16385, 24577];

    var encodedDistanceAdditionalBits = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4,
        5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];

    var clenMap = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

    function buildCodes(lengths) {
        var codes = new Array(lengths.length);
        var maxBits = lengths[0];
        var i;
        for (i = 1; i < lengths.length; i++) {
            if (maxBits < lengths[i]) {
                maxBits = lengths[i];
            }
        }

        var bitLengthsCount = new Array(maxBits + 1);
        for (i = 0; i <= maxBits; i++) {
            bitLengthsCount[i] = 0;
        }

        for (i = 0; i < lengths.length; i++) {
            ++bitLengthsCount[lengths[i]];
        }

        var nextCode = new Array(maxBits + 1);
        var code = 0;
        bitLengthsCount[0] = 0;
        for (var bits = 1; bits <= maxBits; bits++) {
            code = (code + bitLengthsCount[bits - 1]) << 1;
            nextCode[bits] = code;
        }

        for (var n = 0; n < codes.length; n++) {
            var len = lengths[n];
            if (len != 0) {
                codes[n] = nextCode[len];
                nextCode[len]++;
            }
        }
        return codes;
    }

    function buildTreeBranch(codes, prefix, prefixLength) {
        if (codes.length == 0) {
            return null;
        }

        var zeros = new Array(0);
        var ones = new Array(0);
        var branch = {};
        branch.isLeaf = false;
        for (var i = 0; i < codes.length; ++i) {
            if (codes[i].length == prefixLength && codes[i].bits == prefix) {
                branch.isLeaf = true;
                branch.index = codes[i].index;
                break;
            }
            else {
                var nextBit = ((codes[i].bits >> (codes[i].length - prefixLength - 1)) & 1) > 0;
                if (nextBit) {
                    ones.push(codes[i]);
                }
                else {
                    zeros.push(codes[i]);
                }
            }
        }
        if (!branch.isLeaf) {
            branch.zero = buildTreeBranch(zeros, (prefix << 1), prefixLength + 1);
            branch.one = buildTreeBranch(ones, (prefix << 1) | 1, prefixLength + 1);
        }
        return branch;
    }

    function buildTree(codes, lengths) {
        var nonEmptyCodes = new Array(0);
        for (var i = 0; i < codes.length; ++i) {
            if (lengths[i] > 0) {
                var code = {};
                code.bits = codes[i];
                code.length = lengths[i];
                code.index = i;
                nonEmptyCodes.push(code);
            }
        }
        return buildTreeBranch(nonEmptyCodes, 0, 0);
    }


    function initializeStaticTrees() {
        var codes = new Array(288);
        var codesLengths = new Array(288);
        var i;

        for (i = 0; i <= 143; i++) {
            codes[i] = 0x0030 + i;
            codesLengths[i] = 8;
        }
        for (i = 144; i <= 255; i++) {
            codes[i] = 0x0190 + i - 144;
            codesLengths[i] = 9;
        }
        for (i = 256; i <= 279; i++) {
            codes[i] = 0x0000 + i - 256;
            codesLengths[i] = 7;
        }
        for (i = 280; i <= 287; i++) {
            codes[i] = 0x00C0 + i - 280;
            codesLengths[i] = 8;
        }
        staticCodes = buildTree(codes, codesLengths);

        var distances = new Array(32);
        var distancesLengths = new Array(32);
        for (i = 0; i <= 31; i++) {
            distances[i] = i;
            distancesLengths[i] = 5;
        }
        staticDistances = buildTree(distances, distancesLengths);

    }


    function readDynamicTrees(bitReader) {
        var hlit = bitReader.readLSB(5) + 257;
        var hdist = bitReader.readLSB(5) + 1;
        var hclen = bitReader.readLSB(4) + 4;
        var i;

        var clen = new Array(19);
        for (i = 0; i < clen.length; ++i) {
            clen[i] = 0;
        }
        for (i = 0; i < hclen; ++i) {
            clen[clenMap[i]] = bitReader.readLSB(3);
        }

        var clenCodes = buildCodes(clen);
        var clenTree = buildTree(clenCodes, clen);

        var lengthsSequence = new Array(0);
        while (lengthsSequence.length < hlit + hdist) {
            var repeat, q;
            var p = clenTree;
            while (!p.isLeaf) {
                p = bitReader.readBit() ? p.one : p.zero;
            }

            var code = p.index;
            if (code <= 15) {
                lengthsSequence.push(code);
            }
            else if (code == 16) {
                repeat = bitReader.readLSB(2) + 3;
                for (q = 0; q < repeat; ++q) {
                    lengthsSequence.push(lengthsSequence[lengthsSequence.length - 1]);
                }
            }
            else if (code == 17) {
                repeat = bitReader.readLSB(3) + 3;
                for (q = 0; q < repeat; ++q) {
                    lengthsSequence.push(0);
                }
            }
            else if (code == 18) {
                repeat = bitReader.readLSB(7) + 11;
                for (q = 0; q < repeat; ++q) {
                    lengthsSequence.push(0);
                }
            }
        }

       var codesLengths = lengthsSequence.slice(0, hlit);
       var codes = buildCodes(codesLengths);
       var distancesLengths = lengthsSequence.slice(hlit, hlit + hdist);
       var distances = buildCodes(distancesLengths);

        var result = {};
        result.codesTree = buildTree(codes, codesLengths);
        result.distancesTree = buildTree(distances, distancesLengths);
        return result;
    }

    function Inflator(reader) {
        this.reader = reader;
        this.bitReader = new BitReader(reader);
        this.buffer = new Array(0);
        this.bufferPosition = 0;
        this.state = 0;
        this.blockFinal = false;
        this.readByte = function () {
            while (this.bufferPosition >= this.buffer.length) {
                var item = this.decodeItem();
                if (item == null) {
                    return -1;
                }
                switch (item.itemType) {
                    case 0:
                        this.buffer = this.buffer.concat(item.array);
                        break;
                    case 2:
                        this.buffer.push(item.symbol);
                        break;
                    case 3:
                        var j = this.buffer.length - item.distance;
                        for (var i = 0; i < item.length; i++) {
                            this.buffer.push(this.buffer[j++]);
                        }
                        break;
                }
            }
            var symbol = this.buffer[this.bufferPosition++];
            if (this.bufferPosition > 0xC000) {
                var shift = this.buffer.length - 0x8000;
                if (shift > this.bufferPosition) {
                    shift = this.bufferPosition;
                }
                this.buffer.splice(0, shift);
                this.bufferPosition -= shift;
            }
            return symbol;
        };

        this.decodeItem = function () {
            if (this.state == 2) {
                return null;
            }

            var item;
            if (this.state == 0) {
                this.blockFinal = this.bitReader.readBit();
                var blockType = this.bitReader.readLSB(2);
                switch (blockType) {
                    case 0:
                        this.bitReader.align();
                        var len = this.bitReader.readLSB(16);
                        var nlen = this.bitReader.readLSB(16);
                        if ((len & ~nlen) != len) {
                            throw "Invalid block type 0 length";
                        }

                        item = {};
                        item.itemType = 0;
                        item.array = new Array(len);
                        for (var i = 0; i < len; ++i) {
                            var nextByte = this.reader.readByte();
                            if (nextByte < 0) {
                                throw "Uncomplete block";
                            }
                            item.array[i] = nextByte;
                        }
                        if (this.blockFinal) {
                            this.state = 2;
                        }
                        return item;
                    case 1:
                        this.codesTree = staticCodes;
                        this.distancesTree = staticDistances;
                        this.state = 1;
                        break;
                    case 2:
                        var dynamicTrees = readDynamicTrees(this.bitReader);
                        this.codesTree = dynamicTrees.codesTree;
                        this.distancesTree = dynamicTrees.distancesTree;
                        this.state = 1;
                        break;
                    default:
                        throw "Invalid block type (3)";
                }
            }

            item = {};
            var p = this.codesTree;
            while (!p.isLeaf) {
                p = this.bitReader.readBit() ? p.one : p.zero;
            }
            if (p.index < 256) {
                item.itemType = 2;
                item.symbol = p.index;
            }
            else if (p.index > 256) {
                var lengthCode = p.index;
                if (lengthCode > 285) {
                    throw "Invalid length code";
                }

                var length = encodedLengthStart[lengthCode - 257];
                if (encodedLengthAdditionalBits[lengthCode - 257] > 0) {
                    length += this.bitReader.readLSB(encodedLengthAdditionalBits[lengthCode - 257]);
                }

                p = this.distancesTree;
                while (!p.isLeaf) {
                    p = this.bitReader.readBit() ? p.one : p.zero;
                }

                var distanceCode = p.index;
                var distance = encodedDistanceStart[distanceCode];
                if (encodedDistanceAdditionalBits[distanceCode] > 0) {
                    distance += this.bitReader.readLSB(encodedDistanceAdditionalBits[distanceCode]);
                }

                item.itemType = 3;
                item.distance = distance;
                item.length = length;
            }
            else {
                item.itemType = 1;
                this.state = this.blockFinal ? 2 : 0;
            }
            return item;
        };
    }

    /* initialization */
    initializeStaticTrees();

    var base64 ='7b0HYBxJliUmL23Ke39K9UrX4HShCIBgEyTYkEAQ7MGIzeaS7B1pRyMpqyqBymVWZV1mFkDM7Z28995777333nvvvfe6O51OJ/ff/z9cZmQBbPbOStrJniGAqsgfP358Hz8ifuPE/Pcib6+q+m36XfqnWF6kn9fVepXe9nk5Tp/m67aZzn/j5FX+i9Z506bnVZ2eVItFvmybR+nuw/u7GwAcl9lsVizT02Wb16u6aPLmN05Osja/qOrrR+nZkqAtsraollm5AUz4fJFdU78PP5URmk+fnj57fvzmFLit6rxp8ln6NGuz9Bn3kL5e5dPivJhyZ+llXjf4uTu+Bxiv26xdN2l1nr6ZF036Rb6oFDT/vaC/01VdXRazvEkLhzQTo53nNBAa3zJv0ylRZr0s2uux9y5DmlX07rJq04YxuU6zpXutabPlLKtnQCFbXqc0VzOC8LRo2rqYrLmv6pzhtBYj+rlelsWiaPPZGPienb7+PH1Rtfkjiz2hhg/b7C33nq6qphBoS0b8MiuLGaFrOgZGZZlP23VWMoiXdbXKa2rwqriYtw0wbXOefBrrss2KJRG6ADBCZ1ZN1/iOsSFEiinmm+GcVKvrGiDSrekdnr70+Th9mRMBHI9Jj3m9KBqeHgJ5UWeE0ixtK+pvBarN0pkhSx52y9NBo2Awq3VNg835hauinVdrmp15Vl/kI8J3Wq5nkIeWwDclTyZmlnqpiCw1Qyiz5cU6uyDCAQa9UxHEWiaem9Jkrwp9eWQYhFCdE78RFAYyteNeMj0YFmNt/q7zFAyb15f5bKRfEwAzjmY9AXe0xWUO/JfAh4Y5y8tcsD6vqwXPZUX9FBAkgJyWeVaXAmKR1W+VReivY2KCAowHmuI9GgEE28gEcQLjB0zqHF/OLIXN4BnQt9988TwVWUinxM2TnP5a01sy/PSrV8+53ePzdvXo7l36d7xej4nd79KkrubFtLm7Wl7cNbCbuz8oi8ndH9Df28T++bvxvF2UR4z2MdGgzqatL5VNINGz/JxYkbBOy6ppSlIAPD2qCWbQBIoqqKtTo9838v26AUdk+HxCdFSh46E8/6kHD9KsJK1FnLRg0nx7fX6+yJYKCcw0Yj5L83NCqsiX02vuIauzSZkbWk9A6em6rmnAJXHzZUYMRN8zmIt8mddZuW1Y1yAIRBY5sfCsGYtQM75Kc+K72XpKg6xqRWbZEEGJl/LLfKkyQTwxKYiEdUG9lhWNs4E+J7bKSvqEGZDlrFiu1kIe7oPInmeLkdKmWpastzJ6oSBapBPMN72VLeiXFtRizqLeC+Ib4d+WZOYiV8RDdikWq5KVSQ5Wy2ZArgB4IiyRAiKiQyLmpDYTwpTgEq8wV4T/qRYx9iB8bmFpvveS0Ex3v/8bJ78RWbtnJ55tey/bwk9oo94wCxB1TkhlAn3l490xFC7PH786fv8n3TMmcHdM4F4q69z4Xv/xIe0xYrnMLWlK4ub3gJnec5DujdPXpAPf423/8SHtj5n+ZZG9FzL6+JDuw7RCXxSiQSHkxLSi8kh8LiEX+GKNmd4E6VPCSXUyq2HijsuiIldClWmzEc90nyHtycCUsepchVEVEEG6LPKrzQNWSPfgr5FNLglOqB43vu0/6X0zunvgpy8voZHKgCo3wpDHQTLQwJ/ZlP1Qtp+TazI8twDn4xQSa1JW07dGqdwIhyB9GuK0B5xeXy+rVVMwHxDg8+Kdr+BVuXeh9yERZl81LOWdNwtxtT4iEwVr+lEH3/RBF5KdRkbp9mNMH3Yhkcy8qJbbniVkaE269eTN7/Py9LOdnTsxkOnubhfS/T7dCUqZLy/I5BmnjCWTRp03BmwE0qcOEjiTbSbRPA8onjsUdwVWumv1k4H0IAJpdr3MFsU0DmuXh5vuWgm+B1p/fa2S7orcqWoyiDhHYabTeGtIROZX+TkZO8LmFq9FnnRXOJPI/DonTwPOPZmdhlxT8V1vDdZAIjK/rta1Tu1t3/YfA+lgnB5P3y6rK1JQFxpF3Phy8BhIDwnSmjyi+uMmPZ7NQPn3hvQAVrhjgq1hdrbUBZlwYIxvZrzkUM3SB6TXxBf1XFEDYINH+shn7m+lZ4hGZvkKJlgcq5OXX6Xt9YqiFwRk1B18uOuGgrERiQ+5F/qHDycVi0ZRD/nO5E81eSsRxpwNunphbOXgJrLvJjHGYYjOSc/VvKWbGWKzyefc6G+GYG7lfBrH0xtwCMUfPalocaklfJ+qoNCYGoqvy6wGYsQh6xoBbTCkNbmcWZN+tSSzQfNACDRd4nXijNtFCR1k+yHDbcKFCDfQUKk3Cj3XGNbUaIYJgZ7kLYeFxAFisQzEj7r0ryiCW8R55BY+vefPdwCLcx/h0RU4uADrndd5Xl4ffrNe/97PhtfvOmF55mluC8wccwAozIKrWsAKF0U5+E6nPKTQFU0WEZSZ9uIHxSql3FBJKn4kXgZCq4oHDfGZ5WYCq7rDtlcFOXVEV8N1mCnhzi4a+Tsy7ICG7jpMaaGb3ELqhac6LFGGCq4ftpusWEast1iRLqwedWl3XJbVVUqJmhl52Nl0Cl2v2RdPmQ4InfRHWa4fGKW7lY8vxiOC14DZTSriDoT4inJfHYlpNobtAXRr9huPHMfQICQRhC4pKU4w1BeSrWrm1VUjk0aZuV7agq2RYmEdCoiDaQDFW18jpdcwV/lqNG8pxnkm2UkDpTMhlOYi5YjRUYYYw8sazPaKEmJqyu6rh072Jr2393ttG0D4VFxAYrtxTsSkHokEyJERI4l13Bnv7N7/3dkulMi6WcRAHYFzurwoi4YkIX/XEkuv2Sx4WRliGWIjEnyCQRDJCcW837Mznb8jB6fleYAgNT0YaVMt8isQGJQ9NJNNugDIGDBGhStHFAvO+S0yD84CTRZVnZuZjYfIvhTEfIPCvACqkAxjhFZf0iRglE113l5RBs9A8jhdSMihUy+YIOm4y2nBsDGiUgOp+05HaHkWNN8VYp41sPTIrU2yhnzrCQVxFzWn+jQVmFqjwIpHE4AlMWjJIUzRSnDNyVXYb0paI6HpT0MY+CLT9Yw8eXLM2YW1KrPNp/NlQX5EP9IykIjS87xcna9Jxa058UrAf9G6qF0S1CUmQiKEA9e/eOhiUXnmLKaSLxSvxrkXGDDLTYb3tgxTkrjXxF93bHtDGTF3fg+Wphota5YW3EkvOAAuinbjCtIkbnBfLVm58ARc0ToM3EsME5o5J/0KGZ7qe63HRjTcxZq0w8QOz5gMaOIVM57PdVhEMJIeGCTW2ZnTrz02azyPELrpMMCog4/HdbBWTrkEfWqXG/sykNClo+J7pYgclZ/QXDxKD4Th4YCKr8yrDMTyGBozBZaI0q0mW+T8N6V5yD9v71jNKJq7q0IwR6x76Yv8HelF4qoDZSF2wuH4ZdM5EuHfrH9072fPP7oihTwXWmHCbawCvZMu14tJzsqfKTorzjk2biXblmNdxdLsdZ4bVjbLcvI6RxIKAWqEvVHQ0VOAr1s0e+RJM6+IaTRz3RWyG/N+gVahkc2zS2BHc0SmXlQYzJBZ0FG/XxW00ekUAzmt4pYsd+PB5xjz6TXbG7H5s/KGZbVlVVYXpEyJ6aRrrDL+pFsMBWdlwt/eYpCFEWpHQhoM0bTXpZDyVolMpcxxLxhuePmUnI+mZXnDJzV0r8mBEZfTEhy9sqqWVt0TEmS/4RPCnmheikNB4wzpyoOk0eCmNLxAZudWYqT8HWsz9cZcyow9KwWL13S9Ff1+en90/576SIY1Tkn8tKsiWIG69eISg+nnH8c8CPMZRclgPWLz3HUI9CRpwEkDBsRdIDhEW8uliGtpWVGicR3dYQQXOEEMBr5KRjOqmSnWq+lsTbpZTEjD4kNaDD6y5jwz15/4igJpxT7c3u+lMySWcpKfe86VR0SfIdqrikPXBmK6ygrWC36eT8liF/go8zeldeKcR9ZlR6F9lwkBX+0xg4h9Twy11Z8MgrZo8vJS2cu9qAQEVcwbREOZ1DvCm91eBsRAGLXUxJlSBDkhoggFgUgGKD234EjynKhBZP0DRwg6SIlDakgNkjeTqiBBGzt9ndm6wwRiILqSLFmvLjuQvF6x8svsijPJhJ0HtYUCB7P5WLLJI/YvyQV2OeUjleHOHJrUjdFQPaeYhbWxYBrDeuqe0SxLl/zF3v0DhsJfjthztNEpAxI3AnEOT4sGQKo4jNe2XkY0x0itnK9AMoaMXyakGgPWx5Sij8usJDd3S6eWoNiBjHzk7/g06LJSh+JGDfli47JtkuEVvUpMLcGb9h6QSxzWJkfeqtW8sH3DYimmWRjcSmdXaa1WeYbUo3p7ZPx59tKfFq8TekEQisiJ2PlMVVhkTfib84D2fzY8ILvQA5nxGys3DC7BnYmEUqITMRf0p7rwk+odzdhbqLyieeS8EHo+2d7e/sT7+2f4/4+3txkUddKySzLJSJwX8KyQH1oUDXijD8Z8YpmrYf6B8BzegMdnwdNFyXt+ZuNbEQwyEpm64ADF8xx9+5yKj26dc+sPgrXWUFGziiWeFWaWfoR4q6opQ/rRKPTHiGjX4kiUV9l1A+7OjE5j/5501rerK+RorN9usq3czAAiKYRyvEBwl7dX8BF3WMD27t8XDaS4LKqm3VYxpFSFTcc0xcWSOQe2vFDzxbhSQiu9IktuyNG4MJqBxSDMigsMWRiszM8J3hUG2VQKSpTnzYAmIRhxT2Nce2Vny3M12VsXPQvKNXCQMwG6w8ssDBZk6A2fU1LeNGn6oTbd5LO+YPATsOKDT+/v39vb3QmY0GtpPv5ul4Mw2zoe5JDgE62uKWgt2wJ5QGHHFFlNA4K/2+ZxmnlSE2xTduLISGDMQ/H41x9qhCQAe14gw7dl8jLEloRcTgktYmFZPQtjT4oukZaS9CBF95QTK82g7u/xBCgCWUe68eyYX/y1X0e7KLl36Nml//Mv+DVO99i76e9nf/E/tcrEh+Q+/YTzeSHHglSfpXvpO5K9T/23PuEEYqzxgRs9tDWWDTVp45IzAYE4MzirppIDdvlvXcQEwUnnSnoLf7DyAT+wC+EB6kgImMLPM3D8TG223aJbiqWxdbBEKGqCWa2ABQwz9wHXFUjItvk25UlbZPGwTPTN2tj7Pxs21vYBWlBYw36Qr5uvwOFeoOA5GeKiCPYepAJLUmJwoez9jAHTz3fRYZA4BCp8COpHjWTqw4yg6ofv5pJ4A63ZC1IPwV8yowUEeK5IE6Jdo3kw279jQTSTjJiZag+MP2JWtopOX7K/JbS3HYDp0Dv74bYvoo9wrYYs/qNLBBAQ6HLVKV7UARBmWYH8yBpJ1h4Ua32iJsCIjuZ4gje7I6gsLwc+sT+0Xu8GrVui4Se57aMI9NEbwiLSa2B67TOABeB5XlDK5lhGT+s/tFScFufswl1B2MFVFMPR22uxGV3X2/kv9EQ42E2ev9oJKyTaiqF6IL5Vw+X8FpnM+gLmlFwYyu1O8xxxssmPfQuOxLdGwxSIjF1iDfTpOSMQXM7Lj2TI1bqceSluDEmz3BThNCaB0JCdlnwfI4uv1UECPufFu3y2TQu0ziKnXriu7M0ZLIpxvnj9ZLuttp+/fqKy0kn5sBh1tFcNhYUZkDe2REi65A2n3I8N5alzipGRLEPftHjIGe47hjXujcMsXqgCnanbg6l7fb2sVpSpQIf0AlEgkrkKeO6ltJJvfNe9uV5MqlLTqZlkjwpS1+nbZXXlEyIrV/OMHGWa02AxhJIeTLY7MqU8dhtrCvRRSFLyqLPlMkcuDEE33EuXYDb4wIWbeJkH1pEdbe5QgAWwIKySRyohE06qeQVXQwb+xEdIM0M2g0JxREbpwos1WRCsIDFO5Chuy2+hOH+X88eU+5fMm5JZGICXLsRXIN1PXh8H68ap6DAIskr5DGlp2MWcc62acActkR0lfXdOv8zE7ShpPhDCctjiAdplbvB7Se2LjUgC53IxYds0V9ssi2DnLW8BlB7TAb67w3DM9CinG6bgJKYRNGUAX/fKayZ+8JXWzseS1dj9GIEsfy00IIwtAXwiQSNUFSsBOzAfT2EonajAq34kjkn/v2/Gi/r0Z9WL6j13f9/w79dCYnpOTC4p/uyAQfxHPHvz2/Cbd/FPp1csKPCzszP4omL6pPOx+dsPVoJnp4uoPify7e7Qi3E86XnK/1KME39RRnL3972BdjcRaPB76T49Ceb12NdPWM+didVb5u8MF1vdbJQU54R96UIOZAH9eJWVHAPNSHczGEkO4n0jOCP4AKKc23zlQZnOq4r9QyODnqbwfAFGTLPSBfwoD8TnBVZDWdGqsWCJZFPiBiPSX8BXAUC1WoGpMesglH+rrkRpIIfT1uupWUWgXqpVywGyp3U9KFus1VgD+vZOs/OqKrBE00fMg7K2JDnPr3Kx86LSacGdrLikmz0MGpsdjRjPO6SRXsPqZWojSB3TGBHPB04IljpoXTXwHswa0Pd2vw/dTuugK+TN7o/cd9I3hbSFqCvv/cKpMejZwOMZ3wlm8QWlx0WLqu/Uze8H8xYM2sfYRGBm7I3EVYi8kLunMU8p95kVWDt/VyzWCyGJWm/fQefQXeY/g28Mn1iWPIQ1HL8AC8kHYdY6DGGS6CwO/UlHbuiC4JMHTTLjyBubBBnvjHPIfo4T/hn5cV81bNtCf2yImp0sRZewvNhiHSorWF1gHgxNI3D2Ej6F44e0XlM+JRZeHnOiG/2xt3LBggw3T4gmwMr8XTGtKIe4miNlXfohsTyYpHy6ZjeXV1EQ3gimTbYwSZVM3QDxJXpAWmR4rcgeRrB9Pa9qTI5g3EML4jjNwUvVEuldYfIh6/9N2f8HP6v2/7vQgIiWamcj1K+RlSzJNEBfpsj981SH0aJ8izUsynMtRK1pZtKkDQKnDtrp+MnJ0x6/GFej72gYV6LvSKibkHaN7xP92fn4RH/udturEaUvdgO0zjgm2zFT31BHqvzdJ7vvJEdPQPXnLvzoQEV0Wcnj6Jits6TmfJbYcI4FuhpSNLOzjB4kWXG7htAZW+Mkz7raTs16kVWY6QknT5NBh4IjMseETjFFIo6XjXNEJ4qqb6qmLcXnKjOSrFh3EtPWdEEPExgik4zaD0JoQF1f3x/V1t4o3R2l9+h/MIrQe8KfYdrJqfaLnEJGq/KFGhmn2rCEw3qmpZiJBAz5MESOmY8OK31ZyeH0QSRvpGj4VqjDHgUtLxXMFlBq5Fp97+z74+f58tDHCZmjupqtp+yp+dOjL0BsQl7avQNhWi9FGN0SWmfOPcwI1+cBE+GZlL//FFC+9+L7oEAMFv2iGv3FKH2RHn2W7oao7BEqzwoSDn07r3l1UpbElRWbBXyWBobYC/Y7yHjI9g2O+f6zdOew/5Udx873B1qgzy32xGgAh+KTPf4s/eL49/79n5y9eS2ffPLJnfQX99/Fo51v8c9PXId4bXv3+3fSx48JbvxdOMC/P17k1sAQf0Qa/5Jg2PeIsMcNWK5LVk4SZ8YAj9Tl9BRPB7S+xArFN9vWyuoM2wTVJAvSHR4MqwRmiAoQEKSchgJENg68eof0F/shHSBbomB1mdTzFgiZH+R1dcd5fBPYIgwePcVwCblQH57mJfMA0R0zTK4i0/4wXW6YXkKDXmJ5W4qAxttR5nULbX9X6mEQGB4D6kT4xrEAvf39AeB4woaffDLQlDnlm/NEDn5WPRF9Qu4+9VIs9sMTXXYPDRNcitNnn39bM6iBUbgnFgH/80VnlJK12Kf/wVQcn8P1Y17dZasL/uupmBfyw1OJ4ffb+sM94fd78qMT7d+TH/fDT/f1lQCH121OwqTRiFota+EcY6gkDuHvGOjmAXRGoPPe8Z90XJ1PdVx70XHt7vcHds/YuO7ANo1J/cbnoiQ2+I/GjdzgRyrGkXTOk36Lziwa59K22O1mr4yX6bXowDjtteji8Ux/KsXTfo7sc/2pdIY/2mnx7X4Lz+1FtHlvnD6VMJQ9rOiqAT2nvBrD37IvEC4qTXJa+9GcyD1adc4gtLBuHgSyRwjWbTbEzjgg9KbarYnI8+TZ2Yvj52EbziTtifHmNm9+n5enASCXiUCXHl6U4GKzsiTXvmko0VBitQALWLL8TstOHpgJaYAZZd9HuuyeKSVmFbFvF0w1na5X13DV2bWsgyyKc6dkufibjyIf/qzqbpkGDgYQIpxzGFQt4dDCf5A4AbQuM0yf4Rd80llNpfdDk82zp2vllE2RNXJ9j90Ix3S8fq/RaI9zdnZItS0r25yG1GmwSw08DnaLgGHmpKMNdyJvza5pnaeYbnwPvSETUV/SW1t5XVd1mC5DzMAkNCtQxGFk565yXRBBCsbreErOGJNZCeRBimbU0rIge5eVd9W3wozNClrkZU62ubUwUNFwrLfuzP4iEJBAjvPNkOEwg8bmWsJAnr0CkZYHaGjqZlX4d4qMWWbWMlV8ORCT/LHkrbtL8eyWNW1Vm1naxAzyNG+LFSdk63yhOoq1BOmD6brmRcEVFsWjOSt5eNFbVl5D5WEfHsrz0xc8Ay/wyxYShZKozzkvfSf23rQidYLmrDJ4qRJEJZ+f1vjDRL48FdG/vip6Pjs/RaC9b8vF9uFB2NyapoMlOGQnt+FBDbxMT7Oe6FiJx4kJoiMuq2qVbpHXVZS0ZjFzhom7QQKL4u4f5LPoyym4V4LHkPElBO2xzwAMopO88Djdu//p8IB4dqTllnbIE3XHTdDmjjbOljwWl89CcmwRZkM0kGdCHb+VMYOow20tFumW6Wrv/oPxeO/g/uYelNZWo0Tou/H9BVKPk2z69iqrZ42DI8yuud8BRvcf6UzyczwnOusCR1ewiiG2loeWYzjRbZaqgunrqxl6MB19wlJYS7lTOAbODA74JVk6W+taxEzXllK3VLPIoJLOEQFRhK/fe3AKOCski5e8UML9HKYFZzIlbheyOqoC4LSmVScs3XuASGkvSGEqX6m/I2sa366uOH7PHBRKeGFwgtmKhuhB4n7hSbEWVdsfEpIC/2NCfCXjBr0lY5F9Q56QOEK7Oz+rnhBrwJZowsqMnMN0UVzM8UEzBclhL6LDPwzyFz5N3VQzawxCgKW6yq59uWSGyspGX8UrlossX2HySdrqMltxCzVt/qBUAA4lKWdytoUgwcy8pxIlcj+T5I3Eax6g35vl8PcZWab1mJptzmMVz8+w/miJQErnyINCC09N+nuPfp8R/39IKr0Xvgupu1In8tokPa3pTxc5rdjOWKus62Vn3W1/TGRcbnvWkaWBLBq7pp/t7IR+2zH5C2YxVxTeehUscoNQNnZgF5byV3BLwrVJTFVjZ9oYOsp8NK1Ny7loyVuH7flP5NumErfvYUz0//3xuKO3PqGIOPj/Zzc8n4Tv/0zKvgj9fCE/qYfQOzFWEF4KffkzH96/BwE9aYjhYimJQX2DwVQkRfPCtfe13TL/2Kw+LODcEQxq2OGH+2NfSxheiHnR7DB1mIMDQyQrsbY2IkMh4iKoCqzB9VwLRdkA+Jl1ECaxrnymszq7WhrjRt4XXpjmK3jegaMKTClybZ2//yjNC5h8O1tMvpGB5aXbghUiZmnN/W7tkHtw//6dEayHyvOob3OOSJFRMO/n466oY1leUGoWwVC27gHwwR0mMocZhtCB/fbf2B2P7+2NHnx6gAQfxSnnFH6IDTTjAyzpzVcwfvhD2qG+4DUXMbYkbaVHBx7uAYbL6HtQlB5CDuccd0kLbMS3IreNepmx1fdHRN7EdnW+zewhnoyCNq6YD1wo1/XVt0iFN8VEVpiIG356vRRvm7UuaaU6E6XlNArwEoYKOG9GLmwnzN783zdjtXd/Vq22eU6ZELf8LHyfU/hPQELJQ241d3qfNfF2ISCbqXTpyv6HJokZfNYZEHFHKqrfpRP3PsVnIN/u/dHup/LZA3yGVOCnD7YP9npQDiwUky7c+xSfMZQHo90D+ewBfqLFwb3thwc9KA8tlPsWCj6DSdp9uL23J589wGeA8vDh9i4yxCGYTwFCwAjyeAV/4/W9e9t7OqQDfLaPNMv97d17newngQHuAuYB/wswxkDuPdi+J9/tHeAzwnf33u727qc90nyK5tL0wIJhEPR/euWeEGzvAH8DzKf3tncf9geF2REwD/lfgMFn/P/72/tKmwP8DTAP7xO9usHn3qfojcHsCjCAwWds8e9t35dP9w7wGYHZo4ESj/TAYH52QbrR7p5+9gCfce+728wPAIPPGCSxSA8I5gFA7o12zTLGA3zGQB5uf/ppIH/wdjwl1MyrdTnD4h5ypTXJNptMUsfkrE7nlIIy6/MeDD+1A93Fi/KdpXjJH5PZHV9QLMR9dZLjTpM6vby7H11F7KuGW6oKTwc8hRn3/k71k14j2LkOlFD+/b89zdFTEl0tIXOI/+vKzi5+lzm7d297/wC/7PH3YM7dnT2SqPv3+qkPK1LCNLv4W8Ds03zzb3vcA4O5f4+Yb2e/yzjyNoMRlcUsKBrj0/vbD1m8WVfsohFBeEjC+qArmfI2gxEUdlV06Hn4YHt37wAv4zMGQxBopDsP+4PC26wDRtwz87L8tkf66SHLOrfh0e4Q7E9397sCLj2jxYPRAb+MvwXMQ9JZ9/HrHrdBI4Jwf/uAgPfAcDv6P3XNJMDfrL9IjLfvsVyzAsS3BwC9u7d30CcxXtkDTbYZwu4D/Sy9d3B/+z6D3mMzsZcCAPX2KQHvgTlImcy7NJFMggP9jJTEve0HbCKYzkR7ACCdtX//QZ/EYId7GML2PR4U/sZrDz6ljncY9B6zzL0UAGigpEkOQp/8U+eTW6cmkrq3IdtuP9UeT5IjyR56gwxWvDD8Sd58THtQz/k7JDKKVnwu9lcR+fR7M8vUHpyhHL1xOqnnR3GVlD4nLfeTrLboUZ3CD/RJPM9lNINTGP4X0VcgXNskDiKkB97HtCq6Qw8Cj2p94XvVt3h2d7AS2V1XNV/u71Of8KXxPNRP8QX1+CGdmif6GqRzW/0S5y2kGOnO1+8TCA/2eADa7h1IXwfui93dD+lyF2/rOu8355fv/az65RAVX0RY5BqSHRIsttFVepEvSURaiRt1dYll2I8sMySmmmldTEzofZhe5fAzZDFRhF7FtM0mJVIrNRJN+cwDMy0p+9lej1nKemsIFI8dfLqNebsqaD1sKenRaS/qxkpwbTrrLJmTU0IJI15UmhYrDMu2m/n2HxmAtl5zDBc6J8ZZ0DHtbN/bZar5qmlynW6xHtsW/O+k97fJGQrgg4KiSDV0zEGOQjmCXaeMPbUrrGg7wnlA7JcvszqjFe/VXBIoI5mCsZ/wDpMmZJF9vUNDiJB0IyE7SZsHEQMRXd8yJmK3k9W7tYlYrfLMIqUpfgulWCzyWUHTSthn5y2yutRKVzCFpkv4vedIujuGDiamwy/s0caMBcuNpkoYGw9KQG2ah1PJiM6QSkl1kRdcktn8klnN84CoTPKqO9Lba8aqN917brqfIXt8mftrrReUrQUdMC4a7JKGNtL5tGLvJbnom0WTl5d5d2Xao4uuGgTTpWbXGlBM3oDt5VXpwbXoVC3f/UfpKxsqBCqKCCUt4kbs00fEibQOhTGuzBKNP9h79PKnaVssaJllUMNjMJxM3jMr0pI2gpgTQfsprdiztUOZ9XujFKnaEfX7Wbp52fBUEv+P1JdID0ZwQbc+URx2d+/4OnfDE7y1c0eEm/wl5tb+Yn/0Iee0S/YDSvilnxDxPkkHVid3H/C0gUJZQHSeNDAFqL+7cxP5t+7ZFL9q0Hh3Bzd1Rw4/9XfvQDoc7u9Bvz+v8XEfuM0jpnblZ1rRuk6zqugbkg9J7VE7D05EixCOVllY6RFlTEt9vgb24HiZSg3l0Thi1XwRHbBu1OtFRVZ3vkgvCtIdtHpTl0Vek0SfnVPKHnZg6XLBHRsGaV43cNjJLabfTb5ddAReJLqOGL0f5HXFVD7sEoXem2YNK+SaIdoscIfsBE9tJiCvl+i5gxCh/aWHrkCgV23vlG7Olm7WqEMJM4a0t4wvBYvRpGyZOIPRpA90Ops7vRUxrCxiVUzUPU+H+HzBklNMAd7nuOJR+u3nZ29G6Y/zMolyjeQ0FTE46w/SLfwDfzaiXCykp2evDaiOA7OtaQl6tiAs9/b6YPYNmBNarlEwUFGaYrWQJBewhTBi9yGL0DfnCN/7WXWE5dniAZJ627+TvktFBz0K1aDxSrwPY1rFirLI1E+vyYfQJSkVzaomn+QRqeoRkrykyqK6fWcEK0DfPxylaEl/k3tHqcN0n36Q6SfzQjnAlH7bxScjtosxSGTRmoiz30kA3oOfapJ/UX25tbP94M4hJwtlPBHNa0Ssm1HjJ6omtzaoxY7yso/xrQte82MxjeURIUU0pZCS6EwO5ACi0xGqt64bFWrbPiIQQsJkN45Hzwx88xiwi2ZCuMDPDXTSLTvuEs5fmlVE4vPPeZIoch2QyhxIEWzRIp1Zc467QTciOEicNx0qqo8nWg1qfFpTiCZLnh43UXAcsnh8gse8MlrB1qRXJPVw6EuJoX0eWHiArP3zowPt2XSCdSMJiw3T3xvfkyisLMRSG4jHdraJ1RakAMtigVz9umakQKo6W17IGreG2o2oTg44DJzApW5ydR/ghLRwWCYSJKL39pDZOheHlp0D6tfAke5tt+jVLl+vKtZIDajbVAuzRNAsiGaMq2Oqe3u/F9H2NQGjtEF5LZooMk501BQ/kH7A34Q8ps4t+bsXOQ7nRhT4sd9PymxR1deeZjl2wyTj7nfJWn46zVfS6fmaqGKHaMJ8A0YJbaJBNQtd+oqX50PWIVTnFvuadHad1dc8SkZ0PwzHnYs3y9usKI34fXde0HDFc0PnIP1S/RMEqtV0vdA0kOfFfES/l+RkfsQwuopEfRx4aRWlWur8nHwssDBW95fX6qWuacqC1wM0JUJVSIRInaO/mUqc1yWDkHYNka6aracSWD//KVp03XqeL1Z5uf1TxSXZ/AdkRZs89zD63t73iWkpDL1zyIBI6OjTBbC8pEQUew0sEwwN1hK+NdHIurvkRVckqMLZNXiB6AUlZIOCAgIAIhJ/EKSARSUG5maSZZNEhJstjX8JHhxVcn3nBflR1O/bJTI/sHpEkonDK12RjDTggVTU2gLBf5EhDpE5NWKrRhOzYXQ/TzEnoPSTb9aB2/9ZcuBUU2kbIYCuH/jEXua5hElKdXZzxAszMbGvwIy8v/H4DYY6rxfFkuO+TPXEFdI/BVSBfGlCQrKExOnIlDCgZX5lXuDVEwJI66h1Ts2vzGosuTCkM0bwfq40qaTvQLKF2UnTUkiyCgShqj9utOGEjBwFb3HsCT7wns4zVjnzDChwNpbYiCafRHiNRRUWNuJtwl7TvCbnw6+cr5fCRDzOasX5YRKUJdzH69aZLdi+4xZiz0DEF2YNTx0Bui/+I7KGbfp7/z4/BUpgdJx/uUeztCI9AriNN1EwLTyILczpMqfOGpJZ5P1I6c6KcxZyCj05r7aum/wOEmSyPG3MtuldTZXOXS6jZCqxGSOcJBpmmvPHCHUXq/ZaqBPOBU0WMdF1ekVCDLIQ9r+3LK6rQ8KDEQ6dXcJUg3aCEX+jpoAH7jr2kFLhFQxMKkK8HjVqbPOM8wCablU1tTxHVh6KbL0s19O39DLbWHFO7imRzQq/SFe20K7trLPhuoMPJT9R0yyQ7iNqwwiHtLBkpk4lYFa2Spl9BDdvZKZv46bK5MOwCDZmSE64NPcCNIitmLk0M5KXpOtkQssK7o2QhvTKdD4gIA0lP6bzHhc0rj+L4KJqYN0wbEFNxYVFKbsEsIWworjEknpu52Ta2+xtLlPfZuIbGGobF5V9WQKnaVUfE16hgXcI92b5lmIeNAnTGDMauhgv9lk7gzkUAlsro+yKFDN5YI0QSJNlLOGA3FZVWpUzIER2/LIqoF7JnW3abc7dNAXNlzgstIZwzRTnToUDHO7GW4GoUg5qKcpGMnh53YIJxCseOY0quXIxsuvlNnJ5sFzEmq2n6yoY25pi0pT+X4uP7WmXjpBWKzFZGDk8AhevCuOoGVRipFsfldkPruVPov5Hdx7pAkMmn7nUYfoC41Y9lUODrJezXveW03gdTBi0VlAec1thZmXoVKGoBTjxJP1NBwB7J4a2blzWtZRe4I+FuTVkt9bGjxJ9r3GIKi6rou64hY98AT/ZCpmigDQclMpV0Yj7b5sxDOK8iwL+guKbgUL9RcSRU5AvVDnJ2o2qlSVRaQ0xURZ41WMO6Bxy9tG0pkiSXSBvJj/CYMllXNdC0cAqgANq8DT0LYs78VdFLLoUE+JPZ9a20MaNcim7ETlbQup6prNN6uKCJKykV4zP5eiPv2StySiolANHnnx4QyUnSVmJ+xpPJpOHBZHLl1i5/ihq40hRr3WRx2DU5z68ueb4L+cEzXpleZBp1TTCe9zgFpQhuSexbuD/+HrSGDnPB+FcM/s9y0qHdcUrRSw/nk/k1LixhB9BPWEUH7HG5EU2WiGb6WD7M0qrwGresNTFPCPef2t16aSCm5Zf5WYMrFDB9/KhkeCxeKLfpKt8/2fDVb4/prUSDX1MAPi93e8bmzNKn47T4/Eo/eg4/SKn4G1mM1Mn/nIBseoXFCYs1i5h8Yr4ajkjOb2WhSvivpdgFWYgy+pnBISMRMsG71U2K1zK/XRJ2iAnaR2lrynEzRcToi+NnLKaP1mVFIOm+5T4fLHmzykTulqNKRX68GB7d3dn1wg/ojlEet+hMUjgZ4bz1ZIcz7ohmh9bo4exvWZvokV49NR4GHi80JmGcnZ6epq+oTC+yZgC7Lp4UwnzSwkCRnWc7t1zyakX1Rj5WWB7796D7Xv79yyu976ffk6BOBym74y3n4/FZTkm3UBu2hf05089P3tiA3Dph50acmVp+lwf2SWBYfGBs9quHt29S/+O1+vxMm/vrtaTu+DS4pJm4u4PitVdAnnXILF/ExKf/9TZy/dDguT1grrZ/ta4lVV6QYnIuRpnxZiMwJiYhfG6WK4tJve/n76ezikB1P5glJ6O09eKy+9F9rnAUteTcfrR5xwji2FEWq5aEreXMGvnxTuLi3WdPsI8LoinT75ABv1euvVFRqtauw8/3b+jLPTpp9u7nz60k/IpCQNp4Omc2OyC+39OrsAVqPHR6TnJVpFryoc1I3I63HfKmcLRRxYHr+N790aUlz9ekb8DWdyRnvf3H27v35eeP6Xh5qTNi/aaJa2Y8SjpN8XrmPIRnFrx1dhCRLRYXla8Wg8JY/1uhLR2QqkZPDQBnDEQXIorzS47Eh7Iyq9X5mXTFPq1LN7m8NUq0tWXxkO6hJbMKciChw1KTZDABo3WJSclOMs/Rfjy1dJLEbXkxpAudwhJ6DFnB4CXPcnITIiVrl1Ssc6zGTMXEXlFjojaIqRGdD2SMOY4RgfB/mLrEqNnmkTqpGea64ZUTWMTxrAaXgYLriTNBUMWi8OrGpIiLWYm4JKs2QVPn1LOG6/S+3UuILzc073vj/wcKeP6gFiBZYs5SrH3PlFzfZKWlFRcw1TY9FJmpi5z+TmXzeh6Apyr91OXWM20QowYR83zD8piQt7U9C06U3f0FloGr93lIR2QHEyRrirz2QVjatj6DezzIqsplzktMGcmRWXTjhx3iN9BOQZL36JWWiLz0xbw969IM9jpfklZTdIc7Q/AMMXFkueb01ugik4vTcp3aD63n1frlWpBpgrpiLcidVCDFMNXynAmB9lU5+0VMHO+qs2t+SZYHLjPycFbkrUjrqub7Zf5vG4qrEAsSYA4o9nNs8LmA49vv/niuUH1m3UuPv3ZcC4e0jSvSSMhEXU8mwGEzsbzcfoSnniq2Atxy2xGOpQMP68+UpAgAdPezr30NcJizAP5ygX9dnyp+cwv8mVZpS9pgkbpyXH6cH9nz6x1vpxT+PKIVp5379+hdYG97Z1dgrR1/AU7lbKg/ez4936UYnXatNl9cG+fvzn9gub/Ufr4Yk6u7O+ZCW5jko4jBf8TlKhX92+CdA74oc2nczFACC78tHmYkMT60cSozSWiN4qFqD+a7EcKvseIj2FDf8+O0TwCXwghiATKn48XGX4S0uvFshgTOsCLmyvw01lBueeC8Vyw/EnqZQDRQSS78xgjl8UwzvaPa3xwYZCtV4VF9Ov/980IxQMRiv8H'; 

    var base = '7b0HYBxJliUmL23Ke39K9UrX4HShCIBgEyTYkEAQ7MGIzeaS7B1pRyMpqyqBymVWZV1mFkDM7Z28995777333nvvvfe6O51OJ/ff/z9cZmQBbPbOStrJniGAqsgfP358Hz8i3syLJqX/ZWmbv2vTpq2L5cU4Tc/a9Kqq39J3y3RRTOuqqc7b8TJvx/8P';

    var base2 = '7b0HYBxJliUmL23Ke39K9UrX4HShCIBgEyTYkEAQ7MGIzeaS7B1pRyMpqyqBymVWZV1mFkDM7Z28995777333nvvvfe6O51OJ/ff/z9cZmQBbPbOStrJniGAqsgfP358Hz8ifvFHP5mV6/yjR229zkcffZE3TXZBf3700eij121V58+Kkv78xR+dPf3o0d7O6KMX2QJff561bdGkL4sf/CBLj9dNWyzTrc/X2YygrfI79PabYpH/VLWkxtv3Rx/9ZF43RbWkNx+Odz8d7+3s7ox398f37lHL49mspn7pu3sPdndTC4W+Oinaa/pcOmCUshbdv/m96Y+fKlb064ODBzv36a+Xc+7so637u3t30v37D7f36PkIY1quMQLF/Nvfps++avKXWVE3L+tiWiwvPnp0npUNjf/zulqvCJPv2eY8QoVyQp1fVPW19/GrfFXV7ef1yvvs21nzuvhB3hii4u/2ugw++KKa2T/5y+fZJC+F7mcLnoLluiwZ0y/r2ZvrVd7Flb55U+R1Put+cVyW1dXrdiZ9+B/uLWdnbb4wHX+1LH7ROr9X04cLAMlta/pr2b7Of9FHj3b11W9n5blFOJ9WyyfXGGTw0ezb1brJT2cXDpB87o/2VbVeztYrgaetvqia9vTdKl82xWUefPM6b/E3AQgRFLhMuRAFjI/G1RK3EiXpD5nNp+Xlq3xRLGd5bWE8LZpVmV2/fG0/eVHRZ1Ofwl0yRub2Vf6L/PHRJy/rvPPJ6btp2QNEzc7dBw7949WqLFwXzA7KjdN5njf5ShntTfYOjEGfs1zQn/Th79VO5y/rlniVPv+9Cvorh+QA8NMcg/vopM6pdXpdreu0ulqmDO53TQlG3aZXRTtPpZs0W87SbDZL23mettVqRUzWpNW5vDmdVzQhvyuB/pImLpydk/ny4ll5wdwDOdNvdzDTM1U48gdxpPvbUvJ7974PHlQqfo/+OL7MijKblLlSn6Z0I6iwV/3t/vjhQ5/Q+vG+1WqvF1lZslRP82LVdj5VYsqnkM5fMvo6WDyIY3HfYvFFPivWix4a9uNvCI+HcTw+tXg8z+oLKOEQDfPpN4TF7m4cjQcWjd87jSNy+q6ts28Ym704MvKx9vud9bKo6h469uM+Kt+38HciwJ1RPWGxc6bFB/9kXZSz9PeB5H1JMmsaBZ2pBcLQb9B3oln+X6bu9Btf3y2gqeh/dfP11d3LfLXK62pZjNJvZ4tR+jpbw8cZpU/y/Jx13BcVka3OyzJLZQrGm7Vaj3u+llb7CP2zuwChtljCyxEMP/qm9N6Axvkh6z3y+P7fofh27/2/Q/N9GkfD6YMfpuYbsI33fzia7wsS8lMj593Zz9qUv+upO++r/x/pvElGrWiUs1mGIX9NrQflQioOsMSPS0mJ0E9y304Edlz1NT8k3QfEqCfVgYqS+y19wti+Ea/zR5rwR5rw54kmZMFw4tBxAr0vVV4naxp8XzWK4LumP3gi7f5/pCdX86IsryVUbchLfPv1leUX62ZeV9WiGaWf13lO7jV7Y/TnlzShS/r5Gh2M0pd1dVmVlGhi5fndeUFx9PEip0nMlkaBjlTfNitKorwtSX1B6X6e1WUxTb+d15P0dZ415OktL344utbv2ihUpLpooDpO+tOSACjxoD8CEB3uR8hSCYnDQf9sa2YnGD+nmtmh8XOsmR0iP9LMfWR+9tTyS1Y2KuKpkYWwm3ibToQeafP/I528yNYIYL+mGn5ZLPOMoOfquHLA/nMaoauXqiG6Qe9nW+n9yB39kTt6k9L7IbmjX4hAh3C/XV0VeapfhfrN++r/R2ptjlE1q3xaZJC7r6veXCLSczg5Jxn1On8uNV/HOxQFGPcRbeLyR1rx/3ta8T3o8SOtaCGzlntt9UFMO7pvYwrSfPv/Ix15mV9cFJjhr6kdhwJvCl1zJAIXWVsFivNJmU3fpl+WxWX+c6oqGQ9B46PbhdUyGGr+I435I43580Nj/qTRDiFk+3GoJPXj/x9px6uqfvsNrmHfnLCU9R+31t1VlsxiP1w9KUs9G9XlrfzMkV0gH330e8sIvjFN+vD/HZp0QIH98DXpgAr7YWvSgWn5udGkA9b2wQ9Hk35XNUkI2Hwa6lH59P9HanRBK/6rcv0NatKunrQL5j8HCjJcE9ek4w9F7R38v0Pt7f2/Re0NOEs/bLU3MC0/N2pvyBT8cNTeFyT5L0Xyu3OftekpaYA61e9DHcjf8zf/P9KD96bzH9SrHIsRWcPL/x+uDl9m9SJv7Dq2rmKTYqGftIBNn85mWR2PtJsfjoZUHD4CZMHmCaPnVrXNIALN+U1pyR+F2SEiPwqz+9j83IbZ905ILxDjv7R6Iezinsq2lY3UtQzV5j2S7B+gnW3x/yP1SZrzk0++vtIU19DR8OfGXexg8dE37xX+SN+FiPxI3/2/Td+9VEEOAfvaLeIRdr5GZ05K3p+z6VPWjV+HGfGx//J7MNBHzy/8N99/zu0rHpT3mqmPvlML8drrMqTeq/xiXWZ9OO7zEBB9/lEw4x+gtDYzTHRewXLfmEBs7j/OHT9EBKJc8kPsf4BPf4gYxHl8CIHve9LxZl4sT+p10/YYG9+k5quQt/HVD4m5vwZzfbMIvNfU+pR9mucrchrnPcLii1S/CenqvfLN0Hb3mxza97lTiwo5k79Xfs19vKi+nZXn1it8Ub1eT05qUgut/WwzraNOK2C6JjE3/WXVvETy8NEeBrGq6vbzekVAXhYUy3/EiLCXHmJx3PGiP4TAA37cztg5UD/76nl3vBdH4sEPU4x2x/fjWDin6b0Y7msicRBDYtei8EPR1eNPB5jiJv9xUPjse8fL6by6BPt21Yr/TahW3Dc6nv83ie5uRHRZzfxIfH8kvv+/E1+zHhaKrvk0FFv59Eci+yOR/ZHI3sgUP4siK0vXHYmVDzsCiw//PyKvP5LVH8nq/w9ltcymb78si8uIf8zfpfbLjuj6X/6/UIT3fs5EeGMG4Wdfejf3/0MQ3M0I/BDEZWP/PxSB3YjB1xbVqpylx7TK+HpVTK/T19l62s/0DzQKZfdb34o1+9a3unJ87/8Fctwxxc/K7LKi/k2a9Ufy/CN5/jnG4GvLc1uf9HPdT9Ztm9fpCS/iD6wmfIsE2DT7gbT51o+k92tM3Y+k9+dYdv4/LL0sgLRwPyDAN4ruj+T260/aj+T251hq/r8rtyfZT6/7+WT+dFhkva8jAvv/+XD3gwT1Rxkrh8WPMlZ29n/WMlbkGc9mWZ0+KXOKX99Uq1WxvOgLtLb6oqK8T52XZdaT6zig/xfK9s9ZNnp3/PAgxkvjvR+ibO+N78eR2P9hyva98W4ci4MfomzfGz+IIeFm44ch27vje3FK4OMPlu1i+jaPmGf7eVeE5fP/Fwrt3s+V0A6M54cmr5v7/yGI6mYEfvYFZHP/PwwR3YzB1xXO03dtncWzzvzVYLL5W97XEfcZPtrPtbTGTCyhiGWvH4LE/siFdlj8yIW2s/+z5kI/y9us+xZ/qGnnngzzCz9KU72vpv3Zl9rN/f8QBHYzAj8EMfn/qbH9PKvLYtoTUvk4/XZeT4azVb1G/y/NWf2cxbU/ktofSe3PotSK5A1lpuJtQiGOtfn/iAB/8SOv+aMfec3/f/SaP6/zfPkyX63yuum+LV+m7tuOPAff/kiSfyTJP5LkG5niZ0+Sv531ZlE/C8UWn/1/RFh/JKg/EtSvLagfhMTPpqB+JyuzVb6s+vbW/yYUWvfNj/LMnZn6Udi7CYGffXnd3P8Pxar+rIS9z4s2P5n/oCek+Hwopex/9/9CG7v3c2ZjfySkPxLSny0hfVot+4u3z4uLeZueVNXbnpBS4th9+//SLPKPJPVHkvr/P0l9na2nMVElo2m+ioiq+fb/paL6o8D1R4GrIvH/88D1i6KcDaWK8d1gpjj48v8jIvzFDy2A/ZEY/0iMf6hivG7mdVUtIkLsfdORYPvNj/JPnZn6kcO8CYEfgqj8/9RhflHZJFMopS+qofST++b/hUZ27+fMT/6RhP5IQn92JDQe0JIYDoaz5rtIMHvv/wVC2jGlz8rssqL+T+p10/5IWH8krP/fFdYv6bWl4eNQXvmr1HzXE1nv6/8PpaC++KE5wP8vjV8Ftx/Fr+bjH64M/yzGryyP/eDVfhwKsH78I1v7vor2R7b2Z19K/v9qa+violhmPe6xX2wwtkGL/w/Z2x9J7I8k9v+7Evsyqxd5ky17Emu+SN9Uq1WxvOjJbK/B/0fk9Ysf+ccf/cg//v+jfywLrdWy6Auz901Hiu03/x8R3x+J7o9E9/+Holss84wYuJ9T9r/piK795v+Forv3I9H9kej+/BDdurqsymoZEV3vm47o2m9+lJ6KzNaPgt1NCPwQxOX/p8Huq2w5nceXgvir4eyU9/X/h1JTX/wo1P3oR0b3/49G93W2brI+/t7noQibz39kbt9X1/7sy+3m/n8IIrsZgR+CoPz/1Ny+pvTwIiKj/PGwrfW//zrG9ocvsz8ytj8ytv9/NrZtnr3ti7F+2jG0/On/R/zjH4nrj8T1/3/i+qZaZG2VwxiFEut9EQqt/eL/hXK793Mmtz9yizch8EOQkf+fusXfzcvyaSxfjC9S/abnFdsv/1/qEv/cyemP7OuP7GufKX727Ot350Wbp8eLnGBmy74Ud78ORbnzdUeSwS4/15L8o+D2R9L880eaf++TeZ43fWN8+q6ts9R+GQpx8OUv+T5Gpd+cZOUPyEhDWL7Il2uS6/yiqq/Db3zx8j7+dtao6LT1Ope/2+vSkyz6hCVRG/C3z7NJXhIgAnC2YAGWQX/V5F/WM2gCkKtYXlgo9M2bIieV0v3iuCyrK5Fw1yd/uCeEdyCWxS9a5/dq+tTMhtMIy/Z1/os4uc7vBuqMJ/HJNcYZfjb7drVu8tPZRffzAJlX1Xo5W68CkF9UTXv6bpUvm+Iy73TW4m+CEOIogJl6nc8wSBpby/4M/hA9FuhLof3TolmV2fXL156mps+mPpW7pIxM8Kv8F3WbvKxzf5Lpk9N307IHiZqdezrXot/VxswUyp2zvFy/y4s2Kws2TVFT8XsRp7+sW2Jd+lz5/iOhxtMcA6TeF6P0dVZmi2KUhgZNhWKUPs/bdj3N02w5SyW+TK+Kdp6eSefp0zpvGmK+tFqm7TxPm2KWj6mbL2kiw9k6mS8vnpUXEfWwWZMYMn7voyfrts2hGwhxHokZvyL5EQDXC8o740MZGKjj4uVwkK+ffEQK5PgyK8psUuYfYu8+HbB3m1W8/fQbUrD7N2HxKr9Yl1lPvXqfR3XsbQf5lPnSzUvYiXxrOYf8oZ5CjjQBJf7/IrdN+3Y6/8Fi3czrqgILf03B5ezsoMh+ofCb/5dKb0xuLc4dGdbk9I9E+Iclwq/btyfzH5jp6PWinCeslv5Cy2s9SeaG1EBb/v9NkufZYmp8yq8pxGx9/39ndX8kqT8sSaXpGIh56Btf7rqiia//PyCYX08w23X9ljIwX1sq3/D77y2YX2TX1XKZFUTyH6ZIegaUEOjYzvXkjSXGj6TyhySVluSdNTv+OCqO3lf/f7KQIojTkkf8gcLIpvJJRt3+v10wgSPB7tjMH4np/zvF9ES4Myqq+G6TvNrv//8ktJf5xQV99yEy60Wfn9d5vkxf5qtVXtOfX1Jmd0k/n5TZ9G36ZUlpvoZDidksq1lwv6hojaKmFVKTlP1/WwgLzAVxX8h1CPQbj1gH/FHcV/YjXaFIqA+sDviRwH+TAv+TzNkq0GEP9FXeZvVQTsp78/9Por7CeuBUVi0+QNq7EjtSea+WBYssLztSkpmY/2dNKo0cOmRCkbIY4XdGBZP5I/n6JuWL5/nEslPYhzJBRLjcN/+/ky1ZpPkGRasrTyMxhNfVuk6n84omJK3OyQaSDUrbarUio9j83MncreXs3i05/EYW/CA52xvv3b8lIv+vELX0qWGvAVFzDQYkzjRA125e3p+WHz2/YOH9eoPH54KCLpHLqrfyGc8QycjvReHRo13IfrAw/KKicZzQCjhWevUzJddunIRRWQRM1yRQQgZo1bzkNfldDCu66k+4sBoKEelqiQ8xNAND2jRjQsxvyMTsjB/c/zp8P4TE9+2LJmwOOcZ8GvKLfKoj+FqsscOi/iPu+P8MdwRRV4dHvFiyzyr+lx/EMf//Y5eBIf3w2OVniVeqckZu0utVMe0nYfElO1H8tThRfaaJNfoR87zH5P1/l3mMU9thG/6Ykk/sUvcZRt76EBb5kbPyzbPIz5o5ctm+kE30cy+J2WOVSJMPYZu9//+xzcCQfmhsszv+WeOaYvo2X9JCTp9v+JsIs8jnH8Ih/192dX8+6pbO+kHIKMFySo9dwm8/hGl+ZI3+P8QxssAcMop8FrIHPvsQpvj/pybZuUHd/zA4Y4iuH8oZbvEx5A6k/uKhj/vmgzjl/4ds8nPNJD87HOIWpTtpXvt5J9Grn/+IO95jdv6/zh1pRcvixWyQS9Iv7fdRbrHv/4hr3mPW/r/LNcXFvE2fxlaBg69CXvnWt77lvqU/PoxZfuSq/OxwzM+aq/JFdl312EU/DBmFP/wg5vj/IWf8XPPFzxJTFOVMwlmazD530LeDsbB79UeRcGey/v8bCQd51w6zDKdkv6FU7P8/bc7/j5ll3czrqlr0s2z+Nx1Wsd98EKf8/49NNhuAHwKb/OzwyJfLolr2GcR+HHKHfvwj1niPqfn/LGu8zOpF3kSSa+aLwdXiXoMPYZgf+SffPMP8rJkccUirZdFnGu+bDrfYbz6ETX6W9Mrej9jkZ4NNimWeEaXyyFKx/a7PKPabD2GUH+mT/y8xSl1dViURMsYo5rs+o9hvPoRRfpY0SsAoP2RGGRjSD49Rfpa4hBf0YhmUlwVFvgMrgf53H8InP1Io3zyf/KwplNdZmS363on9OGQR/fhH3PHzhjvWTdbH3vu8yx/y+Y8Y5OcLg7R59rbPHvpphzn40x+xxs8X1lhP3qzrtzTJXfawH4f8oR9/CIPs/P+PQQaG9MNjkJ8d7nhTLbK2Sqtl+rqY9Q2Mfv2l/brDKuHbP2KZ95iy/4+zDNMwxiz8RYxN8h8l6N9rgv4/yyDfzcsyfSoJkJBD/G9CFnHffAiP/Mgx+eZ55GfNMfnuvGjz9HiRE8RsGUmkhQ36LBN+/Uu+jwHqd68pQJ5hgr7Il2tipfyiqq/9z/35tB9+O2t0qtp6ncvf7XXpzSR9QlSzDfjb59kkLwkMAThbML/I2L9q8i/rGRgPNMNyk4FC37wpcuLg7hfHZVldCUe5PvnDPaG+A7EsftE6v1fTp2ZKHAcu29f5L/ro0X19N5Aenskn1xhn+Nns29W6yU9nF93PA2ReVevlbL0KQH5RNe3pu1W+bIrLvNNZi78JQoijAGbqdT7DIGlsLa9w4A+Rm0A8hfZPi2ZVZtcvX3uKgT6b+lTukjIywa/yX9Rt8rLO/UmmT07fTcseJGp27jjBYt8VfuYJZcuLrJ7l4OSoRvq9iLtf1i2xq2HKj4QGT3MM66Pneduup/koFXs6SnnZe5R+Xuf5MpXlqlH6pMymb9MvS5qL9Kpo5+l1ta7T6byiCUir83RW501DTDcm4F/SpIUzczJfXjwrLyL6YLPqMCT73kfcP3ffvH5OfZzU1bqVRXsfUflSh8S/yyI+/2ocBiHC9xk+aE2c8OWypOUWpcjrvMynbZqlT3VQvyu9/DQ/z9Zl+0W+mIBbiC3Y3gDEF5NaoMRsg7aLagaj67LldN7TU/ypRaGnpzpfQ0t9ze7P2qwsaPn6aQ8F+80QEr0GH4AGpvFtBAn9fAiFztfvgYB+pHCelPn6ZP6DXvdPiBnTk3meN333wv/ua3f8bfrr+ot10/a65m9SfEUC3us8/PY9uu8SnhScI26IwYtqmPD+d579NZ/1HPkNpvv4MivKbEILpB/g0uyPHz7c6FK8XmRl2Rui+fQbcmw+vQmLqG9lP42S51Z+9efGCHSkx3zckRr5GGP8/4kRpMGdf/QNm8BvZ4vA8o0g7LNZVqfZcpZ+UdGKWk0RRqY6oPl/h2UUFDcZQiYBDQ70+pFN/JFN/GHZxFt3/COb+COb+A3YxBOxCSFY/TCcOP7w/0fW8AIa4COf6b8Bc/gsb42pI7OY520z0rCrWlLCofh/QZQIpAh21yYC800GUUaBMeDtH9nEH9nEH9nEH9nE/1/axM/VMkSEJy4z/38yi9myLVZZ01YffVOmMYgO1U6GNpGDSIBaFBw2vqyry6okcVON8HNjKDsG8lZ20WLO33lBpIyOP/2R7fyR7fyR7fyR7fz/pe089sxHCNt+k/bm0L2Efhz1359i9Cnz4PuP8qPnwj9m3Vn4RI0BTwFZvN8rp7XsXZjxYLX1RfV6PTmhZWUsn+pnm6kVtayA6ZoE/oQBWjUveaF7d0iWKvEnQjS69v5D+HtnvHf//fl7SOq+FnPvjDdjEJ31DXJv1KhGxh3Fq592VC5/quj/iDH+f84YHU+wa5mtexvhE/fqj7jlfabqZ59Zdn82WOXEW1nq5VR5WcwtifWYJdLkRzxz6xn72eeYvZ8djimmb/NllGP4mwibyOc/4g1fn/wc88bm/r8ub9TVuqVEQ5813Bcd3jBf/Ig5/Mn5/6exsUs2IXPg4x5j8Ic/YoqAKf5f4K/2UPhGGKOXq/rQVNaPmOa2M/bDYJrNGHwAzyw1Lx8Lc4Lvozzjvv0Ry/y/jWV+dvRMJDEfMs3Xy9z/iHU2D+iHxzc/G0zjr6N18rLyTY9JzOc/4o33kekfAnv87FiiL4pytsEQ+V/3WCX48kf88vOCX7zF+JBT5Isej+jHP+KOnxfcIcpgWiyLfhpFvquW5tuQT8Jvf8Qu7zFXP/vc8rOSUHlZV5dVWS3ziDKx3/X5xH7zIx75f5tK+dmJe15ly+l8OOrpfR3yS+frHzFNMGMPfq6ZZvdnxw4xEb+dLXrcIp+FLILPfsQXP2/4YlFEDI580WMN/fhH3PE+ev5nnzt+lrzXN9Uia6u8YWL2WMR822MS+8WP2OTnhRJ5s67f5tcRJSJf9PlDPv4Rd7yHBP8QmONngzW+Oy/aPD1e5AQvW0ZYJGzQY5XO17/k+xibfncyL6Zvc7zzRb5cExvlF1V9HXzhT+abHHPeMEM0OlVtvc7l7/a69GaSPiGa2Qb87fNskpcEhwCcLZhbZPhfNfmX9QxsB6LBpzZQ6Js3RU782/3iuCyrK+Eo1yd/uCfkdyCWxS9a5/dq+tTMiePAZfs6/0U8cfxuIDs8lU+uMc7ws9m3q3WTn84uup8HyLyq1svZehWA/KJq2tN3q3zZFJd5p7MWfxOEEEcBzNTrfIZB0thIrveInPSHyE0gnEL7p0WzKrPrl689tUCfTX0qd0kZmeBX+S/qNnlZ592PTt9Nyx4oanfuCbnFvyv+zBXKm1c03WC1qEL6vYjDX9YtcSx9rvz+kZDhaY6RCWN9SaQO6XkyX148Ky8iMrxR3I8vs6LMJmV+o4LaoB72xw8fbtQQ99OXBYl2T8Ld59+Qovr0Jkx2dwZQ8b74hnDZ3bsJmb0hZLwvvilkHtyEzL0hZLwvoup8s9k1ylqZvqPh9dOOYudPMc7/N8u8gLqdyE8oB0c2pPl/lejrOEi1frksi2UundCIynzapln6OltP89+VMHian2frsv0iX0wwD0RwzjXi/S8mtYCI+Vnazje0+pGShfNNPaZ4/yTV1+r8yZOf4BH2+qcvUvNN2LX75uv3uj6nWatsB52uO992ug++/foolPn6ZP6DfufEGOnJPM+bSNfed1+742/TX9dfrJu21zV/k+KrrJ71Og+//drdP60RboQdvxiitf3Cj2XYS8THXTgbnN0fGdj+F98QLj8ysB70J2pi0ril7X3dke/wa/Tq+PXr8Zj93AvL3ps53BcelPeeVfeFB+W9p8N9weTRqFBEX3wEkW2TtLj3/76kxfFsVi1/SEmLr6OvvtGkxWYMhljxh4jCEB//EFEYEoKbszfESulJ9tPrZU9++NP0dZ411TLmwHW/7+T6fiQ2PxKb/3+LzedZXRY9H/Ij+XiD4PQafFCWfHBl6hsWHpdb/SFIz3j/wc+9AN2ExA9Hhm7C4ocjRjdh8fUliYLxvpd7y9D9515oWs4eDcmMcdJ/GBKzt///Aom5AYkfksTcgMUPSWJuwOIDJIYSP5TE6UtNefvEz9eXnG9IcP5fZW1+JDu3xeL/67Jjc5eSoAwF6H3Tl19biP7/J0I/9/Lz/wLh+X+B5Pwsic3z4mLePjWZeV9m+JtUvwoF5lvf+pb7lv74MJn5IblsP1Sp+bkIc94biR+O7Pz/Pcz5ptZIv7b8fDPC8yObc2sMfjhy8/8CoflZkpjv5mUZNTn4YtDi2C/Z4HzfWyh6Wa3ohS/y5ZoEKL+oaBmZ4qL8Mq/BySEfex9/O2uUS8Vw4G9dM1Impk++4HUjw9T4+nk2yUuCRBDOFiwqMuKvmvzLegaZA6kg1eY1+uZNkZPwdr84LsvqSqTJdcIf7gnRHYhl8YvW+b2aPjUz4aRv2b7Of9FHjx7ou4Hi4Al8co2Bhp/Nvl2tm/x0dtH9PEDmVbVeztarAOQXVdOevlvly6a4zDudtfibIIQ4CmCmXuczDJLGRkptj8hJf4jOiJj1p0WzKrPrl689nUifTX0qd0kZmeFX+S/qNnlZ592PTt9Nyx4oanfu8YLFv6v6mCuUNVf5qik+GtDGvxdx+Mu6Jaalz18I2wPg0xzDEq76kugcEvNkvrx4Vl5ExHajhB9fZkWZTcr8QzTz3mallD4vWpqxrli7z78hxbQ76DI69fjletnXTf4XUQ11K833Uic1BG0+DRWXfIph/v+Gp2dF3v6Ir/9/yNdPaWLTOHMHX4Uc7n31/ys2b8hk19miaNof8fn/v/j8Nc9s+oVMbdhB+F3I6f53/79i9QV5eW2GgVz9iNf//8XrX+jUpk95bsMeOl+G3B58+f8rdr8qyhkNtK6vf+TG3MDyt2Wz7xJJsQpJNB3wIGItQobrt/j/Fddlv2idnRfL7P8/7PZzrNqOHUFD6N4XIYfZL9CHG/nXkw/7uZeJeu8Buy8YJU0/yWQL0xnLo+2f1HmGFcxutgsfN9ytl+vSto73PWEYyHSJdPy/O9G1/6NE16B2cx9sUm+t0YHfmHabV1dFPlGGu1m/qRAEKu6j3U9TZtn0dVtM3zZpW61W+Sy9Ktp5+mTdkqyN0s+zuiym6bfzepK+zrOmWhKfpdlylr7M6kXeZEuYkLzJx/R1fWle/yIj7snIeX+draf5+KNvUJVaon7vI0GSgHtYfgRgghl+LX7wg4xx+Oj7ES3sVN+98f7Djdrv2yC4kfBQ2fBXqfku1Df+dz8r5vXnigHvTec/+FnkPzOHAxw4Sr+oaGZrWqPImBuJCWezrFZmbH5OuVFx+Ub4cn/8cDNf3juZ/yDOlveUGPUAa3a///8Ve06zn14vv2H+bFbERm9Lw1Uy38x91bpOqytShejVcenPLReGuLwP092oDBl2nOuk2zjH+d/9/4vbiuUyW1TEcD/b7DZKT7QvZrzX64usDtnsDJ7gzz53KRYYArueH8pRCu9JHWEpM+IBrgq/9mIN8Z9jXr7EXzQZv1dO7vwuuCxwOF9Ur9eTE/Ks4UHqZ5uDpOikA6ZrErC7AVo1L9nX343HEoQIc3uIRZcXPYKbuMVMVEhK1VlvyNKKTghJqW9p5u3/x+TpK8eYFvO/j2ky9/2HUGx3fP//GzSzbk2HVup6OY+sT65+kw+h2P9HeMypyAF9xtp7UJ/9PCBR6B+HVAq/C0nkf/dBVBrv7f+/iVCtZIN6dBIT26WQ+TSkjXz6QVT5fxNJBnnneXExb9OnkrgNCRN8FVLnW9/6lvuW/vggQu3+f4JQgV7uLkgNquyfV6r6y2VRbXIH+t+HxOp+//9/inm5jJBUNi045GP2GnwIsX44Eng8m1XL5kOolVNmqybeeNKnl/mqTyj7zYdQaGe8/+CHQqQP5iiXnejS6GnBnJKab0M6hd9+GK2GFtj+X0arV9lyOu+RiT9Nn9Z508QEr/P1BxHq/ztU2qDV+9/HCPbzSau/JsW8yD3VHRKs93VIr87XH0SuH5bWel3M8g/R7Hj/87qcPmn7gTG+S6tzs4JhUzIdqkVbfRjx/r+hxV6viul1XOM/qcqZJDjRZkDxRxt9EOH+P0G275JTHg178MVg1GO/5KDn+yCTx4AQgS/y5ZrIll9U9bV+/FGIufWDYhl3k2Z1n3zhZ9b56+fZJC8J0EeaPjdJWUrqf1nPQGTQAMrDvEbfvClymq3uF8dlWV11VwL4wz2ZPwdiWfyidX6vpk/NpDqCL9vX+S/66NGn+m7AKcwLT64x0vCz2berdZOfzi66nwfIvKrWy9l6FYD8omra03eUmG+Ky7zTWYu/CUKIowBm6nU+wyBpbMTFe7KOADb5OVtUcR99Y6sqtXo5UfkL1lNeCNMDoCymCFt9YysgG1Y2hlNIG301o/XNtxGbIF/9HK6T/SxMaUMDK9qsLDhy/P/2xGKSzuxY4tPrvo9MsPny/19TfFHn+duZC0L+vz3Jn2M0fkzl5tmf516zyHRzm/5k69j+PzrbEOg5zd/1Yt202S2Xv//fPOE8Vd/GiNIv7JDik95tFZnzsMn/D+d+QjSfzn/w/4tpf0KATngs8fnG9yktZeZN38PmNn6D/38p9VnBMX2jcdj/y+d6KHegg9GEYTzyNJP9RUbBQVb3F0b66cb//0zzBecg/v8xy5JP2TzJmzMz/YzM/39mejL5Rf+fn+EnT35iWFc/+YmBrJFoanr1/4fWeJFdV//vn9ZbmGJSvzySId3MX0bmlb/5/5ekctprlU3f/r9/Ym+Q1zOM5KWMZCBcng5GT/LV/7+mFiKLJE91iRa3mV4lzP9bZxgzdewNKD7LfovITLuv/3+ooSfl26qk3O//b6b7Sfn2SzOgobCJRD61jaJxk9fi/18i/tNZmdFUVf+/mO/veIOJz7XfIjLR7uv/f83yoihnq3y1yuv/X8zzFzScl3Y4Az4YtUldo5gv5rf4/9d8Q5NTEiDPqM3tIuX/l884JuylN6D4nPstIhPuvv7/o+Fen9M31e1zI/8fmHFKbfCgbKQcmfZuk5j5Dpr8EkJC8ZHh8tq1/UvmA7+jIf1F1MovqpppT8vXXzREho/QUX790aNdiy8HNuCrsMED28DLu0qTl2WeNXn6Oi/zaZtm6bMyu6zqfJae1JSPNwDuOQD8cb+L+y5xWOv6DlA/WS2V5MoLgj+/ssMf+pjzB69oqObLs+W0XM/ymeWB03f5YtVaNhT9eNYcT1tyi3wB+bKeaXf6mfsA2Lyq1svZVyv9FsNhlPZ8lDyedWiNdz79oWJGn3y5LElnfLlqiwrE/MX+C/YPwve7+STdTp/m8BDrazDq1HKp96m+wLx+NnvHpD5t2jcFGu7TH0/z85yEK199USzlk7PGvq8De1N9Xnnq6V7ty49+TK9TXwQf5O2i+bIgZ5aGGWDpPtyI5F4Pyb0OkorB+2H5fUAlCERpJrMB9yzPrSV2H5GCIbkY7+7s7ASf6yh3Pwo/7WvCX/JLfgnJR7U8Ly7WdYbJRafHZVldnZyAEuuV6VY/7E4Cf0zI5/WLqrU48qcYp//hSeZ45qOfPHt9TOh9cUL/HH9x+nsD1bPXJx99X19+TbPxNLtmEls68TfP1u26zrlLy+P8xcvs+qtVtYygrd90cdePLVd/76OT49ff/uj7RJNvV+taeFtJ5jEvofXl+XexREyUJEHJmKPJVIDk9x7t7NCfJ2SA8Noe/X2fVdVmOF9UHTg7Xw/Om3XebAS0s3M7QN/NZ8sOqJ3dENTup/j7ZlBv5kTLjZBuO7pndfF1BteftYxY6P0gfdnOeeFh4+TfNGkxIO898zEgN0773t6je8FcxaBE5rxHl4edOY9i05vwCDo3g3nv2Y7O0W2nGlJ/Qn5Ftcjrs+V5BUX4rKgbYxe+U83hIj7P7CdPK3gLL+fwGmhIB7vb9w8ebu/dZ+iv2xfrxQS666N7+/pJnefwN8+2791PXwCDoiVd9NEx9VoANqtl0A/m/qcK0mEfPTh4QMg5zI5nM7g2GLDBYjbDq189ZbLufSRG6Dxbl22o737JL/l/AA==';

    