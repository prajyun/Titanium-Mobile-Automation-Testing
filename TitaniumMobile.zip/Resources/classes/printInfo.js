var deb = (function(){
	var ro = {};
   ro.ug = function(e, str){
      if(!Ti.App.DEBUGBOOL){
         return;
      }
      //Ti.API.debug('\n');
      //Ti.API.debug('\n');
      for(var i in e){
         if(i.toLowerCase() !== 'clone'){
            try{
               Ti.API.debug(str + '['+i+']: ' + JSON.stringify(e[i]));
            }
            catch(ex){
               Ti.API.debug('ex: ' + ex);
            }
         }
      }
      Ti.API.debug('\n');
		Ti.API.debug('\n');
   };
   return ro;
})();