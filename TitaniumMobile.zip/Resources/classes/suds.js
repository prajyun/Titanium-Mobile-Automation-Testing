/**
* Suds: A Lightweight JavaScript SOAP Client
* Copyright: 2009 Kevin Whinnery (http://www.kevinwhinnery.com)
* License: http://www.apache.org/licenses/LICENSE-2.0.html
* Source: http://github.com/kwhinnery/Suds
*/
function SudsClient(_options) {
  function isBrowserEnvironment() {
    try {
      if (window && window.navigator) {
        return true;
      } else {
        return false;
      }
    } catch(e) {
      return false;
    }
  }

  function isAppceleratorTitanium() {
    try {
      if (Titanium) {
        return true;
      } else {
        return false;
      }
    } catch(e) {
      return false;
    }
  }

  //A generic extend function - thanks MooTools
  function extend(original, extended) {
    for (var key in (extended || {})) {
      if (original.hasOwnProperty(key)) {
        original[key] = extended[key];
      }
    }
    return original;
  }

  //Check if an object is an array
  function isArray(obj) {
    return Object.prototype.toString.call(obj) == '[object Array]';
  }

  //Grab an XMLHTTPRequest Object
  function getXHR() {
    var xhr;
    if (isBrowserEnvironment()) {
      if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
      }
      else {
        xhr = new ActiveXObject("Microsoft.XMLHTTP");
      }
    }
    else if (isAppceleratorTitanium()) {
      xhr = Ti.Network.createHTTPClient();
	  //xhr.setTimeout(20000);
    }
    return xhr;
  }

  //Parse a string and create an XML DOM object
  function xmlDomFromString(_xml) {
    var xmlDoc = null;
    if (isBrowserEnvironment()) {
      if (window.DOMParser) {
        parser = new DOMParser();
        xmlDoc = parser.parseFromString(_xml,"text/xml");
      }
      else {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(_xml);
      }
    }
    else if (isAppceleratorTitanium()) {
      xmlDoc = Ti.XML.parseString(_xml);
    }
    return xmlDoc;
  }

  // Convert a JavaScript object to an XML string - takes either an
  function convertToXml(_obj, namespacePrefix) {
    var xml = '';
    if (isArray(_obj)) {
      for (var i = 0; i < _obj.length; i++) {
        xml += convertToXml(_obj[i], namespacePrefix);
      }
    } else {
      //For now assuming we either have an array or an object graph
      for (var key in _obj) {
        if (namespacePrefix && namespacePrefix.length) {
          xml += '<' + namespacePrefix + ':' + key + '>';
        } else {
          xml += '<'+key+'>';
        }
        if (isArray(_obj[key]) || (typeof _obj[key] == 'object' && _obj[key] != null)) {
          xml += convertToXml(_obj[key]);
        }
        else {
          xml += _obj[key];
        }
        if (namespacePrefix && namespacePrefix.length) {
          xml += '</' + namespacePrefix + ':' + key + '>';
        } else {
          xml += '</'+key+'>';
        }
      }
    }
	//Ti.API.debug("XML: " + xml);
    return xml;

  }

  // Client Configuration
  var config = extend({
    endpoint:'http://localhost',
    targetNamespace: 'http://localhost',
    envelopeBegin: '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>',
    envelopeEnd: '</soap:Body></soap:Envelope>'
  },_options);

  // Invoke a web service
  function wasResponseTampered(timeStamp, signature, responseText){
  	//Ti.API.debug('should NOT PRINT THISS: ');
  	  var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
  	  
      var hash = CryptoJS.HmacSHA256((timeStamp+''+responseText), C_CRIT);
      
      var sigHash = CryptoJS.enc.Base64.stringify(hash);
      
      return sigHash != signature;
      /*if(sigHash == signature){
      	return false;
      }
      else{
      	return true;
      }*/
  }
  
  this.invoke = function (_soapAction, _body, _callback, _errCallback, timeout, _progCallback, _sendCallback, shouldHash) {
      //Build request body
      var body = _body;
      if (!timeout) {
          timeout = 30000;
      }
      //Allow straight string input for XML body - if not, build from object
      if (typeof body !== 'string') {
          //body = '<ns0:'+_soapAction+'>';
          //body += convertToXml(_body, 'ns0');
          body = '<' + _soapAction + ' xmlns="' + config.targetNamespace + '">';
          body += convertToXml(_body, '');
          //body += '</ns0:'+_soapAction+'>';
          body += '</' + _soapAction + '>';
      }
      else {
          body = '<' + _soapAction + ' xmlns="' + config.targetNamespace + '">';
          body += '<request>' + _body + '</request>';
          body += '</' + _soapAction + '>';
      }

      var ebegin = config.envelopeBegin;
      config.envelopeBegin = ebegin.replace('PLACEHOLDER', config.targetNamespace);

      //Build Soapaction header - if no trailing slash in namespace, need to splice one in for soap action
      var soapAction = '';
      if (config.targetNamespace.lastIndexOf('/') != config.targetNamespace.length - 1) {
          soapAction = config.targetNamespace + '/' + _soapAction;
      }
      else {
          soapAction = config.targetNamespace + _soapAction;
      }

      //POST XML document to service endpoint
      var xhr = getXHR();
      xhr.setTimeout(timeout);
	   xhr.validatesSecureCertificate = true;//CHANGE BACK TO TRUE FOR LIVE APPS --- CHANGE BACK TO TRUE FOR LIVE APPS --- CHANGE BACK TO TRUE FOR LIVE APPS
      xhr.onload = function (){
      	var responseTimeStamp = this.getResponseHeader("X-Stamp");
      	var responseSignature = this.getResponseHeader("X-Signature");
      	
      	if(shouldHash && wasResponseTampered(responseTimeStamp, responseSignature, this.responseText)){
      		_errCallback.call(this, "Error validating the servers response. Please try again.");
      	}
      	else{
      		_callback.call(this, xmlDomFromString(this.responseText));
      	}
      	
      	//_callback.call(this, xmlDomFromString(this.responseText));
      };

      xhr.onerror = function (e) {
          _errCallback.call(this, e.error);
      };

      xhr.open('POST', config.endpoint);
      xhr.setRequestHeader('Content-Type', 'text/xml;');
      xhr.setRequestHeader('SOAPAction', soapAction);
      xhr.setRequestHeader('Accept-Encoding', 'gzip,deflate');
      
      if(shouldHash){
          /*Ti.include('/classes/crypto.js');
	      Ti.include('/classes/crypto64.js');
	        
	      var timeStamp = parseInt(((new Date().getTime()) / 1000), 10);
          var sig = timeStamp+''+(config.envelopeBegin+body+config.envelopeEnd);
	        
	      var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
	      var hash = CryptoJS.HmacSHA256(sig, C_CRIT);
	      
	      var sigHash = CryptoJS.enc.Base64.stringify(hash);
	      
	      xhr.setRequestHeader('X-Stamp', timeStamp);
          xhr.setRequestHeader('X-Signature', sigHash);*/
      }
      
      xhr.send(config.envelopeBegin + body + config.envelopeEnd);
  };



}
