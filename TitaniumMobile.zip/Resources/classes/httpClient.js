function HTTPClient(_options){
	
  function isBrowserEnvironment() {
    try {
      if (window && window.navigator) {
        return true;
      } else {
        return false;
      }
    } catch(e) {
      return false;
    }
  }

  function isAppceleratorTitanium() {
    try {
      if (Titanium) {
        return true;
      } else {
        return false;
      }
    } catch(e) {
      return false;
    }
  }
	function xmlDomFromString(_xml) {
    var xmlDoc = null;
    if (isBrowserEnvironment()) {
      if (window.DOMParser) {
        parser = new DOMParser();
        xmlDoc = parser.parseFromString(_xml,"text/xml");
      }
      else {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(_xml); 
      }
    }
    else if (isAppceleratorTitanium()) {
      xmlDoc = Ti.XML.parseString(_xml);
    }
    return xmlDoc;
  }
  
	this.invoke = function(_action, _body, _callback, _errCallback, timeout, _progCallback, _sendCallback){
		if(!timeout){
			timeout = 30000;
		}
		var xhr = Ti.Network.createHTTPClient();
		xhr.onerror = function(e){
			_errCallback.call(this, e.error);
		};
		xhr.setTimeout(timeout);
		xhr.onload = function(e){
			Ti.API.debug('ready state '+ xhr.readyState);
			if(xhr.readyState==4){
				//Ti.API.debug('server reponse '+ this.responseText);
				_callback.call(this,xmlDomFromString(this.responseText));
			}
			
			
		};
		xhr.ondatastream = function(e){
			Ti.API.debug('progress '+ e.progress);
		};
		var url = _options.url+'/'+_action;
		Ti.API.debug('url :'+ url);
		xhr.open('POST',url);
		xhr.send({request:''+_body+''});
	};
}


