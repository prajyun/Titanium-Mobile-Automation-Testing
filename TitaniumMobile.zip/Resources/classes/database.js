//Ti.include('../classes/aes.js');
//Ti.include('../classes/cryptoHelpers.js');

//var db = (function(){
var DB = function(){
	var getdb = function(ro){
	
	   var api = {};
	   var dbVersion = 1.0;
	   var conn;
	   var encrypt = function (obj){
	      try{
	      	 var cryptoHelpers = require('classes/cryptoHelpers').cryptoHelpers();
	      	 var slowAES = require('classes/aes').slowAES;
	      	 
	         var key=[156,36,46,156,33,218,42,43,45,167,44,80,37,155,112,85];
	         var iv = [33,37,85,38,35,85,222,121,100,173,58,200,184,37,209,33];
	         var object = {};
	      
	         var iptStr = JSON.stringify(obj);
	         ////Ti.API.debug('iptStr: ' + iptStr);
	         var input = cryptoHelpers.convertStringToByteArray(iptStr);
	      	 ////Ti.API.debug('input: ' + JSON.stringify(input));
	      
	         var crypted = slowAES.encrypt(input, slowAES.modeOfOperation.CBC,key, 16, iv);
	         ////Ti.API.debug('crypted: ' + JSON.stringify(crypted));
	         var base64String = cryptoHelpers.base64.encode_line(crypted.cipher);
	         ////Ti.API.debug('base64String: ' + JSON.stringify(base64String));
	      
	         object.data = base64String;
	         object.len = crypted.originalsize;
	         
	         return object; 
	      }
	      catch (ex){
	      	Ti.API.debug(ex);
	         return '';
	         
	      }  
	   };
	   var decrypt = function(str){
	      try{
	      	 var cryptoHelpers = require('classes/cryptoHelpers').cryptoHelpers();
	      	 var slowAES = require('classes/aes').slowAES;
	         var key=[156,36,46,156,33,218,42,43,45,167,44,80,37,155,112,85];
	         var iv = [33,37,85,38,35,85,222,121,100,173,58,200,184,37,209,33];
	         var object = {};
	      
	         var obj = JSON.parse(str);
	            
	         var cipher = cryptoHelpers.base64.decode(obj.data);
	            
	         var decrypted = slowAES.decrypt(cipher,obj.len,slowAES.modeOfOperation.CBC,key, 16, iv);
	      
	         var output = cryptoHelpers.convertByteArrayToString(decrypted);
	      
	         
	         return output; 
	      }
	      catch (ex){
	      	Ti.API.debug(ex);
	         return '';
	      }  
	   };
	   api.open = function(){
	      conn = Ti.Database.install('/hungerrush.db','hungerrush'+dbVersion);
	   };
	   
	   api.close = function(){
	      conn.close();
	   };
	   
	   // ****************************** Customer Table ********************************
	      
	   api.createCustomer = function (email,pwd,storeID,obj,isDefault){
	      var rtn=-1;
	      try{
	         api.open();       
	         conn.execute('INSERT INTO Customer (Email, Password, StoreID, CustomerObj, isDefault) VALUES(?,?,?,?,?)',email,pwd,storeID,JSON.stringify(obj),isDefault);
	         //api.close();
	         rtn = conn.lastInsertRowId;
	      }
	      catch(ex){
	         Ti.API.debug('Insert Error: '+ ex);              
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateCustomer = function (email,pwd,storeID,obj,isDefault){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE Customer Set CustomerObj=?, StoreID=?, isDefault=?, Password=? WHERE Email=?',JSON.stringify(obj),storeID,isDefault,pwd,email);
	         rtn=conn.rowsAffected;        
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);        
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	      
	   };
	   
	   api.updateCustomerObj = function (email,obj){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE Customer Set CustomerObj=?, isDefault=? WHERE Email=?',JSON.stringify(obj),true,email);
	         rtn=conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);        
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	      
	   };
	   
	   api.updatePassword = function(email,pwd){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE Customer Set Password=?,isDefault=? WHERE Email=?',pwd,true,email);
	         rtn=conn.rowsAffected;        
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);        
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateUsername = function(email,newEmail){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('DELETE FROM CustomerCC WHERE Email=?',newEmail);
	         conn.execute('DELETE FROM CustomerAddress WHERE Email=?',newEmail);
	         conn.execute('DELETE FROM CustomerOrdSummary WHERE Email=?',newEmail);
	         conn.execute('DELETE FROM Customer WHERE Email=?',newEmail);
	         conn.execute('UPDATE Customer Set Email=?, isDefault=? WHERE Email=?',newEmail,true,email);
	         rtn=conn.rowsAffected;        
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);        
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateCustStore = function (email,id){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE Customer Set StoreID=? WHERE Email=?',id,email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateCustPwd = function (email,pwd){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE Customer Set Password=?, isDefault=? WHERE Email=?',pwd,true,email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateCustDefault = function (email,isDefault){
	      var rtn=-1;
	      try{
	         conn.execute('UPDATE Customer Set isDefault=? WHERE Email=?',isDefault,email);
	         rtn=conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Cust Default Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.deleteCustomer = function (email){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('DELETE FROM Customer WHERE Email=?',email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.userExists = function(email){
	      var rtnBool = false;
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT COUNT(*) As Cnt FROM Customer WHERE Email=?',email);
	         if (resultSet && resultSet.isValidRow()){
	            rtnBool = resultSet.fieldByName('Cnt') > 0;
	         }
	         resultSet.close(); 
	         //Ti.API.debug('Bool ' + rtnBool);
	      }
	      catch(ex){
	         rtnBool = false;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtnBool;
	   };
	   
	   api.getCustObj = function (email){
	      var result = null; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM Customer WHERE Email = ?', email); 
	         if (resultSet.isValidRow()) {
	            result = JSON.parse(resultSet.fieldByName("CustomerObj"));                                 
	         } 
	         resultSet.close(); 
	         //return result;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer Obj Error: '+ ex);
	         //return result;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	      
	   };
	   
	   api.getCustomer = function (email){
	      var result = null; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM Customer WHERE Email = ?', email); 
	         if (resultSet.isValidRow()) {
	            result = {Email:resultSet.fieldByName("Email"),
	                    Password: resultSet.fieldByName("Password"),
	                    StoreID: resultSet.fieldByName("StoreID"),
	                    CustomerObj: JSON.parse(resultSet.fieldByName("CustomerObj")),
	                    isDefault: resultSet.fieldByName("isDefault")
	            };                             
	         } 
	         resultSet.close();         
	         return result;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer Error: '+ ex);
	         //api.close();
	         //return result;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	      
	   };
	   
	   api.getDefaultCustomer = function(){
	      var result = null; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM Customer WHERE isDefault = ?',true); 
	         if (resultSet.isValidRow()) {
	            result = {Email:resultSet.fieldByName("Email"),
	                    Password: resultSet.fieldByName("Password"),
	                    StoreID: resultSet.fieldByName("StoreID"),
	                    CustomerObj: JSON.parse(resultSet.fieldByName("CustomerObj")),
	                    isDefault: resultSet.fieldByName("isDefault")
	            };    
	            //Ti.API.debug('DB default customer: Email:' + resultSet.fieldByName("Email") + ' ' + resultSet.fieldByName("isDefault") );                       
	         } 
	         resultSet.close(); 
	         //api.close();
	         return result;
	      }
	      catch (ex){
	         Ti.API.debug('Get Default Customer Error: '+ ex);
	         //api.close();
	         //return result;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   // ****************************** Credit Cards Table **********************************
	   
	   api.createCustCC = function (email,name,obj){
	      var rtn=-1;
	      try{
	         api.open();
	         var encryptedObj = encrypt(obj);       
	         conn.execute('INSERT INTO CustomerCC (Email,CCInfo,Name) VALUES(?,?,?)',email,JSON.stringify(encryptedObj),name);
	         rtn=conn.lastInsertRowId;
	      }
	      catch(ex){
	         Ti.API.debug('Insert Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.deleteCustCC = function (ID){
	      var rtn=-1;
	      try{
	         api.open();       
	         conn.execute('DELETE FROM CustomerCC WHERE rowid=?',ID);
	         rtn=conn.rowsAffected;
	      }
	      catch(ex){
	         Ti.API.debug('Delete Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.getAllCustCC = function (email){
	      var result = [];
	      //email = email.toLowerCase();
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT ROWID,Email,Name,CCInfo FROM CustomerCC WHERE Email = ?', email);
	         while (resultSet.isValidRow()) {
	            result.push({
	                  Email:resultSet.fieldByName("Email"),
	                  Name: resultSet.fieldByName("Name"),                
	                  CCInfo: JSON.parse(decrypt(resultSet.fieldByName("CCInfo"))),
	                  rowid: resultSet.fieldByName("ROWID")
	            });   
	            resultSet.next();                          
	         } 
	         resultSet.close(); 
	         //return results;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer AllCC Error: '+ ex);
	         //return null;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   api.getCustCCByName = function (email,name){
	      var result = null; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM CustomerCC WHERE Name = ? AND Email=?',name,email); 
	         if (resultSet.isValidRow()) {
	            result = {Email:resultSet.fieldByName("Email"),
	                    Name: resultSet.fieldByName("Name"),                 
	                    CCInfo: decrypt(resultSet.fieldByName("CCInfo"))
	            };                             
	         } 
	         resultSet.close(); 
	         //return result;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer CCByName Error: '+ ex);
	         //return result;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   api.updateCustCC = function (email,obj,Name){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE CustomerCC Set CCInfo=?  WHERE Name=? AND Email=?',JSON.stringify(encrypt(obj)),Name,email);
	         rtn=conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Cust CC Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.updateCustCCRow = function (rowid, obj){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE CustomerCC Set CCInfo=?  WHERE rowid=?',JSON.stringify(encrypt(obj)),rowid);
	         rtn=conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Cust CC Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   
	   
	   api.deleteAllCustCC = function (email){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('DELETE FROM CustomerCC WHERE Email=? ',email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Delete All Cust CC Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn; 
	   };
	   
	   // ****************************** Orders Table ****************************************
	   
	   api.createCustOrd = function (email,name,obj,storeObj){
	      var rtn=-1;
	      try{
	         api.open();          
	         conn.execute('INSERT INTO CustomerOrdSummary (Email,OrderObj,Name,StoreObj) VALUES(?,?,?,?)',email,JSON.stringify(obj),name,JSON.stringify(storeObj));
	         rtn= conn.lastInsertRowId;
	      }
	      catch(ex){
	         Ti.API.debug('Insert Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.getAllCustOrd = function (email){
	      var results = []; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT Email,Name,OrderObj,StoreObj,ROWID FROM CustomerOrdSummary WHERE Email = ? ORDER BY ROWID DESC', email); 
	         while (resultSet.isValidRow()) {
	            results.push({Email:resultSet.fieldByName("Email"),
	                    Name: resultSet.fieldByName("Name"),                 
	                    OrderObj: resultSet.fieldByName("OrderObj"),
	                    StoreObj: resultSet.fieldByName("StoreObj"),
	                    rowid: resultSet.fieldByName("ROWID")
	            });   
	            resultSet.next();                          
	         } 
	         resultSet.close(); 
	         //return results;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer AllOrders Error: '+ ex);
	         //return null;
	         results=null;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return results;
	   };
	   
	   api.getCustOrdByName = function (email,name){
	      var result = null; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT Email,Name,OrderObj,StoreObj,ROWID FROM CustomerOrdSummary WHERE Name = ? AND Email=?',name,email); 
	         if (resultSet.isValidRow()) {
	            result = {Email:resultSet.fieldByName("Email"),
	                    Name: resultSet.fieldByName("Name"),                 
	                    OrderObj: resultSet.fieldByName("OrderObj"),
	                    StoreObj: resultSet.fieldByName("StoreObj"),
	                    rowid: resultSet.fieldByName("ROWID")
	            };                             
	         } 
	         resultSet.close(); 
	         //return result;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer OrdersByName Error: '+ ex);
	         //return result;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   api.getCustOrdByStore = function(email){
	      var result = 0;
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM CustomerOrdSummary WHERE email=?',email);
	         result = resultSet.rowCount;
	         resultSet.close();
	      }
	      catch (ex){
	         
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	   };
	   
	   api.updateCustOrdSummary = function (email,obj,Name){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('UPDATE CustomerOrdSummary Set OrderObj=?  WHERE Name=? AND Email=?',JSON.stringify(obj),Name,email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Update Cust CC Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.deleteCustOrd = function (email,name){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('DELETE FROM CustomerOrdSummary WHERE Email=? AND Name=? ',email,name);
	         rtn=conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Delete CusOrdSummary : '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn;
	   };
	   
	   api.deleteAllCustOrd = function (email){
	      var rtn=-1;
	      try{
	         api.open();
	         conn.execute('DELETE FROM CustomerOrdSummary WHERE Email=? ',email);
	         rtn= conn.rowsAffected;
	      }
	      catch (ex){
	         Ti.API.debug('Delete All Cust Ord Error: '+ ex);
	         //return -1;
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return rtn; 
	   };
	   
	   api.getNumOrders = function(email){
	      var result = -1; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM CustomerOrdSummary WHERE Email = ?', email); 
	         result = resultSet.rowCount;
	         resultSet.close(); 
	         //return results;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer AllOrders Error: '+ ex);
	         //return null;
	         
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   api.getOrdByRowID = function(rowid){
	      var result = {}; 
	      try{
	         api.open();
	         var resultSet = conn.execute('SELECT * FROM CustomerOrdSummary WHERE ROWID = ?', rowid); 
	         result = resultSet.fieldByName("OrderObj");
	         resultSet.close(); 
	         //return results;
	      }
	      catch (ex){
	         Ti.API.debug('Get Customer getOrdByRowID Error: '+ ex);
	         //return null;
	         
	      }
	      finally{
	         if (conn){
	            conn.close();
	         }
	      }
	      return result;
	   };
	   
	   //return api;
	   ro.db = api;
	};
	return {
		getdb:getdb
	};
}();
module.exports = DB;

