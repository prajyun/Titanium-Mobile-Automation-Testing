var UTILS = function(){
	var utilities = function(){
	   	var utils = {};
		var curStoreHrs = null;
		var openHr = null;
		var openMin = null;
		var closeHr = null;
		var closeMin = null;
		var weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	     
		utils.skipOrderTime = function(store) {
			var ordType = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? "Delivery" : "Other");
			//var isdeliv = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
			Ti.API.debug('ordType: ' + ordType);
			//Ti.API.debug('store: ' + JSON.stringify(store));
			var anyOpenDays = false;
			for (var i = 0; i < store.Hours.length; i++) {
				if (!store.Hours[i].Type) {
					store.Hours[i].Type = (store.Hours[i].IsDelivery ? "Delivery" : "Other");
				}
				if (store.Hours[i].Type == ordType) {
					if(store.Hours[i].Open != store.Hours[i].Close){
						anyOpenDays = true;
					}
				}
			}
			return !anyOpenDays;
		}; 

		 utils.nextOpenTime = function(store){
		 	////deb.ug(store, 'store');
		 	var rtnStr = "Will open in ";
			var shortTicks = 0;
			var idxNextOpen;
			var rtnBool = false;
			var dateDiff;
			var ordType = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? "Delivery" : "Other");
	
			var curDate = new Date();
			//Ti.API.debug('curDate: ' + JSON.stringify(curDate));
			var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset()*60000);
			//Ti.API.debug('UTCTime: ' + JSON.stringify(UTCTime));
			var localTime = new Date(UTCTime + (store.TimeZone * 3600000));
			//Ti.API.debug('localTime: ' + JSON.stringify(localTime));
	
	
			//new storetime calculation since devices times and timezones can be changed - Changed 4.9.14
			function storeTime(strTme){
				var curDate = new Date(strTme);
				return new Date(curDate.getTime() + (curDate.getTimezoneOffset() * 60000));
			}
			//var localTime = storeTime(store.TimeAtStore);
			//new storetime calculation since devices times and timezones can be changed - Changed 4.9.14
	
	
			try{
				for(var i=0; i<store.Hours.length; i++){
					if(!store.Hours[i].Type){
						store.Hours[i].Type = (store.Hours[i].IsDelivery ? "Delivery" : "Other");
					}
					if(store.Hours[i].Type == ordType){
						var LocalFixTime = new Date(localTime.getTime());
						var weekDayDiff = weekDay.indexOf(store.Hours[i].DayOfWeek) - localTime.getDay();
						if(weekDayDiff < 0){
							dateDiff = 7 + (weekDayDiff);
							LocalFixTime.setDate(LocalFixTime.getDate() + dateDiff);
						}
						else if(weekDayDiff > 0){
							dateDiff = weekDayDiff;
							LocalFixTime.setDate(LocalFixTime.getDate() + dateDiff);
						}
						var OpenDate,CloseDate;
						OpenDate = new Date(LocalFixTime.toDateString() + " " + store.Hours[i].Open);
						CloseDate = new Date(LocalFixTime.toDateString() + " " + store.Hours[i].Close);
	
						if(OpenDate.getTime() > CloseDate.getTime()){
							CloseDate.setDate(CloseDate.getDate() + 1);
						}
					   if(OpenDate.getTime() != CloseDate.getTime()){
							var ticks = OpenDate.getTime() - localTime.getTime();
							if((ticks > 0 && ticks < shortTicks) || shortTicks == 0){
								shortTicks = ticks;
								idxNextOpen = i;
							}
						}
					}
				}
				var hour,minutes;
				if(shortTicks > 0){
					hour = Math.round((shortTicks * 10000)/3600000)/10000;
					minutes = parseInt((shortTicks - (Math.floor(hour) * 3600000))/60000, 10);
				}
				else{
					var tomorrow;
					if(localTime.getDay() == 6){
						tomorrow = 0;
					}
					else{
						tomorrow = localTime.getDay() + 1;
					}
	
					var idx = -1;
					for(j=0; j<store.Hours.length; j++){
						if(weekDay.indexOf(store.Hours[j].DayOfWeek) == tomorrow && store.Hours[j].Type == ordType){
							idx = j;
							break;
						}
					}
					if(idx!= -1){
						var OpenDt;
						var temp = new Date(localTime.getTime());
						temp.setDate(temp.getDate() + 1);
						OpenDt = new Date(temp.toDateString() + " " + store.Hours[idx].Open);
						var tiks = Math.abs(localTime.getTime() - OpenDt.getTime());
						hour = Math.round((tiks * 10000)/3600000)/10000;
						minutes = parseInt((tiks - (Math.floor(hour) * 3600000))/60000,10);
					}
				}
				if(Math.floor(hour) >= 1){
					if(Math.floor(hour) == 1){
						rtnStr += Math.floor(hour) + " hour";
					}
					else{
						rtnStr += Math.floor(hour) + " hours";
					}
				}
				if(minutes > 0){
					rtnStr += " " + minutes + " minutes";
				}
				return rtnStr + '.';
			}
			catch(ex){
				//Ti.API.debug('nextOpenTime() - ex: ' + ex);
				return rtnStr + '.';
			}
		 };
	
		 utils.isOpen = function(store){
		 	var rtnBool = false;
			var curDate = new Date();
			var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset()*60000);
			var timeAtStore = new Date(UTCTime + (store.TimeZone * 3600000));
	
	
	
			//new storetime calculation since devices times and timezones can be changed - Changed 4.9.14
			function storeTimeOpen(strTme){
				var curDate = new Date(strTme);
				return new Date(curDate.getTime() + (curDate.getTimezoneOffset() * 60000));
			}
			//var timeAtStore = storeTimeOpen(store.TimeAtStore);
			//new timeAtStore calculation since devices times and timezones can be changed - Changed 4.9.14
	
	
	
			var dateDiff;
			var ordType = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? "Delivery" : "Other");
			try{
				for (var i = 0; i < store.Hours.length; i++) {
					if(!store.Hours[i].Type){
						store.Hours[i].Type = (store.Hours[i].IsDelivery?"Delivery":"Other");
					}
					if(store.Hours[i].Type == ordType){
						var LocalFixTime = new Date(timeAtStore.getTime());
						var weekDayDiff = weekDay.indexOf(store.Hours[i].DayOfWeek) - timeAtStore.getDay();
	
						if (weekDayDiff < 0) {
							 	dateDiff = 7 + (weekDayDiff);
								LocalFixTime.setDate(timeAtStore.getDate() + dateDiff);
					    }
					    else if (weekDayDiff > 0) {
						 		dateDiff = weekDayDiff;
								LocalFixTime.setDate(timeAtStore.getDate() + dateDiff);
					    }
	
						var OpenDate,CloseDate;
						OpenDate = new Date(LocalFixTime.toDateString() + " " + store.Hours[i].Open);
						CloseDate = new Date(LocalFixTime.toDateString() + " " + store.Hours[i].Close);
	
						if(OpenDate.getTime() > CloseDate.getTime()){
							CloseDate.setDate(CloseDate.getDate() + 1);
						}
	
						if(OpenDate.getTime() < timeAtStore.getTime() && timeAtStore.getTime() < CloseDate.getTime()){
							rtnBool = true;
							break;
						}
						else{
							rtnBool = false;
						}
					}
	
				}
	
				var yesterday;
				if(timeAtStore.getDay() == 0){
					yesterday = 6;
				}
				else{
					yesterday = timeAtStore.getDay() - 1;
				}
	
				var idx = -1;
				for(j=0;j<store.Hours.length;j++){
					if(weekDay.indexOf(store.Hours[j].DayOfWeek) == yesterday && store.Hours[j].Type == ordType ){
						idx = j;
						break;
					}
				}
	
				if(idx != -1){
					var OpenDt,CloseDt;
					var temp = new Date(timeAtStore.getTime());
					temp.setDate(temp.getDate() -1);
					OpenDt = new Date(temp.toDateString() + " " + store.Hours[idx].Open);
					CloseDt = new Date(temp.toDateString() + " " + store.Hours[idx].Close);
	
					if(OpenDt.getTime() > CloseDt.getTime()){
						CloseDt.setDate(CloseDt.getDate() + 1);
					}
	
					if(OpenDt.getTime() < timeAtStore.getTime() &&
						timeAtStore.getTime() < CloseDt.getTime()){
							rtnBool = true;
					}
				}
				
				if(store.Holidays && store.Holidays.length){
				   //Ti.API.debug('store.Holidays: ' + JSON.stringify(store.Holidays));
				   if(Ti.App.Properties.hasProperty('DefaultStore')){
	               if(Ti.App.TimeAtDefStore && Ti.App.TimeAtDefStore !== null){
	                  var tempStore = store;
	                  tempStore.TimeAtStore = Ti.App.TimeAtDefStore;
	                  store = tempStore;
	                  tempStore = null;
	                  //storeObj.TimeAtStore = Ti.App.TimeAtDefStore;
	               }
	            }
	            
				   var mmt = require('classes/momentjs');
				   var currDt, currHr, currMin;
				   currDt = mmt(store.TimeAtStore);
				   currHr = parseInt(currDt.utc().format('HH'),10);
				   //Ti.API.debug('currHr: ' + currHr);
				   currMin = parseInt(currDt.format('mm'),10);
				   //Ti.API.debug('currMin: ' + currMin);
				   var tdy = currDt.format('MM-DD-YYYY');
				   for(var i=0, iMax=store.Holidays.length; i<iMax; i++){
				      var currHoliday = store.Holidays[i];
				      var currHolidayDate = mmt(currHoliday.Date).format('MM-DD-YYYY');
				      if(currHolidayDate === tdy){
				         if(currHoliday.Closed_All_Day){
				            rtnBool = false;
				            break;
				         }
				         //Ti.API.debug('currHr: ' + currHr);
				         //Ti.API.debug('currMin: ' + currMin);
				         var holidayOpenHr, holidayOpenMin, holidayCloseHr, holidayCloseMin;
				         
				         holidayOpenHr = getTime(currHoliday.Open_Time); 
				         holidayOpenMin = getTime(currHoliday.Open_Time, false, true);
				         holidayCloseHr = getTime(currHoliday.Close_Time);
				         holidayCloseMin = getTime(currHoliday.Close_Time, false, true);
				         //Ti.API.debug('currHr: ' + currHr);
				         //Ti.API.debug('holidayOpenHr: ' + holidayOpenHr);
				         if(currHr >= holidayOpenHr && currHr <= holidayCloseHr){
				            if(currHr === holidayOpenHr){
				               if(currMin >= holidayOpenMin){
	                           rtnBool = true;
	                           break;
	                        }
	                        else{
	                           rtnBool = false;
	                        }
				            }
				            else if(currHr === holidayCloseHr){
				               if(currMin < holidayCloseMin){
				                  rtnBool = true;
				                  break;
				               }
				               else{
				                  rtnBool = false;
				               }
				            }
				            else{
				               rtnBool = true;
				               break;
				            }
				         }
				         else{
				            rtnBool = false;
				         }
				      }
				   }
				}
				
				return rtnBool;
			}
			catch(ex){
				//Ti.API.debug('isOpen() - ex: ' + ex);
				return false;
			}
		};
		 var getTime = function(timeStr, fullStringBln, minutesBln){
	      timeStr = timeStr + '';
	      
	      var newHour, newMinute;
	      var hrLength = 2;
	      var prependBln = false;
	      if(timeStr.length === 5){
	         prependBln = true;
	         hrLength = 1;
	      }
	      
	      //Ti.API.debug('timeStr: ' + timeStr);
	      newHour = prependBln ? '0' + timeStr.slice(0, hrLength) : timeStr.slice(0, hrLength);
	      //Ti.API.debug('newHour: ' + newHour);
	      newMinute = timeStr.slice(hrLength, hrLength+2);
	      //Ti.API.debug('newMinute: ' + newMinute);
	      var returnTimeStr = (newHour+':'+newMinute);
	      //Ti.API.debug('returnTimeStr: ' + returnTimeStr);
	      
	      //return returnTimeStr;
	      return fullStringBln ? returnTimeStr : minutesBln ? parseInt(newMinute, 10) : parseInt(newHour,10);
	   };
		var getHr = function(time){
		   //Ti.API.debug('getHr - time: ' + time);
		   var hour;
		   
		   
		  // Ti.API.debug('getHr - time: ' + time);
		   return hour;
		};
		var getMin = function(time){
	      //Ti.API.debug('getMin - time: ' + time);
	      var min;
	      
	      
	      
	      //Ti.API.debug('getMin - time: ' + time);
	      return min;
	   };
	
		utils.getFormattedDate = function(date){
		 	var month = monthNames[date.getMonth()];
			var day = date.getDate();
			var year = date.getFullYear();
			return month + ' ' + day + ', ' + year;
		};
	
		utils.getWeekday = function(date){
		 	return weekDay[date.getDay()];
		};
	
		utils.getFormattedTime = function(date){
		 	var hour = date.getHours();
			var min = date.getMinutes();
			var str = hour + ':' + (min<10?'0'+ min:min);
			var rtnStr = '';
		  	if(hour == 0) {
				rtnStr = "12:" + str.substring(str.indexOf(":") + 1) + " AM";
			}
			else if(hour == 12){
				rtnStr = str + " PM";
			}
			else if(hour < 12){
				rtnStr = str + " AM";
			}
			else if(hour > 12){
				rtnStr = (hour-12) + ":" + str.substring(str.indexOf(":") + 1) + " PM";
			}
		  	return rtnStr;
		 };
	
		 utils.getMatchingIdx = function(val1, val2, key){
		 	for(var _idx=0, j=val2.length; _idx<j; _idx++){
				var thisVal2 = val2[_idx];
				if(val1 === thisVal2[key]){
					return _idx;
				}
			}
			return -1;
		 };
	
		 utils.removeObjProp = function(obj, props){
		 	try{
	   		for(var prop in props){
	   			if(obj.hasOwnProperty(props[prop])){
	   				//var befVal = obj[props[prop]];
	   				//Ti.API.debug('deleting props[prop]: ' + props[prop]);
	   				delete obj[props[prop]];
	   			}
	   		}
	      }
	      catch(ex){
	      	Ti.API.debug('utils.removeObjProp()-Exception: ' + ex);
	      }
		 };
		 //ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
		 /*if("ordOnlineOptions" in ordObj){
         ordObj.ordOnlineOptions.CCInfo = null;
      }

      if("DisplayOrdPayment" in ordObj){
         ordObj.DisplayOrdPayment = null;
      }
      
      if("Tip" in ordObj){
         ordObj.Tip = null;
      }*/
		 utils.removeOrdObjectProps = function(propCol){
			  try{
			  	if(!propCol || !propCol.length) return;
			  	var test = Ti.App.OrderObj;
			  	
			  	for(var i=0, iMax=propCol.length; i<iMax; i++){
			  		test[propCol[i]] = null;
			  	}
			  	
			  	Ti.App.OrderObj = test;
			  	test = null;
		   			/*if(Ti.App.Properties.hasProperty(propString)){
						Ti.App.Properties.removeProperty(propString);
					}*/
		      }
		      catch(ex){
		      	Ti.API.debug('utils.removeOrderObjProps()-Exception: ' + ex);
		      }
		 };
		 utils.removeProp = function(propString){
			  try{
		   			if(Ti.App.Properties.hasProperty(propString)){
						Ti.App.Properties.removeProperty(propString);
					}
		      }
		      catch(ex){
		      	Ti.API.debug('utils.removeProp()-Exception: ' + ex);
		      }
		};
	
		utils.setStrProp = function(propName, propVal){
			try{
				Ti.App.Properties.setString(propName, JSON.stringify(propVal));
			}
			catch(ex){
				Ti.API.debug('utils.setStrProp()-Exception: ' + ex);
			}
		};
	
		utils.hasProp = function(obj, propName){
			try{
				if(obj.hasOwnProperty(propName)){
					if(obj[propName].length > 0){
						return true;
					}
				}
				else{
					return false;
				}
			}
			catch(ex){
				Ti.API.debug('utils.hasProp()-Exception: ' + ex);
			}
		};
	
		utils.printAllProps = function(){
			var props = Ti.App.Properties.listProperties();
	
			for(var i=0, ilen=props.length; i<ilen; i++){
	    		var value = Ti.App.Properties.getString(props[i]);
	    		Ti.API.debug(props[i] + ' = ' + value);
			}
		};
		return utils;
	};
	return {
		utilities:utilities
	};
}();
module.exports = UTILS;