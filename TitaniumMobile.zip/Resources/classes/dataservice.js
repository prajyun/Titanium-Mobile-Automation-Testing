var DATASERVICE = function(){
	//Ti.include('/classes/suds.js');
	var dataservice = function(ro){
	   function SudsClient(_options) {
		  function isBrowserEnvironment() {
		    try {
		      if (window && window.navigator) {
		        return true;
		      } else {
		        return false;
		      }
		    } catch(e) {
		      return false;
		    }
		  }
		
		  function isAppceleratorTitanium() {
		    try {
		      if (Titanium) {
		        return true;
		      } else {
		        return false;
		      }
		    } catch(e) {
		      return false;
		    }
		  }
		
		  //A generic extend function - thanks MooTools
		  function extend(original, extended) {
		    for (var key in (extended || {})) {
		      if (original.hasOwnProperty(key)) {
		        original[key] = extended[key];
		      }
		    }
		    return original;
		  }
		
		  //Check if an object is an array
		  function isArray(obj) {
		    return Object.prototype.toString.call(obj) == '[object Array]';
		  }
		
		  //Grab an XMLHTTPRequest Object
		  function getXHR() {
		    var xhr;
		    if (isBrowserEnvironment()) {
		      if (window.XMLHttpRequest) {
		        xhr = new XMLHttpRequest();
		      }
		      else {
		        xhr = new ActiveXObject("Microsoft.XMLHTTP");
		      }
		    }
		    else if (isAppceleratorTitanium()) {
		      xhr = Ti.Network.createHTTPClient();
			  //xhr.setTimeout(20000);
            }              
		    return xhr;
		  }
		
		  //Parse a string and create an XML DOM object
		  function xmlDomFromString(_xml) {
		    var xmlDoc = null;
		    if (isBrowserEnvironment()) {
		      if (window.DOMParser) {
		        parser = new DOMParser();
		        xmlDoc = parser.parseFromString(_xml,"text/xml");
		      }
		      else {
		        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
		        xmlDoc.async = "false";
		        xmlDoc.loadXML(_xml);
		      }
		    }
		    else if (isAppceleratorTitanium()) {
		      xmlDoc = Ti.XML.parseString(_xml);
		    }
		    return xmlDoc;
		  }
		
		  // Convert a JavaScript object to an XML string - takes either an
		  function convertToXml(_obj, namespacePrefix) {
		    var xml = '';
		    if (isArray(_obj)) {
		      for (var i = 0; i < _obj.length; i++) {
		        xml += convertToXml(_obj[i], namespacePrefix);
		      }
		    } else {
		      //For now assuming we either have an array or an object graph
		      for (var key in _obj) {
		        if (namespacePrefix && namespacePrefix.length) {
		          xml += '<' + namespacePrefix + ':' + key + '>';
		        } else {
		          xml += '<'+key+'>';
		        }
		        if (isArray(_obj[key]) || (typeof _obj[key] == 'object' && _obj[key] != null)) {
		          xml += convertToXml(_obj[key]);
		        }
		        else {
		          xml += _obj[key];
		        }
		        if (namespacePrefix && namespacePrefix.length) {
		          xml += '</' + namespacePrefix + ':' + key + '>';
		        } else {
		          xml += '</'+key+'>';
		        }
		      }
		    }
			//Ti.API.debug("XML: " + xml);
		    return xml;
		
		  }
		
		  // Client Configuration
		  var config = extend({
		    endpoint:'http://localhost',
		    targetNamespace: 'http://localhost',
		    envelopeBegin: '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>',
		    envelopeEnd: '</soap:Body></soap:Envelope>'
		  },_options);
		
		  // Invoke a web service
		  function wasResponseTampered(timeStamp, signature, responseText){
		  	//Ti.API.debug('should NOT PRINT THISS: ');
		  	  var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
		  	  
		      var hash = CryptoJS.HmacSHA256((timeStamp+''+responseText), C_CRIT);
		      
		      var sigHash = CryptoJS.enc.Base64.stringify(hash);
		      
		      return sigHash != signature;
		      /*if(sigHash == signature){
		      	return false;
		      }
		      else{
		      	return true;
		      }*/
		  }
		  
		  this.invoke = function (_soapAction, _body, _callback, _errCallback, timeout, _progCallback, _sendCallback, shouldHash) {
		      //Build request body
		      var body = _body;
		      if (!timeout) {
		          timeout = 60000;
		      }
		      //Allow straight string input for XML body - if not, build from object
		      if (typeof body !== 'string') {
		          //body = '<ns0:'+_soapAction+'>';
		          //body += convertToXml(_body, 'ns0');
		          body = '<' + _soapAction + ' xmlns="' + config.targetNamespace + '">';
		          body += convertToXml(_body, '');
		          //body += '</ns0:'+_soapAction+'>';
		          body += '</' + _soapAction + '>';
		      }
		      else {
		          body = '<' + _soapAction + ' xmlns="' + config.targetNamespace + '">';
		          body += '<request>' + _body + '</request>';
		          body += '</' + _soapAction + '>';
		      }
		
		      var ebegin = config.envelopeBegin;
		      config.envelopeBegin = ebegin.replace('PLACEHOLDER', config.targetNamespace);
		
		      //Build Soapaction header - if no trailing slash in namespace, need to splice one in for soap action
		      var soapAction = '';
		      if (config.targetNamespace.lastIndexOf('/') != config.targetNamespace.length - 1) {
		          soapAction = config.targetNamespace + '/' + _soapAction;
		      }
		      else {
		          soapAction = config.targetNamespace + _soapAction;
		      }
		
		      //POST XML document to service endpoint
		      var xhr = getXHR();
		      xhr.timeout = timeout;
			  xhr.validatesSecureCertificate = ro.App.isSecure;//CHANGE BACK TO TRUE FOR LIVE APPS --- CHANGE BACK TO TRUE FOR LIVE APPS --- CHANGE BACK TO TRUE FOR LIVE APPS
		      xhr.onload = function (){
		      	var responseTimeStamp = this.getResponseHeader("X-Stamp");
		      	var responseSignature = this.getResponseHeader("X-Signature");
		      	
		      	if(shouldHash && wasResponseTampered(responseTimeStamp, responseSignature, this.responseText)){
		      		_errCallback.call(this, "Error validating the servers response. Please try again.");
		      	}
		      	else{
		      		_callback.call(this, xmlDomFromString(this.responseText));
		      	}
		      	
		      	//_callback.call(this, xmlDomFromString(this.responseText));
		      };
		
		      xhr.onerror = function (e) {
		          _errCallback.call(this, e.error);
		      };
		
		      xhr.open('POST', config.endpoint);
		      xhr.setRequestHeader('Content-Type', 'text/xml;');
		      xhr.setRequestHeader('SOAPAction', soapAction);
		      xhr.setRequestHeader('Accept-Encoding', 'gzip,deflate');
		      
		      if(shouldHash){
		          /*Ti.include('/classes/crypto.js');
			      Ti.include('/classes/crypto64.js');
			        
			      var timeStamp = parseInt(((new Date().getTime()) / 1000), 10);
		          var sig = timeStamp+''+(config.envelopeBegin+body+config.envelopeEnd);
			        
			      var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
			      var hash = CryptoJS.HmacSHA256(sig, C_CRIT);
			      
			      var sigHash = CryptoJS.enc.Base64.stringify(hash);
			      
			      xhr.setRequestHeader('X-Stamp', timeStamp);
		          xhr.setRequestHeader('X-Signature', sigHash);*/
		      }
		      
		      xhr.send(config.envelopeBegin + body + config.envelopeEnd);
		  };		
		}
	   ro.dataservice = {		   
		   post:function(req, functionName, responseFunc){
		      if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('req: ' + JSON.stringify(req)); }
		      
		      var suds = new SudsClient({
		         endpoint:Ti.App.serviceURL,
		         targetNamespace:'http://hungerrush.com/api/services'
		      });
		      var response = {
		         value:false,
		         Message:''
		      };
		      if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
		         response.Message = 'Internet connection is required to place an order. Please connect and try again.';
		         responseFunc.apply(null, [response]);
		      }
		      if(!Ti.Network.online){
		         response.Message = 'The network is not reachable to the internet.';
		         responseFunc.apply(null, [response]);
		      }
		      suds.invoke(functionName, '<![CDATA[' + JSON.stringify(req) + ']]>', function(xmlDoc){
		         var res = xmlDoc.documentElement.getElementsByTagName(functionName + 'Result');
		         if(res && res.length > 0){
		            var inflator;
		            var textReader;
		            var outputTxt = null;
		            var Obj;
		            try{
		               outputTxt = res.item(0).textContent;
		            }
		            catch(e){
		               outputTxt = null;
		            }
		            try{
		               if(outputTxt){
		                  response = JSON.parse(outputTxt);
		                  //Ti.API.debug('response: ' + JSON.stringify(response));
		               }
		               else{
		                  response.value = false;
		                  response.Message = 'Error occured. CODE:100.';
		               }
		            }
		            catch(ex){
		               response.Message = 'Error occured. CODE:101.';
		            }
		         }
		         else{
		            response.Message = 'Error occured. CODE:501.';
		         }
		
		         /*if(Ti.App.DEBUGBOOL)	{
		         	 Ti.API.debug('API: ' + functionName + ' ----   ServerResponse: ' + JSON.stringify(response));
		          }*/
		         responseFunc.apply(null, [response]);
		         //Ti.API.debug('response: ' + JSON.stringify(response));
		         
				/*for(var props in response){
					Ti.API.debug('response['+props+']: ' + JSON.stringify(response[props]));
					if(props == "Store"){
					    for(var prop in response[props]){
					        Ti.API.debug('response['+props+']['+prop+']: ' + JSON.stringify(response[props][prop]));
					    }
					}
				}*/
		      },
		      function(error){
		      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('response: ' + JSON.stringify(response)); }
		         response.Message = 'Connection Failed:\n' + error;
		         responseFunc.apply(null, [response]);
		      }, null, null, null, Ti.App.SignReqAndResp);
            },
           registerDevice: function (req, callback) {
               try {               
                   var url = Ti.App.websiteURL + "api/v1/pn/RegisterDevice";
                   var xhrRegDevice = Titanium.Network.createHTTPClient();				   
				   xhrRegDevice.validatesSecureCertificate = ro.App.isSecure;              
                   xhrRegDevice.timeout = 120000;
                   xhrRegDevice.onload = function (e) {                   
                       var response = JSON.parse(this.responseText);
                       callback(response);
                   };
                   xhrRegDevice.onerror = function (e) {                      
                       var response = JSON.parse(this.responseText);
                       callback(response);
                   };
                   var CryptoJS = require('classes/crypto').getCrypto();
                   var reqMethod = "POST";
                   var timeStamp = parseInt(((new Date().getTime()) / 1000), 10);
                   var sig = timeStamp + '' + url + reqMethod;
                   var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
                   var hash = CryptoJS.HmacSHA256(sig, C_CRIT);
                   var sigHash = CryptoJS.enc.Base64.stringify(hash);
                       
                       xhrRegDevice.open(reqMethod, url);
                       xhrRegDevice.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
                       xhrRegDevice.setRequestHeader('Accept-Encoding', 'gzip,deflate');
                       xhrRegDevice.setRequestHeader('Accept', 'application/json');
                       xhrRegDevice.setRequestHeader('X-Stamp', timeStamp);
                       xhrRegDevice.setRequestHeader('X-Signature', sigHash);                   
                       xhrRegDevice.send(JSON.stringify(req));                   
               } catch (ex) {
                   Ti.API.info("Catched registerDevice exception : " + JSON.stringify(ex));
               }
           },
           postAPI: function (req, callUrl, callback) {
               try {
                   var url = Ti.App.websiteURL + "api/v1/mobile/" + callUrl;
                   var xhrPost = Titanium.Network.createHTTPClient();
				   xhrPost.validatesSecureCertificate = ro.App.isSecure;
                   xhrPost.timeout = 120000;
                   xhrPost.onload = function (e) {
                       var response = JSON.parse(this.responseText);
                       callback(response);
                   };
                   xhrPost.onerror = function (e) {
                       Ti.API.info("Error e: " + JSON.stringify(e));
                       Ti.API.info("Error this.responseText: " + this.responseText);
                       var response = JSON.parse(this.responseText);
                       callback(response);
                   };
                   var CryptoJS = require('classes/crypto').getCrypto();
                   var reqMethod = "POST";
                   var timeStamp = parseInt(((new Date().getTime()) / 1000), 10);
                   var APIKey = "";
                   var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
                   var sig = APIKey + timeStamp + url + reqMethod + JSON.stringify(req);
                   Ti.API.info("sig: " + sig);                   
                   
                   var hash = CryptoJS.HmacSHA256(sig, C_CRIT);
                   var sigHash = CryptoJS.enc.Base64.stringify(hash);

                   xhrPost.open(reqMethod, url);
                   xhrPost.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
                   xhrPost.setRequestHeader('Accept-Encoding', 'gzip,deflate');
                   xhrPost.setRequestHeader('Accept', 'application/json');
                   xhrPost.setRequestHeader('X-Stamp', timeStamp);
                   xhrPost.setRequestHeader('X-Signature', sigHash);
                   xhrPost.send(JSON.stringify(req));

               } catch (ex) {
                   Ti.API.info("Catched postAPI exception : " + JSON.stringify(ex));
               }
           }
	   };
	   /*return{
	      post:post
	   };*/
	  
	  //ro.dataservice.post = post;
	};
	return {
		dataservice:dataservice
	};
}();
module.exports = DATASERVICE;