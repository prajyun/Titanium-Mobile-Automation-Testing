function RateMe(appId, username, _cb) {
	var propertyStr = 'NeverRateAgain09042018'+username;//Added todays date to begin asking all users for input again. 
	if(!Ti.App.Properties.hasProperty(propertyStr)){
		Ti.App.Properties.setString(propertyStr, 0);
	}

	var neverAsk = Ti.App.Properties.getString(propertyStr);
	if(parseInt(neverAsk, 10) == 1 || ro.isiOS){
		_cb();
		return;
	}

	var goog_url = 'market://details?id=' + appId;


    ro.ui.popup('Please rate this app!', ['OK', 'Remind Me Later'], 'Would you take a moment to rate this app?', function(e) {
        try{
             Ti.App.Properties.setString(propertyStr, 1);
             Ti.Platform.openURL(goog_url);
             _cb();
          }
          catch(e){
             ro.ui.alert('Error: ', e);
          }
        }, function(){
            _cb();
    }, true);
}

exports.checkNow = RateMe;