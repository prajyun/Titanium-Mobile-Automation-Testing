﻿var GA = function(){
	var googleanalytics = function(ro){
   var ga = {}, analytics = {}, tracker;
   analytics.init = function(id, debug){
      try{
      	  //debug = false;
      	  //id = 'UA-86036253-1';
	      if(id && id.length>0){
	         ga = debug ? { } : require('ti.ga');//require('analytics.google');
	         //ga.optOut = debug;
	         ga.setOptOut(debug);
	         ga.setDebug(true);
	         ga.dryRun = debug;
	         //tracker = debug ? false : ga.getTracker(id);
	         tracker = debug ? false : ga.createTracker({trackingId:id, useSecure:true, debug:true});
	         
	         if(ro.isiOS){
	         	Ti.API.info('SINCE IT IS IOS I AM NOW SETTING TRACK UNCAUGHT EXCEPTIONS');
	         	ga.setTrackUncaughtExceptions();
	         }
	      }
	   }
      catch(ex){
      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('GA.init()-Exception: ' + ex); }
      }
   };
   analytics.trackScreen = function(name){
      if(tracker){
         //tracker.trackScreen({ screenName: name });
         tracker.addScreenView(name);
      }
      if(true || ga.dryRun) { Ti.API.debug('Screen Name: ' + name); }
   };
   analytics.trackEvent = function (category,action,label,value){
      if(tracker){
         //tracker.trackEvent({category:category,action:action,label:label,value:value});
         tracker.addEvent({category:category,action:action,label:label,value:value});
      }
      if(true || ga.dryRun){ Ti.API.debug('category: ' + category + '   action: ' + action + '   label: ' + label + '   value: ' + value); }
         
    };
     analytics.trackTransaction = function (transactionId, storeName, total, tax, delivFee, currency) {
         if (tracker) {
             //tracker.trackTransaction({transactionId:transactionId, affiliation:storeName, revenue:total, tax:tax, shipping:delivFee, currency:currency});
             var label = 'transactionId: ' + transactionId + '   affiliation: ' + storeName + '   revenue: ' + total + '   tax: ' + tax + '   shipping: ' + delivFee + '   currency: ' + currency;
             Ti.API.info('label: ' + label);
             //tracker.addEvent({category:"Transaction", action:"Successful", label:label, value:1});
             tracker.fireTransactionEvent({transactionId:transactionId, affiliation:storeName, revenue:total, tax:tax, shipping:delivFee, currency:currency});
         }
         if (true || ga.dryRun) { Ti.API.debug('transactionId: ' + transactionId + '   affiliation: ' + storeName + '   revenue: ' + total + '   tax: ' + tax + '   shipping: ' + delivFee + '   currency: ' + currency); }
     };
     analytics.setUser = function (userId, category, action) {
     	  try{
           if (tracker) {
              //tracker.setUser({ userId: userId, category: category, action: action});
              tracker.setUserID(userId);
           }
           if(true || ga.dryRun) { Ti.API.debug('userId: ' + userId + '   category: ' + category + '   action: ' + action); }
        }
        catch(ex){
           if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('GA.setUser()-Exception: ' + ex); }
        }
     };
     ro.GA = analytics;
   };
    return {
        googleanalytics:googleanalytics
    };
}();
module.exports = GA;