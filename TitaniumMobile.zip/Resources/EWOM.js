var EWOM = function(){
   var ewomValcodes = [],
   /*validateCode = function(code, storeid, _callback){
      var req = {
         RevKey:'test',
         CompressResponse:false,
         CouponCode:code,
         StoreID:storeid
      };

      ro.dataservice.post(req, 'ValidateCoupon', function(response){
         if(response){
            Obj = response;
            if(Obj.Value){
            	setEwomCode(Obj.ValCode);
               _callback(Obj.ValCode);
            }
            else{
               ro.ui.alert('Coupon Not Valid', 'No eWordOfMouth coupon found');
               ro.ui.hideLoader();
            }
         }
         else{
         	ro.ui.alert('Coupon Not Valid', 'No eWordOfMouth coupon found');
            ro.ui.hideLoader();
         }
      });
   },
   isValidCode = function(code){
      if(code.length <= 10){
         return false;
      }

      var ewTest = code[code.length-2] + code[code.length-1];
      if(ewTest.toLowerCase() != 'ew'){
         return false;
      }

      return true;
   },*/
   setEwomCode = function(code){
		ewomValcodes.push(code);
   },
   addLoyaltyCodes = function(cpnCol){
      if(!cpnCol){
         cpnCol = [];
      }
      if(!ewomValcodes){
         ewomValcodes = [];
      }

      var test = Ti.App.OrderObj;
      test.LoyaltyCodes = [];
      Ti.App.OrderObj = test;
      test = null;

      for(var i=0; i<cpnCol.length; i++){
         var valCode = cpnCol[i].ValCode && cpnCol[i].ValCode.length ? cpnCol[i].ValCode : '';
         for(var j=0; j<ewomValcodes.length; j++){
            if(valCode.toLowerCase() == ewomValcodes[j].toLowerCase()){
               var test = Ti.App.OrderObj;
               if(!test.LoyaltyCodes){
                  test.LoyaltyCodes = [];
               }
               test.LoyaltyCodes.push(ewomValcodes[j]);
               Ti.App.OrderObj = test;
               test = null;
               break;
            }
         }
      }
   };/*,
   hasAfterAccountCreation = function(){
      return false;
   };*/
   return {
      /*init: init,
      setOptOut: setOptOut,
      setOrderObject: setOrderObject,
      setRequestObject: setRequestObject,
      getNewEwomView: getNewEwomView,
      isEnabled: isEnabled,
      isEnabledAtPayment: isEnabledAtPayment,
      didChange: didChange,
      validateCode: validateCode,
      isValidCode: isValidCode,*/
      setEwomCode: setEwomCode,
      addLoyaltyCodes: addLoyaltyCodes,
      setEwomCode: setEwomCode,
      //hasAfterAccountCreation: hasAfterAccountCreation,
      isEWOM: true
   };
}();
module.exports = EWOM;