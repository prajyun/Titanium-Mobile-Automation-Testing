var vsn = Ti.App.version;
Ti.API.debug('GLOBAL vsn: ' + vsn);
Ti.API.debug('Ti.App.id: ' + Ti.App.id);

function test() {
    return _trigger();
}

function check(_callback) {
    return _trigger(true);
    //var timeForCallback = false;
    //timeForCallback = _trigger(true);
    //_trigger(true, _callback);
    //_callback()
}
function needsUpdate(_callback, _callbacktwo){
	//return _trigger(true, true, _callback, _callbacktwo);
	_lookup(_callback, _callbacktwo);
	
}

function open() {
    
    if (!exports.appleId) {
        
        _lookup(function (result) {
            
            if (!result) {
                return;
            }
            
            exports.appleId = result.trackId;
            return open();
        });
        
        return;
    }
    
    Ti.Platform.openURL('http://itunes.apple.com/app/id' + exports.appleId);
    return;
}

function reset() {
    console.debug('[UPDATE] Reset.');
    
    Ti.App.Properties.removeProperty('update_checked');
    Ti.App.Properties.removeProperty('update_never');
    
    return;
}
    
function _trigger(forced, needsUpdateBln, _cb, _cbtwo) {
    
    /*if (Ti.Platform.name !== 'iPhone OS') {
        console.debug('[UPDATE] Platform is not iOS.');
        //_cbtwo();
        return;
    }*/
    
    var now = (new Date() / 1000);
    
    if (!forced) {
        var checked = Ti.App.Properties.getInt('update_checked', 0);
    
        if (now - checked < (exports.daysBetween * 86400)) {
            console.debug('[UPDATE] Checked less than ' + exports.daysBetween + ' days ago.');
            return;
        }
    }

    _lookup(function (result) {
    	Ti.API.debug('result: ' + JSON.stringify(result));
    	Ti.API.debug('needsUpdateBln: ' + JSON.stringify(needsUpdateBln));
        
        if (!result) {
        	if(needsUpdateBln){
        		_cbtwo();
        		return false;
        	}
        	else{
        		//_cbtwo();
            	return;
            }
        }
        
        Ti.App.Properties.setInt('update_checked', now);
        
        if (_cmpVersion(result.version, vsn) <= 0) {
            console.debug('[UPDATE] No new version.');
            if(needsUpdateBln){
            	_cbtwo();
        		return false;
        	}
        	else{
            	return;
            }
        }
        
        if (!forced) {
            var never = Ti.App.Properties.getString('update_never');
            
            if (never === result.version) {
                console.debug('[UPDATE] Never ask again for this version.');
                return;
                    
            } else {
                Ti.App.Properties.removeProperty('update_never');
            }
        }
        
        var buttonNames, cancel;
        
        if (forced) {
            buttonNames = [/*exports.later, */exports.yes];
            cancel = 0;
        } else {
            buttonNames = [exports.yes, exports.later, exports.never];
            cancel = 2;
        }
        
        var title, messsage;
        
        if (exports.title) {
            title = exports.title;
            
            if (exports.title.indexOf('%') !== -1) {
                title = title.replace('%version', result.version);
            }
        }
        
        if (exports.message) {
            message = exports.message;
            
            if (exports.message.indexOf('%') !== -1) {
                message = exports.message
                    .replace('%version', result.version)
                    .replace('%notes', result.releaseNotes);
            }
        }
        
        var alertDialog = Titanium.UI.createAlertDialog({
            title: title,
            message: message,
            buttonNames: buttonNames,
            cancel: cancel
        });
        
        alertDialog.addEventListener('click', function(e) {
            
            if (buttonNames[e.index] === exports.yes) {
            	Ti.App.ButtonWasClicked = true;
            	//Ti.API.debug('Ti.App.version: ' + Ti.App.version);
            	//Ti.API.debug('vsn: ' + vsn);
            	vsn = '2.3.1';
            	//Ti.API.debug('vsn: ' + vsn);
                open();
                
            } else if (buttonNames[e.index] === exports.never) {
                Ti.App.Properties.setString('update_never', result.version);
            }
            
            return;
        });
        
        if(needsUpdateBln){
        		return _cb(true);
        	}
        else{
	       alertDialog.show();
	        return;
	    }
    });
    
    if(needsUpdateBln){
		//return false;
		//_cbtwo();
	}
	else{
		
    	return;
    }
}

function _lookup(_callback, _callbacktwo) {
    var xhr = Ti.Network.createHTTPClient({
        onload: function (e) {
            if (xhr.status === 200 && this.responseText) {
                try {
                    var json = JSON.parse(this.responseText);
                    Ti.API.debug('json:' + JSON.stringify(json));

                    if (json.resultCount === 1) {
                    	Ti.API.debug('json.results: ' + JSON.stringify(json.results));
                    	if(!_callbacktwo){
                        	_callback(json.results[0]);
                        }
                        else{
                        	if (!(_cmpVersion(json.results[0].version, vsn) <= 0)) {
                        		_callback();
                        	}
                        	else{
                        		_callbacktwo();
                        	}
                        }
                        //return;
                        
                    } else {
                        console.error('[UPDATE] LOOKUP ERROR ' + this.responseText);
                    }
                
                } catch (err) {
                    console.error('[UPDATE] LOOKUP ERROR ' + JSON.stringify(err));
                }
            }
            
            //_callback();
            //return;
        },
        onerror:_callbacktwo ? _callbacktwo : function (e) {
            console.error('[UPDATE] LOOKUP ERROR ' + JSON.stringify(e.error));
            _callback();
            return;
        }
    });
    
    if(!isAndroid){
    	var url = 'http://itunes.apple.com/lookup?';
    
	    if (exports.appleId) {
	        url = url + 'id=' + exports.appleId;
	    } else {
	        url = url + 'bundleId=' + Ti.App.id;
	    }
	}
	else{
		var url = 'https://42matters.com/api/1/apps/lookup.json?access_token=b2bb77eb1e6c3c63a63c062f4ac32ce8971753b5&p=' + exports.androidId;
    
	    /*if (exports.appleId) {
	        url = url + 'id=' + exports.appleId;
	    } else {
	        url = url + 'bundleId=' + Ti.App.id;
	    }*/
	}

    xhr.open('GET', url);
    xhr.send();
    
    return;
}

function _cmpVersion(a, b) {
    var i, cmp, len, re = /(\.0)+[^\.]*$/;
    a = (a + '').replace(re, '').split('.');
    b = (b + '').replace(re, '').split('.');
    len = Math.min(a.length, b.length);
    for( i = 0; i < len; i++ ) {
        cmp = parseInt(a[i], 10) - parseInt(b[i], 10);
        if( cmp !== 0 ) {
            return cmp;
        }
    }
    return a.length - b.length;
}

var isAndroid = (Ti.Platform.name !== 'iPhone OS') ? true : false;

exports.title = 'New version available';
exports.message = 'Upgrade to %version for:\n\n%notes';
exports.yes = 'Yes';
exports.later = 'Not now';
exports.never = 'No, thank you';

//exports.appleId = null;
exports.appleId = 410332291;
//exports.appleId = Ti.App.id;
exports.androidId = Ti.App.id;
exports.daysBetween = 1;

exports.test = test;
exports.check = check;
exports.open = open;
exports.reset = reset;
exports.needsUpdate = needsUpdate;