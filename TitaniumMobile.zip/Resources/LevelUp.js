var levelup = function(){
	var lvlup = {
		LU_API_KEY:'',
		LU_SECRET:'',
		LU_STORE_ID:'',
		LU_MERCHANT_ID:'',
		LU_MERCHANT_TOKEN:'',
		LU_TOKEN:'',
		LU_SANDBOX:false,
		LU_STORE_PMT:false
	},
	LU_rewardsText = '',
	LU_webView,
	LU_qrCode,
	LU_rewardsEnabled = false,
	//Init = function(inStoreEnabled, isSandbox, apiKey, secret, storeId, merchId, merchToken, accessToken){
	Init = function(){
		try{
		   ////deb.ug(arguments, 'lvlup-arguments');
			/*lvlup.LU_SANDBOX = isSandbox;
			lvlup.LU_API_KEY = apiKey;
			lvlup.LU_SECRET = secret;
			lvlup.LU_STORE_ID = storeId+'';
			lvlup.LU_MERCHANT_ID = merchId+'';
			lvlup.LU_MERCHANT_TOKEN = merchToken;
         lvlup.LU_STORE_PMT = inStoreEnabled;
			if(accessToken){
				lvlup.LU_TOKEN = accessToken;
			}*/
			//Ti.API.debug('storeConf: ' + JSON.stringify(storeConf));
			
			
			var cfg;
			if(ro.app.Store){
            Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
            cfg = ro.app.Store.Configuration;
         }
			else{
   			cfg = JSON.parse(Ti.App.Properties.getString('Config'));
            if(!cfg){
               cfg = {};
            }
         }
         var custInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
         if(!custInfo){
            custInfo = {};
         }
         //levelUp.Init(Config.LU_STORE_PMT, Config.LU_SANDBOX, Config.LU_API_KEY, Config.LU_SECRET, Config.LU_STORE_ID, Config.LU_MERCHANT_ID, Config.LU_MERCHANT_TOKEN);
         var tempToken = null;
         if(lvlup.LU_TOKEN && lvlup.LU_TOKEN.length){
         	tempToken = lvlup.LU_TOKEN;
         }
         ////deb.ug(cfg, 'cfg');
         
			lvlup.LU_SANDBOX = cfg.LU_SANDBOX;
         lvlup.LU_API_KEY = cfg.LU_API_KEY;
         lvlup.LU_SECRET = cfg.LU_SECRET;
         lvlup.LU_STORE_ID = cfg.LU_STORE_ID+'';
         lvlup.LU_MERCHANT_ID = cfg.LU_MERCHANT_ID+'';
         lvlup.LU_MERCHANT_TOKEN = cfg.LU_MERCHANT_TOKEN;
         lvlup.LU_STORE_PMT = cfg.LU_STORE_PMT;
         if(custInfo.LUToken){
            lvlup.LU_TOKEN = custInfo.LUToken; 
         }
			/*else if(tempToken){
				lvlup.LU_TOKEN = tempToken;
			}*/
			else{
				
			   lvlup.LU_TOKEN = '';
			   if(Ti.App.DEBUGBOOL){
			      //lvlup.LU_TOKEN = '6532-610784f7a4fdafd6f30b86d83f2e544546e0e2053c5ba815f54f5e5ec0512d';
			   }
			   var tokenStr = Ti.App.Properties.getString('LU_ACCESS_TOKEN');
			   var tokenObj = JSON.parse(tokenStr);
			   if(!tokenObj){
			      tokenObj = {};
			   }

			   if(Ti.App.Username && Ti.App.Username.length && tokenObj && tokenObj.user && tokenObj.user.toLowerCase() == Ti.App.Username.toLowerCase() && tokenObj.token && tokenObj.token.length){
			      lvlup.LU_TOKEN = tokenObj.token;
			   }
			   else{
			      ro.utils.removeProp('LU_ACCESS_TOKEN');
			      lvlup.LU_TOKEN = '';
			   }
			}
			/*var wasUnlinked = Ti.App.Properties.getBool('RewardsUnlinked');
			Ti.API.debug('wasUnlinked: ' + wasUnlinked);
			if(wasUnlinked){
				unlinkRewardsAccount();
			}*/
		}
		catch(ex){
			Ti.API.debug('lvlup.Init()-Exception: ' + ex);
		}
	},
	getToken = function(){
		return lvlup.LU_TOKEN;
	},
	isEnabled = function(){
		return lvlup.LU_API_KEY && lvlup.LU_API_KEY.length > 0
			 && lvlup.LU_SECRET && lvlup.LU_SECRET.length > 0
			 && lvlup.LU_STORE_ID && lvlup.LU_STORE_ID.length > 0
		    && lvlup.LU_MERCHANT_ID && lvlup.LU_MERCHANT_ID.length > 0
		    && lvlup.LU_MERCHANT_TOKEN && lvlup.LU_MERCHANT_TOKEN.length > 0;
	},
	isMobileAuthEnabled = function(){
	   return lvlup.LU_STORE_PMT
	       && lvlup.LU_API_KEY && lvlup.LU_API_KEY.length > 0
          && lvlup.LU_SECRET && lvlup.LU_SECRET.length > 0;
          /*&& lvlup.LU_MERCHANT_TOKEN && lvlup.LU_MERCHANT_TOKEN.length > 0;*/
	},
	isLoyaltyEnabled = function(){
      return lvlup.LU_TOKEN && lvlup.LU_TOKEN.length > 0;
	},
	isSiteRewardsCapable = function(/*EMAIL_CLUB_TEXT*/){
	   //LU_rewardsText = EMAIL_CLUB_TEXT;
	   return lvlup.LU_API_KEY && lvlup.LU_API_KEY.length > 0
          && lvlup.LU_SECRET && lvlup.LU_SECRET.length > 0;
	},
	getRegisterRewardsView = function(defaultChecked, companyName, isNewAcct){
      /*
      -fullView-
               |__ -rewardsView-

       -rewardsView-
                  |__ -rewardsCheckbox-  __  -rewardsLbl-
      */
      rewardsView = Ti.UI.createView({
         height:Ti.UI.SIZE
      });

      rewardsCheckbox = Ti.UI.createSwitch(ro.combine(ro.ui.properties.defaultEwomSwitch, {
         height:Ti.UI.FILL,
         left:ro.ui.relX(5),
         top:ro.ui.relX(5),
         bottom:ro.ui.relY(5)
      }));
      if(defaultChecked && defaultChecked == true){
         rewardsCheckbox.value = true;
         rewardsCheckbox.OrigValue = true;
      }
      var rewardsLbl = Ti.UI.createLabel({
         text:'',
         color:ro.ui.theme.ewomTxtLbl,
         font:{
            fontSize:ro.ui.scaleFont(11.5),
            fontWeight:'bold',
            fontFamily:ro.ui.fontFamily
         },
         //textAlign:'center',
         left:ro.ui.relX(40),
         right:ro.ui.relX(5),
         top:ro.ui.relX(5),
         bottom:ro.ui.relY(5)
      });
      rewardsLbl.addEventListener('click', function(e){
         rewardsCheckbox.value = !rewardsCheckbox.value;
      });

      companyName = companyName||'our';

      rewardsLbl.text = (LU_rewardsText + ' (Click Me!)').replace(/(\r\n|\n|\r)/gm," ");//('Would you like to enable ' + companyName + ' Rewards? (Click Me!)').replace(/(\r\n|\n|\r)/gm," ");
      rewardsView.add(rewardsCheckbox);
      rewardsView.add(rewardsLbl);

      fullView = Ti.UI.createView({
         backgroundColor:ro.ui.theme.btnDefault,
         layout:'vertical',
         top:ro.ui.relY(15),
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL
      });
      if(!isNewAcct){
      	fullView.bottom = ro.ui.relY(126);
      }
      else{
      	fullView.borderColor = 'black';
      	fullView.borderWidth = ro.ui.relX(2);
      	fullView.borderRadius = ro.ui.relX(15);
      }
      fullView.add(rewardsView);
      fullView.isEnabled = function(){
         LU_rewardsEnabled = rewardsCheckbox.value;
      };
      return fullView;
   },
   getRewardsBool = function(){
      return LU_rewardsEnabled;
   },
	needsWebview = function(){
		return (lvlup.LU_TOKEN.length == 0);
	},
	releaseWebview = function(){
		try{
			if(Ti.Platform.osname == 'android'){
				Ti.API.debug('releasing web view');
				LU_webView.release();
			}
			else{
				Ti.API.debug('Calling release on a Ti.UI.WebView is Android only.');
				return;
			}
		}
		catch(ex){
			Ti.API.debug('releaseWebview()-Exception: ' + ex);
		}
	},
	getWebView = function(_lvlupCallback, firstTime){

		var baseUrl = lvlup.LU_SANDBOX ? 'https://sandbox.' : 'https://www.';
		var scopeString = 'read_user_basic_info read_qr_code create_orders read_user_orders manage_user_campaigns manage_user_addresses manage_user_payment_methods';
		var otherParams = '&login_hint='+Ti.App.Username;

		//https://sandbox.thelevelup.com/oauth2/authorizations/new?client_id=0cc1e887985c82bcff7ee81df2256645801c81c3a7db10090a3bd5262565b81a&embedded=true&login_hin=crberko%40gmail.com&response_type=token&scope=read_user_basic_info+read_qr_code&first_name=chris&last_name=berkowitz
		var url = baseUrl + 'thelevelup.com/oauth2/authorizations/new?client_id='+lvlup.LU_API_KEY+'&response_type=token&embedded=true&scope='+scopeString+''+otherParams;//+'&login_hint='+username;
		//add first and last name parameters to make it nicer for customer

		LU_webView = Ti.UI.createWebView({
			height:Ti.UI.FILL,
			width:Ti.UI.FILL,
			borderRadius:1
		});
		LU_webView.addEventListener('load', function(e){
			try{
				var html = e.source.html;

				var url = e.source.url;
				var splitUrl = url.split('access_token=');//This searches the url for "access_token=" and inserts the preceding url into splitUrl[0] and the proceeding url into splitUrl[1]

				if(splitUrl.length > 1){
					var access_token = splitUrl[1].split('&')[0];//This splits the new url anywhere it finds "&" and puts the access_token into the 0 index
					lvlup.LU_TOKEN = access_token;
					Ti.App.Properties.setString('LU_ACCESS_TOKEN', JSON.stringify({
					   user:Ti.App.Username,
					   token:lvlup.LU_TOKEN
					}));
					
					/*if(ro.REV_LOYALTY.a()){
						REV_CUSTOMER.changeEClubOptIn(1, true, function(){});
					}
					if(){
						REV_CUSTOMER.changeEClubOptIn(1, true, function(){});
					}*/
					REV_CUSTOMER.changeEClubOptIn(1, true, function(){});
					
					_lvlupCallback();
				}
				else{
					return;
				}
			}
			catch(ex){
				Ti.API.debug('webView-loadEvent-Exception: ' + ex);
			}
		});

      if(firstTime){
      	Ti.API.debug('url: ' + url);
         LU_webView.url = url;
      }
      else{
   		if((!LU_qrCode || !LU_qrCode.length) && !needsWebview()){
         //if(){
         	getQrCode();
         }
         else if(!needsWebview()){
         	url = LU_qrCode;
         	LU_webView.url = url;
         }
         else{
         	LU_webView.url = url;
         }
      }
		return LU_webView;
	},
	getQrCode = function(_callback){
	   var urlPath = 'qr_codes';
	   var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){
               LU_webView.url = 'https://chart.googleapis.com/chart?chl='+ response.responseObj.qr_code.code +'&chs=545x545&cht=qr';
               LU_qrCode = 'https://chart.googleapis.com/chart?chl='+ response.responseObj.qr_code.code +'&chs=545x545&cht=qr';
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('.isRegistered()-Exception: ' + ex);
      }
	},
	contactServer = function(path, action, params, responseFunc, auth){
      var response = {
         Value:false,
         Message:''
      };

      try{
         if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
            response.Message = 'Internet connection is required. Please connect and try again.';
            responseFunc.apply(null, [response]);
         }
         if(!Ti.Network.online){
            response.Message = 'The network is not reachable to the internet.';
            responseFunc.apply(null, [response]);
         }
         var xhr = Ti.Network.createHTTPClient();
         xhr.setTimeout(120000);

         var midUrl = 'thelevelup.com/v15/' + path;
         var baseUrl = lvlup.LU_SANDBOX ? 'https://sandbox.' : 'https://www.';

         var url = baseUrl + midUrl;

         xhr.onload = function(e){
            var responseObject = JSON.parse(this.responseText);
            response.Value = true;
            response.responseObj = responseObject;
            responseFunc.apply(null, [response]);
         };

         xhr.onerror = function(error){
            //Ti.API.debug('error: ' + JSON.stringify(error));
            //var responseObject = JSON.parse(this.responseText);
            //Ti.API.debug('responseObject: ' + JSON.stringify(responseObject));
            //response.error = responseObject[0].error;
            response.error = error;
            responseFunc.apply(null, [response]);
         };
         xhr.onreadystatuschanged = function(e){
            Ti.API.debug('e: ' + JSON.stringify(e));
         };

         xhr.open(action, url);
         xhr.autoEncodeUrl = false;

         xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
         xhr.setRequestHeader('Accept', 'application/json');

         if(auth){
            xhr.setRequestHeader('Authorization', auth);
         }

         try{
            if(action == 'POST' && params){
               xhr.setRequestHeader('X-Requested-With', null);
               xhr.send(JSON.stringify(params));
            }
            else{
               xhr.send();
            }
         }
         catch(ex){
            Ti.API.debug('levelup-contactServer()-Exception: ' + ex);
         }
      }
      catch(ex){
         response.Message = 'Error: \n' + ex;
      }
   },
   getLoyalties = function(_callback){
      var urlPath = 'merchants/'+lvlup.LU_MERCHANT_ID+'/loyalty';
      var authToken = 'token ' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){
               var loyalties = response.responseObj.loyalty ? response.responseObj.loyalty : {};
               _callback(loyalties);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));//Check for possible error response from server.
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   getCreditAmt = function(_callback){
      var urlPath = 'locations/'+lvlup.LU_STORE_ID+'/credit';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            Ti.API.debug('response: ' + JSON.stringify(response));
            if(response.Value){
               var credits = response.responseObj.credit ? response.responseObj.credit : {};
               _callback(credits);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));//Check for possible error response from server.
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   getPaymentInfo = function(_callback){
      var urlPath = 'payment_method';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){
               var paymentInfo = response.responseObj || {};
               _callback(paymentInfo);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   createCreditCard = function(req, _callback){
      var urlPath = 'credit_cards';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'POST', req,  function(response){
            if(response.Value){
               var creditResponse = response.responseObj;
               _callback(creditResponse);
            }
            else{
               ro.ui.alert('Error', response.error.message);
               ro.ui.hideLoader();
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   /*deleteCard = function(bin, _callback){
      var urlPath = 'credit_cards/' + bin;
      var authToken = 'token ' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'DELETE', 0,  function(response){
            if(response.Value){
               var creditResponse = response.responseObj;
               _callback(creditResponse);
            }
            else{
               ro.ui.alert('Error', response.error.message);
               ro.ui.hideLoader();
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },*/
   sendGift = function(req, _callback){
      var urlPath = 'users/gift_card_value_orders';
      var authToken = 'token ' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'POST', req,  function(response){
            if(response.Value){
               _callback(response.responseObj);
            }
            else{
               ro.ui.alert('Error', response.error.message);
               ro.ui.hideLoader();
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Send Gift Card: ' + ex);
      }
   },
   submitFeedback = function(req, _callback, uuid){
      var urlPath = 'orders/'+uuid+'/feedback';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'POST', req,  function(response){
            if(response.Value){
               var feedback = {
                  Value:true,
                  feedback:response.responseObj.feedback
               };
               _callback(feedback);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   getOrderHistory = function(_callback){
      var urlPath = 'apps/orders';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){
               _callback(response.responseObj);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));
               _callback({});
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   getOrderBreakdown = function(_callback, uuid){
      var urlPath = 'orders/';
      var authToken = 'token user=' + lvlup.LU_TOKEN;

      urlPath += uuid;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){
               _callback(response.responseObj);
            }
            else{
               Ti.API.debug('response: ' + JSON.stringify(response));
            }
         }, authToken);
      }
      catch(ex){
         Ti.API.debug('Loyalties: ' + ex);
      }
   },
   isRegistered = function(_callback, username){
      var urlPath = 'registration';
      var getParams = '?api_key=' + lvlup.LU_API_KEY + '&email=' + username;

      urlPath += getParams;

      try{
         contactServer(urlPath, 'GET', 0,  function(response){
            if(response.Value){

            }
            else{
               _callback(response.responseObj);
            }
         });
      }
      catch(ex){
         Ti.API.debug('isRegistered()-Exception: ' + ex);
      }
   },
   getEncryptedVal = function(valToEncrypt){
      var encryptKey = lvlup.LU_SANDBOX ? 'MIIBCgKCAQEAxNUyPf89izTCl00dz+hRu6pbNsyI3aoEH/vUnloIG7FFgXIfzDGIQPHOPEqwaZjG6BaE1MPSVMIGKpQ5slYCvJlYByyBi/Ymhh4FYq/SRxZRhBa81waKEE4br7y7DQQnfb7EaFrvUQVpxP5e7vo5LNNCCLr+Ax/3MEVC1sm0SsPOgjt6c0/UcrfD8dW+qSEkE1slab1nY3kSdCyEKaMZvZEYE/hyEIP3+i9vnlXZ+ysDUpU5KqwRz20P59owCwCJB8pdok6uaHbFjsCweF5BhMl2YI9pBktzUd2EFO0eXmw9ZnVYgthpqV45/fABoBv7Lf3IUHd8nme3ACJ75aMTzwIDAQAB' : 'MIIBCgKCAQEAsWqrT3RkCyH6yF7ir/lphFcc/lKk792OG5sCGW2dZW3A0NDVoNOpoP0Qj6S0uqgT5higISchdJKSaqurE0fBzqpys0n+o3jTShOxsAS+k1urH7kPtW3DSw9HPVZuKkY+C8a3JcfkFb7OLQsolDGmJdI7BLlt/KB52Z7rP2EqsjqrI+HMLgjN8zWnAl6RbAFNyAsHniww8z/z1BcXhen9UTr9LXcbhZjVjsOrGNR7Ylc2uaLbg/NRuEImXhGc53Dd0DSeKocEG4jdrwZSQFVZjf2D+Hoj11bivkhrd1dwa43rik4cr4qEOlRIdq/DbIroq2tTn46nwOmPd8cFSbu81wIDAQAB';
      var braintree = Braintree.create(key);
      return braintree.encrypt(valToEncrypt);
   },
   getEncryptKey = function(){
      return lvlup.LU_SANDBOX ? 'MIIBCgKCAQEAxNUyPf89izTCl00dz+hRu6pbNsyI3aoEH/vUnloIG7FFgXIfzDGIQPHOPEqwaZjG6BaE1MPSVMIGKpQ5slYCvJlYByyBi/Ymhh4FYq/SRxZRhBa81waKEE4br7y7DQQnfb7EaFrvUQVpxP5e7vo5LNNCCLr+Ax/3MEVC1sm0SsPOgjt6c0/UcrfD8dW+qSEkE1slab1nY3kSdCyEKaMZvZEYE/hyEIP3+i9vnlXZ+ysDUpU5KqwRz20P59owCwCJB8pdok6uaHbFjsCweF5BhMl2YI9pBktzUd2EFO0eXmw9ZnVYgthpqV45/fABoBv7Lf3IUHd8nme3ACJ75aMTzwIDAQAB' : 'MIIBCgKCAQEAsWqrT3RkCyH6yF7ir/lphFcc/lKk792OG5sCGW2dZW3A0NDVoNOpoP0Qj6S0uqgT5higISchdJKSaqurE0fBzqpys0n+o3jTShOxsAS+k1urH7kPtW3DSw9HPVZuKkY+C8a3JcfkFb7OLQsolDGmJdI7BLlt/KB52Z7rP2EqsjqrI+HMLgjN8zWnAl6RbAFNyAsHniww8z/z1BcXhen9UTr9LXcbhZjVjsOrGNR7Ylc2uaLbg/NRuEImXhGc53Dd0DSeKocEG4jdrwZSQFVZjf2D+Hoj11bivkhrd1dwa43rik4cr4qEOlRIdq/DbIroq2tTn46nwOmPd8cFSbu81wIDAQAB';
   },
   unlinkRewardsAccount = function(){
   	//Eventually will make API call to either Levelup or Revention and unlink accounts more permanently...but for now here is a temporary solution
   	ro.utils.removeProp('LU_ACCESS_TOKEN');
	   lvlup.LU_TOKEN = '';

	   var customer = JSON.parse(Ti.App.Properties.getString('Customer'));
      if(!customer){
         customer = {};
      }
      ////deb.ug(customer, 'customer');
      delete customer.LUToken;
      ////deb.ug(customer, 'customer');
      Ti.App.Properties.setString('Customer', JSON.stringify(customer));

      Ti.App.Properties.setBool('RewardsUnlinked', true);

	   return true;
   },
   /*hasAfterAccountCreation = function(){
      Ti.API.debug('levelup.afterAccountCreation');
      return true;
   },*/
   afterAccount = function(){
      return ro.ui.registerRewardsBegin();
   },
   isValidCode = function(){
      return false;
   },
   addLoyaltyCodes = function(){
      
   };
	return {
		Init: Init,
		isEnabled: isEnabled,
		isMobileAuthEnabled: isMobileAuthEnabled,
		getWebView: getWebView,
		needsWebview: needsWebview,
		releaseWebview: releaseWebview,
		getToken: getToken,
		getQrCode: getQrCode,
		sendGift: sendGift,
		getLoyalties: getLoyalties,
		getCreditAmt: getCreditAmt,
		getPaymentInfo: getPaymentInfo,
		submitFeedback: submitFeedback,
		getOrderHistory: getOrderHistory,
		isRegistered: isRegistered,
		createCreditCard: createCreditCard,
		//deleteCard: deleteCard,
		getEncryptedVal: getEncryptedVal,
		getEncryptKey: getEncryptKey,
		isLoyaltyEnabled: isLoyaltyEnabled,
		isSiteRewardsCapable: isSiteRewardsCapable,
		getRegisterRewardsView: getRegisterRewardsView,
		getRewardsBool: getRewardsBool,
		getOrderBreakdown: getOrderBreakdown,
		unlinkRewardsAccount: unlinkRewardsAccount,
		//hasAfterAccountCreation: hasAfterAccountCreation,
		afterAccount: afterAccount,
		
		isLU: true,
		
		isValidCode: isValidCode,//DEFAULT LOYALTY FUNCTION - EWOM CPN CODE   - THIS IS SO IT DOESNT THROW EXCEPTION WHEN NOT EWOM
		addLoyaltyCodes: addLoyaltyCodes//DEFAULT LOYALTY FUNCTION - EWOM CPN CODE   - THIS IS SO IT DOESNT THROW EXCEPTION WHEN NOT EWOM
	};
}();
module.exports = levelup;