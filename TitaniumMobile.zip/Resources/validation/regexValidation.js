
   var emailExp = new RegExp("^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$");
   var nameExp = new RegExp("^(?=.{1,40}$)([a-zA-Z\\s]+((['.-][a-zA-Z]|[,]\\s?[a-zA-Z])?[a-zA-Z\\s]*)*[.]?)$");
   var phoneExp = new RegExp("^[01]?[- .]?(\\([2-9]\\d{2}\\)|[2-9]\\d{2})[- .]?\\d{3}[- .]?\\d{4}$");
   //var extExp = new RegExp("^(\\d{0,5})");
   var extExp = new RegExp("^(\\d{0,5})$");
   var stNumExp = new RegExp("^[\\sa-zA-Z0-9/]*$");
   var stNameExp = new RegExp("^[\\sa-zA-Z0-9-',./&]*$");
   //var cityExp = new RegExp("^[A-Za-z0-9 '-.]+$");
   var cityExp = new RegExp("^[A-Za-z0-9 .'-_\u2018\u2019\u201C\u201D]+$");

   
   //var zipExp = new RegExp("^(\\d{5}-\\d{4}|\\d{5}|\\d{4}|\\d{9})$|^([a-zA-Z]\\d[a-zA-Z] {0,1}\\d[a-zA-Z]\\d)$");
   var zipExp = new RegExp("^(\\d{5}-\\d{4}|\\d{5}|\\d{4}|\\d{9})$|^([a-zA-Z]\\d[a-zA-Z] {0,1}\\d[a-zA-Z]\\d)$|^([a-zA-Z]\\d[a-zA-Z])$");
   
   var canadaZipExp = new RegExp();
   var cvvNumExp = new RegExp("^[0-9]{3,4}$");
   var gcNumExp = new RegExp("^[0-9]{15,25}$");
   var ccNumExp;
   var alphaNumExp = new RegExp("^[A-Za-z0-9 '-.]+$");
   var spInstExp = new RegExp("^[A-Za-z0-9 !$&'(),.:;?#*%\n\r-]+$");
   var gateCodeExp = new RegExp("^[\\sa-zA-Z0-9/]*$");
   var dollarAmtExp = new RegExp("^[0-9]+$");

   exports.regExValidate = function(obj){
      var passed = {
         value:1,
         issues:[]
      },
      errorString='',
      nameObj = {
      	 UserName:'Email',
         label:'Location Name',
         addrtype:'Address Type',
         stnum:'Street Number',
         stname:'Street Name',
         city:'City',
         state:'State',
         zip:'Zip Code',
         unitnum:'Unit Number',
         unitname:'Unit Name',
         ccNum:'Credit Card Number',
         ccName:'Cardholder Name',
         cvvNum:'CVV Number',
         ccType:'Credit Card Type',
         expMonth:'Card Expiration Month',
         expYear:'Card Expiration Year',
         firstname:'First name',
         lastname:'Last name',
         phone:'Phone number',
         title:'Title',
         extension:'Extension',
         email:'New Email',
         password:'Current Password',
         newpass:'New Password',
         verifynewpass:'Verify New Password',
         spclInst:'Special Instructions',
         giftCardNum:'Gift Card Number',
         BillingStreet:'Billing Street Name',
         BillingZip:'Billing Zip Code',
         stnumname:'Street Address',
         dollarAmt:'Dollar Amount',
         levelupGcMessage:'Message',
         //itemNote:'Special Instruction',
         gateCode:'Gate Code'
      };

      for(var itm in obj){
         switch(itm){
         	case 'UserName':
         		if(!emailExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'label':
               if(!alphaNumExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'addrtype':
               if(!nameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'unitnum':
               if(!(obj[itm] === 'N/A' || obj[itm] === '')){
                  if(!stNumExp.test(obj[itm])){
                     passed.value = 0;
                     errorString += nameObj[itm] + '\n';
                  }
               }
               break;
            case 'unitname':
               if(!(obj[itm] === 'N/A' || obj[itm] === '')){
                  if(!stNumExp.test(obj[itm])){
                     passed.value = 0;
                     errorString += nameObj[itm] + '\n';
                  }
               }
               break;
            case 'stnum':
               if(!stNumExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'stname':
               if(!stNameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'stnumname':
               if(!stNameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'city':
               if(!cityExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'zip':
               if(!zipExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'title':
               break;
            case 'firstname':
               if(!nameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'lastname':
               if(!nameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'phone':
               if(!phoneExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'extension':
            	if(!obj[itm] && obj[itm]!=0){
            		//Ti.API.debug('obj['+itm+']: ' + JSON.stringify(obj[itm]));
            		//break;
            		break;
            	}
            	//Ti.API.debug('obj['+itm+']: ' + JSON.stringify(obj[itm]));
               if(!extExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'email':
               if(!emailExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            //case 'password':
            //   if(!alphaNumExp.test(obj[itm])){
            //      passed.value = 0;
            //      errorString += nameObj[itm] + '\n';
            //   }
            //   break;
            //case 'newpass':
            //   if(!alphaNumExp.test(obj[itm])){
            //      passed.value = 0;
            //      errorString += nameObj[itm] + '\n';
            //   }
            //   break;
            //case 'verifynewpass':
            //   if(!alphaNumExp.test(obj[itm])){
            //      passed.value = 0;
            //      errorString += nameObj[itm] + '\n';
            //   }
            //   break;
            case 'ccName':
               if(!nameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'ccNum':
               if(obj.ccType.toLowerCase() == 'amex'){
                  ccNumExp = new RegExp("^(\\d{1,15})$");
               }
               else{
                  ccNumExp = new RegExp("^(\\d{1,16})$");
               }

               if(!ccNumExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'cvvNum':
               if(!cvvNumExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'spclInst':
               if(!spInstExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'gateCode':
                Ti.API.debug('itm: ' + itm);
                if(!spInstExp.test(obj[itm])){
                   passed.value = 0;
                   errorString += nameObj[itm] + '\n';
                }
            	break;
            case 'giftCardNum':
               if(!gcNumExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'BillingZip':
            	if(!zipExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
            	break;
            case 'BillingStreet':
            	if(!stNameExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
            	break;
            case 'dollarAmt':
               if(!dollarAmtExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            case 'levelupGcMessage':
               if(!spInstExp.test(obj[itm])){
                  passed.value = 0;
                  errorString += nameObj[itm] + '\n';
               }
               break;
            /*case 'itemNote':
                Ti.API.debug('itm: ' + itm);
                if(!spInstExp.test(obj[itm])){
                   passed.value = 0;
                   errorString += nameObj[itm] + '\n';
                }
            	break;*/
         }
      }
      if(errorString !== ''){
         passed.issues.push('The following fields contain invalid characters: \n' + errorString);
      }
      return passed;
   };
