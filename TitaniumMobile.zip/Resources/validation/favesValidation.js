exports.favNameValidate = function(name){
   if(name != '' && name != null && name.length > 0){
      Ti.App.Properties.setString('favName', name);
      return true;
   }
   else{
      ro.ui.alert('Error: ', 'Please enter a name for this favorite order.');
      return false;
   }
};
