exports.pwValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      if(!obj.newAcc){
         if(obj.password){
            if(obj.newpass){
               if(obj.verifynewpass){
                  if(obj.password === Ti.App.Password){
                     if(obj.password != obj.newpass){
                        if(obj.newpass === obj.verifynewpass){
                           passed.value = 1;
                        }
                        else{
                           passed.issues.push('New Password and Verify Password are not the same.');
                        }
                     }
                     else{
                        passed.issues.push('New Password must not be the same as Current Password.');
                     }
                  }
                  else{
                     passed.issues.push('Current Password is incorrect.');
                  }
               }
               else{
                  passed.issues.push('Verify Password must not be blank.');
               }
            }
            else{
               passed.issues.push('New Password must not be blank.');
            }
         }
         else{
            passed.issues.push('Current Password must not be blank.');
         }
      }
      else{
         if(obj.password){
            if(obj.verifynewpass){
               if(obj.password === obj.verifynewpass){
                  passed.value = 1;
               }
               else{
                  passed.issues.push('Passwords are not the same. Make sure both passwords are exactly the same.');
               }
            }
            else{
               passed.issues.push('Verify Password must not be blank.');
            }
         }
         else{
            passed.issues.push('Password must not be blank.');
         }
      }
      return passed;
   };