exports.levelupGcValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      var errorString = '';
      var nameObj = {
         email:'Email',
         firstname:'First Name',
         dollarAmt:'Dollar Amount',
         levelupGcMessage:'Message'
      };
      
      for(var itm in obj){
         switch(itm){
            case 'email': case 'firstname': case 'dollarAmt': case 'levelupGcMessage':
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               break;
         }
      }
      /*if(!obj.email){
         errorString += '\n' + nameObj.giftCardNum + ' must not be left blank.';
      }*/
      
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
   };