
   exports.addrValidate = function(obj, custObj, isGuest){
      var errorString = '';
      var passed = {
         value:0,
         issues:[]
      };
      var nameObj = {
         label:'Location Name',
         addrtype:'Address Type',
         stnum:'Street Number',
         stname:'Street Name',
         city:'City',
         state:'State',
         zip:'Zip Code',
         unitnum:'Unit Number',
         unitname:'Unit Name',
         stnumname:'Street Address'
      };
      
      if(isGuest){
         var cityExp = new RegExp("^[A-Za-z0-9 .'-_\u2018\u2019\u201C\u201D]+$");
         var zipExp = new RegExp("^(\\d{5}-\\d{4}|\\d{5}|\\d{9})$|^([a-zA-Z]\\d[a-zA-Z] {0,1}\\d[a-zA-Z]\\d)$");
         if(obj.zip){
            if(!zipExp.test(obj.zip)){
               //passed.value = 0;
               errorString += 'Zip\n';
               passed.issues.push('The following fields contain invalid characters: \n' + errorString);
               return passed;
            }
            passed.value = 1;
            return passed;
         }
         else if(obj.city){
            if(!cityExp.test(obj.city)){
               //passed.value = 0;
               errorString += 'City\n';
               passed.issues.push('The following fields contain invalid characters: \n' + errorString);
               return passed;
            }
            obj.useCity = true;
            passed.value = 1;
            return passed;
         }
         else{
            errorString += 'City or Zip Code is required.';
            passed.issues.push(errorString);
            return passed;
         }
      }
      
      if(custObj){
         for(var i=0; i<custObj.AddressCol.length; i++){
            if((!custObj.AddressCol[i].SUD || custObj.AddressCol[i].SUD.toLowerCase() == 'n/a') && obj.unitnum.toLowerCase() === "n/a"){
               custObj.AddressCol[i].SUD = "N/A";
            }
            if((!custObj.AddressCol[i].CustAddrTypeName || custObj.AddressCol[i].CustAddrTypeName.toLowerCase() == 'n/a')  && obj.unitname.toLowerCase() === "n/a"){
               custObj.AddressCol[i].CustAddrTypeName = "N/A";
            }
            if(obj.label === custObj.AddressCol[i].Label && obj.addrtype === custObj.AddressCol[i].AddrTypeName && 
            obj.unitnum === custObj.AddressCol[i].SUD && obj.unitname === custObj.AddressCol[i].CustAddrTypeName &&
            obj.stnum === custObj.AddressCol[i].StNum && obj.stname === custObj.AddressCol[i].St && 
            obj.city === custObj.AddressCol[i].City && obj.state === custObj.AddressCol[i].State && 
            obj.zip === custObj.AddressCol[i].Zip){
               passed.issues.push('This address already exists. Address must not be identical to an existing address.');
               return passed;
            }
         }
      }
      
      for(var itm in obj){
         switch(itm){
            case "label": case "addrtype": case "stnum": case "stname": case "city": case "state": case "zip": case "stnumname":
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               break;
            case "unitnum": case "unitname":
               if(obj['addrtype'] != "House"){
                  if(!obj[itm] || obj[itm].replace(/\s/g, '') == ''){
                     errorString += '\n' + nameObj[itm] + ' must not be left blank.';
                  }
               }
         }
      }
      
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
   };
   