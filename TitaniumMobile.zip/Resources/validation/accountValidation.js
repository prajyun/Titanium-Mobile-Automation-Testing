exports.accValidate = function(obj){
      var errorString = '';
      var passed = {
         value:0,
         issues:[]
      },
      accForm = {
         address:{},
         credentials:{},
         profile:{}
      },
      accCred = {
         newAcc:1,
         password:obj['password'],
         verifynewpass:obj['verifynewpass']
      },
      accAddr = {
         label:obj['label'],
         addrtype:obj['addrtype'],
         unitnum:obj['unitnum'],
         unitname:obj['unitname'],
         //stnum:obj['stnum'],
         //stname:obj['stname'],
         stnumname:obj['stnumname'],
         city:obj['city'],
         state:obj['state'],
         zip:obj['zip']
      },
      accProf = {
         title:obj['title'],
         firstname:obj['firstname'],
         lastname:obj['lastname'],
         phone:obj['phone'],
         extension:obj['extension']
      };

      if(Ti.App.reqAddr){
      	//Ti.include('/validation/addressValidation.js');
      	var addrVal = require('validation/addressValidation');
      	accForm.address = addrVal.addrValidate(accAddr, 0);
      }

      //Ti.include('/validation/profileValidation.js');
      var profileVal = require('validation/profileValidation');
      accForm.profile = profileVal.profileValidate(accProf, 0, false/*This is for EWOM*/);

      //Ti.include('/validation/passwordValidation.js');
      var pwVal = require('validation/passwordValidation');
      accForm.credentials = pwVal.pwValidate(accCred);

      //accForm.address = addrVal.addrValidate(accAddr, 0);
      //accForm.profile = profileVal.profileValidate(accProf, 0);
      //accForm.credentials = pwVal.pwValidate(accCred);
      if(Ti.App.reqAddr){
	      if(accForm.address.value + accForm.profile.value + accForm.credentials.value !== 3){
	         accForm.credentials.value === 0?errorString+=accForm.credentials.issues[0]:'';
	         accForm.profile.value === 0?errorString+=accForm.profile.issues[0]:'';
	         accForm.address.value === 0?errorString+=accForm.address.issues[0]:'';
	         passed.issues.push(errorString);
	      }
	      else{
	         passed.value = 1;
	      }
	   }
	   else{
	   	if(accForm.profile.value + accForm.credentials.value !== 2){
	         accForm.credentials.value === 0?errorString+=accForm.credentials.issues[0]:'';
	         accForm.profile.value === 0?errorString+=accForm.profile.issues[0]:'';
	         //accForm.address.value === 0?errorString+=accForm.address.issues[0]:'';
	         passed.issues.push(errorString);
	      }
	      else{
	         passed.value = 1;
	      }
	   }

      return passed;
   };
