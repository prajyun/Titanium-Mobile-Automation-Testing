exports.gcValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      var errorString = '';
      var nameObj = {
         giftCardNum:'Gift Card Number'
      };
      
      if(!obj.giftCardNum){
         errorString += '\n' + nameObj.giftCardNum + ' must not be left blank.';
      }
      
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
};