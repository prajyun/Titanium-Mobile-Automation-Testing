exports.resetValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      var errorString = '';
      var nameObj = {
         UserName:'Email',
         newpass:'New Password',
         verifynewpass:'Verify New Password',
         Code:'Reset Code'
      };
      
      for(var itm in obj){
         switch(itm){
         	case 'UserName': case 'newpass': case 'verifynewpass': case 'Code':
	         	if(!obj[itm]){
	               errorString += '\n' + nameObj[itm] + ' must not be left blank.\n ';
	            }
         		break;
            default:
               /*if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.\n ' + itm ;
               }*/
               //Ti.API.debug('itm: ' + itm + ' and nameObj[itm]: ' + nameObj[itm]);
               break;
         }
      }
      
      if(obj.newpass !== obj.verifynewpass){
      	errorString += '\nNew password and Verify new password must match.';
      }
      
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
	};