exports.unValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      if(obj.email){
         if(obj.password){
            if(obj.email != Ti.App.Username){
               if(obj.password === Ti.App.Password){
                  passed.value = 1;
               }
               else{
                  passed.issues.push('Password is incorrect.');
               }
            }
            else{
               passed.issues.push('E-mail must be changed to make an update.');
            }
         }
         else{
            passed.issues.push('Password must not be blank.');
         }
      }
      else{
         passed.issues.push('E-mail must not be blank.');
      }
      return passed;
   };