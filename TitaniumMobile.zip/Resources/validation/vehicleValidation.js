exports.vehicleValidate = function(obj){
      var passed = {
         value:0,
         issues:[]
      };
      var errorString = '';
      var nameObj = {
         make:'Vehicle Make',
         model:'Vehicle Model',
         color: 'Vehicle Color',
         vehicleName : 'Vehicle Name'
      };

      if (obj.hasOwnProperty('vehicleName')){
          if (obj.hasOwnProperty('vhclSave')) {
              if (obj.vhclSave && !obj.vehicleName) {
                  errorString += nameObj.vehicleName + ' must not be left blank. \n';
              }
          } else {
              if (!obj.vehicleName) {
                  errorString += nameObj.vehicleName + ' must not be left blank. \n';
              }
          }
      }

      for(var itm in obj){
         switch(itm){
             case 'make': case 'model': case 'color':
               if(!obj[itm]){
                   errorString += nameObj[itm] + ' must not be left blank. \n';
               }
               break;
         }
      }
            
      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }
      
      return passed;
   };