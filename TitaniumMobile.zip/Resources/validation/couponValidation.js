var CPN = function () {
	var coupon, ordObj;
   var isValid = function(cpn, Menu, orderObject, codeBool){
   	if(!cpn || !cpn.length){
			ro.ui.alert('Error: ', 'Please select a valid coupon.');
			return;
		}
   	if(!Menu || !Menu.Cpns || !orderObject){
   		Ti.API.debug('!Menu');
   		return;
   	}
   	
   	
   	if(codeBool){
   		if(!findCouponCode(cpn)){
   			return;
   		}
   	}
   	else{
   		if(!findCouponKey(cpn)){
   			return;
   		}
   	}
   	ordObj = orderObject;
   	
   	//Begin testing coupon here.
   	//Structure the tests as separate individual function calls so that it is very easy to understand and add new tests in future
   	
   },
   findCouponKey = function (code){
   	for(var i=0; i<Menu.Cpns.length; i++){
   		if(Menu.Cpns[i].Key == code){
   			coupon = Menu.Cpns[i];
   			return true;
   		}
   	}
   	ro.ui.alert('Error: ', 'Coupon not found');
   	return false;
   },
   findCouponCode = function (code){
		for(var i=0; i<Menu.Cpns.length; i++){
			if(Menu.Cpns[i].ReqValCode){
				for(var j=0; j<Menu.Cpns[i].ValCodes.length; j++){
					if(code.toUpperCase() == Menu.Cpns[i].ValCodes[j].toUpperCase()){
						coupon = Menu.Cpns[i];
						return true;
					}
				}
			}
		}
		ro.ui.alert('Error: ', 'Coupon not found.');
		return false;
   };
   return{
      isValid:isValid
   };
}();

module.exports = CPN;