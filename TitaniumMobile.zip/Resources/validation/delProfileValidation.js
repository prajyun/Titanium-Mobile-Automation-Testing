exports.delProfileValidate = function(obj, existingCustObj){
      var passed = {
         value:1,
         msg:''
      };
      var errorString = '';
      var nameObj = {
         email:'Email',
         firstname:'First name',
         lastname:'Last name',
         phone:'Phone number'
      };

      for(var itm in obj){
         switch(itm){
            case "firstname": case "lastname": case "phone": case "email":
               if(!obj[itm]){
                  errorString += nameObj[itm] + ' must not be left blank.' +  '\n';
               }
               break;
         }
      }

      if(existingCustObj){
         if(obj['email']!= '' && obj['email'].toLowerCase() != Ti.App.Username.toLowerCase()){
            errorString += 'Email does not match.' +  '\n';
         }
         if(obj['firstname']!= '' && obj['firstname'].toLowerCase() != existingCustObj.FirstName.toLowerCase()){
            errorString += 'First Name does not match.' +  '\n';
         }
         if(obj['lastname']!= '' && obj['lastname'].toLowerCase() != existingCustObj.LastName.toLowerCase()){
            errorString += 'Last Name does not match.' +  '\n';
         }
         if(obj['phone']!= '' && obj['phone'].replace(/-/g,'') != existingCustObj.Phone.replace(/-/g,'')){
            errorString += 'Phone Number does not match.' +  '\n';
         }        
      }      

      if(errorString !== ''){
         passed.value = 0;
         passed.msg = errorString;
      }     

      return passed;
   };