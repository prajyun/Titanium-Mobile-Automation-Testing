//Ti.include('/logic/creditCard.js');
	exports.billingVerified = function(obj, flag){
		var passed = {
         value:1,
         issues:[]
      };
		if(flag === 1){
			if(obj.BillingZip.length > 10){
				passed.issues.push('Billing Zip Code must be 10 or less characters.');
				passed.value = 0;
			}
			else if(!obj.BillingZip){
				passed.issues.push('Billing Zip Code Required.');
				passed.value = 0;
			}
		}
		else if(flag === 2){
			if(obj.BillingStreet.length > 35){
				passed.issues.push('Billing St. must be 35 or less characters.');
				passed.value = 0;
	      }
	      else if(!obj.BillingStreet){
	      	passed.issues.push('Billing St. Required.');
				passed.value = 0;
			}
		}
		return passed;
	};
   exports.credCardValidate = function(obj, ccList){
   	  var ccHelper = require('logic/creditCard');
   	
      var curDate = new Date();
      var curYear = curDate.getFullYear();
      var curMonth = curDate.getMonth();
      curDate = null;

      var errorString ='';
      var passed = {
         value:0,
         issues:[]//,
         //cardType:''
      };
      var nameObj = {
         ccNum:'Credit Card Number',
         ccName:'Cardholder Name',
         cvvNum:'CVV Number',
         ccType:'Credit Card Type',
         expMonth:'Card Expiration Month',
         expYear:'Card Expiration Year',
         BillingZip:'Billing Zip Code',
         BillingStreet:'Billing Street Name'
      };
      var cardNameObj = {
      	 visa:'Visa',
      	 amex:'American Express',
      	 disc:'Discover',
      	 mc:'Master Card'
      };

      if(obj.addNew){
         //We compare newCC to all Saved CC
         for(var i=0; i<ccList.length; i++){
            if(ccList[i].CCInfo.OLCardNum === obj.ccNum){
               passed.issues.push('This creditcard already exists. Credit card number must not be identical to an existing creditcard.');
               return passed;
            }
         }
      }
      else{
         //We check the object directly
         if(ccList.OLSecCode == obj.cvvNum && ccList.OLExpMonth == obj.expMonth && ccList.OLExpYear == obj.expYear ){
            //Ti.include('/controls/ccControl.js');
            var ccControl = require('controls/ccControl');
            if(obj.ccDefault == (ccControl.getDefaultCard() == obj.rowid)){
               passed.issues.push('This creditcard already exists. You must make a change to the creditcard cvv expiry or default to succesfully make a change.');
               return passed;
            }
         }
      }

      var value = obj.ccType;
      var cardType = value.replace(/ /g, '').toLowerCase();
      var validateResult = ccHelper.ValidateCC(obj.ccNum);
      if(validateResult == 'invalid') {
         passed.issues.push('Error! Could not validate card number.');
         return passed;
      }
      else{
      	 if(!ccHelper.isCardAccepted(validateResult)){
      	 	passed.issues.push('Error! ' + cardNameObj[validateResult.toLowerCase()] + ' is not accepted at this location.');
            return passed;
      	 }
         //Ti.API.debug('validateResult: ' + validateResult);
         //Ti.API.debug('cardType: ' + cardType);
         if(validateResult != cardType) {
            passed.issues.push('Error! This card type does not match with the number provided. Please re-check.');
            return passed;
         }
         /*else{
            passed.cardType = validateResult.toUpperCase();
         }*/
      }

      if(obj.expYear == curYear && getMonthIndex(obj.expMonth) < curMonth){
         passed.issues.push('Credit card is expired');
         return passed;
      }

      for(var itm in obj){
         switch(itm){
            case 'ccNum': case 'ccName': case 'cvvNum': case 'ccType': case 'expMonth': case 'expYear': case 'BillingStreet': case 'BillingZip':
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               break;
         }
      }

      if(obj.ccName && obj.ccName.length > 26){
         passed.issues.push('Credit card name must be less than 27 characters.');
         return passed;
      }
      
      if(obj.BillingZip && obj.BillingZip.length > 10){
      	passed.issues.push('Billing Zip Code must be 10 or less characters.');
         return passed;
      }
      
      if(obj.BillingStreet && obj.BillingStreet.length > 35){
      	passed.issues.push('Billing Zip Code must be 35 or less characters.');
         return passed;
      }

      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }

      return passed;
   };
   exports.LUCredCardValidate = function(obj){
      var curDate = new Date();
      var curYear = curDate.getFullYear();
      var curMonth = curDate.getMonth();
      curDate = null;

      var errorString ='';
      var passed = {
         value:0,
         issues:[]
      };
      var nameObj = {
         ccNum:'Credit Card Number',
         ccName:'Cardholder Name',
         cvvNum:'CVV Number',
         ccType:'Credit Card Type',
         expMonth:'Card Expiration Month',
         expYear:'Card Expiration Year',
         BillingZip:'Billing Zip Code',
         BillingStreet:'Billing Street Name'
      };

      var value = obj.ccType;
      var cardType = value.replace(/ /g, '').toLowerCase();
      var validateResult = ccHelper.ValidateCC(obj.ccNum);
      if(validateResult == 'invalid') {
         passed.issues.push('Error! Could not validate card number.');
         return passed;
      }
      else{
         if(validateResult != cardType) {
            passed.issues.push('Error! This card type does not match with the number provided. Please re-check.');
            return passed;
         }
      }

      if(obj.expYear == curYear && getMonthIndex(obj.expMonth) < curMonth){
         passed.issues.push('Credit card is expired');
         return passed;
      }

      for(var itm in obj){
         switch(itm){
            case 'ccNum': case 'ccName': case 'cvvNum': case 'ccType': case 'expMonth': case 'expYear': case 'BillingStreet': case 'BillingZip':
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               break;
         }
      }

      if(obj.ccName && obj.ccName.length > 26){
         passed.issues.push('Credit card name must be less than 27 characters.');
         return passed;
      }
      
      if(obj.BillingZip && obj.BillingZip.length > 10){
         passed.issues.push('Billing Zip Code must be 10 or less characters.');
         return passed;
      }
      
      if(obj.BillingStreet && obj.BillingStreet.length > 35){
         passed.issues.push('Billing Zip Code must be 35 or less characters.');
         return passed;
      }

      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }

      return passed;
   };
   var getMonthIndex = function(inputMonth){
      var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      return monthList.indexOf(inputMonth);
   };
   
   exports.getMonthIndex = getMonthIndex;