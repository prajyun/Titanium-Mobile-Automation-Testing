exports.profileValidate = function(obj, existingCustObj, didEwomChange, didLtyChange){
      var passed = {
         value:0,
         issues:[]
      };
      var errorString = '';
      var nameObj = {
         firstname:'First name',
         lastname:'Last name',
         phone:'Phone number',
         title:'Title'
      };

      if(existingCustObj){
      	Ti.API.debug('didEwomChange: ' + didEwomChange);
      	Ti.API.debug('');
      	Ti.API.debug('obj[firstname]: ' + obj['firstname']);
      	Ti.API.debug('existingCustObj.FirstName: ' + existingCustObj.FirstName);
      	Ti.API.debug('obj[lastname]: ' + obj['lastname']);
      	Ti.API.debug('existingCustObj.LastName: ' + existingCustObj.LastName);
      	Ti.API.debug('obj[phone]: ' + obj['phone']);
      	Ti.API.debug('existingCustObj.Phone: ' + existingCustObj.Phone);
      	Ti.API.debug('obj[title]: ' + obj['title']);
      	Ti.API.debug('existingCustObj.Title: ' + existingCustObj.Title);
      	Ti.API.debug('obj[extension]: ' + obj['extension']);
      	Ti.API.debug('existingCustObj.Ext: ' + existingCustObj.Ext);

         if(!didLtyChange && !didEwomChange && obj['firstname'] === existingCustObj.FirstName && obj['lastname'] === existingCustObj.LastName && obj['phone'].replace(/-/g,'') === existingCustObj.Phone.replace(/-/g,'') && obj['title'] === existingCustObj.Title && obj['extension'] === existingCustObj.Ext){
            passed.issues.push('Error: You must make a change to the profile.');
            return passed;
         }
      }

      for(var itm in obj){
         switch(itm){
            case "firstname": case "lastname": case "phone": case "title":
               if(!obj[itm]){
                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
               }
               break;
         }
      }

      if(errorString !== ''){
         passed.issues.push(errorString);
      }
      else{
         passed.value = 1;
      }

      return passed;
   };