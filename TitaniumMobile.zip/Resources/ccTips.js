var CCTIPS = function(){
	var ccTip = {
		tipsHeader:'',
		ccTipBln:false,
		rewardTipBln:false,
		gcTipBln:false
	},
	tipHolder = 0,
	tipBtnIdx = -1,
	Init = function(tipTxt, ccBln, rewardBln, gcBln, updateTotalCb){
		try{

			tipHolder = 0;
			tipBtnIdx = -1;

			ccTip.tipsHeader = tipTxt&&tipTxt.length ? (tipTxt+'').toUpperCase() : ' WOULD YOU LIKE TO ADD TIP ?';
			ccTip.ccTipBln = ccBln?ccBln:false;
			ccTip.rewardTipBln = rewardBln?rewardBln:false;
			ccTip.gcTipBln = gcBln?gcBln:false;
            updateTotalCb();
		}
		catch(ex){
			Ti.API.debug('ccTips.Init()-Exception: ' + ex);
		}
	},
	getKeyboardToolbar = function (keyboardBtnId, txtField) {
		
        var done = Ti.UI.createButton({
        		title: 'Done',
            style: Ti.UI.iOS.SystemButtonStyle.DONE,
            id: keyboardBtnId
        });

        var spacer = Ti.UI.createButton({
        		systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
        });

        var toolbar = Ti.UI.createToolbar({
        		top: 0,
            items: [spacer, done],
            zIndex: 2,
            width: Ti.UI.FILL
        });

        done.addEventListener('click', function(){ txtField.blur(); });

        return toolbar;
    },
	getTipView = function(tipsParent, updateTotalsCb){
		var preTipBln = false;
		
		var preSelected = false;
		
		   var checkView = Ti.UI.createView({
		      height:ro.ui.relY(35),
		      width:ro.ui.relX(35),
		      backgroundImage:'/images/unselectedPlus.png',
		      visible:true,
			  touchEnabled:false
		   });
		var fullTipView;
		var tipLblView = Ti.UI.createView({
                  
         tipShowing:false,
         height: Ti.UI.SIZE,
		left:ro.ui.relX(5),
              right:ro.ui.relX(5),
				width:Ti.UI.FILL,
				layout:'horizontal'
      });
      tipsParent.ResetTip = function(){
      	if(tipLblView.tipShowing){
      		clearTip();
      		//tipLblView.tipShowing = false;
      		//tipLblViewTxt.text = ccTip.tipsHeader;
      		//checkView.backgroundImage = '/images/unselectedPlus.png';
                tipLblView.tipShowing = true;
                checkView.backgroundImage = '/images/selectedMinus.png';
                tipLblView.parent.remove(fullTipView);
                fullTipView = getFullTipView(-1, updateTotalsCb);
                tipLblView.parent.add(fullTipView);
      	}
      };
      //This if statement is commented out to enable tips to be expanded always, we can later make this configurable.
      //if((tipHolder && parseFloat(tipHolder) > 0) || tipBtnIdx !== -1){
			preTipBln = true;
			
			checkView.backgroundImage = '/images/selectedMinus.png';
			
			fullTipView = getFullTipView(tipBtnIdx, updateTotalsCb);
			//tipLblView.parent.add(fullTipView);
			tipsParent.add(tipLblView);
			tipsParent.add(fullTipView);
			tipLblView.tipShowing = true;
		//}

      //var prependStr = preTipBln ? ' - ' : ' + ';
      var tipLblViewTxt = Ti.UI.createLabel({
         text:ccTip.tipsHeader,
         /*font:{
            fontSize:ro.ui.scaleFont(15, 0, 0),
            fontWeight:'bold',
            fontFamily:ro.ui.fontFamily
         },*/
         font:{
					fontWeight:'bold',
					fontSize:ro.ui.scaleFont(14),
						fontFamily:ro.ui.fontFamily
				},
		left:ro.ui.relX(5),
		color:ro.ui.theme.darkerGray,
		height:Ti.UI.SIZE,//ro.ui.relY(35),
		top: ro.ui.relY(14),
		bottom: ro.ui.relY(14)
      });
      tipLblView.add(checkView);
      tipLblView.add(tipLblViewTxt);
      tipLblView.addEventListener('click', function (e) {        
      	if(!ro.isiOS){
      		Ti.UI.Android.hideSoftKeyboard();
      	}
      	if(tipLblView.tipShowing){
      		clearTip();
      		tipLblView.tipShowing = false;
      		checkView.backgroundImage = '/images/unselectedPlus.png';
      		tipLblView.parent.remove(fullTipView);      		
      	}
      	else{
      		tipLblView.tipShowing = true;
      		checkView.backgroundImage = '/images/selectedMinus.png';
      		fullTipView = getFullTipView(-1, updateTotalsCb);
      		tipLblView.parent.add(fullTipView);

      	}
      	updateTotalsCb(0);
      });

      function getFullTipView(btnOnIdx, updateTotalsCb/*Add some values to this function definition so that you can default certain selections when the time comes*/){
	      var tipView = Ti.UI.createView({
	      	height:Ti.UI.SIZE,//ro.ui.relY(120),
	         //backgroundColor:ro.ui.theme.darkerGray,
	         left:ro.ui.relX(2),
	         right:ro.ui.relX(2),
	         layout:'vertical'
	      });
	      var tipSelection = Ti.UI.createView({
	      	height:Ti.UI.SIZE,//ro.ui.relY(40),
	      	width:Ti.UI.FILL,
	      	bottom: ro.ui.relY(7)
	      });
		
	      var tipBorderWidth = ro.ui.relX(1);
	      var tipSelBg, tipSelTxt, tipDefBg, tipDefTxt;
	      tipSelBg = ro.ui.theme.tipBgSel;
	      tipSelTxt = ro.ui.theme.tipTxtSel;
	      tipDefBg = ro.ui.theme.tipBg;
	      tipDefTxt =  ro.ui.theme.tipTxt;

	      var tipBox = Ti.UI.createView({
	      	top:ro.ui.relY(3),
	      	//height:ro.ui.relY(35),
	      	//borderColor:'green',
	      	//borderWidth:tipBorderWidth,
	      	//borderRadius:ro.ui.relX(1),
	      	layout:'horizontal',
	      	width:Ti.UI.SIZE,
	      	height:Ti.UI.SIZE,
	      	backgroundColor: 'transparent'
	      });

	      var okTip, goodTip, greatTip, customTip;
	      var okTipLbl, goodTipLbl, greatTipLbl, customTipLbl;
		  var defBorderColor = "#e4e4e4";
		  //var clickedColor = 'white';
		  var clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
	      okTip = Ti.UI.createView({
	      	//backgroundImage:btnOnIdx === 0 ? '/images/btnGlassWhite.png' : '/images/btnGlass.png',
	      	//borderColor:ro.ui.theme.tipBorder,
	      	//borderWidth:tipBorderWidth,
	      	width: Ti.UI.SIZE,
            height: Ti.UI.SIZE,
	      	//width:ro.ui.relX(65),
	      	//height:Ti.UI.FILL,
	      	idx:0,
	      	isSelected:btnOnIdx === 0 ? true : false
	      });
	      
	      var okTipHolder = Ti.UI.createView({
                        backgroundColor:'white',
                        borderColor:defBorderColor,
                        borderWidth:ro.ui.relX(2),
                         height: Ti.UI.SIZE,
                         right: ro.ui.relX(10),
                        //height:ro.ui.relX(35),
                        width: Ti.UI.SIZE,
                        borderRadius:ro.ui.relX(17.5),
                        top:ro.ui.relY(3),
                        touchEnabled:false
                    });
                    
	      okTipLbl = Ti.UI.createLabel({
	      	text:'15%',
	      	font:{
	      		fontSize:ro.ui.scaleFont(15),
	      		fontFamily:ro.ui.fontFamily,
	      		fontWeight:btnOnIdx === 0 ? 'bold' : 'normal'
	      	},
	      	textAlign:'center',
	      	color:btnOnIdx === 0 ? tipSelTxt : tipDefTxt,
	      	touchEnabled:false,
	      	width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        left: ro.ui.relX(20),
                        right: ro.ui.relX(20),
                        top: ro.ui.relX(12),
                        bottom: ro.ui.relX(12)
	      });
	      okTipHolder.add(okTipLbl);
	      okTip.add(okTipHolder);

	      goodTip = Ti.UI.createView({
	      	//backgroundImage:btnOnIdx === 0 ? '/images/btnGlassWhite.png' : '/images/btnGlass.png',
	      	//borderColor:ro.ui.theme.tipBorder,
	      	//borderWidth:tipBorderWidth,
	      	width: Ti.UI.SIZE,
            height: Ti.UI.SIZE,
	      	//width:ro.ui.relX(65),
	      	//height:Ti.UI.FILL,
	      	idx:1,
	      	isSelected:btnOnIdx === 1 ? true : false
	      });
	      
	      var goodTipHolder = Ti.UI.createView({
                        backgroundColor:'white',
                        borderColor:defBorderColor,
                        borderWidth:ro.ui.relX(2),
                         height: Ti.UI.SIZE,
                         right: ro.ui.relX(10),
                        //height:ro.ui.relX(35),
                        width: Ti.UI.SIZE,
                        borderRadius:ro.ui.relX(17.5),
                        top:ro.ui.relY(3),
                        touchEnabled:false
                    });
                    
	      goodTipLbl = Ti.UI.createLabel({
	      	text:'20%',
	      	font:{
	      		fontSize:ro.ui.scaleFont(15),
	      		fontFamily:ro.ui.fontFamily,
	      		fontWeight:btnOnIdx === 0 ? 'bold' : 'normal'
	      	},
	      	textAlign:'center',
	      	color:btnOnIdx === 0 ? tipSelTxt : tipDefTxt,
	      	touchEnabled:false,
	      	width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        left: ro.ui.relX(20),
                        right: ro.ui.relX(20),
                        top: ro.ui.relX(12),
                        bottom: ro.ui.relX(12)
	      });
	      goodTipHolder.add(goodTipLbl);
	      goodTip.add(goodTipHolder);

	     greatTip = Ti.UI.createView({
	      	//backgroundImage:btnOnIdx === 0 ? '/images/btnGlassWhite.png' : '/images/btnGlass.png',
	      	//borderColor:ro.ui.theme.tipBorder,
	      	//borderWidth:tipBorderWidth,
	      	width: Ti.UI.SIZE,
            height: Ti.UI.SIZE,
	      	//width:ro.ui.relX(65),
	      	//height:Ti.UI.FILL,
	      	idx:2,
	      	isSelected:btnOnIdx === 2 ? true : false
	      });
	      
	      var greatTipHolder = Ti.UI.createView({
                        backgroundColor:'white',
                        borderColor:defBorderColor,
                        borderWidth:ro.ui.relX(2),
                         height: Ti.UI.SIZE,
                         right: ro.ui.relX(10),
                        //height:ro.ui.relX(35),
                        width: Ti.UI.SIZE,
                        borderRadius:ro.ui.relX(20),
                        top:ro.ui.relY(3),
                        touchEnabled:false
                    });
                    
	      greatTipLbl = Ti.UI.createLabel({
	      	text:'30%',
	      	font:{
	      		fontSize:ro.ui.scaleFont(15),
	      		fontFamily:ro.ui.fontFamily,
	      		fontWeight:btnOnIdx === 0 ? 'bold' : 'normal'
	      	},
	      	textAlign:'center',
	      	color:btnOnIdx === 0 ? tipSelTxt : tipDefTxt,
	      	touchEnabled:false,
	      	width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        left: ro.ui.relX(20),
                        right: ro.ui.relX(20),
                        top: ro.ui.relX(12),
                        bottom: ro.ui.relX(12)
	      });
	      greatTipHolder.add(greatTipLbl);
	      greatTip.add(greatTipHolder);

	      customTip = Ti.UI.createView({
	      	//backgroundImage:btnOnIdx === 0 ? '/images/btnGlassWhite.png' : '/images/btnGlass.png',
	      	//borderColor:ro.ui.theme.tipBorder,
	      	//borderWidth:tipBorderWidth,
	      	width: Ti.UI.SIZE,
            height: Ti.UI.SIZE,
	      	//width:ro.ui.relX(65),
	      	//height:Ti.UI.FILL,
	      	idx:3,
	      	isSelected:btnOnIdx === 3 ? true : false
	      });
	      
	      var customTipHolder = Ti.UI.createView({
                        backgroundColor:'white',
                        borderColor:defBorderColor,
                        borderWidth:ro.ui.relX(2),
                         height: Ti.UI.SIZE,
                         right: ro.ui.relX(10),
                        //height:ro.ui.relX(35),
                        width: Ti.UI.SIZE,
                        borderRadius:ro.ui.relX(17.5),
                        top:ro.ui.relY(3),
                        touchEnabled:false
                    });
                    
	      customTipLbl = Ti.UI.createLabel({
	      	text:'Custom',
	      	font:{
	      		fontSize:ro.ui.scaleFont(15),
	      		fontFamily:ro.ui.fontFamily,
	      		fontWeight:btnOnIdx === 0 ? 'bold' : 'normal'
	      	},
	      	textAlign:'center',
	      	color:btnOnIdx === 0 ? tipSelTxt : tipDefTxt,
	      	touchEnabled:false,
	      	width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        left: ro.ui.relX(20),
                        right: ro.ui.relX(20),
                        top: ro.ui.relX(12),
                        bottom: ro.ui.relX(12)
	      });
	      customTipHolder.add(customTipLbl);
	      customTip.add(customTipHolder);

          tipBox.addEventListener('click', function (e) {
              
			  if(tipBox.children[e.source.idx].isSelected){
			  	return;
			  }				

              var tipViews = tipBox.children;
              var tipsLength = tipViews.length;
              Ti.API.info("tipsLength: " + tipsLength);
              for (var i = 0, iMax = tipsLength; i<iMax; i++){//this loop is to unselect a previously selected tip amount, if there was such a selection
                    
                    if (i === e.source.idx) {
						continue;
					}
					if(tipViews[i].isSelected){
						tipViews[i].isSelected = false;
						tipViews[i].children[0].backgroundColor = 'white';
						tipViews[i].children[0].children[0].color = tipDefTxt;
						tipViews[i].children[0].borderColor = defBorderColor;
						break;
					}
              }
                tipViews[e.source.idx].isSelected = true;
				tipViews[e.source.idx].children[0].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
				tipViews[e.source.idx].children[0].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;;
				tipViews[e.source.idx].children[0].borderColor = ro.ui.theme.sizeBtnBlockBgActive; 
				//tipViews[e.source.idx].children[0].font.fontWeight = 'bold';

				//GET NEW ORDER TOTAL WITH getTip FUNCTION, AND MODIFY TIPENTRY AND ORDERTOTAL DISPLAYS
				
				var totalTip = Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip : 0.00;
				if(e.source.idx !== 3){//THIS IS FOR ALL TIP AMOUNTS EXCEPT CUSTOM TIP BEING CLICKED
					if(!ro.isiOS){
						Ti.UI.Android.hideSoftKeyboard();
					}
					tipEntryTxtBox.blur();
					tipEntryTxtBox.editable = false;
					tipEntryTxtBox.touchEnabled = false;
					var tipVal = calcTip(e.source.idx).toFixed(2);
					orderTotalLbl.text = 'Order Total: $' + (Ti.App.OrderObj.ActiveTotal + totalTip + parseFloat(tipVal)).toFixed(2);
					
					tipEntryTxtBox.value = tipVal;

					tipHolder = tipVal;
					tipBtnIdx = e.source.idx;
					//setTip();
					updateTotalsCb(tipVal);
				}
				else{//THIS IS FOR CUSTOM TIP BEING CLICKED
					orderTotalLbl.text = 'Order Total: $' + (Ti.App.OrderObj.ActiveTotal + totalTip).toFixed(2);
					
					tipEntryTxtBox.editable = true;
					tipEntryTxtBox.touchEnabled = true;
					tipEntryTxtBox.value = '';
					//tipEntryTxtBox.focus();
					tipEntryTxtBox.focus();

					tipHolder = 0;
					tipBtnIdx = e.source.idx;
					//tipBtnIdx = e.source.idx;
					//setTip();
					updateTotalsCb();
				}


			});
			/*function getTip(tipMultiplier){
				return ((.1 + (parseInt(tipMultiplier,10)*.05)) * Ti.App.OrderObj.Subtotal);
			}*/

	      tipBox.add(okTip);
	      tipBox.add(goodTip);
	      tipBox.add(greatTip);
	      tipBox.add(customTip);
	      tipSelection.add(tipBox);
	      tipView.add(tipSelection);

			var tipEntryView;
			var tipEntryLbl;
			var tipEntryTxtBox;

	      var tipEntry = Ti.UI.createView({
	      	height:Ti.UI.SIZE,
	      	width:Ti.UI.FILL
	      });

	      tipEntryView = Ti.UI.createView({
	      	width:Ti.UI.SIZE,
	      	height:Ti.UI.SIZE,
	      	layout:'horizontal',
	      	top:ro.ui.relY(7),
	      	bottom: ro.ui.relY(7)
	      });
	      tipEntryLbl = Ti.UI.createLabel({
	      	text:'Tip      $',
	      	font:{
	      		fontSize:ro.ui.scaleFont(15),
	      		fontFamily:ro.ui.fontFamily
	      	},
	      	color:'#393839'
	      });

	      tipEntryTxtBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
	      	width:ro.ui.relX(80),//50
	      	height:ro.ui.relY(40),//25
			padding: {},
			textAlign:'center',
	      	editable:false,//btnOnIdx === 3 ? true : false,
	      	touchEnabled: false,
	      	font:{
	      		fontFamily:ro.ui.fonts.textFields,
	      		fontSize:ro.ui.scaleFont(15)
	      	},
	      	keyboardType:Ti.UI.KEYBOARD_TYPE_DECIMAL_PAD,
	      	//softKeyboardOnFocus:!ro.isiOS ? Ti.UI.Android.SOFT_KEYBOARD_SHOW_ON_FOCUS : null
	      	
	      }));

	      tipEntryTxtBox.addEventListener('click', function(e){
	      	//Ti.API.debug('click occurred');
	      	tipEntryTxtBox.setSelection(tipEntryTxtBox.value.length, tipEntryTxtBox.value.length);
	      });
	      
	      if(ro.isiOS)
	      	tipEntryTxtBox.keyboardToolbar = getKeyboardToolbar(1, tipEntryTxtBox);

			var tipChangeEvt = function(){
				if(tipEntryTxtBox.value === ''){
					return;
				}

			   tipEntryTxtBox.removeEventListener('change', tipChangeEvt);

			   var trimmedStr = tipEntryTxtBox.value.replace(/\D/g,'');
			   //Ti.API.debug('trimmedStr: ' + trimmedStr);
			   if(!isNaN(trimmedStr)){
			   	trimmedStr = parseInt(trimmedStr,10);
			   	if(isNaN(trimmedStr)){
			   	  trimmedStr = '0';
			   	}
			   	else{
			   	   trimmedStr = trimmedStr.toString();
			   	}
			   	//.toString();
			   }
			   //Ti.API.debug('trimmedStr: ' + trimmedStr);
			   decimalizeTip(trimmedStr);
			   //setTip();
			   updateTotalsCb(tipHolder);
			};
			var decimalizeTip = function(trimmedStr){
				if(trimmedStr && trimmedStr.length){
					if(trimmedStr.length === 1){
						trimmedStr = '0.0'+trimmedStr;
					}
					else if(trimmedStr.length === 2){
						trimmedStr = '0.'+trimmedStr;
					}
					else{
						var lastTwoIdx = (trimmedStr.length-2);
						trimmedStr = trimmedStr.slice(0, lastTwoIdx) + "." + trimmedStr.slice(lastTwoIdx);
					}
					tipEntryTxtBox.value = trimmedStr;
					var tipVal = parseFloat(tipEntryTxtBox.value);
					var totalTip = Ti.App.OrderObj.Tip ? parseFloat(Ti.App.OrderObj.Tip) : 0.00;
					orderTotalLbl.text = 'Order Total: $' + (Ti.App.OrderObj.ActiveTotal + totalTip + tipVal).toFixed(2);	
				}

				var tipVal = parseFloat(tipEntryTxtBox.value);
				tipHolder = tipVal.toFixed(2);

				tipEntryTxtBox.setSelection(tipEntryTxtBox.value.length, tipEntryTxtBox.value.length);

				setTimeout(function(){
			      tipEntryTxtBox.addEventListener('change', tipChangeEvt);
			   }, 100);
			};
	      tipEntryTxtBox.addEventListener('change', tipChangeEvt);

	      if(btnOnIdx !== -1){
	      	tipEntryTxtBox.value = parseFloat(tipHolder).toFixed(2);
	      }

	      tipEntryView.add(tipEntryLbl);
	      tipEntryView.add(tipEntryTxtBox);

	      tipEntry.add(tipEntryView);
	      tipView.add(tipEntry);

	      var orderTotal = Ti.UI.createView({
	      	height:Ti.UI.SIZE
	      });
	      var orderTotalLbl = Ti.UI.createLabel({
	      	text:btnOnIdx !== -1 ? 'Order Total: $' + (Ti.App.OrderObj.ActiveTotal + parseFloat(tipHolder)).toFixed(2) : 'Order Total: $' + Ti.App.OrderObj.ActiveTotal.toFixed(2),//Ti.App.OrderObj.Subtotal + Ti.App.OrderObj.Tax + NewTipProperty?
	      	font:{
					fontWeight:'bold',
					fontSize:ro.ui.scaleFont(16),
						fontFamily:ro.ui.fontFamily
				},
		
		color:ro.ui.theme.darkerGray,
	      	textAlign:'center',
	      	height:Ti.UI.SIZE,
	      	top: ro.ui.relY(7),
	      	bottom: ro.ui.relY(14),
	      	width:Ti.UI.FILL
	      });
	      orderTotal.add(orderTotalLbl);
	      tipView.add(orderTotal);
	      return tipView;
	   }

		/*if(tipBtnIdx === -1){
      	tipsParent.add(tipLblView);
      }*/
	},
	calcTip = function(tipMultiplier){
		var x = parseInt(tipMultiplier,10) + 1;
		return (2.5*x*x - 2.5*x + 15) * 0.01 * Ti.App.OrderObj.Subtotal;
	},
	getTip = function(){
		if(!ccTip.ccTipBln && !ccTip.rewardTipBln && !ccTip.gcTipBln){
			
			return 0;
		}
		//Ti.API.info("tipHolder: "+tipHolder);
		if(tipHolder){
			if(isNaN(tipHolder)){
				return 0;
			}
			
			var tip = (Math.round(parseFloat(tipHolder) * 100) / 100).toFixed(2);
			return parseFloat(tip);
		}else return 0;
	},
	setTip = function(){
		//Ti.API.info("Das setTip been called man");
		if(!ccTip.ccTipBln && !ccTip.rewardTipBln && !ccTip.gcTipBln){
			return;
		}
		if(tipHolder && tipBtnIdx !== -1){
			if(isNaN(tipHolder)){
				return;
			}
			var test = Ti.App.OrderObj;
			var newTip = (Math.round(parseFloat(tipHolder) * 100) / 100);
			//Ti.API.info("test tip before set tip:  " + test.Tip);
			test.Tip = test.Tip ? parseFloat((test.Tip + newTip).toFixed(2)) : newTip;
			//Ti.API.info("test tip after set tip:  " + test.Tip);
			Ti.App.OrderObj = test;
			test = null;
			
			//Ti.API.info("tip in set tip:  " + Ti.App.OrderObj.Tip);
		}
	},
	clearTip = function(){
		tipHolder = 0;
		tipBtnIdx = -1;
	};
	return {
		Init: Init,
		getTipView: getTipView,
		clearTip: clearTip,
		setTip: setTip,
		getTip: getTip
	};
}();
module.exports = CCTIPS;