﻿// <reference path="app.dialog.js" />

var hrush = hrush || {};

var google = {};
google.maps = function () {

    var GeocoderStatus = {
        "OK": "OK",
        "UNKNOWN_ERROR": "UNKNOWN_ERROR",
        "OVER_QUERY_LIMIT": "OVER_QUERY_LIMIT",
        "REQUEST_DENIED": "REQUEST_DENIED",
        "INVALID_REQUEST": "INVALID_REQUEST",
        "ZERO_RESULTS": "ZERO_RESULTS",
        "MASK_ERROR": "MASK_ERROR",
        "ERROR": "ERROR",
        "INVALID_ADDRESS": "INVALID_ADDRESS"
    };

    var geocode = function (addressObject, callback, GOOG_MAPS_KEY) {

        var xhrGeocode = Titanium.Network.createHTTPClient();
        xhrGeocode.timeout = 120000;
        xhrGeocode.onload = function (e) {
            var response = JSON.parse(this.responseText);
            callback(response.results, response.status);
        };       
        
        var websiteUrl;
        if(ro.App.isSecure){
            websiteUrl = Ti.App.websiteURL;
        }else{
            //For testing on unsecure websites
            websiteUrl = 'https://demo.hungerrush.com/';
        }
        var url = websiteUrl + "api/v1/maps/geocode?address=" + addressObject.address.replace(/ /g, '+');

        //var url = Ti.App.websiteURL + "api/v1/maps/geocode?address=" + addressObject.address.replace(/ /g, '+');

        if (false && addressObject.filter) {
            url += 'components=';
            if (addressObject.filter.country) {
                url += 'country:' + addressObject.filter.country;
            }
            if (addressObject.filter.postalCode) {
                url += '|postalCode:' + addressObject.filter.postalCode;
            }
        }
        //url += "&sensor=" + (Titanium.Geolocation.locationServicesEnabled == true);
        
        
        /*if(GOOG_MAPS_KEY && GOOG_MAPS_KEY.length){
        	url += "&key=" + GOOG_MAPS_KEY;
        }*/
       
       	//Ti.include('/classes/crypto.js');
	      //Ti.include('/classes/crypto64.js');
	      //var CryptoJS = require('classes/crypto');
	      //require('classes/crypto64');
	      var Config = JSON.parse(Ti.App.Properties.getString('Config'));
			if (!Config) {
				Config = {};
			}
	        var CryptoJS = require('classes/crypto').getCrypto();
	        
	        
	      var reqMethod = "GET";
	      var timeStamp = parseInt(((new Date().getTime()) / 1000), 10);
	      var sig = timeStamp+''+url+reqMethod;
	        
	      var C_CRIT = "nCQunCHaKistpyxQJZtwVQ==";
	      var hash = CryptoJS.HmacSHA256(sig, C_CRIT);
	      
	      var sigHash = CryptoJS.enc.Base64.stringify(hash);
	      
	      
       
        xhrGeocode.open(reqMethod, url);
        xhrGeocode.setRequestHeader('Accept-Encoding', 'gzip,deflate');
        xhrGeocode.setRequestHeader('Accept', 'application/json');
        xhrGeocode.setRequestHeader('X-Stamp', timeStamp);
	    xhrGeocode.setRequestHeader('X-Signature', sigHash);
        xhrGeocode.send();

        xhrGeocode.onerror = function (e) {
            callback(null, GeocoderStatus.ERROR);
        };

    };

    return {
        geocode: geocode,
        GeocoderStatus: GeocoderStatus
    };
}();

hrush.geo = function () {
    var geocoder = null;
    var mapId = "#map";
    var GeocoderStatusDescription = {
        "OK": "The request did not encounter any errors",
        "UNKNOWN_ERROR": "A geocoding request could not be successfully processed, yet the exact reason for the failure is not known",
        "OVER_QUERY_LIMIT": "The webpage has gone over the requests limit in too short a period of time",
        "REQUEST_DENIED": "The webpage is not allowed to use the geocoder for some reason",
        "INVALID_REQUEST": "This request was invalid",
        "ZERO_RESULTS": "The request did not encounter any errors but Google returns zero results",
        "MASK_ERROR": "Google mapping service is unable to locate your address.",
        "ERROR": "There was a problem contacting the Google servers",
        "INVALID_ADDRESS": "Sorry, we are unable to validate your address."
    },
    allowLongName = false,
    allowPostalCodeAccuracy = false;
    exports.setStreetType = function (allowLName, allowPCAccuracy) {
        allowLongName = allowLName || allowLName == 'True' ? true : false;
        allowPostalCodeAccuracy = allowPCAccuracy || allowPCAccuracy == 'True' ? true : false;
    };
    var stripVowelAccent = function (str) {
        var rExps = [{ re: /[\xC0-\xC6]/g, ch: 'A' },
                     { re: /[\xE0-\xE6]/g, ch: 'a' },
                     { re: /[\xC8-\xCB]/g, ch: 'E' },
                     { re: /[\xE8-\xEB]/g, ch: 'e' },
                     { re: /[\xCC-\xCF]/g, ch: 'I' },
                     { re: /[\xEC-\xEF]/g, ch: 'i' },
                     { re: /[\xD2-\xD6]/g, ch: 'O' },
                     { re: /[\xF2-\xF6]/g, ch: 'o' },
                     { re: /[\xD9-\xDC]/g, ch: 'U' },
                     { re: /[\xF9-\xFC]/g, ch: 'u' },
                     { re: /[\xD1]/g, ch: 'N' },
                     { re: /[\xF1]/g, ch: 'n' },
                     { re: /[,]/g, ch: '' },
                     { re: /[\x60]/g, ch: '\'' }];
        for (var i = 0, len = rExps.length; i < len; i++) {
            str = str.replace(rExps[i].re, rExps[i].ch);
        }
        return str;
    },
    getName = function (addressCol, names, longName, maxlength, defValue) {
        var i, j, k;
        if (addressCol != null && names) {
            for (i = 0; i < names.length; i++) {
                for (j = 0; j < addressCol.length; j++) {
                    for (k = 0; k < addressCol[j].types.length; k++) {
                        if (addressCol[j].types[k] == names[i]) {
                            var name = longName ? addressCol[j].long_name : addressCol[j].short_name;
                            if (maxlength && name.length > maxlength) {
                                if (longName) {
                                    name = addressCol[j].short_name;
                                }
                                else {
                                    name = name.substr(0, maxlength);
                                }
                            }
                            return stripVowelAccent(name);
                        }
                    }
                }
            }
            if (defValue && defValue.length > 0) {
                if (maxlength && defValue.length > maxlength) {
                    return defValue.substr(0, maxlength);
                }
                else {
                    return defValue;
                }
            }
        }
        return "";
    },
    getObj = function (addressResult, fallbackStNumber, fallbackSt) {
        return {
            StNumber: getName(addressResult.address_components, ['street_number'], false, 8, fallbackStNumber),
            Street: getName(addressResult.address_components, ["route"], allowLongName, 35, fallbackSt),
            City: getName(addressResult.address_components, ["locality", "sublocality", "neighborhood", "administrative_area_level_3"], false, 25),
            State: getName(addressResult.address_components, ["administrative_area_level_1"]),
            Zip: getName(addressResult.address_components, ["postal_code"]),
            Address: addressResult.formatted_address,
            Lat: addressResult.geometry.location.lat,
            Lon: addressResult.geometry.location.lng,
            PartialMatch: addressResult.partial_match && addressResult.types && addressResult.types.length > 0 && (addressResult.types.indexOf("route") < 0)
        };
    },
    getResult = function (result, exactMatch, fallbackStNumber, fallbackSt) {
        var markers = [];
        if (result) {
            for (var i = 0; i < result.length; i++) {
                if (!exactMatch || (result[i].types && result[i].types.length > 0 && (result[i].types.indexOf("street_address") > -1
                                                                                      || result[i].types.indexOf("premise") > -1
                                                                                      || result[i].types.indexOf("route") > -1
                                                                                      || result[i].types.indexOf("subpremise") > -1
                                                                                      || result[i].types.indexOf("floor") > -1
                                                                                      || result[i].types.indexOf("point_of_interest") > -1
                                                                                      || result[i].types.indexOf("parking") > -1
                                                                                      || result[i].types.indexOf("room") > -1
                                                                                      || (allowPostalCodeAccuracy && result[i].types.indexOf("postal_code") > -1))
                    )) {
                    var obj = getObj(result[i], fallbackStNumber, fallbackSt);
                    markers.push(obj);
                }
            }
        }
        return markers;
    },
    getMarkersHtml = function (data) {
        var html = '<ul id="didyoumean" class="addressList" style="margin:15px;">';
        for (i = 0; i < data.length; i++) {
            html += '<li><a href="#" data-idx="' + i + '">' + data[i].Address + '</a></li>';
        }
        html += '</ul>';
        return html;
    };
    exports.geocode2 = function (address, callback, exactMatch, GOOG_MAPS_KEY) {
    	
    	////Ti.API.debug("GOOG_MAPS_KEY: " + GOOG_MAPS_KEY);
    	if(!GOOG_MAPS_KEY || !GOOG_MAPS_KEY.length){
        	if(Ti.App.googKey && Ti.App.googKey.length){
        		GOOG_MAPS_KEY = Ti.App.googKey;
        	}
        }
    	
        var fallbackStNumber = "";
        var fallbackSt = "";
        var filter = {};
        if (exactMatch) {
            var splt = address.split(',');
            var len = splt.length;
            if (len > 0) {
                filter.country = splt[len - 1].trim();
                if (allowPostalCodeAccuracy && (len - 2) >= 0) {
                    filter.postalCode = splt[len - 2].trim();
                }
                fallbackSt = splt[0].trim();
                var stNumbers = fallbackSt.match(/\s+\d+|\d+\s+/i);
                if (stNumbers && stNumbers.length > 0) {
                    fallbackStNumber = stNumbers[0].trim();
                }                
            }                       
        }
      

        geocoder = google.maps;
        geocoder.geocode({ 'address': address, 'componentRestrictions': filter }, function (results, status) {
        	//Ti.API.info('results: ' + JSON.stringify(results));
        	//Ti.API.info('status: ' + JSON.stringify(status));
            if (results && results.length > 0) {
                var markers = getResult(results, exactMatch, fallbackStNumber, fallbackSt);
                if (markers.length == 0) {
                    callback({ success: false, message: GeocoderStatusDescription.INVALID_ADDRESS });
                    return false;
                }
                if (markers.length == 1 && !markers[0].PartialMatch) {
                	//var returnData = [];
                	//returnData.push(markers[0]);
                    //callback({ success: true, data:returnData });
                    callback({ success: true, data:markers });
                    return false;
                }
                else {
                    callback({ success: false, data: markers });
                    return false;
                }
            }
            else {
                var msg = "Unable to process geocode request";
                if (status == google.maps.GeocoderStatus.ERROR) {
                    msg = GeocoderStatusDescription.ERROR;
                }
                else {
                    msg = GeocoderStatusDescription.MASK_ERROR;
                }
                callback({ success: false, message: msg });
            }
            return false;
        }, GOOG_MAPS_KEY);
    };

    /*return {
        geocode2: geocode2,
        getMarkersHtml: getMarkersHtml,
        setStreetType: setStreetType
    };*/
}();