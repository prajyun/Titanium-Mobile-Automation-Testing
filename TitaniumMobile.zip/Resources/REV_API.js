var REV_API = function(){
   var UpdateCustomer = function(req, _callback, printMsgBln){
      var response;
      ro.dataservice.post(req, 'UpdateProfile', function(response){
         if(response){
         	//response.Value = false;
         	//response.Message = "O Noes";
            if(response.Value){
               _callback();
            }
            if(!printMsgBln){
               ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
            }
            
            if(!response.Value){
            	//alertD.message = response.Message;
            	//alertD.show();
            	ro.ui.alert('Error', response.Message);
				//alertD.title = "Error";
				//alertD.
            	_callback(true);
            }
         }
         else{
         	ro.ui.alert('Error', 'There was a problem updating your profile.');
         	_callback(true);
         }
      });
   };
   return {
      UpdateCustomer: UpdateCustomer
   };
}();
module.exports = REV_API;