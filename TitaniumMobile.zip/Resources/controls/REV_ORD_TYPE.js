var REV_ORD_TYPE = function(){
   var IS_ANDROID = true,
       cfg = null,
       SelectedOrdTypeObj = null, 
   NeedsToCheckSpecificOrdType = true,
   testCoupons = function(){
   	  if(((!Ti.App.OrderObj.Items || !Ti.App.OrderObj.Items.length) && (!Ti.App.OrderObj.Cpns || !!Ti.App.OrderObj.Cpns.length))){
   	  	 return;
   	  }
   	  
   	  var store;
   	  if(IS_ANDROID){
   	  	 store = ro.app.Store;
   	  }
   	  else{
   	  	 //store = 
   	  }
   	  var newCpnCol = [];
   	  var couponsToRemove = [];
   	  var foundIssues = false;
   	  var addThisOne = true;
   	  if(Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length){
   	  	 var theCpn, storeCpn;
   	  	 for(var i=0, iMax=Ti.App.OrderObj.Cpns.length; i<iMax; i++){
   	  	 	addThisOne = true;
   	  	 	theCpn = Ti.App.OrderObj.Cpns[i];
   	  	 	for(var j=0, jMax=store.Menu.Cpns.length; j<jMax; j++){
   	  	 		storeCpn = store.Menu.Cpns[j];
   	  	 		if(theCpn.Name.toLowerCase() == storeCpn.Name.toLowerCase()){
   	  	 			addThisOne = false;
   	  	 			if(storeCpn.NoDelivery){
		   	  	 		Ti.API.debug('theCpn: ' + JSON.stringify(theCpn));
		   	  	 		//_cb(true);
		   	  	 		foundIssues = true;
		   	  	 		couponsToRemove.push(theCpn.Name);
		   	  	 	}
		   	  	 	else{
		   	  	 		newCpnCol.push(theCpn);
		   	  	 	}
   	  	 		}
   	  	 	}
   	  	 	if(addThisOne){
   	  	 		newCpnCol.push(theCpn);
   	  	 	}
   	  	 }
   	  }
   	  
   	  if(Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
   	  	 var theItem, storeCpn;
   	  	 for(var i=0, iMax=Ti.App.OrderObj.Items.length; i<iMax; i++){
   	  	 	theItem = Ti.App.OrderObj.Items[i];
   	  	 	if(theItem.hasOwnProperty('CpnObj') && theItem.CpnObj){
   	  	 		for(var j=0, jMax=store.Menu.Cpns.length; j<jMax; j++){
   	  	 			storeCpn = store.Menu.Cpns[j];
   	  	 			
   	  	 			if(storeCpn && theItem && storeCpn.Name.toLowerCase() == theItem.CpnObj.Name.toLowerCase()){
   	  	 				if(storeCpn.NoDelivery){
	   	  	 				Ti.API.debug('theItem.CpnObj: ' + JSON.stringify(theItem.CpnObj));
			   	  	 		foundIssues = true;
			   	  	 		couponsToRemove.push(theItem.CpnObj.Name);
			   	  	 		//delete theItem.CpnObj;
			   	  	 		delete theItem.CpnObj;
			   	  	 		delete theItem.singleItemIdentifier;
			   	  	 		Ti.App.OrderObj.Items[i] = theItem;
			   	  	 	}
			   	  	 	break;
   	  	 			}
   	  	 		}
   	  	 	}
   	  	 }
   	  }
   	  
   	  store = null;
   	  if(foundIssues){
   	  	 var msgHdr = 'Coupons Removed';
   	  	 var msgBody = 'The following coupons are not valid for Web-Delivery ordertype: \n';
   	  	 for(var i=0, iMax=couponsToRemove.length; i<iMax; i++){
   	  	 	msgBody += ('\n' + couponsToRemove[i]);
   	  	 }
   	  	 
   	  	 if(IS_ANDROID){
   	  	 	ro.ui.alert(msgHdr, msgBody);
   	  	 	
   	  	 	var test = Ti.App.OrderObj;
   	  	 	test.Cpns = null;
   	  	 	test.Cpns = [];
   	  	 	test.Cpns = newCpnCol;
   	  	 	Ti.App.OrderObj = test;
   	  	 	test = null;
   	  	 }
   	  	 else{
   	  	 	
   	  	 }
   	  }
   },
   setOrdType = function (isDelivery) {
           //NeedsToCheckSpecificOrdType = false;
   	    ro.REV_GUEST_ORDER.setGuestAddr();
   		var clearCust = true;
       NeedsToCheckSpecificOrdType = true;
       SelectedOrdTypeObj = null;
   	 	var test = Ti.App.OrderObj;
   	 	  if(test.ordOnlineOptions && test.ordOnlineOptions.IsDelivery && isDelivery){
   	 	  	 clearCust = false;
   	 	  }
	      test.OrdType = null;
	      test.ordOnlineOptions = {};
	      test.ordOnlineOptions.IsDelivery = isDelivery;
	      if(clearCust){
	      	test.Customer = {};
	      }
	      	
	      Ti.App.OrderObj = test;
	      test = null;
      if(isDelivery){
      	testCoupons();
      }
      
      if(Ti.App.OrderObj){
      	if((Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length)){
      		if(ro.app.Store && ro.app.Store.Menu){
      			
      			setOrderObj();
      		}
      	}
      }
      
   },
   setOrdTypeSpecific = function(ordTypeName){
   	 	NeedsToCheckSpecificOrdType = false;
        var ordIdx, test;
		ordIdx = ro.utils.getMatchingIdx(ordTypeName, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'OrdType');
		test = Ti.App.OrderObj;
        test.OrdType = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdType;
        test.OrderTypeCategory = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrderTypeCategory;
		test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdTypePriceIdx;
		test.Menu = ro.app.Store.Menu.Name;
		test.CurSplit = 0;
		
		if(!test.Items || !test.Items.length){
			test.Items = [];
		}
		
		if(!test.Cpns || !test.Cpns.length){
			test.Cpns = [];
		}
		
		Ti.App.OrderObj = test;
		test = null;
   };
   function IsDeliveryWithoutAddress(){
    		if (Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery && (Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length)){
    			if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
    				return !ro.REV_GUEST_ORDER.hasSelectedAddress();
    			}
    			else{
    				if(!Ti.App.OrderObj.Customer) return true;
    			
    				var foundAddress = ((Ti.App.OrderObj.Customer.StNum && Ti.App.OrderObj.Customer.StNum.length>0) && ((Ti.App.OrderObj.Customer.St && Ti.App.OrderObj.Customer.St.length>0)||(Ti.App.OrderObj.Customer.Street && Ti.App.OrderObj.Customer.Street.length>0)) && (Ti.App.OrderObj.Customer.City && Ti.App.OrderObj.Customer.City.length>0) && (Ti.App.OrderObj.Customer.State && Ti.App.OrderObj.Customer.State.length>0) && (Ti.App.OrderObj.Customer.Zip && Ti.App.OrderObj.Customer.Zip.length>0));
    				return !foundAddress;
    			}
    		}
    		return false;
    }
   function setOrderObj(){
		var ordIdx, test;		
        test = Ti.App.OrderObj;
        if (!hasMultipleOrdTypes()) {
            ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.ordOnlineOptions.IsDelivery, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'IsDelivery');
            test.OrdType = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdType;
            test.OrderTypeCategory = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrderTypeCategory;
            test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdTypePriceIdx;
        }
		test.Menu = ro.app.Store.Menu.Name;
		test.CurSplit = 0;
		
		if(!test.Items || !test.Items.length){
			test.Items = [];
		}
		
		if(!test.Cpns || !test.Cpns.length){
			test.Cpns = [];
		}		
       Ti.App.OrderObj = test;       
       test = null;
       
   }
   function resetOrderObj() {      
       var test = Ti.App.OrderObj;    
           
           test.OrdType = null;
           test.OrderTypeCategory = null;    
       
       Ti.App.OrderObj = test;
       test = null;

   }
	var getButton = function(btnTxt){
	   	  var largerText = true;
          var submitBtn = ro.layout.getPrimaryButton(btnTxt);
	   	  //submitBtn.top = ro.ui.relY(40);
	   	  submitBtn.top = ro.ui.relY(10);
	   	  submitBtn.bottom = ro.ui.relY(10);
	   	  
	   	  return submitBtn;
	  };
	  /*var clrRandomizer = function(idx){
	  	return idx%2 ? "blue" : "brown";
	  };*/
	  var getOrderTypeRow = function(ordType, isSelected, id, _cb/*, clr*/){
	  	//Ti.API.info('isSelected: ' + isSelected);
	  		var row = Ti.UI.createView({
	  			height:ro.ui.relY(60),
	  			width:Ti.UI.FILL,
	  			layout:'horizontal',
	  			//backgroundColor:clr,
	  			id:id,
	  			isSelected:isSelected,
	  			ordType:ordType
	  		});
	  		var leftBox, rightBox;
	  		leftBox = Ti.UI.createView({
	  			height:Ti.UI.FILL,
	  			width:'20%',
	  			touchEnabled:false
	  		});
	  		
	  		var checkbox = Ti.UI.createView({
	         //height:Ti.UI.FILL,
	         //top:ro.ui.relX(5),
	         width:ro.ui.relX(20),
	         height:ro.ui.relY(20),
	         borderRadius:ro.ui.relX(10),
	         //theValue:isChecked==true?true:false,
	         borderColor:'#f2f2f2',
	         borderWidth:ro.ui.relX(2),
	         backgroundImage:isSelected ? "/images/switch_on.png" : null,
	         touchEnabled:false
	     });
      		leftBox.add(checkbox);
	  		
	  		rightBox = Ti.UI.createView({
	  			height:Ti.UI.FILL,
	  			width:Ti.UI.FILL,
	  			touchEnabled:false
	  		});
	  		rightBox.add(Ti.UI.createLabel({
	  			text:ordType.RcptName,
	  			color:'#393839',
	  			//left:ro.ui.relX(20),
	  			font:{
	  				fontFamily:ro.ui.fonts.rowBodyTxt,
	  				fontSize:ro.ui.scaleFont(20)
	  			},
	  			touchEnabled:false,
	  			left:0,
	  			textAlign:'left'
	  		}));
	  		row.add(leftBox);
	  		row.add(rightBox);
	  		row.toggle = function(isSelected){
	  			//policyCheckbox.theValue = !policyCheckbox.theValue;
                row.isSelected = isSelected;
      			checkbox.backgroundImage = isSelected ? "/images/switch_on.png" : "/images/switch_onFAKE.png";
	  		};
	  		/*function toggleCheckbox(isSelected){
	  			
	  		}*/
	  		row.addEventListener('click', function(){
                var newSelectedValue = !row.isSelected;                
	  			//row.isSelected = !row.isSelected;
	  			//row.toggle(newSelectedValue);
                    if (newSelectedValue) {
                        SelectedOrdTypeObj = ordType;
	  				    row.toggle(newSelectedValue);
	  				    _cb(row.id);
	  			    }
	  		});
	  		
	  		return row;
	  };
    var promptForSpecificOrdType = function (_cb) {

        var ordTypes = ro.app.Store.Menu.OnlineOptions.OrdTypes;
        var selectedOrdType = Ti.App.OrderObj.OrdType;
        Ti.API.info("ordTypes.length : " + ordTypes.length);
        for (i = ordTypes.length - 1; i >= 0; i--) {
            if (ordTypes[i].IsDelivery != Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                ordTypes.splice(i, 1);
            }
        }
        if (!ordTypes || !ordTypes.length) { return; };

        var ordTypeWin = layoutMenuHelper.modalSuggWin();
        ordTypeWin.addEventListener('close', function () {
            if (_cb) _cb();
            ordTypeWin = null;
        });

        //var cancelTxt = SUGG_ITM_BTN_NO;
        var confirmTxt = "Submit";

        var tblHdr = Ti.UI.createLabel({
            text: 'Order Type',
            textAlign: 'center',
            top: ro.ui.relY(15),
            font: {
                fontSize: ro.ui.scaleFont(35, 0, 0),
                //fontWeight:'bold',
                fontFamily: ro.ui.fonts.titles
            },
            height: Ti.UI.SIZE,
            width: Ti.UI.FILL,
            color: ro.ui.theme.backgroundpngTxt
        });

        var selectionView = Ti.UI.createView({
            backgroundColor: 'white',
            layout: 'vertical',
            top: ro.ui.properties.topAfterNavbar + ro.ui.relY(15),
            left: ro.ui.relX(10),
            right: ro.ui.relX(10),
            height: Ti.UI.SIZE,
            borderRadius: ro.ui.relX(10),
            zIndex: 6,
            elevation: 10,
            translationZ: 10
        });
        selectionView.add(tblHdr);
        var data = [];
       
        if (checkOrdTypeImages(ordTypes)) {
            var selectionBox = Ti.UI.createScrollView({
                left: ro.ui.relX(10),
                right: ro.ui.relX(10),
                height: Ti.UI.SIZE,
                borderRadius: ro.ui.relX(10),
                layout: 'vertical',
                accessibilityHidden : true
            });
            var ordTypeLen = ordTypes.length;
            for (var i = 0; i < ordTypeLen; i += 2) {
                if (i + 1 < ordTypeLen) {
                    data.push(addItemRow(ordTypes[i], ordTypes[i + 1], ordTypeLen == 2));
                }
                else {
                    data.push(addItemRow(ordTypes[i], null, ordTypeLen == 2));
                }
            }
            selectionBox.add(data);
            selectionView.add(selectionBox);                
        } else {
            selectionView.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));                
            var greyBarCounter = 0;
            Ti.API.info("ordTypes.length : " + ordTypes.length);
            for (i = 0, iMax = ordTypes.length; i < iMax; i++) {
                data.push(getOrderTypeRow(ordTypes[i], (selectedOrdType == ordTypes[i].OrdType), (i + greyBarCounter), deselectOtherRows));
                //if((i+1) != iMax){
                data.push(Ti.UI.createView(ro.ui.properties.fullGreyBar));
                greyBarCounter++;
                //}
            }
            function deselectOtherRows(rowSkipIdx) {
                for (var i = 0, iMax = data.length; i < iMax; i++) {
                    if (i == rowSkipIdx) continue;
                    if (data[i].isHeader) continue;
                    data[i].toggle(false);
                }
            }
            //selectionView.add(suggTblBody);
            selectionView.add(data);
        }
        
        var submitBtn = getButton(confirmTxt);

        submitBtn.addEventListener('click', function () {
            //var selectedOrderType = null;
            //for (var i = 0, iMax = data.length; i < iMax; i++) {
            //    if (data[i].isSelected) {
            //        selectedOrderType = data[i].ordType;
            //        break;
            //    }
            //}

            if (SelectedOrdTypeObj) {
                Ti.API.info('selectedOrderType: ' + JSON.stringify(SelectedOrdTypeObj));
                setOrdTypeSpecific(SelectedOrdTypeObj.OrdType);
            }
            else {
                selectWarning.visible = true;
                selectWarning.height = Ti.UI.SIZE;
                selectWarning.top = ro.ui.relY(5);
                return;
            }
            ro.App.openWindows.pop();
            ordTypeWin.close();
        });

        //submitBtn.left = ro.ui.relX(15);
        //var cancelBtn = HHGetSuggButton(cancelTxt);
        //cancelBtn.left = ro.ui.relX(5);

        //fullGreyBar

        //selectionView.add(Ti.UI.createView(ro.ui.properties.greyBorder));

        var selectWarning = Ti.UI.createLabel({
            text: "Please make your selection",
            color: ro.ui.theme.itemPriceColor,
            top: 0,
            height: 0,
            font: {
                fontSize: ro.ui.scaleFont(20, 0, 0),
                fontWeight: 'bold',
                fontFamily: ro.ui.fonts.titles
            },
            visible: false
        });
        selectionView.add(selectWarning);

        var buttonView = Ti.UI.createView({
            top: ro.ui.relY(5),
            height: Ti.UI.SIZE,
            width: Ti.UI.SIZE,
            layout: 'horizontal'
        });
        buttonView.add(submitBtn);

        selectionView.add(buttonView);		
        ordTypeWin.children[0].add(selectionView);
        ro.App.openWindows.push(ordTypeWin);
        ordTypeWin.open();    
	};
	var needsSpecificOrdType = function(){
        var OrdTypes = ro.app.Store.Menu.OnlineOptions.OrdTypes;        
        if (!OrdTypes || !OrdTypes.length) return false;
		//if(!SelectedOrdType || !SelectedOrdType.length) return false;
		if(!NeedsToCheckSpecificOrdType) return false;
        return hasMultipleOrdTypes();	
    };
    var hasMultipleOrdTypes = function () {
        var OrdTypes = ro.app.Store.Menu.OnlineOptions.OrdTypes;
        var IsDelivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
        var returnOrdTypes = [];
        Ti.API.info('OrdTypes.length: ' + OrdTypes.length);
        for (i = 0, iMax = OrdTypes.length; i < iMax; i++) {
            var ordType = OrdTypes[i];
            if (ordType.IsDelivery == IsDelivery) {
                returnOrdTypes.push(ordType);
            }
        }
        return returnOrdTypes.length > 1 ? returnOrdTypes : false;
    };
    var setNeedsToCheckSpecificOrdType = function (flag) {
        if (flag) {
            resetOrderObj();
        }
        NeedsToCheckSpecificOrdType = flag;
    };
    var addItemRow = function (itm1, itm2, needsOr) {        
        var thisRow = Ti.UI.createView({
            layout: 'horizontal',
            width: Ti.UI.SIZE,
            height: Ti.UI.SIZE,
            top: 0,
            isSelected: false,
            ordType: null,
            accessibilityHidden: true
        });
        thisRow.add(createBtns(itm1, needsOr));
        if (itm2) {
            if (needsOr) {
                var or = Ti.UI.createLabel(ro.combine(ro.ui.properties.ordTypeOrLbl, {
                    text: 'OR',
                    width: '6%'
                }));
                thisRow.add(or);
            }
            thisRow.add(createBtns(itm2, needsOr));
        }
        return thisRow;
    };
    var createBtns = function (itm, needsOr) {
        //var locImg = itm.OrderTypeCategory.toLowerCase() == "none" ? "pickup" : itm.OrderTypeCategory.toLowerCase();
        var imagePath = itm.ImageSource; //? itm.ImageSource : '/images/' + locImg + '-orderType.png';
        var imagePathActive = itm.ImageSourceActive; //? itm.ImageSourceActive : '/images/' + locImg + '-orderType-active.png';
        Ti.API.info("Image Path: " + imagePath);
        var theRow = Ti.UI.createView({
            width: needsOr ? '47%' : '50%',
            height: Ti.UI.SIZE,
            borderWidth: "0.9%",
            top: 0,
            isSelected: false,
            ordType: itm,
            accessibilityLabel: itm.OrdType,
            accessibilityHint: 'Button'
        });

        var imgHolder = Ti.UI.createView({
            top: ro.ui.relX(5),
            height: Ti.UI.SIZE,//'95%',           
            width: '95%',
            label: itm.Name,
            touchEnabled: false,
            //backgroundColor: 'green'
        });

        var rowImg = Ti.UI.createImageView({
            image: imagePath,
            //defaultImage: imagePath,
            label: itm.Name,
            left: ro.ui.relX(10),
            right: ro.ui.relX(10),
            height: Ti.UI.SIZE,
            //bottom: ro.ui.relY(75),
            touchEnabled: false,
            //backgroundColor: 'blue'
        });
        theRow.toggle = function (isSelected) {
            theRow.isSelected = isSelected;
            rowImg.image = isSelected ? imagePathActive : imagePath;
            //// Bubbling these properties over to the parent so the logic for alternative view with the Radio Buttons can still be utilized
            //theRow.parent.isSelected = isSelected;
            //if (isSelected) {
            //    theRow.parent.ordType = itm;
            //} else {
            //    theRow.parent.ordType = null;
            //}
        };
        
        if (Ti.App.OrderObj.OrdType == itm.OrdType) {
            SelectedOrdTypeObj = itm;
            theRow.toggle(true);
        };
        
        theRow.addEventListener('click', function (e) {            
            for (i = 0; i < theRow.parent.parent.children.length; i++) {
                for (j = 0; j < theRow.parent.parent.children[i].children.length; j++) {
                    if (theRow.parent.parent.children[i].children[j].isSelected) {
                        theRow.parent.parent.children[i].children[j].toggle(false);
                    }
                }
            }
            SelectedOrdTypeObj = itm;
            theRow.toggle(true);
        });
        imgHolder.add(rowImg);
        theRow.add(imgHolder);
        return theRow;
    };
    var checkOrdTypeImages = function (ordTypes) {       
        Ti.API.info("ordTypes.length: " + ordTypes.length);
        for (i = 0; i < ordTypes.length; i++) {            
            if ((ordTypes[i].ImageSource && ordTypes[i].ImageSource != "" && ordTypes[i].ImageSourceActive && ordTypes[i].ImageSourceActive != ""))
                continue;
            else {
                return false;
            }
        }
        return true;
    };
   return {
   	  setOrdType: setOrdType,
   	  IsDeliveryWithoutAddress: IsDeliveryWithoutAddress,
   	  setOrderObj: setOrderObj,
   	  
   	  needsSpecificOrdType: needsSpecificOrdType,
      promptForSpecificOrdType: promptForSpecificOrdType,
      hasMultipleOrdTypes: hasMultipleOrdTypes,
      setNeedsToCheckSpecificOrdType: setNeedsToCheckSpecificOrdType
   };
}();
module.exports = REV_ORD_TYPE;