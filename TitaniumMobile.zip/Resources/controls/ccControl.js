//exports.ccControl = function(){
   var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
   exports.nonDefaultCards = function(ro){
   	var returnLength = 0;
   	try{
   		var allCC = ro.db.getAllCustCC(Ti.App.Username);
   		returnLength = allCC?allCC.length:0;
   		if(getDefaultCard() !== -1){
   			returnLength-=1;
   		}
   	}
   	catch(ex){
   		Ti.API.debug('ccControl.nonDefaultCards()-Exception: ' + ex);
   	}
   	return returnLength<=0?0:returnLength;
   };
   exports.hasSavedCards = function(ro){
      return (ro.db.getAllCustCC(Ti.App.Username).length > 0)?true:false;
   };
   exports.getLastFour = function(cardNumber){
   	try{
   		var lstFour = cardNumber.substring(cardNumber.length - 4, cardNumber.length);
   		return lstFour;
   	}
   	catch(ex){
   		Ti.API.debug('ccControl.getLastFour()-Exception: ' + ex);
   		return '';
   	}
   };
   var processCardInfo = function(cardObj){
   		if(cardObj && cardObj.OLExpMonth && !isNaN(cardObj.OLExpMonth)){
	   		var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	   		cardObj.OLExpMonth = monthNames[parseInt(cardObj.OLExpMonth)-1];
	   	}
	   	return cardObj;
   };
   var delDefaultProperty = function(){
      Ti.App.Properties.removeProperty('defCardRow');
   };
   exports.delDefaultProperty = delDefaultProperty;
   var getDefaultCard = function(){
      return Ti.App.Properties.getInt('defCardRow', -1);
   };
   var getMonthText = function(m){     
      return monthNames[m-1];
   };
   exports.getMonthText = getMonthText;
   var getMonthNum = function(m){
      for(i=0; i< monthNames.length; i++){
         if(monthNames[i].toLowerCase() == m.toLowerCase()){
            return i+1;
         }
      }
   };
   exports.getMonthNum = getMonthNum;
   exports.getDefaultCard = getDefaultCard;
   var setDefaultCard = function(cardId){
      delDefaultProperty();
      Ti.App.Properties.setInt('defCardRow',cardId);
   };
   exports.setDefaultCard = setDefaultCard;
   var updateExistingCard = function(cardInfo, rowid, ro){
   	  
   	  var cardInfo = processCardInfo(cardInfo);
   	  
      return ro.db.updateCustCCRow(rowid, cardInfo);
   };
   exports.updateExistingCard = updateExistingCard;
   exports.checkUniqueCard = function(obj){
      //Check Duplicate
      var rs = ro.db.getAllCustCC(Ti.App.Username);
      for(i=0; i < rs.length; i++){
         if(rs[i].CCInfo && //null checks                                                            
            rs[i].CCInfo.OLCardNum ){
               if (obj.OLCardNum == rs[i].CCInfo.OLCardNum) return false;
            }
      }
      return true;
   };
   var saveNewCard = function(cardInfo, ro){     

   	var cardInfo = processCardInfo(cardInfo);     
   	 
      return ro.db.createCustCC(Ti.App.Username, cardInfo.ccName, cardInfo);
   };
   exports.saveNewCard = saveNewCard;
   var deleteCurrentCC = function(cardId, ro){
      if(getDefaultCard() == cardId){
         delDefaultProperty();
      }
      return ro.db.deleteCustCC(cardId);
   };
   exports.deleteCurrentCC = deleteCurrentCC;
   exports.createCardObj = function(ccObj){
      var cardInfo = {};
      cardInfo.OLCardNum = ccObj.ccNum;
      cardInfo.PayerName = ccObj.ccName;
      cardInfo.OLExpMonth = ccObj.expMonth;
      cardInfo.OLExpYear = ccObj.expYear;
      cardInfo.OLSecCode = ccObj.cvvNum;
      cardInfo.CardInfo = ccObj.ccType;
      if(ccObj.AVSStreetNum){
      	cardInfo.AVSStreetNum = ccObj.AVSStreetNum; 
      }
      if(ccObj.BillingStreet){
      	cardInfo.AVSStreetNum = ccObj.BillingStreet;
      }
      if(ccObj.AVSZipCode){
      	cardInfo.AVSZipCode = ccObj.AVSZipCode;
      }
      if(ccObj.BillingZip){
      	cardInfo.AVSZipCode = ccObj.BillingZip;
      }
      if(ccObj.payAmt){
      	cardInfo.PaymentAmt = ccObj.payAmt;
      	//cardInfo.PayAmt = ccObj.payAmt;
      }
      if(ccObj.ccSave){
         cardInfo.CreateCardToken = true;
      }else{
         cardInfo.CreateCardToken = false;
      }
      return cardInfo;
   };
   exports.updateDefaultCard = function(obj){      
      var rs = ro.db.getAllCustCC(Ti.App.Username);
      if(obj.TokenID && obj.TokenID != ''){
         for (i = 0; i < rs.length; i++){
            if(rs[i].CCInfo.TokenID && rs[i].CCInfo.TokenID != ''){
               if(obj.TokenID == rs[i].CCInfo.TokenID){
                  setDefaultCard(rs[i].rowid);
               }
            }
         }
      }else{
         for (i = 0; i < rs.length; i++){
            if(rs[i].CCInfo.OLCardNum && rs[i].CCInfo.OLCardNum != ''){
               if(obj.OLCardNum == rs[i].CCInfo.OLCardNum){
                  setDefaultCard(rs[i].rowid);
               }
            }
         }
      }      
   };
   exports.tokenUpdate = function(cardTokens, AddOrDelCards, ro) {
      Ti.API.info("Add OR Del Cards: " + AddOrDelCards);
      var rs = ro.db.getAllCustCC(Ti.App.Username);      
      for (x = 0; x < cardTokens.length; x++) {
          if (cardTokens[x].MaskedNumber && cardTokens[x].EXPMonth && cardTokens[x].EXPYear) { //null checks
              var foundFlag = false;
              for (i = 0; i < rs.length; i++) {                 
                 if (rs[i].CCInfo && //null checks                                                            
                      rs[i].CCInfo.OLCardNum &&
                      rs[i].CCInfo.OLExpMonth &&
                      rs[i].CCInfo.OLExpYear) {
                      if (rs[i].CCInfo.OLCardNum.slice(-4) == cardTokens[x].MaskedNumber.slice(-4) &&
                          rs[i].CCInfo.OLExpMonth == getMonthText(cardTokens[x].EXPMonth) &&
                          rs[i].CCInfo.OLExpYear == cardTokens[x].EXPYear) {
                             foundFlag = true;
                             rs[i].CCInfo.MaskedNumber = cardTokens[x].MaskedNumber;
                             rs[i].CCInfo.TokenID = cardTokens[x].TokenID;
                             if(cardTokens[x].hasOwnProperty('NetworkTransID')){
                                 rs[i].CCInfo.NetworkTransID = cardTokens[x].NetworkTransID;
                             }                             
                             rs[i].CCInfo.CardInfo = cardTokens[x].CardType;
                             updateExistingCard(rs[i].CCInfo, rs[i].rowid, ro);
                             rs[i].doNotDelete = true; // check if cards with tokens have been deleted
                             break;
                       }
                 }
              }
              if (!foundFlag && AddOrDelCards) {
                  var newCardObj = {};
                  newCardObj.OLCardNum = cardTokens[x].MaskedNumber;
                  newCardObj.MaskedNumber = cardTokens[x].MaskedNumber; // Keeping this consistent in case of switching the Card on File ON/OFF
                  newCardObj.PayerName = cardTokens[x].CardHolderName;
                  newCardObj.OLExpMonth = getMonthText(cardTokens[x].EXPMonth);
                  newCardObj.OLExpYear = cardTokens[x].EXPYear;
                  newCardObj.BillingZip = cardTokens[x].BillingZIP;
                  newCardObj.CardInfo = cardTokens[x].CardType;
                  newCardObj.TokenID = cardTokens[x].TokenID;
                  if(cardTokens[x].hasOwnProperty('NetworkTransID')){
                     newCardObj.NetworkTransID = cardTokens[x].NetworkTransID;
                  }
                  saveNewCard(newCardObj, ro);
              }
          }
      }
      if(AddOrDelCards){
        //Secound round to delete cards which were deleted from website
        Ti.API.info("Result Set before Delete: " + JSON.stringify(rs));
        for (i = 0; i < rs.length; i++) {
            if (rs[i].CCInfo.hasOwnProperty('TokenID') && rs[i].CCInfo.TokenID != null && !rs[i].hasOwnProperty('doNotDelete')) {
                deleteCurrentCC(rs[i].rowid, ro);
            }
        }
      }
   };
   //return ro;
//};
