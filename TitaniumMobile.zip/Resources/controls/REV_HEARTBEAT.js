var REV_HEARTBEAT = function(){
   var IS_ANDROID = true,
   checkHeartbeat = function(isStoreOnline, threshold, hdr, msg){
   	  Ti.API.debug('isStoreOnline: ' + isStoreOnline);
   	  Ti.API.debug('threshold: ' + threshold);
   	  Ti.API.debug('hdr: ' + hdr);
   	  Ti.API.debug('msg: ' + msg);
   	  if(!isStoreOnline && (parseInt(threshold, 10) > 0)){
   	  	 var finalHdr = hdr && hdr.length ? hdr : 'Error: ',
	   	 finalMsg = msg && msg.length ? msg : 'Store is offline';
   	  	 if(false && IS_ANDROID){
   	  	 	ro.ui.alert(finalHdr, finalMsg);
   	  	 }
   	  	 else{
   	  	     
   	  	     ro.ui.popup(finalHdr, ['OK'], finalMsg, function(e) {
                    
                }, function(){
                    
                });
   	  	     
	   	  	 /*var a = Ti.UI.createAlertDialog();
	   	  	 a.title = finalHdr;
	      	 a.message = finalMsg;
	      	 a.buttonNames = ['OK'];
	      	 a.show();*/
	      	 //a.cancel = 1;
	     }
      	 return false;
   	  }
   	  else{
   	  	return true;
   	  }
   },
   checkOfflineOrdType = function(isDeliv, OFFLINE_ORDTYPE, hdr, msg){
   	  Ti.API.debug('arguments: ' + JSON.stringify(arguments));
   	  var returnVal = true;
   	  var defaultHdr = '', defaultMsg = '';
   	  if((parseInt(OFFLINE_ORDTYPE, 10) == 1) && !isDeliv){
   	  	 returnVal = false;
   	  	 defaultHdr = 'No Pickup';
   	  	 defaultMsg = 'Not Accepting pickup orders';
   	  }
   	  if((parseInt(OFFLINE_ORDTYPE, 10) == 2) && isDeliv){
   	  	 returnVal = false;
   	  	 defaultHdr = 'No Delivery';
   	  	 defaultMsg = 'Not Accepting delivery orders';
   	  }
   	  if((parseInt(OFFLINE_ORDTYPE, 10) == 3)){
   	  	 returnVal = false;
   	  	 defaultHdr = 'Error ';
   	  	 defaultMsg = 'Not currently accepting orders';
   	  }
   	  
   	  if(!returnVal){
   	  	 var finalHdr = hdr && hdr.length ? hdr : defaultHdr,
	   	 finalMsg = msg && msg.length ? msg : defaultMsg;
   	  	 if(false && IS_ANDROID){
   	  	 	ro.ui.alert(finalHdr, finalMsg);
   	  	 }
   	  	 else{
   	  	     
   	  	     ro.ui.popup(finalHdr, ['OK'], finalMsg, function(e) {
                    
                }, function(){
                    
                });
	   	  	/*var a = Ti.UI.createAlertDialog();
	   	  	a.title = finalHdr;
	      	a.message = finalMsg;
	      	a.buttonNames = ['OK'];
	      	a.show();*/
	     }
   	  	 return false;
   	  }
   	  else{
   	  	 return true;
   	  }
   	  
   };
   return {
   	  checkHeartbeat: checkHeartbeat,
   	  checkOfflineOrdType: checkOfflineOrdType
   };
}();
module.exports = REV_HEARTBEAT;