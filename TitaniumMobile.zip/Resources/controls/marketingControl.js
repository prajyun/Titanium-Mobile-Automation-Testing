var marketingControl = function () {
    var mktConfig, cust;

    var showMktMsg = function () {
        mktConfig = JSON.parse(Ti.App.Properties.getString('mktConfig', '{}'));
        cust = JSON.parse(Ti.App.Properties.getString('Customer', '{}'));
        if(cust.hasOwnProperty('MktStatus') && cust.MktStatus == 1){
            return false;
        }
        if(mktConfig){
            if(mktConfig.AllStores){
                return true;
            }
            if(ro.app.Store.SalesForceID && ro.app.Store.SalesForceID !='' && mktConfig.Stores && mktConfig.Stores.length){
                for(i=0; i < mktConfig.Stores.length; i++){
                    if(ro.app.Store.SalesForceID == mktConfig.Stores[i]){
                        return true;
                    }
                } 
            }
        }       
        return false;
    };

    var setMarketingStatus = function(val){        
        var test = Ti.App.OrderObj;
        if(!test.Customer){
            test.Customer = {};
        }
        test.Customer.MktStatus = val;
        Ti.App.OrderObj = test;
        test = null;
    };

    var getMarketingStatus = function(){
        if(Ti.App.OrderObj.Customer && Ti.App.OrderObj.Customer.hasOwnProperty('MktStatus')){
            return Ti.App.OrderObj.Customer.MktStatus;
        }else{
            return 0;
        }
    };
    
    var getMarketingView = function(){
        
           var mktView = Ti.UI.createView({
                height: Ti.UI.FILL,
                width: ro.ui.properties.wideViewWidth,
                layout: 'horizontal',
                height: Ti.UI.SIZE,
                top: ro.ui.relX(10),
                bottom: ro.ui.relX(10)
            });
            var currentStatus = getMarketingStatus();
            var isChecked = (currentStatus === 0 || currentStatus === 2) ? false : true;
            if(!isChecked){
                //if it is unchecked by default then set marketing status as 2
                setMarketingStatus(2);
            }
            var lblColor = ro.ui.theme.privacyPolicyTxtLbl;
            var mktCheckbox = Ti.UI.createView({
                    top: ro.ui.relX(10),
                    width: ro.ui.relX(20),
                    height: ro.ui.relY(20),
                    borderRadius: ro.ui.relX(10),
                    theValue: isChecked,
                    borderColor: lblColor,
                    borderWidth: ro.ui.relX(2),
                    backgroundImage: isChecked ? "/images/switch_on.png" : null
                }),
                mktLbl = Ti.UI.createLabel({
                    font: {
                        fontSize: ro.ui.scaleFont(15),
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.policyText
                    },
                    height: Ti.UI.SIZE,
                    width: Ti.UI.FILL,
                    color: lblColor,
                    left: ro.ui.relX(10),
                    top: ro.ui.relX(5)
                });
            mktCheckbox.addEventListener('click', function() {
                toggleCheckBox();
            });
            
            var toggleCheckBox = function(){
                mktCheckbox.theValue = !mktCheckbox.theValue;
                mktCheckbox.backgroundImage = mktCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_onFAKE.png";
                if(mktCheckbox.theValue){
                    setMarketingStatus(1);
                }else{
                    setMarketingStatus(2);
                }
            };
            var raw = mktConfig.EnrollmentMsg ? mktConfig.EnrollmentMsg : '';
            if(ro.app.Store.SalesForceID && ro.app.Store.SalesForceID !='' && mktConfig.StoresConfig && mktConfig.StoresConfig.length){
                for(var x = 0; x < mktConfig.StoresConfig.length; x++){
                    if(mktConfig.StoresConfig[x].AboveStoreID == ro.app.Store.SalesForceID){
                        if(mktConfig.StoresConfig[x].EnrollmentMsg && mktConfig.StoresConfig[x].EnrollmentMsg != ''){
                            raw = mktConfig.StoresConfig[x].EnrollmentMsg;
                        }
                        break;
                    }
                }                
            }           
            raw = raw.replace("target=\"_blank\" ", "");
            raw = raw.replace("<p>", "");
            raw = raw.replace("</p>", "");
            var tagStart = raw.indexOf('<');
            var tagEnd = raw.indexOf('>');
            var endTagStart = raw.indexOf('</a>');
            var linkStart = raw.indexOf('\"');
            var linkEnd = raw.lastIndexOf('\"');
            if(tagStart == -1 || tagEnd == -1 || endTagStart == -1 || linkStart == -1 || linkEnd == -1){
                mktLbl.text = raw;
                mktLbl.addEventListener('click', function(e) {
                    toggleCheckBox();
                });
            }else{
                var htmlLink = raw.substring(linkStart+1, linkEnd);
                var plainText = raw.substring(0, tagStart-1) + ' ' + raw.substring(tagEnd+1, endTagStart);

                var string = Ti.UI.createAttributedString({
                    text: plainText,
                    attributes: [{
                        type: Titanium.UI.ATTRIBUTE_LINK,
                        value: htmlLink,
                        range: [tagStart, endTagStart- tagEnd -1]
                        }, {
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: '#eb0029',
                        range: [tagStart, endTagStart - tagEnd -1]
                    }]
                });
                mktLbl.attributedString = string;
            }            
            
            var leftVw, rightVw;
            leftVw = Ti.UI.createView({
                top: 0,
                left: 0,
                width: ro.ui.relX(40),
                height: Ti.UI.SIZE
            });

            rightVw = Ti.UI.createView({
                top: 0,
                left: 0,
                width: ro.ui.relX(274),
                layout: 'vertical',
                height: Ti.UI.SIZE
            });

            leftVw.add(mktCheckbox);
            rightVw.add(mktLbl);
            
            mktView.add(leftVw);
            mktView.add(rightVw);
            
            var fullView = Ti.UI.createView({
                height: Ti.UI.SIZE,//ro.ui.relY(120),
                layout: 'vertical',
                top: ro.ui.relY(15),
                width: ro.ui.displayCaps.platformWidth,
                backgroundColor: '#F2F2F2'
                //width: ro.ui.properties.wideViewWidth
            });
            fullView.add(mktView);
            return fullView;
    };

    return {
        showMktMsg: showMktMsg,
        getMarketingView: getMarketingView
    };
}();
module.exports = marketingControl;