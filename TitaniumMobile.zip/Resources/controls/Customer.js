var REV_CUSTOMER = function(){
   var getCustReq = function(LtyStoreID){
      /*var cst = JSON.parse(Ti.App.Properties.getString('Customer'));
      if(!cst){
         cst = {};
      }*/
      var profileInfo = ro.db.getCustObj(Ti.App.Username);
      var req = {};
      req.UserName = Ti.App.Username;
      req.Pass = Ti.App.Password;
      req.FName = profileInfo['FirstName'];
      req.LName = profileInfo['LastName'];
      req.Title = profileInfo['Title'];
      req.Phone = profileInfo['Phone'];
      req.Ext = profileInfo['Ext'];
      req.RevKey = 'test';
      req.LtyStoreID = profileInfo['LtyStoreID'];
      
      if(LtyStoreID){
      	req.LtyStoreID = LtyStoreID;
      }

      if(!isNaN(profileInfo['EClubOptIn'])){
         req.EClubOptIn = profileInfo['EClubOptIn'];
      }
      if(!isNaN(profileInfo['LtyOptIn'])){
         req.LtyOptIn = profileInfo['LtyOptIn'];
      }
      return req;
   },
   saveCust = function(reqCust){
      //Ti.API.debug('rs: ' + JSON.stringify(rs));
      
      var customr = JSON.parse(Ti.App.Properties.getString('Customer'));
      if(!customr){
         customr = {};
      }
      customr.Ext = reqCust.Ext;
      customr.Title = reqCust.Title;
      customr.FirstName = reqCust.FName;
      customr.LastName = reqCust.LName;
      customr.Phone = reqCust.Phone;
      
      if(!isNaN(reqCust.EClubOptIn)){
         customr.EClubOptIn = reqCust.EClubOptIn;
      }
      if(!isNaN(reqCust.LtyOptIn)){
         customr.LtyOptIn = reqCust.LtyOptIn;
      }
      
      if(!isNaN(reqCust.LtyStoreID)){
      	 customr.LtyStoreID = reqCust.LtyStoreID;
      }
      Ti.App.Properties.setString('Customer', JSON.stringify(customr));
      Ti.API.debug('customr: ' + JSON.stringify(customr));
      ro.db.updateCustomerObj(Ti.App.Username, customr);
   };
   var changeEClubOptIn = function(ecluboptin, suppressMsgBln, _cb){
      var req = getCustReq();
      req.EClubOptIn = ecluboptin;//2 to decline rewards, 1 to accept, 0 unasked...
      
      REV_API.UpdateCustomer(req, function(){
         saveCust(req);
         //ro.ui.settingsShowNext({showing:mainView.hid});
         _cb();
      }, suppressMsgBln);
   };
   var changeLtyOptIn = function(ltyoptin, suppressMsgBln, _cb, LtyStoreID){
      var req = getCustReq(LtyStoreID);
      req.LtyOptIn = ltyoptin;//2 to decline rewards, 1 to accept, 0 unasked...
      
      REV_API.UpdateCustomer(req, function(notSuccesful){
      	if(notSuccesful){
      		_cb(true);
      	}
      	else{
      		saveCust(req);
         	_cb();
      	}
         
      }, suppressMsgBln);
   };
   var getCurrentLoc = function(_callbackSuccess, _callbackFailure){
   	//return;
   	  try{
   	  	 var req = {};
		 req.RevKey = 'test';
		 req.CompressResponse = false;
	     
	     if(Ti.Geolocation.locationServicesEnabled == false){
		    if(Ti.Platform.version[0] >= 6){
		       Ti.Geolocation.requestLocationPermissions(null, function(e){
		          if(e && e.success){
		             //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
                     Ti.Geolocation.getCurrentPosition(function(e){
	                     if(!e.success || e.error){
	                        ro.ui.hideLoader();
	                        _callbackFailure(req);
	                        return;
	                     }
	                     if(e && e.coords && e.coords.longitude){
	                     	req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
	                     }
	                     if(e && e.coords && e.coords.latitude){
	                     	req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
	                     }
	                     
	                     _callbackSuccess(req);
                     });
		          }
		          else{
		             _callbackFailure(req);
                     ro.ui.hideLoader();
		          }
		       });
		    }
		    else{
		       _callbackFailure(req);
               ro.ui.hideLoader();
		    }
		 }
		 else{
		    //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
			Ti.Geolocation.getCurrentPosition(function(e){
			   if(!e.success || e.error){
			      
				  ro.ui.hideLoader();
				  _callbackFailure(req);
				  return;
			   }
			   if(e && e.coords && e.coords.longitude){
             	  req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
               }
               if(e && e.coords && e.coords.latitude){
             	  req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
               }
			   _callbackSuccess(req);
			});
		 }
	  }
	  catch(ex){
	  	Ti.API.debug('REV_CUSTOMER.getCurrentLoc() - Exception: ' + ex);
	     _callbackFailure(req);
	  }
   };
   return {
      changeEClubOptIn: changeEClubOptIn,
      getCustReq: getCustReq,
      saveCust: saveCust,
      changeLtyOptIn: changeLtyOptIn,
      getCurrentLoc: getCurrentLoc
   };
}();
module.exports = REV_CUSTOMER;