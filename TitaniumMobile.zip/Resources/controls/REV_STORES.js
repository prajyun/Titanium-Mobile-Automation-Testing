var REV_STORES = function(){
   var rev_stores = function(ro){
   	   
	   var IS_ANDROID = true,
	   cfg = null,
	   currStoreId = null,
	   setStore = function(store){
	   	  if(!store){
	   	  	 store = getDefaultStore();
	   	  }
	   	  
	   	  var test = ro.app;
	   	  test.Store = null;
	   	  test.Store = store;
		  ro.app = test;
		  test = null;
	   },
	   clearStore = function(){
	   	  var test = ro.app;
	   	  ////Ti.API.debug('ro');
	  	  test.Store = null;
	  	  ro.app = test;
	  	  test = null;
	  	 // //Ti.API.debug('ro2');
	   },
	   setDefaultStore = function(store, setRoAppStore){
		  Ti.App.Properties.setString('DefaultStore', JSON.stringify(store));
		  
		  if(setRoAppStore)
		     setStore(store);
	   },
	   getDefaultStore = function(){
	   	  return JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}'));
	   },
	   clearDefaultStore = function(clearRoAppStore){
	   	  if(Ti.App.Properties.hasProperty('DefaultStore')){
	   	  	 Ti.App.Properties.removeProperty('DefaultStore');
	   	  }
	   	  
	   	  if(clearRoAppStore)
	   	  	 clearStore();
	   },
	   didStoreChange = function(newStoreId, _cb){
	   	 var storeChanged = false;
	   	 var newStore = false;
	   	 if(ro.app.Store){
	   	 	Ti.API.debug('ro.app.Store.ID: ' + ro.app.Store.ID);
	   	 	if(parseInt(ro.app.Store.ID,10) != parseInt(newStoreId, 10)){
	   	 		storeChanged = true;
	   	 	}
	   	 }
	   	 else{
	   	 	newStore = true;
	   	 }
	   	 Ti.API.debug('NEWSTOREID: ' + newStoreId);
	   	 Ti.API.debug('storeChanged: ' + storeChanged);
	   	 
	   	 if(_cb){
	   	 	_cb(storeChanged, newStore);
	   	 }
	   },
	   setChosenStoreId = function(id){
	   	  currStoreId = id;
	   	  Ti.API.debug('currStoreId: ' + currStoreId);
	   	  //Ti.App.Properties.setString('currStore', id);
	   	  /*Ti.App.Properties.setString('currStore', JSON.stringify({
	   	  	id:id
	   	  	
	   	  }))*/
	   }, 
	   willStoreChange = function(newId){
	   	  var returnVal = false;
	   	  //var currId = Ti.App.Properties.getString('currStore', '');
	   	  var currId = currStoreId;		   
		  if (parseInt(newId, 10) != parseInt(currId, 10)) {
			REV_ORD_TYPE.setNeedsToCheckSpecificOrdType(true);
	   		if(currId && Ti.App.OrderObj && ((Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length) || (Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length))){	   	  	 
	   			return true;
	   	    }
	   	  }
	   	  Ti.API.debug('willStoreChange(): ' + returnVal);
	   	  return returnVal;
	   },
	   promptForChange = function(_cb){
	       
	      ro.ui.popup('Change Store', ['Cancel', 'OK'], 'Items in your cart will be cleared when you choose a different store location. Would you like to continue with this new store?', function(e) {
                _cb();
                ro.ui.hideLoader();
            }, function(){
                ro.ui.hideLoader();
            });
	       ro.ui.hideLoader();
	   	  /*var a = Ti.UI.createAlertDialog();
	      a.title = 'Change Store';
	      a.message = 'Items in your cart will be cleared when you choose a different store location. Would you like to continue with this new store?';
	      a.buttonNames = ['Yes', 'No'];
	      a.cancel = 1;
	      //a.itmIndex = e.source.itmIndex;
	      a.addEventListener('click', function(e){
	      	Ti.API.debug('e.cancel: ' + e.cancel);
		    Ti.API.debug('e.source.cancel: ' + e.source.cancel);
		    Ti.API.debug('e.index: ' + e.index);
		    if (e.index === e.source.cancel){
		       Ti.API.debug('The cancel button was clicked');
		       ro.ui.hideLoader();
		    }
		    else{
		    	_cb();
		    }
		  });
	      a.show();*/
	   };
	   return {
	   	  setStore: setStore,
	   	  clearStore: clearStore,
	   	  setDefaultStore: setDefaultStore,
	   	  getDefaultStore: getDefaultStore,
	   	  clearDefaultStore: clearDefaultStore,
	   	  didStoreChange: didStoreChange, 
	   	  promptForChange: promptForChange,
	   	  setChosenStoreId: setChosenStoreId,
	   	  willStoreChange: willStoreChange
	   	  
	   };
	};
	return {
		rev_stores: rev_stores
	};
}();
module.exports = REV_STORES;