var TABCTRL = function(){
	var tabctrl = function(ro){
	   var tabBar = {};
	   var tbWidth = ro.ui.relX(100);
	   var numTabs = 2;
	   tabBar.createTab = function(_name, _cb, _on, _id, newWidth, newNumTabs){
	   	  tbWidth = newWidth ? newWidth : ro.ui.relX(150);
	   	  numTabs = newNumTabs ? newNumTabs : 2;
	      var bgOn_color = ro.ui.theme.toptbSelBg;
	      var bgOff_color = ro.ui.theme.toptbBg;
	      var view = Ti.UI.createView({
	         width:tbWidth,
	         id:_id,
	         name:_name,
	         backgroundColor:(_on) ? bgOn_color:bgOff_color,
	         borderColor:(_on) ? ro.ui.theme.toptbSelBg : ro.ui.theme.toptbBrd,
	         borderWidth:ro.ui.relX(2),
	         borderRadius:ro.ui.relY(17.5),
	         //left:ro.ui.relX(15),
	         focusable:true
	      }),
	      
	      on_color = ro.ui.theme.toptbSelTxt,
	      off_color = ro.ui.theme.toptbTxt,
	      dimension = ro.ui.relY(35),
	      
	      lbl = Ti.UI.createLabel({
	         text:_name,
	         height:dimension,
	         width:tbWidth,
	         textAlign:'center',
	         id:_id,
	         font:{
	            fontSize:ro.isiOS ? ro.ui.scaleFont(17) : ro.ui.scaleFont(18, 120, 25),
	            //fontWeight:'bold',
	            fontFamily:_on ? ro.ui.fonts.tabs.on : ro.ui.fonts.tabs.off
	         },
	         color:(_on) ? on_color : off_color
	      });
	      view.ison = _on || false;
			function changeLbl(tab){
				var lbl = Ti.UI.createLabel({
		         text:tab.name,
		         height:dimension,
		         width:tbWidth,
		         textAlign:'center',
		         id:tab.id,
		         font:{
		            fontSize:ro.isiOS ? ro.ui.scaleFont(17) : ro.ui.scaleFont(18, 120, 25),
		            //fontWeight:'bold',
		            fontFamily:tab.ison ? ro.ui.fonts.tabs.on : ro.ui.fonts.tabs.off
		         },
		         color:(tab.ison) ? on_color : off_color
		      });
				
				tab.removeAllChildren();
				tab.add(lbl);
			}
			//changeLbl(view);
	      view.add(lbl);
	      view.addEventListener('click',_cb);
	
	      view.toggle = function(){
	         view.ison = !view.ison;
	         changeLbl(view);
	         //view.children[0].color =(view.ison) ? on_color : off_color;
	         view.backgroundColor =(view.ison) ? bgOn_color : bgOff_color;
	         view.borderColor =(view.ison) ? ro.ui.theme.toptbSelBg : ro.ui.theme.toptbBrd;
	         
	      };
	      return view;
	   };
	   tabBar.getTabView = function(tabs, newWidth, newTabNum){
	   	  tabNum = newTabNum ? newTabNum : 2;
	   	  tbWidth = newWidth ? newWidth : ro.ui.relX(150);
	      var tabView = Ti.UI.createView({
	         top:ro.ui.relY(7.5),
	         height:ro.ui.relY(35),
	         width:Ti.UI.SIZE
	      });
	
	      for(var i=0; i<tabs.length; i++){
	         tabs[i].left = ((tbWidth+ro.ui.relX(8)) * i);
	         tabView.add(tabs[i]);
	      }
	      return tabView;
	   };
	   tabBar.printStackSizes = function(){
	      Ti.API.debug('Order Type Stack size: ' + ro.ui.currentOrdTypeStkSize());
	      Ti.API.debug('Setting Stack size: ' + ro.ui.settingsStkSize());
	      Ti.API.debug('Cart Stack size: ' + ro.ui.currentCartStkSize());
	   };
	   tabBar.clearOtherStacks = function(e){
	   	
	   	Ti.API.debug('_args clearOtherStacks(): ' + JSON.stringify(e));
	   	Ti.API.debug('e.isHC: ' + e.isHC);
	   	try{
		      switch(e.oldIdx){
		         case 0:
		            /*if(ro.ui.getOrdTypeStkState() == 'grpsItems'){
		               ro.ui.clrOrdTypeStkChildren();
		            }
		            else{
		               ro.ui.remOrdTypeStkChildren();
		            }*/
		            ro.ui.clrOrdTypeStkChildren();
		            break;
		         case 1:
		            if(e.isGuest){
		               ro.ui.remCartStkChildren();
		            }
		            else if(e.isHC){
		            	   ro.ui.remRewardsStkChildren();
		            }
		            else{
		                ro.ui.remSettingsStkChildren();
		            }
		            break;
		         case 2:
		         	if(e.isHC){
		         		//ro.ui.remRewardsStkChildren();
		         		ro.ui.remSettingsStkChildren();
		         	}
		         	else{
		            	ro.ui.remCartStkChildren();
		            }
		            break;
		         case 3:
		         	ro.ui.remCartStkChildren();
		         	break;
		      }
		   }
		   catch(ex){
		   	Ti.API.debug('clearStacks - ex: ' + ex);
		   }
	   };
	   
	   ro.tabBar = tabBar;
	   //return ro;
	};
	return {
		tabctrl:tabctrl
	};
}();
module.exports = TABCTRL;