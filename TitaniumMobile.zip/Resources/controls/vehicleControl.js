var vehicleControl = function () {
    var custInfoObj = {};
    var isGuest = false;
    if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
        isGuest = true;
    }
    if (!isGuest) {
        custInfoObj = JSON.parse(Ti.App.Properties.getString('Customer'));
    }

    var getButton = function (btnTxt) {        
        var submitBtn = ro.layout.getFilledButton(btnTxt);
        //submitBtn.top = ro.ui.relY(40);
        submitBtn.top = ro.ui.relY(10);
        submitBtn.bottom = ro.ui.relY(10);
        return submitBtn;
    };
    var getSecondaryButton = function (btnTxt) {
        var submitBtn = ro.layout.getSecondaryButton(btnTxt);
        //submitBtn.top = ro.ui.relY(40);
        submitBtn.top = ro.ui.relY(10);
        submitBtn.bottom = ro.ui.relY(10);
        return submitBtn;
    };
    var silentSave = function (obj, _cb) {        
        var req = {};
        req.Name = obj.vehicleName;
        req.Make = obj.make;
        req.Model = obj.model;
        req.Color = obj.color;
        req.Features = obj.features;
        req.Email = Ti.App.Username;        
        ro.dataservice.postAPI(req, "AddVehicle", function (response) {
            Ti.API.info("Silent Add Vehicle Response: " + JSON.stringify(response));
            if (response.Success) {               
                req.VehicleID = response.VehicleID;
                if (!custInfoObj.Vehicles) custInfoObj.Vehicles = [];
                custInfoObj.Vehicles.push(req);  
                
                Ti.App.Properties.setString('Customer', JSON.stringify(custInfoObj));
                Ti.API.info("Silent Saved Cust Obj: " + JSON.stringify(custInfoObj));
                if (_cb) _cb(response.VehicleID);
            } else {
                Ti.API.info("Silent Vehicle Error ");
                if (_cb) _cb(0);
            }
        });
    };
    var openForm = function (fromCart, vhclObj, _cb) {
        Ti.API.info("Vehicle Obj: " + JSON.stringify(vhclObj));
        var isEdit = false;
        if (vhclObj) isEdit = true;
        var curbsideForm = layoutMenuHelper.modalSuggWin();
        curbsideForm.addEventListener('close', function () {
            ro.App.openWindows.pop();
            curbsideForm = null;
        });
        var vhclBox = Ti.UI.createScrollView({
            width: ro.ui.properties.wideViewWidth,
            height: Ti.UI.SIZE,
            layout: 'vertical',
            top: ro.ui.relY(15)
        });
        
        var vhclForm = require('formControls/vehicleForm');
        var carForm = ro.forms.createForm({
            style: ro.forms.STYLE_LABEL,
            fields: vhclForm.getVhclForm({ formType: isGuest ? 3 : 1 }),
            settings: ro.ui.properties.myAccountView
        });
        if (isEdit) {
            carForm.setFields(vhclObj);
        }
        carForm.top = ro.ui.relY(5);
        carForm.bottom = ro.ui.relY(5);
        carForm.height = Ti.UI.SIZE;
        vhclBox.add(carForm);

        var headerView = Ti.UI.createView({
            width: Ti.UI.FILL,
            height: Ti.UI.SIZE
        });

        var tblHdr = Ti.UI.createLabel({
            text: isEdit ? 'Edit Vehicle Information' : 'Add New Vehicle',
            textAlign: 'center',
            top: ro.ui.relY(15),
            font: {
                fontSize: ro.ui.scaleFont(35, 0, 0),
                fontFamily: ro.ui.fonts.titles
            },
            height: Ti.UI.SIZE,
            width: Ti.UI.FILL,
            color: ro.ui.theme.backgroundpngTxt
        });

        var close = Ti.UI.createView({
            backgroundImage: '/images/clearBtn.png',
            height: ro.ui.relY(25),
            width: ro.ui.relX(25),
            right: ro.ui.relX(10)
        });
        close.addEventListener('click', function () {
            curbsideForm.close();
        });

        headerView.add(tblHdr);
        headerView.add(close);

        var formView = Ti.UI.createScrollView({
            backgroundColor: 'white',
            layout: 'vertical',
            top: ro.ui.properties.topAfterNavbar + ro.ui.relY(15),
            left: ro.ui.relX(10),
            right: ro.ui.relX(10),
            height: Ti.UI.SIZE,
            borderRadius: ro.ui.relX(10),
            zIndex: 6,
            elevation: 10,
            translationZ: 10
        });
        formView.add(headerView);
        formView.add(vhclBox);

        var saveBtn = getButton(isEdit ? "Update" : "Save");
        var delBtn = getButton("Delete");

        saveBtn.addEventListener('click', function () {
            var vhclInfo = ro.forms.getValues(carForm);
            var validate = require("validation/vehicleValidation");
            var vehicleSuccess = validate.vehicleValidate(vhclInfo);
            if (vehicleSuccess.value) {
                Ti.API.info(JSON.stringify(vhclInfo));
                if (isGuest) {
                    Ti.App.Properties.setString('guestVhclInfo', JSON.stringify(vhclInfo));
                    Ti.API.info("vhclInfo Edited: " + JSON.stringify(vhclInfo));
                    ro.ui.alert('Success', 'Vehicle Saved');
                    if (_cb) _cb();
                    curbsideForm.close();
                } else {
                    //Check for duplicates
                    if (!isEdit && custInfoObj.Vehicles && custInfoObj.Vehicles.length) {
                        for (i = 0; i < custInfoObj.Vehicles.length; i++) {
                            if (vhclInfo.vehicleName.toLowerCase() == custInfoObj.Vehicles[i].Name.toLowerCase()) {
                                ro.ui.alert('Error', 'Vehicle name already exists');
                                ro.ui.hideLoader();
                                curbsideForm.close();
                                return;
                            }
                        }
                    }
                    var req = {};
                    req.Name = vhclInfo.vehicleName;
                    req.Make = vhclInfo.make;
                    req.Model = vhclInfo.model;
                    req.Color = vhclInfo.color;
                    req.Features = vhclInfo.features;
                    req.Email = Ti.App.Username;
                    if (isEdit) {
                        req.VehicleID = vhclObj.VehicleID;
                    }
                    curbsideForm.close();
                    ro.ui.showLoader();
                    ro.dataservice.postAPI(req, "AddVehicle", function (response) {
                        Ti.API.info("Add/Edit Vehicle Response: " + JSON.stringify(response));
                        if (response.Success) {
                            if (!isEdit) {
                                req.VehicleID = response.VehicleID;
                                custInfoObj.Vehicles.push(req);
                            } else {
                                for (i = 0; i < custInfoObj.Vehicles.length; i++) {
                                    if (custInfoObj.Vehicles[i].VehicleID == req.VehicleID) {
                                        Ti.API.info("Editing Vehicle Info");
                                        custInfoObj.Vehicles[i].Name = req.Name;
                                        custInfoObj.Vehicles[i].Make = req.Make;
                                        custInfoObj.Vehicles[i].Model = req.Model;
                                        custInfoObj.Vehicles[i].Color = req.Color;
                                        custInfoObj.Vehicles[i].Features = req.Features;
                                        break;
                                    }
                                }
                            }
                            Ti.App.Properties.setString('Customer', JSON.stringify(custInfoObj));
                            Ti.API.info("Saved Cust Obj: " + JSON.stringify(custInfoObj));
                            ro.ui.alert('Success', 'Vehicle Saved');
                            if (_cb) _cb();
                            ro.ui.hideLoader();                            

                        } else {
                            ro.ui.alert("Add/Edit Vehicle Error : ", "Could not " + (isEdit ? "Edit" : "Add") + " Vehicle");
                            ro.ui.hideLoader();                            
                        }
                    });
                }

            } else {
                ro.ui.alert('Error: ', vehicleSuccess.issues[0]);
                curbsideForm.close();
            }
        });

        delBtn.addEventListener('click', function () {
            var req = {};
            req.VehicleID = vhclObj.VehicleID;
            curbsideForm.close();
            ro.ui.showLoader();
            ro.dataservice.postAPI(req, "DeleteVehicle", function (response) {
                Ti.API.info("Delete Vehicle Response: " + JSON.stringify(response));
                if (response.Success) {
                    for (i = 0; i < custInfoObj.Vehicles.length; i++) {
                        if (custInfoObj.Vehicles[i].VehicleID == req.VehicleID) {
                            custInfoObj.Vehicles.splice(i, 1);
                            Ti.App.Properties.setString('Customer', JSON.stringify(custInfoObj));
                            Ti.API.info("Saved Cust Obj: " + JSON.stringify(custInfoObj.Vehicles));
                            break;
                        }
                    }
                    ro.ui.alert('Success', 'Vehicle Deleted');
                    if (_cb) _cb();
                    ro.ui.hideLoader();                    
                } else {
                    ro.ui.alert('Error', 'Could not Delete Vehicle');
                    ro.ui.hideLoader();                    
                }
            });
        });

        var buttonHolder = Ti.UI.createView({
            height: Ti.UI.SIZE,
            width: Ti.UI.SIZE,
            layout: 'horizontal'
        });
        buttonHolder.add(saveBtn);
        if (isEdit && !fromCart) {
            delBtn.left = ro.ui.relX(10);
            buttonHolder.add(delBtn);
        }
        formView.add(buttonHolder);
        curbsideForm.children[0].add(formView);
        ro.App.openWindows.push(curbsideForm);
        curbsideForm.open();
    };

    return {
        openForm: openForm,
        getSecondaryButton: getSecondaryButton,
        silentSave: silentSave
    };
}();
module.exports = vehicleControl;