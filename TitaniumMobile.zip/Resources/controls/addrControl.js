//var addrControl = (function(){
   exports.formAddrObj = function(newAddressObj){
      var AddressObj = {};
      AddressObj.StNum = newAddressObj['stnum'];
      AddressObj.St = newAddressObj['stname'];
      //AddressObj.Street = newAddressObj['stname'];
      AddressObj.City = newAddressObj['city'];
      AddressObj.State = newAddressObj['state'];
      AddressObj.Zip = newAddressObj['zip'];
      AddressObj.Label = newAddressObj['label'];
      AddressObj.AddrTypeName = newAddressObj['addrtype'];

      if(newAddressObj['unitnum'] !== "N/A")
         AddressObj.SUD = newAddressObj['unitnum'];
         //AddressObj.SUD = newAddressObj['unitnum'];

      if(newAddressObj['unitname'] !== "N/A")
         AddressObj.CustAddrTypeName = newAddressObj['unitname'];

      useThisAddress(AddressObj);

      return AddressObj;
   };

   exports.contactDeleteServer = function(req, index, rs){
      var response, Obj;
       var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
       if (savedTokenObj && savedTokenObj.token) {
           req.CustomerDevice = {};
           req.CustomerDevice.DeviceID = Ti.Platform.id;
           req.CustomerDevice.DeviceToken = savedTokenObj.token;
           req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
       }
      ro.dataservice.post(req, 'DelCustomerAddress', function(response){
      	Ti.API.debug('response: ' + JSON.stringify(response));
         if(response){
            Obj = response;
            if(Obj.Value){
               rs.AddressCol.splice(index, 1);
               var result = ro.db.updateCustomerObj(Ti.App.Username, rs);
            }
         }
		 Ti.API.debug('result: ' + JSON.stringify(result));
         if(Obj.Value && !result){
            ro.ui.alert('Error:\n', 'Please try again.');
            ro.ui.hideLoader();
         }
         else{
            ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
            ro.ui.settingsShowNext({showing:'delAddress', resetOrder:true});
         }
      });
   };

   exports.newAddrGetStoreList = function(req, hasCustChangedToDeliveryAndNowNeedsAddress){
       var response, defaultCustomer = {};
       var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
       if (savedTokenObj && savedTokenObj.token) {
           req.CustomerDevice = {};
           req.CustomerDevice.DeviceID = Ti.Platform.id;
           req.CustomerDevice.DeviceToken = savedTokenObj.token;
           req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
       }
       Ti.API.info("Request: " + JSON.stringify(req));
      ro.dataservice.post(req, 'InsertCustomerAddress', function(response){
         if(response){
            if(response.Value){
               defaultCustomer = ro.db.getCustObj(Ti.App.Username);
               req.Address.Id = response.Id;
               defaultCustomer.AddressCol.push(req.Address);
               ro.db.updateCustomerObj(Ti.App.Username, defaultCustomer);
            }
            if(response.Stores && response.Stores.length > 0){
               ro.ui.ordShowNext({ addView:true, showing:'storeSelection', stores:response.Stores, checkMatchingStore:(hasCustChangedToDeliveryAndNowNeedsAddress?true:false) });
            }
            else{
            		useThisAddress(null);
               ro.ui.hideLoader();
               ro.ui.alert('No stores found. ', 'We apologize for this inconvenience.');
               ro.ui.ordShowNext({showing:'addNewAddr'});
            }
         }
         else{
         	useThisAddress(null);
            ro.ui.alert('An error has occurred ', 'Please try again.');
         }
      });
   };
   exports.getStoreList = function(req, hasCustChangedToDeliveryAndNowNeedsAddress){
      var response;
      ro.dataservice.post(req, 'GetStores', function(response){
         if(response){
            if(response.Value && response.Stores && response.Stores.length > 0){
               ro.ui.ordShowNext({ addView:true, showing:'storeSelection', stores:response.Stores, checkMatchingStore:(hasCustChangedToDeliveryAndNowNeedsAddress?true:false) });
            }
            else{
            		useThisAddress(null);
               if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
                   ro.ui.alert('This address is not in our delivery zone. ', 'We apologize for this inconvenience.');
                   Ti.App.Properties.removeProperty('guestaddr');
               }
               else{
               	ro.ui.alert('No stores found', 'Please check your address');
               }
               ro.ui.hideLoader();
            }

         }
         else{
            if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('response: ' + JSON.stringify(response)); }
            ro.ui.alert('No stores found', 'Please check your address');
         }
      });
   };

   function useThisAddress(addressObj){
   	try{
   	   if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
   	      return;
   	   }
   	   	if(!addressObj){
   	   		var test = Ti.App.OrderObj;
   	   		test.Customer = null;
   	   		test.Customer = {};
   	   		Ti.App.OrderObj = test;
   	   		
   	   		return;
   	   	}
   	   
	   	if(Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	   		var test = Ti.App.OrderObj;
	   		test.Customer = addressObj;
	   		Ti.App.OrderObj = test;
	   	}
	   }
	   catch(ex){
	   	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('(addrControl) useThisAddress()-Exception: ' + ex); }
	   }
   }

   exports.formRequestGS = function(addressObj){

   	useThisAddress(addressObj);

      var req  = {};
      req.RevKey = 'test';
      req.IsDelivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;
      req.CompressResponse = false;
      req.Lat = addressObj.Lat;
      req.Lon = addressObj.Lon;
      return req;
   };
   //return ro;
//})();