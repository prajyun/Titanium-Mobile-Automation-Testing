//var payControl = (function(){
   var rs = {};
   var ccControl = require('controls/ccControl');
   function checkLoyaltyCodes(){
   	  var test = Ti.App.OrderObj;
   	  var itmCpnDontAdd = false;
   	  var cpnDontAdd = false;
   	  for(var i=0,iMax=test.Items&&test.Items.length?test.Items.length:0; i<iMax; i++){
   	  	 itmCpnDontAdd = false;
   	  	 var itm = test.Items[i];
   	  	 if(itm.hasOwnProperty('CpnObj') && itm.CpnObj && itm.CpnObj.hasOwnProperty('LoyaltyCode') && itm.CpnObj.LoyaltyCode && itm.CpnObj.LoyaltyCode.length){
   	  	 	for(var j=0,jMax=test.LoyaltyCodes && test.LoyaltyCodes.length?test.LoyaltyCodes.length : 0; j<jMax;j++){
   	  	 		if(itm.CpnObj.LoyaltyCode == test.LoyaltyCodes[j]){
   	  	 			itmCpnDontAdd = true;
   	  	 			break;
   	  	 		}
   	  	 	}
   	  	 	if(!itmCpnDontAdd){
   	  	 		test.LoyaltyCodes.push(itm.CpnObj.LoyaltyCode);
   	  	 	}
   	  	 }
   	  }
   	  for(var i=0,iMax=test.Cpns&&test.Cpns.length?test.Cpns.length:0; i<iMax; i++){
   	  	 cpnDontAdd = false;
   	  	 var cpn = test.Cpns[i];
   	  	 if(cpn.hasOwnProperty('LoyaltyCode') && cpn.LoyaltyCode && cpn.LoyaltyCode.length){
   	  	 	for(var j=0,jMax=test.LoyaltyCodes && test.LoyaltyCodes.length?test.LoyaltyCodes.length : 0; j<jMax;j++){
   	  	 		if(cpn.LoyaltyCode == test.LoyaltyCodes[j]){
   	  	 			cpnDontAdd = true;
   	  	 			break;
   	  	 		}
   	  	 	}
   	  	 	if(!cpnDontAdd){
   	  	 		test.LoyaltyCodes.push(cpn.LoyaltyCode);
   	  	 	}
   	  	 }
   	  }
   	  Ti.App.OrderObj = test;
   	  test = null;
   }
   function fixCustomerObj(rsCust, ZoneName){
   	var test = Ti.App.OrderObj;
   	if(rsCust.FirstName){
   		test.Customer.FName = rsCust.FirstName;
   	}
   	if(rsCust.LastName){
   		test.Customer.LName = rsCust.LastName;
   	}
   	if(rsCust.Phone){
   	   //Ti.API.debug('rsCust.Phone: ' + rsCust.Phone);
   	  // Ti.API.debug('test.Customer.SelPhone: ' + test.Customer.SelPhone);
   		test.Customer.SelPhone = rsCust.Phone.replace(/-/g,'');
   	}
   	if(test.Customer.St){
   		test.Customer.Street = test.Customer.St;
   		delete test.Customer.St;
   	}
   	if(test.Customer.AddrTypeName){
   		test.Customer.CustType = test.Customer.AddrTypeName;
   		delete test.Customer.AddrTypeName;
   	}
   	if(test.Customer.CustAddrTypeName){
   		test.Customer.Loc = test.Customer.CustAddrTypeName;
   		delete test.Customer.CustAddrTypeName;
   	}
   	if(test.Customer.SUD){
   		test.Customer.Apt = test.Customer.SUD;
   		delete test.Customer.SUD;
   	}
   	if(ZoneName){
   		test.Customer.Zone = ZoneName;
   	}
   	Ti.App.OrderObj = test;
   }
   function setOrdTracker(time, id){
   	  //Ti.API.debug('time: ' + time);
   	  //Ti.API.debug('id: ' + id);
   	  Ti.App.Properties.setString('ordTrackObj', JSON.stringify({time:time, id:id, wasGuest:ro.REV_GUEST_ORDER.getIsGuestOrder()}));
   }
   
   function processOrder(){
      ro.ui.showLoader();
      var raterAlert = Ti.UI.createAlertDialog();
      var alertDiag = Ti.UI.createAlertDialog();

      // GUEST ORDERS
      var isGuest = false;
      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
         isGuest = true;
      }
      // GUEST ORDERS

      if(ro.REV_LOYALTY.isEnabled() || ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()){
      	 //Ti.API.debug('BEFORE - Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
         ////deb.ug(Ti.App.OrderObj, 'BEFORE-ORDEROBJ');
         if(!Ti.App.OrderObj.Cpns || !Ti.App.OrderObj.Cpns.length){
            var test = Ti.App.OrderObj;
            test.LoyaltyCodes = [];
            Ti.App.OrderObj = test;
            test = null;
         }
         var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
         //Ti.API.debug('currentLoyalty: ' + JSON.stringify(currentLoyalty));
         if(currentLoyalty.isEWOM || currentLoyalty.isHC){
            currentLoyalty.addLoyaltyCodes(Ti.App.OrderObj.Cpns, Ti.App.OrderObj.Items);
            checkLoyaltyCodes();
         }
         else{
            currentLoyalty = {};
         }
         //Ti.API.debug('AFTER - Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
         ////deb.ug(Ti.App.OrderObj, 'AFTER-ORDEROBJ');
      }

      var storeObj = ro.app.Store;

      var req = {};
      req.RevKey = 'test';
      req.CompressResponse = false;
      req.StoreID = storeObj.ID;
      if(isGuest){
         req.IsGuest = true;
         /*if(Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
            var newAddr = ro.REV_GUEST_ORDER.getGuestAddr();
            Ti.API.debug('newAddr: ' + JSON.stringify(newAddr));
         }*/
      }

      rs = ro.db.getCustObj(Ti.App.Username);
		if(!isGuest && Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
			fixCustomerObj(rs, ro.app.Store.Menu.OnlineOptions.DelivOpts.ZoneName);
		}

      if(Ti.App.ItemsSplit){
         //var func = new PricingFunctions();
         var priceEngine = require('logic/pricing');
	     var func = priceEngine.pricer();
         Ti.App.OrderObj = func.Split(Ti.App.OrderObj);
      }
      if(!isGuest && Ti.App.Properties.hasProperty('favName')){
         req.Name = Ti.App.Properties.getString('favName');
      }

      //Privacy Policy
      if(privacyPolicy.isEnabled()){
	   	var test = Ti.App.OrderObj;
	   	if(!test.Customer){
	   		test.Customer = {};
	   	}
	   	test.Customer.AcceptedTerms = true;
	   	Ti.App.OrderObj = test;
	   	test = null;
	   }
	   //Privacy Policy
	   
	   //GateCode
	   if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery && Ti.App.Properties.hasProperty('gateCode')){
	   	  var test = Ti.App.OrderObj;
	   	  if(!test.Customer){
	   	  	 test.Customer = {};
	   	  }
	   	  test.Customer.EntryCode = Ti.App.Properties.getString('gateCode');
	   	  Ti.App.OrderObj = test;
	   	  test = null;
	   	  //payControl.clearGateCode();
	   	  ro.utils.removeProp('gateCode');
	   	  //Ti.App.OrderObj.Customer.GateCode = Ti.App.Properties.getString('gateCode')
	   	  //Ti.API.debug('Ti.APP.OrderObj.Customer.EntryCode: ' + Ti.App.OrderObj.Customer.EntryCode);
	   }
	   //GateCode

      req.OrderObj = Ti.App.OrderObj;
      //Ti.API.debug('req.OrderObj.Tip: ' + req.OrderObj.Tip);

      var secureObj = {}, DeviceInfo = {};
      
      secureObj.Email = Ti.App.Username;
      secureObj.Password = Ti.App.Password;
      
      DeviceInfo.id = 'revmobile';
      DeviceInfo.name = Ti.Platform.osname;
      DeviceInfo.osname = Ti.Platform.name;
      DeviceInfo.version = Ti.App.version;
      DeviceInfo.model = Ti.Platform.model;

	  if(Ti.App.OrderObj.ordOnlineOptions.CCInfoCol && Ti.App.OrderObj.ordOnlineOptions.CCInfoCol.length){
	  	var totalTip = 0;
	  	req.OrderObj.Tip = totalTip;
	  	 for(var i=0, iMax=Ti.App.OrderObj.ordOnlineOptions.CCInfoCol.length; i<iMax; i++){
	  	 	if(Ti.App.OrderObj.ordOnlineOptions.CCInfoCol[i].Tip && Ti.App.OrderObj.ordOnlineOptions.CCInfoCol[i].Tip>0){
	  	 		Ti.API.info('Ti.App.OrderObj.ordOnlineOptions.CCInfoCol[i]: ' + JSON.stringify(Ti.App.OrderObj.ordOnlineOptions.CCInfoCol[i]));
	  	 		totalTip += Ti.App.OrderObj.ordOnlineOptions.CCInfoCol[i].Tip;
	  	 	}
	  	 	
	  	 }
	     req.OrderObj.Tip = totalTip;
	  	 secureObj.CCInfoCol = Ti.App.OrderObj.ordOnlineOptions.CCInfoCol;
         Ti.App.OrderObj.ordOnlineOptions.CCInfoCol = null;
         req.OrderObj.ordOnlineOptions.CCInfoCol = null;
         delete Ti.App.OrderObj.ordOnlineOptions.CCInfo;
         delete req.OrderObj.ordOnlineOptions.CCInfo;
	  }
      else if(Ti.App.OrderObj.ordOnlineOptions.CCInfo){
         secureObj.CCInfo = Ti.App.OrderObj.ordOnlineOptions.CCInfo;
         if(req.OrderObj.Tip){
         	secureObj.CCInfo.Tip = req.OrderObj.Tip;
         } 
         ccControl.updateDefaultCard(secureObj.CCInfo);        
         Ti.App.OrderObj.ordOnlineOptions.CCInfo = {};
         req.OrderObj.ordOnlineOptions.CCInfo = {};
         delete Ti.App.OrderObj.ordOnlineOptions.CCInfoCol;
         delete req.OrderObj.ordOnlineOptions.CCInfoCol;
      }
      Ti.API.info("SecuredObj: " + JSON.stringify(secureObj));
	   var encryptedText = encrypt(secureObj);

      if(encryptedText == ''){
         //alertDiag.title = 'Request Failed.';
         //alertDiag.message = 'Unable to make request to server.';
         //alertDiag.show();
         ro.ui.popup('Request Failed.', ['OK'], 'Unable to make request to server.', function(e) {
                    
                }, function(){
                    
                });
         return;
      }
      req.Secured = encryptedText;
      req.DeviceInfo = DeviceInfo;

      var allowNote = allowNoteFn();
      if(allowNote){
      	if(Ti.App.Properties.hasProperty('spclInst')){
	         if(!req.OrderObj.Notes){
	            req.OrderObj.Notes = [];
	         }
	         req.OrderObj.Notes.push({NoteText:Ti.App.Properties.getString('spclInst')});
	      }
      }

       var allowDelNote = allowDelNoteFn();
       if (allowDelNote) {
           if (Ti.App.Properties.hasProperty('delNote') && Ti.App.Properties.getBool('delNote', false)) {
               var test = req.OrderObj;
               if (!test.Customer) {
                   test.Customer = {};
               }
               test.Customer.DelNote = ro.app.Store.Configuration.DELIV_NOTES;               
               req.OrderObj = test;
               test = null;
           }
       }
		//return;

       if (req.OrderObj.OrderTypeCategory.toLowerCase() == "curbside") {
           if (Ti.App.Properties.hasProperty('vhclInfo')) {
               var vhcl = JSON.parse(Ti.App.Properties.getString('vhclInfo'));
               Ti.API.info("vehicle Info: " + JSON.stringify(vhcl));
               if (!req.OrderObj.Notes) {
                   req.OrderObj.Notes = [];
               }
               if (vhcl.make && vhcl.make != "") {
                   req.OrderObj.Notes.push({Type: 8, NoteText: vhcl.make});
               }
               if (vhcl.model && vhcl.model != "") {
                   req.OrderObj.Notes.push({Type: 9, NoteText: vhcl.model });
               }
               if (vhcl.color && vhcl.color != "") {
                   req.OrderObj.Notes.push({Type: 10, NoteText: vhcl.color });
               }
               if (vhcl.features && vhcl.features != "") {
                   req.OrderObj.Notes.push({Type: 11, NoteText: vhcl.features });
               }
               if (vhcl.vehicleId) {
                   req.VehicleID = vhcl.vehicleId;
               }
           }
       }

       if (!req.OrderObj.hasOwnProperty("Menu") || req.OrderObj.Menu == "") {
           var test = req.OrderObj;
           test.Menu = ro.app.Store.Menu.Name;           
           req.OrderObj = test;
           test = null;
       }
       
	if ((storeObj.Configuration.AllowFutureOrders || storeObj.Configuration.AllowSameDayDefer) && Ti.App.Properties.hasProperty('futureTimeObj')) {
		var futureTimeObj = JSON.parse(Ti.App.Properties.getString('futureTimeObj', '{}'));
		//var deferTime = storeObj.Menu.OnlineOptions.OrdTypes
		var deferTime;
		for(var i=0, iMax=storeObj.Menu.OnlineOptions.OrdTypes.length; i<iMax; i++){
			if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery == storeObj.Menu.OnlineOptions.OrdTypes[i].IsDelivery){
				deferTime = storeObj.Menu.OnlineOptions.OrdTypes[i].DeferPrepMin;
				break;
			} 
		}
		Ti.API.debug('deferTime: ' + deferTime);
		
		var futureOrderDate = new Date(futureTimeObj.dateValue);
		futureOrderDate.setUTCMinutes(futureTimeObj.minValue);

		if (futureTimeObj.hrValue >= 24) {
			futureOrderDate.setUTCDate(futureOrderDate.getUTCDate() + 1);
			futureOrderDate.setUTCHours(futureTimeObj.hrValue - 24);
		} else {
			futureOrderDate.setUTCHours(futureTimeObj.hrValue);

		}

		var deferPrt = new Date(futureOrderDate - 60000 * deferTime);

		var test = req.OrderObj;
		test.IsDeferred = true;
		test.DeferDueStr = futureOrderDate;
		//'8/4/2014 22:00';
		test.DeferPrepMin = deferTime;
		test.DeferPrtStr = deferPrt;
        req.OrderObj = test;
        test = null;
		//Ti.App.Properties.removeProperty('futureTimeObj');
	} else {
		clearFutureOrder();
	} 
       ro.dataservice.post(req, 'ProcessOrder', function (response) {
           Ti.API.info("PROCESSORDER - req: " + JSON.stringify(req));
         if(response){
         	Ti.API.info("PROCESSORDER - response: " + JSON.stringify(response));
            var Obj = response;
            if(Obj.Value){
               if(Obj.CustomerInfo && Obj.CustomerInfo.CardTokens && Obj.CustomerInfo.CardTokens.length){                  
                  ccControl.tokenUpdate(Obj.CustomerInfo.CardTokens, false, ro);
               }
            	//Ti.API.debug('Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
				   Ti.App.Properties.removeProperty('futureTimeObj');
            	//require('RateMe').checkNow(Ti.App.REV_APP_ID, Ti.App.Username);

            	Ti.App.Properties.setBool('lvlupBool', false);
            	Ti.App.atPayScrn = false;
               //payControl.clearSpclInst();
                ro.utils.removeProp('spclInst');
                ro.utils.removeProp('delNote');
               //payControl.clearGateCode();
                ro.utils.removeProp('gateCode');
                ro.utils.removeProp('vhclInfo');
               //raterAlert.title = 'Order Success';
               raterAlert.message = 'The order is complete. You will receive a confirmation email shortly. ';
               //raterAlert.buttonNames = ['OK'];
                

               if(Obj.LoyaltyMessage && Obj.LoyaltyMessage.length){
               	raterAlert.message += Obj.LoyaltyMessage;
               }

               var messageParts = Obj.Message.split(',');
               var obj = {};
               obj.ID = storeObj.ID;
               var curDate = new Date();
               var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
               var timeAtStore = new Date(UTCTime + (storeObj.TimeZone * 3600000));
               obj.Date = ro.utils.getFormattedDate(timeAtStore);
               obj.Time = ro.utils.getFormattedTime(timeAtStore);
               obj.Weekday = ro.utils.getWeekday(timeAtStore);
               obj.Name = storeObj.Name;
               obj.Address = storeObj.Address;
               obj.City = storeObj.City;
               obj.State = storeObj.State;
               obj.Zip = storeObj.Zip;
               obj.Phone = storeObj.Phone;
               obj.Confirmation = '';
				
			   if(Obj.TrackerID){
			   	  setOrdTracker(UTCTime, Obj.TrackerID);
			   }

               if(messageParts){
                  if(messageParts.length == 3){
                     obj.Confirmation = messageParts[2];
                  }
               }

					try{
						ro.app.GA.trackTransaction(obj.Confirmation, storeObj.Name, Ti.App.OrderObj.ActiveTotal.toFixed(2), Ti.App.OrderObj.Tax.toFixed(2), Ti.App.OrderObj.DlvyFee, 'USD');
					}
					catch(ex){
                  		if(Ti.App.DEBUGBOOL){ Ti.API.debug('ro.app.GA.trackTransaction() - Exception: ' + ex); }
					}

               
               if(!isGuest){
                  var rowID = ro.db.createCustOrd(Ti.App.Username, Ti.App.OrderObj.Items[0].Name, Ti.App.OrderObj, obj);
                  updateLocalOrd(Ti.App.OrderObj, obj.Confirmation, curDate, storeObj.ID, req.Name);

                  if(Ti.App.OrderObj.Cpns){
                     var SingleUseKey = rs.CpnUsage? rs.CpnUsage:'';
                     var updateDB = false;
                     for(var x = 0; x< Ti.App.OrderObj.Cpns.length; x++){
   
                        if(Ti.App.OrderObj.Cpns[x].SingleUseKey && Ti.App.OrderObj.Cpns[x].SingleUseKey>0){
                           updateDB = true;
   
                           if(SingleUseKey && SingleUseKey.length>0){
                              SingleUseKey+= '-';//Ti.App.OrderObj.Cpns[x].SingleUseKey;
                           }
   
                           SingleUseKey += Ti.App.OrderObj.Cpns[x].SingleUseKey;
   
                        }
                     }
                     if(updateDB){
                        rs.CpnUsage = SingleUseKey;
                        ro.db.updateCustomerObj(Ti.App.Username, rs);
                     }
                  }
                  
                  var bogoUpdateDB = false;
   					var bogoSingleUseKey = rs.CpnUsage? rs.CpnUsage:'';
   					for(var x=0; x<Ti.App.OrderObj.Items.length; x++){
   						if(Ti.App.OrderObj.Items[x].CpnObj && Ti.App.OrderObj.Items[x].CpnObj.SingleUseKey && Ti.App.OrderObj.Items[x].CpnObj.SingleUseKey > 0){
   							bogoUpdateDB = true;
                        if(bogoSingleUseKey && bogoSingleUseKey.length>0){
                           bogoSingleUseKey+= '-';//Ti.App.OrderObj.Cpns[x].SingleUseKey;
                        }
                        bogoSingleUseKey += Ti.App.OrderObj.Items[x].CpnObj.SingleUseKey;
   						}
   					}
   					if(bogoUpdateDB){
                     rs.CpnUsage = bogoSingleUseKey;
                     ro.db.updateCustomerObj(Ti.App.Username, rs);
                  }          
                  
   
   				   if(req.OrderObj.Customer){
                     if(req.OrderObj.Customer.AcceptedTerms){
                        var cstmr = JSON.parse(Ti.App.Properties.getString('Customer'));
                        if(!cstmr){
                           cstmr = {};
                        }
                        cstmr.TermsDate = timeAtStore.toJSON();
                        Ti.App.Properties.setString('Customer', JSON.stringify(cstmr));
                        cstmr = null;
                     }

	                  if(req.OrderObj.Customer.OptOut || req.OrderObj.Customer.OptOut === false){
	                     var cstmr = JSON.parse(Ti.App.Properties.getString('Customer'));
	                     if(!cstmr){
	                        cstmr = {};
	                     }
	                     cstmr.EClubOptIn = req.OrderObj.Customer.OptOut ? 2 : 1;
	                     Ti.App.Properties.setString('Customer', JSON.stringify(cstmr));
	                     cstmr = null;
	                  }

	                  if(req.OrderObj.Customer.LtyOptOut || req.OrderObj.Customer.LtyOptOut === false){
	                     var cstmr = JSON.parse(Ti.App.Properties.getString('Customer'));
	                     if(!cstmr){
	                        cstmr = {};
	                     }
	                     cstmr.LtyOptIn = req.OrderObj.Customer.LtyOptOut ? 2 : 1;
	                     Ti.App.Properties.setString('Customer', JSON.stringify(cstmr));
	                     cstmr = null;
	                  }

                     if(req.OrderObj.Customer.MktStatus){
                        var cstmr = JSON.parse(Ti.App.Properties.getString('Customer'));
                        if(!cstmr){
                           cstmr = {};
                        }
                        cstmr.MktStatus = req.OrderObj.Customer.MktStatus;
                        Ti.App.Properties.setString('Customer', JSON.stringify(cstmr));
                        cstmr = null;
                     }
	              
                  }                  
                 
               }

               clearOrderObj();
               Ti.App.ItemsSplit = false;
               Ti.App.SplitOrder = Ti.App.OrderObj;

               clearFutureOrder();
               ro.utils.removeProp('Store');
               /*var testSt = storeObj;
               testSt.Configuration.HC_API_KEY = null;
               testSt.Configuration.HC_API_SECRET = null;
               storeObj = testSt;*/
               
               //ro.utils.setStrProp('DefaultStore', storeObj);
               ro.REV_STORES.setDefaultStore(storeObj);
               //testSt = null;
               
               require('RateMe').checkNow(Ti.App.REV_APP_ID, Ti.App.Username, function(){
                         //ro.ui.cartShowNext({showing:'Cart'});
                         
                         ro.ui.popup('Order Success', ['OK'], raterAlert.message, function(e) {
                    try{
                     ro.ui.hideLoader();
                     if(allowNote){
                        req.OrderObj.Notes = [];
                     }
                     Ti.App.OrderObj.ordOnlineOptions.CCInfo = {};
                     Ti.App.OrderObj.ordOnlineOptions.CCInfoCol = {};
                     
                     ro.ui.setOrdTypeStkState('');
                     ro.ui.clearCart({});
                     
                     
                     ro.ui.cartShowNext({showing:'Cart'});
                     //ro.ui.cartReset();
                     /*if(isGuest){
                        ro.ui.ordShowNext({ showing:'ordTypeView', orderComplete:true });   
                     }
                     else{
                        ro.ui.cartShowNext({showing:'Cart'});
                     }*/
                    //ro.ui.cartShowNext({showing:'Cart'});
                     
                     //ro.ui.ordShowNext({ showing:'ordTypeView', orderComplete:true });
                     //ro.ui.ordShowNext({ addView:true, showing:'ordTypeView', orderComplete:true });
                  }
                  catch(e){
                     ro.ui.alert('Error: ', e);
                  }
                }, function(){
                    
                }, true);
                         
                     });
               
                
               raterAlert.addEventListener('click', function(e){
                  try{
                     ro.ui.hideLoader();
                     if(allowNote){
                     	req.OrderObj.Notes = [];
                     }
                     Ti.App.OrderObj.ordOnlineOptions.CCInfo = {};
                     Ti.App.OrderObj.ordOnlineOptions.CCInfoCol = {};
                     
                     ro.ui.setOrdTypeStkState('');
                     ro.ui.clearCart({});
                     //ro.ui.cartReset();
                     /*if(isGuest){
                     	ro.ui.ordShowNext({ showing:'ordTypeView', orderComplete:true });	
                     }
                     else{
                     	ro.ui.cartShowNext({showing:'Cart'});
                     }*/
                    ro.ui.cartShowNext({showing:'Cart'});
                     
                     //ro.ui.ordShowNext({ showing:'ordTypeView', orderComplete:true });
                     //ro.ui.ordShowNext({ addView:true, showing:'ordTypeView', orderComplete:true });
                  }
                  catch(e){
                     ro.ui.alert('Error: ', e);
                  }
               });
              // raterAlert.show();
            }
            else{
               ro.ui.hideLoader();
               //alertDiag.title = 'Order Failed';
               //alertDiag.message = Obj.Message + '\nCODE:500.';
               ro.ui.popup('Order Failed', ['OK'], Obj.Message + '\nCODE:500.', function(e) {
                    
                }, function(){
                    
                });
               if(Ti.App.ItemsSplit){
                  //var func = new PricingFunctions();
                  var priceEngine = require('logic/pricing');
	        	  var func = priceEngine.pricer();
                  Ti.App.OrderObj = func.Join(Ti.App.OrderObj);
               }
               //alertDiag.show();
               if(allowNote){
               	req.OrderObj.Notes = [];
               }
               var tests = Ti.App.OrderObj;
               tests.ordOnlineOptions.CCInfo = secureObj.CCInfo;
               tests.ordOnlineOptions.CCInfoCol = secureObj.CCInfoCol;
               Ti.App.OrderObj = tests;
               tests = null;
            }
         }
         else{
         	if(allowNote){
            	req.OrderObj.Notes = [];
            }
            var tests = Ti.App.OrderObj;
               tests.ordOnlineOptions.CCInfo = secureObj.CCInfo;
               tests.ordOnlineOptions.CCInfoCol = secureObj.CCInfoCol;
               Ti.App.OrderObj = tests;
               tests = null;
         }
      });
   };
   exports.processOrder = processOrder;
   function updateLocalOrd(orderObj, ordId, dt, storeId, name){
      //Ti.include('/logic/prevOrders.js');
      if(!rs.PrevOrders){
         var prevObj = rs;
         prevObj.PrevOrders = [];
         rs = prevObj;
      }
      rs.PrevOrders.unshift(ro.prevOrders.getPrevOrd(orderObj, ordId, dt,storeId,name, orderObj.Customer?orderObj.Customer:{}));
      ro.db.updateCustomerObj(Ti.App.Username, rs);

      try{
      	var cst = JSON.parse(Ti.App.Properties.getString('Customer'));
      	if(!cst){
      		cst = {};
      	}
   		cst.PrevOrders = rs.PrevOrders;
   		Ti.App.Properties.setString('Customer', JSON.stringify(cst));
      }
      catch(ex){
      	Ti.API.debug('cst-Exception: ' + ex);
      }

   };
   exports.updateLocalOrd = updateLocalOrd;
   function encrypt(obj){
      try{
      	 var cryptoHelpers = require('classes/cryptoHelpers').cryptoHelpers();
      	 var slowAES = require('classes/aes').slowAES;
         var key = [156,36,46,156,33,218,42,43,45,167,44,80,37,155,112,85];
         var iv = [33,37,85,38,35,85,222,121,100,173,58,200,184,37,209,33];
         var iptStr = JSON.stringify(obj);
         var input = cryptoHelpers.convertStringToByteArray(iptStr);
         var crypted = slowAES.encrypt(input, slowAES.modeOfOperation.CBC,key, 16, iv);
         var base64String = cryptoHelpers.base64.encode_line(crypted.cipher);
         return base64String;
      }
      catch(ex){
      	 //Ti.API.debug('ex: ' + ex);
         return '';
      }
   };
   exports.encrypt = encrypt;
   exports.fillOrderObjGift = function(gcObj){
      var test = Ti.App.OrderObj;
      var newGcObj = {
         OLCardNum:gcObj.giftCardNum,
         IsGiftCard:true,
         CardInfo:"GiftCard",
         Tip:gcObj.Tip || null
      };
      newGcObj.IsGiftCard = true;
      test.IsOnline = true;
      test.DisplayOrdPayment = 'gift';//THIS MAY NEED CHANGING ONCE THE SERVER PROPERLY ACCEPTS GIFTCARD...
      test.ordOnlineOptions.CCInfo = newGcObj;
      Ti.App.OrderObj = test;
      return true;
   };
   exports.getGiftCardObj = function(gcObj){
	   	 var newGcObj = {
	         OLCardNum:gcObj.giftCardNum,
	         IsGiftCard:true,
	         CardInfo:"GiftCard",
	         Tip:gcObj.Tip || null
	      };
	      newGcObj.IsGiftCard = true;
	      if(gcObj && gcObj.payAmt){
	      	newGcObj.PaymentAmt = gcObj.payAmt;
	      }
	      return newGcObj;
   };
   exports.getPaymentObj = function(readCardObj){
      try{
      	if(ro.app.Store.Configuration.VerifyBilling){
      		if(ro.app.Store.Configuration.VerifyBilling === 1){
      			if(readCardObj.AVSStreetNum){
      				delete readCardObj.AVSStreetNum;
      			}
      		}
      		if(ro.app.Store.Configuration.VerifyBilling === 2){
      			if(readCardObj.AVSZipCode){
      				delete readCardObj.AVSZipCode;
      			}
      		}
      	}
      	else{
      		if(readCardObj.AVSStreetNum){
   				delete readCardObj.AVSStreetNum;
   			}
   			if(readCardObj.AVSZipCode){
   				delete readCardObj.AVSZipCode;
   			}
      	}

         var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
         if(readCardObj.OLExpMonth)
         readCardObj.OLExpMonth = monthNames.indexOf(readCardObj.OLExpMonth) + 1;

         var test = Ti.App.OrderObj;
         test.IsOnline = true;
         //test.DisplayOrdPayment = 'Credit';
         //test.ordOnlineOptions.CCInfo = readCardObj;
         //test.ordOnlineOptions.CCInfo.PaymentAmt = test.ActiveTotal;
         Ti.App.OrderObj = test;
         return readCardObj;
      }
      catch(e){
         alert(e);
      }
   };
   exports.fillOrderObj = function(readCardObj){
      try{
      	Ti.API.info("before processing read cardobj: "+JSON.stringify(readCardObj));
      	if(ro.app.Store.Configuration.VerifyBilling){
      		if(ro.app.Store.Configuration.VerifyBilling === 1){
      			
      			if(readCardObj.AVSStreetNum){
      				delete readCardObj.AVSStreetNum;
      			}
      		}
      		if(ro.app.Store.Configuration.VerifyBilling === 2){
      			
      			if(readCardObj.AVSZipCode){
      				delete readCardObj.AVSZipCode;
      			}
      		}
      	}
      	else{
      		if(readCardObj.AVSStreetNum){
   				delete readCardObj.AVSStreetNum;
   			}
   			if(readCardObj.AVSZipCode){
   				delete readCardObj.AVSZipCode;
   			}
      	}
      	//Ti.API.info("isNan:"+isNaN(readCardObj.OLExpMonth));
         if(isNaN(readCardObj.OLExpMonth)){
         	//Ti.API.info("inside here");
             var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            // Ti.API.info(monthNames.indexOf(readCardObj.OLExpMonth));
             readCardObj.OLExpMonth = monthNames.indexOf(readCardObj.OLExpMonth) + 1;
             //Ti.API.info(readCardObj.OLExpMonth);
             
         }
         //Card On File filing up saved token into card object         
         if(ro.app.Store.Configuration.ALLOW_CARD_TOKEN && readCardObj.TokenID && readCardObj.TokenID != ""){
            readCardObj.OLCardNum = readCardObj.TokenID;
            readCardObj.PayWithToken = true;
         }
		   Ti.API.info("after processing read cardobj:"+JSON.stringify(readCardObj));
         var test = Ti.App.OrderObj;
         test.IsOnline = true;
         test.DisplayOrdPayment = 'Credit';
         test.ordOnlineOptions.CCInfo = readCardObj;
         test.ordOnlineOptions.CCInfo.PaymentAmt = test.ActiveTotal;
         Ti.App.OrderObj = test;
         return true;
      }
      catch(e){
         alert(e);
      }
   };
   exports.CHK_ALERT = function(e){
      if(e.index == 0){
         processOrder();
      }
      else{
      	ro.ui.hideLoader();
      }
   };
   exports.calcAmt = function(msg){
      var trimmedMsg = msg.replace(/^\s+|\s+$/g,'');
      var startPosition = -1;
      startPosition = trimmedMsg.indexOf("[SubTotal");

      if(startPosition > -1){
         var endPosition = -1;
         endPosition = trimmedMsg.indexOf("]", startPosition);
         if(endPosition > -1){
            var func = "";
            func = trimmedMsg.substr(startPosition, endPosition - startPosition + 1);
            var subTotal;
            var math = "";
            math = func.substr(1, func.length-2).replace("SubTotal", Ti.App.OrderObj.Subtotal.toString());
            var strArray = math.split("*");
            var result = parseFloat(strArray[0]) * parseFloat(strArray[1]);
            trimmedMsg = trimmedMsg.replace(func, String.formatCurrency(result));
         }
      }
      return trimmedMsg;
   };
   exports.clearMultiPaymentInfo = function(){
   	  var ordObj = Ti.App.OrderObj;

      if("ordOnlineOptions" in ordObj){
         ordObj.ordOnlineOptions.CCInfoCol = null;
      }

      if("DisplayOrdPayment" in ordObj){
         ordObj.DisplayOrdPayment = null;
      }

      Ti.App.OrderObj = ordObj;
   };
   exports.clearPaymentInfo = function(){
      var ordObj = Ti.App.OrderObj;

      if("ordOnlineOptions" in ordObj){
         ordObj.ordOnlineOptions.CCInfo = null;
         if(ordObj.ordOnlineOptions.CCInfoCol && ordObj.ordOnlineOptions.CCInfoCol.length){
         	ordObj.ordOnlineOptions.CCInfoCol = null;
         }
      }

      if("DisplayOrdPayment" in ordObj){
         ordObj.DisplayOrdPayment = null;
      }
      
      if("Tip" in ordObj){
         ordObj.Tip = null;
      }      

      Ti.App.OrderObj = ordObj;
   };
   exports.phoneClickControl = function(e){
      var storeObj;
      if(ro.app.Store){
      	storeObj = ro.app.Store;
      }
      else{
      	storeObj = ro.app.Store;
      }

      if(storeObj.Phone){
         var phone = 'tel:' + storeObj.Phone.replace(/[\D\s]/g,'');
         /*var alertDiag = Ti.UI.createAlertDialog({
            message:storeObj.Phone,
            buttonNames:['Call','Cancel'],
            cancel:1
         });
         alertDiag.show();
         alertDiag.addEventListener('click', function(e){
            if(e.index == 0){
               Ti.Platform.openURL(phone);
            }
         });*/
        
        ro.ui.popup("", ['OK'], storeObj.Phone, function(e) {
                    Ti.Platform.openURL(phone);
                }, function(){
                    
                });
        
      }
   };
   exports.getStoreObj = function(/*e*/){
   	try{
   		return ro.app.Store;
   	}
   	catch(ex){
   		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('payControl.getStoreObj()-Exception: ' + ex); }
   	}
   };
   exports.hasChosenCard = function(){
      Ti.API.info("Checking chosen card : " + JSON.stringify(Ti.App.OrderObj.ordOnlineOptions.CCInfo));
      if(Ti.App.OrderObj.ordOnlineOptions.CCInfo){
         if(Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLCardNum &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.PayerName &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLExpMonth &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLExpYear &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.PaymentAmt >= 0 &&
            (Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLSecCode || Ti.App.OrderObj.ordOnlineOptions.CCInfo.TokenID) &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.CardInfo){
               return true;
         }
      }
      return false;
   };
   exports.hasChosenGiftCard = function(){
      if(Ti.App.OrderObj.ordOnlineOptions.CCInfo){
         if(Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLCardNum &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.IsGiftCard &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.CardInfo){
               return true;
         }
      }
      return false;
   };
   exports.hasApplePay = function(){
      if(Ti.App.OrderObj.ordOnlineOptions.CCInfo){
         if(Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLCardNum &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.PayerName &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.TokenType &&
            Ti.App.OrderObj.ordOnlineOptions.CCInfo.PaymentAmt >= 0){
               return true;
         }
      }
      return false;
   };
   function clearOrderObj(){
   	var props = ['Items', 'Cpns'];
   	ro.utils.removeObjProp(Ti.App.OrderObj, props);
   };
   exports.clearOrderObj = clearOrderObj;
   function allowNoteFn(){
   	var strObj = ro.app.Store;
   	if(strObj.Configuration.AllowOrderNote){
   		var retBool = strObj.Configuration.AllowOrderNote;
   		strObj = null;
   		return retBool;
   	}
   	return false;
   };
exports.allowNoteFn = allowNoteFn;
function allowDelNoteFn() {
    var strObj = ro.app.Store;    
    if (strObj.Configuration.DELIV_NOTES && strObj.Configuration.DELIV_NOTES != "") {        
        return true;
    }
    return false;
};
exports.allowDelNoteFn = allowDelNoteFn;
   exports.setFutureOrder = function(e){
   	
    Ti.API.debug('setFutureOrder - e: ' + JSON.stringify(e));
   	Ti.App.OrderObj.IsDeferred = true;
   	Ti.App.OrderObj.DeferDueStr = e.storeTmFuture;
   	Ti.App.OrderObj.DeferPrtStr = new Date(Ti.App.OrderObj.DeferDueStr - (60000*e.DeferPrepMin));
   	Ti.API.debug('Ti.App.OrderObj.DeferDueStr: ' + Ti.App.OrderObj.DeferDueStr);
   	Ti.API.debug('Ti.App.OrderObj.DeferPrtStr: ' + Ti.App.OrderObj.DeferPrtStr);
   };
   function clearFutureOrder(){
		var props = ['IsDeferred', 'DeferDueStr', 'DeferPrtStr', 'DeferPrepMin'];
		ro.utils.removeObjProp(Ti.App.OrderObj, props);
   };
   exports.clearFutureOrder = clearFutureOrder;