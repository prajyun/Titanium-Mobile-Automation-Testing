var Suggest = function () {   
   var SU = {
		SUGG_MAX:0,
		SuggItems:[],
		itemsToSuggest:[],
		oncePerSession:false
   },
   init = function(ALLOW_SUGG, SUGG_MAX, SuggItems, numItemsInCart){
   	var tempOncePerSession = SU.oncePerSession;

   	SU = {
   		SUGG_MAX:0,
   		SuggItems:[],
   		itemsToSuggest:[],
   		oncePerSession:tempOncePerSession
   	};

   	SU.SUGG_MAX = SUGG_MAX&&SUGG_MAX>0 ? SUGG_MAX : 3;
   	
   	Ti.API.debug('SuggItems: ' + JSON.stringify(SuggItems));
   	////deb.ug(SuggItems, 'SuggItems');
   	////deb.ug(Arguments, 'Arguments');
   	
   	if(ALLOW_SUGG && numItemsInCart && SuggItems && SuggItems.length){
   		SU.SuggItems = SuggItems;
   		//SU.SuggItems = testSuite();
   		//Ti.API.info('SU.SuggItems: ' + JSON.stringify(SU.SuggItems));

   		return true;
   	}
   	else{
   		return false;
   	}
   },

   resetModule = function(){
   	SU.oncePerSession = false;
   },
   //.needsSuggestion() - This is a second level check that occurs when ALLOW_SUGG is true
   //This parses the SuggItems collection and checks each of them against all Items in cart.
   //If SuggItem should be suggested, then it is added to a new list of suggestable items.
   //If this new list has any items in it, then this returns true;

   needsSuggestion = function(){
   	var itemsToSuggest = [];

   	for(var i=0; i<SU.SuggItems.length; i++){
   		var suggCartItems = SU.SuggItems[i].SuggCartItms && SU.SuggItems[i].SuggCartItms.length ? SU.SuggItems[i].SuggCartItms : [];
   		for(var j=0; j<suggCartItems.length; j++){
   			var breakBool = false;
   			if(suggCartItems[j].SuggCartGrpName == 'all'){
   				itemsToSuggest.push(SU.SuggItems[i]);
   				break;
   			}

	   		for(var k=0; k<Ti.App.OrderObj.Items.length; k++){
                if (suggCartItems[j].SuggCartGrpName == Ti.App.OrderObj.Items[k].GroupName.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
	   				if(suggCartItems[j].SuggCartItmName == 'all'){
	   					itemsToSuggest.push(SU.SuggItems[i]);
	   					breakBool = true;
	   					break;
	   				}
	   				else{
                        if (suggCartItems[j].SuggCartItmName == Ti.App.OrderObj.Items[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
	   						itemsToSuggest.push(SU.SuggItems[i]);
	   						breakBool = true;
	   						break;
	   					}
	   				}
	   			}
	   		}//endfor k
	   		if(breakBool){
	   			break;
	   		}
	   	}//endfor j
   	}//endfor i

   	var fixSuggs = function(suggs){
   		var returnSuggs = [];
   		var passed = true;
			for(var i=0; i<suggs.length; i++){
				passed = true;
				for(var j=0; j<Ti.App.OrderObj.Items.length; j++){
                    if (suggs[i].SuggGrpName == Ti.App.OrderObj.Items[j].GroupName.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
						if(!suggs[i].IsPromotional){
							//suggs.splice(i, 1);
							passed = false;
							break;
						}
						else{
							var sizePassed = false, stylePassed = false;
                            if (suggs[i].SuggItmName == Ti.App.OrderObj.Items[j].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || suggs[i].SuggItmName == 'all'){
								if(suggs[i].SuggSizeName && suggs[i].SuggSizeName.length && suggs[i].SuggSizeName != 'all'){
                                    if (suggs[i].SuggSizeName == Ti.App.OrderObj.Items[j].Size.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
										sizePassed = true;
									}
								}
								else{
									sizePassed = true;
								}

								if(suggs[i].SuggStyleName && suggs[i].SuggStyleName.length && suggs[i].SuggStyleName != 'all'){
									Ti.API.debug('Ti.App.OrderObj.Items['+j+']: ' + JSON.stringify(Ti.App.OrderObj.Items[j]));
                                    if (suggs[i].SuggStyleName == Ti.App.OrderObj.Items[j].Style.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
										stylePassed = true;
									}
								}
								else{
									stylePassed = true;
								}

								if(stylePassed && sizePassed){
									//suggs.splice(i, 1);
									passed = false;
									break;
								}
							}
						}
					}
				}
				if(passed){
					returnSuggs.push(suggs[i]);
				}
			}
			return returnSuggs;
			//return JSON.parse(JSON.stringify(suggs));
		};
		SU.itemsToSuggest = [];
		SU.itemsToSuggest = fixSuggs(itemsToSuggest);

		//Ti.API.debug('itemsToSuggest: ' + JSON.stringify(itemsToSuggest));

   	//Ti.API.debug('itemsToSuggest: ' + JSON.stringify(itemsToSuggest));
   	//Ti.API.debug('itemsToSuggest.length: ' + itemsToSuggest.length);
   	//SU.itemsToSuggest = itemsToSuggest;
   	//Ti.API.debug('SU.itemsToSuggest: ' + JSON.stringify(SU.itemsToSuggest));

   	if(!SU.oncePerSession){
   		SU.oncePerSession = true;
   	}
   	else{
   		return false;
   	}
   	
//   	Ti.API.debug('SU.itemsToSuggest: ' + JSON.stringify(SU.itemsToSuggest));
   	var actuallyItems = getItems();
   	//Ti.API.info('SU.itemsToSuggest: ' + JSON.stringify(SU.itemsToSuggest));
   	//Ti.API.info('actuallyItems: '  + JSON.stringify(actuallyItems));
   	return SU.itemsToSuggest && SU.itemsToSuggest.length && actuallyItems && actuallyItems.length ? true : false;
   },
   getItems = function(){
   	var suggItemsToReturn = [];
   	var suItemsToSuggest = SU.itemsToSuggest;

   	function sortSuggs(sugg1, sugg2){
		if(sugg1.Priority > sugg2.Priority){
		   	return 1;
		}
		if(sugg1.Priority < sugg2.Priority){
		   	return -1;
		}
		return 0;
	}
    suItemsToSuggest.sort(sortSuggs);
    //Ti.API.info("After Sort: " + JSON.stringify(suItemsToSuggest));
    var combineItem = function(itm, sugg, grpIdx, itmIdx){
    	var returnItm = {};
    	returnItm = itm;
    	returnItm.sugg = sugg;
    	returnItm.grpIndx = grpIdx;
    	returnItm.itmIndx = itmIdx;
    	return JSON.parse(JSON.stringify(returnItm));
    };
    
    var sugg = {};

   	for(var i=0; i<suItemsToSuggest.length; i++){
   		for(var j=0; j<ro.app.Store.Menu.Groups.length; j++){
   			var breakBool = false;
            if (suItemsToSuggest[i].SuggGrpName == ro.app.Store.Menu.Groups[j].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
   				for(var k=0; k<ro.app.Store.Menu.Groups[j].Items.length; k++){
	   				if(suItemsToSuggest[i].SuggItmName == 'all'){
	   					if(suItemsToSuggest[i].SuggSizeName && suItemsToSuggest[i].SuggSizeName.length && suItemsToSuggest[i].SuggSizeName != 'all' && ro.app.Store.Menu.Groups[j].Items[k].HasSizes){
							var found = false;
	   						var szLength = ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes && ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes.length ? ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes.length : 0;
	   						for(var m=0; m<szLength; m++){
                                if (ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes[m].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == suItemsToSuggest[i].SuggSizeName){
	   								found = true;
	   								break;
	   							}
	   						}//endfor m
	   						if(!found){
	   							continue;
	   						}
	   					}
						sugg = {};
	   					sugg = {
	   						SuggStyleName:suItemsToSuggest[i].SuggStyleName,
				   			SuggSizeName:suItemsToSuggest[i].SuggSizeName,
				   			IsPromotional:suItemsToSuggest[i].IsPromotional,
				   			Priority:suItemsToSuggest[i].Priority
				   		};

	   					suggItemsToReturn.push(combineItem(JSON.parse(JSON.stringify(ro.app.Store.Menu.Groups[j].Items[k])), JSON.parse(JSON.stringify(sugg)), j, k));
	   				}
                    else {                                
                        if (suItemsToSuggest[i].SuggItmName == ro.app.Store.Menu.Groups[j].Items[k].Name.replace(/[^a-zA-Z0-9]/g,'').toLowerCase()){
	   						if(suItemsToSuggest[i].SuggSizeName && suItemsToSuggest[i].SuggSizeName.length && suItemsToSuggest[i].SuggSizeName != 'all' && ro.app.Store.Menu.Groups[j].Items[k].HasSizes){                                
                                var found = false;
		   						var szLength = ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes && ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes.length ? ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes.length : 0;                                
                                for (var m = 0; m < szLength; m++){
                                    if (ro.app.Store.Menu.Groups[j].Items[k].AvailableSizes[m].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == suItemsToSuggest[i].SuggSizeName){
		   								found = true;
		   								break;
		   							}
		   						}//endfor m
		   						if(!found){
		   							continue;
		   						}
		   					}
	   						sugg = {};
	   						sugg = {
	   							SuggStyleName:suItemsToSuggest[i].SuggStyleName,
					   			SuggSizeName:suItemsToSuggest[i].SuggSizeName,
					   			IsPromotional:suItemsToSuggest[i].IsPromotional,
					   			Priority:suItemsToSuggest[i].Priority
					   		};

	   						suggItemsToReturn.push(combineItem(JSON.parse(JSON.stringify(ro.app.Store.Menu.Groups[j].Items[k])), JSON.parse(JSON.stringify(sugg)), j, k));
	   						breakBool = true;
	   						break;
	   					}
	   				}//endelse
	   			}//endfor k
	   			if(breakBool){
	   				break;
	   			}
   			}//endif
   		}//endfor j
   	}//endfor i
    //Ti.API.info('suggItemsToReturn: ' + JSON.stringify(suggItemsToReturn));
    //Ti.API.info('SU.SUGG_MAX: ' + SU.SUGG_MAX);
   	if(suggItemsToReturn.length > SU.SUGG_MAX){
			return suggItemsToReturn.splice(0, SU.SUGG_MAX);
   	}
   	else{
   		return JSON.parse(JSON.stringify(suggItemsToReturn));
   	}
   };

   var testSuite = function(){
   	var passedTheseTests = function(){
   		var test = [{//passed this test
   			SuggItmName:'all',
	   		SuggGrpName:'pizza',
	   		SuggSizeName:'jr pizza',
	   		SuggStyleName:'all',
	   		IsPromotional:true,
	   		Priority:0,
	   		SuggCartItms:[{
	   			SuggCartItmName:'all',
	   			SuggCartGrpName:'all'
	   		}]
	   	}];
	   	var testTwo = [{//passed this test
   			SuggItmName:'all',
	   		SuggGrpName:'pizza',
	   		SuggSizeName:'jr pizza',
	   		SuggStyleName:'all',
	   		IsPromotional:false,
	   		Priority:0,
	   		SuggCartItms:[{
	   			SuggCartItmName:'all',
	   			SuggCartGrpName:'all'
	   		}]
	   	}];
	   	var testThree = [{//passed this test
   			SuggItmName:'all',
	   		SuggGrpName:'pizza',
	   		SuggSizeName:'jr pizza',
	   		IsPromotional:true,
	   		Priority:0,
	   		SuggCartItms:[{
	   			SuggCartItmName:'all',
	   			SuggCartGrpName:'all'
	   		}]
	   	}];
	   	var testFour = [{//passed this test
   			SuggItmName:'all',
	   		SuggGrpName:'pizza',
	   		SuggSizeName:'all',
	   		SuggStyleName:'Regular',
	   		IsPromotional:false,
	   		Priority:0,
	   		SuggCartItms:[{
	   			SuggCartItmName:'all',
	   			SuggCartGrpName:'all'
	   		}]
	   	}];
   	};
   	var suggItem = function(){
   		var test = [{//passed this test
   			SuggItmName:'all',
	   		SuggGrpName:'pizza',
	   		SuggSizeName:'JR PIZZA',
	   		SuggStyleName:'Regular',
	   		IsPromotional:false,
	   		Priority:0,
	   		SuggCartItms:[{
	   			SuggCartItmName:'all',
	   			SuggCartGrpName:'all'
	   		}]
	   	}];

   		return test;
   	};
   	var suggCol = [], thisSuggItem;
   	suggCol = new suggItem();
   	/*var newPriority = SU.SUGG_MAX;
   	for(var i=0; i<=SU.SUGG_MAX; i++){
   		thisSuggItem = new suggItem();

   		thisSuggItem.Priority = newPriority;
   		suggCol.push(thisSuggItem);
   		newPriority--;
   	}*/
   	return suggCol;
   };
   
   var SUGG_MOD_MSG;
	var SUGG_STY_MSG;
	var SUGG_STY_DISC; 
   	var SUGG_MOD_DISC;
   	var SUGG_ITM_HDR;
   	var SUGG_ITM_BTN_NO;
    var SUGG_ITM_BTN_YES;
    var SUGG_ITEMS_MSG, SUGG_ITEMS_DISC, SUGG_ITEMS_HDR;
    var SuggItmOptsToSuggest = [];
    var SelectedSuggIndex;
    var SuggGrpName = ""; // only used for item level suggesstions
    var SuggRowData = [];
   var SuggsToAdd = {
   	  0:[],
   	  1:[]
   };
   //var SuggsToAdd = [];
   var GetStyleDispName = function(group, styNm){
   	  if(!group || !group.Styles || !group.Styles.length) return "";
   	  
   	  for(var i=0, iMax=group.Styles.length; i<iMax; i++){
        if (group.Styles[i].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == styNm){
   	  		//Ti.API.debug('group.Styles[i]: ' + JSON.stringify(group.Styles[i]));
   	  		return group.Styles[i].DisplayName; 
   	  	}
   	  }
   },
   GetModProps = function(group,modNm, itemName){
   	var returnObj = {
   	   "DisplayName": "",
   	   "IsPresel": false	
   	};
   	 //Ti.API.info(modNm + ' : IsPresel Check');
   	 if(!group || !group.Mods || !group.Mods.length) return returnObj;
   	  
   	  for(var i=0, iMax=group.Mods.length; i<iMax; i++){
        if (group.Mods[i].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == modNm){
   	  		//Ti.API.debug('group.Mods[i]: ' + JSON.stringify(group.Mods[i]));
   	  		returnObj.DisplayName = group.Mods[i].DisplayName;   	  		
   	  	}
   	  }
   	 
   	  for (var i=0; i<group.Items.length;i++){
   	  	if (group.Items[i].Name == itemName){   	  		
   	  		if (group.Items[i].PreMods && group.Items[i].PreMods.length > 0){
   	  			for (var j=0; j< group.Items[i].PreMods.length; j++){
                    if (group.Items[i].PreMods[j].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == modNm){   	  					
   	  					returnObj.IsPresel = true;
   	  					//Ti.API.info(modNm + ' : IsPresel True');
   	  					break;
   	  				}
   	  			}
   	  		}
   	  		break;
   	  	}
   	  }
   	  return returnObj;
   },
   CheckForMatchingSuggItmOpts = function(currentItem, currGroup){
   	Ti.API.info('CHECKING FOR MATCHING SUGG ITM OPTS');
   	    SuggItmOptsToSuggest = [];
   	    SuggsToAdd = {
		   0:[],
		   1:[]
       };
       SuggGrpName = "";
   		if(!ro.app.Store || !ro.app.Store.Configuration) return false;
   		if(!ro.app.Store.Configuration.ALLOW_SUGG) return false;
   		if(!ro.app.Store.SuggItems || !ro.app.Store.SuggItems.length) return false;
   		var store = ro.app.Store;
   		SUGG_MOD_MSG = store.Configuration.SUGG_MOD_MSG && store.Configuration.SUGG_MOD_MSG.length ? store.Configuration.SUGG_MOD_MSG : "";
       SUGG_STY_MSG = store.Configuration.SUGG_STY_MSG && store.Configuration.SUGG_STY_MSG.length ? store.Configuration.SUGG_STY_MSG : "";
       SUGG_ITEMS_MSG = store.Configuration.SUGG_ITEMS_MSG && store.Configuration.SUGG_ITEMS_MSG.length ? store.Configuration.SUGG_ITEMS_MSG : "";
   	    
   	    SUGG_STY_DISC = store.Configuration.SUGG_STY_DISC && store.Configuration.SUGG_STY_DISC.length ? store.Configuration.SUGG_STY_DISC : "";
       SUGG_MOD_DISC = store.Configuration.SUGG_MOD_DISC && store.Configuration.SUGG_MOD_DISC.length ? store.Configuration.SUGG_MOD_DISC : "";
       SUGG_ITEMS_DISC = store.Configuration.SUGG_ITEMS_DISC && store.Configuration.SUGG_ITEMS_DISC.length ? store.Configuration.SUGG_ITEMS_DISC : "";

       SUGG_ITM_HDR = store.Configuration.SUGG_ITM_HDR && store.Configuration.SUGG_ITM_HDR.length ? store.Configuration.SUGG_ITM_HDR : "WOULD YOU LIKE TO UPGRADE?";
       SUGG_ITEMS_HDR = store.Configuration.SUGG_ITEMS_HDR && store.Configuration.SUGG_ITEMS_HDR.length ? store.Configuration.SUGG_ITEMS_HDR : "WOULD YOU LIKE TO UPGRADE?";

       SUGG_ITM_BTN_NO = store.Configuration.SUGG_ITM_BTN_NO && store.Configuration.SUGG_ITM_BTN_NO.length ? store.Configuration.SUGG_ITM_BTN_NO : "NO, THANKS";
   	    SUGG_ITM_BTN_YES = store.Configuration.SUGG_ITM_BTN_YES && store.Configuration.SUGG_ITM_BTN_YES.length ? store.Configuration.SUGG_ITM_BTN_YES : "YES, PLEASE";
   		
   		var foundMatchinhgSuggItmOpts = false;
   		var SuggItems = ro.app.Store.SuggItems;
   		var foundSugg = false;
   		var stillValid = false;       
       for (var i = 0, iMax = SuggItems.length; i < iMax; i++){
           //Ti.API.info(i);
   			foundSugg = false;
   			stillValid = false;
   			if(!SuggItems[i].SuggItmOpts || !SuggItems[i].SuggItmOpts.length) continue;
   			
   			
   			if(SuggItems[i].SuggGrpName == 'all'){
   				foundSugg = true;
   			}
   			//else if(SuggItems[i].SuggGrpName.toLowerCase() == currentItem.GroupName.toLowerCase()){
            else if (SuggItems[i].SuggGrpName == currentItem.GroupName.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
   				//Ti.API.debug('FOUND MATCHING SUGGITeM : ' + JSON.stringify(SuggItems[i]) );
   				if(SuggItems[i].SuggItmName == 'all'){
   					foundSugg = true;
   				}
                else if (SuggItems[i].SuggItmName == currentItem.Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
   					foundSugg = true;
   				}
   				
   			}            
   			if(foundSugg){
   				
                var suggItmOpts = SuggItems[i].SuggItmOpts && SuggItems[i].SuggItmOpts.length ? SuggItems[i].SuggItmOpts : [];
                SuggGrpName = SuggItems[i].SuggGrpName;
	   			for(var j=0, jMax=suggItmOpts.length; j<jMax; j++){
                    stillValid = true;                            
	   				switch(suggItmOpts[j].Type){
	   					case 0:
	   						//Ti.API.debug('case0 ');
	   						suggItmOpts[j].DispName = GetStyleDispName(currGroup, suggItmOpts[j].Name);
	   						//Ti.API.debug('suggItmOpts[j].DispName: ' + suggItmOpts[j].DispName);
	   						
                            if (currentItem.Style.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == suggItmOpts[j].Name){
		   						stillValid = false;
		   						break;//breaks from K loop
		   					}
		   					else{
		   						stillValid = false;
		   						var styles = currGroup.Styles && currGroup.Styles.length ? currGroup.Styles : [];
		   						for(var l=0, lMax=styles.length; l<lMax; l++){
		   							//stillValid = false;
                                    if (styles[l].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == suggItmOpts[j].Name){
		   								var sizes = styles[l].Sizes && styles[l].Sizes.length ? styles[l].Sizes : [];
			   							stillValid = false;
			   							if(sizes.length){
			   								stillValid = false;
			   								//Ti.API.debug('currentItem.Size.toLowerCase(): ' + currentItem.Size.toLowerCase());
			   								for(var m=0, mMax=sizes.length; m<mMax; m++){
			   									//Ti.API.debug('sizes['+m+']: ' + JSON.stringify(sizes[m]));
                                                if (sizes[m].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == currentItem.Size.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()){
			   										stillValid = true;
			   										break;
			   									}
			   								}
			   								if(stillValid){
			   									break;
			   								}
			   							}
			   							else{
			   								stillValid = true;
			   								break;
			   							}
		   							}
		   							
		   						}
		   					}
	   						break;
	   					case 1:
	   						//Ti.API.debug('case1 ');
	   							   						
	   						var modObj = GetModProps(currGroup, suggItmOpts[j].Name, currentItem.Name);
	   						suggItmOpts[j].DispName = modObj.DisplayName;
	   						suggItmOpts[j].IsPresel = modObj.IsPresel;
	   						
	   						
	   						if (currentItem.Mods && currentItem.Mods.length > 0){
	   						   for(var k=0, kMax=currentItem.Mods.length; k<kMax; k++){
                                    if (currentItem.Mods[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == suggItmOpts[j].Name){
	   									stillValid = false;
	   									break;//breaks from K loop
	   								}
	   							}	
	   						} 						
	   						
                            break;
                        case 2:
                            //Ti.API.info("pushing stuff: " + JSON.stringify(suggItmOpts[j]));
                            //continue;            
                            break;
	   					default:
	   						//Ti.API.debug('case default ');
	   						stillValid = false;
	   						break;
	   					
	   				}
	   				if(stillValid){
	   					SuggItmOptsToSuggest.push(suggItmOpts[j]);
	   					//SuggItmOptsToSuggest[SuggItmOptsToSuggest.length - 1].DispName = GetModDispName(group, suggItmOpts[j].Name);
	   				}
                }
                //Ti.API.info('SuggItmOptsToSuggest: ' + JSON.stringify(SuggItmOptsToSuggest));                
                return SuggItmOptsToSuggest && SuggItmOptsToSuggest.length;
   			}
   			
   		}
   		Ti.API.debug('return foundMatchinhgSuggItmOpts: ' + foundMatchinhgSuggItmOpts);
   		return foundMatchinhgSuggItmOpts;
   },
   HHOfferSuggestion = function(_callback, passthroughIndex, sizeName, group){
   		if(!SuggItmOptsToSuggest || !SuggItmOptsToSuggest.length) {_callback(passthroughIndex); return; };
        
   	  	var suggItmOptWin = layoutMenuHelper.modalSuggWin();
   	  	suggItmOptWin.addEventListener('close', function(){
   	  		_callback(passthroughIndex);
			ro.App.openWindows.pop();
   	  		suggItmOptWin = null;
   	  	});
	    
	    var cancelTxt = SUGG_ITM_BTN_NO;
	    var confirmTxt = SUGG_ITM_BTN_YES;
	    var suggViewBtnBar = getBigButtonBar(cancelTxt, confirmTxt);
	    
	    
	    var consolidatedStyleSuggs = [];
	    var consolidatedModSuggs = [];
        var ItemsLst = [];
       var data = [];
       var isItemSugg = SuggItmOptsToSuggest[0].Type == 2 && SuggGrpName != ""; 
       if (isItemSugg) { 
           
           for (var x = 0; x < ro.app.Store.Menu.Groups.length; x++) {
               if (ro.app.Store.Menu.Groups[x].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggGrpName) {                   
                   var idx = 0; // we can use y for below for loop, but its better to count the list in case of descrepency
                   for (var y = 0; y < SuggItmOptsToSuggest.length; y++) {                       
                       for (var z = 0; z < ro.app.Store.Menu.Groups[x].Items.length; z++) {                           
                           if (ro.app.Store.Menu.Groups[x].Items[z].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggItmOptsToSuggest[y].Name) {
                               var SuggItm = ro.app.Store.Menu.Groups[x].Items[z];
                               SuggItm.SuggIndex = idx++;
                               ItemsLst.push(SuggItm);
                               break;
                           }
                       }                       
                   }
                   break;
               }
           }
           if (ItemsLst.length) {
               data.push(subMenuHeaders({ text: SUGG_ITEMS_MSG, disclaimerTxt: SUGG_ITEMS_DISC, leftRightBool: true }));
           }
           if (GetItemSuggsView(ItemsLst)) {
               for (var d = 0; d < SuggRowData.length; d++)
               data.push(SuggRowData[d]);
           }
           //data = GetItemSuggsView(ItemsLst); 
       }
       else {
           for (var i = 0, iMax = 1; i <= iMax; i++) {	//0 and 1 for styles and mods
               switch (i) {
                   case 0:
                       for (var j = 0, jMax = SuggItmOptsToSuggest.length; j < jMax; j++) {
                           if (SuggItmOptsToSuggest[j].Type == 0) {
                               consolidatedStyleSuggs.push(SuggItmOptsToSuggest[j]);
                           }
                       }
                       if (consolidatedStyleSuggs.length) {
                           var suggType = 0; // STYLES
                           var suggRow = HHGetSuggRow(consolidatedStyleSuggs, SUGG_STY_MSG, SUGG_STY_DISC, suggType);
                           data.push(suggRow);
                       }
                       break;
                   case 1:

                       for (var j = 0, jMax = SuggItmOptsToSuggest.length; j < jMax; j++) {
                           if (SuggItmOptsToSuggest[j].Type == 1) {
                               consolidatedModSuggs.push(SuggItmOptsToSuggest[j]);
                           }
                       }
                       if (consolidatedModSuggs.length) {
                           var suggType = 1; // MODS	    				
                           var suggRow = HHGetSuggRow(consolidatedModSuggs, SUGG_MOD_MSG, SUGG_MOD_DISC, suggType);
                           data.push(suggRow);
                       }
                       break;
               }
           }
       }      

		var suggTblHdr = Ti.UI.createLabel({
            text: isItemSugg ? SUGG_ITEMS_HDR:SUGG_ITM_HDR,
           textAlign:'center',
	      	 top:ro.ui.relY(15),
    	      font:{
        	     fontSize:ro.ui.scaleFont(35, 0, 0),
            	 //fontWeight:'bold',
	             fontFamily:ro.ui.fonts.titles
    	      },
        	  height:Ti.UI.SIZE,
	          width:Ti.UI.FILL,
    	      color:ro.ui.theme.backgroundpngTxt
        });
        
	    var suggView = Ti.UI.createScrollView({
	   	 	backgroundColor:'white',
	    	layout:'vertical',
			//top:ro.ui.properties.topAfterNavbar + ro.ui.relY(15),
            top: ro.ui.relY(75),
            bottom: ro.ui.relY(75),
			left:ro.ui.relX(10),
			right:ro.ui.relX(10),
			height:Ti.UI.SIZE,
			borderRadius:ro.ui.relX(10),
			zIndex:6,
			elevation:10,
            translationZ: 10
        });
       var suggWarning = Ti.UI.createLabel({
           text: "Please make your selection",
           color: ro.ui.theme.itemPriceColor,
           top: 0,
           height: 0,
           font: {
               fontSize: ro.ui.scaleFont(20, 0, 0),
               fontWeight:'bold',
               fontFamily: ro.ui.fonts.titles
           },
           visible: false
       });       
       suggView.add(suggTblHdr);
       //suggWarningHolder.add(suggWarning);
        //suggView.add(suggWarningHolder);
        suggView.add(data);
	    var submitBtn = HHGetSuggButton(confirmTxt);
	    submitBtn.left = ro.ui.relX(15);
	    var cancelBtn = HHGetSuggButton(cancelTxt);
	    //cancelBtn.left = ro.ui.relX(5);
	    
       submitBtn.addEventListener('click', function () {
           if (isItemSugg) {
               if (!SelectedSuggIndex && SelectedSuggIndex !== 0) {
                   suggWarning.visible = true;
                   suggWarning.height = Ti.UI.SIZE;
                   suggWarning.top = ro.ui.relY(5);
                   return;
               }
               ro.itemObj.ResetItem(ItemsLst[SelectedSuggIndex]);
               SuggRowData = [];
               SelectedSuggIndex = null;
           } else {
               for (var i = 0, iMax = 1; i <= iMax; i++) {// 0 and 1 for types of sugg 0 = style and 1 = mod
                   if (SuggsToAdd[i] && SuggsToAdd[i].length) {
                       switch (i) {
                           case 0:
                               for (var j = 0, jMax = SuggsToAdd[i].length; j < jMax; j++) {//Should only ever be size of 0 or 1
                                   for (var k = 0, kMax = group.Styles.length; k < kMax; k++) {
                                       if (group.Styles[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggsToAdd[i][j].SuggName) {
                                           if (group.HasSizes && sizeName && sizeName.length && sizeName.toLowerCase() != 'none') {
                                               ro.itemObj.setStyles(k);
                                               ro.itemObj.setSizes(sizeName);
                                               ro.itemObj.setStyles(k);
                                           }
                                           else {
                                               ro.itemObj.setStyles(k);
                                           }
                                           break;
                                       }
                                   }
                               }
                               break;
                           case 1:

                               for (var j = 0, jMax = SuggsToAdd[i].length; j < jMax; j++) {
                                   for (var k = 0, kMax = group.Mods.length; k < kMax; k++) {
                                       if (group.Mods[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggsToAdd[i][j].SuggName) {
                                           var qty = 1;
                                           if (SuggsToAdd[i][j].IsPresel) {
                                               qty = 2;
                                           }
                                           ro.itemObj.setMods(group.Mods[k].Name, 0, SuggsToAdd[i][j].IsPresel, qty);
                                           break;
                                       }
                                   }
                               }
                               var itemObj = ro.itemObj.getItemObj();
                               if (itemObj.Mods) {
                                   ro.itemObj.ModPropFill(itemObj.Mods);
                               }
                               break;
                       }
                   }
               }
           }
	       suggItmOptWin.close();
	    });
       suggView.add(Ti.UI.createView(ro.ui.properties.greyBorder));
       suggView.add(suggWarning);
	    var buttonView = Ti.UI.createView({
	    	top:ro.ui.relY(5),
            height:Ti.UI.SIZE,
            width:Ti.UI.SIZE,
            layout:'horizontal'
        });
	    buttonView.add(cancelBtn);
		buttonView.add(submitBtn);
		
		suggView.add(buttonView);
       cancelBtn.addEventListener('click', function () {
           SuggRowData = [];
           SelectedSuggIndex = null;
	       suggItmOptWin.close();
	    });
       suggItmOptWin.children[0].layout = 'composite';       
		suggItmOptWin.children[0].add(suggView);
		ro.App.openWindows.push(suggItmOptWin);
	    suggItmOptWin.open();
   },
   OLDHHOfferSuggestion = function(_callback, passthroughIndex, sizeName, group){
   		if(!SuggItmOptsToSuggest || !SuggItmOptsToSuggest.length) {_callback(passthroughIndex); return; };
   		
   	  	var suggItmOptWin = layoutMenuHelper.modalSuggWin();
   	  	suggItmOptWin.addEventListener('close', function(){
   	  		_callback(passthroughIndex);
			ro.App.openWindows.push(suggItmOptWin);
   	  		suggItmOptWin = null;
   	  	});
	    
	    var cancelTxt = SUGG_ITM_BTN_NO;
	    var confirmTxt = SUGG_ITM_BTN_YES;
	    var suggViewBtnBar = getBigButtonBar(cancelTxt, confirmTxt);
	    
	    
	    var consolidatedStyleSuggs = [];
	    var consolidatedModSuggs = [];

	    var data = [];
	    
	    for(var i=0, iMax=1; i<=iMax; i++){	//0 and 1 for styles and mods
	    	switch(i){
	    		case 0:
	    			for(var j=0, jMax=SuggItmOptsToSuggest.length; j<jMax; j++){
	    				if(SuggItmOptsToSuggest[j].Type == 0){
	    					consolidatedStyleSuggs.push(SuggItmOptsToSuggest[j]);
	    				}
	    			}
	    			if(consolidatedStyleSuggs.length){
	    				var suggType = 0; // STYLES
	    				var suggRow = HHGetSuggRow(consolidatedStyleSuggs, SUGG_STY_MSG, SUGG_STY_DISC, suggType);
	    				data.push(suggRow);
	    			}
	    			break;
	    		case 1:
	    			
	    			for(var j=0, jMax=SuggItmOptsToSuggest.length; j<jMax; j++){
	    				if(SuggItmOptsToSuggest[j].Type == 1){
	    					consolidatedModSuggs.push(SuggItmOptsToSuggest[j]);
	    				}
	    			}
	    			if(consolidatedModSuggs.length){
	    				var suggType = 1; // MODS
	    				var suggRow = HHGetSuggRow(consolidatedModSuggs, SUGG_MOD_MSG, SUGG_MOD_DISC, suggType);
	    				data.push(suggRow);
	    			}
	    			break;
	    	}
	    }

         
        
	    var suggTbl = Ti.UI.createScrollView({
			width:Ti.UI.FILL,
			layout:'vertical',
			//separatorColor:ro.ui.theme.separatorColor,
			height:Ti.UI.SIZE,
			backgroundColor:ro.ui.theme.tableBgColor,
			visible:true
		});
		var suggTblHdr = menuHeaders({text:SUGG_ITM_HDR, leftRightBool:true});
		
		suggTbl.add(suggTblHdr);     

        for (var i = 0, iMax = itemData.length; i < iMax; i++) {
           suggTbl.add(itemData[i]);
		}

	    var suggView = Ti.UI.createView({
	    	layout:'vertical',
			top:ro.ui.relY(25),
			left:ro.ui.relX(10),
			right:ro.ui.relX(10),
			height:Ti.UI.SIZE,
			zIndex:6
	    });
	    suggView.add(suggTbl);
	    suggItmOptWin.children[0].add(suggView);
	    
	    suggViewBtnBar.children[0].addEventListener('click', function(){
	    	suggItmOptWin.close();
	    });
	    suggViewBtnBar.children[1].addEventListener('click', function(){
	    	
	       for(var i=0, iMax=1; i<=iMax; i++){// 0 and 1 for types of sugg 0 = style and 1 = mod
	       	//Ti.API.debug('SuggsToAdd[i]: ' + JSON.stringify(SuggsToAdd[i]));
	       		if(SuggsToAdd[i] && SuggsToAdd[i].length){
	       			switch(i){
	       				case 0:
	       					for(var j=0, jMax=SuggsToAdd[i].length; j<jMax; j++){//Should only ever be size of 0 or 1
	       						for(var k=0, kMax=group.Styles.length; k<kMax; k++){
                                    if (group.Styles[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggsToAdd[i][j].SuggName){
	       								if(group.HasSizes && sizeName && sizeName.length && sizeName.toLowerCase() != 'none'){
	       									//Ti.API.debug('k: ' + k);
	       									setStyles(k);
	       									setSizes(sizeName);
	       									setStyles(k);
	       								}
	       								else{
	       									setStyles(k);
	       								}
	       								break;
	       							}
	       						}
	       					}
	       					break;
	       				case 1:
	       				
	       					for(var j=0, jMax=SuggsToAdd[i].length; j<jMax; j++){
	       						//Ti.API.debug('SuggsToAdd[i][j]: ' + SuggsToAdd[i][j]);
	       						for(var k=0, kMax=group.Mods.length; k<kMax; k++){
	       							//Ti.API.debug('kMod: ' + k);
	       							//Ti.API.debug('group.Mods[k].Name: ' + group.Mods[k].Name);
                                    if (group.Mods[k].Name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() == SuggsToAdd[i][j].SuggName){
	       								//Ti.API.info('kKKKKKKMod: ' + k);
	       								//Ti.API.debug('group.Mods[k].Name: ' + group.Mods[k].Name);
	       								//Ti.API.debug('group.Mods[6]: ' + JSON.stringify(group.Mods[6]));
	       								var qty = 1;	       								
	       								if (SuggsToAdd[i][j].IsPresel){
	       									qty = 2;
	       								}
	       								setMods(group.Mods[k].Name, 0, SuggsToAdd[i][j].IsPresel, qty);
	       								break;
	       							}
	       						}
	       					}
	       					var itemObj = ro.itemObj.getItemObj();
	       					if (itemObj.Mods) {
                            		ro.itemObj.ModPropFill(itemObj.Mods);
                        		}
	       					break;
	       			}
	       		}
	       }
	    	
	       suggItmOptWin.close();
	    });
	    suggItmOptWin.children[0].add(Ti.UI.createView({
	    	height:ro.ui.relY(10),
	    	width:Ti.UI.FILL,
	    	backgroundColor:'white',
	    	left:ro.ui.relX(10),
		  	right:ro.ui.relX(10)
	    }));
	    suggItmOptWin.children[0].add(suggViewBtnBar);
		ro.App.openWindows.push(suggItmOptWin);
	    suggItmOptWin.open();
   },
   HHGetSuggRow = function(suggs, headerTxt, disclaimerTxt, suggType){
   		var HdrText = headerTxt;
   		var disclaimerTxt = disclaimerTxt;
   		
		var row = Ti.UI.createView({
			height:Ti.UI.SIZE,
			width:Ti.UI.FILL,
			layout:'vertical',
			isRow:true,
			SuggType:suggType,
			top:ro.ui.relY(15)
		});
     	var SuggLabel = subMenuHeaders({text:HdrText, disclaimerTxt:disclaimerTxt, leftRightBool:true});
     	row.add(SuggLabel);
     	
     	var suggDisplayName = "";
     	var isDefault = false;
     	var isPresel = false;
     	//Ti.API.debug('suggs.length: ' + suggs.length);
     	//Ti.API.info('suggs: ' + JSON.stringify(suggs));
     	for(var i=0, iMax=suggs.length; i<iMax; i++){
     		suggDisplayName = suggs[i].DispName && suggs[i].DispName.length ? suggs[i].DispName : suggs[i].Name;
     		/*if(suggs.length == 1){
     		    isDefault = true;
     		}*/
     		
     		isDefault = (i == 0);
     		isPresel = suggs[i].IsPresel;
     		var suggBox = HHGetSuggBoxes(suggDisplayName, suggs[i].Name, suggType, isDefault, isPresel);
     		row.add(suggBox);
     		row.add(Ti.UI.createView({
		    	height:ro.ui.relY(10),
		    	width:Ti.UI.FILL,
		    	backgroundColor:'white',
		    	left:ro.ui.relX(10),
			  	right:ro.ui.relX(10)
		  	}));
     	}
   		return row;
   },
   HHGetSuggBoxes = function(boxText, name, suggType, isDefault, isPresel){
   		var box = Ti.UI.createView({
   			top:ro.ui.relY(20),
   			height:ro.ui.relY(60),
   			borderRadius:ro.ui.relY(30),
   			borderColor:'#e4e4e4',
   			borderWidth:ro.ui.relX(2),
   			width:ro.ui.relX(250),
   			backgroundColor:'white',
   			SuggName:name,
   			IsPresel: isPresel,
   			IsSelected:false,
   			SuggType: suggType
   		});
   		
   		box.add(Ti.UI.createLabel({
   			height:Ti.UI.FILL,
   			width:Ti.UI.FILL,
   			text:boxText,
   			color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
   			textAlign:'center',
   			font:{
				fontSize:ro.ui.scaleFont(23),
				fontFamily:ro.ui.fonts.button
			}
   		}));
   		box.addEventListener('click', function(){
   			if(box.IsSelected){
   				//unselect
   				box.backgroundColor = 'white';
   				box.borderColor = "#e4e4e4";
   				box.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
   				box.IsSelected = false;
   				
				function isStillValid(value) {
				  return value.SuggName != box.SuggName;
				}
				SuggsToAdd[box.SuggType] = SuggsToAdd[box.SuggType].filter(isStillValid);
   			}
   			else{
   				//select
   				box.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
   				box.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
   				box.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
   				box.IsSelected = true;
   				//Ti.API.info('BOX ISPRESEL: ' + box.SuggName + '  ' + box.IsPresel);
   				SuggsToAdd[box.SuggType].push({"SuggName": box.SuggName,"IsPresel": box.IsPresel});
   			}
   		});
   		
   		if(isDefault){
   		    box.fireEvent('click');
   		}
   		return box;
   },
   HHGetSuggButton = function(btnTxt){
   	  var largerText = true;
   	  var submitBtn = ro.layout.getMediumButton(btnTxt, largerText);
   	  //submitBtn.top = ro.ui.relY(40);
   	  submitBtn.top = ro.ui.relY(10);
   	  submitBtn.bottom = ro.ui.relY(10);
   	  
   	  return submitBtn;
   },
   GetItemSuggsView = function(itemList){
       SuggRowData = [];
       var itmLength = itemList.length;
       for (var i = 0; i < itmLength; i += 2) {
           if (i + 1 < itmLength) {
               SuggRowData.push(addNewItemRow(itemList[i], itemList[i + 1]));
           }
           else {
               SuggRowData.push(addNewItemRow(itemList[i], null));
           }
       }
       return true;
   },
   addNewItemRow = function (item1, item2) {
       var thisRow = Ti.UI.createView({
           layout: 'horizontal',
           width: Ti.UI.FILL,
           height: Ti.UI.SIZE,
           top: 0,
           backgroundColor: ro.ui.theme.menuItemRowColors.altBackground,
           name: "thisRow"
       });
       var itemName1 = item1.DisplayName || item1.ReceiptName || item1.Name;
       var itemName2 = item2.DisplayName || item2.ReceiptName || item2.Name;
       var itemName = itemName1 > itemName2 ? itemName1 : itemName2;
       var isLongName = itemName && itemName.length > 20;       
       thisRow.add(createBtns(item1, isLongName));
       if (item2) {
           thisRow.add(createBtns(item2, isLongName));
       }       
       return thisRow;
   },
   createBtns = function (itm, isLongName) {       
       var priceVal =  0
       for (var i = 0; i < itm.AvailableSizes.length; i++) {
           var selSize = ro.itemObj.getSize();           
           if (itm.AvailableSizes[i].Name == selSize) {
               priceVal = itm.AvailableSizes[i].Price;
               break;
           }
       }
       var rowView, rowImg, label;
       var imagePath = itm.defImg ? itm.defImg : ro.ui.properties.defaultPath + 'default.png';
       var theRow = Ti.UI.createView({           
           width: '50%',
           height: Ti.UI.SIZE,           
           borderWidth: "0.9%",
           isTheRow: true,
           name: itm.Name,
           //backgroundColor: 'black',
           top: 0
       });

       rowView = Ti.UI.createView({           
           //name: itm.Name,
           //label: itm.Name,
           height: Ti.UI.SIZE,
           top: ro.ui.relY(3),
           bottom: ro.ui.relY(3),
           right: ro.ui.relX(1),
           left: ro.ui.relX(1),
           width: Ti.UI.FILL,           
           SuggIndex: itm.SuggIndex,
           layout: 'vertical',
           //backgroundColor: 'purple'
       });

       var imgHolder = Ti.UI.createView({
           top: ro.ui.relX(5),           
           height: Ti.UI.SIZE,//'95%',           
           width: '95%',
           label: itm.Name,           
           touchEnabled: false,
           //backgroundColor: 'green'
       });

       rowImg = Ti.UI.createImageView({           
           image: itm.ImageSource,
           defaultImage: imagePath,
           label: itm.Name,           
           left: ro.ui.relX(10),
           right: ro.ui.relX(10),
           height: Ti.UI.SIZE,
           //bottom: ro.ui.relY(75),
           touchEnabled: false,
           //backgroundColor: 'blue'
       });
       var itemName = itm.DisplayName || itm.ReceiptName || itm.Name;       
       label = Ti.UI.createLabel({
           text: itemName && itemName.length ? itemName.toUpperCase() : itemName,
           width: Ti.UI.FILL,
           height: isLongName? ro.ui.relY(60) : ro.ui.relY(30),
           textAlign: 'center',
           color: ro.ui.theme.newGroupsBtnTxt,
           font: {
               fontSize: ro.ui.scaleFontY(24, 14),               
               fontFamily: ro.ui.fonts.titles
           },
           touchEnabled: false
       });       
       var price = Ti.UI.createLabel({
           text: "$" + priceVal,
           font: {
               fontFamily: ro.ui.fonts.prices.newItemsView,
               fontSize: ro.ui.scaleFont(20),
               //fontWeight:'bold'
           },
           color: ro.ui.theme.itemPriceColor,
           touchEnabled: false
       });
       
       var btnHolder = Ti.UI.createView({
           height: Ti.UI.SIZE,
           touchEnabled: false
       });
       var btn = ro.layout.getSmallButton("Select");
       btn.top = 0;
       btnHolder.add(btn);
       rowView.addEventListener('click', function () {                     
           if (SelectedSuggIndex >= 0) {
               SuggRowData[Math.floor(SelectedSuggIndex / 2)].children[SelectedSuggIndex % 2].children[0].children[2].children[0].backgroundColor = 'white';
               SuggRowData[Math.floor(SelectedSuggIndex / 2)].children[SelectedSuggIndex % 2].children[0].children[2].children[0].borderColor = "#e4e4e4";
               SuggRowData[Math.floor(SelectedSuggIndex / 2)].children[SelectedSuggIndex % 2].children[0].children[2].children[0].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;               
           }
           rowView.children[2].children[0].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
           rowView.children[2].children[0].borderColor = ro.ui.theme.sizeBtnBlockBgActive;
           rowView.children[2].children[0].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;           
           SelectedSuggIndex = rowView.SuggIndex;
       });
       var descView = Ti.UI.createView({
           //bottom: ro.ui.relY(2),
           layout: 'vertical',
           height: Ti.UI.SIZE,
           bottom: ro.ui.relY(5)
       });
       imgHolder.add(rowImg);
       rowView.add(imgHolder);
       descView.add(label);
       descView.add(price);       
       rowView.add(descView);
       rowView.add(btnHolder);
       
       theRow.add(rowView);
       //return rowView;   

       return theRow;
   },
   getBigButtonBar = function(cancelTxt, confirmTxt){
	   var borderRadius = null;
	   if(Ti.App.RoundedButtons){
	   	  borderRadius = ro.ui.relX(125);
	   }
	   var thisBtnBar = Ti.UI.createView({
	   	  top:0,
	      height:ro.ui.relY(40),
	      width:Ti.UI.FILL,
	      left:ro.ui.relX(10),
		  right:ro.ui.relX(10),
	      backgroundColor:'white',
	      //borderColor:ro.ui.theme.bigBtnBorder,
		  borderRadius:borderRadius,
	      //borderWidth:ro.ui.relX(1),
	      //layout:'horizontal'
	   });
	   
	   var cancelBtn, confirmBtn;
	   
	   cancelBtn = Ti.UI.createView({
	   	width:'49.5%',
	   	left:'0',
	   	height:Ti.UI.FILL,
	   	backgroundColor:ro.ui.theme.sizeBtnBlockBgDefault
	   	//left:0
	   });
	   cancelBtn.add(Ti.UI.createLabel({
	   	height:Ti.UI.FILL,
	   	width:Ti.UI.FILL,
	   	textAlign:'center',
	   	text:cancelTxt,
	   	color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
	   	font:{
	         fontSize:ro.ui.scaleFont(16),
	         fontFamily:ro.ui.fontFamily
	    }
	   }));	   
	   
	   confirmBtn = Ti.UI.createView({
	   	width:'49.5%',
	    right:0,
	   	backgroundColor:ro.ui.theme.sizeBtnBlockBgDefault,
	   	height:Ti.UI.FILL//,
	   	//right:0
	   });
	   confirmBtn.add(Ti.UI.createLabel({
	   	height:Ti.UI.FILL,
	   	width:Ti.UI.FILL,
	   	textAlign:'center',
	   	text:confirmTxt,
	   	color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
	   	font:{
	         fontSize:ro.ui.scaleFont(16),
	         fontFamily:ro.ui.fontFamily
	    }
	   }));
	   
	   /*thisBtn.add(Ti.UI.createLabel({
	      text:ttl?ttl.toUpperCase() : ttl,
	      font:{
	         fontWeight:'bold',
	         fontSize:ro.ui.scaleFont(20),
	         fontFamily:ro.ui.fontFamily
	      },
	      color:ro.ui.theme.bigBtnTxt,
	      textAlign:'center'
	   }));*/
	   
	   thisBtnBar.add(cancelBtn);
	   thisBtnBar.add(confirmBtn);
	   return thisBtnBar;
	};
	var subMenuHeaders = function(e){
		try{
			var hdrTxt = e.text;
			var disclaimerTxt = e.disclaimerTxt;
			if(!hdrTxt){
				hdrTxt = '';
			}
			if(!disclaimerTxt){
				disclaimerTxt = '';
			}
			//hdrTxt = hdrTxt.toUpperCase();
			var lft = ro.ui.relX(10);
			var rgt = ro.ui.relX(10);
			if(e.leftRightBool){
			   lft = 0;
			   rgt = 0;
			}
	
			var hdrView = Ti.UI.createView({
				layout:'vertical',
				width:Ti.UI.FILL,
				right:rgt,
				left:lft,
				height:5,
				//backgroundColor:e.backgroundColor?e.backgroundColor:ro.ui.theme.headerBackgroundColor,
				backgroundColor:'white',
				//borderColor:e.borderColor?e.borderColor:ro.ui.theme.headerBorderColor,
				//borderWidth:ro.ui.relX(1),
				iAm:'view',
				isHeader:true
			});
			//alert('e.txtClr: ' + e.txtClr);
			//alert('ro.ui.theme.headerTitleTxt: ' + ro.ui.theme.headerTitleTxt);
			//alert("e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt: " + e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt);
			var hdrLbl = Ti.UI.createLabel({
				text:hdrTxt,
				height:ro.ui.relY(30),
				color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
				font:{
					fontSize:e.smallerFont ? ro.ui.scaleFont(15) : ro.isiOS ? ro.ui.scaleFont(17) : ro.ui.scaleFont(19),
					//fontWeight:'bold',
					fontFamily:ro.ui.fonts.rowBodyTxt
				},
				textAlign:'center',
				//left:ro.ui.relX(5),
				touchEnabled:false,
				iAm:'label',
				isHeader:true
			});
			hdrView.add(hdrLbl);
			hdrView.height += hdrLbl.height;
			
			if(disclaimerTxt && disclaimerTxt.length){
				//hdrView.height += ro.ui.relY(30);
				var disclaimerLbl = Ti.UI.createLabel({
					text:disclaimerTxt,
					height:ro.ui.relY(20),
					top:0,
					color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
					font:{
						fontSize:ro.ui.scaleFont(16)
						//fontWeight:'bold',
						//fontFamily:ro.ui.fonts.rowBodyTxt
					},
					textAlign:'center',
					//left:ro.ui.relX(5),
					touchEnabled:false,
					iAm:'label',
					isHeader:true
				});
				hdrView.add(disclaimerLbl);
				hdrView.height += disclaimerLbl.height;
			}
			
		}
		catch(ex){
			if(false){ Ti.API.debug('menuHeaders()-Exception: ' + ex); }
		}
		return hdrView;
	};
	var menuHeaders = function(e){
		try{
			var hdrTxt = e.text;
			if(!hdrTxt){
				hdrTxt = '';
			}
			hdrTxt = hdrTxt.toUpperCase();
			var lft = ro.ui.relX(10);
			var rgt = ro.ui.relX(10);
			if(e.leftRightBool){
			   lft = 0;
			   rgt = 0;
			}
	
			var hdrView = Ti.UI.createView({
				width:Ti.UI.FILL,
				right:rgt,
				left:lft,
				height:ro.ui.relY(50),
				backgroundColor:e.backgroundColor?e.backgroundColor:ro.ui.theme.headerBackgroundColor,
				//borderColor:e.borderColor?e.borderColor:ro.ui.theme.headerBorderColor,
				//borderWidth:ro.ui.relX(1),
				iAm:'view',
				isHeader:true
			});
			//alert('e.txtClr: ' + e.txtClr);
			//alert('ro.ui.theme.headerTitleTxt: ' + ro.ui.theme.headerTitleTxt);
			//alert("e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt: " + e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt);
			var hdrLbl = Ti.UI.createLabel({
				text:hdrTxt,
				color:e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt,
				font:{
					fontSize:e.smallerFont ? ro.ui.scaleFont(13) : ro.ui.scaleFont(20),
					fontWeight:'bold',
					fontFamily:ro.ui.fontFamily
				},
				textAlign:'center',
				//left:ro.ui.relX(5),
				touchEnabled:false,
				iAm:'label',
				isHeader:true
			});
			hdrView.add(hdrLbl);
		}
		catch(ex){
			if(false){ Ti.API.debug('menuHeaders()-Exception: ' + ex); }
		}
		return hdrView;
	};


   return {
      init: init,
      needsSuggestion: needsSuggestion,
      getItems: getItems,
      resetModule: resetModule,
      
      CheckForMatchingSuggItmOpts: CheckForMatchingSuggItmOpts,
      
      HHOfferSuggestion: HHOfferSuggestion
   };
}();
module.exports = Suggest;