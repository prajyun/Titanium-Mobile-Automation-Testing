var CARDSCANNER = function(){
   var cardScan = {
      
   },
   cardio,
   Init = function(){
      try{
         cardio = require('com.likelysoft.cardio');
      }
      catch(ex){
         Ti.API.debug('CardScanner.Init()-Exception: ' + ex);
      }
   },
   getCardScanControl = function(rs, _callback){
      var btnScan = layoutHelper.getBigButton('SCAN NEW CARD');
      if(rs && rs.length){
         btnScan.top = ro.ui.contentsTop;
      }
      else{
         btnScan.top = ro.ui.halfContentsTop;
      }
      //delete btnScan.bottom;
      btnScan.bottom = null;
      btnScan.addEventListener('click', function(){
          cardio.scanCard(function(data){
            if(data.success == 'true') {
               Ti.API.debug('data.success: ' + JSON.stringify(data));
               
               Ti.API.debug("Card number: " + data.cardNumber);
               //Ti.API.debug("Redacted card number: " + data.redactedCardNumber);
               Ti.API.debug("Expiration month: " + data.expiryMonth);
               Ti.API.debug("Expiration year: " + data.expiryYear);
               Ti.API.debug("CVV code: " + data.cvv);
               
               var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
               data.cardNumber = data.cardNumber.replace(/ /g,'');
               var customer = JSON.parse(Ti.App.Properties.getString('Customer'));
               if(!customer){
                  customer = {};
               }
               
               Ti.include('/logic/creditCard.js');
               var cardType = ValidateCC(data.cardNumber);
               if(cardType !== 'invalid'){
                  cardType = cardType.toUpperCase();
               }
               
               var values = {
                  ccNum:data.cardNumber,
                  ccName:customer.FirstName + ' ' + customer.LastName,
                  expMonth:monthList[data.expiryMonth-1],
                  expYear:data.expiryYear,
                  cvvNum:data.cvv,
                  ccType:cardType
               };
               if(!rs || !rs.length){
                  values.ccDefault = true;
               }
               
               Ti.include('/validation/creditcardValidation.js');
               if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
               //var values = forms.getValues(form);
               var success = credCardVal.credCardValidate(ro.combine(values, {addNew:1}), rs);
               if(success.value){
                  /*if(success.cardType){
                     values.ccType = success.cardType;
                  }*/
                  Ti.include('/validation/regexValidation.js');
                  success = regexVal.regExValidate(values);
                  if(success.value){
                     Ti.include('/controls/ccControl.js');
                     var rowid = ccControl.saveNewCard(ccControl.createCardObj(values));
                     if(rowid != -1){
                        if(values.ccDefault){
                           ccControl.setDefaultCard(rowid);
                        }
                           //ro.ui.alert('Success:', 'Credit Card has been saved!');
                           //ro.ui.settingsShowNext({showing:'addCardBtn'});
                        _callback();
                     }
                     else{
                        ro.ui.alert('Error: ', 'Card was not saved');
                        ro.ui.hideLoader();
                     }
                  }
                  else{
                     ro.ui.alert('Error', success.issues[0]);
                     ro.ui.hideLoader();
                  }
               }
               else{
                  ro.ui.alert('Error', success.issues[0]);
                  ro.ui.hideLoader();
               }
            }
            else{
               Ti.API.debug('data.success is false: ' + JSON.stringify(data));
                // User canceled or there was an error
            }
         });
      });
      return btnScan;
   };
   return {
      Init: Init,
      getCardScanControl: getCardScanControl
   };
}();
module.exports = CARDSCANNER;