var REV_ADS = function(){
   var SHOW_ADS = false,	//Kisok boolean used to determine if app is Kiosk mode or not.
   IS_ANDROID = true,
   cfg = null,
   ADS_TO_SHOW = [],
   ALREADY_SHOWN = false,
   DEMO_ADS_LENGTH = 0,
   init = function(){
   	  var promos = null;
   	  promos = [];
   	  if(false){
   	  	 ADS_TO_SHOW = null;
   	  	 ADS_TO_SHOW = [];
   	  	 var adObj = {
   	  	 	url:''
   	  	 };
   	  	 
   	  	 DEMO_ADS_LENGTH = 6;
   	  	 
   	  	 //ADS_TO_SHOW.push(adObj);
   	  }
   	  else{
   	  	 //cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  	 ////deb.ug(cfg, 'cfg');
   	  	 promos = JSON.parse(Ti.App.Properties.getString('promos', '{}'));
   	  	 
   	  	 ADS_TO_SHOW = null;
   	  	 ADS_TO_SHOW = [];
   	  	 ADS_TO_SHOW = getAdsToShow(promos);
   	  	 var adObj = {
   	  	 	url:''
   	  	 };
   	  	 
   	  	 DEMO_ADS_LENGTH = ADS_TO_SHOW;
   	  }
   },
   getAdsToShow = function(promos){
   	  var foundAds = []; 
   	  for(var i=0, iMax=promos&&promos.length?promos.length:0; i<iMax; i++){
   	  	 if(promos[i].Promo && (parseInt(promos[i].Promo.PromoType, 10) == 0)){//(!promos[i].Promo.PromoCode || !promos[i].Promo.PromoCode.length)){
   	  	 	foundAds.push(promos[i]);
   	  	 }
   	  }
   	  return foundAds;
   },
   isImageAd = function(ad){
   	  //if(ad.ContentType.toLowerCase() == 'image/jpeg')
   	  //return ((ad.ContentType.toLowerCase() == 'image/jpeg') || (ad.ContentType.toLowerCase() == 'image/png'));
   	  
   	  //var str = "Hello world, welcome to the universe.";
	  //var n = str.includes("world"); 
   	  //Ti.API.debug('ad.ContentType.toLowerCase().includes(image): ' + (ad.ContentType.toLowerCase().toString().includes('image')));
   	  //Ti.API.debug('ad.ContentType.toLowerCase().includes(omage): ' + (ad.ContentType.toLowerCase().toString().includes('omage')));
   	  //Ti.API.debug('ad: ' + JSON.stringify(ad));
   	  var imageString = "image";
   	  var omageString = 'omage';
   	  //Ti.API.debug('ad.ContentType.toLowerCase().indexOf('+imageString+'): ' + (ad.ContentType.toLowerCase().indexOf("image")));
   	  //Ti.API.debug('ad.ContentType.toLowerCase().indexOf('+omageString+'): ' + (ad.ContentType.toLowerCase().indexOf("omage")));
   	  return (ad.ContentType && ad.ContentType.length ? (ad.ContentType.toLowerCase().indexOf("image") !== -1) : 0);
   	  //return ad.ContentType.toLowerCase().toString().includes('image');
   },
   showAds = function(){
   	  return (!ALREADY_SHOWN && ADS_TO_SHOW && ADS_TO_SHOW.length) || Ti.App.dev;
   },
   getImageAd = function(theAd, isFirstAd){
   	  var adDict = {}, adLabelDict;
   	  if(IS_ANDROID){
   	  	 adDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL,
   	  	 	urlSet:false,
   	  	 	defaultImage:'/images/loading.png'
   	  	 };
   	  	 adLabelDict = {
   	  	 	color:'white',
   	  	 	font:{
   	  	 		fontSize:ro.ui.scaleFont(30)
   	  	 	},
   	  	 	textAlign:'center'
   	  	 };
   	  }
   	  else{
   	  	adDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL,
   	  	 	urlSet:false
   	  	 };
   	  	 adLabelDict = {
   	  	 	color:'white',
   	  	 	font:{
   	  	 		fontSize:30
   	  	 	},
   	  	 	textAlign:'center'
   	  	 };
   	  }
   	  
   	  if(Ti.App.dev && (!ADS_TO_SHOW || !ADS_TO_SHOW.length)){
   	  	 adLabelDict.text = 'Ad Page ' + adNumber;
   	  	 var ad = Ti.UI.createView(adDict);
	   	 ad.add(Ti.UI.createLabel(adLabelDict));
	   	 return ad;
   	  }
   	  else{
   	  	 var ad = Ti.UI.createImageView(adDict);
   	  	 if(isFirstAd){
   	  	 	ad.urlToSet = theAd.URL;
   	  	 	ad.image = theAd.URL;
   	  	 	ad.urlSet = true;
   	  	 }
   	  	 else{
   	  	 	ad.urlToSet = theAd.URL;
   	  	 }
   	  	 
   	  	 return ad;
   	  }
   },
   getAdWin = function(_cb){
   	  var adWinDict = {}, bgViewDict = {}, scrollableAdViewDict = {}, closeViewDict, closeBtnDict;
   	  if(IS_ANDROID){
   	  	 adWinDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  	 closeViewDict = {
   	  	 	height:ro.ui.relX(60),
   	  	 	top:0,
   	  	 	width:Ti.UI.FILL,
   	  	 	zIndex:1000
   	  	 };
   	  	 closeBtnDict = {
   	  	 	right:ro.ui.relX(5),
   	  	 	image:'/images/closeBtn.png',
   	  	 	zIndex:1000
   	  	 };
   	  	 bgViewDict = {
   	  	 	backgroundColor:'black',
   	  	 	opacity:.5,
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  	 scrollableAdViewDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  }
   	  else{
   	  	 adWinDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  	 closeViewDict = {
   	  	 	height:60,
   	  	 	top:0,
   	  	 	width:Ti.UI.FILL,
   	  	 	zIndex:1000
   	  	 };
   	  	 closeBtnDict = {
   	  	 	right:5,
   	  	 	image:'/images/closeBtn.png',
   	  	 	zIndex:1000
   	  	 };
   	  	 bgViewDict = {
   	  	 	backgroundColor:'black',
   	  	 	opacity:.5,
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  	 scrollableAdViewDict = {
   	  	 	height:Ti.UI.FILL,
   	  	 	width:Ti.UI.FILL
   	  	 };
   	  }
   	  
   	  var adWin = Ti.UI.createView(adWinDict);
   	  var closeView = Ti.UI.createView(closeViewDict);
   	  var closeBtn = Ti.UI.createImageView(closeBtnDict);
   	  closeBtn.addEventListener('click', function(){
   	  	 _cb();
   	  });
   	  closeView.add(closeBtn);
   	  
   	  
   	  var bgView = Ti.UI.createView(bgViewDict);
   	  adWin.add(bgView);
   	  adWin.add(closeView);
   	  
   	  var scrollableAdView = Ti.UI.createScrollableView(scrollableAdViewDict);
   	  var scrollPages = [];
   	  var adsLength = ADS_TO_SHOW && ADS_TO_SHOW.length ? ADS_TO_SHOW.length : 0;
   	  var ADS = ADS_TO_SHOW;
   	  
   	  for(var i=0, iMax=adsLength||DEMO_ADS_LENGTH; i<iMax; i++){
   	  	 if(isImageAd(ADS[i])){
   	     	scrollPages.push(getImageAd(ADS[i], (i===0)));
   	     }
   	     else{
   	     	Ti.API.debug('ISNT AN IMAGE AD');
   	     } 
   	  }
   	  
   	  scrollableAdView.views = scrollPages;
   	  
   	  scrollableAdView.addEventListener('click', function(){
   	  	 if((scrollableAdView.getCurrentPage() + 1) == scrollPages.length){
   	  	 	_cb();
   	  	 }
   	  	 else{
   	  	 	scrollableAdView.moveNext();
   	  	 	setTimeout(function(){
   	  	 		//Ti.API.debug('scrollableAdView.views[scrollableAdView.getCurrentPage()]: ' + JSON.stringify(scrollableAdView.views[scrollableAdView.getCurrentPage()]));
	   	  	 	//scrollableAdView.views[scrollableAdView.getCurrentPage()]
	   	  	 	if(!scrollableAdView.views[scrollableAdView.getCurrentPage()].urlSet){
	   	  	 		scrollableAdView.views[scrollableAdView.getCurrentPage()].image = scrollableAdView.views[scrollableAdView.getCurrentPage()].urlToSet;
	   	  	 		scrollableAdView.views[scrollableAdView.getCurrentPage()].urlSet = true;
	   	  	 	}
   	  	 	}, 100);
   	  	 }
   	  });
   	  adWin.add(scrollableAdView);
   	  ALREADY_SHOWN = true;
   	  return adWin;
   };
   return {
   	  init: init,
   	  showAds: showAds,
   	  getAdWin: getAdWin
   };
}();
module.exports = REV_ADS;