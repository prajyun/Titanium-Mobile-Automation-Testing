const { check } = require("./update");

var REV_UPDATE = function(){
   var osname = Ti.Platform.osname;
   var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;

   //var url = isiOS ? "https://itunes.apple.com/lookup?id="+iosid : "https://play.google.com/store/apps/details?id=com.hungerrush.hungryhowies&hl=en";
   var getCurrentStoreVersion = function(_callback){
	if(checkForUpdates()){
		ro.ui.popup('Update Available', ['OK'], 'Please update the app to be able to use it', function(e) {
			if(isiOS){
				Ti.Platform.openURL(Ti.App.appStoreURL);
		   	}
		   	else{
			   var goog_url = 'market://details?id=com.hungerrush.hungryhowies';// + Ti.App.REV_APP_ID;
			   Ti.API.info('Play Store URL: ' + goog_url);
			   Ti.API.info('App Store URL: ' + Ti.App.appStoreURL);
			   Ti.Platform.openURL(goog_url);
		   	}  
		}, function(){
			
		});		
	}else{
		Ti.API.info("called callback");
		_callback();
	}
   	
   };
   var checkForUpdates = function(){
   	   try{
			var cfg = Ti.App.Properties.getString('Config', '{}');
			cfg = JSON.parse(cfg);			
			var newStr = ro.isiOS ? cfg.MIN_APP_APPLE_VER : cfg.MIN_APP_ANDROID_VER;
			Ti.API.info("newSt: " + newStr);
   	   	   if(!newStr || !newStr.length) return false;
	   	   var APP_NEEDS_UPDATE = false;
	   	   
	   	   
	 	   var liveVersionNum = newStr.split('.');
		   var thisVersionNum = Ti.App.version.split('.');
			
		   var liveVersionNumLength = liveVersionNum.length;
		   var thisVersionNumLength = thisVersionNum.length;
		   if(!thisVersionNumLength || !liveVersionNumLength){
		   	  return false;
		   }
			
			for(var i=0, iMax=liveVersionNumLength>thisVersionNumLength ? thisVersionNumLength : liveVersionNumLength; i<iMax; i++){
				if(parseInt(thisVersionNum[i],10) < parseInt(liveVersionNum[i], 10)){
			  	   APP_NEEDS_UPDATE = true;
			       break;
			    }
			}
			
			if(!APP_NEEDS_UPDATE && (liveVersionNumLength > thisVersionNumLength)){
			    APP_NEEDS_UPDATE = true;
			}
   	   }
   	   catch(ex){
			Ti.API.info('checkForUpdates - Exception: ' + ex);
			APP_NEEDS_UPDATE = false;
   	   }
		
		return APP_NEEDS_UPDATE;
   };
   return {
      getCurrentStoreVersion: getCurrentStoreVersion
   };
}();
module.exports = REV_UPDATE;