const REV_UPDATE = require("./REV_UPDATE");

var REV_GUEST = function(){
	var guest = function(ro){
	   var guestOrder = {};
	   var acceptsGuestOrder = false;
	   var isGuestOrder = false;
	   var guestEmail;
	   var guestInfos = {};
	   
	   guestOrder.Init = function(){
	      //EVENTUALLY THIS CAN CHECK IF CONFIG.ALLOWGUEST (OR SOMETHING SIMILAR) THEN SET THE BOOLEAN ACCORDINGLY.
	      //BUT FOR NOW ITS JUST TRUE ALWAYS
	      acceptsGuestOrder = true;
	   };
	   guestOrder.getAcceptsGuestOrder = function(){
	      return acceptsGuestOrder;
	   };
	   function setIsGuestOrder(isGuestBln){
	      guestInfos = {};
	      isGuestOrder = isGuestBln;
	   }
	   guestOrder.setIsGuestOrder = setIsGuestOrder;
	   guestOrder.getIsGuestOrder = function(){
	      //Ti.API.debug('getIsGuestOrder(): ' + isGuestOrder);
	      return isGuestOrder;
	   };
	   guestOrder.getGuestOrderBtn = function(){
	      //var btn = layoutHelper.getBigButton('GUEST ORDER');
	      var guestBorderRadius = null;
		  if(Ti.App.RoundedButtons){
		   	 guestBorderRadius = ro.ui.relX(157.5);
		  }
	      /*var btn = Ti.UI.createView({
	         height:ro.ui.properties.ldfBool?ro.ui.relY(60):ro.ui.relY(50),
	         width:ro.ui.relX(330),
	         bottom:ro.ui.properties.ldfBool?ro.ui.relY(15):ro.ui.relY(10),
	         top:ro.ui.relY(5),
	         backgroundColor:ro.ui.theme.guestOrderBtnBackground,
	         borderColor:ro.ui.theme.guestOrderBtnBorder,
			 borderRadius:guestBorderRadius,
	         borderWidth:ro.ui.relX(1),
	         canClick:false
	      });
	      btn.add(Ti.UI.createLabel({
	         text:'GUEST ORDER',
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFont(20),
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.guestOrderBtnTxt,
	         textAlign:'center'
	      }));*/
	      var btn = ro.layout.getMediumButton('Guest Order');
	      //layoutHelper.animateBtn(btn, ro.ui.theme.loginBtnBackground, ro.ui.theme.btnDefault, 0, ro.ui.theme.loginBtnWhite, ro.ui.theme.btnTxtDefault, ro.ui.theme.btnActive, ro.ui.theme.btnBorderDefault);
	      btn.addEventListener('click', function(){
	      	 //return;
	      	 if(!btn.canClick){
	      	 	//Ti.API.debug('cant click');
	      	 	return;
	      	 }
	         ro.ui.showLoader();
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
	            ro.ui.alert('Login Failed', 'Internet connection is required to place an order. Please connect and try again.');
	            ro.ui.hideLoader();
	            return;
	         }
	         if(!Ti.Network.online){
	            ro.ui.alert('Login Failed', 'The network is not reachable to the internet.');
	            ro.ui.hideLoader();
	            return;
	         }
	
	         /*if(txtUname.value == '' || txtPass.value == ''){
	            ro.ui.alert( 'Login Failed', 'Please enter the login credentials');
	            return;
	         }
	         else{
	            login(txtUname.value, txtPass.value);
	         }*/
	         //login(txtUname.value, txtPass.value);
	         
	         setIsGuestOrder(true);
	         
	         REV_Suggest.resetModule();
	         Ti.App.TimeAtDefStore = null;
	         try{	         	
				 ro.REV_STORES.clearStore();
				 ro.REV_STORES.clearDefaultStore();
				 Ti.API.info("Resetting Customer");
				 Ti.App.Properties.setString('Customer', '{}');
	           	Ti.App.Username = '';
	            Ti.App.fireEvent('app:login.success');
	            ro.ui.hideLoader();
	         }
	         catch(ex){
	            ro.ui.hideLoader();
				Ti.API.info("Login Exception: " + JSON.stringify(ex));
	            ro.ui.alert('Login Exception');
	         }
	      });
	      return btn;
	   };
	   guestOrder.guestOrderValidate = function(obj){
	      var passed = {
	         value:0,
	         issues:[]
	      };
	      var errorString = '';
	
	      var nameObj = {
	         email:'Email',
	         firstname:'First name',
	         lastname:'Last name',
	         phone:'Phone number'
	      };
	
	      for(var itm in obj){
	         switch(itm){
	            case "email": case "firstname": case "lastname": case "phone":
	               if(!obj[itm]){
	                  errorString += '\n' + nameObj[itm] + ' must not be left blank.';
	               }
	               break;
	         }
	      }
	
	      if(errorString !== ''){
	         passed.issues.push(errorString);
	      }
	      else{
	         passed.value = 1;
	      }
	
	      return passed;
	   };
	   guestOrder.setGuestInfo = function(guestInfo){
	      /*if(!guestInfo){
	         if(Ti.App.Properties.hasProperty('guestinfo')){
	            Ti.App.Properties.removeProperty('guestinfo');
	         }
	         return;
	      }
	      Ti.App.Properties.setString('guestinfo', JSON.stringify(guestInfo));*/
	     ////deb.ug(guestInfo, 'guestInfo');
	     
	     var test = Ti.App.OrderObj;
	     //test.IsGuest = true;
	     if(!test.Customer){
	        test.Customer = {};
	     }
	     test.Customer.FName = guestInfo.firstname;
	     test.Customer.LName = guestInfo.lastname;
	     test.Customer.Email = guestInfo.email;
	     test.Customer.SelPhone = guestInfo.phone;
	     
	     guestInfos = {
	        FirstName: guestInfo.firstname,
	        LastName: guestInfo.lastname,
	        Email: guestInfo.email,
	        Phone: guestInfo.phone
	     };
	     
	     Ti.App.OrderObj = test;
	     test = null;
	     ////deb.ug(Ti.App.OrderObj, 'Ti.App.OrderObj');
	     ////deb.ug(Ti.App.OrderObj.Customer, 'Ti.App.OrderObj.Customer');
	   };
	   guestOrder.getGuestInfo = function(){
	      return guestInfos;
	   };
	   guestOrder.setGuestAddr = function(guestAddr){
	      if(!guestAddr){
	         if(Ti.App.Properties.hasProperty('guestaddr')){
	            Ti.App.Properties.removeProperty('guestaddr');
	         }
	         return;
	      }
	      //Ti.API.debug('guestAddr: ' + JSON.stringify(guestAddr));
	      Ti.App.Properties.setString('guestaddr', JSON.stringify(guestAddr));
	   };
	   guestOrder.hasSelectedAddress = function(){
	   	  var guestAddr = JSON.parse(Ti.App.Properties.getString('guestaddr'));
	      if(!guestAddr){
	      	return false;
	      }
	      else{
	      	return true;
	      }
	   };
	   guestOrder.setGuestAddrInOrderObj = function(){
	      var guestAddr = JSON.parse(Ti.App.Properties.getString('guestaddr'));
	      if(!guestAddr){
	         guestAddr = {};
	      }
	      //Ti.API.debug('.getGuestAddr(): ' + JSON.stringify(guestAddr));
	      //return guestAddr;
	      var test = Ti.App.OrderObj;
	      if(!test.Customer){
	         test.Customer = {};
	      }
	      test.Customer.CustType = guestAddr.AddrTypeName;
	      test.Customer.City = guestAddr.City;
	      test.Customer.State = guestAddr.State;
	      test.Customer.Zip = guestAddr.Zip;
	      test.Customer.Street = guestAddr.St;
	      test.Customer.StNum = guestAddr.StNum;
	      test.Customer.Apt = guestAddr.Sud;
	      test.Customer.Loc = guestAddr.CustAddrTypeName;
	      
	      Ti.App.OrderObj = test;
	      test = null;
	   };
	   guestOrder.setGuestEmail = function(gstEmail){
	      guestEmail = gstEmail;
	   };
	   guestOrder.getGuestEmail = function(){
	      return guestEmail;
	   };
	   ro.REV_GUEST_ORDER = guestOrder;
	};
	return {
		guest:guest
	};
}();
module.exports = REV_GUEST;