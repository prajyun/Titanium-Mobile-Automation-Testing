var REVMOBILE = function(){
	var createNamespace = function(ro){
		var ro = ro || {};
		
		
		
		//application state variables are held in this namespace.  
		//Like the current app window, for instance, which is created in app.js
		ro.app = ro.app || {};
		ro.app.isLogout = true;
		ro.app.isDemo = false;
		ro.app.Store = ro.app.Store || null;
		//ro.REV_STORES.clearStore(); //ro.app.Store = null;
		ro.app.isSelectedStore = false;
		
		//Extend an object with the properties from another 
		//(thanks Dojo - http://docs.dojocampus.org/dojo/mixin)
		var empty = {};
		function mixin(/*Object*/ target, /*Object*/ source){
			var name, s, i;
			for(name in source){
				s = source[name];
				if(!(name in target) || (target[name] !== s && (!(name in empty) || empty[name] !== s))){
					target[name] = s;
				}
			}
			return target; //Object
		};
		ro.mixin = function(/*Object*/ obj, /*Object...*/ props){
			if(!obj){ obj = {}; }
			for(var i=1, l=arguments.length; i<l; i++){
				mixin(obj, arguments[i]);
			}
			return obj; //Object
		};
		
		//create a new object, combining the properties of the passed objects with the last arguments having
		//priority over the first ones
		ro.combine = function(/*Object*/ obj, /*Object...*/ props) {
			var newObj = {};
			for(var i=0, l=arguments.length; i<l; i++){
				mixin(newObj, arguments[i]);
			}
			return newObj;
		};
		
		//OS, Locale, and Density specific branching helpers adapted from the Helium library
		//for Titanium: http://github.com/kwhinnery/Helium
		var locale = Ti.Platform.locale;
		var osname = Ti.Platform.osname;
		
		/*
			Branching logic based on locale
		*/
		ro.locale = function(/*Object*/ map) {
			var def = map.def||null; //default function or value
			if (map[locale]) {
				if (typeof map[locale] == 'function') { return map[locale](); }
				else { return map[locale]; }
			}
			else {
				if (typeof def == 'function') { return def(); }
				else { return def; }
			}
		};
	
		/*
			Branching logic based on OS
		*/
		ro.os = function(/*Object*/ map) {
			var def = map.def||null;//default function or value
			if(map[osname]){
				if(typeof map[osname] == 'function'){
					return map[osname]();
				}
				else{
					return map[osname];
				}
			}
			else{
				if(typeof def == 'function'){
					return def();
				}
				else{
					return def;
				}
			}
		};
		
		var UTILS = require("classes/utils");
		ro.utils = UTILS.utilities();
		
		var COUPONS = require("logic/coupons");
		ro.coupons = COUPONS.coupons();
		
		var DATASERVICE = require("classes/dataservice");
		DATASERVICE.dataservice(ro);
		
		var UI = require("revmobile/ui/ui");
		UI.getui(ro);
		
		var TABCTRL = require('controls/tabCtrl');
		TABCTRL.tabctrl(ro);
		
		var CUSTOMALERTVIEW = require('revmobile/ui/customAlertView');
		CUSTOMALERTVIEW.customalertview(ro);
		
		var PREVORDERS = require('logic/prevOrders');
		PREVORDERS.prevorders(ro);
			
		var cpnHelper = require('logic/couponHelper');
		cpnHelper.cpnhelper(ro);
		
		var ORDTYPESTK = require('revmobile/ui/ordTypeStk');
      	ORDTYPESTK.ordtypestk(ro);
      	
      	var SETTINGSSTK = require('revmobile/ui/settingsStk');
      	SETTINGSSTK.settingsstk(ro);
      	
      	var REWARDSSTK = require('revmobile/ui/rewardsStk');
      	REWARDSSTK.rewardsstk(ro);
      
      	var CARTSTK = require('revmobile/ui/cartStk');
      	CARTSTK.cartstk(ro);
		
		return ro;
	};
	return{
		createNamespace:createNamespace
	};
}();
module.exports = REVMOBILE;
//Ti.include('/classes/utils.js');
//Ti.include('/logic/coupons.js');
//Ti.include('/revmobile/ui/ui.js');