var GUESTDETAILS = function () {
    var guestdetails = function (ro) {
        ro.ui.createGuestDetailsView = function (_args) {
            var hid = 'guestDetails';
            var isCurbside = Ti.App.OrderObj.OrderTypeCategory.toLowerCase() == "curbside";            
            var mainView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.stretch, { name: 'Guest Details', hid: hid, layout: 'vertical' }));            
            var navBar = Ti.UI.createView(ro.ui.properties.navBar);

            var btnBack = layoutHelper.getBackBtn('CART');
            btnBack.addEventListener('click', function (e) {
                ro.ui.cartShowNext({ showing: hid });
            });
            navBar.add(btnBack);

            //var forms = require('/revmobile/ui/forms');


            //Ti.include('/formControls/guestOrderForm.js');
            var forms = ro.forms;
            var guestOrderForm = require('formControls/guestOrderForm');
            var regexVal = require('validation/regexValidation');

            var form = forms.createForm({
                style: forms.STYLE_LABEL,
                fields: guestOrderForm.getGuestOrderForm(),
                settings: ro.ui.properties.myAccountView
            });
            //var gstInfo = ro.REV_GUEST_ORDER.getGuestInfo();
            //Ti.API.debug('gstInfo: ' + JSON.stringify(gstInfo));
            form.setFields(ro.REV_GUEST_ORDER.getGuestInfo());
            form.top = ro.ui.relY(20);
            form.bottom = ro.ui.relY(20);
            form.height = Ti.UI.SIZE;
            var btnSubmit = layoutHelper.getBigButton('CONTINUE TO CHECKOUT');
            btnSubmit.addEventListener('click', function () {
                ro.ui.showLoader();
                //Ti.include('/validation/guestOrderValidation.js');
                if (!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
                var values = forms.getValues(form);
                var success = ro.REV_GUEST_ORDER.guestOrderValidate(values);
                if (isCurbside) {
                    var vhclInfo = ro.forms.getValues(carForm);
                    var validate = require("validation/vehicleValidation");
                    var vehicleSuccess = validate.vehicleValidate(vhclInfo);
                    if (!success.issues[0]) success.issues[0] = '';
                    success.issues[0] += '\n' + vehicleSuccess.issues[0];
                }
                if (success.value && ((isCurbside && vehicleSuccess.value) || !isCurbside)) {
                    //Ti.include('/validation/regexValidation.js');
                    
                    success = regexVal.regExValidate(values);
                    if (success.value) {
                        ro.REV_GUEST_ORDER.setGuestInfo(values);
                        ro.REV_GUEST_ORDER.setGuestEmail(values.email);

                        if (Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                            ro.REV_GUEST_ORDER.setGuestAddrInOrderObj();//sets the address for delivery orders in the order object
                            //Ti.API.debug('newAddr: ' + JSON.stringify(newAddr));
                        }
                        if (isCurbside) {
                            Ti.App.Properties.setString('guestVhclInfo', JSON.stringify(vhclInfo));
                        }

                        ro.ui.cartShowNext({ addView: true, showing: 'paymentScreen' });
                    }
                    else {
                        ro.ui.alert('Error', success.issues[0]);
                        ro.ui.hideLoader();
                    }
                }
                else {
                    ro.ui.alert('Error', success.issues[0]);
                    ro.ui.hideLoader();
                }
            });

            //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            if (ro.isiphonex) {
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            }
            else {
                mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            }
            mainView.add(ro.layout.getGuestInfoRowHeader('Personal Information'));            
            if (isCurbside) {
                var vhclForm = require('formControls/vehicleForm');
                var carForm = ro.forms.createForm({
                    style: ro.forms.STYLE_LABEL,
                    fields: vhclForm.getVhclForm({ formType: 3 }),
                    settings: ro.ui.properties.myAccountView
                });
                carForm.top = ro.ui.relY(20);
                carForm.bottom = ro.ui.relY(5);
                carForm.height = Ti.UI.SIZE;
                var guestVhclInfo = JSON.parse(Ti.App.Properties.getString('guestVhclInfo'));
                if (!guestVhclInfo) {
                    guestVhclInfo = {};
                }
                carForm.setFields(guestVhclInfo);
                carForm.container.add(btnSubmit);
                mainView.add(form);
                mainView.add(ro.layout.getGuestInfoRowHeader('Curbside Vehicle Information'));
                mainView.add(carForm);
            } else {
                form.container.add(btnSubmit);
                mainView.add(form);
            }

            return mainView;
        };
    };
    return {
        guestdetails: guestdetails
    };
}();
module.exports = GUESTDETAILS;