var LOADING = function(){
	var loading = function(ro){
		ro.ui.isLoading = null;
		ro.ui.showLoader = null;
		ro.ui.hideLoader = null;
		ro.ui.createLoadingView = function(_args){
			var loadingView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch,{
				visible:false
			})),
			backdrop = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
				backgroundColor:'#787878',
				opacity:0.85
			})),
			loader = Ti.UI.createActivityIndicator({
				message:'Loading...',
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFont(26),
	               fontFamily:ro.ui.fontFamily
				},
				visible:true,
				width:Ti.UI.SIZE,
				height:Ti.UI.SIZE,
				style:Ti.UI.ActivityIndicatorStyle.BIG
			});
			if(ro.isiOS){
				loader.color = 'white';
			}
	
			loadingView.add(backdrop);
			loadingView.add(loader);
	
			ro.ui.isLoading = function(){
			   return loadingView.visible;
			};
	
			ro.ui.showLoader = function(){
				//Ti.API.debug('ro.ui.showLoader()');
				if(!loadingView.visible){
				   //setTimeout(
						//function(){
						   loadingView.visible = !loadingView.visible;
						   loadingView.show();
						   //loader.show();
				   		//},
				  // 100);//500
				}
	
			};
			ro.ui.hideLoader = function(){
				//Ti.API.debug('ro.ui.hideLoader()');
				if(loadingView.visible){
					if(ro.isiOS){
						
				   		setTimeout(
							function(){
								//loader.hide();
						   		loadingView.visible = !loadingView.visible;
						   		loadingView.hide();
						    },
						600);//500
					}
					else{
						setTimeout(
							function(){
								//loader.hide();
						   		loadingView.visible = !loadingView.visible;
						   		loadingView.hide();
						    },
						300);//500
					}
					
				}
	
			};
			return loadingView;
		};
	};
	return {
		loading:loading
	};
}();
module.exports = LOADING;