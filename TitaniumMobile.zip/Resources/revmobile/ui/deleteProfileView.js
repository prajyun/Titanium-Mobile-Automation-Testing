var DELPROFILEVIEW = function(){
	var delprofileview = function(ro){
	
	   var rs = {};
	   ro.ui.createDeleteProfileView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      var forms = ro.forms;
	      //Ti.include('/formControls/profileForm.js');
	      var delProfileForm = require('formControls/delProfileForm');
	      var regexVal = require('validation/regexValidation');
		  var delProfileVal = require('validation/delProfileValidation');
		  
	      rs = ro.db.getCustObj(Ti.App.Username);
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:delProfileForm.getDelProfileForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'profile', hid:'profile', layout: 'vertical'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      
	
	      var btnBack = layoutHelper.getBackBtn('PROFILE');
	      btnBack.addEventListener('click', function(e){
	      	ro.GlobalPicker.hidePicker(); 
	      	ro.ui.settingsShowNext({showing:'delprofile'});
	      });
	      navBar.add(btnBack);
	
		  var warning = Ti.UI.createLabel(ro.combine(ro.ui.properties.settingsTxt, {
				text:'Deleting your account will permanently delete all records of your account and your account will not be recoverable. All coupons, rewards, order history and preferences will be permanently deleted. Are you sure you want to delete your account?'
			}));

	      var btnDelete = layoutHelper.getBigButton('Delete Account');
	      //btnUpdate.top = ro.ui.relY(15);
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnDelete);
		  
		btnDelete.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         ro.GlobalPicker.hidePicker();
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
			 Ti.API.info("Form Values: " + JSON.stringify(values));	
	         var success = delProfileVal.delProfileValidate(values, rs);
			 Ti.API.info("Success :  " + JSON.stringify(success));
	         if(success.value){
	            success = regexVal.regExValidate(values);
	            if(success.value){	            	
	            	Ti.API.info('values: ' + JSON.stringify(values));
					ro.ui.popup('Alert', ['No', 'Yes'], 'Are you sure you want to delete your account?', function(e) {
                        formRequest(values);
                    });	               
	                	               
	            }
	            else{
	               ro.ui.alert('Error: ', success.msg);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.msg);
	            ro.ui.hideLoader();
	         }
	      });
	
			var Config = JSON.parse(Ti.App.Properties.getString('Config'));
			if(!Config){
				Config = {};
			}
			var Cst = JSON.parse(Ti.App.Properties.getString('Customer'));
			if(!Cst){
				Cst = {};
			}     
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}			
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Confirm Information for Deletion", true);
	      hdr.bottom = ro.ui.relY(10);
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      mainView.add(warning);
	      mainView.add(form);
			//form.bottom = ro.ui.relY(70);	
			form.top = ro.ui.relY(10);
			form.container.add(btnWrapper);
	
	      return mainView;
	   };

	   function formRequest(profileChanges){
	      var req = {};
	
	      req.Email = Ti.App.Username;
	      req.FirstName = profileChanges['firstname'];
	      req.LastName = profileChanges['lastname'];
	      req.Phone = profileChanges['phone'];

		  var Config = JSON.parse(Ti.App.Properties.getString('Config', {}));

		  if(Config && Config.CompanyName){
			req.Company = Config.CompanyName;
		  }else{
			req.Company = '';
		  }

		  Ti.API.info("Request for Delete Profile: " + JSON.stringify(req));
	
	      contactServer(req);
	   }
	   function contactServer(req){
		ro.ui.showLoader();
		  ro.dataservice.postAPI(req, "SubmitDeleteRequest", function (response) {
			Ti.API.info("Delete Profile Response: " + JSON.stringify(response));
			if (response.Success) {				
				ro.ui.alert('Success', 'Account Deletion Request Received. Please allow up to 90 days for this request to be completed. You will receive an email confirmation once completed and account will no longer be accessible from the website or app.');				
				ro.ui.popup('Success', ['Ok'], response.Message, function(e) {
					ro.ui.ordShowNext({ showing:'ordTypeView' });
					ro.ui.hideLoader();
				});
				                            

			} else {
				ro.ui.alert("Error", response.Message);
				ro.ui.hideLoader();                            
			}
		});
	   }	   
	};
	return {
		delprofileview:delprofileview
	};
}();
module.exports = DELPROFILEVIEW;