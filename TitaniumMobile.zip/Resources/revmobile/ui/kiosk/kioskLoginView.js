(function(){
   ro.ui.createLoginView = function(_args){
      var defaultCustomer = db.getDefaultCustomer();
      var remember = true;

      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, { name:'login', layout:'vertical' }));
      var loginView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView, {
         height:Ti.UI.SIZE,
         layout:'vertical'
      }));

      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
      if(ro.ui.theme.bannerImg){
         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
         navBar.add(headerImg);
      }
      else{
         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Login'}));
         navBar.add(headerLbl);
      }

      mainView.add(navBar);
      mainView.add(loginView);
      var data = [];

      function login(username, pass){

          var storeObj = null;
          var req = {};

          req.UserName = username;
          req.Password = pass;
          req.RevKey = 'test';
          req.Version = '';
          req.StoreID = 0;
          req.CompressResponse = false;

          ro.ui.showLoader();
          try{
              var isDemo = false;
              if(false && username == 'demo@revention.com'){
                  //username = 'demo@revention.com';
                  //pass = 'test';
                  
                  //req.UserName = username;
                  //req.Password = pass;
                  
                  //var file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, 'demo.json');
                  //var contents = file.read();
                  //storeObj = eval('(' + contents.text + ')');
                  req.StoreID = storeObj.ID;
                  req.Version = storeObj.Version;
                  req.IsDemo = true;
                  isDemo = true;
                  //Ti.App.Properties.setString('DefaultStore', contents.text);
                  ro.REV_STORES.setDefaultStore(JSON.parse(contents.text));
                  
              }

              if(Ti.App.Properties.hasProperty('DefaultStore') && !isDemo){
                  storeObj = ro.REV_STORES.getDefaultStore();
                  req.StoreID = storeObj.ID;
                  req.Version = storeObj.Version;
                  req.IsDemo = false;
              }
          }
          catch(ex){
             if(Ti.App.DEBUGBOOL) { Ti.API.debug('loginView-Exception: ' + ex); }
             req.StoreID = 0;
             req.Version = '';
          }

          ro.dataservice.post(req, 'cLogin_Json', function(response){
             if(response){
                if(response.Value){
                   
                   /*var test = Ti.App.OrderObj;
                   if(!test){
                      test = {};
                   }
                   test.OrdType = null;
                   test.ordOnlineOptions = {};
                   test.ordOnlineOptions.IsDelivery = false;
                   test.Customer = {};
                   Ti.App.OrderObj = test;
                   test = null;*/

                   REV_Suggest.resetModule();

                   Ti.App.TimeAtDefStore = null;
                   var storeID = req.StoreID;

                   if(response.Store){
                      //Ti.App.Properties.setString('DefaultStore', JSON.stringify(response.Store));
                      ro.REV_STORES.setDefaultStore(response.Store);
                      storeID = response.Store.ID;
                      if(response.Store.Configuration){
                         Ti.App.Properties.setString('Config', JSON.stringify(response.Store.Configuration));
                      }
                   }
                   if(response.Config){
                      Ti.App.Properties.setString('Config', JSON.stringify(response.Config));
                   }
                   if(response.CustomerInfo){
                      if(response.CustomerInfo.CpnUsage){
                         Ti.App.CpnUsageString = response.CustomerInfo.CpnUsage.split("-");
                      }
                      else{
                         Ti.App.CpnUsageString = [];
                      }

                      Ti.App.Properties.setString('Customer', JSON.stringify(response.CustomerInfo));
                      Ti.App.PrevOrders = response.CustomerInfo.PrevOrders;
                      Ti.App.LastOrdCnt = response.CustomerInfo.LastOrdCnt;

                      if(!isDemo && response.CustomerInfo.TimeAtDefaultStore){
                        Ti.App.TimeAtDefStore = response.CustomerInfo.TimeAtDefaultStore;
                      }

                      if(db.getCustomer(username) != null){
                         db.updateCustomer(username, req.Password, storeID, response.CustomerInfo, remember);
                      }
                      else{
                         db.createCustomer(username, pass, storeID, response.CustomerInfo, remember);
                      }

                      if(!isDemo && !response.Store){
                         if(response.CustomerInfo.Business_ID == 0 || (response.CustomerInfo.Business_ID !== req.StoreID)){
                            //ro.utils.removeProp('DefaultStore');
                            ro.REV_STORES.clearDefaultStore();
                         }
                      }
                   }
                   /*else{
                      Ti.App.CpnUsageString = null;
                      Ti.App.PrevOrders = null;
                      Ti.App.LastOrdCnt = null;
                      Ti.App.TimeAtDefStore = null;
                   }*/

                   Ti.App.Username = username;
                   Ti.App.Password = pass;

                   try{
                      Ti.App.fireEvent('app:login.success');
                   }
                   catch(ex){
                      ro.ui.hideLoader();
                      ro.ui.alert('login.success ', ex);
                   }
                }
                else{
                   ro.ui.hideLoader();
                   ro.ui.alert('Login Failed', response.Message);
                }
             }
             else{
                ro.ui.hideLoader();
                ro.ui.alert('Login Failed', 'Error occured. CODE:100.');
             }
          });
      }

      data[0] = Ti.UI.createTableViewRow({ className:'login', height:ro.ui.relY(80), bottom:ro.ui.relY(5), top:ro.ui.relY(5), layout:'vertical' });
      data[1] = Ti.UI.createTableViewRow({ className:'login', height:ro.ui.relY(80), bottom:ro.ui.relY(5), top:ro.ui.relY(5), layout:'vertical' });
      data[2] = Ti.UI.createTableViewRow({ className:'remember', height:ro.ui.relY(50), bottom:ro.ui.relY(5), top:ro.ui.relY(5), layout:'horizontal' });

      data[0].add(Ti.UI.createLabel({
         text:'Email Address:',
         width:ro.ui.relX(90),
         height:ro.ui.relY(30),
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(12, 90, 30),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.loginLittleTxt
      }));


      var txtUname = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
         height:ro.ui.relY(45),
         //width:ro.ui.relX(330),
         left:ro.ui.relX(5),
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(12, 175, 30),
            fontFamily:ro.ui.fontFamily
         },
         borderColor:ro.ui.theme.btnBorderDefault,
         keyboardType:Ti.UI.KEYBOARD_EMAIL,
         returnKeyType:Ti.UI.RETURNKEY_NEXT,
         minimumFontSize:4,
         passwordMask:'false',
         borderWidth:ro.ui.relX(1)
      }));

      data[0].add(txtUname);

      data[1].add(Ti.UI.createLabel({
         text:'Password:',
         width:ro.ui.relX(90),
         height:ro.ui.relY(30),
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(12, 90, 30),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.loginLittleTxt
      }));

      var txtPass = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
         height:ro.ui.relY(45),
         //width:ro.ui.relX(330),
         left:ro.ui.relX(5),
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(12, 175, 30),
            fontFamily:ro.ui.fontFamily
         },
         borderColor:ro.ui.theme.btnBorderDefault,
         passwordMask:'true',
         keyboardType:Ti.UI.KEYBOARD_DEFAULT,
         returnKeyType:Ti.UI.RETURNKEY_DONE,
         minimumFontSize:0,
         borderWidth:ro.ui.relX(1)
      }));

      data[1].add(txtPass);

      var frgtPw = Ti.UI.createLabel({
         //text:'Forgot Password?',
         left:ro.ui.relX(5),
         textAlign:'center',
         height:ro.ui.relY(30),
         color:ro.ui.theme.forgotPwTxt,
         font:{
             fontSize:ro.ui.scaleFont(9.5, 80, 30),
             fontFamily:ro.ui.fontFamily
         },
         width:'35%'
      });
      /*frgtPw.addEventListener('click', function(e){
         Ti.UI.Android.hideSoftKeyboard();
         ro.ui.showPassRecovery();
      });*/
      data[2].add(frgtPw);

      data[2].add(Ti.UI.createLabel({
          text:'Remember Me',
          font:{
             fontSize:ro.ui.scaleFont(12, 80, 30),
             fontFamily:ro.ui.fontFamily
          },
          width:'35%',
          textAlign:'center',
          height:ro.ui.relY(30),
          color:ro.ui.theme.loginLittleTxt
      }));

      var switchRemember = Ti.UI.createSwitch({
          value:true,
          height:Ti.UI.FILL
      });
      switchRemember.addEventListener('change', function(e){
          remember = e.value;
      });
      data[2].add(switchRemember);

      var tblView = Ti.UI.createTableView({
          data:data,
          height:ro.ui.relY(235),
          top:ro.ui.relY(25),
          backgroundColor:'transparent'
      });

      var padding = Ti.UI.createView({
         top:ro.ui.relY(10),
         layout:'vertical',
         height:Ti.UI.SIZE
      });

      var titleLbl = Ti.UI.createLabel({
         text:Ti.App.loginGreeting,
         font:{
            fontWeight:'bold',
            fontSize:ro.ui.scaleFont(20),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.loginTitleTxt,
         textAlign:'center'
      });
      padding.add(titleLbl);
      padding.add(tblView);
      loginView.add(padding);

      var btnSubmit = Ti.UI.createView({
         height:ro.ui.properties.ldfBool?ro.ui.relY(60):ro.ui.relY(50),
         width:ro.ui.relX(330),
         bottom:ro.ui.properties.ldfBool?ro.ui.relY(15):ro.ui.relY(10),
         top:ro.ui.relY(5),
         backgroundColor:ro.ui.theme.loginBtnBackground,
         borderColor:ro.ui.theme.loginBtnBorder,

         borderWidth:ro.ui.relX(1)
      });
      btnSubmit.add(Ti.UI.createLabel({
         text:'SIGN IN',
         font:{
            fontWeight:'bold',
            fontSize:ro.ui.scaleFont(20),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.loginBtnWhite,
         textAlign:'center'
      }));
      layoutHelper.animateBtn(btnSubmit, ro.ui.theme.loginBtnBackground, ro.ui.theme.loginBtnBorder, 0, ro.ui.theme.loginBtnWhite, ro.ui.theme.btnTxtDefault, ro.ui.theme.loginBtnBorder, ro.ui.theme.btnBorderDefault);
      btnSubmit.addEventListener('click', function (e){
         if(ro.ui.properties.isAndroid){
         	Ti.UI.Android.hideSoftKeyboard();
         }

         if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
            ro.ui.alert('Login Failed', 'Internet connection is required to place an order. Please connect and try again.');
              return;
         }
         if(!Ti.Network.online){
            ro.ui.alert('Login Failed', 'The network is not reachable to the internet.');
            return;
         }

         if(txtUname.value == '' || txtPass.value == ''){
            ro.ui.alert( 'Login Failed', 'Please enter the login credentials');
            return;
         }
         else{
            /*if(txtUname.value.toLowerCase() != 'kiosk@picklemans.com' && txtUname.value.toLowerCase() != 'kiosk@revention.com'){
               Ti.API.debug('This user is not the kiosk admin user, instead it was:' + txtUname.value.toLowerCase());
               ro.ui.alert('Login Failed', 'Please enter the KIOSK credentials');
               return;
            }*/
            if(KIOSK.isKioskLoginValid(txtUname.value)){
               login(txtUname.value, txtPass.value);
            }
         }
      });

      txtUname.addEventListener('return', function(e){
         txtPass.focus();
      });
      loginView.add(btnSubmit);
      
      var skipScreen = false;
      if(defaultCustomer){
         txtUname.value = defaultCustomer.Email;
         txtPass.value = defaultCustomer.Password;
         skipScreen = true;
      }

      if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
         ro.ui.alert(Ti.App.name, 'Internet connection is required to place an order.  Please connect and try again.');
      }

      ro.ui.loginChange = function(e){
         if(e.rowIndex == 0){
            ro.ui.getConfig();
            ro.ui.showNewAccount();
         }
         else{
            try{
               ro.ui.showLoader();
               Ti.App.fireEvent('app:viewDemo');
            }
            catch(ex){
               ro.ui.alert('demo click', ex);
            }
         }
      };

      var newAccountBtnView = Ti.UI.createView({
         height:Ti.UI.FILL,
         top:ro.ui.relY(50),
         width:Ti.UI.FILL,
         backgroundColor:ro.ui.theme.btnDefault,
         layout:'vertical'
      });
      newAccountBtnView.add(Ti.UI.createLabel({
         top:ro.ui.properties.ldfBool?ro.ui.relY(10):ro.ui.relY(5),
         text:'APP CONFIGURATION',
         font:{
            fontWeight:'bold',
            fontSize:ro.ui.scaleFont(20),
            fontFamily:ro.ui.fontFamily
         },
         height:Ti.UI.SIZE,
         color:ro.ui.theme.loginGray,
         left:ro.ui.relX(10),
         right:ro.ui.relX(10),
         textAlign:'center'
      }));
      /*var attr = Ti.UI.createAttributedString({
         text:Ti.App.newAccountDesc,
         attributes:[{
               type:Ti.UI.ATTRIBUTE_BACKGROUND_COLOR,
               value:'purple'//.,
               //range:[0, (Ti.App.newAccountDesc.length/2)]
            }
         ]
      });
      newAccountBtnView.add(Ti.UI.createLabel({
         //text:Ti.App.newAccountDesc,
         attributedString:attr,
         font:{
            fontSize:ro.ui.scaleFont(14.75),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.loginGray,
         textAlign:'center',
         left:ro.ui.relX(10),
         right:ro.ui.relX(10),
         top:ro.ui.properties.ldfBool?ro.ui.relY(15):ro.ui.relY(10)
      }));*/

      var newAccountBtn = Ti.UI.createView({
         height:ro.ui.relY(45),
         width:ro.ui.relX(330),
         backgroundColor:ro.ui.theme.loginGray,
         top:ro.ui.properties.ldfBool?ro.ui.relY(15):ro.ui.relY(10),
         borderColor:ro.ui.theme.btnBorderDefault,
         borderWidth:ro.ui.relX(1)
      });
      newAccountBtn.add(Ti.UI.createLabel({
         text:'Configure Kiosk',
         font:{
            fontWeight:'bold',
            fontSize:ro.ui.scaleFont(20),
            fontFamily:ro.ui.fontFamily
         },
         color:ro.ui.theme.btnDefault,
         textAlign:'center'
      }));
      //layoutHelper.animateBtn(newAccountBtn, ro.ui.theme.loginGray, ro.ui.theme.btnActive, 0, ro.ui.theme.btnDefault, ro.ui.theme.btnTxtActive, ro.ui.theme.btnBorderDefault, ro.ui.theme.btnBorderActive);

      newAccountBtn.addEventListener('click', function(e){
         ro.ui.showLoader();
         ro.ui.getConfig();
         //ro.ui.showKioskConfig();
      });
      newAccountBtnView.add(newAccountBtn);

      mainView.add(newAccountBtnView);
      ro.ui.hideLoader();

      ro.app.GA.trackPageView('loginView' /*name*/);

      /*var postLayoutBln = false;
      mainView.addEventListener('postlayout', function(){
         //Ti.UI.Android.hideSoftKeyboard();
         ro.ui.showLoader();
         if(postLayoutBln){
            Ti.API.debug('postLayoutBln returned');
            ro.ui.hideLoader();
            return;
         }
         postLayoutBln = true;
         
         if(!skipScreen){
            ro.ui.hideLoader();
            Ti.API.debug('!skipScreen');
            return;
         }
         
         if(Ti.Network.networkType == Ti.Network.NETWORK_NONE){
            ro.ui.hideLoader();
            ro.ui.alert('Login Failed', 'Internet connection is required to place an order. Please connect and try again.');
              return;
         }
         if(!Ti.Network.online){
            ro.ui.hideLoader();
            ro.ui.alert('Login Failed', 'The network is not reachable to the internet.');
            return;
         }

         if(txtUname.value.toLowerCase() != 'admin@revention.com'){
            ro.ui.hideLoader();
            Ti.API.debug('This user is not the kiosk admin user, instead it was:' + txtUname.value.toLowerCase());
            ro.ui.alert( 'Login Failed', 'Please enter the KIOSK credentials');
            return;
         }
         login(txtUname.value, txtPass.value);
      });*/

      return mainView;
   };
})();