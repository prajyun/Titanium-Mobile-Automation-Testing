var sizesView;
exports.getNewSizesView = function(group, itemSelected, moveNext){
    try {
		var sizeData = [], i, j, k;
		//var group = ro.app.group;
		//var itemSelected = ro.app.itemSelected;
        function getButtonBlock(btns, btnAction, btnBlockCallback, styPrice, group) {
				var btnBlock = null;
				if(!styPrice){
					styPrice = false;
				}
				try{
					if(!btns){
						return;
					}
					var finalBtns = [];
					var menuUtils = require('logic/menuUtils');
					for(var i=0, iMax=btns.length; i<iMax; i++){
					    if(!menuUtils.isSizeOutOfStock(group, itemSelected.Name, "None", btns[i].Name)){
                            finalBtns.push(btns[i]);
                        }
					}
					btns = finalBtns;
					
					btnBlock = Ti.UI.createView({
						//width:Ti.UI.FILL,
						height: Ti.UI.SIZE,
						//left:ro.ui.relX(20),
						left:'0.5%',//ro.ui.relX(15),
						bottom: ro.ui.relY(5),
						right: '0.5%',//ro.ui.relX(10),
						layout:'horizontal',//vertical',
						bubbleParent:'false',
						visible:true,
						toggle:function(sizeToToggle){
							for(var i=0, iMax=btnBlock.children.length; i<iMax; i++){
								//for(var j=0, jMax=btnBlock.children[i].children.length; j<jMax; j++){
									if(btnBlock.children[i].id === sizeToToggle){
										btnBlock.children[i].toggle(true);
										btnAction(sizeToToggle);
									}
									else{
										btnBlock.children[i].toggle(false);
									}
								//}
							}
						}
					});
			
					var getBtnBlockChildren = function(btnBlock, btns, group, allBtnLength){
						//Ti.API.debug('btnBlockRowIdx: ' + btnBlockRowIdx);
						/*var btnsRow = Ti.UI.createView({
							width:Ti.UI.SIZE,
							layout:'horizontal',
							left:0,
							height:ro.ui.relY(65)
						});*/
						
						
						var aBtn, btnLbl, btnLbl2, clickedBool, clickedColor, btnPriceLblClr;
						var defBorderColor = "#e4e4e4";
						for(var i=0; i<btns.length; i++){
							defBorderColor = "#e4e4e4";
							clickedBool = false;
							clickedColor = 'white';
							btnLblClr = ro.ui.theme.sizeBtnBlockNameTxtDefault;
							btnPriceLblClr = ro.ui.theme.sizeBtnBlockPriceTxtDefault;
							
			
							if(btns[i].OnlineDefault || allBtnLength === 1){
								clickedBool = true;
								clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
								defBorderColor = ro.ui.theme.sizeBtnBlockBgActive;
								btnLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
								ro.itemObj.setSizes(btns[i].Name);
							}
							aBtn = Ti.UI.createView({
								//btnBlockRowIdx:btnBlockRowIdx,
								//width:ro.ui.relX(105),
								//left:ro.ui.relX(5),
								//height:ro.ui.relY(60),
								width: '31%',
                         		height: Ti.UI.SIZE,
								id:btns[i].Name,
								clicked:clickedBool,
								layout:'vertical',
								name:btns[i].ReceiptName || btns[i].Name,
								szName:btns[i].Name,
								idx:i,
								left: '1%',//ro.ui.relX(2),
                        			right: '1%',//ro.ui.relX(2),
                        			top: ro.ui.relX(2),
                        			bottom: ro.ui.relX(2)
							});
			
							var btnName = btns[i].DisplayName || btns[i].ReceiptName || btns[i].Name;
							if(btnName){
								//btnName = btnName.toUpperCase();
							}
			
							var btnLblView = Ti.UI.createView({
								backgroundColor:clickedColor,
								borderColor:defBorderColor,
								borderWidth:ro.ui.relX(2),
								height:ro.ui.relX(35),//Ti.UI.SIZE,//
								width:Ti.UI.SIZE,//ro.ui.relX(100),
								borderRadius:ro.ui.relX(17.5),
								top:ro.ui.relY(3),
								touchEnabled:false
							});
							btnLbl = Ti.UI.createLabel({
							   height:Ti.UI.SIZE,
							   //width:Ti.UI.FILL,//Ti.UI.SIZE,
								text:btnName,
								wordWrap:false,
								maxLines:1,
								color:btnLblClr,
								font:{
									//fontWeight:'bold',
									fontSize:ro.ui.scaleFont(12),
									fontFamily:ro.ui.fonts.rowBodyTxt
								},
								textAlign:'center',
								touchEnabled:false,
								left: ro.ui.relX(12),
                        			right: ro.ui.relX(12)//,
                        			//top: ro.ui.relX(12),
                        			//bottom: ro.ui.relX(12)
								//top:ro.ui.relY(7)
							});
			
							btnLbl2 = Ti.UI.createLabel({
							   height:Ti.UI.SIZE,
							   width:Ti.UI.FILL,
							   top: ro.ui.relY(2),
							   bottom: ro.ui.relY(5),
							   text:'$' + parseFloat(getSizePrice(btns[i])).toFixed(2),
					         color:btnPriceLblClr,
					         font:{
					            //fontWeight:'bold',
					            fontSize:ro.ui.scaleFont(12),
									fontFamily:ro.ui.fonts.prices.italic
					         },
					         textAlign:'center',
					         touchEnabled:false,
							});
							btnLblView.add(btnLbl);
							aBtn.add(btnLblView);
							aBtn.add(btnLbl2);
							aBtn.toggle = toggle;
							function toggle(shouldSelect){
								if(shouldSelect){
									this.clicked = true;
									this.children[0].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
									this.children[0].borderColor = ro.ui.theme.sizeBtnBlockBgActive;
									//this.children[0].borderColor = 'transparent';
									this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label1
								}
								else{
									this.clicked = false;
									this.children[0].backgroundColor = 'white';
									this.children[0].borderColor = '#e4e4e4';
									//this.children[0].borderColor = defBorderColor;
									this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;//Label1
								}
							}
							aBtn.addEventListener('click', function(e){
								if(e.source.clicked){
									return;
								}
								e.source.parent.toggle(e.source.id);
								if(moveNext){
									moveNext();
								}
							});
							//btnsRow.add(aBtn);
							btnBlock.add(aBtn);
						}
						//btnBlock.add(btnsRow);
					};
					var btnsPerRow = 3;
					var rowBtns;
					var btnBlockHeight = 0;
					var btnBlockRow = 0;
					/*for(var i=0, iMax=btns.length; i<iMax; i+=btnsPerRow){
						btnBlockHeight += ro.ui.relY(65);
						rowBtns = btns.slice(i, i+btnsPerRow);
						getBtnBlockChildren(btnBlock, rowBtns, group, btns.length);
					}*/
					getBtnBlockChildren(btnBlock, btns, group, btns.length);
					//btnBlock.height = btnBlockHeight;
					return btnBlock;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL){ Ti.API.debug('getButtonBlock()-Exception: ' + ex); }
					return btnBlock;
				}
			};
		function addSizeBlock()
		{
			/*getButtonBlock(row.sizes, ro.itemObj.setSizes, null, row.styPrice, group);
			         if(sizeToChoose){
			         	row.btnBlocks.toggle(sizeToChoose);
			         }*/
		}
		function addSize(name, label, price, OnlineDefault){
			var row, l, priceLbl;
			row = Ti.UI.createTableViewRow({
				className:'sizes',
				name:name,
				height:ro.ui.relY(40),
				backgroundSelectedColor:ro.ui.theme.tblRowSelected,
				hasChecked:false
			});
			l = Ti.UI.createLabel({
				left:ro.ui.relX(5),
				font:ro.combine(ro.ui.theme.titleFont, {
					fontSize:ro.ui.scaleFontY(9.5, 18)
				}),
				color:ro.ui.theme.textColor,
				text:label || name,
				height:ro.ui.relY(23)
			});
			priceLbl = Ti.UI.createLabel({
				right:0,
				top:ro.ui.relY(3),
				height:ro.ui.relY(12),
				width:ro.ui.relX(35),
				font:{
					fontSize:ro.ui.scaleFontY(8.5, 12),
					fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.textColor,
				text:'$' + ((price*100)/100).toFixed(2)
			});
			row.add(l);
			row.add(priceLbl);
			sizeData.push(row);

			if(OnlineDefault){
				ro.ui.chooseRow(row);
				ro.itemObj.setSizes(name);
			}
		}

		function getTierPrices(TierSizeCol){
			for (i = 0; i < group.Sizes.length; i++) {
				for (j = 0; j < TierSizeCol.length; j++) {
					if ((group.Sizes[i].Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)) {
						addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, TierSizeCol[j].Price, group.Sizes[i].OnlineDefault);
						break;
					}
				}
			}
		}
		
		var FinalSizeCollection = [];
		if(group.UseTieredPricing){
			switch(Ti.App.OrderObj.OrdTypePriceIdx){
				case 0:
					getTierPrices(itemSelected.TierObj.OT0Sizes);
					break;
				case 1:
					 getTierPrices(itemSelected.TierObj.OT1Sizes);
					break;
				case 2:
					getTierPrices(itemSelected.TierObj.OT2Sizes);
					break;
			}

		}
		else{
			var FinalSizeCollection = [];
			for(i=0; i<group.Sizes.length; i++){
				for(j=0; j<itemSelected.AvailableSizes.length; j++){
					if(itemSelected.AvailableSizes[j].Name == group.Sizes[i].Name || itemSelected.AvailableSizes[j].Name.replace(/ /g,'').toLowerCase() == group.Sizes[i].Name.replace(/ /g,'').toLowerCase()){
						var szObj = {
							size:group.Sizes[i],
							price:null
						};
						//FinalSizeCollection.push(group.Sizes[i]);
						if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
							switch(Ti.App.OrderObj.OrdTypePriceIdx){
								case 1:
									if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
										//addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].OrdTypePrice1, group.Sizes[i].OnlineDefault);
										szObj.price = itemSelected.AvailableSizes[j].OrdTypePrice1;
									}
									break;
								case 2:
									if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
										//addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].OrdTypePrice2, group.Sizes[i].OnlineDefault);
										szObj.price = itemSelected.AvailableSizes[j].OrdTypePrice2;
									}
									break;
							}
						}
						else{
							//addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].Price, group.Sizes[i].OnlineDefault);
							szObj.price = itemSelected.AvailableSizes[j].Price;
						}
						FinalSizeCollection.push(szObj);
						break;
					}
				}
			}
		}
		
		//FinalSizeCollection
		
		var oneTimeCounter = 0;
		function testSizes(itemObj){
			try{
				oneTimeCounter++;
				if(!itemObj.Size){
					ro.ui.alert('Required!', 'Please select a size');
					return false;
				}
				else{
					return true;
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL) { Ti.API.debug('testSizes()-Exception: ' + ex); }
			}
		}
	
			var view = Ti.UI.createView({
				//backgroundImage:'/images/invGrpBackground.png',
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				//borderColor:'brown',
				//borderWidth:1,
				layout:'vertical',
				testRequired:true,
				itemTest:function(itemObj){
					return testSizes(itemObj);
				}
			});
			var hdrTxt = 'Please Select Size';
			//view.add(ro.layout.getGenericHdrRowWithHeader(hdrTxt));
			var hdrRow = ro.layout.getGenericMenuHdrRowWithHeader(hdrTxt);
            //hdrRow.backgroundColor = '#e4e4e4';
            view.add(hdrRow);
            view.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));
			
			var sizesView = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				top:0,
				left:ro.ui.relX(10),
				right:ro.ui.relX(10),
				layout:'vertical',
				clicked:false
			});
	
		/*sizesView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
			top:0,
			layout:'vertical',
			testRequired:true,
			itemTest:function(itemObj){
				return testSizes(itemObj);
			}
		}));*/

		/*var hdr = layoutMenuHelper.menuHeaders({text:'PLEASE SELECT A SIZE:'});
      sizesView.add(hdr);*/

		/*getButtonBlock(row.sizes, ro.itemObj.setSizes, null, row.styPrice, group);
			         if(sizeToChoose){
			         	row.btnBlocks.toggle(sizeToChoose);
			         }*/
      //var sizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, getSzs(group.Sizes, null, itemSelected).szs, ro.itemObj.setSizes, function(e){
	  var sizeBlock = getButtonBlock(getSzs(group.Sizes, null, itemSelected).szs, ro.itemObj.setSizes, null,  null, group);
      sizeBlock.top = ro.ui.relY(10);
      sizesView.btnBlock = sizeBlock;
      sizesView.add(sizesView.btnBlock);
      
	    function getSzs(szCol, oneSz, itemSelected){
			if(oneSz){
				if(typeof oneSz != 'string'){
				    var returnSzArr = [];
                    for (var i = 0; i < itemSelected.AvailableSizes.length; i++) {
                        for (var j = 0; j < oneSz.length; j++){				    	
							//.replace(/ /g,'')
				    		if(oneSz[j].toLowerCase() === itemSelected.AvailableSizes[i].Name.toLowerCase()){
								returnSzArr.push(itemSelected.AvailableSizes[i]);
								break;
							}
							if(oneSz[j].replace(/ /g,'').toLowerCase() === itemSelected.AvailableSizes[i].Name.replace(/ /g,'').toLowerCase()){
								returnSzArr.push(itemSelected.AvailableSizes[i]);
								break;
							}
				    	}
					}
					return returnSzArr;
				}
				else{
					var returnCol = [];
					for(var i=0; i<itemSelected.AvailableSizes.length; i++){
						//.replace(/ /g,'')
						if(oneSz && oneSz.length && oneSz.toLowerCase() == 'all'){
							returnCol.push(itemSelected.AvailableSizes[i]);
						}
						else{
							if(oneSz && oneSz.length && oneSz.toLowerCase() === itemSelected.AvailableSizes[i].Name.toLowerCase()){
								return itemSelected.AvailableSizes[i];
							}
							else if(oneSz && oneSz.length && oneSz.replace(/ /g,'').toLowerCase() === itemSelected.AvailableSizes[i].Name.replace(/ /g,'').toLowerCase()){
								return itemSelected.AvailableSizes[i];
							}
						}
					}
					return returnCol;
				}
			}
			else{
		        var availableSz = itemSelected.AvailableSizes;
		        var finalSzs = [], skipBool = false;
		        for(var i=0; i<szCol.length; i++){
		           for(var j=0; j<availableSz.length; j++){
		              if(szCol[i].Name === availableSz[j].Name){
		
		                 finalSzs.push(availableSz[j]);
		                 if(szCol[i] && szCol[i].OnlineDefault){
		                 	  finalSzs[finalSzs.length-1].OnlineDefault = true;
		                 }
		                 break;
		              }
		              if(szCol[i].Name.replace(/ /g,'') === availableSz[j].Name.replace(/ /g,'')){
		
		                 finalSzs.push(availableSz[j]);
		                 if(szCol[i] && szCol[i].OnlineDefault){
		                 	  finalSzs[finalSzs.length-1].OnlineDefault = true;
		                 }
		                 break;
		              }
		           }
		        }
		
		        if(!finalSzs.length){
		           skipBool = true;
		        }
		        return {
		           skipRow:skipBool,
		           szs:finalSzs
		        };
		    }
		}
		function reloadSizes(sizesChosen){
			sizesView.btnBlock.toggle(sizesChosen);
			//setModsPerSize(sizesChosen);
		}
		function reloadSuggSize(SuggSizeName, group, itemSelected){
			try{
				//return;
				if(SuggSizeName.toLowerCase() == 'all'){
					return;
				}
		
				//Ti.API.debug('SuggSizeName: ' + SuggSizeName);
				var SuggSizeArr = [];
				SuggSizeArr.push(SuggSizeName);
		
		
				var suggSize = getSzs(group.Sizes, SuggSizeArr, itemSelected);
				//Ti.API.debug('suggSize: ' + JSON.stringify(suggSize));                
				//var sizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, getSzs(group.Sizes, SuggSizeArr), setSizes);
				var sizeBlock = getButtonBlock(suggSize, ro.itemObj.setSizes, null, null, group);
				//Ti.API.debug('sizeBlock: ' + JSON.stringify(sizeBlock));
				sizesView.remove(sizesView.btnBlock);
				sizesView.btnBlock = null;
				sizesView.btnBlock = sizeBlock;
				sizesView.add(sizesView.btnBlock);
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL) { Ti.API.debug('reloadSuggSize()-Exception: ' + ex); }
			}
		}
		function editSizes(isChosenSize, sizeRestraint){
            try {
                
			  var sizeCol = [];
			  if(sizeRestraint){
			  	  var newSizeRestraint = sizeRestraint.toString().split("__");
			  	  if(newSizeRestraint.length == 1){
			  	  	if(newSizeRestraint[0] && newSizeRestraint[0].length && newSizeRestraint[0].toLowerCase() == 'all'){
			  	  		sizeCol = getSzs(null, newSizeRestraint[0], itemSelected);
			  	  	}
			  	  	else{
			  	  		sizeCol[0] = getSzs(null, newSizeRestraint[0], itemSelected);	
			  	  	}
			  	     
			  	  }
			  	  else{
			  	     sizeCol = getSzs(null, newSizeRestraint, itemSelected);
			     }
			  }
			  else{
			  	  sizeCol = modifySize() || [];
			  }
		
		      var newSizeData = [];
		      var sizeColLen = sizeCol.length;
		      var sizeFound, sizeBlockCounter = 0;
		
                if (sizeColLen > 0) {
			      var thisSizeBlock = getButtonBlock(sizeCol, ro.itemObj.setSizes, function(e){ }, null, group);
			      thisSizeBlock.top = ro.ui.relY(10);
			      sizesView.remove(sizesView.btnBlock);
			      sizesView.btnBlock = thisSizeBlock;
			      sizesView.add(sizesView.btnBlock);
		
			      sizeBlockCounter = thisSizeBlock.children.length;
			  }
		      var setModsPerSizeBool = true;
		      for(var _indx=0; _indx<sizeBlockCounter; _indx++){
		         if(thisSizeBlock.children[_indx].name === isChosenSize){
		            thisSizeBlock.children[_indx].clicked = true;
		            thisSizeBlock.children[_indx].backgroundColor = ro.ui.theme.loginBtnBackground;
		            thisSizeBlock.children[_indx].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
		            thisSizeBlock.children[_indx].children[1].color = ro.ui.theme.sizeBtnBlockTxtActive;
		            ro.itemObj.setSizes(thisSizeBlock.children[_indx].id);
		            //setModsPerSize(thisSizeBlock.children[_indx].id);
		            //etModsPerSizeBool = false;
		        }
		      }
		
		      if(thisSizeBlock && thisSizeBlock.children && thisSizeBlock.children.length > 0){
		         if(thisSizeBlock.children.length === 1){
		            if(group.HasMods){
		               //if(setModsPerSizeBool){
		                  //setModsPerSize(thisSizeBlock.children[0].id);//.name
		              // }
		            }
		         }
		      }
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('editSizes()-Exception: ' + ex); }
			}
		}
		function modifySize(){
			try{
				var changeGrp = ro.cpnHelper.cpnSpecs('MenuSize', group.Sizes);
				if(changeGrp !== -1){
					var grpSize = [];
					grpSize.push(group.Sizes[changeGrp]);
					return grpSize;
				}
				else{
					return [];
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('sizesView.js-modifySize()-Exception: ' + ex); }
			}
		}
		function getSizePrice(sizesCol/*, group, itemSelected*/){
			var priceFound;
		
			function getNewTierPrices(TierSizeCol){
				for(var j=0; j<TierSizeCol.length; j++){
					if((sizesCol.Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)){
						return TierSizeCol[j].Price;
					}
				}
			}
		
			if(group.UseTieredPricing){
				switch(Ti.App.OrderObj.OrdTypePriceIdx){
					case 0:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT0Sizes);
						break;
					case 1:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT1Sizes);
						break;
					case 2:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT2Sizes);
						break;
				}
			}
			else{
				for(var j=0; j<itemSelected.AvailableSizes.length; j++){
					if(itemSelected.AvailableSizes[j].Name == sizesCol.Name){
						if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
							switch(Ti.App.OrderObj.OrdTypePriceIdx){
								case 1:
									if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
										priceFound = itemSelected.AvailableSizes[j].OrdTypePrice1;
									}
									break;
								case 2:
									if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
										priceFound = itemSelected.AvailableSizes[j].OrdTypePrice2;
									}
									break;
							}
						}
						else{
							priceFound = itemSelected.AvailableSizes[j].Price;
						}
						break;
					}
				}
			}
			return priceFound;
		}
      
      view.reloadCpnSelections = editSizes;
      view.reloadSelections = reloadSizes;
      view.reloadSuggs = reloadSuggSize;
      view.add(sizesView);
      
		return view;
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('sizesView.js-Exception: ' + ex); }
		ro.ui.alert('sizes ', 'CODE 101');
	}
};
exports.getSizesView = function(group, itemSelected){
	try{
		var sizeData = [], i, j, k;
		//var group = ro.app.group;
		//var itemSelected = ro.app.itemSelected;
		function addSize(name, label, price, OnlineDefault){
			var row, l, priceLbl;
			row = Ti.UI.createTableViewRow({
				className:'sizes',
				name:name,
				height:ro.ui.relY(40),
				backgroundSelectedColor:ro.ui.theme.tblRowSelected,
				hasChecked:false
			});
			l = Ti.UI.createLabel({
				left:ro.ui.relX(5),
				font:ro.combine(ro.ui.theme.titleFont, {
					fontSize:ro.ui.scaleFontY(9.5, 18)
				}),
				color:ro.ui.theme.textColor,
				text:label || name,
				height:ro.ui.relY(23)
			});
			priceLbl = Ti.UI.createLabel({
				right:0,
				top:ro.ui.relY(3),
				height:ro.ui.relY(12),
				width:ro.ui.relX(35),
				font:{
					fontSize:ro.ui.scaleFontY(8.5, 12),
					fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.textColor,
				text:'$' + ((price*100)/100).toFixed(2)
			});
			row.add(l);
			row.add(priceLbl);
			sizeData.push(row);

			if(OnlineDefault){
				ro.ui.chooseRow(row);
				ro.itemObj.setSizes(name);
			}
		}

		function getTierPrices(TierSizeCol){
			for (i = 0; i < group.Sizes.length; i++) {
				for (j = 0; j < TierSizeCol.length; j++) {
					if ((group.Sizes[i].Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)) {
						addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, TierSizeCol[j].Price, group.Sizes[i].OnlineDefault);
						break;
					}
				}
			}
		}

		if(group.UseTieredPricing){
			switch(Ti.App.OrderObj.OrdTypePriceIdx){
				case 0:
					getTierPrices(itemSelected.TierObj.OT0Sizes);
					break;
				case 1:
					getTierPrices(itemSelected.TierObj.OT1Sizes);
					break;
				case 2:
					getTierPrices(itemSelected.TierObj.OT2Sizes);
					break;
			}

		}
		else{
			for(i=0; i<group.Sizes.length; i++){
				for(j=0; j<itemSelected.AvailableSizes.length; j++){
					if(itemSelected.AvailableSizes[j].Name == group.Sizes[i].Name || itemSelected.AvailableSizes[j].Name.replace(/ /g,'').toLowerCase() == group.Sizes[i].Name.replace(/ /g,'').toLowerCase()){
						if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
							switch(Ti.App.OrderObj.OrdTypePriceIdx){
								case 1:
									if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
										addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].OrdTypePrice1, group.Sizes[i].OnlineDefault);
									}
									break;
								case 2:
									if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
										addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].OrdTypePrice2, group.Sizes[i].OnlineDefault);
									}
									break;
							}
						}
						else{
							addSize(group.Sizes[i].Name, group.Sizes[i].ReceiptName, itemSelected.AvailableSizes[j].Price, group.Sizes[i].OnlineDefault);
						}
						break;
					}
				}
			}
		}
		var oneTimeCounter = 0;
		function testSizes(itemObj){
			try{
				oneTimeCounter++;
				if(!itemObj.Size){
					ro.ui.alert('Required!', 'Please select a size');
					return false;
				}
				else{
					return true;
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL) { Ti.API.debug('testSizes()-Exception: ' + ex); }
			}
		}

		sizesView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
			top:0,
			left:ro.ui.relX(10),
			right:ro.ui.relX(10),
			layout:'vertical',
			testRequired:true,
			itemTest:function(itemObj){
				return testSizes(itemObj);
			}
		}));

		var hdr = layoutMenuHelper.menuHeaders({text:'PLEASE SELECT A SIZE:'});
      sizesView.add(hdr);

      var sizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, getSzs(group.Sizes, null, itemSelected).szs, ro.itemObj.setSizes, function(e){
      	//scrollNext();
      }, null, group);
      sizeBlock.top = ro.ui.relY(10);
      sizesView.btnBlock = sizeBlock;
      sizesView.add(sizesView.btnBlock);
      
	    function getSzs(szCol, oneSz, itemSelected){
			if(oneSz){
				if(typeof oneSz != 'string'){
				    var returnSzArr = [];
				   for(var j=0; j<oneSz.length; j++){
				    	for(var i=0; i<itemSelected.AvailableSizes.length; i++){
							//.replace(/ /g,'')
				    		if(oneSz[j].toLowerCase() === itemSelected.AvailableSizes[i].Name.toLowerCase()){
								returnSzArr.push(itemSelected.AvailableSizes[i]);
								break;
							}
							if(oneSz[j].replace(/ /g,'').toLowerCase() === itemSelected.AvailableSizes[i].Name.replace(/ /g,'').toLowerCase()){
								returnSzArr.push(itemSelected.AvailableSizes[i]);
								break;
							}
				    	}
					}
					return returnSzArr;
				}
				else{
					var returnCol = [];
					for(var i=0; i<itemSelected.AvailableSizes.length; i++){
						//.replace(/ /g,'')
						if(oneSz && oneSz.length && oneSz.toLowerCase() == 'all'){
							returnCol.push(itemSelected.AvailableSizes[i]);
						}
						else{
							if(oneSz && oneSz.length && oneSz.toLowerCase() === itemSelected.AvailableSizes[i].Name.toLowerCase()){
								return itemSelected.AvailableSizes[i];
							}
							else if(oneSz && oneSz.length && oneSz.replace(/ /g,'').toLowerCase() === itemSelected.AvailableSizes[i].Name.replace(/ /g,'').toLowerCase()){
								return itemSelected.AvailableSizes[i];
							}
						}
					}
					return returnCol;
				}
			}
			else{
		        var availableSz = itemSelected.AvailableSizes;
		        var finalSzs = [], skipBool = false;
		        for(var i=0; i<szCol.length; i++){
		           for(var j=0; j<availableSz.length; j++){
		              if(szCol[i].Name === availableSz[j].Name){
		
		                 finalSzs.push(availableSz[j]);
		                 if(szCol[i] && szCol[i].OnlineDefault){
		                 	  finalSzs[finalSzs.length-1].OnlineDefault = true;
		                 }
		                 break;
		              }
		              if(szCol[i].Name.replace(/ /g,'') === availableSz[j].Name.replace(/ /g,'')){
		
		                 finalSzs.push(availableSz[j]);
		                 if(szCol[i] && szCol[i].OnlineDefault){
		                 	  finalSzs[finalSzs.length-1].OnlineDefault = true;
		                 }
		                 break;
		              }
		           }
		        }
		
		        if(!finalSzs.length){
		           skipBool = true;
		        }
		        return {
		           skipRow:skipBool,
		           szs:finalSzs
		        };
		    }
		}
		function reloadSizes(sizesChosen){
			sizesView.btnBlock.toggle(sizesChosen);
			//setModsPerSize(sizesChosen);
		}
		function reloadSuggSize(SuggSizeName, group, itemSelected){
			try{
				//return;
				if(SuggSizeName.toLowerCase() == 'all'){
					return;
				}
		
				//Ti.API.debug('SuggSizeName: ' + SuggSizeName);
				var SuggSizeArr = [];
				SuggSizeArr.push(SuggSizeName);
		
		
				var suggSize = getSzs(group.Sizes, SuggSizeArr, itemSelected);
				Ti.API.debug('suggSize: ' + JSON.stringify(suggSize));
		
				//var sizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, getSzs(group.Sizes, SuggSizeArr), setSizes);
				var sizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, suggSize, ro.itemObj.setSizes, null, null, group);
				//Ti.API.debug('sizeBlock: ' + JSON.stringify(sizeBlock));
				sizesView.remove(sizesView.btnBlock);
				sizesView.btnBlock = null;
				sizesView.btnBlock = sizeBlock;
				sizesView.add(sizesView.btnBlock);
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL) { Ti.API.debug('reloadSuggSize()-Exception: ' + ex); }
			}
		}
		function editSizes(isChosenSize, sizeRestraint){
			try{
			  var sizeCol = [];
			  if(sizeRestraint){
			  	  var newSizeRestraint = sizeRestraint.toString().split("__");
			  	  if(newSizeRestraint.length == 1){
			  	  	if(newSizeRestraint[0] && newSizeRestraint[0].length && newSizeRestraint[0].toLowerCase() == 'all'){
			  	  		sizeCol = getSzs(null, newSizeRestraint[0], itemSelected);
			  	  	}
			  	  	else{
			  	  		sizeCol[0] = getSzs(null, newSizeRestraint[0], itemSelected);	
			  	  	}
			  	     
			  	  }
			  	  else{
			  	     sizeCol = getSzs(null, newSizeRestraint, itemSelected);
			     }
			  }
			  else{
			  	  sizeCol = modifySize() || [];
			  }
		
		      var newSizeData = [];
		      var sizeColLen = sizeCol.length;
		      var sizeFound, sizeBlockCounter = 0;
		
			  if(sizeColLen > 0){
			      var thisSizeBlock = layoutMenuHelper.getButtonBlock(itemSelected, getSizePrice, sizeCol, ro.itemObj.setSizes, function(e){ }, null, group);
			      thisSizeBlock.top = ro.ui.relY(10);
			      sizesView.remove(sizesView.btnBlock);
			      sizesView.btnBlock = thisSizeBlock;
			      sizesView.add(sizesView.btnBlock);
		
			      sizeBlockCounter = thisSizeBlock.children.length;
			  }
		      var setModsPerSizeBool = true;
		      for(var _indx=0; _indx<sizeBlockCounter; _indx++){
		         if(thisSizeBlock.children[_indx].name === isChosenSize){
		            thisSizeBlock.children[_indx].clicked = true;
		            thisSizeBlock.children[_indx].backgroundColor = ro.ui.theme.loginBtnBackground;
		            thisSizeBlock.children[_indx].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
		            thisSizeBlock.children[_indx].children[1].color = ro.ui.theme.sizeBtnBlockTxtActive;
		            ro.itemObj.setSizes(thisSizeBlock.children[_indx].id);
		            //setModsPerSize(thisSizeBlock.children[_indx].id);
		            //etModsPerSizeBool = false;
		        }
		      }
		
		      if(thisSizeBlock && thisSizeBlock.children && thisSizeBlock.children.length > 0){
		         if(thisSizeBlock.children.length === 1){
		            if(group.HasMods){
		               //if(setModsPerSizeBool){
		                  //setModsPerSize(thisSizeBlock.children[0].id);//.name
		              // }
		            }
		         }
		      }
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('editSizes()-Exception: ' + ex); }
			}
		}
		function modifySize(){
			try{
				var changeGrp = ro.cpnHelper.cpnSpecs('MenuSize', group.Sizes);
				if(changeGrp !== -1){
					var grpSize = [];
					grpSize.push(group.Sizes[changeGrp]);
					return grpSize;
				}
				else{
					return [];
				}
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('sizesView.js-modifySize()-Exception: ' + ex); }
			}
		}
		function getSizePrice(sizesCol, group, itemSelected){
			var priceFound;
		
			function getNewTierPrices(TierSizeCol){
				for(var j=0; j<TierSizeCol.length; j++){
					if((sizesCol.Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)){
						return TierSizeCol[j].Price;
					}
				}
			}
		
			if(group.UseTieredPricing){
				switch(Ti.App.OrderObj.OrdTypePriceIdx){
					case 0:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT0Sizes);
						break;
					case 1:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT1Sizes);
						break;
					case 2:
						priceFound = getNewTierPrices(itemSelected.TierObj.OT2Sizes);
						break;
				}
			}
			else{
				for(var j=0; j<itemSelected.AvailableSizes.length; j++){
					if(itemSelected.AvailableSizes[j].Name == sizesCol.Name){
						if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
							switch(Ti.App.OrderObj.OrdTypePriceIdx){
								case 1:
									if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
										priceFound = itemSelected.AvailableSizes[j].OrdTypePrice1;
									}
									break;
								case 2:
									if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
										priceFound = itemSelected.AvailableSizes[j].OrdTypePrice2;
									}
									break;
							}
						}
						else{
							priceFound = itemSelected.AvailableSizes[j].Price;
						}
						break;
					}
				}
			}
			return priceFound;
		}
      
      sizesView.reloadCpnSelections = editSizes;
      sizesView.reloadSelections = reloadSizes;
      sizesView.reloadSuggs = reloadSuggSize;
      
      
		return sizesView;
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('sizesView.js-Exception: ' + ex); }
		ro.ui.alert('sizes ', 'CODE 101');
	}
};

