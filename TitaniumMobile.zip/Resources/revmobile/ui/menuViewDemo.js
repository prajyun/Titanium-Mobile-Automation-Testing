(function(){
	ro.ui.createMenuViewDemo = function(_args){
	   Ti.include('/revmobile/ui/itemsViewDemo.js');
	   Ti.include('/logic/menuUtils.js');
      Ti.include('/logic/menuHelper.js');
      var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
      var Groups = menuHelper.getGroups(ro.app.Store.Menu, timeAtStore);
		
		var center = {
		   x:ro.ui.relX(110),
			y:0
		};
		
		var prevSelectedGroup = null;
		var curSelectedGroup = null;
		var n;
		var visibleView = ro.ui.relX(4);
	   var grpItemViewWidth = ro.ui.relX(75);
		var customAlertView = ca.createCustomAlert(); 
		var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch,{name:'grpsItems', hid:'menuView'}));
		var navBar = Ti.UI.createView(ro.ui.properties.navBar);
		var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Menu(Demo)'}));
		navBar.add(headerLbl);
 	
		var backBtn = Ti.UI.createButton(ro.combine(ro.ui.properties.backBtn, {title:'Login'}));
		backBtn.addEventListener('click', function(e){
			ro.ui.demoShowNext({showing:'menuView'});
		});
		
		n=Groups.length;
	//  Set order obj order type
	for (var i=0; i< ro.app.Store.Menu.OnlineOptions.OrdTypes.length;i++){
		if (ro.app.Store.Menu.OnlineOptions.OrdTypes[i].IsDelivery == Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
			var test = Ti.App.OrderObj;
			test.OrdType = ro.app.Store.Menu.OnlineOptions.OrdTypes[i].OrdType;		
			test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[i].OrdTypePriceIdx;		
			test.Menu = ro.app.Store.Menu.Name;	 	
			test.CurSplit = 0;	
			Ti.App.OrderObj = test;
			test = null;
			break;
		}
	} 
	navBar.add(backBtn);
	mainView.add(navBar);
	
	var grpView = Ti.UI.createView({
		height:ro.ui.relY(75),
		top:ro.ui.relY(50),
		backgroundImage:ro.ui.properties.defaultPath + 'grpBackground.png'
   });
	var leftImage = Ti.UI.createView({
		backgroundImage:ro.ui.properties.defaultIconPath + 'icon_arrow_left.png',
		height:ro.ui.relX(20),
		width:ro.ui.relX(20),
		top:ro.ui.relY(35),
		left:ro.ui.relX(2),
		visible:false
	});
	grpView.add(leftImage);
	
	var rightImage = Ti.UI.createView({
		backgroundImage:ro.ui.properties.defaultIconPath + 'icon_arrow_right.png',
		height:ro.ui.relX(20),
		width:ro.ui.relX(20),
		top:ro.ui.relY(35),
		right:ro.ui.relX(2)
	});
	grpView.add(rightImage);
	
	var grpsScroll = Ti.UI.createScrollView({
		contentWidth:ro.ui.relX(75) * (n + 1),
		contentHeight:ro.ui.relY(85),
		top:ro.ui.relY(2),
		height:ro.ui.relY(75),
		width:Ti.UI.SIZE,
		borderRadius:10,
		backgroundColor:'transparent',
		scrollType:'horizontal'
	});
	/*for(var i=0;i<grpsScroll.children.length;i++){
		grpsScroll.children[i].children[0].animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
	}*/
  
  grpsScroll.addEventListener('click',function(e){
			if(e.source.label){			
				curSelectedGroup = e.source.label;
				var parent = e.source.parent;
				var diff = center.x - parent.left;
				grpsScroll.scrollTo(-diff,0);				
				
				if(e.source.label != prevSelectedGroup){
               e.source.animate({
                  transform:Ti.UI.create2DMatrix().scale(1),
                  duration:1
               },
               function(){
                  ro.ui.refreshItems(curSelectedGroup);
               });
               
               grpsScroll.children[prevSelectedIndice].children[0].animate({
                  transform:Ti.UI.create2DMatrix().scale(0.8),
                  duration:1
               });
               prevSelectedGroup = e.source.label;
               prevSelectedIndice = e.source.parent.indice;
            }
            
				if(itemsView.visible == false){
					defaultLabel.visible=false;
					itemsView.visible = true;
				}
			}
  });
   
  
	
  grpsScroll.addEventListener('scroll', function(e){	
				if(e.x > ro.ui.relX(50)){
					leftImage.show();
				}
				else{
					leftImage.hide();
				}
				if(e.x > ((n - displayableItems) + .6) * grpItemViewWidth){
					rightImage.hide();
				}
				else{
					rightImage.show();
				}
				
			});
 
 	var cpnView = Ti.UI.createView({
				name: 'Coupons',
				indice:0,
				left: ro.ui.relX(5),
				width: ro.ui.relX(80),
				height: ro.ui.relY(85),
				top:0,
				borderRadius: 6
			
			});
			
			//create a button for the group
			var cpnButton = Ti.UI.createButton({
				backgroundImage:ro.ui.properties.defaultPath + 'coupon.png',
				label: 'Coupons',
				width: ro.ui.relX(55),
				height: ro.ui.relX(55),
				top: ro.ui.relY(15),
				borderRadius: 6,
				borderColor: 'black',
				borderWidth: 0.5
			
			});
			
			var cpnLabel = Ti.UI.createLabel({
				text: 'Coupons',
				top:0,
				textAlign: 'center',
				width: ro.ui.relX(57),
				height: ro.ui.relY(15),
				color: ro.ui.theme.grpItemColor,
				font: {
					fontSize: ro.ui.scaleFontY(11,14),
					fontWeight: 'bold'
				}
			});
	
	cpnButton.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});	
	cpnView.add(cpnButton);
	cpnView.add(cpnLabel);
	
	grpsScroll.add(cpnView);

   var grpName;// = Groups[i].Name;
   var imagePath = ro.ui.properties.defaultPath + 'default.png';
   var startLoc = ro.ui.relX(80);
   var GrpLngth = Groups.length;
 for(var i=0; i<GrpLngth; i++){
	grpName = Groups[i].Name;
   //var imagePath = ro.ui.properties.defaultPath + 'default.png';
   //var startLoc = ro.ui.relX(80);
   
	/*if(Groups[i].HasImage){// Newly added Aug 7, 2013
      imagePath = Groups[i].ImageSource;
   }*/
   
	var view = Ti.UI.createView({				
					name:grpName,
					indice:(i+1),
					left:startLoc + (ro.ui.relX(75) * i),
					width:ro.ui.relX(80),
					height:ro.ui.relY(85),
					top:0,
					borderRadius:6
				
				});
				//create a button for the group
				var button = Ti.UI.createImageView({
					image:Groups[i].HasImage?Groups[i].ImageSource:imagePath,
               defaultImage:'/images/default.png',
               label:grpName,
					width:ro.ui.relX(55),
					height:ro.ui.relX(55),
					top:ro.ui.relY(15),
					borderRadius:6,
					borderColor:'black',
					borderWidth:0.5
				});
				
				var label = Ti.UI.createLabel({
					text: Groups[i].DisplayName || Groups[i].Name,
					top:0,
					textAlign: 'center',
					width: ro.ui.relX(57),
					height: ro.ui.relY(15),
					color: ro.ui.theme.grpItemColor,
					font:{
						fontSize: ro.ui.scaleFontY(11,14),
						fontWeight: 'bold'
					}
				});
		
	button.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
	view.add(button);
	view.add(label);
	
	grpsScroll.add(view);
	
	}
	
	var scrollPadding = Ti.UI.createView({
		width:Ti.UI.FILL,
		left:ro.ui.relX(25),
		right:ro.ui.relX(25)
	});
	scrollPadding.add(grpsScroll);
	grpView.add(scrollPadding);
			
	mainView.add(grpView);
	var displayableItems = (ro.ui.displayCaps.platformWidth - scrollPadding.left - scrollPadding.right)/grpItemViewWidth;

	var itemsView = ro.ui.createItemsViewDemo();

	mainView.add(itemsView);
	mainView.add(customAlertView);
		  
	if(grpsScroll.children.length > 0 && ro.app.Store.Menu.Cpns.length > 0){
		grpsScroll.children[0].children[0].animate({
		   transform:Ti.UI.create2DMatrix().scale(1),
			duration:200
		});
		curSelectedGroup = grpsScroll.children[0].children[0].label;
		prevSelectedGroup = grpsScroll.children[0].children[0].label;
		prevSelectedIndice = grpsScroll.children[0].children[0].parent.indice;
		try{
			ro.ui.refreshItems(curSelectedGroup);
		} 
		catch(e){
			ro.ui.alert('Item List Error ', ' CODE 100' + e);
		}
				
			}
	else if(grpsScroll.children.length > 1){
				grpsScroll.children[1].children[0].animate({
					transform: Ti.UI.create2DMatrix().scale(1),
					duration: 200
				});
				curSelectedGroup = grpsScroll.children[1].children[0].label;
				prevSelectedGroup = grpsScroll.children[1].children[0].label;
				prevSelectedIndice = grpsScroll.children[1].children[0].parent.indice;
				try{
					ro.ui.refreshItems(curSelectedGroup);
				} 
				catch(e){
					ro.ui.alert('Item List Error ', ' CODE 100'+ e);
				}
	}
	return mainView;	
	};
}());
