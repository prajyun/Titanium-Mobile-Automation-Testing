(function(){
try{
	ro.ui.createPastOrdersView = function(_args){
var storeObj;
var ordersData;
var dbResults;
var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch,{name:'ordType', hid:'past orders'}));
var ordersView =  Ti.UI.createView(ro.ui.properties.contentsView);
var navBar = Ti.UI.createView(ro.ui.properties.navBar);
var logoutBtn = Ti.UI.createButton(ro.ui.properties.logoutBtn);
logoutBtn.addEventListener('click',function(e){
 	ro.ui.exitApp();
});
navBar.add(logoutBtn);
/* if(ro.ui.theme.bannerImg){
   var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
   navBar.add(headerImg);
}
else{
   var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Recent Orders'}));
   navBar.add(headerLbl);
} */
//var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Recent Orders'}));
//navBar.add(headerLbl);
mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
mainView.add(ordersView);

var tblItems = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsTblView,{
	backgroundColor:'transparent',
	top:ro.ui.contentsTop
	})
);

var tblItemsClick=tblItems.addEventListener('click',function(e){


});
var alertDiag = Ti.UI.createAlertDialog({

});

alertDiag.addEventListener('click',function(e){
	if (e.index==0){
		var phone = 'tel:' + e.source.Phone.replace(/[\D\s]/g,'');
		Ti.Platform.openURL(phone);
	}
});

function PHONE_CLICK(e){
	if (e.source.Phone){
		alertDiag.message=e.source.Phone;
		alertDiag.buttonNames=['Call','Cancel'];
		alertDiag.cancel=1;
		alertDiag.Phone=e.source.Phone;
		alertDiag.show();

	}

}

function DETAILS_CLICK(e){
	 ro.ui.pastOrdShowNext({addView:true,showing:'past order details',rowid:e.source.rowid});
}

function showOrders(){
	ordersData = [];
	for (var i=0;i<dbResults.length;i++){
		var orderObj = JSON.parse(dbResults[i].OrderObj);
		var store = JSON.parse(dbResults[i].StoreObj);
		var title = Ti.UI.createLabel({
			text:(store.Date?store.Date:'') + ' ' +(store.Time?store.Time:''),
			left:ro.ui.relX(5),
			top:ro.ui.relY(10),
			font:{
				fontWeight:'bold',
				fontSize:ro.ui.scaleFontY(11,13),
				fontFamily:ro.ui.fontFamily
			},
			height:ro.ui.relY(13),
			width:ro.ui.relX(150),
			color:ro.ui.theme.contentsTextColor,
			textAlign:'left'
		});

		var confirmationTitle = Ti.UI.createLabel({
			text: '#: ' +  (store.Confirmation?store.Confirmation:''),
			right:ro.ui.relX(5),
			top:ro.ui.relY(10),
			font:{
				fontSize:ro.ui.scaleFontY(10.5,13),
            fontFamily:ro.ui.fontFamily
			},
			height:ro.ui.relY(13),
			width:ro.ui.relX(150),
			textAlign:'right',
			color:ro.ui.theme.contentsTextColor
		});
		var desc = Ti.UI.createLabel({
			text:  ' Day:  ' + (store.Weekday?store.Weekday:'') + '\n Item Qty:  ' + orderObj.Items.length + '\n '+ store.Name  ,
			left:ro.ui.relX(5),
			top:ro.ui.relY(25),
			font:{
				fontSize:ro.ui.scaleFontY(10.5,13),
            fontFamily:ro.ui.fontFamily
			},
			textAlign:'left',
			color:ro.ui.theme.contentsTextColor
		});


		var btnPhone = Ti.UI.createButton({
			height:ro.ui.relX(24),
			right:ro.ui.relX(80),
			bottom:ro.ui.relY(5),
			width:ro.ui.relX(24),
			backgroundImage:ro.ui.properties.defaultPath + 'phone@2x.png',
			backgroundSelectedImage:ro.ui.properties.defaultPath + 'phone@2x.png',
			Phone:(store.Phone?store.Phone:null)
		});
		var btnDetails = Ti.UI.createButton({
			height:ro.ui.relY(25),
			right:ro.ui.relX(5),
			bottom:ro.ui.relY(5),
			title: 'Details',
			color: ro.ui.theme.btnTextColor,
			textAlign:'center',
			width:ro.ui.relX(60),
			font:{fontWeight:'bold',
			fontSize:ro.ui.scaleFontY(11,13),
			fontFamily:ro.ui.fontFamily},
			backgroundImage:ro.ui.properties.defaultPath + 'normalBtn.png',
			backgroundSelectedImage:ro.ui.properties.defaultPath + 'normalBtnPress.png',
			rowid: dbResults[i].rowid
		});
		btnPhone.addEventListener('click',PHONE_CLICK);
		btnDetails.addEventListener('click', DETAILS_CLICK);
		var row = Ti.UI.createTableViewRow({
			hasChild:false,
			height:ro.ui.relY(80),
			className:'order',
			backgroundSelectedColor:ro.ui.theme.tblRowSelected
		});

		row.add(confirmationTitle);
		row.add(title);
		row.add(desc);
		row.add(btnPhone);
		row.add(btnDetails);
		ordersData.push(row);
	}
	tblItems.data = ordersData;
}

function setVisibility(){
	var rtnBool = true;
	if (dbResults == null){
		rtnBool=false;
	}
	else{
		if (dbResults.length==0){
			rtnBool=false;
		}
	}
	return rtnBool;
}

ordersView.add(tblItems);

ro.ui.pastOrderFocus = function(){
	if (!ro.app.isLogout){
		try{
			dbResults= db.getAllCustOrd(Ti.App.Username);

		}
		catch (ex){
			dbResults=[];
		}

		storeObj = ro.app.Store;

		if (setVisibility()){
			showOrders();
		}
		else{
			tblItems.data = [];
		}
	}

};

ro.ui.resetOrders = function(){
	dbResults = db.getAllCustOrd(Ti.App.Username);
};
 ro.ui.pastOrderFocus();
 return mainView;

};
}
catch(ex){
	ro.ui.alert('past orders view', ex);
}
}());
