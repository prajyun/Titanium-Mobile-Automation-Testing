(function(){
   ro.ui.addGiftCard = function(_args){
      var forms = require('/revmobile/ui/forms');
      Ti.include('/formControls/giftCardForm.js');
      var form = forms.createForm({
         style:forms.STYLE_LABEL,
         fields:gcForm.getGcForm(),
         settings:ro.ui.properties.myAccountView
      });

      var mainView =  Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'Gift', hid:'GiftC'}));
      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
      
      /* if(ro.ui.theme.bannerImg){
         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
         navBar.add(headerImg);
      }
		else{
	      var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Gift Card'}));
	      navBar.add(headerLbl);
	  } */

      var clearBtn = layoutHelper.getRightBtn('CLEAR');
      clearBtn.addEventListener('click', function(e){ form.clearFields(); });

      var btnBack = layoutHelper.getBackBtn('PAYMENT SCREEN');
      btnBack.addEventListener('click', function(e){ ro.ui.cartShowNext({ showing:'GiftC' }); });
      navBar.add(btnBack);
      navBar.add(clearBtn);

      var btnUpdate = layoutHelper.getBigButton('CONTINUE & CHECKOUT');
      btnUpdate.addEventListener('click', function(e){
         ro.ui.showLoader();
         Ti.include('/validation/giftCardValidation.js');
         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
         var values = forms.getValues(form);
         var success = gcVal.gcValidate(values);
         if(success.value){
            Ti.include('/validation/regexValidation.js');
            success = regexVal.regExValidate(values);
            if(success.value){
               try{
                  var success = payControl.fillOrderObjGift(values);
                  if(success){
                     ro.ui.cartShowNext({showing:'GiftC'});
                  }
                  else{
                     ro.ui.alert('Gift Card Error: ','Please try again');
                     ro.ui.hideLoader();
                  }
               }
               catch(ex){
                  ro.ui.hideLoader();
                  ro.ui.alert('GiftCard Error', 'Code:110' + ex);
               }
            }
            else{
               ro.ui.alert('Error: ', success.issues[0]);
               ro.ui.hideLoader();
            }
         }
         else{
            ro.ui.alert('Error: ', success.issues[0]);
            ro.ui.hideLoader();
         }
      });

      mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
      mainView.add(btnUpdate);
      mainView.add(form);
      return mainView;
   };
})();