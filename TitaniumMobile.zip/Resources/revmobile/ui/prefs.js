exports.newgetPrefsView = function(group, itemSelected) {
	try {
	    var view = Ti.UI.createView({
	    	//backgroundImage:'/images/invGrpBackground.png',
			height:Ti.UI.SIZE,
			width:Ti.UI.FILL,
			isPrefView:true,
			//borderColor:'brown',
			//borderWidth:1,
			layout:'vertical'
		});
		var hdrTxt = "Please Select Preference";
		//view.add(ro.layout.getGenericMenuHdrRowWithHeader(hdrTxt));
		//view.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));
		var hdr = ro.layout.getGenericMenuHdrRowWithHeader(hdrTxt, true);
		hdr.top = 0;
                    hdr.bottom = 0;
                    hdr.height = Ti.UI.FILL;
            hdr.touchEnabled = false;
		var modRow = Ti.UI.createView({
                height:ro.ui.relY(40),
                //height:Ti.UI.SIZE,
                width:Ti.UI.FILL,
                isHeader:true,
                
                isShowing:true//,
                //backgroundImage:'/images/invGrpBackground.png'
            });
            var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
            greyBar.bottom = 0;
            
            modRow.add(hdr);
            modRow.add(greyBar);
            view.add(modRow);
		function testPrefs(itemObj) {
			try {
				var prefString = '';
				var itmSelPrefLngth = itemSelected.Prefs.length;
				var itmObjPrfmbrsLngth,
				    found,
				    returnBool = 0;
				for (var i = 0; i < itmSelPrefLngth; i++) {
					found = false;
					if (itemObj.PrfMbrs) {
						itmObjPrfmbrsLngth = itemObj.PrfMbrs.length;
						for (var j = 0; j < itmObjPrfmbrsLngth; j++) {
							if (itemSelected.Prefs[i].Name == itemObj.PrfMbrs[j].PrefName) {
								found = true;
								break;
							}
						}
					}

					if (!found) {
						//ro.ui.alert('Required!', 'Please select ' + itemSelected.Prefs[i].Name);
						prefString += 'Please select ' + itemSelected.Prefs[i].Name + '\n';
						returnBool++;
					}
				}
			} catch(ex) {
				if (Ti.App.DEBUGBOOL) {
					Ti.API.debug('testPrefs()-Exception: ' + ex);
				}
			} finally {
				if (returnBool) {
					ro.ui.alert('Required!', prefString);
				}
				return (returnBool > 0) ? false : true;
			}
		}
		
		var prefView = Ti.UI.createView({
			height:Ti.UI.SIZE,
			width:Ti.UI.FILL,
			top:0,
			layout:'vertical',
			clicked:false
		});
		view.testRequired = true;
        view.itemTest = function(itemObj){
         	return testPrefs(itemObj);
        };
        
		var prefsArray = [];
		var prefRows = [];
		

		var tbl = [];
		var prefLength = itemSelected && itemSelected.Prefs && itemSelected.Prefs.length ? itemSelected.Prefs.length : 0;
		for (var i = 0; i < prefLength; i++) {
			try {
				var presetPrefBool = false,
				    presetPrefIndex = 1;
				var prefsData = [];
				var prefModHdrView = Ti.UI.createView({
					ignoreclick:true,
					height:0,//ro.ui.relY(50),
					width:ro.ui.properties.wideViewWidth//,
					//borderColor:'green',
					//borderWidth:1
				});
				function toggleMe(toggle, rowIndex, prefModInfo, prefChosenName, MODS, NOMODS){
					//Ti.API.info('this: ' + JSON.stringify(this));
					//Ti.API.info('toggle: ' + toggle);
					//Ti.API.info('prefRows[rowIndex]: ' + JSON.stringify(prefRows[rowIndex]));
					prefRows[rowIndex].children[2].removeAllChildren();
					prefRows[rowIndex].children[2].height = toggle ? ro.ui.relY(50) : 0;
					
					var prefModsHdr = layoutMenuHelper.menuHeaders({
						text : (prefChosenName ? prefChosenName : prefRows[rowIndex].prefName) + ' Options -- *Click to expand',
						smallerFont : true/*backgroundColor:'transparent', borderColor:'transparent', txtClr:ro.ui.theme.prefHdrTxtClr*/
					});
					prefModsHdr.ignoreclick = true;
					prefModsHdr.bottom = ro.ui.relY(5);
					//prefModsHdr.height = Ti.UI.FILL;
					//prefModsHdr.width = Ti.UI.FILL;
					
					if(toggle){
						prefModsHdr.addEventListener('click', function(){
							//Ti.API.info('prefModsHdr.clicked');
							var prefModWin = layoutMenuHelper.modalPrefWin();
							prefModWin.width = ro.ui.displayCaps.platformWidth;
							prefModWin.children[0].width = ro.ui.displayCaps.platformWidth;
							prefModWin.children[0].height = ro.ui.displayCaps.platformHeight * .65;
							
							var alreadyChosenPrefMods = [];
							var alreadyChosenPrefNoMods = [];
							var usePrefGroupHalf = null;
								if (ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.USE_PREF_GRP_HALF) {
									usePrefGroupHalf = {
										//USE_PREF_GRP_HALF:storeObj.Configuration.USE_PREF_GRP_HALF,
										AllowHalf : group.AllowHalf
									};
								}
							
							var prefNameObj = {
									name : prefChosenName,
									title : prefChosenName ? prefChosenName : prefRows[rowIndex].prefName
							};
							
							var MODSVIEW = require('revmobile/ui/mods_new');
                            var mdView = MODSVIEW.getModsView(prefModInfo.grp, prefModInfo.itm, prefNameObj, function(modView) { }, null, null, null, null, usePrefGroupHalf);
                            //scrollViewData.push(mdView);
                            
                            mdView.height = (ro.ui.displayCaps.platformHeight * .65) - ro.ui.relY(64);
                            //mdView.width = ro.ui.displayCaps.platformWidth;
                            function _pl(){
                            	  mdView.removeEventListener('postlayout', _pl);
                            	     //if (isEdit) {
                            	     	
                            	     	
                            	     	
                            	     	var mds = [],
								    noMds = [];
								    if((MODS && MODS.length) || (NOMODS && NOMODS.length)){
								    		mds = MODS || [];
								    		noMds = NOMODS || [];
								    }
								    else{
								    		var itemObject = ro.itemObj.getItemObj();
										for (var i = 0,
										    iMax = itemObject.PrfMbrs.length; i < iMax; i++) {
											var prfMbr = itemObject.PrfMbrs[i];
											if (prfMbr.Name == prefChosenName) {
												if (prfMbr.Mods && prfMbr.Mods.length) {
													mds = prfMbr.Mods;
												}
												if (prfMbr.NoMods && prfMbr.NoMods.length) {
													noMds = prfMbr.NoMods;
												}
												break;
											}
										}
								    }
								    
								
								var isEdit = ((mds && mds.length) || (noMds && noMds.length)) ? true : false;
								//Ti.API.info('mds: ' + JSON.stringify(mds));
								//Ti.API.info('noMds: ' + JSON.stringify(noMds));
									if(isEdit){
								    		mdView.edit(mds, noMds);
								    	}
							     //}
                            }
                            mdView.addEventListener('postlayout', _pl);
							var prefModsBtn = layoutHelper.getBigButton('SAVE Modifiers', true, true);
									prefModsBtn.addEventListener('click', function() {
										prefModWin.close();
										prefModWin.removeAllChildren();
										prefModWin = null;
									});
									prefModWin.children[0].add(mdView);

									//prefModWin.children[0].add(prefModsView);
									prefModsBtn.top = 0;
									prefModWin.children[0].add(prefModsBtn);
							
							
							
							/*if (isEdit) {
										prefModsView.edit(mds, noMds);
									}*/
							prefModWin.open();
						});
						prefRows[rowIndex].children[2].add(prefModsHdr);
					}
					
					//Ti.API.info('prefRows['+rowIndex+']: ' + JSON.stringify(prefRows[rowIndex].children.length));
					//Ti.API.info('prefRows['+rowIndex+']: ' + JSON.stringify(prefRows[rowIndex].children));
				}
				prefModHdrView.toggleMods = toggleMe;
				var prefRow = getNewPrefRow(itemSelected.Prefs[i], i, createPrefMbrView(itemSelected.Prefs[i], i, prefModHdrView.toggleMods));
				
				prefRow.add(prefModHdrView);
				//prefRow.prefMemberView.add();
				prefRow.addEventListener('click', function(e){
					if(e.source.ignoreclick){
						return;
					}
					if(e.source.toggle(e.source)){
						e.source.prefMemberView.children[0].visible=true;
					    e.source.prefMemberView.children[0].height = Ti.UI.SIZE;//e.source.prefMemberView.children[0].openHeight;
					}
					else{
						e.source.prefMemberView.children[0].visible=false;
						e.source.prefMemberView.children[0].height = 0;
					}
				});
				//Ti.API.info('itemSelected.Prefs[i].DefaultMember: ' + itemSelected.Prefs[i].DefaultMember);
				if(!itemSelected.Prefs[i].DefaultMember || !itemSelected.Prefs[i].DefaultMember.length || itemSelected.Prefs[i].DefaultMember.toLowerCase() === 'none'){
					
					prefRow.fireEvent('click');
				}
				prefRows.push(prefRow);

				if (presetPrefBool) {
					

				}

			} catch(ex) {
				Ti.API.debug('prefs.js-LOOP-Exception: ' + ex);
				ro.ui.alert('prefs loop', ex);
			}
		}
		
		prefView.add(prefRows);
		
		function createPrefMbrView(pref, prefIndex, toggleMods){
			
			if(!pref){
				return;
			}
			var thebtns = pref.PrefMbrs && pref.PrefMbrs.length ? JSON.parse(JSON.stringify(pref.PrefMbrs)) : [];
			var theBtnLength = thebtns.length;
			
			var btnsPerRow = 3;
			var openHeightMultiplier = Math.ceil(thebtns.length / btnsPerRow);
			
			var btnBlock = Ti.UI.createView({
				width:ro.isiOS ? Ti.UI.FILL : Ti.UI.FILL,
				isBtnBlock:true,
				openHeight:openHeightMultiplier * ro.ui.relY(46),
				height:0,//Ti.UI.SIZE,
				bottom:ro.ui.relY(10),
				visible: false,
				layout:'vertical',
				bubbleParent:false,
				ignoreclick:true,
				toggle:function(prefToToggle){
					for(var i=0, iMax=btnBlock.children.length; i<iMax; i++){
						for(var j=0, jMax=btnBlock.children[i].children.length; j<jMax; j++){
							if(btnBlock.children[i].children[j].id === prefToToggle){
								btnBlock.children[i].children[j].toggle(true);
							}
							else{
								btnBlock.children[i].children[j].toggle(false);
							}
						}
					}
					
					
					
				}
			});
			
			var rowBtns;
			var btnBlockHeight = 0;
			var btnBlockRow = 0;
			Ti.API.info();// SOMEDAY, SOMEBODY MIGHT SEE THIS AND KNOW ITS HERE BECAUSE WHEN REMOVED THE BELOW CODE IS SIMPLY SKIPPED OVER....ASK TITANIUM
			/*for(var i=0, iMax=theBtnLength; i<iMax; i+=btnsPerRow){
				rowBtns = thebtns.slice(i, i+btnsPerRow);
				btnBlock.add(getBtnBlockChildren(rowBtns, pref.DefaultMember, theBtnLength, prefIndex, pref.Name, toggleMods));
			}*/
			btnBlock.add(getBtnBlockChildren(thebtns, pref.DefaultMember, theBtnLength, prefIndex, pref.Name, toggleMods));
			return btnBlock;
		}
		function getBtnBlockChildren(btns, DefaultMember, allBtnLength, prefIndex, PrefName, toggleMods){
                var btnsRow = Ti.UI.createView({
                    width:ro.isiOS ? Ti.UI.FILL : Ti.UI.SIZE,
                    layout:'horizontal',
                    height:Ti.UI.SIZE,
                    horizontalWrap: true,
                    left:ro.ui.relX(15)
                });
                
                
                var aBtn, btnLbl, btnLbl2, clickedBool, clickedColor, btnPriceLblClr;
                var defBorderColor = "#e4e4e4";
                for(var i=0; i<btns.length; i++){
                	defBorderColor = "#e4e4e4";
                    //Ti.API.info('btns['+i+']:  ' + JSON.stringify(btns[i]));
                    clickedBool = false;
                    clickedColor = 'white';
                    btnLblClr = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    btnPriceLblClr = ro.ui.theme.sizeBtnBlockPriceTxtDefault;
                    
    
                    if(btns[i].Name == DefaultMember || allBtnLength === 1){
                        clickedBool = true;
                        clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
                        defBorderColor = clickedColor;
                        btnLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
                            ro.itemObj.setPrefs(btns[i].Name, prefIndex);
                    }
                     var btnName = btns[i].DisplayName || btns[i].ReceiptName || btns[i].Name;
                     if(btnName && btnName.length > 0){
                     	btnName = btnName.trim();
                     } 
                     //btnName = btnName.replace(/[^A-Za-z\s]/g,'');                   
                    var btnWidth = btnName.length <= 9 ? ro.ui.relX(105) : ro.ui.relX(150);
                    aBtn = Ti.UI.createView({
                    		prefMbr:btns[i],
                        PrefName:PrefName,
                        width: Ti.UI.SIZE,
                         height: Ti.UI.SIZE,
                        //left: ro.ui.relX(3),
                        //height:ro.ui.relY(45),
                        id:btns[i].Name,
                        prefMbrName:btns[i].Name,
                        prefIndex:prefIndex,
                        clicked:clickedBool,
                        layout:'vertical',
                        left: ro.ui.relX(2),
                        right: ro.ui.relX(2),
                        top: ro.ui.relX(2),
                        bottom: ro.ui.relX(2)
                    });   
                   
    
                    var btnLblView = Ti.UI.createView({
                        backgroundColor:clickedColor,
                        borderColor:defBorderColor,
                        borderWidth:ro.ui.relX(2),
                        //height: Ti.UI.SIZE,
                        height:ro.ui.relX(35),
                        width: Ti.UI.SIZE,
                        borderRadius:ro.ui.relX(17.5),
                        top:ro.ui.relY(3),
                        touchEnabled:false
                    });
                    btnLbl = Ti.UI.createLabel({
                        //height:ro.isiOS ? ro.ui.relX(30) : Ti.UI.SIZE,
                        text:btnName,
                        color:btnLblClr,
                        font:{
                            fontSize:/*ro.isiOS ? */ro.ui.scaleFont(12) /*: ro.ui.scaleFont(12)*/,
                            fontFamily:ro.ui.fonts.rowBodyTxt
                        },
                        textAlign:'center',
                        touchEnabled:false,
                        width: Ti.UI.SIZE,
                        height: Ti.UI.SIZE,
                        left: ro.ui.relX(12),
                        right: ro.ui.relX(12)
                        //top: ro.ui.relX(12),
                        //bottom: ro.ui.relX(12)
                    });
    
                    
                    btnLblView.add(btnLbl);
                    aBtn.add(btnLblView);
                    aBtn.toggle = toggle;
                    function toggle(shouldSelect){
                        if(shouldSelect){
                            this.clicked = true;
                            this.children[0].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                            this.children[0].borderColor =  ro.ui.theme.sizeBtnBlockBgActive;
                            this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label1
                        }
                        else{
                            this.clicked = false;
                            this.children[0].backgroundColor = 'white';
                            this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;//Label1
                            this.children[0].borderColor =  "#e4e4e4";
                        }
                    }
                    aBtn.addEventListener('click', function(e){
                        if(e.source.clicked){
                            return;
                        }
                        ro.itemObj.setPrefs(e.source.prefMbrName, e.source.prefIndex);
                        //Ti.API.info('e.source.prefMbr: ' + JSON.stringify(e.source.prefMbr));
                         //ModGrpName : currPrefMbr.ModGrpName
						//thisRow.PsItmName = currPrefMbr.UsePSMods ? currPrefMbr.PSItmName : (currPrefMbr.UseMods ? itemSelected.Name : '')
				 		//thisRow.UsePSMods = currPrefMbr.UsePSMods
				 		if(e.source.prefMbr.UseMods && e.source.prefMbr.ModGrpName && e.source.prefMbr.ModGrpName != ''){
				 			var psItmName = e.source.prefMbr.UsePSMods ? e.source.prefMbr.PSItmName : (e.source.prefMbr.UseMods ? itemSelected.Name : '');
				 			var prefModInfo = getPrefModInfo(e.source.prefMbr.ModGrpName, psItmName, e.source.prefMbr.UsePSMods);
				 			//Ti.API.info('prefModInfo: ' + JSON.stringify(prefModInfo));
				 			//Ti.API.info('e.source: ' + JSON.stringify(e.source));
				 			
				 			toggleMods(true, e.source.prefIndex, prefModInfo, e.source.prefMbr.Name, e.source.Mds, e.source.NoMds);
				 		}
				 		else{
				 			toggleMods(false, e.source.prefIndex);
				 		}
                        
                        e.source.parent.parent.toggle(e.source.id);
                    });
                    btnsRow.add(aBtn);
                }
                return btnsRow;
            }
		function getNewPrefRow(rowDetail, id, thePrefMemberView){
			var fontWgt = 'normal';
			var rowText = 'Tap To Add';
			var rowHeight = ro.ui.relY(50);
		
			var row = Ti.UI.createView({
				borderRadius:ro.ui.relY(15),
				height:Ti.UI.SIZE,
				left:ro.ui.relX(5),
                right:ro.ui.relX(5),
				width:Ti.UI.FILL,
				layout:'vertical',
				clicked:false,
				prefIndex:id,
                backgroundColor:((id%2) ? "#f6f6f6" : "white"),
                prefName:rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name
			});
			var rowView = Ti.UI.createView({
				height:Ti.UI.SIZE,//rowHeight,
				width:Ti.UI.FILL,
				layout:'horizontal',
				touchEnabled:false
			});
		
			var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
			if (rowDetail.OnlineDesc.length > 0) {
				labelOneTxt = rowDetail.OnlineDesc;
			}
			
		
			var labelOne = Ti.UI.createLabel({
				height:ro.ui.relY(50),
				text:labelOneTxt,
				font:{
					fontWeight:'bold',
					fontSize:ro.ui.scaleFont(14),
						fontFamily:ro.ui.fontFamily
				},
				left:ro.isiOS ? null : ro.ui.relX(5),
				color:ro.ui.theme.darkerGray,
				width:Ti.UI.SIZE,
				bubbleParent:true,
				touchEnabled:false
			});
			var labelTwo = Ti.UI.createLabel({
				height:ro.ui.relY(50),
				text:rowText,
				font:{
					fontSize:ro.ui.scaleFont(11),
						fontFamily:ro.ui.fontFamily
				},
				right:ro.ui.relX(10),
				color:ro.ui.theme.loginGray,
				textAlign:'right',
				width:Ti.UI.FILL,
				touchEnabled:false
			});
			rowView.add(Ti.UI.createView({
			   width:ro.ui.relX(35),
			   left:ro.ui.relX(10),
			   height:ro.ui.relY(35),
			   touchEnabled:false
			}));
		   var checkView = Ti.UI.createView({
		      height:ro.ui.relY(35),
		      width:ro.ui.relX(35),
		      backgroundImage:'/images/unselectedPlus.png',
		      visible:true,
			  touchEnabled:false
		   });
		   row.checkView = checkView;
		   rowView.children[0].add(row.checkView);
			
			rowView.add(labelOne);
			row.labelTwo = labelTwo;
			rowView.add(row.labelTwo);
			row.add(rowView);
			var prefMemberView = Ti.UI.createView({
				bubbleParent:false,
				height: Ti.UI.SIZE,
				width:Ti.UI.FILL
			});
			prefMemberView.add(thePrefMemberView);
			row.prefMemberView = prefMemberView;
			row.add(row.prefMemberView);
			
			row.toggle = function(theRow) {
				if (theRow.clicked) {//Row was clicked and is now being unclicked
					theRow.clicked = false;
					theRow.labelTwo.text = 'Tap To Add';
					theRow.checkView.backgroundImage = '/images/unselectedPlus.png';
				}
				else {//Row isnt clicked but is currently getting clicked
					theRow.clicked = true;
					theRow.checkView.backgroundImage = '/images/selectedMinus.png';
					theRow.labelTwo.text = 'Tap To Remove';
				}
				return theRow.clicked;
			}; 

			return row;
		}
		
		view.reloadCpnSelections = editPrefs;
		view.reloadSelections = editPrefs;
		view.add(prefView);
		
		
		
	} catch(ex) {
		Ti.API.debug('prefs.js-Exception: ' + ex);
		ro.ui.alert('Preferences', 'CODE 100');

	}
	function editPrefs(isChosenPref) {
		try {
			var chosenPrefLength = isChosenPref.length || 0;
			/*Ti.API.debug('chosenPrefLength: ' + chosenPrefLength);
			for (var i = 0; i < chosenPrefLength; i++) {
				//Ti.API.debug('isChosenPref['+i+']: ' + JSON.stringify(isChosenPref[i]));
				//var thisPicker = prefsArray[i].children[1];
				
				for (var j = 0; j < itemSelected.Prefs.length; j++) {
					if (isChosenPref[i].PrefName === itemSelected.Prefs[j].Name) {
						
						for (var k = 0; k < itemSelected.Prefs[j].PrefMbrs.length; k++) {
							if (isChosenPref[i].Name === itemSelected.Prefs[j].PrefMbrs[k].Name) {
								
								break;
							}
						}
					}
				}
			}*/

			for (var i = 0; i < chosenPrefLength; i++) {
				for (var m = 0, mMax = prefView.children.length; m < mMax; m++) {
					var prefMemberView = prefView.children[m].prefMemberView;
					var prefMemberViewRows = prefMemberView.children;
					for(var n=0, nMax=prefMemberViewRows.length; n<nMax; n++){
						for(var p=0, pMax=prefMemberViewRows[n].children.length; p<pMax; p++){
							
							var prefButtons = prefMemberViewRows[n].children[p].children;
							for(var o=0, oMax=prefButtons.length; o<oMax; o++){
								//isChosenPref
								var thisButton = prefButtons[o];
								if((isChosenPref[i].PrefName == thisButton.PrefName) && thisButton.prefMbrName == isChosenPref[i].Name){
									
									thisButton.Mds = isChosenPref[i].Mods || [];
									thisButton.NoMds =  isChosenPref[i].NoMods || [];
									thisButton.fireEvent('click');
									break;
								}
		
								
								//find correct button and call 
								//thisButton.fireEvent('click');
							}
						}
					}
					/*aBtn.addEventListener('click', function(e){
						if(e.source.clicked){
							return;
						}
						ro.itemObj.setPrefs(e.source.prefMbrName, e.source.prefIndex);
						e.source.parent.parent.toggle(e.source.id);
					});*/
				}
			}

		} catch(ex) {
			if (Ti.App.DEBUGBOOL) {
				Ti.API.debug('editPrefs()-Exception: ' + ex);
			}
		}
	}

	function reloadPrefs() {

	}

	function getPrefModInfo(modGrpName, PSItmName, usePSMods) {
		//Ti.include('/logic/menuUtils.js');
		var menuUtils = require('logic/menuUtils');
		//Ti.include('../views/l-mods.js');
		var prefModGrp = menuUtils.getGrp(modGrpName, ro.app.Store.Menu);
		var prefPreMods = [],
		    theItem = {};
		if(prefModGrp && prefModGrp.Items){
			if (usePSMods) {
				for (var i = 0,
				    iMax = prefModGrp.Items.length; i < iMax; i++) {
					if (prefModGrp.Items[i].Name == PSItmName) {
						theItem = prefModGrp.Items[i];
						break;
					}

				}
			} else {
				for (var i = 0,
				    iMax = prefModGrp.Items.length; i < iMax; i++) {
					if (prefModGrp.Items[i].Name == PSItmName) {
						theItem = prefModGrp.Items[i];
						break;
					}

				}
			}
		}
		return {
			grp : prefModGrp,
			itm : theItem
		};
	}

	return view;
};
exports.getPrefsView = function(group, itemSelected) {
	try {

		var prefsArray = [];
		//var tbl = [];

		//var sharedLayout = require('revmobile/ui/menu/sharedMenuLayouts');

		//itemObj.PrfMbrs = [];
		function testPrefs(itemObj) {
			try {
				var prefString = '';
				var itmSelPrefLngth = itemSelected.Prefs.length;
				var itmObjPrfmbrsLngth,
				    found,
				    returnBool = 0;
				for (var i = 0; i < itmSelPrefLngth; i++) {
					found = false;
					if (itemObj.PrfMbrs) {
						itmObjPrfmbrsLngth = itemObj.PrfMbrs.length;
						for (var j = 0; j < itmObjPrfmbrsLngth; j++) {
							if (itemSelected.Prefs[i].Name == itemObj.PrfMbrs[j].PrefName) {
								found = true;
								break;
							}
						}
					}

					if (!found) {
						//ro.ui.alert('Required!', 'Please select ' + itemSelected.Prefs[i].Name);
						prefString += 'Please select ' + itemSelected.Prefs[i].Name + '\n';
						returnBool++;
					}
				}
			} catch(ex) {
				if (Ti.App.DEBUGBOOL) {
					Ti.API.debug('testPrefs()-Exception: ' + ex);
				}
			} finally {
				if (returnBool) {
					ro.ui.alert('Required!', prefString);
				}
				return (returnBool > 0) ? false : true;
			}
		}

		var tbl = [];
		//Ti.API.debug('itemSelected.Prefs: ' + JSON.stringify(itemSelected.Prefs));
		for (var i = 0; i < itemSelected.Prefs.length; i++) {
			try {
				var presetPrefBool = false,
				    presetPrefIndex = 1;
				var prefsData = [];
				var title = itemSelected.Prefs[i].DisplayName || itemSelected.Prefs[i].ReceiptName || itemSelected.Prefs[i].Name;
				if (itemSelected.Prefs[i].OnlineDesc.length > 0) {
					title = itemSelected.Prefs[i].OnlineDesc;
				}
				var view = Ti.UI.createView({
					id : i,
					layout : 'vertical',
					height : Ti.UI.SIZE,
					width : Ti.UI.FILL,
					//backgroundImage:'/images/contents_small.png',
					left : ro.ui.relX(10),
					right : ro.ui.relX(10),
					top : ro.ui.relY(10),
					borderWidth : .5,
					borderColor : ro.ui.theme.prefBoxBorderClr
				});
				var hdr = layoutMenuHelper.menuHeaders({
					text : title,
					backgroundColor : 'transparent',
					borderColor : 'transparent',
					txtClr : ro.ui.theme.prefHdrTxtClr
				});
				view.add(hdr);

				tbl[i] = Ti.UI.createPicker({
					height : ro.ui.relY(45), //35
					width : ro.ui.relX(150),
					left : ro.ui.relX(10),
					top : ro.ui.relX(5),
					bottom : ro.ui.relY(5),
					backgroundColor : ro.ui.theme.pickerColor,
					selPrefName : ''
				});
				var pickRows = [];
				pickRows.push(Ti.UI.createPickerRow({
					title : '--Select--',
					idx : 1,
					prefIndex : i,
					rowNum : -1//,
					//					color:'white'
				}));
				/*tbl[i].add(Ti.UI.createPickerRow({
				 title:'--Select--',
				 idx:1,
				 prefIndex:i,
				 rowNum:-1
				 }));*/

				for (var j = 0; j < itemSelected.Prefs[i].PrefMbrs.length; j++) {
					var currPrefMbr = itemSelected.Prefs[i].PrefMbrs[j];
					var row = Ti.UI.createPickerRow({
						title : currPrefMbr.DisplayName || currPrefMbr.ReceiptName || currPrefMbr.Name,
						prefName : currPrefMbr.Name,
						prefIndex : i,
						UseMods : currPrefMbr.UseMods,
						ModGrpName : currPrefMbr.ModGrpName,
						PsItmName : currPrefMbr.UsePSMods ? currPrefMbr.PSItmName : (currPrefMbr.UseMods ? itemSelected.Name : ''),
						UsePSMods : currPrefMbr.UsePSMods,
						name : currPrefMbr.Name,
						rowNum : j + 1//,
						//						color:'white'
					});
					if (currPrefMbr.UsePSMods) {
						tbl[i].UsePSMods = true;
					}

					if (itemSelected.Prefs[i].DefaultMember == currPrefMbr.Name) {
						presetPrefBool = true;
						presetPrefIndex = j;
						ro.itemObj.setPrefs(currPrefMbr.Name, i);
						tbl[i].selPrefName = currPrefMbr.Name;
					}
					pickRows.push(row);
					//tbl[i].add(row);
				}
				//tbl[i].add(pickRows);
				tbl[i].pickRows = pickRows;
				//tbl[i].add(tbl[i].pickRows);
				for (var k = 0,
				    kMax = tbl[i].pickRows && tbl[i].pickRows.length ? tbl[i].pickRows.length : 0; k < kMax; k++) {
					tbl[i].add(tbl[i].pickRows[k]);
				}

				tbl[i].addEventListener('change', function(e) {

					var theView = e.source.parent;
					var thisRow = e.source.getSelectedRow(0);

					if (thisRow.idx !== 1) {
						ro.itemObj.setPrefs(thisRow.prefName, thisRow.prefIndex);

						if (thisRow.UseMods) {
							ro.ui.showLoader();

							//Ti.include('/revmobile/ui/mods_new.js');
							var MODSVIEW = require('revmobile/ui/mods_new');
							theView.prefModsView.removeAllChildren();
							var prefModInfo = getPrefModInfo(thisRow.ModGrpName, thisRow.PsItmName, thisRow.UsePSMods);

							var prefModsHdr = layoutMenuHelper.menuHeaders({
								text : thisRow.title + ' Options -- *Click to expand',
								smallerFont : true/*backgroundColor:'transparent', borderColor:'transparent', txtClr:ro.ui.theme.prefHdrTxtClr*/
							});
							prefModsHdr.bottom = ro.ui.relY(5);
							prefModsHdr.addEventListener('click', function(e) {
								ro.ui.showLoader();
								var prefModWin = layoutMenuHelper.modalPrefWin();
								var mds = [],
								    noMds = [];
								var itemObject = ro.itemObj.getItemObj();
								for (var i = 0,
								    iMax = itemObject.PrfMbrs.length; i < iMax; i++) {
									var prfMbr = itemObject.PrfMbrs[i];
									if (prfMbr.Name == thisRow.name) {
										if (prfMbr.Mods && prfMbr.Mods.length) {
											mds = prfMbr.Mods;
										}
										if (prfMbr.NoMods && prfMbr.NoMods.length) {
											noMds = prfMbr.NoMods;
										}
										break;
									}
								}
								var isEdit = ((mds && mds.length) || (noMds && noMds.length)) ? true : false;

								var usePrefGroupHalf = null;
								if (ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.USE_PREF_GRP_HALF) {
									usePrefGroupHalf = {
										//USE_PREF_GRP_HALF:storeObj.Configuration.USE_PREF_GRP_HALF,
										AllowHalf : group.AllowHalf
									};
								}

								MODSVIEW.getModsView(prefModInfo.grp, prefModInfo.itm, {
									name : thisRow.name,
									title : thisRow.title
								}, function(prefModsView) {
									var prefModsBtn = layoutHelper.getBigButton('SAVE Modifiers', true);
									prefModsBtn.addEventListener('click', function() {
										prefModWin.close();
									});
									if (isEdit) {
										prefModsView.edit(mds, noMds);
									}

									prefModWin.children[0].add(prefModsView);
									prefModsBtn.top = 0;
									prefModWin.children[0].add(prefModsBtn);
									prefModWin.open();
									ro.ui.hideLoader();

								}, null, null, null, null, usePrefGroupHalf);
							});
							theView.prefModsView.add(prefModsHdr);
							ro.ui.hideLoader();
						}
					} 
					else {
						theView.prefModsView.removeAllChildren();
						ro.itemObj.unsetPrefs(thisRow.prefIndex);
						ro.ui.hideLoader();
					}
				});

				view.add(tbl[i]);

				var prefModsView = Ti.UI.createView({
					height : Ti.UI.SIZE
				});
				view.prefModsView = prefModsView;
				view.add(view.prefModsView);

				if (presetPrefBool) {
					tbl[i].setSelectedRow(0, presetPrefIndex + 1);

					var theView = view;
					//var thisRow = tbl[i].getSelectedRow(0);
					//var thisRow = tbl[i].children[0].rows[presetPrefIndex+1];
					var thisRow = tbl[i].pickRows[presetPrefIndex + 1];

					if (thisRow.idx !== 1) {
						//setPrefs(thisRow.prefName, thisRow.prefIndex);

						if (thisRow.UseMods) {//UseMods
							//Ti.include('/revmobile/ui/mods_new.js');
							var MODSVIEW = require('revmobile/ui/mods_new');
							theView.prefModsView.removeAllChildren();
							var prefModInfo = getPrefModInfo(thisRow.ModGrpName, thisRow.PsItmName, thisRow.UsePSMods);
							var prefModsHdr = layoutMenuHelper.menuHeaders({
								text : thisRow.title/*name*/ + ' Options	                 *Click to expand',
							});
							prefModsHdr.bottom = ro.ui.relY(5);
							prefModsHdr.addEventListener('click', function(e) {
								var prefModWin = layoutMenuHelper.modalPrefWin();

								var usePrefGroupHalf = null;
								if (ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.USE_PREF_GRP_HALF) {
									usePrefGroupHalf = {
										//USE_PREF_GRP_HALF:storeObj.Configuration.USE_PREF_GRP_HALF,
										AllowHalf : group.AllowHalf
									};
								}

								MODSVIEW.getModsView(prefModInfo.grp, prefModInfo.itm, {
									name : thisRow.name,
									title : thisRow.title
								}, function(prefModsView) {
									var prefModsBtn = layoutHelper.getBigButton('SAVE Modifiers', true);
									prefModsBtn.addEventListener('click', function() {
										prefModWin.close();
									});
									prefModWin.children[0].add(prefModsView);
									prefModsBtn.top = 0;
									prefModWin.children[0].add(prefModsBtn);
									prefModWin.open();

								}, null, null, null, null, usePrefGroupHalf);
							});
							theView.prefModsView.add(prefModsHdr);
						}

					}

				} else {
					//tbl.setSelectedRow(0,0);
				}

				prefsArray.push(view);
			} catch(ex) {
				Ti.API.debug('prefs.js-LOOP-Exception: ' + ex);
				ro.ui.alert('prefs loop', ex);
			}
		}

		var returnView = Ti.UI.createScrollView({
			disableBounce : ro.isiOS ? true : false,
			height : Ti.UI.FILL,
			width : Ti.UI.FILL,
			//right:ro.ui.relX(1),
			//left:ro.ui.relX(1),
			layout : 'vertical',
			testRequired : true,
			isPrefView : true,
			itemTest : function(itemObj) {
				return testPrefs(itemObj);
			}
		});

		var hdr = layoutMenuHelper.menuHeaders({
			text : 'PREFERENCES'
		});
		returnView.add(hdr);

		for (var i = 0; i < prefsArray.length; i++) {
			returnView.add(prefsArray[i]);
		}
		returnView.reloadCpnSelections = editPrefs;
		returnView.reloadSelections = editPrefs;
		//scrollViewData.push(returnView);
	} catch(ex) {
		Ti.API.debug('prefs.js-Exception: ' + ex);
		ro.ui.alert('Preferences', 'CODE 100');

	}
	function editPrefs(isChosenPref) {
		try {
			var chosenPrefLength = isChosenPref.length || 0;
			for (var i = 0; i < chosenPrefLength; i++) {

				//Ti.API.debug('isChosenPref['+i+']: ' + JSON.stringify(isChosenPref[i]));

				var thisPicker = prefsArray[i].children[1];
				for (var j = 0; j < itemSelected.Prefs.length; j++) {
					if (isChosenPref[i].PrefName === itemSelected.Prefs[j].Name) {
						for (var k = 0; k < itemSelected.Prefs[j].PrefMbrs.length; k++) {
							if (isChosenPref[i].Name === itemSelected.Prefs[j].PrefMbrs[k].Name) {
								//Ti.API.debug('isChosenPref[i].Name: ' + isChosenPref[i].Name);
								thisPicker.setSelectedRow(0, k + 1, false);
								//thisPicker.setSelectedRow(0, k+1, false);
								ro.itemObj.setPrefs(isChosenPref[i].Name, j);

								/*if(thisPicker.UsePSMods){
								for(var l=0, lMax=isChosenPref.length; l<lMax; l++){
								var myRow = thisPicker.getSelectedRow(0);
								Ti.API.debug('myRow:' + JSON.stringify(myRow));
								}
								}*/

								//var theView = thisPicker.parent;
								//Ti.API.debug('theView: ' + JSON.stringify(theView));

								//var thisRow = thisPicker.children[0].rows[k+1];

								/*if(thisRow.idx !== 1){
								 if(thisRow.UsePSMods){//UseMods
								 var chosenPrefMods = isChosenPref[i].Mods || [];
								 var chosenPrefNoMods = isChosenPref[i].NoMods || [];

								 Ti.include('/revmobile/ui/mods_new.js');
								 theView.prefModsView.removeAllChildren();
								 var prefModInfo = getPrefModInfo(thisRow.ModGrpName, thisRow.PsItmName, thisRow.UsePSMods);
								 var prefModsHdr = layoutMenuHelper.menuHeaders({text:thisRow.name+' Options	                 *Click to expand', });
								 prefModsHdr.bottom = ro.ui.relY(5);
								 prefModsHdr.addEventListener('click', function(e){
								 var prefModWin = layoutMenuHelper.modalPrefWin();
								 getModsView(prefModInfo.grp, prefModInfo.itm, thisRow.name, function(prefModsView){
								 var prefModsBtn = layoutHelper.getBigButton('SAVE Modifiers', true);
								 prefModsBtn.addEventListener('click', function(){
								 prefModWin.close();
								 });
								 prefModWin.children[0].add(prefModsView);
								 prefModsBtn.top = 0;
								 prefModWin.children[0].add(prefModsBtn);
								 prefModWin.open();

								 }, chosenPrefMods, chosenPrefNoMods, null, null, function(){
								 prefModWin.close();
								 });
								 });
								 theView.prefModsView.add(prefModsHdr);
								 }

								 }*/

								break;
							}
						}
					}
				}
			}

			for (var j = 0,
			    jMax = prefsArray.length; j < jMax; j++) {
				var thePick = prefsArray[j].children[1];
				//Ti.API.debug('thePick: ' + JSON.stringify(thePick));
				if (thePick.UsePSMods) {

					var rowLength = thePick.pickRows && thePick.pickRows.length ? thePick.pickRows.length : 0;
					//Ti.API.debug('THIS PICKER LOGIC MAY BE INCORRECT EDIT PREFS FUNCTION mybe needs to be thePick.children[0].pickRows');
					//var
					for (var k = 0,
					    kMax = isChosenPref.length; k < kMax; k++) {
						for (var i = 0,
						    iMax =
						    rowLength; i < iMax; i++) {
							//var thisRow = thePick.children[0].rows[i];
							var thisRow = thePick.pickRows[i];

							if (thisRow.prefName == isChosenPref[k].Name) {
								var theView = thePick.parent;
								var chosenPrefMods = isChosenPref[k].Mods || [];
								var chosenPrefNoMods = isChosenPref[k].NoMods || [];

								var MODSVIEW = require('revmobile/ui/mods_new');
								theView.prefModsView.removeAllChildren();
								var prefModInfo = getPrefModInfo(thisRow.ModGrpName, thisRow.PsItmName, thisRow.UsePSMods);
								var prefModsHdr = layoutMenuHelper.menuHeaders({
									text : thisRow.title + ' Options	                 *Click to expand',
								});
								prefModsHdr.Mods = chosenPrefMods;
								prefModsHdr.NoMods = chosenPrefNoMods;
								prefModsHdr.bottom = ro.ui.relY(5);
								prefModsHdr.addEventListener('click', function(e) {
									var mds,
									    noMds;
									mds = this.Mods;
									noMds = this.NoMods;
									var prefModWin = layoutMenuHelper.modalPrefWin();

									var usePrefGroupHalf = null;
									if (ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.USE_PREF_GRP_HALF) {
										usePrefGroupHalf = {
											//USE_PREF_GRP_HALF:storeObj.Configuration.USE_PREF_GRP_HALF,
											AllowHalf : group.AllowHalf
										};
									}

									MODSVIEW.getModsView(prefModInfo.grp, prefModInfo.itm, {
										name : thisRow.name,
										title : thisRow.title
									}, function(prefModsView) {
										var prefModsBtn = layoutHelper.getBigButton('SAVE Modifiers', true);
										prefModsBtn.addEventListener('click', function() {
											prefModWin.close();
										});

										prefModsView.edit(mds, noMds);

										prefModWin.children[0].add(prefModsView);
										prefModsBtn.top = 0;
										prefModWin.children[0].add(prefModsBtn);
										prefModWin.open();

									}, this.Mods, this.NoMods, null, null, usePrefGroupHalf);
								});
								theView.prefModsView.add(prefModsHdr);

								break;
							}
						}
						//}
						//else{

						//}
					}
				}
			}

		} catch(ex) {
			if (Ti.App.DEBUGBOOL) {
				Ti.API.debug('editPrefs()-Exception: ' + ex);
			}
		}
	}

	function reloadPrefs() {

	}

	function getPrefModInfo(modGrpName, PSItmName, usePSMods) {
		//Ti.include('/logic/menuUtils.js');
		var menuUtils = require('logic/menuUtils');
		//Ti.include('../views/l-mods.js');
		var prefModGrp = menuUtils.getGrp(modGrpName, ro.app.Store.Menu);
		var prefPreMods = [],
		    theItem = {};

		if (usePSMods) {
			for (var i = 0,
			    iMax = prefModGrp.Items.length; i < iMax; i++) {
				if (prefModGrp.Items[i].Name == PSItmName) {
					theItem = prefModGrp.Items[i];
					break;
				}

			}
		} else {
			for (var i = 0,
			    iMax = prefModGrp.Items.length; i < iMax; i++) {
				if (prefModGrp.Items[i].Name == PSItmName) {
					theItem = prefModGrp.Items[i];
					break;
				}

			}
		}
		return {
			grp : prefModGrp,
			itm : theItem
		};
	}

	return returnView;
}; 