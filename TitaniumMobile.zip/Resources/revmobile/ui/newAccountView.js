var NEWACCOUNTVIEW = function(){
	var newaccountview = function(ro){
		var ad;
		var hasDOB = false;
	   ro.ui.createNewAccountView = function(LtyStores){
	       Ti.API.info('LtyStores: ' + JSON.stringify(LtyStores));
		  var NeedsAStore = false;
		  var LTY_ENROLL_TYPE = 0;
		  if(LtyStores && LtyStores.Stores && LtyStores.Stores.length){
		  	LtyStores = LtyStores.Stores;
		  }
	
	      var enableRewards = false;
	      var newAccount = {};
	      //var forms = require('/revmobile/ui/forms');
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
	         name:'Create Account',
	         hid:'newAccountView',
	         height:Ti.UI.FILL,
	         width:Ti.UI.FILL,
	         backgroundImage:ro.ui.properties.defaultPath + 'backgroundImg.png'//,
	         //borderColor:'black',
	         //borderWidth:5
	      }));
	
	      var btnCreate = layoutHelper.getBigButton('Create Profile');
	      //btnCreate.top = ro.ui.relY(15);
	    //  delete btnCreate.bottom;
	    var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnCreate);
	
	      btnCreate.addEventListener('click', function(e){
	      	
	      	//ad.showAlert('New Account', "response.Message");
      		//return;
	      	
	         ro.ui.showLoader();
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	
	         if(doPrivacy){
	         	if(!privacyPolicy.hasAccepted()){
	         		ro.ui.hideLoader();
	         		return;
	         	}
	         }
	         
	         if(doLoyaltyNoEclub){
	         	if(!ro.REV_LOYALTY.HasSelectedStore(LtyStores && LtyStores.length)){
	         		ro.ui.hideLoader();
	         		return;
	         	}
	         }
	
	         var values = ro.forms.getValues(form);
	         Ti.API.debug('values: ' + JSON.stringify(values));
			 //values = test();
			 ////Ti.API.debug('test: ' + JSON.stringify(values));
			 //var addr = profileChanges['stnumname'] + ', ' + profileChanges['city'] + ', ' + profileChanges['state'] + ', ' + profileChanges['zip'] + ', US';
	         
	         //Ti.include('/validation/accountValidation.js');
	         var accVal = require('validation/accountValidation');
	         var success = accVal.accValidate(values);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            var regexVal = require('validation/regexValidation');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	            	if(doPrivacy){
	            		values.AcceptedTerms = true;
	            	}
	            	if(doLoyalty){
	            		
	            		ro.REV_LOYALTY.setRequestObject(values);
	            	}
	            	
	            	if(doLoyaltyNoEclub){
	            		//Ti.API.debug('values: ' + JSON.stringify(values));
	            		if(LTY_ENROLL_TYPE == 0){
	            			ro.REV_LOYALTY.setRequestObjectNoEclub(values);
	            		}
	            		
	            		if(NeedsAStore){
	            			//alert("NeedsAStore: " + NeedsAStore);
	            			ro.REV_LOYALTY.setLtyStoreID(values, LTY_ENROLL_TYPE);
	            		}
	            	}
	
					if (Ti.App.reqAddr) {
	               		formRequest(values);
	               }
	               else{
	               	noAddrFormReq(values);
	               }
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      var btnCancel = layoutHelper.getBackBtn('CANCEL');
	      btnCancel.addEventListener('click', function(e){
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         ro.ui.closeNewAccount();
	      });
	
	      //Ti.include('/formControls/addressForm.js');
	      var addressForm = require('formControls/addressForm');
	      //Ti.include('/formControls/credentialsForm.js');
	      var credentialsForm = require('formControls/credentialsForm');
	      //Ti.include('/formControls/profileForm.js');
	      var profileForm = require('formControls/profileForm');
	
	      newAccount.finalForm = [];
	      newAccount.myAccount = false;
	      newAccount.userForm = credentialsForm.getUserForm();
	      //newAccunt.userForm[newAccount.userForm.length - 1].returnKeyType = null;
	
	      if(Ti.App.reqAddr){
	      	newAccount.addressForm = addressForm.getAddrForm();
	      }
	
	      newAccount.profileForm = profileForm.getProForm();
	
	      for(var i=0; i<newAccount.userForm.length; i++){
	         newAccount.finalForm.push(newAccount.userForm[i]);
		  }
	      for(var i=0; i<newAccount.profileForm.length; i++){
	         newAccount.finalForm.push(newAccount.profileForm[i]);
	      }
	
	      if(Ti.App.reqAddr){
		      for(var i=0; i<newAccount.addressForm.length; i++){
		         newAccount.finalForm.push(newAccount.addressForm[i]);
		      }
		   }
		   
		   for(var i=0, iMax=newAccount.finalForm.length; i<iMax; i++){
		      if(i !== iMax-1){
		      	newAccount.finalForm[i].returnKeyType = null;
		      }
		   }
		  
		  //Ti.API.debug('newAccount.finalForm: ' + JSON.stringify(newAccount.finalForm));
		  
		   ////Ti.API.debug('ro.ui.properties.myAccountView: ' + JSON.stringify(ro.ui.properties.myAccountView));
	      var form = ro.forms.createForm({
	         style:ro.forms.STYLE_LABEL,
	         fields:newAccount.finalForm,
	         settings:ro.ui.properties.myAccountView
	      });
	      form.bottom = null;
	
	      navBar.add(btnCancel);
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Create Account'}));
	         navBar.add(headerLbl);
	      } */
	
			var Config = JSON.parse(Ti.App.Properties.getString('Config'));
			if(!Config){
				Config = {};
			}
			
			 ro.REV_LOYALTY.init(true);
			 var doLoyalty = ro.REV_LOYALTY.isEnabled();
			 var doLoyaltyNoEclub = ro.REV_LOYALTY.isLoyaltyNoEClubEnabled();
	       
	       privacyPolicy.Init(Config.Docs, Config.PrivacyUrl, Config.TermsUrl, Config.DocsDate, Config.CompanyName, false, Config.TERMS_PRIVACY_POLICY ? Config.TERMS_PRIVACY_POLICY : false);
	       var doPrivacy = privacyPolicy.isEnabled();
	
	       //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, null, false, true));
	       
	       if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	       
	       var loginHdr = ro.layout.getGenericHdrRowWithHeader("Log In Information", true);
	       loginHdr.bottom = ro.ui.relY(10);
		   form.container.insertAt({
			   view:loginHdr,
			   position:0
		   });
	       
	       var personalInfoHdr = ro.layout.getGenericHdrRowWithHeader("Personal Information", true);
	       personalInfoHdr.bottom = ro.ui.relY(10);
		   form.container.insertAt({
			   view:personalInfoHdr,
			   position:7
		   });
		   
		   if(Ti.App.reqAddr){
		   	  var addressHdr = ro.layout.getGenericHdrRowWithHeader("Address Information", true);
		       addressHdr.bottom = ro.ui.relY(10);
			   form.container.insertAt({
				   view:addressHdr,
				   position:18
			   });
		   }
		   
	       
	       mainView.add(form);
	
			//Ti.API.debug('Config: ' + JSON.stringify(Config));
	
			 if(doLoyalty){
			 	/*if(!doLoyaltyNoEclub){
			 		if(Config.LTY_ENROLL_TYPE && LtyStores && LtyStores.length){
			 	       
			       	   switch(Config.LTY_ENROLL_TYPE){
			       	   	  case 1:
			       	   	  	//dropdown only
			       	   	  	
	          				var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView(Config.ST_EMAIL_CLUB, 1, LtyStores);
	          				form.container.add(LoyaltyView);
	          				
			       	   	  	break;
			       	   	  case 2:
			       	   	  	//dropdown and checkbox
			       	   	  	var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView(Config.ST_EMAIL_CLUB, 2, LtyStores);
	          				form.container.add(LoyaltyView);
	          				
	          				
	          				
			       	   	  	break;
			       	   }
			       	   
			       	   
			 		}
			 		else{
			 			var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView(Config.ST_EMAIL_CLUB);
	          			form.container.add(LoyaltyView);
			 		}
			 	}
			 	else{
			 		var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView(Config.ST_EMAIL_CLUB);
	          		form.container.add(LoyaltyView);
			 	}*/
	          var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView(Config.ST_EMAIL_CLUB);
	          //form.container.add(LoyaltyView);
	          form.container.insertAt({
				   view:LoyaltyView,
				   position:18
			   });
			 }
	       
	       //Ti.API.debug('NEWACC - LtyStores: ' + JSON.stringify(LtyStores));
	       //Ti.API.debug('NEWACC - LTY_ENROLL_TYPE: ' + Config.LTY_ENROLL_TYPE);
	       
	       if(doLoyaltyNoEclub){
	       	  if(Config.LTY_ENROLL_TYPE){
	       	  	 LTY_ENROLL_TYPE = Config.LTY_ENROLL_TYPE;
	       	  	 if(Config.LTY_ENROLL_TYPE && LtyStores && LtyStores.length){
	       	  	 	   NeedsAStore = true;
			       	   switch(parseInt(Config.LTY_ENROLL_TYPE,10)){
			       	   	  case 1:
			       	   	  	//dropdown only
			       	   	  	/*var LoyaltyPicker = ro.REV_LOYALTY.getLoyaltyPicker(LtyStores);
	          				form.container.add(LoyaltyPicker);*/
	          				var newLoyaltyWebView = Ti.UI.createView({
					          	height:0,
					          	width:Ti.UI.FILL
					          });
					          mainView.add(newLoyaltyWebView);
					
					          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true, false, 1, LtyStores);
					          //form.container.add(newLoyaltyView);
					          form.container.insertAt({
								   view:newLoyaltyView,
								   position:18
							   });
	          				
			       	   	  	break;
			       	   	  case 2:
			       	   	  	//dropdown and checkbox
	          				
	          				/*var LoyaltyPicker = ro.REV_LOYALTY.getLoyaltyPicker(LtyStores);
	          				form.container.add(LoyaltyPicker);*/
	          				
	          				var newLoyaltyWebView = Ti.UI.createView({
					          	height:0,
					          	width:Ti.UI.FILL
					          });
					          mainView.add(newLoyaltyWebView);
					
					          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true, false, 2, LtyStores);
					          //form.container.add(newLoyaltyView);
					          form.container.insertAt({
								   view:newLoyaltyView,
								   position:18
							   });
	          				
			       	   	  	break;
			       	   }
			       	   
			       	   
			 		}
			 		else{
			 			NeedsAStore = false;
			 			//Ti.API.debug('inside else');
			 			var newLoyaltyWebView = Ti.UI.createView({
				          	height:0,
				          	width:Ti.UI.FILL
				          });
				          mainView.add(newLoyaltyWebView);
				
				          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true);
				          //form.container.add(newLoyaltyView);
				          form.container.insertAt({
							   view:newLoyaltyView,
							   position:18
						   });
			 		}
	       	  	 
	       	  }
	       	  else{
	       	  	//Ti.API.debug('inside BIGGER else');
	       	  	 var newLoyaltyWebView = Ti.UI.createView({
		          	height:0,
		          	width:Ti.UI.FILL
		          });
		          mainView.add(newLoyaltyWebView);
		
		          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true);
		          //form.container.add(newLoyaltyView);
		          form.container.insertAt({
					   view:newLoyaltyView,
					   position:18
				   });
	       	  }
	       }
	       
	       if(doPrivacy){
	          var privWebView = Ti.UI.createView({
	          	height:0,
	          	width:Ti.UI.FILL,
	          	layout:'vertical'
	          });
	          mainView.add(privWebView);
	
	          var privView = privacyPolicy.getNewPolicyView(privWebView);
	          form.container.add(privView);
	       }
	       
			//Ti.API.debug('returning222222222');
	       form.container.add(btnWrapper);
	
	       ro.app.GA.trackPageView(mainView.hid);
		   ro.ui.hideLoader();
		   //var REV_POPUP = require('/logic/REV_POPUP');
		   ad = ro.popup(function(){
	          ro.REV_GUEST_ORDER.setIsGuestOrder(false);
	          var skipAnalytics = true;
	          ro.ui.closeNewAccount(skipAnalytics);
					//Ti.App.Username = req.Email;
					
					ro.REV_LOYALTY.afterAccountCreation();
					
	       });
		   mainView.add(ad);
	
	       return mainView;
	  	};
		var test = function(){
			return{
				email:"wadaadw@rev.com",
                password:"1",
                verifynewpass:"1",
                firstname:"c",
                lastname:"b",
                title:"Ms.",

				stnumname:"11411 blue gama",
                city:"houston",
                state:"tx",
                zip:"77095",

                label:"my house",
                //profileChanges['unitnum'] = "";
                //profileChanges['unitname'] = "";
                unitnum:"",
                unitname:"",
                addrtype:"House",
                phone:"7138052316",
                extension:"",
                CountryCode:"US"
			};
		};
	   function formRequest(profileChanges){
	   	
	   		//profileChanges = test();
	   	
	      var req = {}, success = 0;
	      try{
	//         var addr = profileChanges['stnumname'] + ', ' + profileChanges['city'] + ', ' + profileChanges['state'] + ', ' + profileChanges['zip'] + ', US';
	         var addr = profileChanges['stnumname'] + ', ' + profileChanges['city'] + ', ' + profileChanges['state'] + ', ' + profileChanges['zip'] +', ' + (profileChanges['CountryCode'] || "US");//', US';
	
			 var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	      	if(!cfg){
	      	   cfg = {};
	      	}
	      	var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
			
			//Ti.include('/app.geo.js');
			var hrush = {
				geo:require('app.geo')
			};
			hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy);
			hrush.geo.geocode2(addr, function(addresses){
				//Ti.API.debug('addresses: ' + JSON.stringify(addresses));
				if(!addresses || !addresses.data || !addresses.data.length){
			      	ro.ui.hideLoader();
			      	
			      	var msg = 'Please check address';
			      	if(addresses && addresses.message){
			      		msg = addresses.message;
			      	}
			      	ro.ui.alert('Error: ', msg);
			      	return;
			    }
			    
			    function getReq(addrIdx){
			    	if(!addresses.data[addrIdx].StNumber || !addresses.data[addrIdx].StNumber.length){
		           	   ro.ui.hideLoader();
		           	   ro.ui.alert('Error: ', 'Street # is required');
		           	   return;
		            }
	               		if(profileChanges.AcceptedTerms){
									req.AcceptedTerms = true;
								}
	
								if(addresses.data[addrIdx].City && addresses.data[addrIdx].City.length){
						      	profileChanges['city'] = addresses.data[0].City;//Uses the City value returned from the module. Otherwise, it uses the users input value;
						      }
	
						      if(addresses.data[addrIdx].State && addresses.data[addrIdx].State.length){
						      	profileChanges['state'] = addresses.data[addrIdx].State;//Uses the State value returned from the module. Otherwise, it uses the users input value;
						      }
	
						      if(addresses.data[addrIdx].Zip && addresses.data[addrIdx].Zip.length){
						      	profileChanges['zip'] = addresses.data[addrIdx].Zip;//Uses the Zip value returned from the module. Otherwise, it uses the users input value;
						      }
	
		               	req.Lat = addresses.data[addrIdx].Lat;
		                  req.Lon = addresses.data[addrIdx].Lon;
	
		                  req.Email = profileChanges['email'];
		                  req.Pass = profileChanges['password'];
		                  req.FName = profileChanges['firstname'];
		                  req.LName = profileChanges['lastname'];
		                  req.Title = profileChanges['title'];
	
		                  req.StNum = addresses.data[addrIdx].StNumber;
		                  req.St = addresses.data[addrIdx].Street;
	
		                  req.City = profileChanges['city'];
		                  req.State = profileChanges['state'];
		                  req.Zip = profileChanges['zip'];
	
		                  req.Label = profileChanges['label'];
		                  req.SUD = profileChanges['unitnum'];
		                  req.CustAddrTypeName = profileChanges['unitname'];
		                  req.AddrTypeName = profileChanges['addrtype'];
		                  req.Phone = profileChanges['phone'];
						  req.Ext = profileChanges['extension'];
						  if (hasDOB) {
						  	var dob = profileChanges['dob'].toJSON();
						  	var dobLst = dob.split("T");
						  	req.DOB = dobLst[0] + "T00:00:00"
						  }
		                  req.RevKey = 'test';
	
		                  if(!isNaN(profileChanges['EClubOptIn'])){
		                  	req.EClubOptIn = profileChanges['EClubOptIn'];
		                  }
		                  
		                  if(!isNaN(profileChanges['LtyOptIn'])){
		                  	req.LtyOptIn = profileChanges['LtyOptIn'];
		                  }
						  
						  if(!isNaN(profileChanges['LtyStoreID'])){
						  	req.LtyStoreID = profileChanges['LtyStoreID'];
						  }
						  
		                  contactServer(req);
	               	}
	               	var GEO = require('geo');
	           	if(addresses.data.length > 1){
	           		GEO.displayList(addresses.data, getReq);
	           	}
	           	else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
	           		GEO.displayList(addresses.data, getReq);
	           	}
	           	else{
	           		getReq(0);
	           	}
	           	
			}, true, GOOG_MAPS_KEY);
			return;
	
	         /*if(!Ti.Network.online){
	            ro.ui.hideLoader();
	            return;
	         }
	         else{
	            var xhrGeocode = Ti.Network.createHTTPClient();
	            xhrGeocode.setTimeout(120000);
	
	            xhrGeocode.onload = function(e){
	               var response = JSON.parse(this.responseText);
	               if(response.status == 'OK' && response.results != undefined && response.results.length > 0){
	
	               	var addresses = GEO.parseResults(response.results, true, Ti.App.AllowLongSt);
	
	               	function getReq(addrIdx){
	               		if(profileChanges.AcceptedTerms){
									req.AcceptedTerms = true;
								}
	
								if(addresses[addrIdx].City && addresses[addrIdx].City.length){
						      	profileChanges['city'] = addresses[0].City;//Uses the City value returned from the module. Otherwise, it uses the users input value;
						      }
	
						      if(addresses[addrIdx].State && addresses[addrIdx].State.length){
						      	profileChanges['state'] = addresses[addrIdx].State;//Uses the State value returned from the module. Otherwise, it uses the users input value;
						      }
	
						      if(addresses[addrIdx].Zip && addresses[addrIdx].Zip.length){
						      	profileChanges['zip'] = addresses[addrIdx].Zip;//Uses the Zip value returned from the module. Otherwise, it uses the users input value;
						      }
	
		               	req.Lat = addresses[addrIdx].Lat;
		                  req.Lon = addresses[addrIdx].Lon;
	
		                  req.Email = profileChanges['email'];
		                  req.Pass = profileChanges['password'];
		                  req.FName = profileChanges['firstname'];
		                  req.LName = profileChanges['lastname'];
		                  req.Title = profileChanges['title'];
	
		                  req.StNum = addresses[addrIdx].StNumber;
		                  req.St = addresses[addrIdx].Street;
	
		                  req.City = profileChanges['city'];
		                  req.State = profileChanges['state'];
		                  req.Zip = profileChanges['zip'];
	
		                  req.Label = profileChanges['label'];
		                  req.SUD = profileChanges['unitnum'];
		                  req.CustAddrTypeName = profileChanges['unitname'];
		                  req.AddrTypeName = profileChanges['addrtype'];
		                  req.Phone = profileChanges['phone'];
		                  req.Ext = profileChanges['extension'];
		                  req.RevKey = 'test';
	
		                  if(!isNaN(profileChanges['EClubOptIn'])){
		                  	req.EClubOptIn = profileChanges['EClubOptIn'];
		                  }
	
		                  contactServer(req);
	               	}
	
	               	try{
	               		if(!addresses || !addresses.length || !addresses[0].StNumber || !addresses[0].StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
		               		ro.ui.alert('Error: ', 'Unable to find "Street Address".');
		               		ro.ui.hideLoader();
		               		return;
		               	}
	
		               	if(addresses.length > 1){
		               		GEO.displayList(addresses, getReq);
		               	}
		               	else{
		               		getReq(0);
		               	}
		               }
		               catch(ex){
		               	if(Ti.App.DEBUGBOOL){ Ti.API.debug('newAddressView-AddressModule-Exception: ' + ex); }
		               }
	
	
	               }
	               else{
	                  ro.ui.alert('Could not verify address. Please try again.', 'Error');
	                  ro.ui.hideLoader();
	               }
	            };
	            xhrGeocode.onerror = function(e){
	               ro.ui.hideLoader();
	               return;
	            };
	            var url = "http://maps.google.com/maps/api/geocode/json?address=" + addr.replace(' ', '+');
	            url += "&sensor=" + (Ti.Geolocation.locationServicesEnabled === true);
	            xhrGeocode.open("GET", url);
	            xhrGeocode.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
	            xhrGeocode.send();
	         }*/
	      }
	      catch(ex){
	         ro.ui.hideLoader();
	         ro.ui.alert('Error: ', ex);
	         Ti.API.debug('formReqest()-Exception: ' + ex);
	      }
	   };
	
	   function contactServer(req){		   
		   req.Url = ro.isiOS ? Ti.App.name + '://' : Ti.App.websiteURL + 'Account/EmailValidation';
		   var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
		   if (savedTokenObj && savedTokenObj.token) {
			   req.CustomerDevice = {};
			   req.CustomerDevice.DeviceID = Ti.Platform.id;
			   req.CustomerDevice.DeviceToken = savedTokenObj.token;
			   req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
		   }
	      ro.dataservice.post(req, 'CreateCustomer', function(response){
	         if(response){
	         	//Ti.API.debug('response: ' + JSON.stringify(response));
	            if(response.Value){
	            	
	
	            	ro.utils.removeProp('Store');
	            	//ro.utils.removeProp('DefaultStore');
	            	ro.REV_STORES.clearDefaultStore(true);
	
	               if(response.Config){
	                  Ti.App.Properties.setString('Config', JSON.stringify(response.Config));
	               }
	
	               /*var ad = Ti.UI.createAlertDialog({
	                  buttonNames:['OK'],
	                  title:'New Account',
	                  message:response.Message
	               });
	               ad.addEventListener('click', function(){
	                  ro.REV_GUEST_ORDER.setIsGuestOrder(false);
	                  var skipAnalytics = true;
	                  ro.ui.closeNewAccount(skipAnalytics);
							Ti.App.Username = req.Email;
							
							ro.REV_LOYALTY.afterAccountCreation();
							
	               });*/
	               /*if(saveCustomer(req, response.Id?response.Id:0)){
	                  ad.show();
	               }*/
	               if(saveCustomer(req, response.Id?response.Id:0)){
	               	  
	               	  Ti.App.Username = req.Email;
	                  ad.showAlert('New Account', response.Message);
	                  ro.ui.hideLoader();
	                  
	               }
	            }
	            else{
	               ro.ui.hideLoader();
	               ro.ui.alert('Create Account', 'Error:' + response.Message);
	            }
	         }
	         else{
	            ro.ui.hideLoader();
	         }
	      });
	   };
	
	   function saveCustomer(reqCust, Id){
	      var cust = {};
	      var Address = {};
	      Ti.App.Username = reqCust.Email;
	      Ti.App.Password = reqCust.Pass;

		  if (hasDOB) cust.DOB = reqCust.DOB;
	      cust.Ext = reqCust.Ext;
	      cust.Title = reqCust.Title;
	      cust.FirstName = reqCust.FName;
	      cust.LastName = reqCust.LName;
	      cust.Phone = reqCust.Phone;
	      cust.IsDefaultDelivery = false;
		  cust.Business_ID = 0;
		  cust.EmailVerificationStatus = 'Required';
	
	      if(!isNaN(reqCust.EClubOptIn)){
	         cust.EClubOptIn = reqCust.EClubOptIn;
	      }
	      if(!isNaN(reqCust.LtyOptIn)){
	         cust.LtyOptIn = reqCust.LtyOptIn;
	      }
	
	      if(Ti.App.reqAddr){
	      	Address.AddrTypeName = reqCust.AddrTypeName;
		      Address.StNum = reqCust.StNum;
		      Address.St = reqCust.St;
		      Address.Lat = reqCust.Lat;
		      Address.Lon = reqCust.Lon;
		      Address.City = reqCust.City;
		      Address.State = reqCust.State;
		      Address.Zip = reqCust.Zip;
		      Address.CustAddrTypeName = reqCust.CustAddrTypeName;
		      Address.SUD = reqCust.SUD;
		      Address.Label = reqCust.Label;
		      Address.IsDefault = false;
		      if(Id){
		      	Address.Id = Id;
		      }
	
		      cust.AddressCol = [];
		      cust.AddressCol[0] = Address;
		   }
	
	      ro.db.createCustomer(reqCust.Email, reqCust.Pass, 0, cust, true);
	      Ti.App.Properties.setString('Customer', JSON.stringify(cust));
	
	      return true;
	   };
	   function noAddrFormReq(profileChanges){
	   	var req = {};
	
	   	if(profileChanges.AcceptedTerms){
				req.AcceptedTerms = true;
			}
	
	       if(!isNaN(profileChanges['EClubOptIn'])){
	          req.EClubOptIn = profileChanges['EClubOptIn'];
	       }
	       
	       if(!isNaN(profileChanges['LtyOptIn'])){
	         req.LtyOptIn = profileChanges['LtyOptIn'];
	      }
	
	      req.Email = profileChanges['email'];
	      req.Pass = profileChanges['password'];
	      req.FName = profileChanges['firstname'];
	      req.LName = profileChanges['lastname'];
	      req.Title = profileChanges['title'];
	      req.Phone = profileChanges['phone'];
	      req.Ext = profileChanges['extension'];
	      req.RevKey = 'test';
	      contactServer(req);
	   }

	};
	return {
		newaccountview:newaccountview
	};
}();
module.exports = NEWACCOUNTVIEW;