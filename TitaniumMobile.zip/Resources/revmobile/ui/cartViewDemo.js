(function(){
try {
	ro.ui.createDemoCartView = function(_args){
	try	{
		var storeObj;
		var mainFont = {
			fontSize:ro.ui.scaleFont(11,0,0),
			fontWeight:'bold'
		};
		var tableData;
		var qty;
		var dlvAdded = false;
		
		var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
			name: 'cart',
			softInputMode:(Ti.UI.Android) ? Ti.UI.Android.SOFT_INPUT_ADJUST_PAN: '',
			hid:'demoCart'
		}));
		var itmTcktView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView,{name: 'Summary', top: ro.ui.relY(50)}));
		var topNavBar = Ti.UI.createView(ro.ui.properties.navBar);
		var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Cart(Demo)'}));
		topNavBar.add(headerLbl);
		var bottomNavBar = Ti.UI.createView(ro.ui.properties.bottomNavBar,{zIndex:10});
		
		var btnContinue = Ti.UI.createButton(ro.combine(ro.ui.properties.backBtn, {
			title: 'Menu'
		}));
		btnContinue.addEventListener('click', function(){
			ro.ui.changeTab({tabIndex:0});
			ro.ui.showTabview();
		});
		var btnPayment = Ti.UI.createButton(ro.combine(ro.ui.properties.logoutBtn, {
   		title:'Payment',
   		visible:false,
   		backgroundImage:ro.ui.properties.defaultPath + 'forward.png',
   		backgroundSelectedImage:ro.ui.properties.defaultPath + 'forwardPress.png'
   	}));
		btnPayment.addEventListener('click', function(){
			ro.ui.demoCartShowNext({addView:true, showing:'Payment'});
		});
		var btnClear = Ti.UI.createButton(ro.combine(ro.ui.properties.backBtn, {
		   title:'Clear',
		   visible:false
		}));
		var btnCoupons = Ti.UI.createButton(ro.combine(ro.ui.properties.couponBtn, {
   		title:'Coupons',
   		visible:false,
   		backgroundImage:ro.ui.properties.defaultPath + 'forward.png',
   		backgroundSelectedImage:ro.ui.properties.defaultPath + 'forwardPress.png'
   	}));
		
		topNavBar.add(btnContinue);
		bottomNavBar.add(btnPayment);
		bottomNavBar.add(btnClear);
		bottomNavBar.add(btnCoupons);
		mainView.add(topNavBar);
		mainView.add(bottomNavBar);
		mainView.add(itmTcktView);
		
		var itemTable = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsTblView, {
			backgroundColor: 'transparent',
			separatorColor: 'transparent',
			top:ro.ui.relY(25),
			bottom:ro.ui.relY(90)
			})
		);
		
		var noItems = Ti.UI.createImageView({
			image:ro.ui.properties.defaultPath +  'cart.png',
			width: ro.ui.relY(128),
			height: ro.ui.relY(128)
		});
		itmTcktView.add(itemTable);
		itmTcktView.add(noItems);
		
		var totalsView = Ti.UI.createView(ro.ui.properties.grpBackgroundView);
		
		var subTotalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(5),
			width: ro.ui.relX(50),
			right: ro.ui.relX(70),
			text: 'Subtotal:',
			textAlign: 'right'
		}));
		var subTotalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(5),
			width: ro.ui.relX(60),
			right: ro.ui.relX(10),
			textAlign: 'right'
		}));
		var taxLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(20),
			width: ro.ui.relX(50),
			right: ro.ui.relX(70),
			text: 'Tax:',
			textAlign: 'right'
		}));
		var taxValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(20),
			width: ro.ui.relX(60),
			right: ro.ui.relX(10),
			textAlign: 'right'
		}));
		var delFeeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(35),
			width: ro.ui.relX(90),
			right: ro.ui.relX(120),
			textAlign: 'right'
		}));
		var totalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(35),
			width: ro.ui.relX(50),
			right: ro.ui.relX(70),
			text: 'Total:',
			textAlign: 'right'
		}));
		var totalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			top: ro.ui.relY(35),
			width: ro.ui.relX(60),
			right: ro.ui.relX(10),
			textAlign: 'right'
		}));
		totalsView.add(subTotalLbl);
		totalsView.add(subTotalValue);
		totalsView.add(taxLbl);
		totalsView.add(taxValue);
		totalsView.add(delFeeLbl);
		totalsView.add(totalLbl);
		totalsView.add(totalValue);
		itmTcktView.add(totalsView);
		
		var a = Ti.UI.createAlertDialog();
		
		btnClear.addEventListener('click', function(){
			a.title = 'Cancel Order';
			a.message = 'Do you wish to cancel order?';
			a.buttonNames = ['Yes', 'No'];
			a.cancel = 1;
			a.show();
			
		});
	
		function deleteItem(e){
			a.title = (e.source.rowType == 'item' ? 'Delete Item' : 'Delete Coupon');
			a.message = (e.source.rowType == 'item' ? 'Do you wish to remove this item from your order?' : 'Do you wish to remove this coupon from your order?');
			a.buttonNames = ['Yes', 'No'];
			a.cancel = 1;
			a.itmIndex = e.source.itmIndex;
			a.show();
		}
		
		function setVisibility(){
			var show = false;
			if (Ti.App.OrderObj.Items) {
				if (Ti.App.OrderObj.Items.length > 0) {
					show = true;
				}
			}
			if (show) {
				itemTable.show();
				noItems.hide();
				btnClear.visible=true;
				btnCoupons.visible = true;
				btnPayment.visible = true;
			}
			else {
				var test = Ti.App.OrderObj;
				test.Cpns = null;
				Ti.App.OrderObj = test;
				itemTable.data = [];
				itemTable.hide();
				noItems.show();
				subTotalValue.text = '$ 0.00';
				taxValue.text = '$ 0.00';
				totalValue.text = '$ 0.00';
				btnClear.visible=false;
				btnCoupons.visible = false;
				btnPayment.visible = false;
			}
			return show;
			
		}
		
		function showTicket(){
		
			if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
				delFeeLbl.text = '( Dlvy Fee incl. )';
			}
			else {
				delFeeLbl.text = '';
			}
			
			tableData = [];
			var childLevel = 3;
			for (var count = 0; count < Ti.App.OrderObj.Items.length; count++) {
				var itemObj = Ti.App.OrderObj.Items[count];
				var section = Ti.UI.createTableViewSection();
				var mainRow = Ti.UI.createTableViewRow({
					height:Ti.UI.SIZE,
					className:'mainRow'
				});
				var btnDelete = Ti.UI.createButton({
					left:0,
					backgroundImage:ro.ui.properties.defaultPath + 'delete@2x.png',
					height:ro.ui.relX(32),
					width:ro.ui.relX(32),
					rowType:'item',
					itmIndex:count
				});
				btnDelete.addEventListener('click', deleteItem);
				//*** Newly added				
				mainRow.add(btnDelete);

				var itmName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName,{
					text:(itemObj.Size == 'None' ? '' : itemObj.Size + ' ') + (itemObj.Style ? itemObj.Style + ' ' : '') + ' ' + itemObj.RcptName,
					width:ro.ui.relX(160),
					height:ro.ui.relY(25),
					left:ro.ui.relX(40),
					font:{
                  fontWeight:'bold',
                  fontSize:ro.ui.scaleFontY(11, 14),
                  fontFamily:ro.ui.fontFamily
               },
					textAlign:'left',
					color:ro.ui.theme.contentsSmallTxtHead
				}));
				
				mainRow.add(itmName);
				var itmPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
					text:(itemObj.ActivePrice == 0 ? '': '$' + itemObj.ActivePrice.toFixed(2)),
					right:ro.ui.relX(8),
					height:ro.ui.relY(25),
					width:ro.ui.relX(60),
					textAlign:'right'
				}));
				mainRow.add(itmPriceLbl);
				section.add(mainRow);
				
				var row, lbl, priceLbl;
				if(itemObj.PrfMbrs) {
					for(var i = 0; i < itemObj.PrfMbrs.length; i++){
						row = Ti.UI.createTableViewRow({
							height:ro.ui.relY(20),
							indentionLevel:childLevel,
							className:'subRow'
						});
						lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
							text: itemObj.PrfMbrs[i].RcptName
						}));
						priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
							text: (itemObj.PrfMbrs[i].ActivePrice == 0 ? '' : '$' + itemObj.PrfMbrs[i].ActivePrice.toFixed(2))
						}));
						row.add(lbl);
						row.add(priceLbl);
						section.add(row);
					};
				}
				
				if (itemObj.NoMods) {
				
					for (var j = 0; j < itemObj.NoMods.length; j++) {
						var noModName;
						switch (itemObj.NoMods[j].HalfStatus) {
							case 0:
								noModName = 'NO ' + itemObj.NoMods[j].RcptName;
								break;
							case 1:
								noModName = 'H1- ' + 'NO ' + itemObj.NoMods[j].RcptName;
								break;
							case 2:
								noModName = 'H2- ' + 'NO ' + itemObj.NoMods[j].RcptName;
								break;
						}
						row = Ti.UI.createTableViewRow({
							height: ro.ui.relY(20),
							indentionLevel: childLevel,
							className: 'subRow'
						});
						lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
							text: noModName
						}));
						priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
							text: ''
						}));
						row.add(lbl);
						row.add(priceLbl);
						section.add(row);
						
					};
									}
				
				if (itemObj.Mods) {
				
					for (var k = 0; k < itemObj.Mods.length; k++) {
						var modName;
						switch (itemObj.Mods[k].HalfStatus) {
							case 0:
								modName = (itemObj.Mods[k].Qty > 1 ? '2X ' : '') + itemObj.Mods[k].RcptName;
								break;
							case 1:
								modName = 'H1-' + (itemObj.Mods[k].Qty > 1 ? ' 2X ' : ' ') + itemObj.Mods[k].RcptName;
								break;
							case 2:
								modName = 'H2-' + (itemObj.Mods[k].Qty > 1 ? ' 2X ' : ' ') + itemObj.Mods[k].RcptName;
								break;
						}
						
						row = Ti.UI.createTableViewRow({
							height: ro.ui.relY(20),
							indentionLevel: childLevel,
							className:'subRow'
						});
						lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
							text: modName
						}));
					
						var price = '$' + itemObj.Mods[k].ActivePrice.toFixed(2);
						
						if (!(itemObj.Mods[k].ActivePrice) || itemObj.Mods[k].ActivePrice == 0) {
							price = ' ';
						}
						priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
							text: price
						}));
						row.add(lbl);
						row.add(priceLbl);
						section.add(row);
						
					}
				}
				
				row = Ti.UI.createTableViewRow({
					height:Ti.UI.SIZE,
					indentionLevel:childLevel,
					className:'qty'
				});
				var plusBtn = Ti.UI.createButton({
         			top:ro.ui.relY(5),
        				backgroundImage:ro.ui.properties.defaultPath + 'plus@2x.png',
        				width:ro.ui.relX(24),
        				height:ro.ui.relX(25),
        				right:ro.ui.relX(2),
        				itmIndex:count
        		});
        		plusBtn.addEventListener('click',INCREASE);
        			var qtyLbl = Ti.UI.createLabel({
        				top:ro.ui.relY(5),
        				text:'x'+ itemObj.Qty,
        				width:ro.ui.relX(22),
        				height:ro.ui.relY(24),
        				textAlign:'center',
        				right:ro.ui.relX(26),
        				itmIndex:count,
        				font:{fontSize:ro.ui.scaleFontY(12,24),fontWeight:'bold'},
        				color:ro.ui.theme.textColor
        		});
        		var minusBtn = Ti.UI.createButton({
        				top:ro.ui.relY(5),
        				backgroundImage:ro.ui.properties.defaultPath + 'minus@2x.png',
        				width:ro.ui.relX(24),
        				height:ro.ui.relX(25),
        				right:ro.ui.relX(48),
        				itmIndex:count,
        				enabled:(itemObj.Qty>1?true:false)
        		});    
        		minusBtn.addEventListener('click',DECREASE);
        		 row.add(minusBtn);
        		row.add(qtyLbl);       
        		row.add(plusBtn);      
				section.add(row);
				
				tableData.push(section);
			}
			if (Ti.App.OrderObj.Cpns) {
				for (var cpnIdx = 0; cpnIdx < Ti.App.OrderObj.Cpns.length; cpnIdx++) {
					var cpnSection = Ti.UI.createTableViewSection();
					var cpnRow = Ti.UI.createTableViewRow({
						height:Ti.UI.SIZE,
						className:'cpnRow'
					});
					var cpnDelete = Ti.UI.createButton({
						left:0,
						backgroundImage:ro.ui.properties.defaultPath + 'delete@2x.png',
						height:ro.ui.relX(32),
						width:ro.ui.relX(32),
						itmIndex:cpnIdx,
						rowType:'coupon'
					});
					cpnDelete.addEventListener('click', deleteItem);
					//*** Newly added
					cpnRow.add(cpnDelete);
					
					var cpnName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName,{
						text: '[' + Ti.App.OrderObj.Cpns[cpnIdx].RcptName + ']',
						color:ro.ui.theme.cpnColor,
						width: ro.ui.relX(160),
						height: ro.ui.relY(25),
						left: ro.ui.relX(40),
						textAlign: 'left'
					}));
					
					cpnRow.add(cpnName);
					
					var cpnPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
						text: (Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue > 0 ? '- ' + Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue.toFixed(2) : ''),
						color: 'red',
						textAlign: 'right',
						right: ro.ui.relX(8),
						height: ro.ui.relY(25),
						width: ro.ui.relX(60),
					}));
					
					cpnRow.add(cpnPriceLbl);
					cpnSection.add(cpnRow);
					tableData.push(cpnSection);
					
				}
			}
			itemTable.data = tableData;
			subTotalValue.text = '$' + Ti.App.OrderObj.Subtotal.toFixed(2);
			taxValue.text = '$' + Ti.App.OrderObj.Tax.toFixed(2);
			totalValue.text = '$' + Ti.App.OrderObj.ActiveTotal.toFixed(2);
		}
		
		
		ro.ui.reloadCartDemo = function(){
			try{
				var func = new PricingFunctions();
				if(setVisibility()){
					Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx);
					showTicket();
					var rowCount = 0;
					for(var i=0; i<tableData.length; i++){
						rowCount += tableData[i].rowCount;
					}
					itemTable.scrollToIndex(rowCount - 1);
				}
			} 
			catch(ex){
				ro.ui.alert('cart', 'Error occured. CODE: 102: ' + ex);
			}
		};
		
		btnCoupons.addEventListener('click', function(e){
			try{
				ro.ui.demoCartShowNext({showing:'Coupons',addView:true});
			} 
			catch(ex){
				ro.ui.alert('Error', 'Please try again.');
			}
		});
		
		
		a.addEventListener('click', function(e){
			try{
				if (e.index == 0) {
				var test = Ti.App.OrderObj;
				switch (e.source.title) {
				
					case "Cancel Order":
						test.Items = [];
						test.Cpns = null;
						break;
					case "Delete Item":
						test.Items.splice(e.source.itmIndex, 1);
						break;
					case "Delete Coupon":
						test.Cpns.splice(e.source.itmIndex, 1);
						break;
				}
				Ti.App.OrderObj = test;
				test = null;
				ro.ui.reloadCartDemo();
				}
			}
			catch(ex){
				ro.ui.alert('Cart','CL100');
			}
		});
		
		function INCREASE(e){
			var test = Ti.App.OrderObj;
			test.Items[e.source.itmIndex].Qty++;
			Ti.App.OrderObj=test;
			Ti.App.ItemsSplit = true;
			ro.ui.reloadCartDemo();
		}

		function DECREASE(e){
			var test = Ti.App.OrderObj;
			test.Items[e.source.itmIndex].Qty--;
			Ti.App.OrderObj=test;
			Ti.App.ItemsSplit = true;
			ro.ui.reloadCartDemo();
		}
		
		function encrypt(obj){
			try{
				var key = [156, 36, 46, 156, 33, 218, 42, 43, 45, 167, 44, 80, 37, 155, 112, 85];
				var iv = [33, 37, 85, 38, 35, 85, 222, 121, 100, 173, 58, 200, 184, 37, 209, 33];
				var iptStr = JSON.stringify(obj);
				var input = cryptoHelpers.convertStringToByteArray(iptStr);
				var crypted = slowAES.encrypt(input, slowAES.modeOfOperation.CBC, key, 16, iv);
				var base64String = cryptoHelpers.base64.encode_line(crypted.cipher);
				return base64String;
			}
			catch(ex){
				return '';
			}
		}
		
		ro.ui.refreshCartDemo = function(){
			try{
			   storeObj = ro.app.Store;
			   if(setVisibility()){
   				var rowCount = 0;
   				showTicket();
   				for(var i=0; i<tableData.length; i++){
   					rowCount += tableData[i].rowCount;
   				}
   				itemTable.scrollToIndex(rowCount - 1);
   			}
		   }
		   catch(ex){
				ro.ui.alert('Cart','CR100');
		   }
		};
		return mainView;
	 }
	 catch(e){
	 	ro.ui.alert('cart demo try ', e);
	 }
	};
}
catch(ex){
	ro.ui.alert('cart','CODE 500');
}
}());
