
var CARTVIEW = function() {
    var cartview = function(ro) {
        try {
            ro.ui.createCartView = function (_args) {
                //This needs to be improved more, what if there are multiple coupons which disqualify
                var checkCpnsForDisqualification = function(removingItemPrice) {
                    var ordObj = Ti.App.OrderObj;
                    if (!ordObj.Cpns || !ordObj.Cpns.length) return;
                    if (!ordObj.Items || !ordObj.Items.length) return;
                    if (!ordObj.TempCpns || !ordObj.TempCpns.length) {
                        ordObj.TempCpns = [];
                    }

                    var multiQualCpn = null;
                    var cpnRemoved = false;
                    Ti.API.info("Cpn length: "+ ordObj.Cpns.length);
                    for (var i = 0, iMax = ordObj.Cpns.length; i < iMax; i++) {
                        if (ordObj.Cpns[i].MultiQualTtl && ordObj.Cpns[i].MultiQualTtl > 0) {
                            multiQualCpn = ordObj.Cpns[i];
                            amtToSubtract = 0;
                            Ti.API.info("Items length: "+ ordObj.Cpns.length);
                            for (var j = 0, jMax = ordObj.Items.length; j < jMax; j++) {
                                currItem = ordObj.Items[j];
                                if (currItem.realCpnKey == multiQualCpn.SelectedCoupon.Key) {
                                    amtToSubtract += currItem.RollupPrice;
                                }
                            }

                            if (!amtToSubtract || amtToSubtract <= 0) {
                                return;
                            }
                            if ((ordObj.Subtotal - amtToSubtract - removingItemPrice).toFixed(2) < multiQualCpn.MultiQualTtl) {
                                multiQualCpn.CpnActiveValue = null;
                                if (!cpnRemoved) cpnRemoved = true;
                                ordObj.Cpns.splice(i, 1);
                                ordObj.TempCpns.push(multiQualCpn);
                                for (var j = 0, jMax = ordObj.Items.length; j < jMax; j++) {
                                    currItem = ordObj.Items[j];
                                    if (currItem.realCpnKey == multiQualCpn.SelectedCoupon.Key) {
                                        ordObj.Items[j].tempCpnKey = currItem.realCpnKey;
                                    }
                                }
                                Ti.App.OrderObj = ordObj;
                                ordObj = null;
                            }
                            break;
                        }
                    }
                    Ti.API.info("cpnRemoved: " + cpnRemoved);
                    return cpnRemoved;
                };
                var checkTempCpnsForQualification = function() {
                    var OrdObj = Ti.App.OrderObj;
                    if (!OrdObj.TempCpns || !OrdObj.TempCpns.length) return;
                    if (!OrdObj.Items || !OrdObj.Items.length) return;
                    if (!OrdObj.Cpns || !OrdObj.Cpns.length) {
                        //var test = Ti.App.OrderObj;
                        OrdObj.Cpns = [];
                        //Ti.App.OrderObj = test;
                        //test = null;
                        //Ti.App.OrderObj.Cpns = [];
                    }
                    var tempCpn, currItem, amtToSubtract;
                    var cpnApplied = false;
                    Ti.API.info("Temp cpn length: "+ OrdObj.TempCpns.length);
                    for (var i = 0, iMax = OrdObj.TempCpns.length; i < iMax; i++) {
                        amtToSubtract = 0;
                        tempCpn = OrdObj.TempCpns[i];
                        Ti.API.info("Temp Items length: "+ OrdObj.Items.length);
                        for (var j = 0, jMax = OrdObj.Items.length; j < jMax; j++) {
                            currItem = OrdObj.Items[j];
                            if (currItem.tempCpnKey == tempCpn.SelectedCoupon.Key) {
                                amtToSubtract += currItem.RollupPrice;
                            }
                        }

                        if (!amtToSubtract || amtToSubtract <= 0) {
                            OrdObj.TempCpns.splice(i, 1);
                            cpnApplied = checkTempCpnsForQualification();
                            break;
                        }

                        if ((OrdObj.Subtotal - amtToSubtract).toFixed(2) >= tempCpn.MultiQualTtl) {
                            //Ti.API.info('b4 - OrdObj: ' + JSON.stringify(OrdObj));
                            var test = OrdObj;

                            test.Cpns.push(tempCpn);
                            test.TempCpns.splice(i, 1);

                            //Ti.API.info('after - OrdObj: ' + JSON.stringify(OrdObj));
                            var priceEngine = require('logic/pricing');
                            var func = priceEngine.pricer();
                            test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                            OrdObj = test;
                            test = null;
                            //ticketItemsBox.reprintTicket();

                            for (var j = 0, jMax = OrdObj.Items.length; j < jMax; j++) {
                                currItem = OrdObj.Items[j];
                                if (currItem.tempCpnKey == tempCpn.SelectedCoupon.Key) {
                                    OrdObj.Items[j].tempCpnKey = null;
                                }
                            }
                            Ti.App.OrderObj = OrdObj;
                            OrdObj = null;
                            cpnApplied = checkTempCpnsForQualification();
                            if (!cpnApplied) cpnApplied = true;
                            break;
                        }
                    }
                    Ti.API.info("cpnApplied: " + cpnApplied);

                    return cpnApplied;
                    //if (cpnApplied) {
                    //    Ti.API.info("03");
                    //   // ticketItemsBox.reprintTicket();
                    //}
                };
                if (!ro.app.Store || !Ti.App.OrderObj || ((!Ti.App.OrderObj.Items || !Ti.App.OrderObj.Items.length) && (!Ti.App.OrderObj.Cpns || !Ti.App.OrderObj.Cpns.length) && (!Ti.App.OrderObj.TempCpns || !Ti.App.OrderObj.TempCpns.length))) {

                    ro.ui.refreshCart = function(e) {};
                    ro.ui.reloadCart = function(_cbFn) {};

                    var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                        name: 'cart',
                        softInputMode: (Ti.UI.Android) ? Ti.UI.Android.SOFT_INPUT_ADJUST_PAN : '',
                        hid: 'Cart'
                    }));

                    var topNavBar = Ti.UI.createView(ro.ui.properties.navBar);
                    var btnContinue = layoutHelper.getBackBtn('MENU');
                    btnContinue.addEventListener('click', function(e) {
                        ro.ui.cartShowNext({
                            showing: 'Cart'
                        });
                    });


                    topNavBar.add(btnContinue);
                    //mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));

                    if (ro.isiphonex) {
                        var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                        var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                        var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                        navParent.add(topNav);
                        bottomNav.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                        navParent.add(bottomNav);
                        mainView.add(navParent);
                    } else {
                        mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                    }

                    var emptyCartView = Ti.UI.createView({
                        name: 'Summary',
                        top: ro.ui.properties.topAfterNavbar,
                        bottom: ro.ui.relY(60),
                        disableBounce: ro.isiOS ? true : false,
                        contentWidth: Ti.UI.FILL,
                        visible: true
                        //layout:'vertical',

                        //borderColor:'brown',
                        //borderWidth:2
                    });
                    var noItems = Ti.UI.createImageView({
                        image: ro.ui.properties.defaultPath + 'cartEmpty.png',
                        width: ro.ui.relY(128),
                        height: ro.ui.relY(128)
                    });
                    emptyCartView.add(noItems);

                    mainView.add(emptyCartView);
                    return mainView;
                }
                var storeObj = ro.app.Store;
                if (!storeObj) {
                    storeObj = {};
                }


                var menuUtils = require('logic/menuUtils');

                var checkoutHid = 'paymentScreen';
                var isGuest = false;
                if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                    checkoutHid = 'guestDetails';
                    isGuest = true;
                }
                //GUEST ORDERS

                var priceEngine = require('logic/pricing');
                var func = priceEngine.pricer();
                Ti.App.Properties.setBool('lvlupBool', false);

                var Config = JSON.parse(Ti.App.Properties.getString('Config'));
                if (!Config) {
                    Config = {};
                }
                ///////////         CCTIPS       ////////////
                //CC_TIPS.Init(Config.TipsHeader, Config.AllowCCTips, Config.AllowLUTips, Config.AllowGiftTips);
                ///////////         CCTIPS       ////////////


                /*if(Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length){
                    checkTempCpnsForQualification(Ti.App.OrderObj);
                }*/

                Ti.API.info('DEFINING MAIN VIEW');
                var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                    name: 'cart',
                    softInputMode: (Ti.UI.Android) ? Ti.UI.Android.SOFT_INPUT_ADJUST_PAN : '',
                    hid: 'Cart'
                }));

                var topNavBar = Ti.UI.createView(ro.ui.properties.navBar);
                var btnContinue = layoutHelper.getBackBtn('MENU');
                btnContinue.addEventListener('click', function(e) {
                    ro.ui.cartShowNext({
                        showing: 'Cart'
                    });
                });
                var btnCoupons = layoutHelper.getNewRightBtn('Deals', null, "/images/myDealsLight.png", 40);
                btnCoupons.hide();
                btnCoupons.addEventListener('click', function(e) {
                    try {
                        ro.ui.cartShowNext({
                            showing: 'Coupons',
                            addView: true
                        });
                    } catch (ex) {
                        ro.ui.alert('Error', 'Please try again.');
                    }
                });

                topNavBar.add(btnContinue);
                topNavBar.add(btnCoupons);
                //mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));

                if (ro.isiphonex) {
                    var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                    var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                    var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                    navParent.add(topNav);
                    bottomNav.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                    navParent.add(bottomNav);
                    mainView.add(navParent);
                } else {
                    mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                }

                //var cartView = Ti.UI.createView()

                var itmTcktView = Ti.UI.createScrollView({
                    name: 'Summary',
                    top: ro.ui.properties.topAfterNavbar,
                    bottom: ro.ui.relY(60),
                    disableBounce: ro.isiOS ? true : false,
                    contentWidth: Ti.UI.FILL,
                    layout: 'vertical',
                    visible: false
                    //borderColor:'brown',
                    //borderWidth:2
                });
                var emptyCartView = Ti.UI.createView({
                    name: 'Summary',
                    top: ro.ui.properties.topAfterNavbar,
                    bottom: ro.ui.relY(60),
                    disableBounce: ro.isiOS ? true : false,
                    contentWidth: Ti.UI.FILL,
                    visible: true
                    //layout:'vertical',

                    //borderColor:'brown',
                    //borderWidth:2
                });

                //BOTTOM NAVIGATION
                var bottomNavigationView = Ti.UI.createView({
                    height: ro.ui.relY(60),
                    width: Ti.UI.FILL,
                    bottom: 0,
                    visible: false,
                    backgroundColor: 'white'
                });
                var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
                greyBar.top = 0;
                bottomNavigationView.add(greyBar);
                var leftVw,
                    middleVw,
                    rightVw;

                leftVw = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: '35%',
                    left: 0,
                    layout: 'vertical'
                    /*,
                                         backgroundColor:'green'*/
                });
                leftVw.add(Ti.UI.createImageView({
                    image: '/images/leftArrow.png',
                    top: 0,
                    height: ro.ui.relY(40)
                    //bottom:20
                }));
                leftVw.add(Ti.UI.createLabel({
                    text: 'Back',
                    height: ro.ui.relY(20),
                    color: '#666',
                    font: {
                        fontFamily: ro.ui.fonts.navBtns,
                        fontSize: ro.ui.scaleFont(14)
                    }
                }));
                leftVw.addEventListener('click', function(e) {
                    ro.ui.cartShowNext({
                        showing: 'Cart'
                    });
                });

                middleVw = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: '30%',
                    layout: 'vertical'
                });
                middleVw.add(Ti.UI.createImageView({
                    image: '/images/clearBtn.png',
                    top: ro.ui.relY(4),
                    height: ro.ui.relY(35)
                }));
                middleVw.add(Ti.UI.createLabel({
                    text: 'Clear',
                    height: ro.ui.relY(20),
                    color: '#666',
                    top: ro.ui.relY(1),
                    font: {
                        fontFamily: ro.ui.fonts.navBtns,
                        fontSize: ro.ui.scaleFont(14)
                    }
                }));
                middleVw.addEventListener('click', function() {
                    /*a.title = 'Cancel Order';
                    a.message = 'Do you wish to cancel order?';
                    a.buttonNames = ['Yes', 'No'];
                    a.cancel = 1;
                    a.show();*/

                    var title = "Cancel Order";
                    var msg = 'Do you wish to cancel order?';
                    ro.ui.popup(title, ['Cancel', 'OK'], msg, function(ee) {
                        //var test = Ti.App.OrderObj;


                        ro.ui.clearCart();


                        ro.windowpopup.hideWindowpopup();
                        //Ti.App.OrderObj = test;
                        //test = null;                        
                        if (ticketItemsBox.reprintTicket()) {
                            btnCoupons.show();
                            itmTcktView.show();
                            bottomNavigationView.show();
                            emptyCartView.hide();
                        } else {
                            btnCoupons.hide();
                            itmTcktView.hide();
                            bottomNavigationView.hide();
                            emptyCartView.show();
                        }

                        ro.ui.reloadCart(function(e) {
                            areCouponsStillValid();
                        });
                    });

                });

                rightVw = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: '35%',
                    right: 0,
                    layout: 'vertical'
                });
                rightVw.add(Ti.UI.createImageView({
                    image: '/images/redRightArrow.png',
                    top: 0,
                    height: ro.ui.relY(40)
                }));
                rightVw.add(Ti.UI.createLabel({
                    text: 'Checkout',
                    height: ro.ui.relY(20),
                    color: ro.ui.theme.minorColor,
                    font: {
                        fontFamily: ro.ui.fonts.navBtns,
                        fontSize: ro.ui.scaleFont(14)
                    }
                }));
                rightVw.addEventListener('click', function() {
                    //Ti.include('/controls/paymentControl.js');
                    try {
                        if (!Ti.App.OrderObj.Items || !Ti.App.OrderObj.Items.length) {
                            ro.ui.alert('Error:', 'You must have at least one item before proceeding to checkout.');
                            return;
                        }
                        var payControl = require('controls/paymentControl');
                        payControl.clearPaymentInfo();
                        ro.utils.removeProp('favName');
                        require('logic/MultiplePmtHelper').SaveMultiPmts();

                        if (minOrdValidation()) {
                            var numItemsInCart = Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
                            if (REV_Suggest.init(storeObj.Configuration.ALLOW_SUGG, storeObj.Configuration.SUGG_MAX, storeObj.SuggItems, numItemsInCart)) {                                
                                if (REV_Suggest.needsSuggestion()) {
                                    ro.ui.cartShowNext({
                                        addView: true,
                                        showing: 'Suggest'
                                    });
                                } else {
                                    ro.ui.cartShowNext({
                                        addView: true,
                                        showing: checkoutHid
                                    });
                                }
                            } else {
                                ro.ui.cartShowNext({
                                    addView: true,
                                    showing: checkoutHid
                                });
                            }
                        }
                    } catch (ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('btnCheckout(Event)-Exception: ' + ex);
                        }
                    }
                });

                bottomNavigationView.add(leftVw);
                bottomNavigationView.add(middleVw);
                bottomNavigationView.add(rightVw);
                //BOTTOM NAVIGATION
                //END END END END END

                //ORDER TYPE AND LOCATION BLOCK
                var formattedText = storeObj && storeObj.Address ? (storeObj.Address + '\n' + (storeObj.City + ', ' + storeObj.State + ', ' + storeObj.Zip) + (storeObj.Distance ? ('\n(' + storeObj.Distance + ' miles)') : "")) : "";
                var estTimeTxt = "";
                for (var x = 0; x < storeObj.Menu.OnlineOptions.OrdTypes.length; x++) {
                    if (storeObj.Menu.OnlineOptions.OrdTypes[x].OrdType == Ti.App.OrderObj.OrdType) {
                        estTimeTxt = storeObj.Menu.OnlineOptions.OrdTypes[x].EstTime + " Minutes";
                        break;
                    }
                }
                var orderTypeBox = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: 0
                });
                var specialTextObj = null;
                if (estTimeTxt != "") {
                    specialTextObj = {
                        specialText: "",
                        specialBoldText: ""
                    };
                    var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
                    if (!cfg) {
                        cfg = {};
                    }
                    var carryoutLbl = 'Pickup';
                    var deliveryLbl = 'Delivery';
                    if (ro.utils.hasProp(cfg, 'CarryoutLabel')) {
                        carryoutLbl = cfg.CarryoutLabel;
                    }
                    if (ro.utils.hasProp(cfg, 'DeliveryLabel')) {
                        deliveryLbl = cfg.DeliveryLabel;
                    }
                    var specialText = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? deliveryLbl : carryoutLbl) + " - ";
                    //var specialText = "Estimated Order Time: ";
                    var specialBoldText = estTimeTxt;                    

                    specialTextObj.specialText = specialText;
                    specialTextObj.specialBoldText = specialBoldText;
                }
                var orderTypeBoxHdr = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'horizontal'
                });
                var ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.OrdType, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'OrdType');
                var ordName = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName ? ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName : Ti.App.OrderObj.OrdType;
                var ordTypeHdr = ro.layout.getGenericHdrRowWithHeader(ordName + " from", true);
                ordTypeHdr.width = Ti.UI.SIZE;
                orderTypeBoxHdr.add(ordTypeHdr);
                if (REV_ORD_TYPE.hasMultipleOrdTypes()) {
                    var editLbl = ro.layout.getGenericHdrRowWithHeader("(edit)", false);
                    editLbl.width = Ti.UI.SIZE;
                    editLbl.children[0].left = ro.ui.relX(8);
                    editLbl.children[0].color = "#eb0029";
                    editLbl.children[0].touchEnabled = true;
                    editLbl.touchEnabled = true;
                    orderTypeBoxHdr.add(editLbl);
                    editLbl.addEventListener('click', function (e) {      
                        REV_ORD_TYPE.promptForSpecificOrdType(function() {
                            ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.OrdType, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'OrdType');
                            ordName = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName ? ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName : Ti.App.OrderObj.OrdType;
                            ordTypeHdr.children[0].text = ordName + " from";
                            if (checkOrdTypeImage()) {
                                orderTypeImage.image = '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png';
                                OrderTypeLabel.text = ordName;
                                orderTypeImageHolder.height = Ti.UI.SIZE;
                            } else {
                                orderTypeImageHolder.height = 0;
                            }
                            
                            areOrdTypeCpnsValid();
                            if (ticketItemsBox.reprintTicket()) {                        
                                ro.ui.reloadCart();
                            };                            
                        });                        
                    });
                }               
                orderTypeBox.add(orderTypeBoxHdr);
                orderTypeBox.add(ro.layout.getGenericRowWithHeader({
                    formattedText: formattedText,
                    specialText: specialTextObj,                    
                    headerText: storeObj && storeObj.Name && storeObj.Name.length ? storeObj.Name.toUpperCase() : "",
                    customObj: {
                        borderColor: 'transparent'
                    }
                }));
                var orderTypeImageHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    layout: 'vertical'
                });
                var orderTypeImage = Ti.UI.createImageView({
                    height: ro.ui.relY(51),
                    top: ro.ui.relX(25)
                });
                var OrderTypeLabel = Ti.UI.createLabel({
                    font: {
                        fontSize: ro.ui.scaleFont(22),
                        fontFamily: ro.ui.fonts.titles
                    },
                    touchEnabled: false,
                    top: ro.ui.relX(5),
                    color: '#383938',
                    text: ordName
                });
                var checkOrdTypeImage = function () {
                    Ti.API.info("check Ord Type Image: " + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png').exists());
                    return Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png').exists();
                };
                if (checkOrdTypeImage()) {

                    orderTypeImage.image = '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png';
                    orderTypeImageHolder.add(orderTypeImage);
                    orderTypeImageHolder.add(OrderTypeLabel);
                    orderTypeImageHolder.height = Ti.UI.SIZE;
                    orderTypeBox.add(orderTypeImageHolder);
                } else {
                    orderTypeImageHolder.height = '0';
                }
                itmTcktView.add(orderTypeBox);

                //ORDER TYPE AND LOCATION BLOCK
                //END END END END END END

                //PROMO CODE BLOCK
                Ti.API.info('PROMO CODE BLOCK');
                if (storeObj && storeObj.Menu && menuUtils.hasValidCpnCode(storeObj.Menu)) {
                    var promoCodeBox = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth,
                        height: Ti.UI.SIZE,
                        layout: 'vertical',
                        top: 0 // ro.ui.relX(5)
                    });
                    var cpnCodeTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Enter A Coupon Code';
                    promoCodeBox.add(ro.layout.getGenericHdrRowWithHeader(cpnCodeTxt, true));
                    var cpnCodeLittleTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Coupon Code';

                    var cpnView = Ti.UI.createView({
                        top: 0, //ro.ui.relY(5),
                        height: ro.ui.relY(40),
                        //width:Ti.UI.FILL,
                        left: ro.ui.relX(25),
                        right: ro.ui.relX(25),
                        layout: 'horizontal'
                    });
                    var cpnTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                        left: 0,
                        width: '60%',
                        height: Ti.UI.FILL,
                        hintText: cpnCodeLittleTxt,
                        //bottom:ro.ui.relX(5),
                        font: {
                            fontFamily: ro.ui.fonts.textFields,
                            fontSize: ro.ui.scaleFont(18)
                        },
                        backgroundColor: '#f6f6f6',
                        borderColor: '#cbcbcb',
                        hintTextColor: '#393839'
                    }));

                    function getKeyboardToolbar(doneEvt) {
                        /*var picNext = Ti.UI.createButton({
                            title : 'Next',
                            style : Ti.UI.iOS.SystemButtonStyle.DONE,
                            id : keyboardBtnId
                        });*/
                        var picDone = Ti.UI.createButton({
                            title: 'Done',
                            style: Ti.UI.iOS.SystemButtonStyle.DONE //,
                            //id : keyboardBtnId
                        });

                        var picSpacer = Ti.UI.createButton({
                            systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
                        });

                        var picToolbar = Ti.UI.createToolbar({
                            top: 0,
                            items: [picSpacer, picDone],
                            zIndex: 2,
                            width: Ti.UI.FILL
                        });

                        picDone.addEventListener('click', doneEvt);
                        //picNext.addEventListener('click', nextEvt);

                        return picToolbar;
                    };
                    var doneFn = function() {
                        cpnTextBox.blur();
                    };
                    if (ro.isiOS) {

                        cpnTextBox.keyboardToolbar = getKeyboardToolbar(doneFn);
                    }

                    var cpnBtn = Ti.UI.createView({
                        width: Ti.UI.FILL,
                        height: Ti.UI.FILL,
                        right: ro.ui.relX(15),
                        left: ro.ui.relX(15),
                        backgroundColor: ro.ui.theme.btnActive,
                        borderColor: ro.ui.theme.btnActive,
                        borderRadius: ro.ui.relX(20),
                        //bottom:ro.ui.relX(5)
                    });
                    cpnBtn.add(Ti.UI.createLabel({
                        text: 'Add',
                        font: {
                            //fontWeight:'bold',
                            fontFamily: ro.ui.fonts.button,
                            fontSize: ro.ui.scaleFont(19),
                            //fontFamily:ro.ui.fontFamily
                        },
                        color: ro.ui.theme.loginBtnWhite,
                        textAlign: 'center',
                        touchEnabled: false
                    }));
                    cpnView.add(cpnTextBox);
                    cpnView.add(cpnBtn);

                    var cpnBtnClickTime = 0;
                    cpnBtn.addEventListener('click', function(e) {
                        if (new Date().getTime() - cpnBtnClickTime < 1000) {
                            Ti.API.info('returning');
                            return;
                        }
                        var thisClickTime = new Date();
                        cpnBtnClickTime = thisClickTime.getTime();
                        thisClickTime = null;

                        if (!cpnTextBox.value) {
                            ro.ui.alert('Error', 'Please enter a valid coupon code');
                            return;
                        }

                        if (ro.REV_LOYALTY.isValidCode(cpnTextBox.value)) {
                            ro.REV_LOYALTY.validateCoupon(cpnTextBox.value, storeObj.ID, function(newCode, LoyaltyCode) {
                                // menuUtils.testCpnCode(newCode, false, true, LoyaltyCode);


                                menuUtils.testCpnCode(newCode, false, true, LoyaltyCode);
                            }, false, false, function() {
                                menuUtils.testCpnCode(cpnTextBox.value, false, false); //DYNAMIC CODE NOT FOUND FALLBACK
                            });
                        } else {
                            menuUtils.testCpnCode(cpnTextBox.value, false, false);
                        }
                    });

                    //mainView.add(cpnBigView);

                    //promoCodeBox.add(cpnBtn);
                    //var promoCodeHdrTxt = "Promo Code";
                    //promoCodeBox.add(ro.layout.getGenericHdrRowWithHeader(promoCodeHdrTxt));
                    promoCodeBox.add(cpnView);
                    itmTcktView.add(promoCodeBox);
                }
                //PROMO CODE BLOCK
                //END END END END END END

                //TICKET ITEMS BLOCK
                var ticketItemsBox = Ti.UI.createView({
                    //width:ro.ui.relX(325),
                    width: Ti.UI.FILL, //ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(10) //,
                    //borderColor:'purple',
                    //borderWidth:1
                });

                var numItemsView = Ti.UI.createView(ro.ui.properties.genericMenuHdrRowViewWithHeader);

                var setItemNumbersText = function(count) {

                    var obj = {
                        hdr: count + " Item(s)",
                        body: " in Your Cart"
                    };
                    var text = obj.hdr + obj.body;
                    var attributesCol = [];
                    if (obj.hdr && obj.hdr.length) {
                        /*attributesCol = [{
                         type:Ti.UI.ATTRIBUTE_FONT,
                         value:{ fontSize: ro.ui.scaleFont(16), fontFamily: ro.ui.fonts.rowHdrTxt },
                         range:[text.indexOf(obj.hdr), obj.hdr.length]
                         }];*/
                        attributesCol.push({
                            type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                            value: '#eb0029',
                            range: [text.indexOf(obj.hdr), obj.hdr.length]
                        });
                    }
                    var attr = Ti.UI.createAttributedString({
                        text: text,
                        attributes: attributesCol
                    });
                    numItemsView.removeAllChildren();
                    numItemsView.add(Ti.UI.createLabel({
                        attributedString: attr,
                        font: {
                            //fontWeight:'bold',
                            fontSize: ro.ui.scaleFont(26),
                            fontFamily: ro.ui.fonts.titles
                        },
                        color: '#393839',
                        left: ro.ui.relX(25),
                        touchEnabled: false,
                        bottom: ro.ui.relY(5)
                    }));
                };

                function reprintTicket() {
                    var cpnCount = Ti.App.OrderObj && Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0;
                    var itemCount = Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
                    var tempCpnCount = Ti.App.OrderObj && Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length ? Ti.App.OrderObj.TempCpns.length : 0;
                    Ti.API.info("Reprinting Ticket");
                    var realItemCount = 0;
                    if (itemCount && itemCount > 0) {
                        realItemCount = 0;
                        for (var i = 0,
                                iMax = Ti.App.OrderObj.Items.length; i < iMax; i++) {
                            realItemCount += Ti.App.OrderObj.Items[i].Qty;
                        }
                        //itemCount = realItemCount;
                    }
                    var totalCount = realItemCount + cpnCount + tempCpnCount;
                    this.removeAllChildren();
                    setItemNumbersText(realItemCount);

                    if (itemCount) {
                        this.add(numItemsView);
                        this.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));

                        for (var i = 0, iMax = itemCount; i < iMax; i++) {
                            this.add(getTicketItemRow(i, i == 0));
                        }
                    }

                    var itmCpns = [];
                    for (var i = 0; i < Ti.App.OrderObj.Items.length; i++) {
                        var itm = JSON.parse(JSON.stringify(Ti.App.OrderObj.Items[i]));
                        if (itm && itm.CpnObj && Object.keys(itm.CpnObj) && Object.keys(itm.CpnObj).length) {                            
                            itm.CpnObj.itemIndex = i;
                            itmCpns.push(itm.CpnObj);
                        }
                    }
                    
                    if (tempCpnCount) {
                        this.add(getCpnRow(Ti.App.OrderObj.TempCpns, true));
                    }
                    var cpns = [];
                    if (cpnCount) {
                        cpns = cpns.concat(Ti.App.OrderObj.Cpns);
                    }
                    if (itmCpns.length) {
                        cpns = cpns.concat(itmCpns);
                    }
                    if (cpns.length) {
                        this.add(getCpnRow(cpns));
                    }
                    

                    return totalCount > 0;
                }
                ticketItemsBox.reprintTicket = reprintTicket;
                //ticketItemsBox.reprintTicket();
                itmTcktView.add(ticketItemsBox);

                //TICKET ITEMS BLOCK
                //END END END END END END

                // Moved this code from above to here, coz reprint ticket was not working in

                var test = Ti.App.OrderObj || {};
                if (!test) {
                    test = {};
                }
                //Ti.App.OrderObj
                if (!test.ordOnlineOptions) {
                    test.ordOnlineOptions = {};
                }
                Ti.App.OrderObj = test;
                test = null;
                if (Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length) {
                    if (checkTempCpnsForQualification()) {
                        ticketItemsBox.reprintTicket();
                    };
                }

                // end moving of code



                //UPSELL IN CART BLOCK
                var upsellBox = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: 0,
                    borderColor: 'green',
                    borderWidth: 1
                });
                //UPSELL IN CART BLOCK
                //END END END END END END

                //TICKET SUBTOTALS/TOTALS BLOCK
                var topOffset = ro.ui.relY(18);
                var sectionOffset = ro.ui.relY(10);
                var origSectionOffset = 0;
                var totalsView = Ti.UI.createView({
                    top: ro.ui.relY(15),
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    //width:ro.ui.relX(325)
                    width: ro.ui.properties.wideViewWidth
                });

                //var top = ro.ui.relY(5);
                var itemCountLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                    text: 'Item(s)'
                }));
                var itemCountValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                    //top: top
                }));
                var itemCountHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: ro.ui.properties.wideViewWidth,
                    top: ro.ui.relY(5)
                });
                itemCountHolder.add(itemCountLbl);
                itemCountHolder.add(itemCountValue);
                totalsView.add(itemCountHolder);

                var cpnSurchargeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                    text: 'Surcharge(s)'
                }));
                var cpnSurchargeValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                    //top: top
                }));
                var cpnSurchargeHolder = Ti.UI.createView({
                    height: ro.ui.relY(30),
                    width: ro.ui.properties.wideViewWidth,
                    top: ro.ui.relY(3)
                });
                cpnSurchargeHolder.add(cpnSurchargeLbl);
                cpnSurchargeHolder.add(cpnSurchargeValue);
                totalsView.add(cpnSurchargeHolder);

                //top += topOffset;
                //sectionOffset += origSectionOffset;
                //top += sectionOffset;
                var subTotalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                    text: 'Subtotal',
                    //top: top
                }));
                var subTotalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                    //top: top
                }));
                var subTotalHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: ro.ui.properties.wideViewWidth,
                    top: ro.ui.relY(3)
                });
                subTotalHolder.add(subTotalLbl);
                subTotalHolder.add(subTotalValue);
                totalsView.add(subTotalHolder);


                //Based on the current Surcharge setup in pricing, it appears that IF there are surcharges in the Store Menu, there will always be an equal number of surcharges attached to the order object
                //So when I get to the cart in some cases those surcharges havent been applied to the order obj until after the cart is created
                //Since I need to have pre created the surcharges in the ticket area at this point, I am doing so based on the Store Menu surcharges instead of the order obj surcharges 
                //Disregard earlier 3 lines of comment; no longer valid
                var hasPmntSurcharge = false;
                if (ro.app.Store && ro.app.Store.Surcharges && ro.app.Store.Surcharges.length){
                    var test = Ti.App.OrderObj;
                    test.PaymentsList = [];
                    test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                    Ti.App.OrderObj = test;
                    test = null;
                    for(var i=0; i<ro.app.Store.Surcharges.length; i++){
                        if(ro.app.Store.Surcharges[i].BusinessSurchargePayments && ro.app.Store.Surcharges[i].BusinessSurchargePayments.length){
                            hasPmntSurcharge = true;
                            break;
                        }
                    }
                }   
                var surchargeValueLbls = [];
                if (Ti.App.OrderObj.Surcharges && Ti.App.OrderObj.Surcharges.length) {
                    for (var i = 0, iMax = Ti.App.OrderObj.Surcharges.length; i < iMax; i++) {
                        var surchargeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                            text: Ti.App.OrderObj.Surcharges[i].RcptName
                        }));
                        var surchargeValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                            //top: top,
                            //text: "$" + Ti.App.OrderObj.Surcharges[i].ActivePrice
                        }));
                        var surchargeHolder = Ti.UI.createView({
                            height: Ti.UI.SIZE,
                            width: ro.ui.properties.wideViewWidth,
                            top: ro.ui.relY(3)
                        });
                        surchargeValueLbls.push(surchargeValue);
                        surchargeHolder.add(surchargeLbl);
                        surchargeHolder.add(surchargeValueLbls[i]);
                        totalsView.add(surchargeHolder);
                    }
                }

                if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                    if (storeObj && storeObj.Menu && storeObj.Menu.OnlineOptions &&
                        storeObj.Menu.OnlineOptions.DelivOpts &&
                        storeObj.Menu.OnlineOptions.DelivOpts.DeliveryFee &&
                        storeObj.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
                        var delFeeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                            //top: top,
                            text: 'Delivery'
                        }));
                        var delFeeVal = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                            //top: top
                        }));
                        var delFeeHolder = Ti.UI.createView({
                            height: Ti.UI.SIZE,
                            width: ro.ui.properties.wideViewWidth,
                            top: ro.ui.relY(3)
                        });
                        //delFeeVal.text = '$' + Ti.App.OrderObj.DlvyFee.toFixed(2);
                        delFeeVal.text = '$' + (Ti.App.OrderObj.DlvyFee ? Ti.App.OrderObj.DlvyFee.toFixed(2) : "0.00");

                        delFeeHolder.add(delFeeLbl);
                        delFeeHolder.add(delFeeVal);
                        totalsView.add(delFeeHolder);
                        Ti.API.info('ORD TYPE DELIVERY BLOCK');
                    }
                }
                var taxLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                    //top: top,
                    text: 'Tax'
                }));
                var taxValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                    //top: top
                }));
                var taxHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: ro.ui.properties.wideViewWidth,
                    top: ro.ui.relY(3)
                });
                taxHolder.add(taxLbl);
                taxHolder.add(taxValue);
                totalsView.add(taxHolder);

                if(hasPmntSurcharge){                    
                    var pmntSurchargeWarning = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                        text: 'Surcharge applicable for select Payments',
                        width: ro.ui.properties.wideViewWidth,
                    }));
                    var pmntSurchargeWarningHolder = Ti.UI.createView({
                        height: Ti.UI.SIZE,
                        width: ro.ui.properties.wideViewWidth,
                        top: ro.ui.relY(3)
                    });
                    pmntSurchargeWarningHolder.add(pmntSurchargeWarning);
                    totalsView.add(pmntSurchargeWarningHolder);
                }

                var totalsGreyView = Ti.UI.createView({
                    height: ro.ui.relY(40),
                    width: ro.ui.relX(210),
                    backgroundColor: '#f6f6f6',
                    //top: top,
                    right: 0

                });
                var totalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartTtlsLbls, {
                    text: 'Total',
                    //top: top,
                    height: ro.ui.relY(35),
                    color: ro.ui.theme.backgroundpngTxt,
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.rowHdrTxt,
                        fontSize: ro.ui.scaleFont(25 * .75)
                    }
                }));
                totalLbl.top = null;
                var totalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.newLblCartValuesLbls, {
                    //top: top,
                    color: ro.ui.theme.minorColor,
                    height: ro.ui.relY(35),
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(25 * 1.25)
                    }
                }));
                totalsGreyView.add(totalLbl);
                totalsGreyView.add(totalValue);
                totalsView.add(totalsGreyView);
                itmTcktView.add(totalsView);


                //TICKET SUBTOTALS/TOTALS BLOCK
                //END END END END END END

                //HONEYCOMB REWARDS BLOCK
                Ti.API.info('HC REQARDS BLOCK');
                var honeycombBox = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(20) //,
                    //borderColor: 'brown',
                    //borderWidth: 1
                });



                var ShowLtyView = function(resp, showEnrollMsg) {
                    this.removeAllChildren();
                    var dataLty = [];
                    var title = storeObj.Configuration.LTY_ENROLL_HDR && storeObj.Configuration.LTY_ENROLL_HDR.length ? storeObj.Configuration.LTY_ENROLL_HDR : "";
                    var fullTitle = resp.Points + " " + title;
                    var pointsMsg = "This order qualifies to earn " + fullTitle + " points.";
                    //var nonTitle = "This order qualifies to earn points.";
                    var signupMsg = "Not a member? [Sign up]";

                    var msg = storeObj.Configuration.LTY_CHK_PTS_TXT;
                    if (msg && msg.length) {
                        pointsMsg = msg.replace('[]', fullTitle);
                        // nonTitle = storeObj.Configuration.LTY_CHK_PTS_TXT.replace("[]", "");
                    }



                    var lblView = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth * .7,
                        height: Ti.UI.SIZE,
                        layout: 'vertical',
                        bottom: ro.ui.relY(15)
                    });
                    Ti.API.debug('pointsMsg: ' + pointsMsg);
                    var ptsAttributes = [];
                    var signupAttributes = [];
                    ptsAttributes.push({
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: '#eb0029',
                        range: [pointsMsg.indexOf(fullTitle), fullTitle.length]
                    });
                    ptsAttributes.push({
                        type: Ti.UI.ATTRIBUTE_FONT,
                        value: {
                            fontFamily: ro.ui.fonts.rowHdrTxt
                        },
                        range: [pointsMsg.indexOf(fullTitle), fullTitle.length]
                    });

                    /*if(msg && msg.length && (pointsMsg.indexOf(nonTitle) != -1)){
                         ptsAttributes.push({
                            type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                            value: '#393839',
                            range:[pointsMsg.indexOf(nonTitle), nonTitle.length]
                        });
                        ptsAttributes.push({
                           type: Ti.UI.ATTRIBUTE_FONT,
                           value: {
                               //fontFamily:ro.ui.fonts.rowHdrTxt
                                 fontFamily:ro.ui.fonts.rowBodyTxt,
                                 fontSize:ro.ui.scaleFont(19)
                           },
                           range: [pointsMsg.indexOf(nonTitle), nonTitle.length]
                        });
                    }*/



                    /*attributesCol.push({
                       type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                       value: ro.ui.theme.pendingPointsTxt,
                       range: [0, beginLength]
                   });*/
                    var ptsAttr = Ti.UI.createAttributedString({
                        text: pointsMsg,
                        attributes: ptsAttributes
                    });
                    var topLbl = Ti.UI.createLabel({
                        //text:pointsMsg,
                        attributedString: ptsAttr,
                        textAlign: 'center',
                        color: 'grey',
                        font: {
                            fontFamily: ro.ui.fonts.rowBodyTxt,
                            fontSize: ro.ui.scaleFont(19)
                        }


                    });
                    lblView.add(topLbl);
                    if (showEnrollMsg) {

                        var enrollMsg = storeObj.Configuration.LTY_SIGNUP_MSG;
                        if (enrollMsg && enrollMsg.length) {
                            signupMsg = enrollMsg;
                        }

                        Ti.API.debug('signupMsg: ' + signupMsg);

                        var beforeTxt = signupMsg.slice(0, signupMsg.indexOf('['));
                        var insideTxt = signupMsg.slice(signupMsg.indexOf('[') + 1, signupMsg.indexOf(']'));
                        var finalText = beforeTxt + insideTxt;

                        var signupAttributes = [];
                        signupAttributes.push({
                            type: Titanium.UI.ATTRIBUTE_UNDERLINES_STYLE,
                            value: Ti.UI.ATTRIBUTE_UNDERLINE_STYLE_SINGLE,
                            range: [finalText.indexOf(insideTxt), insideTxt.length]
                        });
                        signupAttributes.push({
                            type: Ti.UI.ATTRIBUTE_LINK,
                            value: '',
                            range: [finalText.indexOf(insideTxt), insideTxt.length]
                        });
                        signupAttributes.push({
                            type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                            value: 'grey',
                            range: [finalText.indexOf(insideTxt), insideTxt.length]
                        });
                        var signupAttr = Ti.UI.createAttributedString({
                            text: finalText,
                            attributes: signupAttributes
                        });


                        var bottomLbl = Ti.UI.createLabel({
                            //text:signupMsg,
                            attributedString: signupAttr,
                            color: 'grey',
                            textAlign: 'center',
                            font: {
                                fontFamily: ro.ui.fonts.policyLink,
                                fontSize: ro.ui.scaleFont(21)
                            },
                            top: ro.ui.relY(5)
                        });
                        bottomLbl.addEventListener('link', function(e) {
                            /*needsRst = true;
                            var url = Ti.App.websiteURL + 'Common/LtyTermsPolicy';
                            //Ti.API.debug('url: ' + url);
                            openWebview(url);*/
                            Ti.API.debug('clicked the link text');
                            REV_CUSTOMER.changeLtyOptIn(1, true, function() {});
                            bottomLbl.height = 0;

                        });

                        lblView.add(bottomLbl);
                    }
                    this.add(lblView);
                    //addLabels([storeObj.Address, storeObj.City + ', ' + storeObj.State + ', ' + storeObj.Zip], ltyRow);

                    /*var hrsView = Ti.UI.createView({
                       right:ro.ui.relX(5),
                       width:ro.ui.relX(100),
                       bottom:ro.ui.relY(5)
                    });
           
                    ltyRow.add(hrsView);*/
                    //dataLty[0] = ltyRow;

                    /*var tblViewLtyHeaderView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
                       right:ro.ui.relX(2),
                       left:ro.ui.relX(2),
                       top:ro.ui.relY(5),
                       focusable:false
                    }));
                    tblViewLtyHeaderView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
                       text:(storeObj.Configuration.LTY_ENROLL_HDR||"").toUpperCase(),
                       font:{
                          fontSize:ro.ui.scaleFont(15, 0, 0),
                          fontWeight:'bold',
                          fontFamily:ro.ui.fontFamily
                       }
                    })));*/

                    /*var tableViewLty = Ti.UI.createScrollView({
                       layout:'vertical',
                       //data:dataLty,
                       left:ro.ui.relX(2),
                       right:ro.ui.relX(2),
                       scrollable:false,
                       height:Ti.UI.SIZE,
                       separatorColor:ro.ui.theme.separatorColor,
                       borderColor:ro.ui.theme.loginGray,
                       borderWidth:ro.ui.relX(1),
                       backgroundColor:'white'
                    });
                    tableViewLty.add(ltyRow);
                    
                    */
                    /*if(showEnrollMsg){
                       
                       //tableViewLty.add()
                       var LoyaltyNoEClubView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(null, null, true, null, null, true);
                       LoyaltyNoEClubView.left = ro.ui.relX(5);
                       LoyaltyNoEClubView.right = ro.ui.relX(5);
                       LoyaltyNoEClubView.bottom = ro.ui.relY(5);
                       tableViewLty.add(LoyaltyNoEClubView);
                    }
                    
                    ltyNewView.add(tblViewLtyHeaderView);
                    ltyNewView.add(tableViewLty);
                    
                    ltyNewView.height = Ti.UI.SIZE;
                    ltyNewView.visible = true;
                    ltyNewView.show();*/
                };
                honeycombBox.ShowLtyView = ShowLtyView;


                itmTcktView.add(honeycombBox);

                //HONEYCOMB REWARDS BLOCK
                //END END END END END END

                var deletedItemHolder;
                var noItems = Ti.UI.createImageView({
                    image: ro.ui.properties.defaultPath + 'cartEmpty.png',
                    width: ro.ui.relY(128),
                    height: ro.ui.relY(128)
                });

                var a = Ti.UI.createAlertDialog();
                a.addEventListener('click', function(e) {
                    try {
                        if (e.index == 0) {
                            var test = Ti.App.OrderObj;

                            switch (e.source.title) {
                                case "Cancel Order":
                                    ro.ui.clearCart();
                                    break;
                                case "Delete Item":
                                    deletedItemHolder = test.Items[e.source.itmIndex];
                                    test.Items.splice(e.source.itmIndex, 1);
                                    if (deletedItemHolder && deletedItemHolder.CpnObj && deletedItemHolder.CpnObj.BogoID) {
                                        for (var i = 0; i < Ti.App.OrderObj.Items.length; i++) {
                                            if (Ti.App.OrderObj.Items[i].BogoID && (deletedItemHolder.CpnObj.BogoID == Ti.App.OrderObj.Items[i].BogoID)) {
                                                delete Ti.App.OrderObj.Items[i].BogoID;
                                            }
                                        }
                                    } else if (deletedItemHolder && deletedItemHolder.BogoID) {
                                        for (var i = 0; i < Ti.App.OrderObj.Items.length; i++) {
                                            if (Ti.App.OrderObj.Items[i].CpnObj && (Ti.App.OrderObj.Items[i].CpnObj.BogoID == deletedItemHolder.BogoID)) {
                                                delete Ti.App.OrderObj.Items[i].CpnObj;
                                            }
                                        }
                                    }
                                    break;
                                case "Delete Coupon":
                                    test.Cpns.splice(e.source.itmIndex, 1);
                                    break;
                            }

                            Ti.App.OrderObj = test;
                            test = null;
                            if (ticketItemsBox.reprintTicket()) {
                                btnCoupons.show();
                                itmTcktView.show();
                                bottomNavigationView.show();
                                emptyCartView.hide();
                            } else {
                                btnCoupons.hide();
                                itmTcktView.hide();
                                bottomNavigationView.hide();
                                emptyCartView.show();
                            }

                            ro.ui.reloadCart(function(e) {
                                areCouponsStillValid();
                            });

                        }
                    } catch (ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('CartCL100-Exception: ' + ex);
                        }
                        ro.ui.alert('Cart', 'CL100');
                    }
                });

                function findGroup(grpName) {
                    for (var i = 0,
                            iMax = storeObj.Menu.Groups.length; i < iMax; i++) {
                        if (storeObj.Menu.Groups[i].Name == grpName) {
                            return storeObj.Menu.Groups[i];
                        }
                    }
                }

                function findMenuItem(grp, rcptName) {
                    for (var i = 0,
                            iMax = grp.Items.length; i < iMax; i++) {
                        if (grp.Items[i].ReceiptName == rcptName) {
                            return grp.Items[i];
                        }
                    }
                }

                function getCpnRow(cpns, isTempCpns) {                    
                    var cpnView = Ti.UI.createView({
                        height: Ti.UI.SIZE,
                        width: ro.ui.properties.wideViewWidth
                    });
                    var rowHeight = Ti.UI.SIZE;
                    var row = Ti.UI.createView({
                        height: rowHeight,
                        borderWidth: ro.ui.relY(2),
                        borderRadius: ro.ui.relX(10),
                        width: ro.ui.properties.wideViewWidth * .85,
                        top: ro.ui.relY(5),
                        borderColor: '#e4e4e4',
                        layout: 'horizontal',
                        right: 0 //,
                        //elevation:7
                        //itmIndex: idx
                    });
                    var titleRow = Ti.UI.createView({
                        height: ro.ui.relY(30),
                        width: Ti.UI.FILL,
                        top: ro.ui.relY(3),
                        //layout:'horizontal'
                    });
                    var imageView = Ti.UI.createImageView({
                        image: '/images/myDeals.png',
                        height: ro.ui.relY(25),
                        left: ro.ui.relX(4)
                    });
                    var titleLbl = Ti.UI.createLabel({
                        text: 'Deals Applied',
                        color: '#eb0029',
                        font: {
                            fontFamily: ro.ui.fonts.rowHdrTxt,
                            fontSize: ro.ui.scaleFont(16)
                        },
                        textAlign: 'left',
                        left: ro.ui.relX(35)
                    });
                    titleRow.add(imageView);
                    titleRow.add(titleLbl);
                    row.add(titleRow);
                    for (var i = 0, iMax = cpns.length; i < iMax; i++) {
                        var printCpn = JSON.parse(JSON.stringify(cpns[i]));
                        delete printCpn.Items;
                        Ti.API.info("Cpn Object: " + JSON.stringify(printCpn));
                        var cpnObj = cpns[i];
                        var discountRow = Ti.UI.createView({
                            height: ro.ui.relY(25),
                            width: Ti.UI.FILL,
                            top: ro.ui.relY(3) //,
                            //layout:'horizontal'
                        });
                        var discountLbl = Ti.UI.createLabel({
                            text: cpnObj.RcptName,
                            color: '#393839',
                            font: {
                                fontFamily: ro.ui.fonts.rowHdrTxt,
                                fontSize: ro.ui.scaleFont(14)
                            },
                            textAlign: 'left',
                            left: ro.ui.relX(35),
                            right: ro.ui.relX(120),
                            ellipsize: Ti.UI.TEXT_ELLIPSIZE_TRUNCATE_END,
                            wordWrap: false,
                            maxLines: 1
                        });
                        discountRow.add(discountLbl);
                        var text = "Remove";
                        var attr = Titanium.UI.createAttributedString({
                            text: text,
                            attributes: [
                                // Underlines text
                                {
                                    type: Titanium.UI.ATTRIBUTE_UNDERLINES_STYLE,
                                    value: Ti.UI.ATTRIBUTE_UNDERLINE_STYLE_SINGLE,
                                    range: [text.indexOf(text), (text).length]
                                }
                            ]
                        });

                        var removeLbl = Ti.UI.createLabel({
                            color: '#eb0029',
                            //text:"Remove",
                            attributedString: attr,
                            font: {
                                fontSize: ro.ui.scaleFont(11),
                                fontFamily: ro.ui.fonts.policyLink
                            },
                            right: ro.ui.relX(70),
                            idx: i,
                            isItemCpn: cpnObj.hasOwnProperty("itemIndex"),
                            itemIndex: cpnObj.hasOwnProperty("itemIndex") ? cpnObj.itemIndex : null,
                            isBogo: cpnObj.CpnScope == 4,
                            BogoID: cpnObj.hasOwnProperty("BogoID") ? cpnObj.BogoID : null,
                            isTempCpn: isTempCpns,
                            //tempCpnKey:isTempCpns ? cpnObj.SelectedCoupon.Key : null
                            //width:ro.ui.relX(45)
                        });
                        removeLbl.addEventListener('click', function(e) {
                            Ti.API.debug('e.source.idx: ' + e.source.idx);
                            //'Delete Coupon''Do you wish to remove this coupon from your order?'
                            var title = 'Delete Coupon';
                            var msg = 'Do you wish to remove this coupon from your order?';
                            ro.ui.popup(title, ['Cancel', 'OK'], msg, function(ee) {
                                var test = Ti.App.OrderObj;
                                var itemCnt = 0;
                                if (test.Items && test.Items.length) {
                                    itemCnt = test.Items.length;
                                }
                                if (removeLbl.isTempCpn) {

                                    //cpnObj.SelectedCoupon.Key
                                    
                                    for (var i = 0, iMax = itemCnt; i < iMax; i++) {
                                        if (test.TempCpns[e.source.idx].SelectedCoupon.Key == test.Items[i].tempCpnKey) {
                                            test.Items[i].tempCpnKey = null;
                                        }
                                    }

                                    test.TempCpns.splice(e.source.idx, 1);
                                } else {
                                    if (e.source.isItemCpn && e.source.itemIndex != null) {
                                        if (e.source.isBogo) {
                                            for (var i = 0, iMax = itemCnt; i < iMax; i++) {
                                                if (test.Items[i].BogoID == e.source.BogoID) {
                                                    if (test.Items[i].hasOwnProperty("BogoCpnKey")) {
                                                        delete test.Items[i].BogoCpnKey;
                                                    }
                                                    if (test.Items[i].hasOwnProperty("BogoReq")) {
                                                        delete test.Items[i].BogoReq;
                                                    }
                                                    delete test.Items[i].BogoID;
                                                    break;
                                                }
                                            }
                                            if (test.Items[e.source.itemIndex].hasOwnProperty("BogoCpnKey")) {
                                                delete test.Items[e.source.itemIndex].BogoCpnKey;
                                            }
                                            if (test.Items[e.source.itemIndex].hasOwnProperty("BogoReq")) {
                                                delete test.Items[e.source.itemIndex].BogoReq;
                                            }
                                        }
                                        if (test.Items[e.source.itemIndex].hasOwnProperty("CpnObj")) {
                                            delete test.Items[e.source.itemIndex].CpnObj;
                                        }
                                        if (test.Items[e.source.itemIndex].hasOwnProperty("singleItemIdentifier")) {
                                            delete test.Items[e.source.itemIndex].singleItemIdentifier;
                                        }
                                    } else {
                                        var cpnToRemove = test.Cpns[e.source.idx];
                                        var cpnKeyToRemove = cpnToRemove.hasOwnProperty("SelectedCoupon") ? cpnToRemove.SelectedCoupon.Key : 0;
                                        for (var i = 0, iMax = itemCnt; i < iMax; i++) {
                                            if (test.Items[i].hasOwnProperty("CpnKey") && test.Items[i].CpnKey == cpnKeyToRemove) {
                                                delete test.Items[i].CpnKey;
                                                if (test.Items[i].hasOwnProperty("CpnItemSurcharge")) {
                                                    delete test.Items[i].CpnItemSurcharge;
                                                }
                                            }
                                        }
                                        test.Cpns.splice(e.source.idx, 1);
                                        cpnToRemove = null;
                                    }
                                }


                                ro.windowpopup.hideWindowpopup();
                                Ti.App.OrderObj = test;
                                test = null;
                                ro.ui.reloadCart(function (eee) {
                                    areCouponsStillValid();
                                });
                                if (ticketItemsBox.reprintTicket()) {
                                    btnCoupons.show();
                                    itmTcktView.show();
                                    bottomNavigationView.show();
                                    emptyCartView.hide();
                                } else {
                                    btnCoupons.hide();
                                    itmTcktView.hide();
                                    bottomNavigationView.hide();
                                    emptyCartView.show();
                                }
                            });
                        });
                        var priceLbl = Ti.UI.createLabel({
                            width: ro.ui.relX(50),
                            right: ro.ui.relX(6),
                            color: '#eb0029',
                            text: (cpnObj.CpnActiveValue > 0 ? '-$' + cpnObj.CpnActiveValue.toFixed(2) : (isTempCpns ? '-$0.00' : '')),
                            textAlign: 'right',
                            font: {
                                fontFamily: ro.ui.fonts.prices.normal,
                                fontSize: ro.ui.scaleFont(13)
                            }
                        });
                        discountRow.add(removeLbl);
                        discountRow.add(priceLbl);
                        row.add(discountRow);
                    }

                    cpnView.add(row);
                    return cpnView;
                }

                function getTicketItemRow(idx, isFirstRow) {
                    //Ti.API.info('Ti.App.OrderObj.Items[' + idx + ']: ' + JSON.stringify(Ti.App.OrderObj.Items[idx]));
                    var itemObj = Ti.App.OrderObj.Items[idx];
                    var noEdit = false;
                    var menuGroup = findGroup(itemObj.GroupName);
                    var menuItem = findMenuItem(menuGroup, itemObj.RcptName);
                    if (!itemObj.ItemType || itemObj.ItemType != 5) {
                        if (menuUtils.straightToCart(menuGroup, menuItem)) {
                            noEdit = true;
                        }
                    }                    

                    var largeRowHeight = 270;
                    var rowHeight = 150;
                    var row = Ti.UI.createView({

                        height: ro.ui.relY(largeRowHeight),
                        borderWidth: ro.ui.relY(2),
                        borderRadius: ro.ui.relX(10),
                        width: ro.ui.properties.wideViewWidth,
                        top: isFirstRow ? ro.ui.relY(15) : ro.ui.relY(5),
                        borderColor: '#e4e4e4',
                        layout: 'horizontal',
                        itmIndex: idx //,
                        //elevation:7
                    });
                    var leftParentView = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: '45%'
                    });
                    var leftVw,
                        rightVw;
                    var overlayRemoveVw,
                        labelVw,
                        removeVw;
                    leftVw = Ti.UI.createView({
                        height: ro.ui.relY(rowHeight),
                        //width:ro.ui.relX(325 * .45)
                        width: Ti.UI.FILL
                    });
                    var itemNameLbl,
                        itemPriceLbl,
                        itemImageVw;
                    itemNameLbl = Ti.UI.createLabel({
                        height: ro.ui.relY(20),
                        width: Ti.UI.FILL,
                        top: 0,
                        textAlign: 'center',
                        text: itemObj.RcptName,
                        font: {
                            fontFamily: ro.ui.fonts.titles,
                            fontSize: ro.ui.scaleFont(20) //,
                            //fontWeight:'bold'
                        },
                        color: ro.ui.theme.backgroundpngTxt,
                        zIndex: 1000
                    });
                    //Ti.API.info('itemObj: ' + JSON.stringify(itemObj));
                    var itemPrice = (itemObj.RollupPrice == 0 ? '' : '$' + itemObj.RollupPrice.toFixed(2));
                    if (itemObj.CpnObj) {
                        if (itemObj.CpnObj.CpnScope && itemObj.CpnObj.CpnScope == 2) {
                            itemPrice = (itemObj.ActivePrice == 0 ? itemPrice : '$' + itemObj.ActivePrice.toFixed(2));
                        }
                        /*else if(itemObj.CpnObj.CpnScope && itemObj.CpnObj.CpnScope == 4){
                            itemPrice = (itemObj.ActivePrice == 0 ? "" :  '$' + itemObj.ActivePrice.toFixed(2));
                        }*/
                    }


                    itemPriceLbl = Ti.UI.createLabel({
                        height: ro.ui.relY(20),
                        width: Ti.UI.FILL,
                        bottom: 0,
                        textAlign: 'center',
                        text: itemPrice,
                        font: {
                            fontFamily: ro.ui.fonts.prices.italic,
                            fontSize: ro.ui.scaleFont(14)
                        },
                        color: '#eb0029',
                        zIndex: 1000
                    });
                    itemImageView = Ti.UI.createImageView({
                        left: ro.ui.relX(5),
                        right: ro.ui.relX(5),
                        image: menuItem && menuItem.ImageSource ? menuItem.ImageSource : "",
                        zIndex: 1 
                    });
                    leftVw.add(itemNameLbl);
                    leftVw.add(itemImageView);
                    leftVw.add(itemPriceLbl);
                    leftParentView.add(leftVw);
                    rightVw = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: '55%'
                        //width:ro.ui.relX(325 * .55)
                    });
                    overlayRemoveVw = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL,
                        //touchEnabled: false,
                        zIndex: 1
                    });
                    removeVw = Ti.UI.createView({
                        itmIndex: idx,
                        type: 'item',
                        zIndex: 1,
                        //bogo:false,
                        right: ro.ui.relX(5),
                        top: ro.ui.relX(5),
                        height: ro.ui.relX(20),
                        width: ro.ui.relX(20),
                        backgroundImage: '/images/clearBtn.png'
                    });
                    removeVw.addEventListener('click', deleteItem);
                    //overlayRemoveVw.add(removeVw);
                    //rightVw.add(overlayRemoveVw);
                    rightVw.add(removeVw);
                    labelVw = Ti.UI.createView({
                        layout: 'vertical',
                        height: Ti.UI.SIZE,
                        width: Ti.UI.FILL,
                        right: ro.ui.relX(10)
                    });

                    var customizations = formItemTicket(itemObj, menuGroup, menuItem);
                    for (var i = 0, iMax = customizations.length; i < iMax; i++) {
                        labelVw.add(getFormattedString(customizations[i], (iMax - i), (i == 0)));
                    }

                    /*if(itemObj.tempCpnKey){
                        var discountTxt = '';
                        var tempCpnKey = itemObj.tempCpnKey;
                        Ti.API.info('tempCpnKey: ' + tempCpnKey);
                        for(var i=0, iMax=Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length ? Ti.App.OrderObj.TempCpns.length : 0; i<iMax; i++){
                            if(Ti.App.OrderObj.TempCpns[i].Key == tempCpnKey){
                                discountTxt = Ti.App.OrderObj.TempCpns[i].Name;
                            }
                        }
                    }*/

                    if (!itemObj.noEdit && !noEdit) {
                        var text = "Edit this Item";
                        var attr = Titanium.UI.createAttributedString({
                            text: text,
                            attributes: [
                                // Underlines text
                                {
                                    type: Titanium.UI.ATTRIBUTE_UNDERLINES_STYLE,
                                    value: Ti.UI.ATTRIBUTE_UNDERLINE_STYLE_SINGLE,
                                    range: [text.indexOf(text), (text).length]
                                }
                            ]
                        });
                        var editItemLabel = Ti.UI.createLabel({
                            itmIndex: idx,
                            attributedString: attr,
                            //text: "Edit this Item",
                            textAlign: 'left',
                            width: Ti.UI.FILL,
                            color: '#eb0029',
                            font: {
                                fontSize: ro.ui.scaleFont(14),
                                fontFamily: ro.ui.fonts.prices.italic
                            }
                        });
                        if (ro.isiOS) {
                            editItemLabel.top = ro.ui.relY(3);
                        }
                        editItemLabel.addEventListener('click', editCartItem);
                        labelVw.add(editItemLabel);
                    }

                    //QTY 
                    var qtyParentView = Ti.UI.createView({
                        layout: 'vertical',
                        width: Ti.UI.FILL,
                        height: ro.ui.relY(55)
                    });
                    var topPad, botPad, qtyView;
                    topPad = Ti.UI.createView({
                        height: ro.ui.relY(15),
                        width: Ti.UI.FILL
                    });
                    botPad = Ti.UI.createView({
                        height: ro.ui.relY(15),
                        width: Ti.UI.FILL
                    });
                    qtyView = Ti.UI.createView({
                        height: ro.ui.relY(40),
                        width: Ti.UI.FILL,
                        layout: 'horizontal'
                    });
                    qtyView.add(Ti.UI.createLabel({
                        height: Ti.UI.FILL,
                        width: Ti.UI.SIZE,
                        text: 'Qty:',
                        font: {
                            fontFamily: ro.ui.fonts.rowHdrTxt,
                            fontSize: ro.ui.scaleFont(14)
                        },
                        color: '#393839'
                    }));
                    var minusBtn, plusBtn, qtyLbl;
                    minusBtn = Ti.UI.createImageView({
                        left: ro.ui.relX(10),
                        width: ro.ui.relX(40),
                        image: '/images/greyMinus.png',
                        itmIndex: idx //,
                        //opacity:itemObj.Qty == 1 ? .5 : 1
                    });
                    plusBtn = Ti.UI.createImageView({
                        left: ro.ui.relX(10),
                        width: ro.ui.relX(40),
                        image: '/images/greyPlus.png',
                        itmIndex: idx
                    });
                    qtyLbl = Ti.UI.createLabel({
                        height: Ti.UI.FILL,
                        width: Ti.UI.SIZE, //ro.ui.relX(20),
                        left: ro.ui.relX(10),
                        text: itemObj.Qty,
                        textAlign: 'center',
                        font: {
                            fontFamily: ro.ui.fonts.rowHdrTxt,
                            fontSize: ro.ui.scaleFont(14)
                        },
                        color: '#393839'
                    });

                    //Ti.API.info("itemObj: " + JSON.stringify(itemObj));
                    if (itemObj.CpnApplied == 2 || itemObj.CpnObj || (itemObj.BogoCpnKey) || (itemObj.ItemType && itemObj.ItemType == 5)) {
                        minusBtn.opacity = .5;
                        plusBtn.opacity = .5;
                    } else {
                        minusBtn.addEventListener('click',
                            function(e) {
                                var qty = qtyLbl.text;
                                if (qty === 1) return;
                                //qtyLbl.text = --itemObj.Qty; This doesn't work perfectly.
                                qtyLbl.text = qty - 1;
                                DECREASE(e);
                            });
                        plusBtn.addEventListener('click',
                            function(e) {
                                var qty = qtyLbl.text;
                                qtyLbl.text = qty + 1;
                                //qtyLbl.text = ++itemObj.Qty; This doesn't work perfectly.
                                INCREASE(e);
                            });
                    }

                    qtyView.add(minusBtn);
                    qtyView.add(qtyLbl);
                    qtyView.add(plusBtn);
                    qtyParentView.add(topPad);
                    qtyParentView.add(qtyView);
                    //qtyParentView.add(botPad);

                    labelVw.add(qtyParentView);

                    function labelFix() {
                        labelVw.removeEventListener('postlayout', labelFix);
                        //Ti.API.info('labelVw: ' + JSON.stringify(labelVw));
                        //Ti.API.info('labelVw.rect: ' + JSON.stringify(labelVw.rect));
                        //Ti.API.info('ro.ui.relY(150): ' + ro.ui.relY(150));
                        if (labelVw.rect.height > ro.ui.relY(150)) {
                            row.height = labelVw.rect.height + ro.ui.relY(40);
                        } else if (labelVw.rect.height > ro.ui.relY(140)) {
                            row.height = ro.ui.relY(175);
                        } else if (labelVw.rect.height > ro.ui.relY(130)) {
                            row.height = ro.ui.relY(165);
                        } else {
                            row.height = ro.ui.relY(150);
                        }
                        /* if((labelVw.rect.height + ro.ui.relY(40)) <= ro.ui.relY(rowHeight)){
                                                    row.height = ro.ui.relY(rowHeight);
                                                }*/
                    }
                    labelVw.addEventListener('postlayout', labelFix);
                    //END QTY

                    rightVw.add(labelVw);
                    row.add(leftParentView);
                    row.add(rightVw);

                    return row;
                }

                function getFormattedString(itemCustomizations, zIndex, isFirst) {
                    var obj = itemCustomizations;
                    if (!obj || (!obj.hdr && !obj.body)) {
                        return Ti.UI.createLabel();
                    }

                    var text = obj.hdr + ' ' + obj.body;
                    /*Ti.API.debug('text: ' + text);
                    Ti.API.debug('obj.hdr: ' + obj.hdr);
                    Ti.API.debug('obj.body: ' + obj.body);

                    Ti.API.debug('text.indexOf(obj.hdr): ' + text.indexOf(obj.hdr));
                    Ti.API.debug('text.indexOf(obj.body): ' + text.indexOf(obj.body));*/
                    var attributesCol = [];

                    //rowBodyTxt:GothamBook,
                    //rowHdrTxt:GothamMedium
                    if (obj.hdr && obj.hdr.length) {
                        attributesCol = [{
                            type: Ti.UI.ATTRIBUTE_FONT,
                            value: {
                                fontSize: ro.ui.scaleFont(14),
                                fontFamily: ro.ui.fonts.rowHdrTxt
                            },
                            range: [text.indexOf(obj.hdr), obj.hdr.length]
                        }];
                        attributesCol.push({
                            type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                            value: obj.hdrClr && obj.hdrClr.length ? obj.hdrClr : ro.ui.theme.backgroundpngTxt,
                            range: [text.indexOf(obj.hdr), obj.hdr.length]
                        });
                    }

                    if (obj.body && obj.body.length) {
                        attributesCol.push({
                            type: Ti.UI.ATTRIBUTE_FONT,
                            value: {
                                fontSize: ro.ui.scaleFont(14),
                                fontFamily: ro.ui.fonts.rowBodyTxt
                            },
                            range: [text.indexOf(obj.body), obj.body.length]
                        });
                        attributesCol.push({
                            type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                            value: ro.ui.theme.backgroundpngTxt,
                            range: [text.indexOf(obj.body), obj.body.length]
                        });
                    }

                    var attr = Ti.UI.createAttributedString({
                        text: text,
                        attributes: attributesCol
                    });
                    /*var multiplier = 1;
                    if(text.length < 25){
                        
                    }
                    else if(text.length < 50){
                        multiplier = 2;
                    }
                    else if(text.length < 75){
                        multiplier = 3;
                    }
                    else if(text.length < 100){
                        multiplier = 4;
                    }*/
                    var theLbl = Ti.UI.createLabel({
                        attributedString: attr,
                        textAlign: 'left',
                        width: Ti.UI.FILL
                    });
                    if (ro.isiOS) {
                        if (!isFirst) {
                            if (ro.isiphonex) {
                                theLbl.top = ro.ui.relY(-5);
                            } else {
                                theLbl.top = ro.ui.relY(-5);
                            }

                        }

                        theLbl.zIndex = zIndex;
                        //theLbl.backgroundPaddingTop = 0;
                        //theLbl.backgroundPaddingBottom = 0;
                        //theLbl.verticalAlign = Ti.UI.TEXT_VERTICAL_ALIGNMENT_TOP;
                        //theLbl.includeFontPadding = false;
                        //theLbl.left = 0;

                        //theLbl.height = ro.ui.relY(18) * multiplier;
                        //theLbl.width = Ti.UI.SIZE;
                        //theLbl.bottom = 0;
                    }
                    return theLbl;
                }

                function formItemTicket(itemObj, menuGroup, menuItem) {
                    var modsCol = {
                        wholeMods: [],
                        halfOneMods: [],
                        halfTwoMods: []
                    };

                    function getString(col) {
                        var returnString = "";
                        for (var i = 0,
                                iMax = col.length; i < iMax; i++) {
                            if (iMax - 1 == i) {
                                returnString += col[i];
                                return returnString;
                            }
                            returnString += col[i] + ', ';
                        }
                    }

                    function formatNoMods(nomods, modsCol) {
                        var modName,
                            noModName;
                        var wholeMods = [],
                            halfOneMods = [],
                            halfTwoMods = [];
                        var wholeReqMods = [],
                            halfOneReqMods = [],
                            halfTwoReqMods = [];

                        for (var k = 0, kMax = nomods.length; k < kMax; k++) {
                            var theNoMod = nomods[k];
                            switch (theNoMod.HalfStatus) {
                                case 0:
                                    noModName = 'NO ' + theNoMod.RcptName;
                                    if (isReqMod()) {
                                        wholeReqMods.push(noModName);
                                    } else {
                                        modsCol.wholeMods.push(noModName);
                                    }
                                    break;
                                case 1:
                                    noModName = ' ' + 'NO ' + theNoMod.RcptName;
                                    if (isReqMod()) {
                                        halfOneReqMods.push(noModName);
                                    } else {
                                        modsCol.halfOneMods.push(noModName);
                                    }
                                    break;
                                case 2:
                                    noModName = ' ' + 'NO ' + theNoMod.RcptName;
                                    if (isReqMod()) {
                                        halfTwoReqMods.push(noModName);
                                    } else {
                                        modsCol.halfTwoMods.push(noModName);
                                    }
                                    break;
                            }
                        }
                        //modsCol.wholeMods
                        //modsCol.
                        //modsCol.
                        return modsCol;
                    }

                    function formatMods(mods, modsCol) {

                        var modName,
                            noModName;
                        var wholeMods = [],
                            halfOneMods = [],
                            halfTwoMods = [];
                        var wholeReqMods = [],
                            halfOneReqMods = [],
                            halfTwoReqMods = [];

                        for (var k = 0; k < mods.length; k++) {
                            var theMod = mods[k];
                            switch (theMod.HalfStatus) {
                                case 0:
                                    modName = (theMod.Qty > 1 ? (theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : '')) + theMod.RcptName;
                                    if (isReqMod()) {
                                        wholeReqMods.push(modName);
                                    } else {
                                        modsCol.wholeMods.push(modName);
                                    }
                                    break;
                                case 1:
                                    modName = /*'H1-' + */ (theMod.Qty > 1 ? (' ' + theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : ' ')) + theMod.RcptName;
                                    if (isReqMod()) {
                                        halfOneReqMods.push(modName);
                                    } else {
                                        modsCol.halfOneMods.push(modName);
                                    }
                                    break;
                                case 2:
                                    modName = /*'H2-' + */ (theMod.Qty > 1 ? (' ' + theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : ' ')) + theMod.RcptName;
                                    if (isReqMod()) {
                                        halfTwoReqMods.push(modName);
                                    } else {
                                        modsCol.halfTwoMods.push(modName);
                                    }
                                    break;
                            }
                        }
                        //returnModCol.wholeMods = wholeMods;
                        //returnModCol.halfOneMods = halfOneMods;
                        //returnModCol.halfTwoMods = halfTwoMods;
                        return modsCol;
                    }

                    var returnCol = [];
                    var obj = {
                        hdr: "",
                        body: ""
                    };

                    if (itemObj.Style && itemObj.Style.length) {
                        if (itemObj.Size && itemObj.Size.length && itemObj.Size.toLowerCase() != 'none') {
                            obj.hdr = itemObj.Size + ": ";
                            obj.body = itemObj.Style;
                        } else {
                            obj.hdr = itemObj.Style;
                        }
                        returnCol.push(obj);
                    } else {
                        if (itemObj.Size && itemObj.Size.length && itemObj.Size.toLowerCase() != 'none') {
                            obj.hdr = itemObj.Size;
                            returnCol.push(obj);
                        }
                    }
                    obj = {
                        hdr: "",
                        body: ""
                    };
                    if (itemObj.PrfMbrs) {
                        for (var i = 0; i < itemObj.PrfMbrs.length; i++) {
                            obj.hdr = itemObj.PrfMbrs[i].RcptName;
                            obj.body = "";
                            returnCol.push(obj);
                            obj = {
                                hdr: "",
                                body: ""
                            };

                            if (itemObj.PrfMbrs[i].Mods && itemObj.PrfMbrs[i].Mods.length) {
                                modsCol = formatMods(itemObj.PrfMbrs[i].Mods, modsCol);
                            }
                            if (itemObj.PrfMbrs[i].NoMods && itemObj.PrfMbrs[i].NoMods.length) {
                                modsCol = formatNoMods(itemObj.PrfMbrs[i].NoMods, modsCol);
                            }
                        }
                    }
                    obj = {
                        hdr: "",
                        body: ""
                    };



                    if (itemObj.Mods || itemObj.NoMods) {
                        //var modsCol = {};
                        if (itemObj.Mods) {
                            modsCol = formatMods(itemObj.Mods, modsCol);
                        }
                        if (itemObj.NoMods) {
                            modsCol = formatNoMods(itemObj.NoMods, modsCol);
                        }
                    }
                    var wholeModString = getString(modsCol.wholeMods);
                    var halfOneModString = getString(modsCol.halfOneMods);
                    var halfTwoModString = getString(modsCol.halfTwoMods);
                    if (wholeModString) {
                        obj.hdr = "Whole: ";
                        obj.body = wholeModString;
                        returnCol.push(obj);
                        obj = {
                            hdr: "",
                            body: ""
                        };
                    }
                    if (halfOneModString) {
                        obj.hdr = "Half One: ";
                        obj.body = halfOneModString;
                        returnCol.push(obj);
                        obj = {
                            hdr: "",
                            body: ""
                        };
                    }
                    if (halfTwoModString) {
                        obj.hdr = "Half Two: ";
                        obj.body = halfTwoModString;
                        returnCol.push(obj);
                        obj = {
                            hdr: "",
                            body: ""
                        };
                    }
                    if (itemObj.CpnObj /*&& itemObj.CpnObj.CpnScope && itemObj.CpnObj.CpnScope == 2*/ ) {

                        var cpnObjTxt = itemObj.CpnObj.RcptName;

                        obj.hdr = "Deal: ";
                        obj.body = cpnObjTxt;
                        obj.hdrClr = '#eb0029';
                        returnCol.push(obj);
                        obj = {
                            hdr: "",
                            body: ""
                        };
                    }



                    if (itemObj.tempCpnKey) {
                        var discountTxt = '';
                        var tempCpnKey = itemObj.tempCpnKey;
                        //Ti.API.info('tempCpnKey: ' + tempCpnKey);
                        for (var i = 0, iMax = Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length ? Ti.App.OrderObj.TempCpns.length : 0; i < iMax; i++) {
                            //Ti.API.info('Ti.App.OrderObj.TempCpns[i]: ' + JSON.stringify(Ti.App.OrderObj.TempCpns[i]));
                            //Ti.API.info('Ti.App.OrderObj.TempCpns[i].CpnKey: ' + Ti.App.OrderObj.TempCpns[i].CpnKey);
                            //Ti.API.info('Ti.App.OrderObj.TempCpns[i].Key: ' + Ti.App.OrderObj.TempCpns[i].Key);
                            if (Ti.App.OrderObj.TempCpns[i].SelectedCoupon.Key == tempCpnKey) {
                                discountTxt = Ti.App.OrderObj.TempCpns[i].RcptName;
                                obj.hdr = "Deal: ";
                                obj.body = discountTxt;
                                obj.hdrClr = '#eb0029';
                                returnCol.push(obj);
                                obj = {
                                    hdr: "",
                                    body: ""
                                };
                                break;
                            }
                        }                       

                    }

                    if (itemObj.CpnKey && itemObj.CpnKey != "" && !(itemObj.hasOwnProperty("CpnObj"))) {
                        var discountTxt = '';                        
                        for (var i = 0, iMax = Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; i < iMax; i++) {                            
                            if (Ti.App.OrderObj.Cpns[i].SelectedCoupon.Key == itemObj.CpnKey) {
                                discountTxt = Ti.App.OrderObj.Cpns[i].RcptName;
                                obj.hdr = "Deal: ";
                                obj.body = discountTxt;
                                obj.hdrClr = '#eb0029';
                                returnCol.push(obj);
                                obj = {
                                    hdr: "",
                                    body: ""
                                };
                                break;
                            }
                        }
                        
                    }

                    if (itemObj.BogoID && itemObj.BogoID != "" && !(itemObj.hasOwnProperty("CpnObj"))) {
                        var discountTxt = '';
                        for (var i = 0, iMax = Ti.App.OrderObj.Items.length; i < iMax; i++) {
                            if (Ti.App.OrderObj.Items[i].CpnObj && Ti.App.OrderObj.Items[i].CpnObj.BogoID == itemObj.BogoID) {
                                discountTxt = Ti.App.OrderObj.Items[i].CpnObj.RcptName;
                                break;
                            }
                        }
                        obj.hdr = "Deal: ";
                        obj.body = discountTxt;
                        obj.hdrClr = '#eb0029';
                        returnCol.push(obj);
                        obj = {
                            hdr: "",
                            body: ""
                        };
                    }

                    if (itemObj.Notes && itemObj.Notes.length && itemObj.Notes[0].NoteText && itemObj.Notes[0].NoteText.length) {
                        /*lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
                         text:'Notes: ' + itemObj.Notes[0].NoteText,
                         color:ro.ui.theme.specialInstructionBlue,
                         height:Ti.UI.SIZE,
                         width:ro.ui.relX(190),
                         }));*/
                    }

                    obj = {
                        hdr: "",
                        body: ""
                    };

                    Ti.API.debug('returnCol: ' + JSON.stringify(returnCol));
                    return returnCol;
                }

                function deleteItem(e) {
                    /*if (e.source.type == 'item' || e.source.type == 'coupon') {
                        a.title = (e.source.type == 'item' ? 'Delete Item' : 'Delete Coupon');
                        a.message = (e.source.type == 'item' ? 'Do you wish to remove this item from your order?' : 'Do you wish to remove this coupon from your order?');
                        a.buttonNames = ['Yes', 'No'];
                        a.cancel = 1;
                        a.itmIndex = e.source.itmIndex;
                        a.bogo = false;
                        if (e.source.bogo) {
                            a.bogo = true;
                        }
                        a.show();
                    }*/
                    var priceEngine = require('logic/pricing');
                    var func = priceEngine.pricer();
                    //ro.ui.alert('Error', 'Please enter a valid coupon code');
                    if (e.source.type == 'item' || e.source.type == 'coupon') {
                        var title = (e.source.type == 'item' ? 'Delete Item' : 'Delete Coupon');
                        var msg = (e.source.type == 'item' ? 'Do you wish to remove this item from your order?' : 'Do you wish to remove this coupon from your order?');
                        ro.ui.popup(title, ['Cancel', 'OK'], msg, function(ee) {
                            var test = JSON.parse(JSON.stringify(Ti.App.OrderObj));                            
                            if (e.source.type == 'item') {

                                var tempCpnKey;
                                if (test.Items[e.source.itmIndex].tempCpnKey && test.TempCpns && test.TempCpns.length) {
                                    tempCpnKey = test.Items[e.source.itmIndex].tempCpnKey;
                                    for (var i = 0, iMax = test.Items.length; i < iMax; i++) {
                                        if (test.Items[i].tempCpnKey && test.Items[i].tempCpnKey == tempCpnKey) {
                                            test.Items[i].tempCpnKey = null;
                                            test.Items[i].realCpnKey = null;
                                        }
                                    }
                                    for (var i = 0, iMax = test.TempCpns.length; i < iMax; i++) {
                                        if (test.TempCpns[i].SelectedCoupon && test.TempCpns[i].SelectedCoupon.Key && test.TempCpns[i].SelectedCoupon.Key == tempCpnKey) {
                                            test.TempCpns.splice(i, 1);
                                            break;
                                        }
                                    }
                                }
                                // Need to work on this in the future to retain multiqual cpn in temp coupons list when u delete items, need to tweak chekcpnfordis method
                                /*else {
                                    if (!test.Items[e.source.itmIndex].realCpnKey) {
                                        if (checkCpnsForDisqualification(test.Items[e.source.itmIndex].RollupPrice)) { };
                                    }
                                }*/

                                deletedItemHolder = test.Items[e.source.itmIndex];
                                //var ordCpnWarning = false;
                                //var cpnMinPrice;
                                //var ordCpnIdx = -1;
                                //var isMultiItemCpn = false;
                                //var itemPrice = 0;
                                test.Items.splice(e.source.itmIndex, 1);
                                //test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                                Ti.App.OrderObj = JSON.parse(JSON.stringify(test));

                                //for (var i = 0; i < test.Items.length; i++) {
                                //    Ti.API.info("Test Items after splice: " + JSON.stringify(test.Items[i]));
                                //}
                                //for (var i = 0; i < Ti.App.OrderObj.Items.length; i++) {
                                //    Ti.API.info("Order Items after splice: " + JSON.stringify(Ti.App.OrderObj.Items[i]));
                                //}                                
                                if (test.Cpns && test.Cpns.length > 0) {                                    
                                    for (var x = test.Cpns.length - 1; x >= 0 ; x--) {
                                        var cpn2test = test.Cpns[x];
                                        if(cpn2test.CpnScope == 1) continue;
                                        test.Cpns.splice(x, 1);                                        
                                        test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                                        if(!test.cpns) test.Cpns = [];
                                        Ti.App.OrderObj = JSON.parse(JSON.stringify(test));
                                        ro.cpnHelper.findItem(cpn2test.SelectedCoupon.Key);
                                        var cpnItemsArr = ro.cpnHelper.checkCart({
                                            cpnKey: cpn2test.SelectedCoupon.Key
                                        });
                                        if (!cpnItemsArr.allDone) {

                                            //for (var i = 0; i < test.Items.length; i++) {
                                            //    Ti.API.info("itemObj :" + JSON.stringify(test.Items[i]));
                                            //    if (test.Items[i].CpnObj && (test.Items[i].CpnKey == test.Cpns[ordCpnIdx].SelectedCoupon.Key)) {
                                            //        Ti.API.info("removed cpn");
                                            //        Ti.API.info("cpnObj :" + JSON.stringify(test.Items[i].CpnObj));
                                            //        test.Items[i].CpnApplied = 0;
                                            //        delete test.Items[i].CpnObj;
                                            //    }
                                            //}
                                            //alert(test.Cpns[x].Name);
                                            //ro.ui.alert('Error', 'Please enter a valid coupon code');
                                            ro.ui.alert('Coupon Removed', cpn2test.Name + ' has been removed');                                            
                                        }
                                        else {
                                            test.Cpns.push(cpn2test);                                            
                                            Ti.App.OrderObj = JSON.parse(JSON.stringify(test));
                                        }
                                        //if (test.Cpns[x].CpnScope = 1 || (test.Cpns[x].CpnScope = 3 && test.Cpns[x].MultiQualTtl > 0)) {
                                        //    Ti.API.info("Inside bro : " + test.Cpns[x].MultiQualTtl > 0);
                                        //    ordCpnIdx = x;
                                        //    if (test.Cpns[x].CpnScope = 1) {
                                        //        cpnMinPrice = test.Cpns[x].MinPrice;
                                        //    }
                                        //    else {
                                        //        cpnMinPrice = test.Cpns[x].MinPrice;
                                        //        isMultiItemCpn = true;
                                        //        if (deletedItemHolder.CpnKey && deletedItemHolder.CpnKey != test.Cpns[x].SelectedCoupon.Key) {
                                        //            itemPrice = deletedItemHolder.RollupPrice
                                        //        }
                                        //    }
                                        //}
                                        //else if (test.Cpns[x].CpnScope = 3 && test.Cpns[x].SelectedCoupon.Key == deletedItemHolder.CpnKey) {
                                        //    Ti.API.info("Inside bro");
                                        //    ordCpnIdx = x;
                                        //    isMultiItemCpn = true;
                                        //}
                                    }
                                }
                                //Ti.API.info("ordCpnIdx " + ordCpnIdx);
                                
                                
                                //if (ordCpnIdx > -1) {
                                //    ordCpnWarning = true;
                                //    if (!isMultiItemCpn || (isMultiItemCpn && cpnMinPrice > 0)) {
                                //        test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                                //        ordCpnWarning = test.Subtotal - itemPrice < cpnMinPrice;
                                //    }
                                //}
                                //if (ordCpnWarning) {
                                    
                                //    for (var i = 0; i < test.Items.length; i++) {
                                //        Ti.API.info("itemObj :" + JSON.stringify(test.Items[i]));
                                //        if (test.Items[i].CpnObj && (test.Items[i].CpnKey == test.Cpns[ordCpnIdx].SelectedCoupon.Key)) {
                                //            Ti.API.info("removed cpn");                                            
                                //            Ti.API.info("cpnObj :" + JSON.stringify(test.Items[i].CpnObj));
                                //            test.Items[i].CpnApplied = 0;
                                //            delete test.Items[i].CpnObj;
                                //        }
                                //    }
                                //    alert(test.Cpns[ordCpnIdx].Name);
                                //    ro.ui.alert('Coupon Removed', test.Cpns[ordCpnIdx].Name + ' has been removed');
                                //    test.Cpns.splice(ordCpnIdx, 1);                                    
                                //}
                                if (deletedItemHolder && deletedItemHolder.CpnObj && deletedItemHolder.CpnObj.BogoID) {
                                    for (var i = 0; i < test.Items.length; i++) {
                                        if (test.Items[i].BogoID && (deletedItemHolder.CpnObj.BogoID == test.Items[i].BogoID)) {
                                            test.Items[i].CpnApplied = 0;
                                            delete test.Items[i].BogoID; 
                                        }
                                    }
                                } else if (deletedItemHolder && deletedItemHolder.BogoID) {
                                    for (var i = 0; i < test.Items.length; i++) {
                                        if (test.Items[i].CpnObj && (test.Items[i].CpnObj.BogoID == deletedItemHolder.BogoID)) {
                                            test.Items[i].CpnApplied = 0;
                                            delete test.Items[i].CpnObj;
                                        }
                                    }
                                }
                                
                            } else if (e.source.type == 'coupon') {
                                test.Cpns.splice(e.source.itmIndex, 1);
                            }

                            //ro.windowpopup.hideWindowpopup();                            
                            test = func.RepriceOrder(test, storeObj.Menu, test.OrdTypePriceIdx, (storeObj.Surcharges || []));
                            Ti.App.OrderObj = test;
                            test = null;
                            if (ticketItemsBox.reprintTicket()) {
                                btnCoupons.show();
                                itmTcktView.show();
                                bottomNavigationView.show();
                                emptyCartView.hide();
                            } else {
                                btnCoupons.hide();
                                itmTcktView.hide();
                                bottomNavigationView.hide();
                                emptyCartView.show();
                            }

                            ro.ui.reloadCart(function(e) {
                                areCouponsStillValid();
                            });
                        });
                    }

                }

                function areCouponsStillValid() {
                    var cpnLength = Ti.App.OrderObj.Cpns ? Ti.App.OrderObj.Cpns.length : 0;
                    var currentSubtotal = Ti.App.OrderObj.Subtotal || 0;

                    for (var i = 0; i < cpnLength; i++) {
                        for (var j = 0; j < storeObj.Menu.Cpns.length; j++) {
                            if (Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[j].Name) {
                                if (storeObj.Menu.Cpns[j].MultiQualTtl) {
                                    var cpnMinPrice = storeObj.Menu.Cpns[j].MultiQualTtl;
                                    if (currentSubtotal < cpnMinPrice) {

                                        ro.ui.popup('Warning: ', ['Cancel', 'OK'], 'Removing the previous item makes ' + Ti.App.OrderObj.Cpns[i].Name + ' invalid. Touch Cancel to undo?', function(e) {
                                            /*if (e.source.index === -1 || e.index === -1) {
                                                return;
                                            }*/

                                            var test = Ti.App.OrderObj;
                                            if (test.Cpns.length === 1) {
                                                test.Cpns = [];
                                            } else {
                                                test.Cpns.splice(i, 1);
                                            }

                                            Ti.App.OrderObj = test;
                                            test = null;
                                            ro.ui.reloadCart();
                                            deletedItemHolder = null;
                                            ro.windowpopup.hideWindowpopup();
                                        }, function() {
                                            var test = Ti.App.OrderObj;

                                            var deletedItem = deletedItemHolder;
                                            test.Items.push(deletedItem);

                                            Ti.App.OrderObj = test;
                                            test = null;
                                            ro.ui.reloadCart();
                                            deletedItemHolder = null;
                                            ro.windowpopup.hideWindowpopup();
                                        });

                                    }
                                }
                            }
                        }
                    }
                }

                function areOrdTypeCpnsValid() {
                    var cpnLength = Ti.App.OrderObj.Cpns ? Ti.App.OrderObj.Cpns.length : 0;
                    for (var i = 0; i < cpnLength; i++) {
                        for (var j = 0; j < storeObj.Menu.Cpns.length; j++) {
                            if (Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[j].Name) {
                                if (storeObj.Menu.Cpns[j].ExcldOrdTypes && storeObj.Menu.Cpns[j].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
                                    for(var exclOrdIdx = 0; exclOrdIdx < storeObj.Menu.Cpns[j].ExcldOrdTypes.length; exclOrdIdx++){
                                        if(Ti.App.OrderObj.OrdType == storeObj.Menu.Cpns[j].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
                                            var test = Ti.App.OrderObj;
                                            if (test.Cpns.length === 1) {
                                                test.Cpns = [];
                                            } else {
                                                test.Cpns.splice(i, 1);
                                            }
                                            Ti.App.OrderObj = test;
                                            test = null;                                            
                                            break;
                                        }
                                    }
                                }
                                break; 
                            }
                        }
                    }
                }

                function INCREASE(e) {
                    var test = Ti.App.OrderObj;                    
                    test.Items[e.source.itmIndex].Qty++;
                    Ti.App.OrderObj = test;
                    Ti.App.ItemsSplit = true;
                    ro.ui.reloadCart();
                    // var test = Ti.App.
                    //var priceEngine = require('logic/pricing');
                    //var func = priceEngine.pricer();
                    //Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, storeObj.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (storeObj.Surcharges || []));

                    if (checkTempCpnsForQualification()) {
                        ticketItemsBox.reprintTicket();
                        ro.ui.reloadCart();
                    }



                    //ticketItemsBox.reprintTicket();
                    // Ti.App.OrderObj = test;
                    //test = null;
                    //ro.ui.reloadCart();
                }

                function DECREASE(e) {
                    var test = Ti.App.OrderObj;
                    if (test.Items[e.source.itmIndex].Qty == 1) {
                        Ti.App.OrderObj = test;
                        return;
                    }
                    var rollupPriceToRemove = test.Items[e.source.itmIndex].RollupPrice; //(/ test.Items[e.source.itmIndex].Qty;)
                    test.Items[e.source.itmIndex].Qty--;
                    Ti.App.OrderObj = test;
                    if (checkCpnsForDisqualification(rollupPriceToRemove)) ticketItemsBox.reprintTicket();

                    Ti.App.ItemsSplit = true;

                    //Ti.API.info('DECREASE - Ti.App.OrderObj.Cpns: ' + JSON.stringify(Ti.App.OrderObj.Cpns));
                    //Ti.API.info('DECREASE - Ti.App.OrderObj.TempCpns: ' + JSON.stringify(Ti.App.OrderObj.TempCpns));

                    /*var priceEngine = require('logic/pricing');
                    var func = priceEngine.pricer();
                    Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, storeObj.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (storeObj.Surcharges || []));
                    Ti.API.info('DECREASE - Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
                    ticketItemsBox.reprintTicket();*/
                    ro.ui.reloadCart();
                }

                function isReqMod() {
                    return false;
                }

                function editCartItem(e) {
                    // Ti.API.debug('e: ' + JSON.stringify(e));

                    //if(true || e.section.secType === 'item'){
                    var itmIdx = e.source.itmIndex;
                    if (Ti.App.OrderObj.Items[itmIdx].noEdit) {
                        Ti.API.debug('Cant Edit due to it have nothing editable about it');
                    } else {
                        ro.App.edit.editMode = true;
                        ro.App.edit.editIndex = itmIdx;
                        ro.ui.cartShowNext({
                            showing: 'Cart'
                        });
                    }
                    //}
                    /*if(e.row.className === 'subRow'){

                     }
                     if(e.row.className === 'mainRow'){

                     }*/
                }

                function minOrdValidation() {

                    var minOrdStoreObj = storeObj;
                    var minOrder = 0;
                    for (var j = 0; j < minOrdStoreObj.Menu.OnlineOptions.OrdTypes.length; j++) {
                        if (minOrdStoreObj.Menu.OnlineOptions.OrdTypes[j].IsDelivery == Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                            minOrder = minOrdStoreObj.Menu.OnlineOptions.OrdTypes[j].MinOrd;
                            break;
                        }
                    }

                    if (Ti.App.OrderObj.Subtotal < minOrder) {
                        ro.ui.alert('Order', 'Minimum subtotal amount for ' + Ti.App.OrderObj.OrdType + ' is $' + minOrder + '.');
                        return 0;
                    } else {
                        return 1;
                    }
                }

                function setVisibility() {
                    var show = false;
                    //var show = true;
                    if (Ti.App.OrderObj.Items) {
                        if (Ti.App.OrderObj.Items.length > 0) {
                            show = true;
                        }
                    }
                    if (Ti.App.OrderObj.Cpns) {
                        if (Ti.App.OrderObj.Cpns.length > 0) {
                            show = true;
                        }
                    }

                    if (show) {
                        /*btnCoupons.show();
                         itmTcktView.show();
                         bottomNavigationView.show();
                         emptyCartView.hide();*/
                    } else {
                        btnCoupons.hide();
                        itmTcktView.hide();
                        bottomNavigationView.hide();
                        emptyCartView.show();

                    }

                    /*if(show){
                     itemTable.show();
                     noItems.hide();
                     btnCheckout.visible = true;
                     btnClear.visible = true;
                     btnCoupons.visible = true;
                     }
                     else{
                     var test = Ti.App.OrderObj;
                     test.Cpns = null;
                     Ti.App.OrderObj = test;
                     itemTable.data = [];
                     itemTable.hide();
                     noItems.show();
                     subTotalValue.text = '$ 0.00';
                     taxValue.text = '$ 0.00';
                     totalValue.text = '$ 0.00';
                     btnCheckout.visible = false;
                     btnClear.visible = false;
                     btnCoupons.visible = false;
                     }*/
                    return show;
                }

                var onlyOneTime = false;
                var postLayoutEvt = function() {
                    //checkoutView.removeEventListener('postlayout', postLayoutEvt);
                    if (onlyOneTime) {
                        return;
                    }
                    onlyOneTime = true;
                    /*if(DoMultiPmts){

                     }*/

                    if (storeObj.Configuration.LTY_CHK_PTS && storeObj.Configuration.LTY_CHK_PTS.length) {
                        var foundMatch = false;
                        var showEnrollMsg = false;
                        var rs = null;
                        if (!isGuest) {
                            rs = ro.db.getCustObj(Ti.App.Username);
                        }
                        //isLtyNoEclub
                        var isCustEnrolled = !isGuest && rs && rs.LtyOptIn == 1;
                        //needs actual logic

                        switch (storeObj.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase()) {
                            case 'all':
                                showEnrollMsg = !isCustEnrolled;
                                foundMatch = true;
                                break;
                            case 'enrolled':
                                showEnrollMsg = false;
                                foundMatch = isCustEnrolled;
                                // will need real logic
                                break;
                            case 'notenrolled':
                                showEnrollMsg = true;
                                foundMatch = !isCustEnrolled;
                                // will need real logic
                                break;
                            case 'none':
                                showEnrollMsg = false;
                                foundMatch = false;
                                break;
                            default:
                                //alert('default case: ' + storeObj.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase());
                                break;
                        }
                        if (isGuest) {
                            showEnrollMsg = false;
                        }

                        var req = {
                            Email: isGuest ? null : Ti.App.Username,
                            RevKey: 'test',
                            CompressResponse: false,
                            StoreID: storeObj.ID,
                            OrderObj: Ti.App.OrderObj
                        };
                        //Ti.API.debug('foundMatch: ' + foundMatch);
                        if (foundMatch) {
                            ro.ui.showLoader();
                            ro.dataservice.post(req, 'GetLtyPoints', function(response) {
                                //alert('response: ' + JSON.stringify(response));
                                if (response) {
                                    if (response.Success && response.Points && response.Points > 0) {
                                        honeycombBox.ShowLtyView(response, showEnrollMsg);
                                    } else {

                                    }
                                    ro.ui.hideLoader();
                                } else {
                                    ro.ui.hideLoader();
                                }
                            });
                        }
                    }
                };

                ro.ui.reprintTicket = function(e) {
                    ticketItemsBox.reprintTicket();
                }
                ro.ui.refreshCart = function(e) {
                    //return;
                    try {
                        Ti.API.info('REFRESH CART 2038');
                        storeObj = ro.app.Store;
                        if (!storeObj) {
                            storeObj = {};
                        }
                        if (setVisibility()) {
                            //emptyCartView.hide();
                            if (false && Ti.App.firstOLOrdCpnExists && !Ti.App.firstOLOrdCpnApplied && !isGuest) {
                                firstOnlineOrder();
                            } else {
                                //ticketItemsBox.reprintTicket();
                                var itemCount = Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
                                var cpnItemSurcharge = 0;
                                if (itemCount && itemCount > 0) {
                                    var realItemCount = 0;
                                    for (var i = 0, iMax = Ti.App.OrderObj.Items.length; i < iMax; i++) {
                                        realItemCount += Ti.App.OrderObj.Items[i].Qty;
                                        cpnItemSurcharge += Ti.App.OrderObj.Items[i].CpnItemSurcharge ? Ti.App.OrderObj.Items[i].CpnItemSurcharge : 0;
                                    }
                                    itemCount = realItemCount;
                                } else {
                                    itemCount = 0;
                                }
                                itemCountValue.text = itemCount;

                                if (cpnItemSurcharge > 0) {
                                    cpnSurchargeValue.text = '$' + cpnItemSurcharge.toFixed(2);
                                    cpnSurchargeHolder.height = ro.ui.relY(30);
                                    cpnSurchargeHolder.top = ro.ui.relY(3);
                                    cpnSurchargeHolder.visible = true;
                                } else {
                                    cpnSurchargeValue.text = '$' + cpnItemSurcharge.toFixed(2);
                                    cpnSurchargeHolder.height = 0;
                                    cpnSurchargeHolder.top = 0;
                                    cpnSurchargeHolder.visible = false;
                                }
                                
                                if (surchargeValueLbls && surchargeValueLbls.length && Ti.App.OrderObj && Ti.App.OrderObj.Surcharges && Ti.App.OrderObj.Surcharges.length && (Ti.App.OrderObj.Surcharges.length == surchargeValueLbls.length)) {
                                    for (var i = 0, iMax = surchargeValueLbls.length; i < iMax; i++) {
                                        surchargeValueLbls[i].text = ("$" + Ti.App.OrderObj.Surcharges[i].ActivePrice.toFixed(2));
                                    }
                                }
                                subTotalValue.text = '$' + Ti.App.OrderObj.Subtotal.toFixed(2);
                                taxValue.text = '$' + Ti.App.OrderObj.Tax.toFixed(2);
                                totalValue.text = '$' + Ti.App.OrderObj.ActiveTotal.toFixed(2);
                            }
                        }
                    } catch (ex) {
                        ro.ui.alert('Cart', 'CR100');
                    }
                };

                ro.ui.reloadCart = function(_cbFn) {
                    try {
                        if (!storeObj) {
                            storeObj = {};
                        }                        
                        var priceEngine = require('logic/pricing');
                        var func = priceEngine.pricer();
                        Ti.API.info("Reloading Cart");
                        if (setVisibility()) {                            
                            Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, storeObj.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (storeObj.Surcharges || []));                            
                            if (Ti.App.OrderObj.RemovedCpns && Ti.App.OrderObj.RemovedCpns.length) {
                                ticketItemsBox.reprintTicket();
                                var rmvdCpnList = Ti.App.OrderObj.RemovedCpns[0];
                                if (Ti.App.OrderObj.RemovedCpns.length > 1) {
                                    for (var i = 1; i < Ti.App.OrderObj.RemovedCpns.length; i++) {
                                        rmvdCpnList = rmvdCpnList + ', ' + Ti.App.OrderObj.RemovedCpns[i];
                                    }
                                }
                                ro.ui.alert('Coupon Removed', rmvdCpnList + ' has been removed');
                            } else {
                                //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
                                var itemCount = Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
                                var cpnItemSurcharge = 0;
                                if (itemCount && itemCount > 0) {
                                    var realItemCount = 0;
                                    for (var i = 0, iMax = Ti.App.OrderObj.Items.length; i < iMax; i++) {
                                        realItemCount += Ti.App.OrderObj.Items[i].Qty;
                                        cpnItemSurcharge += Ti.App.OrderObj.Items[i].CpnItemSurcharge ? Ti.App.OrderObj.Items[i].CpnItemSurcharge : 0;
                                    }
                                    itemCount = realItemCount;
                                } else {
                                    itemCount = 0;
                                }
                                if (surchargeValueLbls && surchargeValueLbls.length && Ti.App.OrderObj && Ti.App.OrderObj.Surcharges && Ti.App.OrderObj.Surcharges.length && (Ti.App.OrderObj.Surcharges.length == surchargeValueLbls.length)) {
                                    for (var i = 0, iMax = surchargeValueLbls.length; i < iMax; i++) {
                                        surchargeValueLbls[i].text = ("$" + Ti.App.OrderObj.Surcharges[i].ActivePrice.toFixed(2));
                                    }
                                }

                                if (cpnItemSurcharge > 0) {
                                    cpnSurchargeValue.text = '$' + cpnItemSurcharge.toFixed(2);
                                    cpnSurchargeHolder.height = ro.ui.relY(30);
                                    cpnSurchargeHolder.top = ro.ui.relY(3);
                                    cpnSurchargeHolder.visible = true;
                                } else {
                                    cpnSurchargeValue.text = '$' + cpnItemSurcharge.toFixed(2);
                                    cpnSurchargeHolder.height = 0;
                                    cpnSurchargeHolder.top = 0;
                                    cpnSurchargeHolder.visible = false;
                                }

                                if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                                    if (storeObj && storeObj.Menu && storeObj.Menu.OnlineOptions &&
                                        storeObj.Menu.OnlineOptions.DelivOpts &&
                                        storeObj.Menu.OnlineOptions.DelivOpts.DeliveryFee &&
                                        storeObj.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
                                        //delFeeVal.text = '$' + Ti.App.OrderObj.DlvyFee.toFixed(2);
                                        delFeeVal.text = '$' + (Ti.App.OrderObj.DlvyFee ? Ti.App.OrderObj.DlvyFee.toFixed(2) : "0.00");

                                    }
                                }
                                setItemNumbersText(itemCount);
                                itemCountValue.text = itemCount;
                                subTotalValue.text = '$' + Ti.App.OrderObj.Subtotal.toFixed(2);
                                taxValue.text = '$' + Ti.App.OrderObj.Tax.toFixed(2);
                                totalValue.text = '$' + Ti.App.OrderObj.ActiveTotal.toFixed(2);

                                //ticketItemsBox.reprintTicket();
                                //emptyCartView.hide();
                                //itmTcktView.show();
                                /*showTicket();
                                 var rowCount = 0;
    
                                 for(var i=0; i<tableData.length; i++){
                                 rowCount += tableData[i].rowCount;
                                 }
                                 itemTable.scrollToIndex(rowCount - 1);*/
                            }


                        } else {
                            if (storeObj && storeObj.Menu) {
                                Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, storeObj.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (storeObj.Surcharges || []));
                                //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
                            }
                        }

                        if (_cbFn) {
                            _cbFn();
                        }
                    } catch (ex) {
                        ro.ui.alert('cart', 'Error occured. CODE: 102 \n');
                        Ti.API.info("Exception Code 102: " + JSON.stringify(ex));
                    }
                };

                emptyCartView.add(noItems);
                mainView.add(itmTcktView);
                mainView.add(emptyCartView);
                mainView.add(bottomNavigationView);

                function postlayout() {
                    mainView.removeEventListener('postlayout', postlayout);
                    areOrdTypeCpnsValid();
                    if (ticketItemsBox.reprintTicket()) {                        
                        ro.ui.reloadCart();
                        postLayoutEvt();
                        btnCoupons.show();
                        itmTcktView.show();
                        bottomNavigationView.show();
                        emptyCartView.hide();
                    }

                    var deliveryLbl = "Delivery";
                    if (Ti.App.Properties.hasProperty('Config')) {
                        var cartConfig = JSON.parse(Ti.App.Properties.getString('Config'));
                        /*if (Config && (Config.AllowDelivery == false || Config.AllowDelivery == 'False')) {
                            allowDeliv = false;
                        }*/
                        /*if (ro.utils.hasProp(Config, 'CarryoutLabel')) {
                            carryoutLbl = Config.CarryoutLabel;
                        }*/
                        if (ro.utils.hasProp(cartConfig, 'DeliveryLabel')) {
                            deliveryLbl = cartConfig.DeliveryLabel;

                        }
                    }

                    if (REV_ORD_TYPE.IsDeliveryWithoutAddress()) {
                        ro.ui.popup('Error', ['OK'], 'You have selected ' + deliveryLbl + ' but have not chosen an address. You must choose an address before continuing.', function(e) {
                            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                                ro.ui.setOrdTypeStkState('addNewAddr');
                            } else {
                                ro.ui.setOrdTypeStkState('newAddrList');
                            }

                            ro.ui.cartShowNext({
                                showing: 'Cart'
                            });
                        }, function() {

                        }, true);

                    }

                }


                mainView.addEventListener('postlayout', postlayout);
                return mainView;
            };
            ro.ui.oldcreateCartView = function(_args) {
                Ti.API.info("OLD Cart Called");
                //GUEST ORDERS
                var checkoutHid = 'paymentScreen';
                var isGuest = false;
                if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                    checkoutHid = 'guestDetails';
                    isGuest = true;
                }
                //GUEST ORDERS

                
                var priceEngine = require('logic/pricing');
                var func = priceEngine.pricer();
                Ti.App.Properties.setBool('lvlupBool', false);

                var Config = JSON.parse(Ti.App.Properties.getString('Config'));
                if (!Config) {
                    Config = {};
                }
                ///////////         CCTIPS       ////////////
                //CC_TIPS.Init(Config.TipsHeader, Config.AllowCCTips, Config.AllowLUTips, Config.AllowGiftTips);
                ///////////         CCTIPS       ////////////

                if (Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length) {
                    //deb.ug(Ti.App.OrderObj.Items, 'Items');
                }
                if (Ti.App.OrderObj && Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length) {
                    //deb.ug(Ti.App.OrderObj.Cpns, 'Cpns');
                }

                var storeObj,
                    tableData,
                    qty;
                var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                    name: 'cart',
                    softInputMode: (Ti.UI.Android) ? Ti.UI.Android.SOFT_INPUT_ADJUST_PAN : '',
                    hid: 'Cart'
                }));

                var itmTcktView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
                    name: 'Summary',
                    top: ro.ui.properties.topAfterNavbar,
                    bottom: ro.ui.relY(55),
                    //visible: false
                }));

                var topNavBar = Ti.UI.createView(ro.ui.properties.navBar);
                /* if(ro.ui.theme.bannerImg){
                 var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
                 topNavBar.add(headerImg);
                 }
                 else{
                 headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Cart'}));
                 topNavBar.add(headerLbl);
                 } */

                var bottomNavBar = Ti.UI.createView(ro.ui.properties.bottomNavBar, {
                    zIndex: 10
                });
                var btnCheckout = layoutHelper.getRightBtn('CHECKOUT', true);
                btnCheckout.children[0].color = 'black';
                btnCheckout.backgroundColor = ro.ui.theme.btnBg;
                bottomNavBar.add(btnCheckout);

                var btnContinue = layoutHelper.getBackBtn('MENU');
                btnContinue.addEventListener('click', function(e) {
                    ro.ui.cartShowNext({
                        showing: 'Cart'
                    });
                });
                var btnClear = layoutHelper.getCustomBtn('CLEAR');
                //var btnCoupons = layoutHelper.getRightBtn('COUPONS');
                var btnCoupons = layoutHelper.getNewRightBtn('Deals', null, "/images/myDealsLight.png", 40);

                topNavBar.add(btnContinue);
                bottomNavBar.add(btnClear);
                topNavBar.add(btnCoupons);


                if (ro.isiphonex) {
                    var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                    var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                    var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                    navParent.add(topNav);
                    bottomNav.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                    navParent.add(bottomNav);
                    mainView.add(navParent);
                } else {
                    mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                }
                //mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));


                mainView.add(bottomNavBar);
                mainView.add(itmTcktView);

                var headerVw = layoutMenuHelper.menuHeaders({
                    text: 'ORDER PREVIEW'
                });
                headerVw.top = ro.ui.relY(25);

                var itemTablePadding = Ti.UI.createView({
                    top: ro.ui.relY(60),
                    bottom: ro.ui.relY(90),
                    backgroundColor: 'transparent'
                });
                var itemTable = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsTblView, {
                    separatorColor: 'transparent',
                    top: 0,
                    height: Ti.UI.SIZE,
                    backgroundColor: 'white'
                }));

                itemTable.addEventListener('click', editCartItem);
                itemTablePadding.add(itemTable);

                var noItems = Ti.UI.createImageView({
                    image: ro.ui.properties.defaultPath + 'cartEmpty.png',
                    width: ro.ui.relY(128),
                    height: ro.ui.relY(128)
                });

                if ((Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length) || (Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length)) {
                    itmTcktView.add(headerVw);
                }
                itmTcktView.add(itemTablePadding);
                itmTcktView.add(noItems);

                var surchargeValueLbls = [];
                var totalsView = Ti.UI.createView(ro.combine(ro.ui.properties.grpBackgroundView, {
                    left: ro.ui.relX(10),
                    right: ro.ui.relX(10)
                }));

                var totalLblHeight = 0;
                var topIncrement = ro.ui.relY(15);
                var heightIncrement = ro.ui.relY(15);
                var subtotalTop = ro.ui.relY(5);

                totalLblHeight += heightIncrement;
                var subTotalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: subtotalTop,
                    width: ro.ui.relX(50),
                    right: ro.ui.relX(70),
                    text: 'Subtotal:',
                    textAlign: 'right'
                }));
                var subTotalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: subtotalTop,
                    width: ro.ui.relX(60),
                    right: ro.ui.relX(10),
                    textAlign: 'right'
                }));
                totalsView.add(subTotalLbl);
                totalsView.add(subTotalValue);

                var hasPmntSurcharge = false;
                if (ro.app.Store && ro.app.Store.Surcharges && ro.app.Store.Surcharges.length){
                    var test = Ti.App.OrderObj;                    
                    test.PaymentsList = [];
                    test = func.RepriceOrder(test, ro.app.Store.Menu, test.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                    Ti.App.OrderObj = test;
                    test = null;
                    for(i=0; i<ro.app.Store.Surcharges.length; i++){
                        if(ro.app.Store.Surcharges[i].BusinessSurchargePayments && ro.app.Store.Surcharges[i].BusinessSurchargePayments.length){
                            hasPmntSurcharge = true;
                            break;
                        }
                    }
                }   
                var totalSurchargeTop = subtotalTop; // + ro.ui.relY(15);
                if (Ti.App.OrderObj.Surcharges && Ti.App.OrderObj.Surcharges.length) {
                    for (var i = 0, iMax = Ti.App.OrderObj.Surcharges.length; i < iMax; i++) {
                        //Ti.API.info('Ti.App.OrderObj.Surcharges['+i+']: ' + JSON.stringify(Ti.App.OrderObj.Surcharges[i]));
                        totalLblHeight += heightIncrement;
                        totalSurchargeTop += topIncrement;
                        //sectionOffset += origSectionOffset;
                        //top += sectionOffset;
                        var surchargeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                            text: Ti.App.OrderObj.Surcharges[i].RcptName + ":",
                            width: Ti.UI.SIZE,
                            right: ro.ui.relX(70),
                            //text: 'Subtotal:',
                            textAlign: 'right',
                            top: totalSurchargeTop
                        }));
                        var surchargeValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                            top: totalSurchargeTop,
                            width: ro.ui.relX(60),
                            right: ro.ui.relX(10),
                            textAlign: 'right'
                            //text: "$" + Ti.App.OrderObj.Surcharges[i].ActivePrice
                        }));
                        surchargeValueLbls.push(surchargeValue);
                        totalsView.add(surchargeLbl);
                        totalsView.add(surchargeValueLbls[i]);
                    }
                }

                //if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                //if (ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFee && ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
                // Ti.API.info('Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery: ' + (Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery));
                //Ti.API.info('Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));       
                var showDeliv = false;
                if (Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                    if (ro.app.Store && ro.app.Store.Menu && ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFee && ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
                        showDeliv = true;
                    }
                }

                var dlvyFeeTop = totalSurchargeTop;
                var dlvyFeeHeight = 0;
                if (showDeliv) {
                    totalLblHeight += heightIncrement;
                    dlvyFeeTop = totalSurchargeTop + topIncrement;
                    dlvyFeeHeight = ro.ui.relY(15);
                }

                var delFeeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: dlvyFeeTop,
                    height: dlvyFeeHeight,
                    width: ro.ui.relX(50),
                    right: ro.ui.relX(70),
                    //text: 'Dlvy Fee:',
                    textAlign: 'right'
                }));
                var delFeeVal = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: dlvyFeeTop,
                    height: dlvyFeeHeight,
                    width: ro.ui.relX(60),
                    right: ro.ui.relX(10),
                    textAlign: 'right'
                }));
                totalsView.add(delFeeLbl);
                totalsView.add(delFeeVal);

                totalLblHeight += heightIncrement;
                var taxTop = dlvyFeeTop + topIncrement;
                var taxLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: taxTop,
                    width: ro.ui.relX(50),
                    right: ro.ui.relX(70),
                    text: 'Tax:',
                    textAlign: 'right'
                }));
                var taxValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: taxTop,
                    width: ro.ui.relX(60),
                    right: ro.ui.relX(10),
                    textAlign: 'right'
                }));
                totalsView.add(taxLbl);
                totalsView.add(taxValue);
                /*var delFeeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                 top:ro.ui.relY(35),
                 width:ro.ui.relX(90),
                 right:ro.ui.relX(120),
                 textAlign:'right'
                 }));*/

                totalLblHeight += heightIncrement;
                var totalTop = taxTop + topIncrement;
                var totalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: totalTop,
                    width: ro.ui.relX(50),
                    right: ro.ui.relX(70),
                    text: 'Total:',
                    textAlign: 'right'
                }));
                var totalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                    top: totalTop,
                    width: ro.ui.relX(60),
                    right: ro.ui.relX(10),
                    textAlign: 'right'
                }));
                totalsView.add(totalLbl);
                totalsView.add(totalValue);

                if(hasPmntSurcharge){
                    totalLblHeight += heightIncrement;
                    var surchargeWarningTop = totalTop + topIncrement;                    
                    var surchargeWarning = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCartTtls, {
                        top: surchargeWarningTop,
                        width: Ti.UI.SIZE,
                        right: ro.ui.relX(10),
                        textAlign: 'right',
                        text: 'Surcharge applicable for select Payments'
                    }));
                    totalsView.add(surchargeWarning);
                }

                totalsView.height = totalLblHeight + ro.ui.relY(10);
                /*function resizePostLayout(){
                        totalsView.removeEventListener('postlayout', resizePostLayout);
                        
                        
                }
                totalsView.addEventListener('postlayout', resizePostLayout);*/

                itmTcktView.add(totalsView);

                var a = Ti.UI.createAlertDialog();

                btnClear.addEventListener('click', function() {
                    a.title = 'Cancel Order';
                    a.message = 'Do you wish to cancel order?';
                    a.buttonNames = ['Yes', 'No'];
                    a.cancel = 1;
                    a.show();
                });

                function deleteItem(e) {
                    if (e.source.type == 'item' || e.source.type == 'coupon') {
                        a.title = (e.source.type == 'item' ? 'Delete Item' : 'Delete Coupon');
                        a.message = (e.source.type == 'item' ? 'Do you wish to remove this item from your order?' : 'Do you wish to remove this coupon from your order?');
                        a.buttonNames = ['Yes', 'No'];
                        a.cancel = 1;
                        a.itmIndex = e.source.itmIndex;
                        a.bogo = false;
                        if (e.source.bogo) {
                            a.bogo = true;
                        }
                        a.show();
                    }
                }

                function setVisibility() {
                    var show = false;
                    //var show = true;
                    if (Ti.App.OrderObj.Items) {
                        if (Ti.App.OrderObj.Items.length > 0) {
                            show = true;
                        }
                    }
                    if (Ti.App.OrderObj.Cpns) {
                        if (Ti.App.OrderObj.Cpns.length > 0) {
                            show = true;
                        }
                    }

                    if (show) {
                        itemTable.show();
                        noItems.hide();
                        btnCheckout.visible = true;
                        btnClear.visible = true;
                        btnCoupons.visible = true;
                    } else {
                        var test = Ti.App.OrderObj;
                        test.Cpns = null;
                        Ti.App.OrderObj = test;
                        itemTable.data = [];
                        itemTable.hide();
                        noItems.show();
                        subTotalValue.text = '$ 0.00';
                        taxValue.text = '$ 0.00';
                        totalValue.text = '$ 0.00';
                        btnCheckout.visible = false;
                        btnClear.visible = false;
                        btnCoupons.visible = false;
                    }
                    return show;
                }

                var getModRow = function(theMod, prfMd, itemObj) {
                    try {
                        //Ti.API.debug('theMod: ' + JSON.stringify(theMod));
                        var modName;
                        var childLevel = 3;

                        /*switch(theMod.HalfStatus){
                        case 0:
                        modName = (theMod.Qty > 1 ? '2X ' : '') + theMod.RcptName;
                        break;
                        case 1:
                        modName = 'H1-' + (theMod.Qty > 1 ? ' 2X ' : ' ') + theMod.RcptName;
                        break;
                        case 2:
                        modName = 'H2-' + (theMod.Qty > 1 ? ' 2X ' : ' ') + theMod.RcptName;
                        break;
                        }*/
                        //Ti.API.debug('theMod.Qty:' + theMod.Qty);
                        switch (theMod.HalfStatus) {
                            case 0:
                                modName = (theMod.Qty > 1 ? (theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : '')) + theMod.RcptName;
                                break;
                            case 1:
                                modName = 'H1-' + (theMod.Qty > 1 ? (' ' + theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : ' ')) + theMod.RcptName;
                                break;
                            case 2:
                                modName = 'H2-' + (theMod.Qty > 1 ? (' ' + theMod.Qty + 'X ') : (theMod.IsLite ? 'LT ' : ' ')) + theMod.RcptName;
                                break;
                        }

                        var row = Ti.UI.createTableViewRow({
                            height: ro.ui.relY(20),
                            //height:Ti.UI.SIZE,
                            indentionLevel: childLevel,
                            className: 'subRow',
                            backgroundColor: 'white'
                        });
                        lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
                            //text:modName
                            text: (prfMd ? (' +  ' + modName) : (modName))
                        }));

                        //var price = '$' + theMod.ActivePrice.toFixed(2);
                        var price = (theMod.ActivePrice && theMod.ActivePrice > 0 ? '$' + theMod.ActivePrice.toFixed(2) : '');

                        if (!(theMod.ActivePrice) || theMod.ActivePrice == 0) {
                            price = '';
                            if (itemObj.CpnObj && (theMod.ActivePrice != 0)) {
                                price = '$' + theMod.ActivePrice.toFixed(2);
                            }
                        }

                        priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
                            text: price
                        }));
                        row.add(lbl);
                        row.add(priceLbl);
                        return row;
                    } catch (ex) {
                        Ti.API.debug('getModRow - Exception: ' + ex);
                    }

                };
                var getNoModRow = function(theNoMod, prfMd) {
                    var noModName;
                    var childLevel = 3;
                    switch (theNoMod.HalfStatus) {
                        case 0:
                            noModName = 'NO ' + theNoMod.RcptName;
                            break;
                        case 1:
                            noModName = 'H1- ' + 'NO ' + theNoMod.RcptName;
                            break;
                        case 2:
                            noModName = 'H2- ' + 'NO ' + theNoMod.RcptName;
                            break;
                    }

                    var row = Ti.UI.createTableViewRow({
                        height: ro.ui.relY(20),
                        //height:Ti.UI.SIZE,
                        indentionLevel: childLevel,
                        className: 'subRow',
                        backgroundColor: 'white'
                    });
                    lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
                        //text:noModName
                        text: (prfMd ? (' -  ' + noModName) : (noModName))
                    }));
                    priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
                        text: ''
                    }));
                    row.add(lbl);
                    row.add(priceLbl);

                    return row;
                };

                function showTicket() {
                    delFeeVal.text = '';
                    delFeeVal.height = 0;
                    delFeeLbl.text = '';
                    delFeeLbl.height = 0;
                    //taxValue.top = ro.ui.relY(20);
                    //taxLbl.top = ro.ui.relY(20);
                    //totalLbl.top = ro.ui.relY(35);
                    //totalValue.top = ro.ui.relY(35);
                    //Ti.API.info('Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
                    if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                        if (ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFee && ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal > 0) {
                            //delFeeLbl.text = '( Dlvy Fee incl. )';
                            delFeeLbl.text = 'Dlvy Fee:';
                            //alert('TempDlvyFee: ' + Ti.App.OrderObj.TempDlvyFee);
                            //delFeeVal.text = '$' + (ro.app.Store.Menu.OnlineOptions.DelivOpts.DeliveryFeeVal + (ro.app.Store.Menu.OnlineOptions.DelivOpts.AddDelFee ? ro.app.Store.Menu.OnlineOptions.DelivOpts.AddDelFee : 0)).toFixed(2);
                            //delFeeVal.text = '$' + (Ti.App.OrderObj.TempDlvyFee).toFixed(2);
                            delFeeVal.text = '$' + (Ti.App.OrderObj.DlvyFee ? Ti.App.OrderObj.DlvyFee.toFixed(2) : "0.00");
                            delFeeLbl.height = ro.ui.relY(15);
                            delFeeVal.height = ro.ui.relY(15);
                            /*taxValue.top = ro.ui.relY(35);
                                taxLbl.top = ro.ui.relY(35);
                            totalLbl.top = ro.ui.relY(50);
                            totalValue.top = ro.ui.relY(50);*/
                        }
                    }

                    tableData = [];
                    var childLevel = 3;

                    for (var count = 0; count < Ti.App.OrderObj.Items.length; count++) {
                        var itemObj = Ti.App.OrderObj.Items[count];
                        var section = Ti.UI.createTableViewSection({
                            thisItemIndex: count,
                            secType: 'item',
                            backgroundColor: 'white'
                        });
                        var mainRow = Ti.UI.createTableViewRow({
                            height: Ti.UI.SIZE,
                            className: 'mainRow',
                            type: 'item',
                            backgroundColor: 'white'
                        });

                        var btnDelete = Ti.UI.createButton({
                            left: 0,
                            backgroundImage: ro.ui.properties.defaultPath + 'delete.png',
                            height: ro.ui.relX(32),
                            width: ro.ui.relX(32),
                            type: 'item',
                            itmIndex: count,
                            bubbleParent: false
                        });
                        btnDelete.addEventListener('click', deleteItem);
                        mainRow.add(btnDelete);
                        //*** Newly added

                        var itmName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
                            text: (itemObj.Size == 'None' ? '' : itemObj.Size + ' ') + (itemObj.Style ? itemObj.Style + ' ' : '') + itemObj.RcptName,
                            width: ro.ui.relX(160),
                            height: Ti.UI.SIZE,
                            left: ro.ui.relX(40),
                            textAlign: 'left',
                            color: ro.ui.theme.contentsSmallTxtHead,
                            type: 'item',
                            font: {
                                fontWeight: 'bold',
                                fontSize: ro.ui.scaleFontY(11, 14),
                                fontFamily: ro.ui.fontFamily
                            }
                        }));
                        mainRow.add(itmName);

                        var bogoPrice = '';
                        /*if(itemObj.ActivePrice == 0 && itemObj.CpnObj && itemObj.OrigPrice != 0){
                         //bogoPrice = '$' + itemObj.ActivePrice.toFixed(2);
                         }*/
                        var itmPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart, {
                            text: (itemObj.ActivePrice == 0 ? '' : '$' + itemObj.ActivePrice.toFixed(2)),
                            right: ro.ui.relX(8),
                            height: ro.ui.relY(25),
                            width: ro.ui.relX(60),
                            textAlign: 'right',
                            type: 'item'
                        }));
                        mainRow.add(itmPriceLbl);
                        section.add(mainRow);

                        var row,
                            lbl,
                            priceLbl;

                        if (itemObj.PrfMbrs) {
                            for (var i = 0; i < itemObj.PrfMbrs.length; i++) {
                                row = Ti.UI.createTableViewRow({
                                    //height:Ti.UI.SIZE,
                                    height: ro.ui.relY(20),
                                    indentionLevel: childLevel,
                                    className: 'subRow',
                                    backgroundColor: 'white'
                                });
                                lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
                                    text: itemObj.PrfMbrs[i].RcptName
                                }));

                                var prfMbrsBogoPrice = '';
                                /*if(itemObj.PrfMbrs[i].ActivePrice == 0 && itemObj.CpnObj && itemObj.PrfMbrs[i].OrigPrice != 0){
                                 prfMbrsBogoPrice = '$' + itemObj.PrfMbrs[i].OrigPrice.toFixed(2);
                                 }*/

                                priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
                                    text: (itemObj.PrfMbrs[i].ActivePrice == 0 ? '' : '$' + itemObj.PrfMbrs[i].ActivePrice.toFixed(2))
                                }));
                                row.add(lbl);
                                row.add(priceLbl);
                                section.add(row);
                                if (itemObj.PrfMbrs[i].Mods && itemObj.PrfMbrs[i].Mods.length) {
                                    for (var k = 0,
                                            kMax = itemObj.PrfMbrs[i].Mods.length; k < kMax; k++) {
                                        //Ti.API.debug('itemObj.PrfMbrs[i].Mods[k]: ' + JSON.stringify(itemObj.PrfMbrs[i].Mods[k]));
                                        row = getModRow(itemObj.PrfMbrs[i].Mods[k], true, itemObj);
                                        section.add(row);
                                    }
                                }
                                if (itemObj.PrfMbrs[i].NoMods && itemObj.PrfMbrs[i].NoMods.length) {
                                    for (var k = 0,
                                            kMax = itemObj.PrfMbrs[i].NoMods.length; k < kMax; k++) {
                                        row = getNoModRow(itemObj.PrfMbrs[i].NoMods[k], true);
                                        section.add(row);
                                    }
                                }
                            }
                        }

                        if (itemObj.NoMods) {
                            for (var j = 0; j < itemObj.NoMods.length; j++) {
                                row = getNoModRow(itemObj.NoMods[j]);
                                section.add(row);
                            }
                        }

                        if (itemObj.Mods) {
                            for (var k = 0; k < itemObj.Mods.length; k++) {
                                row = getModRow(itemObj.Mods[k], null, itemObj);
                                section.add(row);
                            }
                        }

                        if (itemObj.Notes && itemObj.Notes.length && itemObj.Notes[0].NoteText && itemObj.Notes[0].NoteText.length) {
                            row = Ti.UI.createTableViewRow({
                                height: ro.ui.relY(40),
                                //height:Ti.UI.SIZE,
                                indentionLevel: childLevel,
                                className: 'subRow',
                                backgroundColor: 'white'
                            });
                            lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl, {
                                text: 'Notes: ' + itemObj.Notes[0].NoteText,
                                color: ro.ui.theme.specialInstructionBlue,
                                height: Ti.UI.SIZE,
                                width: ro.ui.relX(190),
                            }));
                            /*priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl, {
                             text:''
                             }));*/
                            row.add(lbl);
                            //row.add(priceLbl);
                            section.add(row);
                        }

                        row = Ti.UI.createTableViewRow({
                            //height:Ti.UI.SIZE,
                            //height:Ti.UI.SIZE,
                            height: ro.ui.relY(30),
                            indentionLevel: childLevel,
                            className: 'qty',
                            backgroundColor: 'white'
                        });

                        var plusBtn = Ti.UI.createButton({
                            top: ro.ui.relY(5),
                            backgroundImage: ro.ui.properties.defaultPath + 'plus.png',
                            width: ro.ui.relX(24),
                            height: ro.ui.relX(25),
                            right: ro.ui.relX(2),
                            itmIndex: count,
                            bubbleParent: false
                        });
                        plusBtn.addEventListener('click', INCREASE);

                        var qtyLbl = Ti.UI.createLabel({
                            top: ro.ui.relY(5),
                            text: 'x' + itemObj.Qty,
                            width: ro.ui.relX(22),
                            height: ro.ui.relY(24),
                            textAlign: 'center',
                            right: ro.ui.relX(26),
                            itmIndex: count,
                            font: {
                                fontSize: ro.ui.scaleFontY(12, 24),
                                fontWeight: 'bold',
                                fontFamily: ro.ui.fontFamily
                            },
                            color: ro.ui.theme.textColor
                        });
                        var minusBtn = Ti.UI.createButton({
                            top: ro.ui.relY(5),
                            backgroundImage: ro.ui.properties.defaultPath + 'minus.png',
                            width: ro.ui.relX(24),
                            height: ro.ui.relX(25),
                            right: ro.ui.relX(48),
                            itmIndex: count,
                            enabled: (itemObj.Qty > 1 ? true : false),
                            bubbleParent: false
                        });
                        minusBtn.addEventListener('click', DECREASE);
                        row.add(minusBtn);
                        row.add(qtyLbl);
                        row.add(plusBtn);

                        try {
                            if (itemObj.CpnObj) {
                                var thisCpn = itemObj.CpnObj;
                                var cpnRow = Ti.UI.createTableViewRow({
                                    height: Ti.UI.SIZE,
                                    indentionLevel: childLevel,
                                    className: 'qty',
                                    backgroundColor: 'white',
                                    top: ro.ui.relY(5)
                                });
                                //tableData.push(getCpnRow(itemObj.CpnObj, count));
                                var cpnName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
                                    //text:'[' + Ti.App.OrderObj.Cpns[cpnIdx].RcptName + ']',
                                    text: '[' + thisCpn.RcptName + ']',
                                    color: ro.ui.theme.cpnColor,
                                    width: ro.ui.relX(160),
                                    height: ro.ui.relY(25),
                                    left: ro.ui.relX(40),
                                    textAlign: 'left',
                                    type: 'coupon'
                                }));
                                //cpnRow.add(cpnName);

                                var cpnPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart, {
                                    //text:(Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue > 0 ? '- ' + Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue.toFixed(2) : ''),
                                    text: (thisCpn.CpnActiveValue && thisCpn.CpnActiveValue > 0 ? '- ' + thisCpn.CpnActiveValue.toFixed(2) : ''),
                                    color: ro.ui.theme.cpnColor,
                                    textAlign: 'right',
                                    right: ro.ui.relX(8),
                                    height: ro.ui.relY(25),
                                    width: ro.ui.relX(60),
                                    type: 'coupon'
                                }));
                                cpnRow.add(cpnName);
                                cpnRow.add(cpnPriceLbl);
                                section.add(cpnRow);
                            }
                        } catch (ex) {
                            Ti.API.debug('getCpnRow()-Exception: ' + ex);
                        }

                        if (!itemObj.CpnObj) {
                            section.add(row);
                        }

                        var itemSeparator = Ti.UI.createTableViewRow({
                            height: ro.ui.relY(5),
                            bottom: 0,
                            width: Ti.UI.FILL
                        });
                        itemSeparator.add(Ti.UI.createView({
                            top: ro.ui.relY(3),
                            height: 3,
                            width: Ti.UI.FILL,
                            backgroundColor: ro.ui.theme.separatorColor
                        }));
                        section.add(itemSeparator);
                        tableData.push(section);
                    }

                    if (Ti.App.OrderObj.Cpns) {
                        for (var cpnIdx = 0; cpnIdx < Ti.App.OrderObj.Cpns.length; cpnIdx++) {
                            var cpnSection = Ti.UI.createTableViewSection({
                                thisCouponIndex: i,
                                secType: 'coupn'
                            });
                            var cpnRow = Ti.UI.createTableViewRow({
                                height: Ti.UI.SIZE,
                                className: 'cpnRow',
                                type: 'coupon',
                                backgroundColor: 'white'
                            });

                            var cpnDelete = Ti.UI.createButton({
                                left: 0,
                                backgroundImage: ro.ui.properties.defaultPath + 'delete.png',
                                height: ro.ui.relX(32),
                                width: ro.ui.relX(32),
                                itmIndex: cpnIdx,
                                type: 'coupon',
                                bubbleParent: false
                            });
                            cpnDelete.addEventListener('click', deleteItem);
                            cpnRow.add(cpnDelete);
                            //*** Newly added

                            var cpnName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
                                text: '[' + Ti.App.OrderObj.Cpns[cpnIdx].RcptName + ']',
                                color: ro.ui.theme.cpnColor,
                                width: ro.ui.relX(160),
                                height: ro.ui.relY(25),
                                left: ro.ui.relX(40),
                                textAlign: 'left',
                                type: 'coupon'
                            }));
                            cpnRow.add(cpnName);

                            var cpnPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart, {
                                text: (Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue > 0 ? '- ' + Ti.App.OrderObj.Cpns[cpnIdx].CpnActiveValue.toFixed(2) : ''),
                                color: ro.ui.theme.cpnColor,
                                textAlign: 'right',
                                right: ro.ui.relX(8),
                                height: ro.ui.relY(25),
                                width: ro.ui.relX(60),
                                type: 'coupon'
                            }));
                            cpnRow.add(cpnPriceLbl);
                            cpnSection.add(cpnRow);
                            var sectionSeparator = Ti.UI.createTableViewRow({
                                height: 1,
                                width: Ti.UI.FILL
                            });
                            sectionSeparator.add(Ti.UI.createView({
                                height: 2,
                                width: Ti.UI.FILL,
                                backgroundColor: ro.ui.theme.separatorColor
                            }));
                            cpnSection.add(sectionSeparator);
                            tableData.push(cpnSection);
                        }
                    }

                    itemTable.data = tableData;
                    if (surchargeValueLbls && surchargeValueLbls.length && Ti.App.OrderObj && Ti.App.OrderObj.Surcharges && Ti.App.OrderObj.Surcharges.length && (Ti.App.OrderObj.Surcharges.length == surchargeValueLbls.length)) {
                        for (var i = 0, iMax = surchargeValueLbls.length; i < iMax; i++) {
                            surchargeValueLbls[i].text = ("$" + Ti.App.OrderObj.Surcharges[i].ActivePrice.toFixed(2));
                        }
                    }
                    subTotalValue.text = '$' + Ti.App.OrderObj.Subtotal.toFixed(2);
                    taxValue.text = '$' + Ti.App.OrderObj.Tax.toFixed(2);
                    totalValue.text = '$' + Ti.App.OrderObj.ActiveTotal.toFixed(2);
                }


                ro.ui.reloadCart = function(_cbFn) {
                    try {
                        var priceEngine = require('logic/pricing');
                        var func = priceEngine.pricer();

                        if (setVisibility()) {
                            Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                            showTicket();
                            var rowCount = 0;

                            for (var i = 0; i < tableData.length; i++) {
                                rowCount += tableData[i].rowCount;
                            }
                            itemTable.scrollToIndex(rowCount - 1);
                        } else {
                            if (ro.app.Store && ro.app.Store.Menu) {
                                Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                            }
                        }

                        if (_cbFn) {
                            _cbFn();
                        }
                    } catch (ex) {
                        ro.ui.alert('cart', 'Error occured. CODE: 102 \n');
                        Ti.API.info("Exception Code 102: " + JSON.stringify(ex));
                    }
                };

                var deletedItemHolder;

                function areCouponsStillValid() {
                    var cpnLength = Ti.App.OrderObj.Cpns ? Ti.App.OrderObj.Cpns.length : 0;
                    var currentSubtotal = Ti.App.OrderObj.Subtotal || 0;

                    for (var i = 0; i < cpnLength; i++) {
                        for (var j = 0; j < ro.app.Store.Menu.Cpns.length; j++) {
                            if (Ti.App.OrderObj.Cpns[i].Name == ro.app.Store.Menu.Cpns[j].Name) {
                                if (ro.app.Store.Menu.Cpns[j].MultiQualTtl) {
                                    var cpnMinPrice = ro.app.Store.Menu.Cpns[j].MultiQualTtl;
                                    if (currentSubtotal < cpnMinPrice) {
                                        ro.ui.popup('WARNING: ', ['CANCEL', 'OK'], 'Removing the previous item makes ' + Ti.App.OrderObj.Cpns[i].Name + ' invalid. Touch Cancel to undo?', function(e) {
                                            var test = Ti.App.OrderObj;
                                            if (e.index === 1) {
                                                if (test.Cpns.length === 1) {
                                                    test.Cpns = [];
                                                } else {
                                                    test.Cpns.splice(i, 1);
                                                }
                                            } else {
                                                var deletedItem = deletedItemHolder;
                                                test.Items.push(deletedItem);
                                            }
                                            Ti.App.OrderObj = test;
                                            test = null;
                                            ro.ui.reloadCart();
                                            deletedItemHolder = null;
                                        });
                                    }
                                }
                            }
                        }
                    }
                }


                btnCoupons.addEventListener('click', function(e) {
                    try {
                        ro.ui.cartShowNext({
                            showing: 'Coupons',
                            addView: true
                        });
                    } catch (ex) {
                        ro.ui.alert('Error', 'Please try again.');
                    }
                });

                a.addEventListener('click', function(e) {
                    try {
                        if (e.index == 0) {
                            switch (e.source.title) {                                
                                case "Cancel Order":                                    
                                    ro.ui.clearCart();
                                    break;
                                case "Delete Item":
                                    var test = Ti.App.OrderObj;
                                    deletedItemHolder = test.Items[e.source.itmIndex];
                                    test.Items.splice(e.source.itmIndex, 1);
                                    if (deletedItemHolder.CpnObj && deletedItemHolder.CpnObj.BogoID) {
                                        for (var i = 0; i < test.Items.length; i++) {
                                            if (test.Items[i].BogoID && (deletedItemHolder.CpnObj.BogoID == test.Items[i].BogoID)) {
                                                delete test.Items[i].BogoID;
                                            }
                                        }
                                    } else if (deletedItemHolder.BogoID) {
                                        for (var i = 0; i < test.Items.length; i++) {
                                            if (test.Items[i].CpnObj && (test.Items[i].CpnObj.BogoID == deletedItemHolder.BogoID)) {
                                                delete test.Items[i].CpnObj;
                                            }
                                        }
                                    }
                                    Ti.App.OrderObj = test;
                                    test = null;
                                    break;
                                case "Delete Coupon":
                                    var test = Ti.App.OrderObj;
                                    test.Cpns.splice(e.source.itmIndex, 1);
                                    Ti.App.OrderObj = test;
                                    test = null;
                                    break;
                            }
                            ro.ui.reloadCart(function(e) {
                                areCouponsStillValid();
                            });

                        }
                    } catch (ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('CartCL100-Exception: ' + ex);
                        }
                        ro.ui.alert('Cart', 'CL100');
                    }
                });

                function INCREASE(e) {
                    var test = Ti.App.OrderObj;                    
                    test.Items[e.source.itmIndex].Qty++;
                    Ti.App.OrderObj = test;
                    Ti.App.ItemsSplit = true;
                    ro.ui.reloadCart();
                }

                function DECREASE(e) {
                    var test = Ti.App.OrderObj;
                    test.Items[e.source.itmIndex].Qty--;
                    Ti.App.OrderObj = test;
                    Ti.App.ItemsSplit = true;
                    ro.ui.reloadCart();
                }

                function addFOLCoupon(coupon) {
                    var cpnObj = {};
                    var Ord = Ti.App.OrderObj;

                    if (!Ord.Cpns) {
                        Ord.Cpns = [];
                    }

                    cpnObj.CpnValue = coupon.CpnValue;
                    cpnObj.RcptName = coupon.RcptName;
                    cpnObj.Name = coupon.Name;
                    cpnObj.CpnScope = coupon.CpnScope;
                    cpnObj.CpnType = coupon.CpnType;
                    cpnObj.CpnPct = coupon.CpnPct;
                    cpnObj.MinPrice = coupon.MinPrice;
                    cpnObj.MaxValue = coupon.MaxValue;
                    cpnObj.AdjItemPrice = coupon.AdjItemPrice;
                    cpnObj.TaxType = coupon.TaxType;
                    cpnObj.ReportGrp = coupon.ReportGrp;
                    cpnObj.FreeDlvy = coupon.FreeDlvy;
                    cpnObj.LeaveTax = coupon.LeaveTax;
                    cpnObj.No2ndItm = coupon.No2ndItm;
                    cpnObj.BeatClock = coupon.BeatClock;
                    var curDate = new Date();
                    var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
                    cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
                    cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));
                    cpnObj.IsExclusive = coupon.IsExclusive;
                    cpnObj.MaxModValue = coupon.MaxModValue;
                    Ord.Cpns.push(cpnObj);
                    Ti.App.OrderObj = Ord;
                    ro.ui.reloadCart();
                }

                function firstOnlineOrder() {
                    var CpnIdx;
                    for (CpnIdx = 0; CpnIdx < storeObj.Menu.Cpns.length; CpnIdx++) {
                        if (storeObj.Menu.Name == storeObj.Menu.Cpns[CpnIdx].Menu || storeObj.Menu.Cpns[CpnIdx].Menu == 'All') {
                            if (storeObj.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER') {
                                addFOLCoupon(storeObj.Menu.Cpns[CpnIdx]);
                                Ti.App.firstOLOrdCpnApplied = true;
                                var firstOLOrder = Ti.UI.createAlertDialog();
                                firstOLOrder.title = 'FIRST ONLINE ORDER';
                                firstOLOrder.buttonNames = ['OK'];
                                firstOLOrder.message = storeObj.Menu.Cpns[CpnIdx].CpnDesc;
                                firstOLOrder.show();
                                break;
                            }
                        }
                    }
                }


                ro.ui.refreshCart = function(e) {
                    try {
                        Ti.API.info('REFRESH CART 3040');
                        storeObj = ro.app.Store || {};
                        if (setVisibility()) {
                            if (false && Ti.App.firstOLOrdCpnExists && !Ti.App.firstOLOrdCpnApplied && !isGuest) {
                                firstOnlineOrder();
                            } else {
                                showTicket();
                            }
                        }
                    } catch (ex) {
                        ro.ui.alert('Cart', 'CR100');
                    }
                };

                function calcAmt(msg) {
                    var trimmedMsg = msg.replace(/^\s+|\s+$/g, '');
                    var startPosition = -1;
                    startPosition = trimmedMsg.indexOf("[SubTotal");

                    if (startPosition > -1) {
                        var endPosition = -1;
                        endPosition = trimmedMsg.indexOf("]", startPosition);

                        if (endPosition > -1) {
                            var func = "";
                            func = trimmedMsg.substr(startPosition, endPosition - startPosition + 1);
                            var subTotal;
                            var math = "";
                            math = func.substr(1, func.length - 2).replace("SubTotal", Ti.App.OrderObj.Subtotal.toString());
                            var strArray = math.split("*");
                            var result = parseFloat(strArray[0]) * parseFloat(strArray[1]);
                            trimmedMsg = trimmedMsg.replace(func, String.formatCurrency(result));
                        }
                    }
                    return trimmedMsg;
                }

                function editCartItem(e) {
                    //Ti.API.debug('e: ' + JSON.stringify(e));
                    if (e.section.secType === 'item') {
                        var itmIdx = e.section.thisItemIndex;
                        if (Ti.App.OrderObj.Items[itmIdx].noEdit) {
                            Ti.API.debug('Cant Edit due to it have nothing editable about it');
                        } else {
                            ro.App.edit.editMode = true;
                            ro.App.edit.editIndex = itmIdx;
                            ro.ui.cartShowNext({
                                showing: 'Cart'
                            });
                        }
                    }
                    if (e.row.className === 'subRow') {

                    }
                    if (e.row.className === 'mainRow') {

                    }
                }

                function minOrdValidation() {
                    var minOrdStoreObj = ro.app.Store;
                    var minOrder = 0;
                    for (var j = 0; j < minOrdStoreObj.Menu.OnlineOptions.OrdTypes.length; j++) {
                        if (minOrdStoreObj.Menu.OnlineOptions.OrdTypes[j].IsDelivery == Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                            minOrder = minOrdStoreObj.Menu.OnlineOptions.OrdTypes[j].MinOrd;
                            break;
                        }
                    }

                    if (Ti.App.OrderObj.Subtotal < minOrder) {
                        ro.ui.alert('Order', 'Minimum subtotal amount for ' + Ti.App.OrderObj.OrdType + ' is $' + minOrder + '.');
                        return 0;
                    } else {
                        return 1;
                    }
                }


                btnCheckout.addEventListener('click', function() {
                    //Ti.include('/controls/paymentControl.js');
                    try {

                        if (!Ti.App.OrderObj.Items || !Ti.App.OrderObj.Items.length) {
                            ro.ui.alert('Error:', 'You must have at least one item before proceeding to checkout.');
                            return;
                        }
                        var payControl = require('controls/paymentControl');
                        payControl.clearPaymentInfo();
                        /*var propsToClear = ["DisplayOrdPayment", "Tip"];
                        if("ordOnlineOptions" in ordObj){
                        ordObj.ordOnlineOptions.CCInfo = null;
                        }*/
                        //ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
                        //payControl.clearFavoriteProp();
                        ro.utils.removeProp('favName');
                        //payControl.clearMultiPaymentInfo();
                        require('logic/MultiplePmtHelper').SaveMultiPmts();

                        if (minOrdValidation()) {
                            var numItemsInCart = Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
                            if (REV_Suggest.init(ro.app.Store.Configuration.ALLOW_SUGG, ro.app.Store.Configuration.SUGG_MAX, ro.app.Store.SuggItems, numItemsInCart)) {
                                Ti.API.info("Cleared Sugg Init 2");
                                if (REV_Suggest.needsSuggestion()) {
                                    ro.ui.cartShowNext({
                                        addView: true,
                                        showing: 'Suggest'
                                    });
                                } else {
                                    ro.ui.cartShowNext({
                                        addView: true,
                                        showing: checkoutHid
                                    });
                                }
                            } else {
                                ro.ui.cartShowNext({
                                    addView: true,
                                    showing: checkoutHid
                                });
                            }
                        }
                    } catch (ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('btnCheckout(Event)-Exception: ' + ex);
                        }
                    }
                });
                ro.ui.reloadCart();
                return mainView;
            };
            var canEdit = function(idx) {
                var canEditBln = true;
                //Ti.API.debug('idx: ' + idx);
                var itm = Ti.App.OrderObj.Items[idx];
                //Ti.API.debug('itm: ' + JSON.stringify(itm));
                var grpName = itm.GroupName,
                    itmName = itm.Name;
                var menu = ro.app.Store.Menu;

                var thisGroup = menuUtils.getGrp(grpName, menu);
                //Ti.API.debug('thisGroup: ' + JSON.stringify(thisGroup));
                var thisItem = menuUtils.getItm(itmName, thisGroup);
                //Ti.API.debug('thisItem: ' + JSON.stringify(thisItem));
                if (menuUtils.straightToCart(thisGroup, thisItem)) {
                    canEditBln = false;
                }

                return canEditBln;
            };
        } catch (ex) {
            ro.ui.alert('Cart', 'CODE 500');
            if (Ti.App.DEBUGBOOL) {
                Ti.API.debug('ro.ui.createCartView()-Exception: ' + ex);
            }
        }
    };
    return {
        cartview: cartview
    };
}();
module.exports = CARTVIEW;