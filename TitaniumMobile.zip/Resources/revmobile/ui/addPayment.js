var ADDPAYMENTVIEW = function(){
	var addpaymentview = function(){
		//var 
		//Ti.include('/controls/ccControl.js');
		//Ti.include('/controls/paymentControl.js');
		
		//var regexVal;
	   	//var credCardVal;
	   	//var ccControl;
	   	//var payControl;
	   	//var creditCardForm;
		
		var getDollarFormat = function(number){
			return (Math.round(number * 100) / 100);
		};
		var reset;
		var MultiplePmtHelper = require('logic/MultiplePmtHelper');
		var doesTotalExceedThreshold = function(){
	  	
	  	 /*for(var p in Ti.App.OrderObj){
	  	 	Ti.API.debug('Ti.App.OrderObj['+p+']: ' + JSON.stringify(Ti.App.OrderObj[p]));
	  	 }*/
	  	 var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	     if(!cfg){
	        cfg = {};
	     }
	  	
	  	 var ttl = Ti.App.OrderObj.ActiveTotal;
	  	 
	  	 return cfg
	  	 	&& cfg.FORCE_CC_THRESHOLD
	  	 	&& !(parseFloat(cfg.FORCE_CC_THRESHOLD) > parseFloat(ttl)); 
	  };
	    function getPicker(pickerTxt, isFullRowWidth) {
				var picker = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
					height : Ti.UI.FILL,
					width : isFullRowWidth ? '100%' : '45%'//,
					//top:ro.ui.relY(5),
					//bottom:ro.ui.relY(25)
				}));
				var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
					text : pickerTxt,
					left : ro.ui.relX(10),
					touchEnabled : false
				}));
				var arrowImg = Ti.UI.createImageView({
					image : '/images/downArrow.png',
					height : ro.ui.relY(40),
					width : ro.ui.relY(40),
					right : ro.ui.relX(5),
					touchEnabled : false
				});
				picker.add(lbl);
				picker.add(arrowImg);
				picker.setPickText = function(text){
					lbl.text = text;
				};
				picker.getPickText = function(){
					return lbl.text;
				};
				return picker;
			}
			
			function getAndroidPicker(defaultText, pickRowData, pickChangeEvt, isFullRowWidth, firstOrLast){
                //Ti.API.info('pickRowData: ' + JSON.stringify(pickRowData));
                var pickerParent = Ti.UI.createView({
                   width:isFullRowWidth ? '100%' : (ro.ui.properties.wideViewWidth - 2*innerTablePadding) * .333,
                   height:Ti.UI.FILL
                });
                var picker = Ti.UI.createPicker(ro.combine(ro.ui.properties.allTxtField,{
                    type:Ti.UI.PICKER_TYPE_PLAIN,
                    height:Ti.UI.FILL,
                    focusable:true,
                    //selectionOpens:true,
                    zindex:5,
                    width:Ti.UI.FILL,
                    opacity:0,
                    backgroundColor:'white'
                }));
                picker.add(pickRowData);
                
                if(pickChangeEvt){
                    picker.addEventListener('change', pickChangeEvt);
                }
                
                var fieldObject = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
                    height:ro.ui.relY(50),
                    //width:ro.ui.relX(325),
                    //top:ro.ui.relY(0),
                    //bottom:ro.ui.relY(25),
                    text:defaultText,
                    textData:defaultText,
                    picker:picker,
                    specialType:'iospicker',
                    width:isFullRowWidth ? '100%' : (firstOrLast ? Ti.UI.FILL :(ro.ui.properties.wideViewWidth - 2*innerTablePadding) * .31)
                }));
                var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                    text:defaultText,
                    textData:defaultText,
                    left:ro.ui.relX(13),
                    touchEnabled:false
                }));
                var arrowSize = isFullRowWidth ? ro.ui.relX(40) : ro.ui.relY(30);
                var arrowRight = isFullRowWidth ? ro.ui.relX(5) : ro.ui.relX(3);
                var arrowImg = Ti.UI.createImageView({
                    image:'/images/downArrow.png',
                    height:arrowSize,
                    width:arrowSize,
                    right:arrowRight,
                    touchEnabled:false
                });
                fieldObject.add(lbl);
                fieldObject.add(arrowImg);
                fieldObject.add(fieldObject.picker);
                
                function setLblText(newTxt, newTxtData){
                    fieldObject.text = newTxt;
                    fieldObject.textData = newTxtData;
                    lbl.text = newTxt;
                    lbl.textData = newTxtData;
                }
                //fieldObject.setLblText = setLblText;
                pickerParent.setLblText = setLblText;
                pickerParent.add(fieldObject);
                pickerParent.getChosenRow = function(){
                    Ti.API.info('fieldObject.picker.getSelectedRow(0): ' + JSON.stringify(fieldObject.picker.getSelectedRow(0)));
                    return fieldObject.picker.getSelectedRow(0);
                };
                pickerParent.setFutureDate = function(rowIndex){
                    fieldObject.picker.setSelectedRow(0, rowIndex);
                    var selRow = fieldObject.picker.getSelectedRow(0);
                    
                    setLblText(selRow.title, selRow.title);
                };
                pickerParent.getPickText = function(){
                    return lbl.text;
                };
                
                pickerParent.pickRowData = pickRowData;
                return pickerParent;
            }
	   ro.ui.addPaymentView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/giftCardForm.js');
	      /*var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:gcForm.getGcForm(),
	         settings:ro.ui.properties.myAccountView
	      });*/
	     
	      var ccControl = require('controls/ccControl');
	     
		  var storeObj = ro.app.Store;
		  var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	      if(!cfg){
	         cfg = {};
	      }
	      var customAlertView = ro.ca.createCustomAlert();
	      var parentView =  Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'addPmt', hid:'addPmt'}));
	      var mainView =  Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'addPmt', hid:'addPmt', layout:'vertical'}));
	      parentView.add(mainView);
	      //mainView.customAlertView = customAlertView;
	      parentView.customAlertView = customAlertView;
	      parentView.add(parentView.customAlertView);
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      
	      var btnBack = layoutHelper.getBackBtn('BACK');
	      btnBack.addEventListener('click', function(e){ 
	      	ro.GlobalPicker.hidePicker();
	      	ro.ui.cartShowNext({ showing:'addPmt' });
	      });
	      navBar.add(btnBack);
	
	      var btnUpdate = layoutHelper.getBigButton('Add Payment');
	      btnUpdate.addEventListener('click', function(e){
	          //ro.GlobalPicker.hidePicker();
	      	 //if(MultiPmtSwitch && MultiPmtSwitch.value){
	      	 	
	      	 //}
	      	 //else{
	      	 	ro.GlobalPicker.hidePicker();
	      	 	//var selRow = paymentPicker.getSelectedRow(0);
	      	 	var dispordpayment = thePick.getPickText();
	      	 	Ti.API.info('dispordpayment: ' + dispordpayment);
	      	 	
	      	 	var tip = CC_TIPS.getTip();
	      	 	//Ti.API.debug('tip1: ' + tip);
	      	 	//if(selRow && selRow.title.toLowerCase() == 'cash'){
	      	 	if(!payView || !payView.children || !payView.children.length){
	      	 		var test = Ti.App.OrderObj;
	                test.IsOnline = true;
	                test.DisplayOrdPayment = dispordpayment.replace(' ', '');
	                Ti.App.OrderObj = test;
	                
	                ro.ui.cartShowNext({ showing:'addPmt' });
	      	 	}
	      	 	else{
	      	 		payView.children[0].SubmitForm(tip);
	      	 	}
	      	 //}
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      
	      var scrollableView = Ti.UI.createScrollView({
	      	disableBounce:ro.isiOS ? true : false,
	      	 top:0,
	      	 height:Ti.UI.FILL,
	      	 width:Ti.UI.FILL,
	      	 layout:'vertical'
	      });
	      mainView.add(scrollableView);
	      
	      var paymentPicker = Ti.UI.createPicker({
	      	selectionIndicator: true,
	      	 top:ro.ui.relY(20),
			 type:Ti.UI.PICKER_TYPE_PLAIN,
			 height:ro.ui.relY(40),
			 width:Ti.UI.FILL,
			 backgroundColor:ro.ui.theme.pickerColor,
			 bottom:ro.ui.relY(25),
			 focusable:true//,
			 //selectionOpens:true
		  });
		  var paymentPickerRows = [];
	      
	      var ccOnly = doesTotalExceedThreshold() || false;
	         //Ti.API.debug('ccOnly: ' + ccOnly);
	         
	         var creditRow = Ti.UI.createPickerRow({title:'CREDIT CARD'});
	         var savedRow = Ti.UI.createPickerRow({title:'USE EXISTING CARD'});
	         var otherPayRow, otherPayLbl;
	
	         //var chosenGiftCard = payControl.hasChosenGiftCard();
	
	         switch(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	            case true:
	               var creditIdxOffset = 0;
	               var savedCreditIdxOffset = 0; 
	               if(storeObj.Configuration.AllowCCDelivery && storeObj.Configuration.CardTypes){
	               	  //Ti.include('/controls/ccControl.js');
	         		  //ro.ui.cartShowNext({addView:true, showing:ccControl.hasSavedCards()?'Payment':'AddPayment'});
	         		  if(ccControl.hasSavedCards(ro)){
	         		  	 savedRow.index = 0;
	         		  	 savedCreditIdxOffset = 1;
	         		  	 paymentPickerRows.push(savedRow);
	         		  }
	               	
	               	  creditRow.index = 0 + savedCreditIdxOffset;
	               	  creditIdxOffset = 1 + savedCreditIdxOffset;
	                  paymentPickerRows.push(creditRow);
	                  hasCC = true;
	               }
	               if(storeObj.Configuration.AllowPayUponDelivery && storeObj.Configuration.PayUponOptions){
	                  for(var k=0; k<storeObj.Configuration.PayUponOptions.length; k++){
	                    var otherPayRow = Ti.UI.createPickerRow({index:k+creditIdxOffset, title:storeObj.Configuration.PayUponOptions[k]});
	                     if(!ccOnly || (storeObj.Configuration.PayUponOptions[k]==='GIFT')){
	                     	paymentPickerRows.push(otherPayRow);
	                     }
	                  }
	                  hasPayupon = true;
	               }
	               break;
	            case false:
	               var creditIdxOffset = 0;
	               if(storeObj.Configuration.AllowCCPickup && storeObj.Configuration.CardTypes){
	               	  if(ccControl.hasSavedCards(ro)){
	         		  	 savedRow.index = 0;
	         		  	 savedCreditIdxOffset = 1;
	         		  	 paymentPickerRows.push(savedRow);
	         		  }
	               	
	               	  creditRow.index = 0 + savedCreditIdxOffset;
	               	  creditIdxOffset = 1 + savedCreditIdxOffset;
	                  paymentPickerRows.push(creditRow);
	                  hasCC = true;
	               }
	               if(storeObj.Configuration.AllowPayUponPickup && storeObj.Configuration.PayUponOptions){
	                  for(var k=0; k<storeObj.Configuration.PayUponOptions.length; k++){
	                    var otherPayRow = Ti.UI.createPickerRow({index:k+creditIdxOffset, title:storeObj.Configuration.PayUponOptions[k]});
	                     if(!ccOnly || (storeObj.Configuration.PayUponOptions[k]==='GIFT')){
	                     	paymentPickerRows.push(otherPayRow);
	                     }
	                  }
	                  hasPayupon = true;
	               }
	               break;
	         }
	
				/*var levelupRowCount = 0;
				if(!ccOnly && levelUp.isLU && levelUp.isEnabled()){//This will be the check that if true will display levelUp as a payment option.
					var lvlupDone = Ti.App.Properties.getBool('lvlupBool', false);
					var levelupLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		               text:'REWARDS'
		            }));
	            var levelupRow = Ti.UI.createTableViewRow({
	               className:'paymentOptions',
	               height:ro.ui.relY(43),
	               width:ro.ui.relX(345),
	               layout:'horizontal',
	               isCredit:false,
	               isLevelup:true,
	               rightImage:lvlupDone?'/images/check.png':'',
	               hasChecked:lvlupDone?true:false,
	               rowName:'levelup',
	               isGiftCard:false,
	               backgroundColor:'white'
	            });
	            levelupRow.add(levelupLbl);
	            data1.push(levelupRow);
	            levelupRowCount = 1;
	
	            if(lvlupDone){
	            	var test = Ti.App.OrderObj;
	               test.IsOnline = true;
	               test.DisplayOrdPayment = 'LEVELUP';
	               Ti.App.OrderObj = test;
	            }*/
	       	//}
			var levelupRowCount = 0;
	         var payRowCount;
	         if(storeObj.Configuration.PayUponOptions){
	            payRowCount = 1+storeObj.Configuration.PayUponOptions.length + levelupRowCount;
	         }
	         else{
	            payRowCount = 1 + levelupRowCount;
	         }
	
	         //scrollableView.add(paymentPicker);
	         var innerTablePadding = ro.ui.relX(15);
	         var paymentTypeView = Ti.UI.createView({
				top : ro.ui.relY(5),
				height : ro.ui.relY(50),
				width:ro.ui.properties.wideViewWidth// - 2*innerTablePadding,
				//left : innerTablePadding,
				//right : innerTablePadding
			 });
			 //function getAndroidPicker(defaultText, pickRowData, pickChangeEvt, isFullRowWidth, firstOrLast){
			     
			 
            var androidPaymentPickerFn = function(ee) {
                //Ti.API.debug('ee: ' + JSON.stringify(ee));
                var newText;
                var selRow = ee.source.getSelectedRow(0);
                //Ti.API.debug('selectedRow: ' + JSON.stringify(selectedRow));
                if (selRow && selRow.title) {
                    Ti.API.info('selRow.title: ' + selRow.title);

                    thePick.setLblText(selRow.title, selRow.title);

                    payView.removeAllChildren();

                    var mPmts = MultiplePmtHelper.GetMultiPmts();
                    newAddPmtBtnVis = true;

                    tipsView.ResetTip(selRow.title.toLowerCase());

                    switch(selRow.title.toLowerCase()) {
                        case "use existing card":
                            //toggleAddPaymentBtnVis(false);
                            if (cfg && cfg.AllowCCTips) {
                                tipsView.show();
                                tipsView.visible = true;
                            }
                            else {
                                tipsView.hide();
                                tipsView.visible = false;
                            }
                            newAddPmtBtnVis = false;
                            payView.add(GetSavedCreditView(mPmts, parentView.customAlertView));
                            break;
                        case "credit card":
                            if (cfg && cfg.AllowCCTips) {
                                tipsView.show();
                                tipsView.visible = true;
                            }
                            else {
                                tipsView.hide();
                                tipsView.visible = false;
                            }
                            payView.add(GetCreditView(mPmts));
                            break;
                        case "gift":
                            if (false && cfg && cfg.AllowGiftTips) {
                                tipsView.show();
                                tipsView.visible = true;
                            }
                            else {
                                tipsView.hide();
                                tipsView.visible = false;
                            }
                            payView.add(GetGiftView(mPmts));
                            break;
                        default:
                            tipsView.hide();
                            tipsView.visible = false;
                            if (mPmts.DoMultiPmts)
                                payView.add(GetNonCardView(mPmts, selRow.title));
                            break;
                    }

                    toggleAddPmtBtnVis(newAddPmtBtnVis);

                }
            }; 

			     
			 var thePick = ro.isiOS ? getPicker(paymentPickerRows[0].title, true) : getAndroidPicker(paymentPickerRows[0].title, paymentPickerRows, androidPaymentPickerFn, true);
			 
			 function getPaymentOptionsPicker(pickRows){
				/*var pickRows = [];
   				var nowRow = ro.isiOS ? {title:"Now"} : Ti.UI.createPickerRow({title:"Now"});
   				pickRows.push(nowRow);
   				var futureRow = ro.isiOS ? {title:"Future"} : Ti.UI.createPickerRow({title:"Future"});
				pickRows.push(futureRow);*/
					
	   			var picker = Ti.UI.createPicker({
	   				selectionIndicator: true,
					type:Ti.UI.PICKER_TYPE_PLAIN,
					//useSpinner:true,
					top:ro.isiOS ? 13 : 0
				});
				if(true){
					picker.width = Ti.UI.FILL;
					picker.height = Ti.UI.FILL;
				}
				
				picker.add(pickRows);
				return picker;
			}
			 if(ro.isiOS){
    			 thePick.addEventListener('click', function(e){
    			 		
    					var paymentOptionsPicker = getPaymentOptionsPicker(paymentPickerRows);
    					paymentOptionsPicker.addEventListener('change', function(ee){
    						//Ti.API.debug('ee: ' + JSON.stringify(ee));
    						var newText;
    						var selRow = paymentOptionsPicker.getSelectedRow(0);
    						//Ti.API.debug('selectedRow: ' + JSON.stringify(selectedRow));
    						if(selRow && selRow.title){
    							Ti.API.info('selRow.title: ' + selRow.title);
    							/*if(selectedRow.title == "Future"){
    								getDateTimePicker(function(){
    									
    								},setLbls);
    								orderTimeView.height = ro.ui.relY(50);
    								newText = "Future";
    							}
    							else{
    								newText = "Now";
    								orderTimeView.height = 0;
    								var payControl = require('controls/paymentControl');
    								ro.utils.removeProp('futureTimeObj');
    								payControl.clearFutureOrder();
    							}*/
    							thePick.setPickText(selRow.title);
    							
    							payView.removeAllChildren();
    	         	
    	         	var mPmts = MultiplePmtHelper.GetMultiPmts();
    	         	newAddPmtBtnVis = true;
    	         	
    	         	tipsView.ResetTip(selRow.title.toLowerCase());
    	         	
    	         	switch(selRow.title.toLowerCase()){
    	         		case "use existing card":
    	         		    //toggleAddPaymentBtnVis(false);
    	         		    if(cfg && cfg.AllowCCTips){
    	         		    	tipsView.show();
    		         			tipsView.visible = true;
    	         		    }
    	         		    else{
    	         		    	tipsView.hide();
    		         			tipsView.visible = false;
    	         		    }
    	         		    newAddPmtBtnVis = false;
    	         			payView.add(GetSavedCreditView(mPmts, parentView.customAlertView));
    	         			break;
    	         		case "credit card":
    	         			if(cfg && cfg.AllowCCTips){
    	         		    	tipsView.show();
    		         			tipsView.visible = true;
    	         		    }
    	         		    else{
    	         		    	tipsView.hide();
    		         			tipsView.visible = false;
    	         		    }
    	         			payView.add(GetCreditView(mPmts));
    	         			break;
    	         		case "gift":
    	         			if(false && cfg && cfg.AllowGiftTips){
    	         		    	tipsView.show();
    		         			tipsView.visible = true;
    	         		    }
    	         		    else{
    	         		    	tipsView.hide();
    		         			tipsView.visible = false;
    	         		    }
    	         			payView.add(GetGiftView(mPmts));
    	         			break;
    	         		default:
    	         			tipsView.hide();
    		         		tipsView.visible = false;
    	         			if(mPmts.DoMultiPmts)
    	         				payView.add(GetNonCardView(mPmts, selRow.title));
    	         			break;
    	         	}
    	         	
    	         	toggleAddPmtBtnVis(newAddPmtBtnVis);
    							
    						}
    					});
    					ro.GlobalPicker.setPicker(paymentOptionsPicker);
    					if(!ro.isiOS){
    						var customHeight = ro.ui.relY(150);
    			      	    ro.GlobalPicker.showPicker(customHeight);
    					}
    					else{
    			      	 	ro.GlobalPicker.showPicker();
    					}
    				});
    		}
			 
			 paymentTypeView.add(thePick);
	         scrollableView.add(paymentTypeView);
	         
	         var payView = Ti.UI.createView({
	         	top:ro.ui.relY(5),
	         	height:Ti.UI.SIZE,
	         	//width:ro.ui.relX(325)
	         	width:ro.ui.properties.wideViewWidth
	         });
	         
	         
	         var allowMultiPmts = storeObj.Configuration.AllowMultiPmts;
	         var doingMultiPmts = false;
			 var multiPmts = MultiplePmtHelper.GetMultiPmts();
			 var MultiPmtSwitch;
	         if(allowMultiPmts){
	         	
	         	try{
	         		var MultiPmtView = Ti.UI.createView({
			         	height:Ti.UI.SIZE,
			         	top:ro.ui.relY(5),
			         	width:Ti.UI.SIZE,
			         	//backgroundColor:ro.isiOS ? "transparent" : '#f6f6f6',
			         	layout:'horizontal'
			         });
			         var MultiPmtLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
			               text:'Split Payments? (Click Me)',
			               top:0,
			               width:Ti.UI.SIZE
			            }));
			         MultiPmtSwitch = Ti.UI.createView({/*ro.combine(ro.ui.properties.defaultSwitch, {*/			        	
			         	left:ro.ui.relY(5),
			         	height:ro.ui.relY(25),
			         	width:ro.ui.relY(25),
			         	borderColor:'transparent',
			         	
				        //backgroundColor:ro.isiOS ? null : 'black',
				        backgroundImage:multiPmts && multiPmts.DoMultiPmts ? "/images/checkedbox.png" : "/images/uncheckedbox.png",
				        thevalue:multiPmts && multiPmts.DoMultiPmts ? true : false
				     });
				     MultiPmtSwitch.addEventListener('click', function(e){
				     	//Ti.API.info('e: ' + JSON.stringify(e));
				         ro.GlobalPicker.hidePicker();
				         MultiPmtSwitch.thevalue = !MultiPmtSwitch.thevalue;
				         MultiPmtSwitch.backgroundImage = MultiPmtSwitch.thevalue ? "/images/checkedbox.png" : "/images/uncheckedbox.png";
				     	tipsView.ResetTip();
				     	multiPmts.DoMultiPmts = MultiPmtSwitch.thevalue;
				     	if(!MultiPmtSwitch.thevalue){
				     		multiPmts.MultiPmts = [];
				     		mpView.visible = false;
				     		MultiplePmtHelper.SaveMultiPmts();
				     	}
				     	else{
				     		mpView.visible = true;
				     		MultiplePmtHelper.SaveMultiPmts(multiPmts);
				     	}
				     	
				     	//paymentPicker.setSelectedRow(0, 1, false);
				     	//paymentPicker.setSelectedRow(0, 0, false);
				     	_postlayoutevt(paymentPickerRows[0].title ,true);
				     	
				     	mpView.ToggleLabelVis(MultiPmtSwitch.thevalue);
				     });
				     
			         
			         MultiPmtView.add(MultiPmtLbl);
			         MultiPmtView.add(MultiPmtSwitch);
			         scrollableView.add(MultiPmtView);
			         
			         var mp = require('logic/MultiplePmtHelper');
			         var mpView = mp.GetView();	
			         mpView.visible = multiPmts && multiPmts.DoMultiPmts ? true : false;			
					 scrollableView.add(mpView);
	         	}
	         	catch(ex){
	         		Ti.API.debug('ex: ' + ex);
	         	}
	         	
	         }
	         
	         //////////////////////////////
	         //  	 		TIPS BEGIN   	 //
	         //////////////////////////////
	         var tipsView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:0
	         }));
	         	try{
		         	tipsView.top = ro.ui.relY(15);
		         	//tipsView.add(CC_TIPS.getTipView(tipsView));
		         	CC_TIPS.getTipView(tipsView);
		         	tipsView.hide();
		         	tipsView.visible = false;
		         }
		         catch(ex){
		         	Ti.API.debug('ex: ' + ex);
		         }
	
	         //////////////////////////////
	         //  	 		TIPS END    	 //
	         //////////////////////////////
	         scrollableView.add(tipsView);
	         scrollableView.add(payView);
	         
	         
	         
	         paymentPicker.addEventListener('change', function(e){
	         	var selRow = e.source.getSelectedRow(0);
	         	payView.removeAllChildren();
	         	
	         	var mPmts = MultiplePmtHelper.GetMultiPmts();
	         	newAddPmtBtnVis = true;
	         	
	         	tipsView.ResetTip(selRow.title.toLowerCase());
	         	
	         	switch(selRow.title.toLowerCase()){
	         		case "use existing card":
	         		    //toggleAddPaymentBtnVis(false);
	         		    if(cfg && cfg.AllowCCTips){
	         		    	tipsView.show();
		         			tipsView.visible = true;
	         		    }
	         		    else{
	         		    	tipsView.hide();
		         			tipsView.visible = false;
	         		    }
	         		    newAddPmtBtnVis = false;
	         			payView.add(GetSavedCreditView(mPmts, parentView.customAlertView));
	         			break;
	         		case "credit card":
	         			if(cfg && cfg.AllowCCTips){
	         		    	tipsView.show();
		         			tipsView.visible = true;
	         		    }
	         		    else{
	         		    	tipsView.hide();
		         			tipsView.visible = false;
	         		    }
	         			payView.add(GetCreditView(mPmts));
	         			break;
	         		case "gift":
	         			if(false && cfg && cfg.AllowGiftTips){
	         		    	tipsView.show();
		         			tipsView.visible = true;
	         		    }
	         		    else{
	         		    	tipsView.hide();
		         			tipsView.visible = false;
	         		    }
	         			payView.add(GetGiftView(mPmts));
	         			break;
	         		default:
	         			tipsView.hide();
		         		tipsView.visible = false;
	         			if(mPmts.DoMultiPmts)
	         				payView.add(GetNonCardView(mPmts, selRow.title));
	         			break;
	         	}
	         	
	         	toggleAddPmtBtnVis(newAddPmtBtnVis);
	         });
	         
	         reset = function(){
	         	paymentPicker.setSelectedRow(0, 1, false);
	         	paymentPicker.setSelectedRow(0, 0, false);
	         };
	         //reset();
	         
	         var toggleAddPmtBtnVis = function(visBln){
	         	btnUpdate.visible = visBln;
	         };
	         //btnUpdate.visible = false;
	         scrollableView.add(btnUpdate);
	      //mainView.add(mainView.customAlertView);
	      //return mainView;
	      //_postlayoutevt( ,true);
	      var _postlayoutevt = function(dispOrdPay, dontRemove){
	      	 if(!dontRemove)	parentView.removeEventListener('postlayout', _postlayoutevt);
	      	 //reset();
      	 	payView.removeAllChildren();
         	
         	var resetTitle;
         	if(dispOrdPay && dispOrdPay.length){
         		resetTitle = dispOrdPay;
         	}
         	else{
         		var selRow = paymentPickerRows[0];
         		resetTitle = selRow.title;
         	}
         	thePick.setPickText(resetTitle);
         	
         	var mPmts = MultiplePmtHelper.GetMultiPmts();
         	newAddPmtBtnVis = true;
         	
         	tipsView.ResetTip(resetTitle.toLowerCase());
         	
         	switch(resetTitle.toLowerCase()){
         		case "use existing card":
         		    //toggleAddPaymentBtnVis(false);
         		    if(cfg && cfg.AllowCCTips){
         		    	tipsView.show();
	         			tipsView.visible = true;
         		    }
         		    else{
         		    	tipsView.hide();
	         			tipsView.visible = false;
         		    }
         		    newAddPmtBtnVis = false;
         			payView.add(GetSavedCreditView(mPmts, parentView.customAlertView));
         			break;
         		case "credit card":
         			if(cfg && cfg.AllowCCTips){
         		    	tipsView.show();
	         			tipsView.visible = true;
         		    }
         		    else{
         		    	tipsView.hide();
	         			tipsView.visible = false;
         		    }
         			payView.add(GetCreditView(mPmts));
         			break;
         		case "gift":
         			if(false && cfg && cfg.AllowGiftTips){
         		    	tipsView.show();
	         			tipsView.visible = true;
         		    }
         		    else{
         		    	tipsView.hide();
	         			tipsView.visible = false;
         		    }
         			payView.add(GetGiftView(mPmts));
         			break;
         		default:
         			tipsView.hide();
	         		tipsView.visible = false;
         			if(mPmts.DoMultiPmts)
         				payView.add(GetNonCardView(mPmts, resetTitle));
         			break;
         	}
         	
         	toggleAddPmtBtnVis(newAddPmtBtnVis);
	      };
	      if(ro.isiOS){
	           parentView.addEventListener('postlayout', _postlayoutevt);
	           }
	           else{
	               var _androidPostLayoutEvt = function(e){
	                   thePick.removeEventListener('postlayout', _androidPostLayoutEvt);
	                   thePick.setFutureDate(1);
	                   thePick.setFutureDate(0);
	               };
	               thePick.addEventListener('postlayout', _androidPostLayoutEvt);
	           }
	      return parentView;
	   };
	   var GetChooseExistingCardView = function(){
	   	
	   };
	   var GetNonCardView = function(multiPay, dispOrdPayment){
	   	  var multiPayBln = multiPay.DoMultiPmts;
	   	  //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/cashForm.js');
	      var cashForm = require('formControls/cashForm');
	      var form = ro.forms.createForm({
	         style:ro.forms.STYLE_LABEL,
	         fields:cashForm.getCashForm({ShowAmountField:multiPayBln}),
	         settings:ro.ui.properties.myAccountView
	      });
	      
	      form.SubmitForm = function(){
	      	if(multiPayBln){
	      		 var values = ro.forms.getValues(form);
	      		 multiPay = MultiplePmtHelper.GetMultiPmts();
	      		 
		     	if(!values.payAmt) values.payAmt = 0.00;
		     	var paymentAmt = getDollarFormat(values.payAmt).toFixed(2);
		     	//Ti.API.debug('paymentAmt: ' + paymentAmt);
		     	if(!paymentAmt || getDollarFormat(paymentAmt) < .01 || getDollarFormat(paymentAmt) > getDollarFormat(getCurrentBalanceDue())){
		     		ro.ui.alert('Error', "The amount field must be in range 0.01 to " + getCurrentBalanceDue());
		            ro.ui.hideLoader();
		            try{
	                	form.focusField('payAmt');
	                }
	                catch(ex){
	                	Ti.API.debug('foxusField: ex: ' + ex);
	                }
		            return;
		     	}
	      		 
	      		var payObj = {
	      			isCredOrGift: false,
	      			PaymentAmt:values.payAmt,
	      			CardInfo:dispOrdPayment
	      		};
				   	  if(!multiPay.MultiPmts || !multiPay.MultiPmts.length){
				   	  	 multiPay.MultiPmts = [];
				   	  }
				   	  //PayerName":"c","OLExpMonth":3,"OLExpYear":"2018","OLSecCode":"111","CardInfo":"visa"
				   	  //
				   	  var combinedPmtsBln = false;
				   	  for(var i=0, iMax=multiPay.MultiPmts.length; i<iMax; i++){
				   	  	var mpObj = multiPay.MultiPmts[i];
				   	  	if(mpObj.CardInfo == dispOrdPayment){
				   	  		//Ti.API.debug('multiPay.MultiPmts[i].PaymentAmt: ' + multiPay.MultiPmts[i].PaymentAmt);
				   	  		//Ti.API.debug('payObj.PaymentAmt: ' + payObj.PaymentAmt);
				   	  		multiPay.MultiPmts[i].PaymentAmt = (getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + getDollarFormat(payObj.PaymentAmt)).toFixed(2);
				   	  		combinedPmtsBln = true;
				   	  		//Ti.API.debug('AFTER AFTER multiPay.MultiPmts[i].PaymentAmt: ' + multiPay.MultiPmts[i].PaymentAmt);
				   	  		break;
				   	  	}
				   	  }
				   	  
				   	  if(!combinedPmtsBln){
				   	  	//payObj.IsCredOrGift = true;
				   	  	multiPay.MultiPmts.push(payObj);
				   	  }
				   	  
				   	  
				   	  MultiplePmtHelper.SaveMultiPmts(multiPay);
				   	  //reset();
				   	  
				   	  if(MultiplePmtHelper.IsPaymentValid()){
				   	  	ro.ui.cartShowNext({ showing:'addPmt' });
				   	  }
				   	  else{
				   	  	ro.ui.cartShowNext({ addView:true, showing:'addPmt' });
				   	  }
				   	  
	      		 
	      	}
	      	else{
	      		
	      	}
	      	
	      };
	      
	      return form;
	   };
	   var GetGiftView = function(multiPay){
	   	  var multiPayBln = multiPay.DoMultiPmts;
	   	  //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/giftCardForm.js');
	      var gcForm = require('formControls/giftCardForm');
	      var form = ro.forms.createForm({
	         style:ro.forms.STYLE_LABEL,
	         fields:gcForm.getGcForm({ShowAmountField:multiPayBln}),
	         settings:ro.ui.properties.myAccountView
	      });
	      form.height = Ti.UI.SIZE;
	      form.top = ro.ui.relY(10);
		  var payControl = require('controls/paymentControl');
		  var regexVal = require('validation/regexValidation');
	
		  form.SubmitForm = function(ccTip){
	   	  	 ro.ui.showLoader();
	         //Ti.include('/validation/giftCardValidation.js');
	         var gcVal = require('validation/giftCardValidation');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = ro.forms.getValues(form);
	         
	         multiPay = MultiplePmtHelper.GetMultiPmts();
	         
	         //Ti.API.debug('values: ' + JSON.stringify(values));
	         var success = gcVal.gcValidate(values);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            
	            success = regexVal.regExValidate(values);
	            
	            
	            
	            if(success.value){
	            	values.Tip = ccTip || 0;
	            	if(!multiPayBln){
		        		var success = payControl.fillOrderObjGift(values);
		                  if(success){
		                     //ro.ui.cartShowNext({showing:'GiftC'});
		                     ro.ui.cartShowNext({showing:'addPmt'});
		                  }
		                  else{
		                     ro.ui.alert('Gift Card Error: ','Please try again');
		                     ro.ui.hideLoader();
		                  }
		                  return;
	            	}
	            	//“StoreID”: 1,
	                //“RevKey”: “test”,
	                //“CardNumber”: “123456789”
	            	var req = {
	            		StoreID:ro.app.Store.ID,
	            		RevKey:'test',
	            		CardNumber:values.giftCardNum
	            	};
	            	ro.dataservice.post(req, 'CheckBalance', function(response){
	            		 //Ti.API.debug('response: ' + JSON.stringify(response));
				         if(response){
				         	//response.Value = false;
				         	//response.Message = "O Noes";
				            if(response.Success){
				               //_callback();
				               try{
				               	  if(multiPayBln){
				               	  	var cardBal = getDollarFormat(response.Balance);
				               	  	if(cardBal < getDollarFormat(values.payAmt)){
				               	  		ro.ui.alert('Card Balance is ' + cardBal.toFixed(2));
				               	  		values.payAmt = cardBal;
				               	  		values.Tip = 0;
				               	  		ro.ui.hideLoader();
				               	  		return;
				               	  	}
				               	  	else if(cardBal < (getDollarFormat(values.payAmt) + getDollarFormat(values.Tip))){
					               	  	Ti.API.debug('b4b4b4values.Tip: ' + values.Tip);
				               	  		var oldTotal = getDollarFormat(values.payAmt) + getDollarFormat(values.Tip);
				               	  		Ti.API.debug('oldTotal: ' + oldTotal);
				               	  		var excessAmt = cardBal - oldTotal;
				               	  		Ti.API.debug('excessAmt: ' + excessAmt);
				               	  		
				               	  		
				               	  		//ro.ui.alert('Error', "The gift card ");
				               	  		
				               	  		
				               	  		values.Tip = getDollarFormat(values.Tip) - excessAmt;
				               	  		Ti.API.debug('b4b4b4values.Tip: ' + values.Tip);
				               	  	}
				               	  	
				               	  	multiPay = MultiplePmtHelper.GetMultiPmts();
						         	if(!values.payAmt) values.payAmt = 0.00;
						         	var paymentAmt = getDollarFormat(values.payAmt).toFixed(2);
						         	//Ti.API.debug('paymentAmt: ' + paymentAmt);
						         	if(!paymentAmt || getDollarFormat(paymentAmt) < .01 || getDollarFormat(paymentAmt) > getDollarFormat(getCurrentBalanceDue())){
						         		ro.ui.alert('Error', "The amount field must be in range 0.01 to " + getCurrentBalanceDue());
						                ro.ui.hideLoader();
						                try{
						                	form.focusField('payAmt');
						                }
						                catch(ex){
						                	Ti.API.debug('foxusField: ex: ' + ex);
						                }
						                return;
						         	}
						         	//payControl.fillOrderObjGift(values);
						         	//var newGCObj = ccControl.createCardObj(values);
						         	var payObj = payControl.getGiftCardObj(values);
							   	  	payObj.IsCredOrGift = true;
							   	  	multiPay.MultiPmts.push(payObj);
							   	  	//Ti.API.debug('made it here');
							   	  
							   	    MultiplePmtHelper.SaveMultiPmts(multiPay);
							   	    
							   	    if(MultiplePmtHelper.IsPaymentValid()){
							   	    	//Ti.API.debug('222made it here');
							   	  	   ro.ui.cartShowNext({ showing:'addPmt' });
							   	    }
							   	    else{
							   	    	//Ti.API.debug('333333made it here');
							   	    	ro.ui.cartShowNext({ addView:true, showing:'addPmt' });
							   	    }
				               	  	
				               	  	//if(cardBal > getDollarFormat())
				               	  	//payObj.IsCredOrGift = true;
				               	  }
				               	  else{
				               	  	/*var success = payControl.fillOrderObjGift(values);
					                  if(success){
					                     //ro.ui.cartShowNext({showing:'GiftC'});
					                     ro.ui.cartShowNext({showing:'addPmt'});
					                  }
					                  else{
					                     ro.ui.alert('Gift Card Error: ','Please try again');
					                     ro.ui.hideLoader();
					                  }*/
				               	  }
				               }
				               catch(ex){
				                  ro.ui.hideLoader();
				                  ro.ui.alert('GiftCard Error', 'Code:110' + ex);
				               }
				            }
				            else{
				            	ro.ui.alert('Error', response.Message);
				            	ro.ui.hideLoader();
				            }
				         }
				         else{
				         	ro.ui.alert('Error', 'There was a problem retrieving the card balance.');
				         	ro.ui.hideLoader();
				         }
				      });
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	   	  };   	  
	   	  return form;
	   };
	   var GetSavedCreditView = function(multiPay, HRushAlertView){
	   	
	   		  var multiPayBln = multiPay.DoMultiPmts;
	   		  var payControl = require('controls/paymentControl');
	   		  var ccControl = require('controls/ccControl');
	   		  var credCardVal = require('validation/creditcardValidation');
	   		  var regexVal = require('validation/regexValidation');
	   		  
		      var rs = {};
		      rs = ro.db.getAllCustCC(Ti.App.Username);
		      var CCinfo, cardObj, cardLastDigits, creditLbl;
	
			var form = Ti.UI.createScrollView(ro.combine(ro.ui.properties.contentsSmallView, {
	           top:ro.ui.relY(5),
	           layout:'vertical',
	           disableBounce:ro.isiOS ? true : false,
	   	  	   contentWidth:Ti.UI.FILL
	      	}));
		     /*var form = Ti.UI.createView({
		     	height:Ti.UI.SIZE,
		     	width:Ti.UI.FILL,
		     	layout:'vertical'
		     });
		      var defLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		         focusable:false
		      }));
		      defLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		         text:'DEFAULT CARD:',
		         font:{
		            fontSize:ro.ui.scaleFont(15, 0, 0),
		            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
		         }
		      })));
	
		      var otherLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		         //right:ro.ui.relX(10),
		         //left:ro.ui.relX(10),
		         top:ro.ui.halfContentsTop,
		         focusable:false
		      }));
		      otherLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		         text:'OTHER CARDS:',
		         font:{
		            fontSize:ro.ui.scaleFont(15, 0, 0),
		            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
		         }
		      })));
	
		     var defTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
		         top:0,
		         height:Ti.UI.SIZE,
		         right:0,
		         left:0
		      }));*/
	
		       try{
			      var cardRows = ccControl.nonDefaultCards(ro)*41;
			      if(cardRows > 164){
			         cardRows = 164;
			      }
			   }
			   catch(ex){
			   	  Ti.API.debug('ccControl.nonDefaultCard()-Exception: ' + ex);
			   	  cardRows = 164;
			   }
		      /* var otherTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
		          top:0,
		          height:Ti.UI.SIZE,
		          right:0,
		          left:0
		       }));
	
	
	
		      var noneTbl = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
		      	className:'noneRow',
		         height:ro.ui.relY(40),
		         backgroundColor:'white'
		      }));
		      var noneLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		         text:'No Saved Cards',
		         color:ro.ui.theme.contentsTextColor
		      }));
		      noneTbl.add(noneLbl);*/
		      
		      var defData = [], otherData = [];
		      var defCardCol = [];
	         var otherCardCol = [];
	
		      function vrfyBilling(card){
		      	var returnFlag = 0;
		      	if(ro.app.Store.Configuration.VerifyBilling === 1){
		      		if(!card.AVSZipCode){
		      			returnFlag = 1;
		      		}
		      	}
		      	else if(ro.app.Store.Configuration.VerifyBilling === 2){
		      		if(!card.AVSStreetNum){
		      			returnFlag = 2;
		      		}
		      	}
		      	return returnFlag;
		      }
		      function getBillingInfo(billingFlag, billCB){
		      	var popupTitle;
		      	if(billingFlag === 1){
		      		popupTitle = 'Please enter your Billing Zip Code:';
		      	}
		      	else if(billingFlag === 2){
		      		popupTitle = 'Please enter your Billing St.';
		      	}
		      	popupTitle = popupTitle.toUpperCase();
	
					ro.ca.showQuestion(popupTitle, function(button, verBilling){
			      	button.addEventListener('click', function(e){
			      		var billKey;
							var billInfoTest = {};
							if(billingFlag === 1){
								billKey = 'AVSZipCode';
								billInfoTest = {
									BillingZip:verBilling.value
								};
							}
							else if(billingFlag === 2){
								billKey = 'AVSStreetNum';
								billInfoTest = {
									BillingStreet:verBilling.value
								};
							}
	
							//Ti.include('/validation/creditcardValidation.js');
			         	if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
							var success = credCardVal.billingVerified(billInfoTest, billingFlag);
				         if(success.value){
				            //Ti.include('/validation/regexValidation.js');
				            success = regexVal.regExValidate(billInfoTest);
				            if(success.value){
				            	ro.ca.hide();
				            	if(billingFlag === 1){
				            		billCB({AVSZipCode:billInfoTest.BillingZip}, billKey);
				            	}
				            	else if(billingFlag === 2){
				            		billCB({AVSStreetNum:billInfoTest.BillingStreet}, billKey);
				            	}
				            }
				            else{
				               ro.ui.alert('Error', success.issues[0]);
				               ro.ui.hideLoader();
				            }
				         }
				         else{
				            ro.ui.alert('Error', success.issues[0]);
				            ro.ui.hideLoader();
				         }
				         ro.ca.hide();
			      	});
			      });
		      }
		      var ccLngth = rs?rs.length:0;
		      for(var i=0; i<ccLngth; i++){
		         /*CCinfo = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.newPayTxt, {
		            id:rs[i].rowid,
		            rowid:i,
		            className:'card',
		            cardObj:rs[i].CCInfo,
		            height:ro.ui.relY(40),
		            leftImage:'/images/' + rs[i].CCInfo.CardInfo.toLowerCase() + '.png'
		         }));
		         CCinfo.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		            //text:rs[i].CCInfo.CardInfo + '\t\t\t\t\t **-' + ccControl.getLastFour(rs[i].CCInfo.OLCardNum),
		            text:'**-' + ccControl.getLastFour(rs[i].CCInfo.OLCardNum),
		            id:rs[i].rowid,
		            rowid:i,
		            cardObj:rs[i].CCInfo,
		            color:ro.ui.theme.contentsTextColor
		         })));*/
				  //Ti.API.debug('rs[i]' + JSON.stringify(rs[i]));
			      	  var formattedString = rs[i].CCInfo.PayerName + '\n' + (rs[i].CCInfo.CardInfo.toUpperCase()) + "\txx-xxxx-" + ccControl.getLastFour(rs[i].CCInfo.OLCardNum);
	         		
	         		var ccObj = {
	         			customObj:{
	         				id:rs[i].rowid,
	         				cardObj:rs[i].CCInfo
	         			},
	         			formattedText:formattedString
	         		};
	         		CCinfo = ro.layout.getGenericRow(ccObj);
	         		/*CCinfo.addEventListener('click', function(e){
		               try{
		                  ro.ui.showLoader();
		                  ro.ui.settingsShowNext({addView:true, showing:'editCardView', rowid:e.source.id});
		               }
		               catch(ex){
		                  ro.ui.alert('editCreditCardList Error', 'Code:110' + ex);
		               }
		            });I*/
	         		
		         CCinfo.addEventListener('click', function(e){
		            try{
		               ro.ui.showLoader();
					   //Ti.API.debug('e: ' + JSON.stringify(e));
					   
		               var verifiedBilling = vrfyBilling(e.source.cardObj);
		               var ccTip = CC_TIPS.getTip();
	
		               if(verifiedBilling){
		               	getBillingInfo(verifiedBilling, function(billInfo, newKey){
		               		e.source.cardObj[newKey] = billInfo[newKey];
	
		               		var ccSuccess = ccControl.updateExistingCard(e.source.cardObj, e.source.id, ro);
		               		if(ccSuccess === -1){
			                   ro.ui.alert('Error: ', 'Card failed to update.');
			                   return;
			                }
	
								
							if(multiPayBln){
	               	   			var values = ro.forms.getValues(amtForm);
	               	   			multiPay = MultiplePmtHelper.GetMultiPmts();
	               	   			
					         	if(!values.payAmt) values.payAmt = 0.00;
					         	var paymentAmt = getDollarFormat(values.payAmt).toFixed(2);
					         	
					         	if(!paymentAmt || getDollarFormat(paymentAmt) < .01 || getDollarFormat(paymentAmt) > getDollarFormat(getCurrentBalanceDue())){
					         		ro.ui.alert('Error', "The amount field must be in range 0.01 to " + getCurrentBalanceDue());
					                ro.ui.hideLoader();
					                try{
					                	amtForm.focusField('payAmt');
					                }
					                catch(ex){
					                	Ti.API.debug('foxusField: ex: ' + ex);
					                }
					                return;
					         	}
					         	
					         	  if(!multiPay.MultiPmts || !multiPay.MultiPmts.length){
							   	  	 multiPay.MultiPmts = [];
							   	  }
							   	  
							   	  var payObj = payControl.getPaymentObj(e.source.cardObj);
								  payObj.Tip = ccTip || 0;
							   	  
							   	  payObj.PaymentAmt = paymentAmt;
							   	  
							   	  var combinedPmtsBln = false;
							   	  
							   	  for(var i=0, iMax=multiPay.MultiPmts.length; i<iMax; i++){
							   	  	var mpObj = multiPay.MultiPmts[i];
							   	  	if(mpObj.OLCardNum == payObj.OLCardNum 
							   	  		&& mpObj.PayerName == payObj.PayerName
							   	  		&& mpObj.OLExpMonth == payObj.OLExpMonth
							   	  		&& mpObj.OLExpYear == payObj.OLExpYear
							   	  		&& mpObj.OLSecCode == payObj.OLSecCode
							   	  		&& mpObj.CardInfo == payObj.CardInfo
							   	  	){
							   	  		multiPay.MultiPmts[i].PaymentAmt = (getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + getDollarFormat(payObj.PaymentAmt)).toFixed(2);
							   	  		multiPay.MultiPmts[i].Tip = (getDollarFormat(multiPay.MultiPmts[i].Tip) + getDollarFormat(payObj.Tip)).toFixed(2);
							   	  		combinedPmtsBln = true;
							   	  		break;
							   	  	}
							   	  }
							   	  
							   	  if(!combinedPmtsBln){
							   	  	payObj.IsCredOrGift = true;
							   	  	multiPay.MultiPmts.push(payObj);
							   	  }
							   	  
							   	  
							   	  MultiplePmtHelper.SaveMultiPmts(multiPay);
							   	  
							   	  if(MultiplePmtHelper.IsPaymentValid()){
							   	  	ro.ui.cartShowNext({ showing:'addPmt' });
							   	  }
							   	  else{
							   	  	ro.ui.cartShowNext({ addView:true, showing:'addPmt' });
							   	  }
					         	
					         	
		               	   }
		               	   else{
		               	   	   e.source.cardObj.Tip = ccTip || 0;
				               if(payControl.fillOrderObj(e.source.cardObj)){
				                  ro.ui.cartShowNext({showing:'addPmt'});
				               }
				               else{
				                  ro.ui.alert('Error accessing saved card: ','Please try again');
				                  ro.ui.hideLoader();
				               }
				           }
		               	});
		               	ro.ui.hideLoader();
		               }
		               else{
		               	   if(multiPayBln){
	               	   			var values = ro.forms.getValues(amtForm);
	               	   			multiPay = MultiplePmtHelper.GetMultiPmts();
	               	   			
					         	if(!values.payAmt) values.payAmt = 0.00;
					         	var paymentAmt = getDollarFormat(values.payAmt).toFixed(2);
					         	//Ti.API.debug('paymentAmt: ' + paymentAmt);
					         	if(!paymentAmt || getDollarFormat(paymentAmt) < .01 || getDollarFormat(paymentAmt) > getDollarFormat(getCurrentBalanceDue())){
					         		ro.ui.alert('Error', "The amount field must be in range 0.01 to " + getCurrentBalanceDue());
					                ro.ui.hideLoader();
					                try{
					                	amtForm.focusField('payAmt');
					                }
					                catch(ex){
					                	Ti.API.debug('foxusField: ex: ' + ex);
					                }
					                return;
					         	}
					         	
					         	  if(!multiPay.MultiPmts || !multiPay.MultiPmts.length){
							   	  	 multiPay.MultiPmts = [];
							   	  }
							   	  var payObj = payControl.getPaymentObj(e.source.cardObj);
								  payObj.Tip = ccTip || 0;
							   	  payObj.PaymentAmt = paymentAmt;
							   	  var combinedPmtsBln = false;
							   	  
							   	  for(var i=0, iMax=multiPay.MultiPmts.length; i<iMax; i++){
							   	  	var mpObj = multiPay.MultiPmts[i];
							   	  	if(mpObj.OLCardNum == payObj.OLCardNum 
							   	  		&& mpObj.PayerName == payObj.PayerName
							   	  		&& mpObj.OLExpMonth == payObj.OLExpMonth
							   	  		&& mpObj.OLExpYear == payObj.OLExpYear
							   	  		&& mpObj.OLSecCode == payObj.OLSecCode
							   	  		&& mpObj.CardInfo == payObj.CardInfo
							   	  	){
							   	  		multiPay.MultiPmts[i].PaymentAmt = (getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + getDollarFormat(payObj.PaymentAmt)).toFixed(2);
							   	  		multiPay.MultiPmts[i].Tip = (getDollarFormat(multiPay.MultiPmts[i].Tip) + getDollarFormat(payObj.Tip)).toFixed(2);
							   	  		combinedPmtsBln = true;
							   	  		break;
							   	  	}
							   	  }
							   	  
							   	  if(!combinedPmtsBln){
							   	  	payObj.IsCredOrGift = true;
							   	  	multiPay.MultiPmts.push(payObj);
							   	  }
							   	  
							   	  
							   	  MultiplePmtHelper.SaveMultiPmts(multiPay);
							   	  if(MultiplePmtHelper.IsPaymentValid()){
							   	  	ro.ui.cartShowNext({ showing:'addPmt' });
							   	  }
							   	  else{
							   	  	ro.ui.cartShowNext({ addView:true, showing:'addPmt' });
							   	  }
					         	
					         	
		               	   }
		               	   else{
		               	   	    e.source.cardObj.Tip = ccTip || 0;
			               	   	if(payControl.fillOrderObj(e.source.cardObj)){
				                  ro.ui.cartShowNext({ showing:'addPmt' });
				               }
				               else{
				                  ro.ui.alert('Error accessing saved card: ','Please try again');
				                  ro.ui.hideLoader();
				               }
		               	   }
			               
			            }
		            }
		            catch(ex){
		               ro.ui.alert('CardList-PaymentScreen Error', 'Code:110' + ex);
		            }
		         });
		         /*if(ccControl.getDefaultCard() == rs[i].rowid){
		            defData.push(CCinfo);
		         }
		         else{
		            otherData.push(CCinfo);
		         }*/
		        if(ccControl.getDefaultCard(ro) == rs[i].rowid){
		               defCardCol.push(CCinfo);
		            }
		            else{
		               otherCardCol.push(CCinfo);
		            }
		      }//endLoop
	
	
	
		     if(!ccControl.hasSavedCards(ro)){
	            form.add(noCardLbl);
	         }
	         else{
	         	var otherCardLength = 0;
	         	if(defCardCol && defCardCol.length){
	         		form.add(ro.layout.getGenericHdrRow("Default Credit Card"));
	         		form.add(defCardCol[0]);
	         	}
	         	if(otherCardCol && otherCardCol.length){
	         		otherCardLength = otherCardCol.length;
	         		form.add(ro.layout.getGenericHdrRow("Previously Used"));
	         	}
	         	for(var i=0, iMax=otherCardLength; i<iMax; i++){
	         		form.add(otherCardCol[i]);
	         	}
	         }
		    /* if(defData && defData.length){
		      	if(ro.isiOS){
		      		defTbl.appendRow(defData);
		      	}
		      	else{}
		      	
		         defTbl.setData(defData);
		      }
		      else{
		      	if(ro.isiOS){
		      		defTbl.appendRow(noneTbl);
		      	}
		      	else{
		      		defTbl.setData(noneTbl);
		      	}
		         
		      }
		      if(otherData && otherData.length){
		      	if(ro.isiOS){
		      		otherTbl.appendRow(otherData);
		      	}
		      	else{
		      		  otherTbl.setData(otherData);
		      	}
		       
		      }
		      else{
		      	if(ro.isiOS){
		      		otherTbl.appendRow(noneTbl);
		      	}
		      	else{
		      		otherTbl.setData(noneTbl);
		      	}
		         
		      }*/
	         /*form.add(defLblView);
		      form.add(defTbl);
	
		      form.add(otherLblView);
		      form.add(otherTbl);*/
		      /*form.add(Ti.UI.createView({
		      	height:ro.ui.relY(20),
		      	top:0,
		      	width:Ti.UI.FILL
		      }));*/
		     
		     var amtForm;
		     if(multiPayBln){
		     	//var forms = require('/revmobile/ui/forms');
			      //Ti.include('/formControls/creditCardForm.js');
			      var creditCardForm = require('formControls/creditCardForm');
			      amtForm = ro.forms.createForm({
			         style:ro.forms.STYLE_LABEL,
			         fields:creditCardForm.getCCForm({IsSavedCard:true, ShowAmountField:multiPayBln}),
			         settings:ro.ui.properties.myAccountView
			      });
			   	  amtForm.top = 0;
			   	  form.add(amtForm);
		     }
		     
	   	  
	   	  
	   	  form.SubmitForm = function(){
	   	  	
	   	  };
	   	  return form;
	   };
	   var GetCreditView = function(multiPay){
	   	  var payControl = require('controls/paymentControl');
	   	  var ccControl = require('controls/ccControl');
	   	  var credCardVal = require('validation/creditcardValidation');
	   	  var regexVal = require('validation/regexValidation');
	   	  var ccHelper = require('logic/creditCard');
	   	  
	   	  var multiPayBln = multiPay.DoMultiPmts;
	      var rs = ro.db.getAllCustCC(Ti.App.Username);
	      var hasSavedCC = rs.length;
	      
	      //GUEST ORDERS
	      var isGuest = false;
	      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	         isGuest = true;
	      }
	      //GUEST ORDERS
	
	      var billFlg = 0;
	      //Ti.API.debug('ro.app.Store: ' + JSON.stringify(ro.app.Store));
	      //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
	      //Ti.API.debug('ro.app.Store.Configuration.VerifyBilling: ' + ro.app.Store.Configuration.VerifyBilling);
	      if(ro.app.Store.Configuration.VerifyBilling){
	      	if(ro.app.Store.Configuration.VerifyBilling === 1){
	      		billFlg = 1;
	      	}
	      	else if(ro.app.Store.Configuration.VerifyBilling === 2){
	      		billFlg = 2;
	      	}
	      }
	
	      //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/creditCardForm.js');
	      var creditCardForm = require('formControls/creditCardForm');
	      var form = ro.forms.createForm({
	         style:ro.forms.STYLE_LABEL,
	         fields:creditCardForm.getCCForm({ShowAmountField:multiPayBln, save:/*false*/isGuest ? false : true, billingFlag:billFlg, noneDefault:true/*isGuest ? true : false*/}),
	         settings:ro.ui.properties.myAccountView
	      });
	      var curDate = new Date();
	      var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	      var curMonth = curDate.getMonth();
		  //form.fieldRefs['expMonth'].setLblText(monthList[curMonth]);
	      form.fieldRefs['expMonth'].setLblText(((curMonth+1) + " - " +  monthList[curMonth]), monthList[curMonth]);
	      //form.fieldRefs['expMonth'].text = monthList[curMonth];
	      //form.fieldRefs['expMonth'].setSelectedRow(0, curMonth, true);
	      /*try{
	      	form.fieldRefs['expMonth'].text = monthList[curMonth];
	      }
	      catch(ex){
	      	Ti.API.debug('catch: ' + ex);
	      }*/
	      curDate = null;
	      curMonth = null;
	      form.height = Ti.UI.SIZE;
	      form.top = ro.ui.relY(10);
	      
	      form.SubmitForm = function(ccTip){
	      	ro.ui.showLoader();
	      	
	      	
	      	
	         //Ti.include('/validation/creditcardValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var rowid;
	         var values = ro.forms.getValues(form);
	         
	         //Ti.API.debug('values: ' + JSON.stringify(values));
	         
	         var ccTypeStr = ccHelper.ValidateCC(values.ccNum);
	         //Ti.API.debug('ccTypeStr: ' + ccTypeStr);
	         
	         var temp = values;
	         temp.ccType = ccTypeStr;
	         values = temp;
	         temp = null;
	         //Ti.API.debug('values: ' + JSON.stringify(values));
	         
	         if(multiPayBln){
	         	multiPay = MultiplePmtHelper.GetMultiPmts();
	         	if(!values.payAmt) values.payAmt = 0.00;
	         	var paymentAmt = getDollarFormat(values.payAmt).toFixed(2);
	         	//Ti.API.debug('paymentAmt: ' + paymentAmt);
	         	if(!paymentAmt || getDollarFormat(paymentAmt) < .01 || getDollarFormat(paymentAmt) > getDollarFormat(getCurrentBalanceDue())){
	         		ro.ui.alert('Error', "The amount field must be in range 0.01 to " + getCurrentBalanceDue());
	                ro.ui.hideLoader();
	                try{
	                	form.focusField('payAmt');
	                }
	                catch(ex){
	                	Ti.API.debug('foxusField: ex: ' + ex);
	                }
	                return;
	         	}
	         }
	         
	         var success = credCardVal.credCardValidate(ro.combine(values, {addNew:values.ccSave}), rs);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               
	               var newCCObj = ccControl.createCardObj(values);
	               newCCObj.Tip = ccTip;
	               if(values.ccSave){
	                  if(ccControl.hasSavedCards(ro)){
	                     rowid = ccControl.saveNewCard(newCCObj, ro);
	                  }
	                  else{
	                     ccControl.setDefaultCard(ccControl.saveNewCard(newCCObj, ro));
	                  }
	               }
	               
				   if(multiPayBln){
				   	  var payObj = payControl.getPaymentObj(newCCObj);
				   	  if(!multiPay.MultiPmts || !multiPay.MultiPmts.length){
				   	  	 multiPay.MultiPmts = [];
				   	  }
				   	  var combinedPmtsBln = false;
				   	  
				   	  for(var i=0, iMax=multiPay.MultiPmts.length; i<iMax; i++){
				   	  	var mpObj = multiPay.MultiPmts[i];
				   	  	if(mpObj.OLCardNum == payObj.OLCardNum 
				   	  		&& mpObj.PayerName == payObj.PayerName
				   	  		&& mpObj.OLExpMonth == payObj.OLExpMonth
				   	  		&& mpObj.OLExpYear == payObj.OLExpYear
				   	  		&& mpObj.OLSecCode == payObj.OLSecCode
				   	  		&& mpObj.CardInfo == payObj.CardInfo
				   	  	){
				   	  		multiPay.MultiPmts[i].PaymentAmt = (getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + getDollarFormat(payObj.PaymentAmt)).toFixed(2);
				   	  		multiPay.MultiPmts[i].Tip = (getDollarFormat(multiPay.MultiPmts[i].Tip) + getDollarFormat(payObj.Tip)).toFixed(2);
				   	  		combinedPmtsBln = true;
				   	  		break;
				   	  	}
				   	  }
				   	  
				   	  
				   	  
				   	  if(!combinedPmtsBln){
				   	  	payObj.IsCredOrGift = true;
				   	  	
				   	  	multiPay.MultiPmts.push(payObj);
				   	  }
				   	  
				   	  
				   	  MultiplePmtHelper.SaveMultiPmts(multiPay);
				   	  if(MultiplePmtHelper.IsPaymentValid()){
				   	  	ro.ui.cartShowNext({ showing:'addPmt' });
				   	  }
				   	  else{
				   	  	ro.ui.cartShowNext({ addView:true, showing:'addPmt' });
				   	  }
				   }
				   else{
				   	  if(payControl.fillOrderObj(newCCObj)){
		                  ro.ui.cartShowNext({ showing:'addPmt' });
		               }
		               else{
		                  ro.ui.alert('Error: ','Please try again');
		                  ro.ui.hideLoader();
		               }
				   }
	            }
	            else{
	               ro.ui.alert('Error', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      };
	      
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Card Details", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:2
			});
	      
	      return form;
	   };
	   var getCurrentBalanceDue = function(){
	   	  //var MultiplePmtHelper = require('logic/MultiplePmtHelper');
	   	  var currentBalanceDue = Ti.App.OrderObj.ActiveTotal;
	   	  var multiPmts = MultiplePmtHelper.GetMultiPmts();
	   	  //Ti.API.debug('multiPmts: ' + JSON.stringify(multiPmts));
	   	  for(var i=0, iMax=multiPmts.MultiPmts && multiPmts.MultiPmts.length ? multiPmts.MultiPmts.length : 0; i<iMax; i++){
	   	  	 currentBalanceDue -= multiPmts.MultiPmts[i].PaymentAmt;
	   	  }
	   	  
	   	  //Ti.API.debug('getDollarFormat(currentBalanceDue).toFixed(2): ' + getDollarFormat(currentBalanceDue).toFixed(2));
	   	  return getDollarFormat(currentBalanceDue).toFixed(2);
	   };
	};
	return {
		addpaymentview:addpaymentview
	};
}();
module.exports = ADDPAYMENTVIEW;