var NEWCREDITCARDVIEW = function(){
	var newcreditcardview = function(ro){
	   ro.ui.createNewCreditCardView = function(_args){
	      var rs = ro.db.getAllCustCC(Ti.App.Username);
	
	      //var forms = require('/revmobile/ui/forms');
	      var forms = ro.forms;
	      var creditCardForm = require('formControls/creditCardForm');
	      var ccHelper = require('logic/creditCard');
	      var regexVal = require('validation/regexValidation');
	      var ccControl = require('controls/ccControl');
	      var credCardVal = require('validation/creditcardValidation');
	      
	      //Ti.include('/formControls/creditCardForm.js');
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:creditCardForm.getCCForm({save:false, billingFlag:0}),
	         settings:ro.ui.properties.myAccountView
	      });
	      var curDate = new Date();
	      var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	      var curMonth = curDate.getMonth();
	
	      //form.fieldRefs['expMonth'].setSelectedRow(0, curMonth, true);
	      //setLblText
	      //setLblText
	      form.fieldRefs['expMonth'].setLblText(((curMonth+1) + " - " +  monthList[curMonth]), monthList[curMonth]);
	      //form.fieldRefs['expMonth'].text = monthList[curMonth];
	      
	      //Ti.include('/logic/creditCard.js');
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'newcc', hid:'addCardBtn'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      
	      //var resetBtn = layoutHelper.getRightBtn('CLEAR');
	      var resetBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      resetBtn.addEventListener('click', function(e){
	         ro.GlobalPicker.hidePicker();
	         form.clearFields();
	         
	      });
	      //resetBtn.fireEvent('click');
	
	      var btnBack = layoutHelper.getBackBtn('CREDIT CARDS');
	      btnBack.addEventListener('click', function(e){ 
	          ro.GlobalPicker.hidePicker();
	          ro.ui.settingsShowNext({showing:'addCardBtn'});
	      });
	      navBar.add(btnBack);
	      navBar.add(resetBtn);
	
	      var btnUpdate = layoutHelper.getBigButton('Save');
	      var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         //Ti.include('/validation/creditcardValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         Ti.API.debug('values: ' + JSON.stringify(values));
	         
	         var ccTypeStr = ccHelper.ValidateCC(values.ccNum);
	         Ti.API.debug('ccTypeStr: ' + ccTypeStr);
	         
	         var temp = values;
	         temp.ccType = ccTypeStr;
	         values = temp;
	         temp = null;
	         Ti.API.debug('values: ' + JSON.stringify(values));
	         var success = credCardVal.credCardValidate(ro.combine(values, {addNew:1}), rs);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               //Ti.include('/controls/ccControl.js');
	               var rowid = ccControl.saveNewCard(ccControl.createCardObj(values), ro);
	               if(rowid != -1){
	                  if(values.ccDefault){
	                     ccControl.setDefaultCard(rowid, ro);
	                  }
	                  ro.ui.alert('Success:', 'Credit Card has been saved!');
	                  ro.ui.settingsShowNext({showing:'addCardBtn'});
	               }
	               else{
	                  ro.ui.alert('Error: ', 'Card was not saved');
	                  ro.ui.hideLoader();
	               }
	            }
	            else{
	               ro.ui.alert('Error', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Add Credit Card"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Card Details", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:2
			});
	      
	      mainView.add(form);
	      return mainView;
	   };
	   /*var removeDashes = function(creditNum){
	   	  var newVal = null;
	   	  newVal = creditNum.replace(/-/g,'');
	   	  return newVal;
	   };*/
	   /*var ccChangeEvt = function(creditNumber, type){
		   
		   //var trimmedStr = creditField.value.replace(/-/g,'');
		   var trimmedStr = creditNumber.replace(/-/g,'');
		   
		   //Ti.API.debug('creditField.maxLength: ' + creditField.maxLength);
		   //if(creditField.maxLength === 19){
		   var maxLength = 19;
		   if(type !== 'amex'){
		      return ccDashes(trimmedStr, maxLength);
		   }
		   else{
		   	  maxLength = 17;
		      return amexDashes(trimmedStr, maxLength);
		   }
		};*/
		/*var ccDashes = function(value, maxLength){
		   Ti.API.debug('ccDashes - value: ' + value);
		
		   var length = value.length;
		   var newVal = value;
		   var totalLength = maxLength;
		   
		   newVal = value.substr(0,4) + '-' + value.substr(4,4) + '-' + value.substr(8,4) + '-' + value.substr(12);
		   return newVal;
		};*/
		/*var amexDashes = function(value, maxLength){
		   Ti.API.debug('amexDashes - value: ' + value);
		
		   var length = value.length;
		   var newVal = value;
	
		   var totalLength = maxLength;//3 for the hyphens
	
		   newVal = value.substr(0,4) + '-' + value.substr(4,6) + '-' + value.substr(10);
		   return newVal;
		};*/
	};
	return {
		newcreditcardview:newcreditcardview
	};
}();
module.exports = NEWCREDITCARDVIEW;