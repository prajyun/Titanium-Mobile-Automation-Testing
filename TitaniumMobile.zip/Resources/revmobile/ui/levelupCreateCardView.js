(function(){
   ro.ui.getLoyaltiesCreateCardView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesCreateCard', 'LEVELUP', layoutHelper.getLogoutBtn(), null, false);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      
      var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);
      
      var forms = require('/revmobile/ui/forms');
      Ti.include('/formControls/creditCardForm.js');
      var form = forms.createForm({
         style:forms.STYLE_LABEL,
         fields:creditCardForm.getCCForm({save:false, billingFlag:1, noneDefault:true}),
         settings:ro.ui.properties.myAccountView
      });
      var curDate = new Date();
      var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      var curMonth = curDate.getMonth();

      form.fieldRefs['expMonth'].setSelectedRow(0, curMonth, true);
      
      form.fieldRefs['ccType'].setSelectedRow(0, 0, true);
      form.fieldRefs['ccType'].addEventListener('change', function(e){
         if(form.fieldRefs['ccType'].getSelectedRow(0).title.toUpperCase() === 'AMEX'){
            form.fieldRefs['ccNum'].maxLength = 17;
         }
         else{
            form.fieldRefs['ccNum'].maxLength = 19;
         }
      });

      var btnUpdate = layoutHelper.getBigButton('SAVE');
      btnUpdate.addEventListener('click', function(e){
         ro.ui.showLoader();
         Ti.include('/validation/creditcardValidation.js');
         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
         
         var values = forms.getValues(form);
         var success = credCardVal.LUCredCardValidate(values);
         
         if(success.value){
            Ti.include('/validation/regexValidation.js');
            success = regexVal.regExValidate(values);
            if(success.value){
               
               var finishedEncryptEvent = function(e){
                  mainView.remove(invisWebView);
                  invisWebView.release();
                  var req = {
                     credit_card:{
                        encrypted_cvv:e.enc_cvv,
                        encrypted_expiration_month:e.enc_month,
                        encrypted_expiration_year:e.enc_year,
                        encrypted_number:e.enc_number,
                        postal_code:values.BillingZip
                     }
                  };
                  
                  levelUp.createCreditCard(req, function(e){
                     ro.ui.settingsShowNext({showing:mainView.hid});
                     ro.ui.hideLoader();
                  });
                  Ti.App.removeEventListener('finishedEncrypting', finishedEncryptEvent);
               };
               Ti.App.addEventListener('finishedEncrypting', finishedEncryptEvent);
               
               var invisWebView = Ti.UI.createWebView({
                  url:'/levelUp/example/index.html',
                  height:0,
                  width:0
               });
               invisWebView.addEventListener('load', function(e){
                  Ti.App.fireEvent('encryptVals', {
                     key:levelUp.getEncryptKey(),
                     cvv:values.cvvNum,
                     month:(monthList.indexOf(values.expMonth)+1),
                     year:values.expYear,
                     num:values.ccNum
                  });
               });
               mainView.add(invisWebView);
            }
            else{
               ro.ui.alert('Error', success.issues[0]);
               ro.ui.hideLoader();
            }
         }
         else{
            ro.ui.alert('Error', success.issues[0]);
            ro.ui.hideLoader();
         }
      });
      mainView.add(btnUpdate);
      mainView.add(form);
      return mainView;
   };
})();