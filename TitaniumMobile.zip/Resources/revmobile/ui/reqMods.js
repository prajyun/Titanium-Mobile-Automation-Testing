try {
	var reqModsArray = [];
	var reqModsData = [];
	itemObj.ReqMods = [];
	var halfStatus = 0;
	
	var optionsData = [];
	var optionsDialog = Ti.UI.createOptionDialog({
		options: null,
		buttonNames: ['OK']
	});
	var optionsView = Ti.UI.createView();
	var optionsTbl = Ti.UI.createTableView({
		backgroundColor: 'transparent',
		separatorColor: ro.ui.theme.separatorColor,
		row: null,
		name: 'optionsTbl'
	});
	optionsView.add(optionsTbl);
	
	function sortMods(mod1, mod2){
		if (mod1.isPreselected && !mod2.isPreselected) {
			return -1;
		}
		else 
			if (!mod1.isPreselected && mod2.isPreselected) {
				return 1;
			}
		return 0;
	}
	
	function extraClick(e){
		if (e.source.text) {
			if (e.source.text == 'x 2') {
				e.source.text = 'x 1';
				e.source.parent.qty = 1;
				setMods(e.source.parent.name, e.source.parent.index, e.source.parent.isPreselected, 1);
			}
			else {
				e.source.text = 'x 2';
				e.source.parent.qty = 2;
				setMods(e.source.parent.name, e.source.parent.index, e.source.parent.isPreselected, 2);
			}
		}
	}
	
	function reqModClick(e){
		if (e.button) {
			try {
				var tblView = e.source.androidView.children[0];
				var row = tblView.row;
				var view = row.children[2];
				var lblHalf = row.children[1];
				var noneIndex;
				var remModIndex;
				if (group.AllowHalf) {
					noneIndex = 3;
					remModIndex = 3;
					for (var i = 0; i < group.Mods.length; i++) {
						if (group.Mods[i].Name == row.name) {
							if (group.Mods[i].NoHalf) {
								noneIndex = 1;
							}
							break;
						}
					}
				}
				else {
					noneIndex = 1;
					remModIndex = 1;
				}
				if (row.index == noneIndex) {
					view.visible = false;
					view.qty = 0;
				}
				else {
					if (!view.visible) {
						view.visible = true;
						view.qty = 1;
						view.children[0].text = 'x 1';
					}
				}
				lblHalf.text = row.halfOptions[row.index].title;
				setMods(row.name, (view.qty > 0 ? row.index : remModIndex), row.isPreselected, view.qty);
			} 
			catch (ex) {
				ro.ui.alert('req mod click', ex);
			}
		}
		
	}
	
	for (var i = 0; i < itemSelected.ReqMods.length; i++) {
	
		var title;
		for (var j = 0; j < Menu.ModCategories.length; j++) {
			if (Menu.ModCategories[j].Key == itemSelected.ReqMods[i]) {
				title = Menu.ModCategories[j].Msg;
				break;
			}
		}
		var modsView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
		   id:i,
		   name:'Step ' + step++ + ': ' + title,
		   color: ro.ui.theme.grpItemColor
		}));
		var modsTbl = Ti.UI.createTableView({
			backgroundColor: 'transparent',
			separatorColor: ro.ui.theme.separatorColor,
			width:ro.ui.relY(280),
			height:ro.ui.relY(280),
			//style: Ti.UI.iPhone.TableViewStyle.PLAIN,
			type: 'table',
			clickable: true
		});
		
		
		for (var j = 0; j < group.Mods.length; j++) {
			var idx = 1;
			var isPreselected = false;
			var halfOptions = [];
			if (group.Mods[j].ModCatKey == itemSelected.ReqMods[i]) {
			
				if (itemSelected.PreMods) {
					for (var k = 0; k < itemSelected.PreMods.length; k++) {
						if (itemSelected.PreMods[k].Name == group.Mods[j].Name) {
							idx = 0;
							isPreselected = true;
							break;
						}
					}
				}
				
				var enable;
				halfOptions[0] = Ti.UI.createTableViewRow({
					title: 'Whole',
					className: 'halfStatus'
				});
				if (group.AllowHalf) {
					enable = (group.Mods[j].NoHalf ? false : true);
					if (enable) {
						if (idx != 0) {
							idx = 3;
						}
						halfOptions[1] = Ti.UI.createTableViewRow({
							title: 'Half-One',
							className: 'halfStatus'
						});
						halfOptions[2] = Ti.UI.createTableViewRow({
							title: 'Half-Two',
							className: 'halfStatus'
						});
					}
				}
				if (halfOptions.length > 1) {
					halfOptions[3] = Ti.UI.createTableViewRow({
						title: 'None',
						className: 'halfStatus'
					});
				}
				else {
					halfOptions[1] = Ti.UI.createTableViewRow({
						title: 'None',
						className: 'halfStatus'
					});
				}
				
				var row = Ti.UI.createTableViewRow({
					className: 'mods' + idx,
					height: ro.ui.relY(45),
					name: group.Mods[j].Name,
					index: idx,
					clickable: true,
					halfOptions: halfOptions,
					isPreselected: isPreselected,
					type: 'row',
					backgroundSelectedColor:ro.ui.theme.tblRowSelected
				});
				
				var l = Ti.UI.createLabel({
					left: ro.ui.relX(5),
					top: ro.ui.relY(10),
					height: ro.ui.relY(20),
					font: {
						fontSize: ro.ui.scaleFont(12,0,0),
						fontWeight: 'bold'
					},
					color: ro.ui.theme.textColor,
					text: group.Mods[j].ReceiptName,
					clickable: true,
					type: 'label',
					width: ro.ui.relX(120)
				});
				var lblHalfStatus = Ti.UI.createLabel({
					right: ro.ui.relX(60),
					top: ro.ui.relY(10),
					height: ro.ui.relY(20),
					font: {
						fontSize: ro.ui.scaleFont(11,0,0),
						fontWeight: 'bold'
					},
					color: ro.ui.theme.textColor,
					text: halfOptions[idx].title,
					type: 'label',
					clickable: true,
					textAlign: 'left'
				});
				var extraLbl = Ti.UI.createLabel({
					height: ro.ui.relY(18),
					font: {
						fontSize: ro.ui.scaleFont(12,0,0),
						fontWeight: 'bold'
					},
					color: '#fff',
					text: 'x 1',
					width: ro.ui.relX(18),
					textAlign: 'center',
					clickable: false
				});
				
				var extraView = Ti.UI.createView({
					top: ro.ui.relY(5),
					right: ro.ui.relX(15),
					width: ro.ui.relX(30),
					height: ro.ui.relY(30),
					visible: (isPreselected ? true : false),
					name: group.Mods[j].Name,
					isPreselected: isPreselected,
					backgroundImage: '../images/extra.png',
					qty: (isPreselected ? 1 : 0),
					clickable: false
				});
				extraView.addEventListener('click', extraClick);
				extraView.add(extraLbl);
				row.add(l);
				row.add(lblHalfStatus);
				row.add(extraView);
				reqModsData[j] = row;
			}
		}
		reqModsData.sort(sortMods);
		modsTbl.data = reqModsData;
		modsView.add(modsTbl);
		reqModsArray.push(modsView);
	}
	
	optionsDialog.addEventListener('click', reqModClick);
	
	optionsTbl.addEventListener('click', function(e){
		try {
			for (var i = 0; i < optionsData.length; i++) {
				if (i != e.index) {
					optionsData[i].hasCheck = false;
				}
			};
			e.row.hasCheck = true;
			e.source.row.index = e.index;
			optionsTbl.data = optionsData;
		} 
		catch (ex) {
			ro.ui.alert('optionsTblClick', ex);
		}
	});
	
	modsTbl.addEventListener('click', function(e){
		try {
			var row;
			if (e.source.clickable) {
				switch (e.source.type) {
					case 'row':
						row = e.source;
						break;
					case 'label':
						row = e.source.parent;
						break;
					case 'table':
						row = e.row;
						break;
				}
				var modName = row.name;
				var index = row.index;
				for (var i = 0; i < row.halfOptions.length; i++) {
					if (i != index) {
						row.halfOptions[i].hasCheck = false;
					}
				};
				row.halfOptions[index].hasCheck = true;
				optionsData = row.halfOptions;
				optionsTbl.data = optionsData;
				optionsTbl.row = row;
				optionsDialog.androidView = optionsView;
				optionsDialog.show();
			}
		} 
		catch (ex) {
			ro.ui.alert('modsTblClick', ex);
		}
	});
	for (var i = 0; i < reqModsArray.length; i++) {
	
		scrollViewData.push(reqModsArray[i]);
	}
}
catch(ex){
	ro.ui.alert('Modifiers','CODE 101');
}

