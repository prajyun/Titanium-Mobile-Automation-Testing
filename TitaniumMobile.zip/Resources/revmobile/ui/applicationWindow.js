var APPWINDOW = function() {
	var appwindow = function(ro) {
        
		var hasForgotPasswordDigest = !ro.isiOS &&
										Ti.Android.currentActivity &&
										Ti.Android.currentActivity.intent.data &&
										Ti.Android.currentActivity.intent.data !== null &&
										Ti.Android.currentActivity.intent.data.includes('digest');
        
		var checkiOSDeepLink = function() {
			if (ro.isiOS) {
				try {					
					var args = Ti.App.getArguments();
					var deepLinkArgs = null;
					var digest = null;
					if (args) {
						if (args.url) {
							digest = args.url;
						}
						//Ti.API.info('*Digest ' + digest);
						if (args.UIApplicationLaunchOptionsUserActivityDictionaryKey) {
							if (args.UIApplicationLaunchOptionsUserActivityDictionaryKey.UIApplicationLaunchOptionsUserActivityKey && args.UIApplicationLaunchOptionsUserActivityDictionaryKey.UIApplicationLaunchOptionsUserActivityKey.webpageURL && args.UIApplicationLaunchOptionsUserActivityDictionaryKey.UIApplicationLaunchOptionsUserActivityKey.webpageURL.length) {
								deepLinkArgs = args.UIApplicationLaunchOptionsUserActivityDictionaryKey.UIApplicationLaunchOptionsUserActivityKey.webpageURL;
							}
						}
						//Ti.API.info('*Deeplink args ' + deepLinkArgs);
					}

					if (digest) {
						var splitDigest = digest.split("?");
						if (splitDigest && splitDigest.length && splitDigest.length > 1) {
							var fullDigest = splitDigest[1].split("=");
							if (fullDigest && fullDigest.length && fullDigest.length > 1) {
								if (fullDigest[0].toLowerCase() == 'digest') {
									hasForgotPasswordDigest = true;
									//This section is new.*************
									Ti.App.Properties.setString('digest', fullDigest[1]);
									setTimeout(function (e) {
										ro.ui.showPassRecovery(true);
									}, 500);
								} else if (fullDigest[0].toLowerCase() == 'emailtoken') {
									setTimeout(function (e) {
										verifyEmail(fullDigest[1]);
									}, 500);
                                }
							}
						}
					} else if (deepLinkArgs) {
						var splitDigest = deepLinkArgs.split("?");
						if (splitDigest && splitDigest.length && splitDigest.length > 1) {
							var fullDigest = splitDigest[1].split("=");
							if (fullDigest && fullDigest.length && fullDigest.length > 1) {
								if (fullDigest[0].toLowerCase() == 'promocode') {
									var finalDigest = decodeURIComponent(fullDigest[1].split("&")[0]).trim();
									Ti.App.Properties.setString('promoDigest', finalDigest);
								} else if (fullDigest[0].toLowerCase() == 'digest') {
									hasForgotPasswordDigest = true;
									Ti.App.Properties.setString('digest', fullDigest[1]);
									setTimeout(function (e) {
										ro.ui.showPassRecovery(true);
									}, 500);
								} else if (fullDigest[0].toLowerCase() == 'emailtoken') {
									setTimeout(function (e) {
										verifyEmail(fullDigest[1]);
									}, 500);
								}
							}
						}
					}
				} catch(ex) {
					Ti.API.info('digest - Ex: ' + ex);
					//alert('digest - Ex: ' + ex);
				}
			}
		};
        
		var platformWidth = ro.ui.displayCaps.platformWidth,
		    platformHeight = ro.ui.displayCaps.platformHeight,
		    tabBarHeight = ro.ui.relY(64),
		    tabHeight = ro.ui.relY(54);//45
		    
		var selectedTabIdx = 0,
		    adView = null,
		    newAccView = null,
		    kioskConfigView = null,
		    rewardsView,
		    passWordRecovery = null,
		    digestBool = false,
		    tabs = [],
		    appFilmStrip = null,
		    filmStripAdded = false;
		var tabWidth,
		    tabParent,
		    tabView,
		    tab,
		    tabNum = 3;
		var honeycombBln = false;
		ro.app.currentView = 'none';
		var NEWACCOUNTVIEW;

		ro.ui.createApplicationWindow = function(_args) {
			try {
                ro.utils.removeProp('spclInst');
                ro.utils.removeProp('delNote');
				ro.utils.removeProp('gateCode');
                ro.utils.removeProp('futureOrder');
                ro.utils.removeProp('vhclInfo');

				function isIphoneX() {
					Ti.API.debug('Ti.Platform.displayCaps.platformWidth: ' + Ti.Platform.displayCaps.platformWidth);
					Ti.API.debug('Ti.Platform.displayCaps.platformHeight: ' + Ti.Platform.displayCaps.platformHeight);
					Ti.API.debug('Ti.Platform.displayCaps.logicalDensityFactor: ' + Ti.Platform.displayCaps.logicalDensityFactor);
					return ro.isiOS && (Ti.Platform.displayCaps.platformWidth >= 375 && Ti.Platform.displayCaps.platformHeight >= 812 && (Ti.Platform.displayCaps.logicalDensityFactor >= 2));
				}
				
				if(ro.isiphonex){
					var win = Ti.UI.createWindow(ro.combine(ro.ui.properties.Window, {
						bottom: 0,
						exitOnClose: true
					}));
					var fullWin = Ti.UI.createView({
						top:0,
						left:0,
						right:0,
						bottom:ro.ui.relX(20)
						//height:ro.ui.displayCaps.platformHeight - ro.ui.relX(20)
					});
					var bottomWin = Ti.UI.createView({
						height:ro.ui.relY(20),
						width:Ti.UI.FILL,
						bottom:0
					});
					win.add(fullWin);
					win.add(bottomWin);
				}
				else{
					var win = Ti.UI.createWindow(ro.combine(ro.ui.properties.Window, {
						bottom: 0,
						exitOnClose: true
					}));
				}
				

				//ro.windowpopup = getwindowpopup;

				function getwindowpopup() {
					var windowpopup = Ti.UI.createView({
						height: Ti.UI.FILL,
						width: Ti.UI.FILL,
						visible: false,
						zIndex: 5,
						KeepShowing:false
					});

					windowpopup.clearWindowpopup = function() {
						windowpopup.removeAllChildren();
					};
					windowpopup.setWindowpopup = function(popup, _cb) {
						windowpopup.add(popup);
						if (!ro.isiOS)
							Ti.UI.Android.hideSoftKeyboard();
						windowpopup.visible = true;
						
						if(popup.KeepShowing){
						    windowpopup.KeepShowing = true;
						}
						
						windowpopup.show();

						/*if(_cb){
						 _cb();
						 }*/
					};
					/*ro.showWindowpopup = function(){
					 win.windowpopup.show();
					 };*/
					windowpopup.hideWindowpopup = function(removeKeepShowing) {
						var wasVisible = windowpopup.visible ? true : false;
						if(removeKeepShowing){
						    windowpopup.KeepShowing = false;
						}
						if(windowpopup && !windowpopup.KeepShowing){
						    windowpopup.hide();
						}
						
						return wasVisible;
					};
					return windowpopup;
				}


				ro.windowpopup = getwindowpopup();
				win.add(ro.windowpopup);
				//win.add(win.windowpopup);

				//ro.windowpopup =

				if (true || ro.isiOS) {
					function getPickerView() {
						var hiddenValue = ro.isiOS ? -200 : ro.ui.relY(-200);
						var height = ro.isiOS ? 200 : ro.ui.relY(200);
						var slide_in = Ti.UI.createAnimation({
							bottom: 0
						});
						var slide_out = Ti.UI.createAnimation({
							bottom: hiddenValue
						});
						var pickerView = Ti.UI.createView({
							backgroundColor: '#e3e3e3',
							width: Ti.UI.FILL,
							isCurrentlyShowing: false,
							bottom: hiddenValue,
							height: height,
							defaultHeight: height,
							zIndex: 5
						});
						if (!ro.isiOS) {
							pickerView.layout = 'vertical';
						}

						var getToolbar = ro.isiOS ? function() {
							var picNext = Ti.UI.createButton({
								title: 'Next',
								style: Ti.UI.iOS.SystemButtonStyle.DONE,
								id: 1
							});
							var picDone = Ti.UI.createButton({
								title: 'Done',
								style: Ti.UI.iOS.SystemButtonStyle.DONE,
								id: 0
							});

							var picSpacer = Ti.UI.createButton({
								systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
							});

							var picToolbar = Ti.UI.createToolbar({
								top: 0,
								items: [ picSpacer, picDone],
								zIndex: 2,
								width: Ti.UI.FILL
							});

							picDone.addEventListener('click', function(e) {
								//Ti.API.debug('done clicked');
								//Ti.API.debug('e.source.id: ' + e.source.id);
								//Ti.API.debug('e: ' + JSON.stringify(e));
								switch (e.source.id) {
									case 0:
										pickerView.hidePicker();
										break;
								}

							});

							return picToolbar;
						} : function() {
							var picToolbar = Ti.UI.createView({
								width: Ti.UI.FILL,
								height: ro.ui.relY(40),
								top: 0//,
								//backgroundColor:'green'
							});

							var picNext = Ti.UI.createButton({
								title: 'Next',
								//style : Ti.UI.iOS.SystemButtonStyle.DONE,
								id: 1
							});
							var picDone = Ti.UI.createButton({
								title: 'Done',
								//style : Ti.UI.iOS.SystemButtonStyle.DONE,
								id: 0,
								left: ro.ui.relX(5)
							});

							picToolbar.add(picDone);

							picToolbar.addEventListener('click', function() {
								pickerView.hidePicker();
							});
							return picToolbar;
						};

						pickerView.setPicker = function(picker, customToolbar) {
							pickerView.removeAllChildren();
							if (customToolbar) {
								pickerView.add(customToolbar);
							}
							else {
								pickerView.add(getToolbar());
							}
							pickerView.add(picker);
						};
						pickerView.showPicker = function(customHeight) {
							Ti.API.debug('pickerView.isCurrentlyShowing ?? if FALSE then this will be set to TRUE NOW: ' + pickerView.isCurrentlyShowing);
							if (!ro.isiOS)
								Ti.UI.Android.hideSoftKeyboard();
							if (!pickerView.isCurrentlyShowing) {
								pickerView.isCurrentlyShowing = true;
								//pickerView.height=customHeight;
								if (customHeight) {
									pickerView.height = customHeight;
								}
								pickerView.animate(slide_in);
							}
						};
						pickerView.hidePicker = function() {
							Ti.API.debug('pickerView.isCurrentlyShowing ?? if TRUE then this will be set to FALSE NOW: ' + pickerView.isCurrentlyShowing);
							
							var wasVisible = pickerView.isCurrentlyShowing ? true : false;
							
							if (pickerView.isCurrentlyShowing) {
								//pickerView.removeAllChildren();
								pickerView.isCurrentlyShowing = false;
								pickerView.animate(slide_out, function() {
									pickerView.height = pickerView.defaultHeight;
								});
								pickerView.removeAllChildren();

							}
							
							return wasVisible;
						};
						return pickerView;
					}


					ro.GlobalPicker = getPickerView();
					win.add(ro.GlobalPicker);
				}
				//if(KIOSK.isKiosk()){
				/*win.addEventListener('click', function(e){
				Ti.API.debug('mainWindow clicked');
				if(Ti.App.OrderHasBegun){
				Ti.App.currOrderTouchCount++;
				if(Ti.App.currOrderTouchCount > 1){
				Ti.App.currOrderTouchCount = 0;
				KIOSK.kioskTimerReset();
				}
				}
				});*/
				//}
				if (!ro.isiOS) {
					win.addEventListener('androidback', function(rgs) {
						if (!ro.isiOS)
							Ti.UI.Android.hideSoftKeyboard();
						
						if(ro.GlobalPicker.hidePicker()){
						    return;
						}

						if (ro.windowpopup.hideWindowpopup()) {
							return;
						}

						if (newAccView) {
							if (privacyPolicy.needsReset()) {
								privacyPolicy.resetPolicyView();
							}
							else if (ro.REV_LOYALTY.needsReset()) {
								ro.REV_LOYALTY.reset();
							}
							else {
								ro.ui.closeNewAccount();
							}
						}
						else if (passWordRecovery) {
							ro.ui.closePassRecovery();
						}
						else if (rewardsView) {
							if (ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()) {
								REV_CUSTOMER.changeLtyOptIn(2, true, function() {
								});
							}
							else {
								REV_CUSTOMER.changeEClubOptIn(2, true, function() {
								});
							}

							var Config = JSON.parse(Ti.App.Properties.getString('Config'));
							if (!Config) {
								Config = {};
							}

							var companyName = Config.CompanyName;
							ro.ui.alert('Rewards: ', 'You did not complete the rewards enrollment process. You may enroll in ' + companyName + ' rewards in the settings menu.');
							ro.ui.registerRewardsEnd();
						}
						else {
							if (ro.app.isLogout == true && ro.app.isDemo == false) {
								ro.ui.showAlert();
							}
							else {
								if (ro.app.isDemo) {
									switch(selectedTabIdx) {
										case 0:
											if (!ro.ui.isLoading()) {
												ro.ui.demoShowNext({
													showing: ro.ui.demoStkViewID()
												});
											}
											break;
										case 1:
											ro.ui.demoCartShowNext({
												showing: ro.ui.demoCartStkViewID()
											});
											break;
									}
								}
								else {
									var cartIdx = 2,
									    settingsIdx = 1,
									    homeIdx = 0,
									    rewardsIdx = -2;
									if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
										cartIdx = 1;
										settingsIdx = -2;
									}
									else if (honeycombBln) {
										//rewardsIdx = 2;
										rewardsIdx = 1;
										settingsIdx = 2;
										cartIdx = 3;
									}
									switch(selectedTabIdx) {
										case homeIdx:
											if (true || !ro.ui.isLoading()) {
												var viewShowing = ro.ui.ordTypeStkViewID();
												if (false && viewShowing === 'grpsItems' && Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length > 0) {
													
                                                    ro.ui.popup('Warning: ', ['Cancel', 'OK'], 'You are leaving the menu and this will reset your cart. Would you like to continue?', function(e) {
                                                        /*if (e.source.index === -1 || e.index === -1) {
                                                            return;
                                                        }

                                                        if (e.index === 1) {*/
                                                            ro.ui.ordShowNext({
                                                                showing: viewShowing
                                                            });
                                                        //}
                                                        ro.windowpopup.hideWindowpopup();
                                                    }); 

												}
												else {
													if (ro.App.edit.editMode) {
														ro.App.edit.editMode = false;
														ro.App.edit.editIndex = null;
														ro.ui.showCart();
													}
													else if (ro.App.sugg.suggMode) {
														ro.App.sugg.suggMode = false;
														ro.App.sugg.itmIndx = null;
														ro.App.sugg.grpIndx = null;
														ro.App.sugg.SuggSizeName = null;
														ro.App.sugg.SuggStyleName = null;
														ro.ui.showCart();
													}
													else if (viewShowing === 'cpnSelViewToCart') {
														ro.ui.changeTab({
															tabIndex: ro.REV_GUEST_ORDER.getIsGuestOrder() ? 1 : ( honeycombBln ? 3 : 2)
														});
													}
													else {
														ro.ui.ordShowNext({
															showing: viewShowing
														});
													}
												}
											}
											break;
										case settingsIdx:
											ro.ui.settingsShowNext({
												showing: ro.ui.settingsStkViewID()
											});
											break;
										case rewardsIdx:
											ro.ui.rewardsShowNext({
												showing: ro.ui.rewardsStkViewID()
											});
											break;
										case cartIdx:
											if (privacyPolicy.needsReset()) {
												privacyPolicy.resetPolicyView();
											}
											else {
												ro.ui.cartShowNext({
													showing: ro.ui.cartStkViewID()
												});
											}
											break;
									}
								}
							}
						}
					});
				}

				var appView;
				function addComponents(isGuest, isHC) {
					try {
						var settingsIndex = 1;
						isGuest = ro.REV_GUEST_ORDER.getIsGuestOrder();

						honeycombBln = ro.REV_LOYALTY.getCurrentLoyalty().isHC && ro.REV_LOYALTY.getCurrentLoyalty().showHcTab() ? true : false;
						tabNum = 3;

						if (!isGuest) {

							if (honeycombBln) {
								tabNum = 4;
							}
						}
						else {
							tabNum = 2;
						}
                        
                        
                        var leftRightOffset = ro.ui.relX(30);
						tabs = [];
						tab = null;
						tabView = null;
						appFilmStrip = null;
						//tabWidth = platformWidth / tabNum;

                        tabWidth = ((platformWidth - (2*leftRightOffset))/ tabNum);
                        tabParent = Ti.UI.createView({
                            //borderColor:'green',
                            //borderWidth:2,
                            //left:leftRightOffset,
                            //right:leftRightOffset,
                            bottom: 0,
                            height: tabBarHeight,
                            backgroundColor: 'white',
                            width: platformWidth//,
                            //name: 'tabView'
                        });
                        tabParent.add(Ti.UI.createView(ro.combine(ro.ui.properties.fullGreyBar, {
                            top:0,
                            zIndex:2
                        })));
                        
						tabView = Ti.UI.createView({
						    //borderColor:'green',
						    //borderWidth:2,
						    left:leftRightOffset,
						    right:leftRightOffset,
							//bottom: 0,
							height: tabHeight,
							backgroundColor: 'white',
							//width: platformWidth,
							name: 'tabView'
						});

						if (tabNum == 2) {
							//Ti.API.debug('tabNum 2');
							appFilmStrip = ro.ui.createFilmStripView({
								top: 0,
								left: 0,
								right: 0,
								bottom: 0,
								width: ro.ui.properties.platformWidth,
								views: [ro.ui.createOrdTypeStk(), ro.ui.createCartStk()],
								name: 'filmstrip'
							});
						}
						else if (tabNum == 4) {

							appFilmStrip = ro.ui.createFilmStripView({
								top: 0,
								left: 0,
								right: 0,
								bottom: 0,
								width: ro.ui.properties.platformWidth,
								views: [ro.ui.createOrdTypeStk(), ro.ui.createRewardsStk(), ro.ui.createSettingsStk(), ro.ui.createCartStk()],
								name: 'filmstrip'
							});

						}
						else {

							appFilmStrip = ro.ui.createFilmStripView({
								top: 0,
								left: 0,
								right: 0,
								bottom: 0,
								width: ro.ui.properties.platformWidth,
								views: [ro.ui.createOrdTypeStk(), ro.ui.createSettingsStk(), ro.ui.createCartStk()],
								name: 'filmstrip'
							});

						}

						tab = Ti.UI.createView({
							left: 0,
							top: 0,
							height: tabHeight,
							width: Ti.UI.FILL,
							bottom: 0//,
							//backgroundImage:ro.ui.properties.defaultPath + 'tabHighlight.png'
						});
						tabView.add(tab);
						tabs.push(createTab('home', function() {
							selectIndex(0);
						}, null, 'Home'));

						if (tabNum > 2) {

							if (tabNum > 3) {
								var imgUrl = '/images/rewardsTab.png';
								//Ti.App.websiteURL + 'content/images/rewards.png';
								var imgUrlOn = '/images/rewardsTab_blk.png';
								//Ti.App.websiteURL + 'content/images/rewards_blk.png';

								tabs.push(createTab('rewardsTab', function() {
									selectIndex(1);
								}, null, 'Rewards', imgUrlOn, imgUrl));
								
								settingsIndex = 2;
							}

							tabs.push(createTab('settings', function() {
								selectIndex(settingsIndex);
							}, null, 'Settings'));
						}

						tabs.push(createTab('cart', function() {
							selectIndex(tabNum - 1);
						}, null, 'Cart'));

						for (var i = 0, l = tabs.length; i < l; i++) {
							tabs[i].left = tabWidth * i;
							tabView.add(tabs[i]);
						}

						appView = Ti.UI.createView();
						appView.zIndex = 1;
						appView.add(appFilmStrip);
						tabParent.add(tabView);
						appView.add(tabParent);
						if(ro.isiphonex){
							ro.app.applicationWindow.children[0].add(appView);
						}
						else{
							ro.app.applicationWindow.add(appView);
						}
						filmStripAdded = true;

						ro.ui.changeTab({
							tabIndex: 0
						});

						ro.ui.hideDrawer();
						ro.app.currentView = 'regular';
					}
					catch(e) {
						ro.ui.alert('Error ', 'AC100' + e);
					}
				}

				function addDemoComponents() {
					try {
						tabs = [];
						tab = null;
						tabView = null;
						appFilmStrip = null;
						tabWidth = platformWidth / 2;

						tabView = Ti.UI.createView({
							bottom: 0,
							height: tabHeight,
							backgroundImage: ro.ui.properties.defaultPath + 'tab_bg.png',
							width: platformWidth,
							name: 'tabView'
						});

						appFilmStrip = ro.ui.createFilmStripView({
							top: 0,
							left: 0,
							right: 0,
							bottom: 0,
							width: ro.ui.properties.platformWidth,
							views: [ro.ui.createDemoStk(), ro.ui.createCartStkDemo()],
							name: 'filmstrip'
						});

						tab = Ti.UI.createView({
							left: 0,
							top: 0,
							height: tabHeight,
							width: tabWidth,
							bottom: 0,
							backgroundImage: ro.ui.properties.defaultPath + 'tabHighlight.png'
						});
						tabView.add(tab);

						tabs.push(createTab('home', function() {
							selectIndex(0);
						}));

						tabs.push(createTab('cart', function() {
							selectIndex(1);
						}));

						for (var i = 0,
						    l = tabs.length; i < l; i++) {
							tabs[i].left = tabWidth * i;
							tabView.add(tabs[i]);
						}

						appView = Ti.UI.createView();
						appView.zIndex = 1;
						appView.add(appFilmStrip);
						appView.add(tabView);
						ro.app.applicationWindow.add(appView);
						filmStripAdded = true;

						ro.ui.changeTab({
							tabIndex: 0
						});

						ro.app.currentView = 'demo';
						ro.ui.hideDrawer();
						ro.ui.hideLoader();
					}
					catch(e) {
						ro.ui.alert('Error', 'AD100' + e);
					}
				}

				function createTab(_icon, _cb, _on, _ttl, customOn, customOff) {//create clickable tab images
					var view = Ti.UI.createView({
					    name:_ttl,
						width: tabWidth,
						layout: 'vertical', /*borderWidth:ro.ui.relX(.5), borderColor:ro.ui.theme.tbBrd*/
					}),
					    off_path = customOff && customOff.length ? customOff : '/images/' + _icon + '.png',
					    on_path = customOn && customOn.length ? customOn : '/images/' + _icon + '_blk.png',
					    default_on_path = '/images/' + _icon + '_blk.png',
					    default_off_path = '/images/' + _icon + '.png',
					//on_path = 'https://hungryhowies.hungerrush.com/content/images/store.png',
					    dimension = ro.ui.relY(37);//37
					

					//imageHolder.add(image);
					
                   
                    if (_icon == "cart") {
                        var imageHolder = Ti.UI.createView({
                            top: ro.ui.relY(1),
                            height: dimension,
                            width: dimension
                        }),
                        image = Ti.UI.createImageView({
                            top: 0, //ro.ui.relY(1),
                            height: dimension,
                            width: dimension,
                            imageOnPath: on_path,
                            imageOffPath: off_path,
                            image: (_on) ? on_path : off_path,
                            defaultImage: (_on) ? default_on_path : default_off_path
                        });
                        imageHolder.add(image);
                        var cartCountLbl = Ti.UI.createLabel({
                            top:ro.isiOS ? ro.ui.relY(8) : ro.ui.relY(6),
                            textAlign: 'center',
                            right:ro.isiOS ? ro.ui.relX(12.5) : ro.ui.relY(13),
                            font: {
                                fontSize: ro.ui.scaleFont(11),
                                fontFamily: ro.ui.fonts.navBtns
                            },
                            text: "0",
                            color: 'white'
                        });
                        cartCountLbl.updateCount = function(newCount){
                            cartCountLbl.text = newCount;
                            image.image = newCount && newCount>0 ? image.imageOnPath : image.imageOffPath;
                        };
                        imageHolder.add(cartCountLbl);
                        ro.updateCartCount = cartCountLbl.updateCount;
                    }
                    else{
                        var image = Ti.UI.createImageView({
                            top: 0, //ro.ui.relY(1),
                            height: dimension,
                            width: dimension,
                            image: (_on) ? on_path : off_path,
                            defaultImage: (_on) ? default_on_path : default_off_path
                        });
                    }
                    


					/*image = Ti.UI.createImageView({
					 top:ro.ui.relY(1),
					 height:dimension,
					 width:dimension,
					 image: (_on) ? on_path : off_path,
					 defaultImage: (_on) ? default_on_path : default_off_path
					 });*/

					view.ison = _on || false;
					
					if(_icon == "cart"){
					    view.add(imageHolder);
					}
					else{
					    view.add(image);
					}
					
					//view.add(imageHolder);
					function changeLbl(tab, isOn){
					    if(tab && tab.children && tab.children.length == 2){
					        tab.remove(tab.children[1]);
					        tab.add(Ti.UI.createLabel({
                                text: tab.name,
                                font: {
                                    fontSize: ro.ui.scaleFont(13),
                                    //fontWeight:'bold',
                                    fontFamily: isOn ? ro.ui.fonts.on : ro.ui.fonts.off
                                },
                                color: isOn ? '#393839' : ro.ui.theme.loginGray,
                                top: 0//ro.ui.relY(1)
                            }));
					    }
					}
					//view.changeLbl = changeLbl;
					if (_ttl) {
						var tbLbl = Ti.UI.createLabel({
							text: _ttl,
							font: {
								fontSize: ro.ui.scaleFont(13),
								//fontWeight:'bold',
								fontFamily: (_on) ? ro.ui.fonts.on : ro.ui.fonts.off
							},
							color: (_on) ? '#393839' : ro.ui.theme.loginGray,
							top: 0//ro.ui.relY(1)
						});
						view.add(tbLbl);
					}
					view.addEventListener('click', _cb);
					if(_ttl == "Home"){
					    view.specialToggle = function(hideSelection){
                            view.specialison = !hideSelection;
                            image.defaultImage = (!hideSelection) ? default_on_path : default_off_path;
                            image.image = (!hideSelection) ? on_path : off_path;
                            changeLbl(view, view.specialison);
                            //tbLbl.color = (!hideSelection) ? ro.ui.theme.bottomNavTabTxt : ro.ui.theme.loginGray;
                        };
					}
                    
					view.toggle = function() {
						view.ison = !view.ison;
                        if(view.name == "Home"){
                            return;
                        }
                        
                        changeLbl(view, view.ison);
                        
						image.defaultImage = (view.ison) ? default_on_path : default_off_path;
						image.image = (view.ison) ? on_path : off_path;

						//tbLbl.color = (view.ison) ? ro.ui.theme.bottomNavTabTxt : ro.ui.theme.loginGray;
					};
					return view;
				}
                ro.ui.hideHomeSelection = function(hideSelection){
                    
                    tabs[0].specialToggle(hideSelection);
                };
				function selectIndex(_idx) {//toggle view state of application to the relevant tab
					//Ti.API.debug('honeycombBln selectIndex: ' + honeycombBln);

					//Ti.API.debug('selectIndex: ' + _idx);

					var cartIdx = 2,
					    settingsIdx = 1,
					    homeIdx = 0,
					    rewardsIdx = -2,
					    isGuest = false;
					if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
						isGuest = true;
						cartIdx = 1;
						settingsIdx = -2;
					}
					else if (honeycombBln) {
						cartIdx = 3;
						//settingsIdx = 1;
						settingsIdx = 2;
						rewardsIdx = 1;
					}
					selectedTabIdx = _idx;

                    if(_idx == 0){
                        if(!tabs[0].specialison && tabs[0].ison){
                            tabs[0].ison = false;
                            ro.ui.setOrdTypeStkState('');
                        }
                    }
                    else{
                        //tabs[0].specialison = true;
                    }

					var _prvIdx = -1;
					var samePrv;

					for (var i = 0, l = tabs.length; i < l; i++) {
						if (_idx === i) {
							//Ti.API.debug('i: ' + i);
							//Ti.API.debug('_idx: ' + _idx);
							//Ti.API.debug('tabs[i].ison:' + tabs[i].ison);
							if (!tabs[i].ison) {//if the tab is already selected, do nothing
								tab.animate({
									duration: 1,
									left: 0,
									bottom: 0
								}, function(idx) {
									return function() {
										if (!tabs[idx].ison) {
											tabs[idx].toggle();
										}
									};
								}(i));
								appFilmStrip.fireEvent('changeIndex', {//set the current film strip index
									idx: i
								});
							}
							else {
								samePrv = i;
							}
						}
						else {
							if (tabs[i].ison && _idx != i) {
								_prvIdx = i;
								tabs[i].toggle();
							}
						}
					}

					//Ti.API.debug('ro.app.isDemo: ' + ro.app.isDemo);
					//Ti.API.debug('_idx: ' + _idx);
					//Ti.API.debug('samePrv: ' + samePrv);
					//Ti.API.debug('homeIdx:  ' + homeIdx);
					////Ti.API.debug();
					if (!ro.app.isDemo) {
						if (_idx != samePrv) {
							ro.GlobalPicker.hidePicker();
							if (_idx == homeIdx) {
								//Ti.API.debug('homeidx');
								//Ti.API.debug('ro.App.edit: ' + JSON.stringify(ro.App.edit));
								if (ro.App.edit.editMode) {//This is for editing items in the cart
									ro.ui.ordShowNext({
										addView: true,
										showing: 'itemDetails'
									});
								}
								else if (ro.App.sugg.suggMode) {
									ro.ui.ordShowNext({
										addView: true,
										showing: 'itemDetails'
									});
								}
								else if (ro.App.cpnCodeMode.Flg) {//This is for using coupon code from couponsView.js this takes you from couponsView.js in cart to the coupon walkthrough.
									ro.App.cpnCodeMode.Flg = false;
									//Ti.include('/logic/couponHelper.js');
									ro.cpnHelper.setCpnBool(true, ro.App.cpnCodeMode.LoyaltyCode || null);
									ro.utils.removeProp('SelectedCoupon');
									ro.utils.removeProp('nrq');
									ro.utils.removeProp('rq');
									ro.ui.ordShowNext({
										addView: true,
										showing: 'cpnSelView',
										cpnKey: ro.App.cpnCodeMode.Key,
										goBackToCart: true
									});
									ro.App.cpnCodeMode.Key = null;
									ro.App.cpnCodeMode.LoyaltyCode = null;
								}
								else {
									//Ti.API.debug('ro.ui.getOrdTypeStkState(): ' + ro.ui.getOrdTypeStkState());

									ro.ui.ordShowNext({
										addView: true,
										showing: ro.ui.getOrdTypeStkState()
									});
								}
							}//endif

							if (_idx == settingsIdx) {
								//payControl.clearAllProps();//Clears FavoriteOrderName - CardObj - OrderObj properties whenever settings or pastOrder stacks are accessed
								//ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
								var payControl = require('controls/paymentControl');
								payControl.clearPaymentInfo();
								ro.utils.removeProp('favName');
								ro.ui.settingsShowNext({
									addView: true,
									showing: 'settings'
								});
							}//endif

							if (_idx == rewardsIdx) {
								//payControl.clearAllProps();//Clears FavoriteOrderName - CardObj - OrderObj properties whenever settings or pastOrder stacks are accessed
								ro.ui.rewardsShowNext({
									addView: true,
									showing: 'honeycomb'
								});
							}//endif

							if (_idx == cartIdx) {
								ro.ui.hideTabview();
								ro.ui.cartShowNext({
									addView: true,
									showing: 'Cart'
								});
							}//endif

							if (_prvIdx != -1) {//When changing tabs this takes the source tab and ensures the stack is emptied.
								//(ro.REV_LOYALTY.getCurrentLoyalty()||{}).isHC
								ro.tabBar.clearOtherStacks({
									oldIdx: _prvIdx,
									newIdx: _idx,
									isGuest: isGuest,
									isHC: honeycombBln
								});
							}//endif

							if (((_idx == homeIdx && _prvIdx == -1) || _prvIdx == cartIdx) && !ro.App.edit.editMode && !ro.App.sugg.suggMode) {//Bring up tab view only when coming from the cart screen or from the loginscreen.
								ro.ui.showTabview();
							}//endif
						}
					}
					else {
						if (_idx != samePrv) {
							if (_idx == 0) {
								ro.ui.demoCartStkExplode();
								ro.ui.showTabview();
								ro.ui.demoShowNext({
									addView: true,
									showing: 'menuView'
								});
							}
							if (_idx == 1) {
								ro.ui.demoStkExplode();
								ro.ui.hideTabview();
								ro.ui.demoCartShowNext({
									addView: true,
									showing: 'demoCart'
								});
							}
						}
					}
				}


				ro.ui.showAlert = function() {
					/*var alertDialog = Ti.UI.createAlertDialog({
						title: 'Alert',
						message: 'Do you want to quit this application?',
						buttonNames: ['Yes', 'No'],
						cancel: 1
					});

					alertDialog.addEventListener('click', function(e) {
						if (e.index == 1) {
							return;
						}
						win.close();
					});
					alertDialog.show();*/
					
					ro.ui.popup('Alert', ['Cancel', 'OK'], 'Do you want to quit this application?', function(e) {
                        win.close();
                    });
				};

				ro.ui.changeTab = function(e) {
					//selectIndex(e.tabIndex);
					var tabIdx = e.tabIndex;
					if (tabNum == 3 && e.tabIndex == 3) {
						tabIdx = 2;
					}
					selectIndex(tabIdx);
				};

				ro.ui.hideTabview = function(e) {
					appFilmStrip.bottom = 0;
					tabParent.animate({
						bottom: ro.ui.relY(-100)
					});
				};

				ro.ui.showTabview = function(e) {
					appFilmStrip.bottom = 0;
					tabParent.animate({
						bottom: 0
					});
				};

				ro.ui.showRegular = function(e) {
					addComponents();
				};

				ro.ui.showDemo = function(e) {
					addDemoComponents();
				};

				Ti.App.addEventListener('resetOrdTypeStk', function(e) {
					if (Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length) {
						ro.ui.clearCart();
					}

					ro.ui.remOrdTypeStkChildren();

				});

				Ti.App.addEventListener('app:login.success', function(e) {					
					REV_UPDATE.getCurrentStoreVersion(function(){
					if(hasForgotPasswordDigest){
					    hasForgotPasswordDigest = false;
					    return;
					}
					if (!e) {
						e = {};
					}
					ro.REV_LOYALTY.init();
					ro.REV_LOYALTY.setCurrentLoyalty();
					//Ti.API.debug('e: ' + JSON.stringify(e));
					ro.app.GA.setUser(Ti.App.Username || '', "UX"/*category*/, "User Sign In"/*action*/);
					//All three properties are required
					ro.app.isLogout = false;
					var test = {};
					Ti.App.OrderObj = test;
					test = null;
					initOrderObject();
					//payControl.clearFavoriteProp();
					ro.utils.removeProp('favName');					
					clearEvent();
					var isHC = false;
					var currLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
					//Ti.API.debug('currLoyalty: ' + JSON.stringify(currLoyalty));
					isHC = currLoyalty && currLoyalty.isHC ? true : false;
					addComponents(e.isGuest, isHC);
				});
					
				});

				Ti.App.addEventListener('app:viewDemo', function() {
					ro.app.isDemo = true;
					var test = {};
					test.ordOnlineOptions = {};
					test.ordOnlineOptions.IsDelivery = false;
					Ti.App.OrderObj = test;
					test = null;

					if (false && !ro.app.Store) {
						//var file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, 'demo.json');
						//var contents = file.read();
						//ro.app.Store = eval('(' + contents.text + ')');
						//ro.REV_STORES.setStore(JSON.parse(contents.text));
					}

					ro.app.isSelectedStore = false;
					addDemoComponents();
				});

				ro.ui.exitApp = function(e) {
					try {
						if (!e || !e.orderComplete) {
							//ro.utils.removeProp("ordTrackObj");
							ro.utils.removeProp('ordTrackObj');
						}
						//payControl.clearFavoriteProp();
						ro.utils.removeProp('favName');
						ro.app.isLogout = true;
						//Ti.API.debug('e.orderComplete: ' + (e && e.orderComplete ? e.orderComplete : false));
						ro.ui.showDrawer({
							orderComplete: e && e.orderComplete ? e.orderComplete : false
						});
						try {
							//ro.app.applicationWindow.remove(appView);
							if(ro.isiphonex){
								ro.app.applicationWindow.children[0].remove(appView);
							}
							else{
								ro.app.applicationWindow.remove(appView);
							}
						}
						catch(ex) {
							if (Ti.App.DEBUGBOOL) {
								Ti.API.debug('ro.app.applicationWindow.remove()-Exception: ' + ex);
							}
						}
						ro.app.isDemo = false;
						while(ro.App.openWindows.length){
							ro.App.openWindows.pop().close();
						}						
						ro.REV_STORES.clearStore();
						setEvent();
					}
					catch(e) {
						ro.ui.alert('Application Exit', 'error occured');
					}
				};

				ro.ui.logout = function(e) {
					ro.app.isLogout = true;
					ro.ui.showDrawer();
					ro.ui.ordReset();
					//ro.ui.cartReset();
				};

				ro.ui.showCart = function(straightToCartBool) {
					if (Ti.App.OrderObj.Items) {
						if (Ti.App.OrderObj.Items.length > 0) {
							if (ro.app.isDemo) {
								if (ro.ui.demoStkViewID == 'itemDetails') {
									ro.ui.demoReset();
								}
								ro.ui.changeTab({
									tabIndex: 1
								});
								ro.ui.refreshCartDemo();
							}
							else {
								//Ti.API.debug('honeycombBln ro.ui.showCart: ' + honeycombBln);
								if (ro.ui.ordTypeStkViewID() == 'itemDetails' || straightToCartBool === true) {
									ro.ui.ordReset();
									//THIS IS WHY THE MENU IS RESET ONCE U ADD ITEM AND AND AND HAVE IT TAKE YOU TO THE CART
								}
								ro.ui.changeTab({
									tabIndex: ro.REV_GUEST_ORDER.getIsGuestOrder() ? 1 : ( honeycombBln ? 3 : 2)
								});
								ro.ui.refreshCart();
							}
						}
						else {
							Ti.API.debug('ro.ui.showCart -else else else NO ITEMS');
						}
					}
					else {
						Ti.API.debug('ro.ui.showCart - NO ITEMS');
					}
				};

				ro.ui.clearCart = function(e) {
					try {
						if (!ro.app.isDemo) {
							var payControl = require('controls/paymentControl');
							payControl.clearPaymentInfo();
							//payControl.clearFavoriteProp();
							//ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
							ro.utils.removeProp('favName');
						}
					}
					catch(ex) {
						if (Ti.App.DEBUGBOOL) {
							Ti.API.debug('ro.ui.clearCart()-Exception: ' + ex);
						}
					}
					var test = Ti.App.OrderObj;
					test.Items = null;
					test.Items = [];
					test.Cpns = null;
					test.Cpns = [];
					test.TempCpns = null;
					test.TempCpns = [];
					Ti.App.OrderObj = test;
					test = null;

					/*if(ro.app.isDemo){
					 ro.ui.demoCartReset();
					 ro.ui.refreshCartDemo();
					 }
					 else{
					 //ro.ui.cartReset();
					 //if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length>0){
					 try{
					 ro.ui.refreshCart();
					 }
					 catch(ex){
					 Ti.API.debug('ro.ui.clearCart(cartReset)-Exception: ' + ex);

					 ro.ui.cartReset();
					 ro.ui.refreshCart();
					 }
					 //}
					 }*/
				};
				ro.ui.closeAdView = function() {
					if(ro.isiphonex){
						win.children[0].remove(adView);
					}
					else{
						win.remove(adView);
					}
					adView = null;
				};
				ro.ui.showAdView = function() {
					adView = REV_ADS.getAdWin(ro.ui.closeAdView);
					adView.zIndex = 4;
					if(ro.isiphonex){
						win.children[0].add(adView);
					}
					else{
						win.add(adView);
					}
						
						
				};

				ro.ui.prepareToCreateNewAccount = function() {
					clearEvent();
					//var cfg = Ti.App.Properties.setString('Config', JSON.stringify(response.Config));
					var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
					if (!cfg) {
						cfg = {};
					}

					ro.REV_LOYALTY.init(true);
					//var doLoyalty = ro.REV_LOYALTY.isEnabled();
					var doLoyaltyNoEclub = ro.REV_LOYALTY.isLoyaltyNoEClubEnabled();

					if (doLoyaltyNoEclub) {
						if (cfg.LTY_ENROLL_TYPE) {
							REV_CUSTOMER.getCurrentLoc(function(req) {
								//THIS CALLBACK IS FOR THE SUCCESFULL GEOLOCATION AND NOW ITS TIME TO MAKE THE NEW API CALL
								//alert('req: ' + JSON.stringify(req));

								ro.dataservice.post(req, 'GetLtyStores', function(response) {
									if (response) {
										if (response.Value) {
											//Ti.API.debug('AAAAAAAAAresponse: ' + JSON.stringify(response));
											ro.ui.showNewAccount(response);
										}
										else {
											//Ti.API.debug('response: ' + JSON.stringify(response));
											ro.ui.showNewAccount();
										}
									}
									else {
										//Ti.API.debug('ERROR');
										ro.ui.showNewAccount();
									}
								});
							}, function(req) {
								//THIS CALLBACK IS FOR ANY ERRORS SO THE NEW API CALL CAN STILL BE CALLED BUT WITHOUT COORDINATES
								//Ti.API.debug('req: ' + JSON.stringify(req));

								ro.dataservice.post(req, 'GetLtyStores', function(response) {
									if (response) {
										if (response.Value) {
											//Ti.API.debug('BBBBBBBBBresponse: ' + JSON.stringify(response));
											ro.ui.showNewAccount(response);
										}
										else {
											//Ti.API.debug('response: ' + JSON.stringify(response));
											ro.ui.showNewAccount();
										}
									}
									else {
										//Ti.API.debug('ERROR');
										ro.ui.showNewAccount();
									}
								});

							});
						}
						else {
							ro.ui.showNewAccount();
						}
					}
					else {
						ro.ui.showNewAccount();
					}

				};
				ro.ui.showNewAccount = function(LtyStores) {
					//Ti.API.debug('ro.ui.showNewAccount: CALLED!!!!!!');
					setEvent();
					//Ti.include('/revmobile/ui/newAccountView.js');
					NEWACCOUNTVIEW = NEWACCOUNTVIEW || require('revmobile/ui/newAccountView');
					NEWACCOUNTVIEW.newaccountview(ro);

					newAccView = ro.ui.createNewAccountView(LtyStores);
					newAccView.zIndex = 4;
					if(ro.isiphonex){
						win.children[0].add(newAccView);
					}
					else{
						win.add(newAccView);
					}
				};

				ro.ui.closeNewAccount = function(skipGoogAnalytics) {
					if (skipGoogAnalytics !== true) {
						ro.app.GA.trackPageView('loginView' /*name*/);
					}
					if(ro.isiphonex){
						win.children[0].remove(newAccView);
					}
					else{
						win.remove(newAccView);
					}
					newAccView = null;
				};
				ro.ui.registerRewardsBegin = function() {
					Ti.include('/revmobile/ui/rewardsView.js');
					rewardsView = ro.ui.addRewardsView();
					rewardsView.zIndex = 4;
					if(ro.isiphonex){
						win.children[0].add(rewardsView);
					}
					else{
						win.add(rewardsView);
					}
					ro.ui.hideLoader();
				};
				ro.ui.registerRewardsEnd = function() {
					if(ro.isiphonex){
						win.children[0].remove(rewardsView);
					}
					else{
						win.remove(rewardsView);
					}
					rewardsView = null;

					ro.REV_LOYALTY.getCurrentLoyalty().releaseWebview();
					ro.REV_STORES.clearStore();
					Ti.App.fireEvent('app:login.success');
				};

				var drawer = ro.ui.createDrawerView();
				drawer.zIndex = 2;
				var loader = ro.ui.createLoadingView();
				loader.zIndex = 999;
				if(ro.isiphonex){
					win.children[0].add(drawer);
					//win.children[0].add(loader);
				}
				else{
					win.add(drawer);
					//
				}
				win.add(loader);
				if (Ti.Network.online == false) {
					/*Ti.UI.createAlertDialog({
						title: 'No Network Connection',
						message: 'Sorry, but we couldn\'t detect a connection to the internet'
					}).show();*/
					ro.ui.popup('No Network Connection', ['OK'], 'Sorry, but we couldn\'t detect a connection to the internet', function(e) {
                       //win.close();
                    });
				}

				ro.ui.showDrawer();
				//This is where the loginView is being created and added to the screen.
				//ro.ui.hideDrawer(); does the opposite

				////////////////////          MODULE          ////////////////////
				var FP = require('revmobile/ui/forgotPwd');
				//FORGOT PASSWORD MODULE;
				////////////////////          MODULE          ////////////////////

				ro.ui.showPassRecovery = function(e) {
					passWordRecovery = null;
					ro.app.GA.trackPageView('forgotPasswordView' /*name*/);
					if (e === true) {
						//passWordRecovery = require('revmobile/ui/forgotPwd').createUrlResetView();
						passWordRecovery = FP.createUrlResetView();
					}
					else {
						//passWordRecovery = require('revmobile/ui/forgotPwd').createPasswordRecoveryView();
						passWordRecovery = FP.createPasswordRecoveryView();
					}
					passWordRecovery.zIndex = 4;
					if(ro.isiphonex){
						win.children[0].add(passWordRecovery);
					}
					else{
						win.add(passWordRecovery);
					}
				};
				ro.ui.closePassRecovery = function(e) {
					e = false;
					try {
						ro.ui.showLoader();
						if (e !== true) {
							ro.ui.hideDrawer();
						}
						if(ro.isiphonex){
							win.children[0].remove(passWordRecovery);
						}
						else{
							win.remove(passWordRecovery);
						}
						passWordRecovery = null;
						if (e === true) {
							ro.REV_STORES.clearStore();
							REV_UPDATE(getCurrentStoreVersion(Ti.App.fireEvent('app:login.success')));
						}
						else {
							setTimeout(function() {
								ro.ui.showDrawer();
							}, 300);
						}
					}
					catch(ex) {
						Ti.API.debug('closePassRecovery-Exception: ' + ex);
					}
				};

				function clearWin() {
					try {
						win.removeAllChildren();
					}
					catch(ex) {
						if (Ti.App.DEBUGBOOL) {
							Ti.API.debug('clearWin()-Exception: ' + ex);
						}
					}
					win.close();
				}
				function resumEvt(){
					var currTime = new Date();
					if(Ti.App.getConfigTime && (Math.ceil(currTime - Ti.App.getConfigTime) > (86400000))){
						ro.GlobalPicker.hidePicker();
						if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();						
						ro.windowpopup.hideWindowpopup();						
						ro.getAppConfig();
						ro.ui.exitApp();
					}
					if(ro.isiOS){
						Ti.App.iOS.addEventListener("handleurl", function() {							
								Ti.API.info("RESUME URLSCHEME: " + Ti.App.getArguments().url);
								var digest = Ti.App.getArguments().url;	
								if(digest){
								//digestBool = true;
									var fullDigest = digest.split("?")[1].split("=");
						
									if(fullDigest[0].toLowerCase() == 'promocode'){
										Ti.App.Properties.setString('promoDigest', fullDigest[1]);
									}
						
									if (fullDigest[0].toLowerCase() == 'digest') {
										hasForgotPasswordDigest = true;
										digest = fullDigest[1];
							
										Ti.App.Properties.setString('digest', digest);
										setTimeout(function(e) {
											ro.ui.showPassRecovery(true);
										}, 500);
							
									}

									if (fullDigest[0].toLowerCase() == 'emailtoken') {
										setTimeout(function (e) {
											verifyEmail(fullDigest[1]);
										}, 500);

									}

								}						
						});
					}
					//Ti.API.info('Digest - ' + digest);
					
				}
				
				function clearEvent() {
					
						if(win._hasEvent && !digestBool){
							try{
								//Ti.API.info('REMOVING THE RESUME EVENT');
								//Ti.App.removeEventListener('close',clearWin);
								Ti.App.removeEventListener('resumed',resumEvt);
								win._hasEvent = false;
							}
							catch(ex) {
								if (Ti.App.DEBUGBOOL) {
									Ti.API.debug('clearEvent()-Exception: ' + ex);
								}
							}
						}
						
					if (win._hasEvent && !digestBool) {
						try {
							var activity = win.activity;
							activity.removeEventListener('stop', clearWin);
							activity.removeEventListener('pause', clearWin);

							win._hasEvent = false;
						}
						catch(ex) {
							if (Ti.App.DEBUGBOOL) {
								Ti.API.debug('clearEvent()-Exception: ' + ex);
							}
						}
					}
				}

				function setEvent() {
					Ti.API.info("Set Event Called");
					clearEvent();
					
						try{							
							Ti.App.addEventListener('resume', resumEvt);
							win._hasEvent = true;
						}
						catch(ex) {							
							Ti.API.info('setEvent()-Exception: ' + ex);							
						}
						
						
					if (!win._hasEvent) {
						try {
							var activity = win.activity;
							activity.addEventListener('stop', clearWin);
							activity.addEventListener('pause', clearWin);
							win._hasEvent = true;
						}
						catch(ex) {
							if (Ti.App.DEBUGBOOL) {
								Ti.API.debug('setEvent()-Exception: ' + ex);
							}
						}
					}
				}

				if (!ro.isiOS && Ti.Android.currentActivity && Ti.Android.currentActivity.intent.data && Ti.Android.currentActivity.intent.data !== null) {
					try {
						var dig = Ti.Android.currentActivity.intent.data;
						var digLastIndOf = dig.lastIndexOf('?');
						if (digLastIndOf !== -1) {
							var promoDigestCheck = dig.indexOf("promocode");

							if (promoDigestCheck !== -1) {//ALL NEW DIGEST STUFF FOR PROMOCODE DEEP LINKING
								var digCheck = dig.substring(digLastIndOf + 1, digLastIndOf + 10);
								if (digCheck.toLowerCase() === 'promocode') {
									var digStr = dig.substring(digLastIndOf + 11);
									digStr = decodeURIComponent(digStr.split("&")[0]).trim();
									Ti.App.Properties.setString("promoDigest", digStr);

								}
							}
							else {//ALL OLD DIGEST STUFF FOR FORGOT PASSWORD EMAIL CLICK DEEP LINKING
								digestBool = true;
								var digCheck = dig.substring(digLastIndOf + 1, digLastIndOf + 7);
								var emailCheck = dig.substring(digLastIndOf + 1, digLastIndOf + 11);
								if (digCheck.toLowerCase() === 'digest') {
									var digStr = dig.substring(digLastIndOf + 8);
									Ti.App.Properties.setString('digest', digStr);
									setTimeout(function(e) {
										ro.ui.showPassRecovery(true);
									}, 500);
								}
								if (emailCheck.toLowerCase() === 'emailtoken') {
									var emailStr = dig.substring(digLastIndOf + 12);
									setTimeout(function (e) {
										verifyEmail(emailStr);
									}, 500);
								}
							}
						}
					}
					catch(ex) {
						if (Ti.App.DEBUGBOOL) {
							Ti.API.debug('AppWin(applicationWindow.js)-Exception: ' + ex);
						}
					}
				}

                //****** Commented the code as it is handled in window open (checkIOSdeeplink)
				/*if(ro.isiOS){
					try{
						var digest = null;
						var args = null;//Ti.App.getArguments();
						if (args){
						  digest = args.url;
						}
						
						//alert(digest);
						if(digest){
							digestBool = true;
							var fullDigest = digest.split("?")[1].split("=");
							
							if(fullDigest[0].toLowerCase() == 'promocode'){
								Ti.App.Properties.setString('promoDigest', fullDigest[1]);
							}
							
							//RevDemo://?digest=3DsQCMYTZvT3q436waUQd3FA2
							if(fullDigest[0].toLowerCase() == 'digest'){
								//digestBool = true;
								digest = fullDigest[1];
								
								Ti.App.Properties.setString('digest', digest);
								setTimeout(function(e) {
									ro.ui.showPassRecovery(true);
								}, 500);
							}
						}
					}
					catch(ex){
						Ti.API.info('digest 2 - ex: ' + ex);
					}
					
				}*/

				function verifyEmail(token) {
					var req = {};
					req.emailtoken = token;// "iSTuMAygW2ooQ7tKoydR3g2";
					Ti.API.info("req : " + JSON.stringify(req));
					ro.ui.showLoader();
					ro.dataservice.postAPI(req, "EmailValidation", function (response) {
						Ti.API.info("Email Validation Response: " + JSON.stringify(response));
						if (response.Success) {
							ro.ui.alert('Email Verified', 'Thanks, your email has been verified');
							ro.ui.hideLoader();
						} else {
							ro.ui.alert("Email Verification Error : ", response.Message);
							ro.ui.hideLoader();
						}
					});
                }

				function initOrderObject() {
					var test = Ti.App.OrderObj;
					if (!test) {
						test = {};
					}

					test.OrdType = null;
					test.ordOnlineOptions = {};
					test.ordOnlineOptions.IsDelivery = false;
					test.Customer = {};
					test.Items = [];
					Ti.App.OrderObj = test;
					test = null;
				}


				ro.ui.showKioskConfig = function(e) {
					initOrderObject();
					kioskConfigView = KIOSK.createKioskConfigView();
					kioskConfigView.zIndex = 4;
					if(ro.isiphonex){
						win.children[0].add(kioskConfigView);
					}
					else{
						win.add(kioskConfigView);
					}
				};
				ro.ui.closeKioskConfig = function() {
					if(ro.isiphonex){
						win.children[0].remove(kioskConfigView);
					}
					else{
						win.remove(kioskConfigView);
					}
					kioskConfigView = null;
					ro.ui.hideLoader();
				};
				ro.ui.getConfig = function(_cb) {
					if (false && KIOSK.isKiosk()) {
						ro.ui.showKioskConfig();
					}
					else {
						ro.ui.prepareToCreateNewAccount();
					}
				};
				
				if (ro.isiOS) {
					var continueActivityFn = function(e) {
						//Ti.API.info('e: ' + JSON.stringify(e));
						if (e.activityType === "NSUserActivityTypeBrowsingWeb") {
							var digest = e.webpageURL && e.webpageURL.length ? e.webpageURL : "";
							if (digest) {
								var splitDigest = digest.split("?");
								if (splitDigest && splitDigest.length && splitDigest.length > 1) {
									var fullDigest = splitDigest[1].split("=");
									if (fullDigest && fullDigest.length && fullDigest.length > 1) {
										if (fullDigest[0].toLowerCase() == 'promocode') {
											var finalDigest = decodeURIComponent(fullDigest[1].split("&")[0]).trim();
											Ti.App.Properties.setString('promoDigest', finalDigest);
											
											var isAtGroup = ro.ui.getOrdTypeStkState() == "grpsItems";
											//Ti.API.info('ro.ui.getOrdTypeStkState(): ' + ro.ui.getOrdTypeStkState());
											//Ti.API.info('isAtGroup: ' + isAtGroup);
											if(isAtGroup){
												//Ti.API.info('attempting same page deep link 1');
												ro.ui.ordStackDeepLink();
											}											
										}else if (fullDigest[0].toLowerCase() == 'digest') {
											hasForgotPasswordDigest = true;
											Ti.App.Properties.setString('digest', fullDigest[1]);
											setTimeout(function (e) {
												ro.ui.showPassRecovery(true);
											}, 500);
										}else if (fullDigest[0].toLowerCase() == 'emailtoken') {
											setTimeout(function (e) {
												verifyEmail(fullDigest[1]);
											}, 500);
										}
									}
								}
							}
				
						}
					};
					Ti.App.iOS.addEventListener('continueactivity', continueActivityFn);
					win.addEventListener('close', function(ee){
						Ti.App.iOS.removeEventListener('continueactivity', continueActivityFn);
					});
				}
				
				win.addEventListener('open', function() {
					
					checkiOSDeepLink();
				});			
					
				setEvent();
				return win;
			}
			catch(exx) {
				ro.ui.alert('app window exception', exx);
			}
		};
	};
	return {
		appwindow: appwindow
	};
}();
module.exports = APPWINDOW;
