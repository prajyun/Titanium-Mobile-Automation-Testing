var ORDTYPEADDRVIEW = function(){
	var ordtypeaddrview = function(ro){
	   ro.ui.newAddrList = function(_args){
	   	
	   	  var hasCustChangedToDeliveryAndNowNeedsAddress = false;
	   	  if(REV_ORD_TYPE.IsDeliveryWithoutAddress()){
	   	  	
	   	  	hasCustChangedToDeliveryAndNowNeedsAddress = true;
	   	  	//Ti.API.info('hasCustChangedToDeliveryAndNowNeedsAddress: ' + hasCustChangedToDeliveryAndNowNeedsAddress);
	   	  }
	   	  
	   	  if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
                  //Ti.API.info('Ti.App.OrderObj.Items.length: ' + Ti.App.OrderObj.Items.length);
                  ro.updateCartCount(Ti.App.OrderObj.Items.length);
              }
              else{
                  ro.updateCartCount(0);
              }
	   	
	   	  var rs = ro.db.getCustObj(Ti.App.Username);
	   	  var showNewAddress = true;
	   	  if(rs.AddressCol && rs.AddressCol.length >= 5){
               showNewAddress = false;
               //ro.ui.alert('Error: ', 'Only five addresses may be saved at any given time');
            }
	   	  
	      var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
	         top:ro.ui.relY(5),
	         bottom:ro.ui.relY(65),
	         layout:'vertical',
	         childType:-1
	      }));
	      var newAddrView;
		  var savedAddrView;
		  
		  var addAddrBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
          var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
          
		  
		  savedAddrView = getSavedAddressView(addAddrBtn);
		  newAddrView = getNewAddressView(clearBtn);
	      	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:'newAddrList', layout:'vertical'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      /*var addAddrBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/clearBtn.png");
	      */
	      
	      
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      btnBack.addEventListener('click', function(e){
	          ro.GlobalPicker.hidePicker();
	          ro.ui.ordShowNext({showing:mainView.hid});
	      });
	      addAddrBtn.addEventListener('click', function(e){
              Ti.API.debug('ADDING');
             try{
                if(rs.AddressCol && rs.AddressCol.length >= 5){
                   ro.ui.alert('Error: ', 'Only five addresses may be saved at any given time');
                }
                else{
                   //ro.ui.showLoader();
                   //ro.ui.settingsShowNext({addView:true, showing:'newAddress'});
                   var obj = {
                        source:{
                            id:1
                        }
                    };
                    tabClick(obj);
                }
             }
             catch(ex){
                ro.ui.alert('Address Error', 'Code:110' + ex);
             }
          });
	
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
	      clearBtn.hide();
	      if(showNewAddress){
	         navBar.add(addAddrBtn);
	      }
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
		 
		  var tabWidth = ro.ui.relX(120);
			var tabs = [];
		
			function changePwTab(e){
			    ro.GlobalPicker.hidePicker();
				/*if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
				if(e.rowIndex === 0){
					try{
		            padding.remove(finalizeResetForm);
		         }
		         catch(ex){
		            if(Ti.App.DEBUGBOOL) { Ti.API.debug('changePwTab()-Exception #1: ' + ex); }
		         }
		         padding.add(reqResetForm);
				}
				else if(e.rowIndex === 1){
					try{
		            padding.remove(reqResetForm);
		         }
		         catch(ex){
		            if(Ti.App.DEBUGBOOL) { Ti.API.debug('changePwTab()-Exception #2: ' + ex); }
		         }
		         padding.add(finalizeResetForm);
				}*/
				if(e.rowIndex == 0){
				    //navBar.remove(clearBtn);
					//clearBtn.hide();
					//navBar.remove(clearBtn);
					//addAddrBtn
					//if(view.childType != -1){
					    addAddrBtn.zIndex = 10;
					    clearBtn.zIndex = 0;
					    addAddrBtn.show();
					    clearBtn.hide();
						view.remove(newAddrView);
					//}
					view.childType = 0;
					//savedAddrView = getSavedAddressView();
					view.add(savedAddrView);
				}
				else{
					//clearBtn.show();
					//navBar.remove(addAddrBtn);
					//clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/clearBtn.png");
					//navBar.add(clearBtn);
					addAddrBtn.zIndex = 0;
                        clearBtn.zIndex = 10;
					addAddrBtn.hide();
                    clearBtn.show();
					view.remove(savedAddrView);
					view.childType = 1;
					//newAddrView = getNewAddressView(/*clearBtn*/);
					view.add(newAddrView);
				}
			}
		
			function selectIndex(_idx){
				changePwTab({rowIndex:_idx});
			}
		
			//Ti.include('/controls/tabCtrl.js');
			function tabClick(e){
		      if(e.source.id == 0){
		         if(!tabs[0].ison){
		            selectIndex(0);
		            tabs[0].toggle();
		            tabs[1].toggle();
		         }
		      }
		      else{
		         if(!tabs[1].ison){
		            selectIndex(1);
		            tabs[1].toggle();
		            tabs[0].toggle();
		         }
		      }
		   };
		
			tabs.push(ro.tabBar.createTab('Saved', function(e){
			   tabClick(e);
			}, true, 0));
			
			if(showNewAddress){
			    tabs.push(ro.tabBar.createTab('New Address', function(e){
                tabClick(e);
            }, false, 1));
        
			}
			
		   var tabView = ro.tabBar.getTabView(tabs);
			view.add(tabView);
			view.add(savedAddrView);
			/*var obj = {
				source:{
					id:0
				}
			};*/
			//tabClick(obj);
	      mainView.add(view);
	      
	      function getSavedAddressView(){
		   	var addrControl = require('controls/addrControl');
		   	//navBar.add(addAddrBtn);
		   	  var view = Ti.UI.createScrollView({
		   	  	layout:'vertical',
		   	  	top:ro.ui.relX(5),
		   	  	bottom:0,
		   	  	disableBounce:ro.isiOS ? true : false,
		   	  	contentWidth:Ti.UI.FILL
		   	  });
		   	  var aInfo, numRows;
		      var rs = ro.db.getCustObj(Ti.App.Username);
		      
		      
          
		      
		   	  var noAddrLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved addresses.'}));
		      if(rs.AddressCol && rs.AddressCol.length > 0){
		         numRows = rs.AddressCol.length;
		      }
		      else{
		         numRows = 0;
		      }
		      
		      for(var i=0, iMax=numRows; i<iMax; i++){
		      	  var addrObject = {};
		      	  
		      	  var formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
		      	  if(rs.AddressCol[i].hasOwnProperty('SUD') && rs.AddressCol[i].SUD && rs.AddressCol[i].SUD.length){
		      	 	formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + ', #' + rs.AddressCol[i].SUD + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
		      	  }
		      	  
		      	  addrObject.formattedText = formattedAddress;
		      	  addrObject.customObj = {
		      	  	id:i
		      	  };
		      	  var autoSizeBool = !i;
		      	  var theHdr = ro.layout.getGenericHdrRow(rs.AddressCol[i].Label, autoSizeBool);
		      	  
		      	  view.add(theHdr);
		      	  
		      	  var addressRow = ro.layout.getGenericRow(addrObject);
		      	  addressRow.addEventListener('click', function(e){
		      	  	try{
		               ro.ui.showLoader();
		               ////Ti.API.debug('rs.AddressCol[e.source.id]: ' + rs.AddressCol[e.source.id]);
		               //ro.ui.settingsShowNext({addView:true, showing:'editAddress', rowid:e.source.id});
		               addrControl.getStoreList(addrControl.formRequestGS(rs.AddressCol[e.source.id]), hasCustChangedToDeliveryAndNowNeedsAddress);
		            }
		            catch(ex){
		               ro.ui.alert('Address Error', 'Code:110' + ex);
		            }
		      	  });
		      	  view.add(addressRow);
		      }
		      
		      
		      if(!rs.AddressCol.length){
		         view.add(noAddrLbl);
		      }
		   	  
		   	  return view;
		   }
		   function getNewAddressView(clearBtn){
		   	
		   	  var view = Ti.UI.createView({
		   	  	 top:ro.ui.relX(5)
		   	  });
		   	
		   	  var addrControl = require('controls/addrControl');
		      //ro.include('/formControls/addressForm.js');
		      var addressForm = require('formControls/addressForm');
		      var addrVal = require('validation/addressValidation');
			  var regexVal = require('validation/regexValidation');
			  
			  var hid = 'addNewAddr';
		      var saveAddrBln = true;
		      var defaultCustomer, Id;
		      var bigBtnTxt = 'Save & Continue';
		      var backBtnTxt = 'ADDRESS SELECTION';
			  
			  if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
		         saveAddrBln = false;
		         bigBtnTxt = 'Continue';
		         isGuest = true;
		         defaultCustomer = null;
		         Id = null;
		      }//GUEST ORDERS
		      else{
		         defaultCustomer = ro.db.getCustObj(Ti.App.Username);
		         Id = defaultCustomer.AddressCol.length;
		      }
		      
		      var form = ro.forms.createForm({
		         style:ro.forms.STYLE_LABEL,
		         fields:addressForm.getAddrForm({save:saveAddrBln}),
		         settings:ro.ui.properties.myAccountView
		      });
		      
		      clearBtn.addEventListener('click', function(e){
		          Ti.API.debug('CLEARING');
		          ro.GlobalPicker.hidePicker();
		          form.clearFields();
		      });
		      //navBar.add(clearBtn);
		      var btnUpdate = layoutHelper.getBigButton(bigBtnTxt);
		      var btnWrapper = ro.layout.getBtnWrapper();
	      	  btnWrapper.add(btnUpdate);
		      
		      btnUpdate.addEventListener('click', function(e){
		         ro.GlobalPicker.hidePicker();
		         ro.ui.showLoader();
		         //ro.include('/validation/addressValidation.js');
		         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		         var values = ro.forms.getValues(form);
		         var success = addrVal.addrValidate(values, defaultCustomer);
		         if(success.value){
		            //ro.include('/validation/regexValidation.js');
		            success = regexVal.regExValidate(values);
		            if(success.value){
		               formRequest(values);
		            }
		            else{
		               ro.ui.alert('Error', success.issues[0]);
		               ro.ui.hideLoader();
		            }
		         }
		         else{
		            ro.ui.alert('Error', success.issues[0]);
		            ro.ui.hideLoader();
		         }
		      });
		
				var hdr = ro.layout.getGenericHdrRowWithHeader("Address Information", true);
		        hdr.bottom = ro.ui.relY(10);
				form.container.insertAt({
					view:hdr,
					position:0
				});
		      
		      form.container.add(btnWrapper);
		      //mainView.add(form);
		      form.top = 0;
		      view.add(form);
		      
		      return view;
		      
		   }
	       function formRequest(modifyAddrObj){
              var req  = {}, AddressObj = {};
              try{
                 var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.zip + ', ' + modifyAddrObj.CountryCode;//', US';
        
                var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
                if(!cfg){
                   cfg = {};
                }
                var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
        
                var hrush = {
                    geo:require('app.geo')
                };
                //ro.include('/app.geo.js');
                hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy/*storeObj.Configuration.AllowPCAccuracy*/);
                hrush.geo.geocode2(addr, function(addresses){
                    //Ti.API.debug('addresses: ' + JSON.stringify(addresses));
                    if(!addresses || !addresses.data || !addresses.data.length){//}|| !addresses.data.StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
                        ro.ui.hideLoader();
                        //ro.ui.alert('Error: ', 'Please check address');
                        var msg = 'Please check address';
                        if(addresses && addresses.message){
                            msg = addresses.message;
                        }
                        ro.ui.alert('Error: ', msg);
                        return;
                    }
                    
                    function getReq(addrIdx){
                        if(!addresses.data[addrIdx].StNumber || !addresses.data[addrIdx].StNumber.length){
                           ro.ui.hideLoader();
                           ro.ui.alert('Error: ', 'Street # is required');
                           return;
                        }
                        modifyAddrObj.stnum = addresses.data[addrIdx].StNumber;
                          modifyAddrObj.stname = addresses.data[addrIdx].Street;
        
                          if(addresses.data[addrIdx].City && addresses.data[addrIdx].City.length){
                            modifyAddrObj.city = addresses.data[addrIdx].City;
                          }
        
                          if(addresses.data[addrIdx].State && addresses.data[addrIdx].State.length){
                            modifyAddrObj.state = addresses.data[addrIdx].State;
                          }
        
                          if(addresses.data[addrIdx].Zip && addresses.data[addrIdx].Zip.length){
                            modifyAddrObj.zip = addresses.data[addrIdx].Zip;
                          }
                          var addrControl = require('controls/addrControl');
                        //ro.include('/controls/addrControl.js');
                      AddressObj = addrControl.formAddrObj(modifyAddrObj);
                      AddressObj.Lat = addresses.data[addrIdx].Lat;
                      AddressObj.Lon = addresses.data[addrIdx].Lon;
        
                      if(!modifyAddrObj.addrSave){
                         ro.REV_GUEST_ORDER.setGuestAddr(AddressObj);
                        addrControl.getStoreList(addrControl.formRequestGS(AddressObj), hasCustChangedToDeliveryAndNowNeedsAddress);
                      }
                      else{
                        req.UserName = Ti.App.Username;
                          req.Pass = Ti.App.Password;
                          req.RevKey = 'test';
                          req.GetStores = true;//NOT REQUIRED - BUT IS IT?
                          req.IsDelivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;//NOT REQUIRED - BUT IS IT?
                          req.Address = AddressObj;
                          addrControl.newAddrGetStoreList(req, hasCustChangedToDeliveryAndNowNeedsAddress);
                       }
                        
                    }
                    
                    var GEO = require('geo');
                    if(addresses.data.length > 1){
                        GEO.displayList(addresses.data, getReq);
                    }
                    else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
                        GEO.displayList(addresses.data, getReq);
                    }
                    else{
                        getReq(0);
                    }
                    
                }, true, GOOG_MAPS_KEY);
                return;
              }
              catch(e){
                 ro.ui.alert('Error: ', e);
              }
           };
	      
	      
	      return mainView;
	   };
	   ro.ui.oldnewAddrList = function(_args){
	      
	      //ro.include('/controls/addrControl.js');
	      var addrControl = require('controls/addrControl');
	      var aInfo;
	      var rs = ro.db.getCustObj(Ti.App.Username);
	      var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
	            layout:'vertical',
	            top:ro.ui.relY(10)
	      }));
	
	      var addressInfo = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
	         height:Ti.UI.SIZE,
	         separatorColor:ro.ui.theme.separatorColor,
	         borderColor:ro.ui.theme.loginGray,
	         borderWidth:ro.ui.relX(1),
	         minRowHeight:ro.ui.relY(40),
	         backgroundColor:'#fff',
	         top:0
	      }));
	      var selectAddrLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	         right:ro.ui.relX(10),
	         left:ro.ui.relX(10),
	         top:ro.ui.relY(7),
	         focusable:false
	      }));
	      selectAddrLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:'SELECT YOUR ADDRESS:',
	         font:{
	            fontSize:ro.ui.scaleFont(15, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }
	      })));
	      
	      //var addAddrBtn = layoutHelper.getRightBtn('ADD ADDRESS');
	      var addAddrBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	      addAddrBtn.notlogout = true;
	      addAddrBtn.addEventListener('click', function(e){
	         try{
	            if(rs.AddressCol && rs.AddressCol.length >= 5){
	               ro.ui.alert('Error: ', 'Only five addresses may be saved at any given time');
	            }
	            else{
	               ro.ui.showLoader();
	               ro.ui.ordShowNext({ addView:true, showing:'addNewAddr' });
	            }
	         }
	         catch(ex){
	            ro.ui.alert('New Address Error', 'Code:110' + ex);
	         }
	      });
	      
	      var mainView = layoutHelper.getMainView('newAddrList', 'Address', addAddrBtn, layoutHelper.getBackBtn(), true);
	      var noAddrLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved addresses.'}));
	      var data = [];
	
	      for(var i=0; i<rs.AddressCol.length||0; i++){
	         aInfo = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
	            layout:'vertical',
	            className:'addrRow',
	            id:i,
	            height:ro.ui.relY(60),
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	         }));
	         aInfo.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.addressListHdr, {
	            text:rs.AddressCol[i].Label?rs.AddressCol[i].Label.toUpperCase():'',
	            color:ro.ui.theme.contentsTextColor,
	            id:i
	         })));
	         aInfo.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.addressList, {
	            text:rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip,
	            id:i
	         })));
	         aInfo.addEventListener('click', function(e){
	            try{
	               ro.ui.showLoader();
	               addrControl.getStoreList(addrControl.formRequestGS(rs.AddressCol[e.source.id]));
	            }
	            catch(ex){
	               ro.ui.hideLoader();
	               ro.ui.alert('New Address GetStoreList Error', 'Code:110' + ex);
	            }
	         });
	         data.push(aInfo);
	      }
	      addressInfo.setData(data);
	
	      if(!rs.AddressCol.length){
	         view.add(noAddrLbl);
	      }
	      else{
	         view.add(selectAddrLblView);
	         view.add(addressInfo);
	      }
	
	      mainView.add(view);
	      return mainView;
	   };
	};
	return {
		ordtypeaddrview:ordtypeaddrview
	};
}();
module.exports = ORDTYPEADDRVIEW;