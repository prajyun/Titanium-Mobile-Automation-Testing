var SETTINGSVIEW = function(){
	var settingsview = function(ro){		
	
		ro.ui.createSettingsView = function(_args){
	      try{
	         var mainView = layoutHelper.getMainView('settings', 'Settings', null, null, true);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL) { Ti.API.debug('settingsView()-Exception: ' + ex); }
	      }
	      
	      var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
	      if(!currentLoyalty.isLU && !currentLoyalty.isHC){
	         currentLoyalty = false;
	      }
	
	      var settingsView =  Ti.UI.createScrollView({
	         layout:'vertical',
	         top:0,
	         height:Ti.UI.SIZE
	         //bottom:ro.ui.relY(110)
	      });
			mainView.add(settingsView);
	
	      /* currentLoyalty.getLtyCustomerDetails(Ti.App.Username, 1, function(response){
	         //deb.ug(response, 'response');
	      }); */
	
	      //var allowRewards = currentLoyalty && (currentLoyalty.isLU && currentLoyalty.isSiteRewardsCapable()) || (currentLoyalty.isHC);
	      var rewardsShowingStr = 'rewards';
	      var creditShowingStr = 'creditCard';
	      var creditTtl = ' CREDIT CARD';
	      var rewardsTtl = ' ENABLE REWARDS';
	      //isLoyaltyEnabled ? ' REWARDS' : ' ENABLE REWARDS'
	      
	      var allowRewards = currentLoyalty && !currentLoyalty.isHC ? true : false;
	      var isLoyaltyEnabled = false;
	      var ecluboptin = 0;
	      if(allowRewards){
					if(ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()){
						ecluboptin = ro.REV_LOYALTY.getLtyOptIn();
					}
					else{
	         			ecluboptin = ro.REV_LOYALTY.getEClubOptIn();
	         		}
	         if(ecluboptin == 1){
	            if(currentLoyalty.isLU){
	         	  isLoyaltyEnabled = currentLoyalty.isLoyaltyEnabled();
	         	  if(isLoyaltyEnabled){
	         	     rewardsShowingStr = 'levelup';
	                 creditShowingStr = 'loyaltiesCredit';
	                 creditTtl = ' PAYMENT OPTIONS';
	                 rewardsTtl = ' REWARDS ACCOUNT';
	         	  }
	         	}
	         	else if(currentLoyalty.isHC){
	         	   rewardsShowingStr = 'honeycomb';
	               //creditShowingStr = 'loyaltiesCredit';
	               //creditTtl = ' PAYMENT OPTIONS';
	               rewardsTtl = ' REWARDS';
	         	}
	         }
	      }
	
			var properties = [
	         ro.combine(ro.ui.properties.lblStoreName, {
	            title:' PROFILE',
	            hasChild:true,
	            className:'settings',
	            IsDelivery:false,
	            height:ro.ui.relY(40),
	            showing:'profile',
	            leftImage:'/images/contact.png',
	            rightImage:'/images/details.png'
	         }),
	         ro.combine(ro.ui.properties.lblStoreName, {
	            title:' ADDRESS',
	            hasChild:true,
	            className:'settings',
	            IsDelivery:true,
	            height:ro.ui.relY(40),
	            showing:'address',
	            leftImage:'/images/address.png',
	            rightImage:'/images/details.png'
	         }),
	         ro.combine(ro.ui.properties.lblStoreName, {
	            title:creditTtl,
	            hasChild:true,
	            className:'settings',
	            IsDelivery:true,
	            height:ro.ui.relY(40),
	            showing:creditShowingStr,
	            leftImage:'/images/credit_card.png',
	            rightImage:'/images/details.png'
	         })
	      ];
	      
	      var profileBtn, addrBtn, curbsideBtn, creditBtn, usernameBtn, passBtn, logoutBtn;
	
			var credentials = [
	   		ro.combine(ro.ui.properties.lblStoreName, {
	   		   title:' UPDATE USERNAME',
	   		   hasChild:true,
	   		   className:'settings',
	   		   IsDelivery:false,
	   		   height:ro.ui.relY(40),
	   		   showing:'username',
	            leftImage:'/images/username.png',
	            rightImage:'/images/details.png'
	   		}),
	   		ro.combine(ro.ui.properties.lblStoreName, {
	   		   title:' UPDATE PASSWORD',
	   		   hasChild:true,
	   		   className:'settings',
	   		   IsDelivery:true,
	   		   height:ro.ui.relY(40),
	   		   showing:'password',
	            leftImage:'/images/password.png',
	            rightImage:'/images/details.png'
	   		})
	   	];
	
	   	var loyalties = [
	         ro.combine(ro.ui.properties.lblStoreName, {
	            title:rewardsTtl,
	            hasChild:true,
	            className:'settings',
	            IsDelivery:false,
	            height:ro.ui.relY(40),
	            showing:rewardsShowingStr,
	            leftImage:'/images/rewards.png',
	            rightImage:'/images/details.png'
	         })
	      ];
	
			var tblProperties = Ti.UI.createTableView({
				data:properties,
			  	scrollable:false,
			  	separatorColor:ro.ui.theme.separatorColor,
				top:0,
				left:ro.ui.relX(10),
				right:ro.ui.relX(10),
				backgroundColor:'white',
				borderColor:ro.ui.theme.loginGray,
				borderWidth:ro.ui.relX(1),
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL
	 		});
	 		var tblHdrView = layoutMenuHelper.menuHeaders({text:'PERSONAL INFORMATION'});
	 		tblHdrView.top = ro.ui.contentsTop * .75;
	
	 		var tblCredentials = Ti.UI.createTableView({
				data:credentials,
				separatorColor:ro.ui.theme.separatorColor,
			  	scrollable:false,
			  	top:0,
			  	borderColor:ro.ui.theme.loginGray,
			  	borderWidth:ro.ui.relX(1),
			  	left:ro.ui.relX(10),
			  	right:ro.ui.relX(10),
				height:Ti.UI.SIZE,
				backgroundColor:'white',
				width:Ti.UI.FILL
	 		});
	
	 		var tblLoyalties = Ti.UI.createTableView({
	         data:loyalties,
	         separatorColor:ro.ui.theme.separatorColor,
	         scrollable:false,
	         top:0,
	         borderColor:ro.ui.theme.loginGray,
	         borderWidth:ro.ui.relX(1),
	         left:ro.ui.relX(10),
	         right:ro.ui.relX(10),
	         height:Ti.UI.SIZE,
	         backgroundColor:'white',
	         width:Ti.UI.FILL
	      });
	
	 		var credHdrView = layoutMenuHelper.menuHeaders({text:'ACCOUNT INFORMATION'});
	      credHdrView.top = ro.ui.halfContentsTop;
	
	      var loyHdrView = layoutMenuHelper.menuHeaders({text:'REWARDS'});
	      loyHdrView.top = ro.ui.halfContentsTop;
	
			tblProperties.addEventListener('click', function(e){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:e.rowData.showing});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100' + ex);
				}
			});
	
			tblCredentials.addEventListener('click', function(e){
	         try{
	            ro.ui.showLoader();
	            ro.ui.settingsShowNext({addView:true, showing:e.rowData.showing});
	            ro.ui.hideLoader();
	         }
	         catch(ex){
	            ro.ui.alert('Settings', 'Code:100' + ex);
	         }
	      });
	
	      /*settingsView.add(tblHdrView);
			settingsView.add(tblProperties);
	
			settingsView.add(credHdrView);
			settingsView.add(tblCredentials);*/
			
			var clearBgBln = true;
			profileBtn = ro.layout.getSettingsButton('Profile', '/images/contact.png');
			profileBtn.addEventListener('click', function(){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:"profile"});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100');
				}
			});
			addrBtn = ro.layout.getSettingsButton('Address', '/images/address.png');
			addrBtn.addEventListener('click', function(){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:"address"});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100');
				}
            });
            curbsideBtn = ro.layout.getSettingsButton('Curbside Information', '/images/curbside_settings.png');
            curbsideBtn.addEventListener('click', function () {
                try {
                    ro.ui.showLoader();
                    ro.ui.settingsShowNext({ addView: true, showing: "curbside" });
                    ro.ui.hideLoader();
                }
                catch (ex) {
                    ro.ui.alert('Settings', 'Code:100');
                }
            });
			creditBtn = ro.layout.getSettingsButton('Credit Cards', '/images/credit_card.png');
			creditBtn.addEventListener('click', function(){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:"creditCard"});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100');
				}
			});
			usernameBtn = ro.layout.getSettingsButton('Update Email', '/images/username.png');
			usernameBtn.addEventListener('click', function(){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:"username"});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100');
				}
			});
			passBtn = ro.layout.getSettingsButton('Update Password', '/images/password.png');
			passBtn.addEventListener('click', function(){
				try{
					ro.ui.showLoader();
					ro.ui.settingsShowNext({addView:true, showing:"password"});
					ro.ui.hideLoader();
				}
				catch(ex){
					ro.ui.alert('Settings', 'Code:100');
				}
			});
			logoutBtn = ro.layout.getSettingsButton('Sign Out', '/images/signout.png');
			logoutBtn.addEventListener('click', function(e){
				if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
					ro.REV_GUEST_ORDER.setIsGuestOrder(false);
				}
			   ro.ui.ordShowNext({ showing:'ordTypeView' });
			});
			
			settingsView.add(profileBtn);
            settingsView.add(addrBtn);
            settingsView.add(curbsideBtn);
			settingsView.add(creditBtn);
			settingsView.add(usernameBtn);
			settingsView.add(passBtn);
			settingsView.add(logoutBtn);
	
			if(allowRewards){
			   tblLoyalties.addEventListener('click', function(e){
	            try{
	               var str = {};
	               str = ro.app.Store || {};
	               if(e.rowData.showing == 'levelup'){
	                  if(!str || !str.Configuration || !str.Configuration.LU_STORE_ID){
	                     ro.ui.alert('Error:', 'Must select a store to see rewards status');
	                     return;
	                  }
	                  else{
	                  	 currentLoyalty.Init();
	                     var cfg = str && str.Configuration?str.Configuration:{};
	                     var CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
	                     if(!CustInfo){
	                        CustInfo = {};
	                     }
	                  }
	               }
	
	               if(!str || !str.Configuration){
	                  ro.ui.alert('Error:', 'Must select a store to see rewards status');
	                  return;
	               }
	              
	               var doThis = true;
	               if(e.rowData.showing == 'rewards'){
	                  if(currentLoyalty.isHC || (currentLoyalty.isLU && currentLoyalty.isLoyaltyEnabled())){
	                    doThis = false;
					if(ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()){
						REV_CUSTOMER.changeLtyOptIn(1, false, function(){
	                       ro.ui.settingsShowNext({addView:true, showing:'settings'});//must go back to settings in case user does not have store yet
	                    });
					}
					else{
	                    REV_CUSTOMER.changeEClubOptIn(1, false, function(){
	                       ro.ui.settingsShowNext({addView:true, showing:'settings'});//must go back to settings in case user does not have store yet
	                    });
	                }
	             }
	           }
	                              
	               if(doThis){
	                  ro.ui.showLoader();
	                  ro.ui.settingsShowNext({addView:true, showing:e.rowData.showing});
	                  ro.ui.hideLoader();
	               }
	            }
	            catch(ex){
	               ro.ui.alert('Settings', 'Code:100' + ex);
	            }
	         });
	
			   settingsView.add(loyHdrView);
	         settingsView.add(tblLoyalties);
	      }
			return mainView;
		};
	};
	return {
		settingsview:settingsview
	};
}();
module.exports = SETTINGSVIEW;