var OLDNEWPAYMENTVIEW = function(){
	var oldnewpaymentview = function(ro){
	   ro.ui.createNewPayView = function(){
	   	  var doesTotalExceedThreshold = function(){
	   	  	
	   	  	 /*for(var p in Ti.App.OrderObj){
	   	  	 	Ti.API.debug('Ti.App.OrderObj['+p+']: ' + JSON.stringify(Ti.App.OrderObj[p]));
	   	  	 }*/
	   	  	
	   	  	 var ttl = Ti.App.OrderObj.ActiveTotal;
	   	  	 
	   	  	 return cfg
	   	  	 	&& cfg.FORCE_CC_THRESHOLD
	   	  	 	&& !(parseFloat(cfg.FORCE_CC_THRESHOLD) > parseFloat(ttl)); 
	   	  };
	   	  var getThresholdView = function(){
	   	  	    var ccMsg = cfg && cfg.FORCE_CC_MSG && cfg.FORCE_CC_MSG.length ? cfg.FORCE_CC_MSG : "Some payment options are not available for your order.";
	         	var thresholdView = Ti.UI.createView({
	         		layout:'horizontal',
	         		width:Ti.UI.FILL,
	         		height:ro.ui.relY(16)
	         	});
	         	var alertImg = Ti.UI.createImageView({
	         		left:ro.ui.relX(2),
	         		height:Ti.UI.FILL,
	         		image:'/images/alertImg.png'
	         	});
	         	var ccThresholdLbl = Ti.UI.createLabel({
	         		text:ccMsg,
	         		textAlign:'left',
			         color:ro.ui.theme.backgroundpngTxt,
			         font:{
			            fontSize:ro.ui.scaleFont(12,0,0),
			            //fontWeight:'bold',
						fontFamily:ro.ui.fontFamily
			         },
			         left:ro.ui.relX(2)
	         	});
	         	thresholdView.add(alertImg);
	         	thresholdView.add(ccThresholdLbl);
	         	return thresholdView;
	         	//paymentView.add(thresholdView);
	   	  };
	   	  
	      try{
	      	var payControl = require('controls/paymentControl');
	      	var favVal, regexVal;
			
			var rs = ro.db.getCustObj(Ti.App.Username);
			var gateCodeBln = false;
	
	         //GUEST ORDER
	         var isGuest = false;
	         if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	            isGuest = true;
	            rs = {};
	            ////deb.ug(Ti.App.OrderObj, 'Ti.App.OrderObj');
	           // //deb.ug(Ti.App.OrderObj.Customer, 'Ti.App.OrderObj.Customer');
	         }
	         //GUEST ORDER
	
	         var Config = JSON.parse(Ti.App.Properties.getString('Config'));
	         if(!Config){
	            Config = {};
	         }
	         var CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
	         if(!CustInfo){
	            CustInfo = {};
	         }
	
	
				//////////		Privacy Policy		///////////
				var doPrivacy = false;
				privacyPolicy.Init(Config.Docs, Config.PrivacyUrl, Config.TermsUrl, Config.DocsDate, Config.CompanyName, CustInfo.TermsDate?CustInfo.TermsDate:false);
				doPrivacy = privacyPolicy.isEnabled()==true?true:false;
				//////////		Privacy Policy		///////////
	
				var isSpecialLtyNoEclub = false;
				if(ro.app.Store.Configuration.LTY_CHK_PTS && ro.app.Store.Configuration.LTY_CHK_PTS.length){
					switch(ro.app.Store.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase()){
						case 'notenrolled':
							isSpecialLtyNoEclub = true;
							break;
						case 'all':
							if(rs.LtyOptIn == 0 || rs.LtyOptIn == 2){
								isSpecialLtyNoEclub = true;
							}
							break;
					}
				}
				if(isGuest){
					isSpecialLtyNoEclub = false;
				}
	
				//////////			LEVELUP			///////////
	       	var cfg = ro.app.Store.Configuration?ro.app.Store.Configuration:{};
	       	Ti.App.Properties.setString('Config', JSON.stringify(cfg));
	         var registerRewards = false;
	         var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
	         if(levelUp.isLU){
	            levelUp.Init(ro.app.Store.Configuration);
	            registerRewards = levelUp.isSiteRewardsCapable();
	         }
			   //////////			LEVELUP			///////////
	
	         //////////        LOYALTY        ///////////
	         ro.REV_LOYALTY.init();
	         var doLoyalty = ro.REV_LOYALTY.isEnabled();
	         if(doLoyalty){
	            doLoyalty = ro.REV_LOYALTY.isEnabledAtPayment();
	         }
	         var doNoEClubLoyalty = ro.REV_LOYALTY.isLoyaltyNoEClubEnabled();
	         if(isSpecialLtyNoEclub){
	         	doNoEClubLoyalty = false;
	         }
	         if(doNoEClubLoyalty){
	         	doNoEClubLoyalty = ro.REV_LOYALTY.isLoyaltyNoEClubEnabledAtPayment();
	         	if(!doNoEClubLoyalty){
	         		doNoEClubLoyalty = ro.REV_LOYALTY.haveTermsChanged();
	         	}
	         }
	         //////////        LOYALTY        ///////////
	
	      	Ti.App.atPayScrn = true;
	
	         var hasCC = false;
	         var raterAlert = Ti.UI.createAlertDialog();
	         var alertDiag = Ti.UI.createAlertDialog();
	         var hasPayupon = false;
	         
	         var storeObj;
	         var clickTime = null;
	         var favCount=0;
	
	         try{
	            if(!isGuest && rs.PrevOrders && rs.PrevOrders.length){
	               for(var i=0; i<rs.PrevOrders.length; i++){
	                  if(rs.PrevOrders[i].Name){
	                     favCount++;
	                  }
	               }
	            }
	         }
	         catch(ex){
	            favCount = 5;
	            if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('Error with prevOrd: ' + ex); }
	         }
	         if(isGuest){
	            favCount = 5;
	         }
	
	         storeObj = ro.app.Store;
	
	         function addLabels(List, row){
	            var top = 25;
	            var bottom = 18;
	            for(var j=0; j<List.length; j++){
	               row.add(Ti.UI.createLabel({
	                  text:List[j],
	                  left:ro.ui.relX(15),
	                  top:ro.ui.relY(top + (15 * j)),
	                  bottom:ro.ui.relY(bottom - (13 * j)),
	                  font:{
	                     fontSize:ro.ui.scaleFont(11.5, 0, 0),
	                     fontWeight:'bold',
	            			fontFamily:ro.ui.fontFamily
	                  },
	                  height:ro.ui.relY(13),
	                  color:ro.ui.theme.textColor
	               }));
	            };
	            return;
	         }
	         var checkoutView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
	            hid:'paymentScreen'
	         }));
	
	         var mainScroll = Ti.UI.createScrollView({
	         	scrollType:'vertical',
	            top:(ro.ui.displayCaps.platformHeight * .15) + ro.ui.relY(5),
	            bottom:ro.ui.relY(15),//15
	            right:ro.ui.relX(7),
	            left:ro.ui.relX(7),
	            layout:'vertical'
	         });
	         var mainView = Ti.UI.createView({
	            height:Ti.UI.SIZE,
	            layout:'vertical'
	         });
	         //mainScroll.add(mainView);
	         var emptyView = Ti.UI.createView({
	            height:ro.ui.relY(45),
	            backgroundColor:'transparent'
	         });
	
	         var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	         var btnBack = layoutHelper.getBackBtn('CART');
	         navBar.add(btnBack);
	         /* if(ro.ui.theme.bannerImg){
	            var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	            navBar.add(headerImg);
	         }
	         else{
	         	var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, { text:'Payment Details' }));
	         	navBar.add(headerLbl);
	         } */
	         checkoutView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	
	         btnBack.addEventListener('click', function(e){
	            payControl.clearPaymentInfo();
	            //ro.utils.removeOrdObjectProps(["ordOnlineOptions", "DisplayOrdPayment", "Tip"]);
	            try{
	               //payControl.clearFavoriteProp();
	               ro.utils.removeProp('favName');
	            }
	            catch(ex){
	               if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('btnBack(newPaymentView - event)-Exception: ' + ex); }
	            }
	            ro.ui.cartShowNext({ showing:'paymentScreen' });
	         });
	
	         var data = [];
	         var data1 = [];
	         var data0 = [];
	         var dataCust = [];
	         var dataGuest = [];
	
	         var storeRow = Ti.UI.createTableViewRow({
	            className:'storeSelection',
	            top:ro.ui.relY(5),
	            height:ro.ui.relY(60),
	            storeName:storeObj.Name,
	            backgroundColor:'white'
	         });
	
	         storeRow.add(Ti.UI.createLabel(ro.combine( ro.ui.properties.newPayHdr, {
	            text:storeObj.Name?storeObj.Name.toUpperCase():storeObj.Name
	         })));
	
	         addLabels([storeObj.Address, storeObj.City + ', ' + storeObj.State + ', ' + storeObj.Zip], storeRow);
	
	         var hrsView = Ti.UI.createView({
	            right:ro.ui.relX(5),
	            width:ro.ui.relX(100),
	            bottom:ro.ui.relY(5)
	         });
	
	         storeRow.add(hrsView);
	         data0[0] = storeRow;
	
	         var tblView0HeaderView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(2),
	            left:ro.ui.relX(2),
	            top:ro.ui.relY(5),
	            focusable:false
	         }));
	         tblView0HeaderView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:Ti.App.OrderObj.OrdType.toUpperCase(),
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         })));
	
	         var ordTypeView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:ro.ui.relY(10)//25
	         }));
	
	         var tableView0 = Ti.UI.createTableView({
	            data:data0,
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            scrollable:false,
	            height:Ti.UI.SIZE,
	            separatorColor:ro.ui.theme.separatorColor,
	            borderColor:ro.ui.theme.loginGray,
	            borderWidth:ro.ui.relX(1),
	            backgroundColor:'transparent'
	         });
	         ordTypeView.add(tblView0HeaderView);
	         ordTypeView.add(tableView0);
	         
	         //////////////////////////////
	         // Loyalty Box //
	         //////////////////////////////
	         var ltyNewView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:0,
	            top:ro.ui.relY(10),
	            visible:false
	         }));
	         var ShowLtyView = function(resp, showEnrollMsg){
	         	 var dataLty = [];
		         //if(storeObj.Configuration.LTY_CHK_PTS)
		         var ltyRow = Ti.UI.createView({
		            //className:'storeSelection',
		            top:ro.ui.relY(5),
		            height:ro.ui.relY(35),
		            //storeName:storeObj.Name,
		            backgroundColor:'white'
		         });
				 var pointsMsg = "This order qualifies to earn " + resp.Points + " points.";
				
				 var msg = storeObj.Configuration.LTY_CHK_PTS_TXT;
				
				 if(msg && msg.length){
					pointsMsg = msg.replace('[]', resp.Points);
			     }
		         ltyRow.add(Ti.UI.createLabel(ro.combine( ro.ui.properties.newPayHdr, {
		            text:pointsMsg
		         })));
				 
		         //addLabels([storeObj.Address, storeObj.City + ', ' + storeObj.State + ', ' + storeObj.Zip], ltyRow);
		
		         /*var hrsView = Ti.UI.createView({
		            right:ro.ui.relX(5),
		            width:ro.ui.relX(100),
		            bottom:ro.ui.relY(5)
		         });
		
		         ltyRow.add(hrsView);*/
		         //dataLty[0] = ltyRow;
		
		         var tblViewLtyHeaderView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		            right:ro.ui.relX(2),
		            left:ro.ui.relX(2),
		            top:ro.ui.relY(5),
		            focusable:false
		         }));
		         tblViewLtyHeaderView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		            text:(storeObj.Configuration.LTY_ENROLL_HDR||"").toUpperCase(),
		            font:{
		               fontSize:ro.ui.scaleFont(15, 0, 0),
		               fontWeight:'bold',
		               fontFamily:ro.ui.fontFamily
		            }
		         })));
		         
		         var tableViewLty = Ti.UI.createScrollView({
		         	layout:'vertical',
		            //data:dataLty,
		            left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
		            scrollable:false,
		            height:Ti.UI.SIZE,
		            separatorColor:ro.ui.theme.separatorColor,
		            borderColor:ro.ui.theme.loginGray,
		            borderWidth:ro.ui.relX(1),
		            backgroundColor:'white'
		         });
		         tableViewLty.add(ltyRow);
		         
		         
		         if(showEnrollMsg){
		         	
		         	//tableViewLty.add()
		         	var LoyaltyNoEClubView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(null, null, true, null, null, true);
		         	LoyaltyNoEClubView.left = ro.ui.relX(5);
		         	LoyaltyNoEClubView.right = ro.ui.relX(5);
		         	LoyaltyNoEClubView.bottom = ro.ui.relY(5);
		         	tableViewLty.add(LoyaltyNoEClubView);
		         }
		         
		         ltyNewView.add(tblViewLtyHeaderView);
		         ltyNewView.add(tableViewLty);
		         
		         ltyNewView.height = Ti.UI.SIZE;
		         ltyNewView.visible = true;
		         ltyNewView.show();
	         };
	         //////////////////////////////
	         // Loyalty Box //
	         //////////////////////////////
	         
	         
	         
	         
	         //////////////////////////////
	         // Cust Info if GUEST ORDER //
	         //////////////////////////////
	         if(isGuest && !Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	            var guestRow = Ti.UI.createTableViewRow({
	               className:'guestSelection',
	               top:ro.ui.relY(5),
	               height:ro.ui.relY(60),
	               backgroundColor:'white'
	            });
	            
	            var resultSet = ro.REV_GUEST_ORDER.getGuestInfo();
	            var guestFirstName, guestLastName, guestEmail, guestPhone;
	
	            guestFirstName = resultSet.FirstName?resultSet.FirstName:'';
	            guestLastName = resultSet.LastName?resultSet.LastName:'';
	            guestEmail = resultSet.Email?resultSet.Email:'';
	            guestPhone = resultSet.Phone?resultSet.Phone:'';
	            
	            guestRow.add(Ti.UI.createLabel(ro.combine( ro.ui.properties.newPayHdr, {
	               text:guestEmail.toUpperCase() + '\n' + guestFirstName.toUpperCase() + ' ' + guestLastName.toUpperCase() + '\n' + (guestPhone.slice(0,3) + '-' + guestPhone.slice(3,6) + '-' + guestPhone.slice(6,10)),
	               height:Ti.UI.SIZE
	            })));
	
	            dataGuest[0] = guestRow;
	
	            var guestHeaderView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	               right:ro.ui.relX(2),
	               left:ro.ui.relX(2),
	               top:ro.ui.relY(5),
	               focusable:false
	            }));
	            guestHeaderView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	               text:'GUEST INFORMATION',
	               font:{
	                  fontSize:ro.ui.scaleFont(15, 0, 0),
	                  fontWeight:'bold',
	                  fontFamily:ro.ui.fontFamily
	               }
	            })));
	            var guestInfoView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	               layout:'vertical',
	               height:Ti.UI.SIZE,
	               top:ro.ui.relY(15)
	            }));
	
	            var guestInfoTbl = Ti.UI.createTableView({
	               data:dataGuest,
	               left:ro.ui.relX(2),
	               right:ro.ui.relX(2),
	               scrollable:false,
	               height:Ti.UI.SIZE,
	               separatorColor:ro.ui.theme.separatorColor,
	               borderColor:ro.ui.theme.loginGray,
	               borderWidth:ro.ui.relX(1),
	               backgroundColor:'transparent'
	            });
	            guestInfoView.add(guestHeaderView);
	            guestInfoView.add(guestInfoTbl);
	         }
	         //////////////////////////////
	         // Cust Info if GUEST ORDER //
	         //////////////////////////////
	         
	
	         //////////////////////////////
	         //   Cust Info if Delivery	 //
	         //////////////////////////////
	         var isDeliv = false;
	         if(Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery == true){
	         	isDeliv = true;
	         	gateCodeBln = true;
		         var custRow = Ti.UI.createTableViewRow({
		            className:'custSelection',
		            top:ro.ui.relY(5),
		            height:ro.ui.relY(60),
		            backgroundColor:'white'
		         });
		         var resultSet = isGuest ? {FirstName:Ti.App.OrderObj.Customer.FName, LastName:Ti.App.OrderObj.Customer.LName} : ro.db.getCustObj(Ti.App.Username);
					var combinedAddress, firstName, lastName, strtName, strtNum, cty, stt, zp;
	
					firstName = resultSet.FirstName?resultSet.FirstName:'';
					lastName = resultSet.LastName?resultSet.LastName:'';
					strtName = Ti.App.OrderObj.Customer.St?Ti.App.OrderObj.Customer.St:(Ti.App.OrderObj.Customer.Street?Ti.App.OrderObj.Customer.Street:'');
					strtNum = Ti.App.OrderObj.Customer.StNum?Ti.App.OrderObj.Customer.StNum:'';
					combinedAddress = strtNum + ' ' + strtName;
					cty =	Ti.App.OrderObj.Customer.City?Ti.App.OrderObj.Customer.City:'';
					stt = Ti.App.OrderObj.Customer.State?Ti.App.OrderObj.Customer.State:'';
					zp = Ti.App.OrderObj.Customer.Zip?Ti.App.OrderObj.Customer.Zip:'';
	
		         custRow.add(Ti.UI.createLabel(ro.combine( ro.ui.properties.newPayHdr, {
		            text:'' + firstName.toUpperCase() + ' ' + lastName.toUpperCase()
		         })));
	
		         addLabels([combinedAddress, cty + ', ' + stt + ', ' + zp], custRow);
		         dataCust[0] = custRow;
	
		         var custHeaderView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		            right:ro.ui.relX(2),
		            left:ro.ui.relX(2),
		            top:ro.ui.relY(5),
		            focusable:false
		         }));
		         custHeaderView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		            text:'CUSTOMER INFORMATION',
		            font:{
		               fontSize:ro.ui.scaleFont(15, 0, 0),
		               fontWeight:'bold',
		               fontFamily:ro.ui.fontFamily
		            }
		         })));
		         var custInfoView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
		            layout:'vertical',
		            height:Ti.UI.SIZE,
		            top:ro.ui.relY(15)
		         }));
	
		         var custInfoTbl = Ti.UI.createTableView({
		            data:dataCust,
		            left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
		            scrollable:false,
		            height:Ti.UI.SIZE,
		            separatorColor:ro.ui.theme.separatorColor,
		            borderColor:ro.ui.theme.loginGray,
		            borderWidth:ro.ui.relX(1),
		            backgroundColor:'transparent'
		         });
		         custInfoView.add(custHeaderView);
		         custInfoView.add(custInfoTbl);
		         
		         var gateCodeTextField = Ti.UI.createTextField({
		         	font:{
		         		fontFamily:ro.ui.fontFamily,
		         		fontWeight:'bold',
		         		fontSize:ro.ui.scaleFont(11.5)
		         	},
		         	color:'black',
		         	paddingLeft:ro.ui.relX(5),
		         	top:0,
		         	left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
		            height:ro.ui.relY(45),
		            borderColor:ro.ui.theme.loginGray,
		            borderWidth:ro.ui.relX(1),
		            backgroundColor:'white',
		            hintTextColor:'gray',
		            hintText:'   Enter Gate Code (Optional)'
		         });
		         custInfoView.add(gateCodeTextField);
		         
		         if(Ti.App.Properties.hasProperty('gateCode')){
		            gateCodeTextField.value = Ti.App.Properties.getString('gateCode');
		         }
		         
		      }
	         //////////////////////////////
	         //   Cust Info if Delivery	 //
	         //////////////////////////////
	
	
	
	         //////////////////////////////
	         //     FAVORITE ORDERS		 //
	         //////////////////////////////
	         var favLbl = Ti.UI.createLabel(ro.combine( ro.ui.properties.newPayTxt, {
	            text:'Save order to favorites?',
	            hid:'savFavRow'
	         }));
	
	         var favLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(2),
	            left:ro.ui.relX(2),
	            top:ro.ui.relY(5),
	            focusable:false
	         }));
	         favLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'FAVORITE',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         })));
	
	         var favoriteView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {//Entire Favorite View
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:ro.ui.relY(15)
	         }));
	
	         var switchFav = Ti.UI.createSwitch({
	             value:false,
	             right:ro.ui.relX(5)
	         });
	
	         var favOrdTxtRow = Ti.UI.createView({
	            height:ro.ui.relY(40),
	            width:Ti.UI.FILL,
	            visible:true
	         });
	         var favOrdName = Ti.UI.createTextField(ro.combine( ro.ui.properties.newPayTxt, {
	            hintText:'    Name favorite order',
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            top:0,
	            height:Ti.UI.FILL,
	            width:Ti.UI.FILL,
	            backgroundColor:'white',
	            hintTextColor:'gray',
	            paddingLeft:ro.ui.relX(5),
	            borderColor:ro.ui.theme.txtFldBrd,
	            borderWidth:ro.ui.relX(1),
	            color:ro.ui.theme.txtFldTxt
	         }));
	         favOrdTxtRow.add(favOrdName);
	
	         var dataFav = [];
	         dataFav[0] = Ti.UI.createTableViewRow({
	            height:ro.ui.relY(43),
	            className:'favoriteName',
	            width:Ti.UI.FILL,
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            scrollable:false,
	            top:ro.ui.relY(5),
	            backgroundColor:'white'
	         });
	         dataFav[0].add(favLbl);
	         dataFav[0].add(switchFav);
	
	         var tableView1 = Ti.UI.createTableView({
	            data:dataFav,
	            height:Ti.UI.SIZE,
	            width:Ti.UI.FILL,
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            scrollable:false,
	            borderColor:ro.ui.theme.loginGray,
	            borderWidth:ro.ui.relX(1),
	            backgroundColor:'transparent'
	         });
	         favoriteView.add(favLblView);
	         favoriteView.add(tableView1);
	
	         if(Ti.App.Properties.hasProperty('favName')){
	            favOrdName.value = Ti.App.Properties.getString('favName');
	            switchFav.value = true;
	            favoriteView.add(favOrdTxtRow);
	         }
	         //////////////////////////////
	         //	   FAVORITE ORDERS END   //
	         //////////////////////////////
	
	         //////////////////////////////
	         //  	  PAYMENT OPTIONS    //
	         //////////////////////////////
	         var ccOnly = doesTotalExceedThreshold() || false;		
			var chosenCard;
			 var addPaymentLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(2),
	            left:ro.ui.relX(2),
	            top:ro.ui.relY(5),
	            focusable:false
	         }));
	         
	         
	         addPaymentLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'PAYMENT',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         })));
	         var addPaymentView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:ro.ui.relY(15)
	         }));
			
			var ccOnly = doesTotalExceedThreshold() || false;
	         Ti.API.debug('ccOnly: ' + ccOnly);
	         if(ccOnly){
	         	addPaymentView.add(getThresholdView());
	         }
			
			var addPayData = [];
			var addPaymentRow = Ti.UI.createTableViewRow({
	            className:'paymentOptions',
	            height:ro.ui.relY(43),
	            width:ro.ui.relX(345),
	            layout:'horizontal',
	            backgroundColor:'white'
	         });
	         var addPaymentLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
	            text:"ADD PAYMENT"
	         }));
	         addPaymentRow.add(addPaymentLbl);
			addPayData.push(addPaymentRow);
			
	         var tblView2 = Ti.UI.createTableView({
	            data:addPayData,
	            height:Ti.UI.SIZE,
	            separatorColor:ro.ui.theme.separatorColor,
	            borderColor:ro.ui.theme.loginGray,
	            borderWidth:ro.ui.relX(1),
	            scrollable:false,
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            backgroundColor:'transparent'
	         });
	         var toggleTblView2Vis = function(newVis){
	         	tblView2.visible = newVis;
	         	tblView2.height = newVis ? Ti.UI.SIZE : 0;
	         };
	         addPaymentView.add(addPaymentLblView);
	         addPaymentView.add(tblView2);
	         
	         
	         var allowMultiPmts = storeObj.Configuration.AllowMultiPmts;
	         var doingMultiPmts = false;
	         var MultiplePmtHelper = require('logic/MultiplePmtHelper');
			 var multiPmts = MultiplePmtHelper.GetMultiPmts();
			 
	         if(true || allowMultiPmts){
	         	 var mp = require('logic/MultiplePmtHelper');
	         	 
		         var mpView = mp.GetView(!multiPmts.DoMultiPmts ? (isPaymentValid() ? true : false) : false, toggleTblView2Vis);
		         mpView.visible = true;				
				 addPaymentView.add(mpView);
				 
				 if(multiPmts && multiPmts.DoMultiPmts){
					paymentValid = MultiplePmtHelper.IsPaymentValid();
				 	if(paymentValid){
				 		toggleTblView2Vis(false);
				 	}
			 	 }
			 	 else{
			 	 	if(isPaymentValid()){
			 	 		toggleTblView2Vis(false);
			 	 	}
			 	 }
				 
	         }
			
			
	         //////////////////////////////
	         //  	  PAYMENT OPTIONS    //
	         //////////////////////////////		
	
	         //////////////////////////////
	         //  	  PAYMENT OPTIONS    //
	         //////////////////////////////
	         
	         //var ccOnly = doesTotalExceedThreshold() || false;
	         //Ti.API.debug('ccOnly: ' + ccOnly);
	         
	         /*var chosenCard = payControl.hasChosenCard();
	         var creditRow = Ti.UI.createTableViewRow({
	            className:'paymentOptions',
	            height:ro.ui.relY(43),
	            width:ro.ui.relX(345),
	            layout:'horizontal',
	            isCredit:true,
	            rightImage:chosenCard?'/images/check.png':'',
	            backgroundColor:'white'
	         });
	         var creditLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
	            text:chosenCard?'CREDIT CARD\t\t\t' + Ti.App.OrderObj.ordOnlineOptions.CCInfo.CardInfo.toUpperCase() + '\t\t **-' + ccControl.getLastFour(Ti.App.OrderObj.ordOnlineOptions.CCInfo.OLCardNum):'CREDIT CARD',
	            hasChecked:chosenCard?true:false
	         }));
	         creditRow.add(creditLbl);*/
	         var otherPayRow, otherPayLbl;
	
	         //var chosenGiftCard = payControl.hasChosenGiftCard();
	
	         switch(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	            case true:
	               if(storeObj.Configuration.AllowCCDelivery && storeObj.Configuration.CardTypes){
	                  //data1.push(creditRow);
	                  hasCC = true;
	               }
	               if(storeObj.Configuration.AllowPayUponDelivery && storeObj.Configuration.PayUponOptions){
	                  /*for(var k=0; k<storeObj.Configuration.PayUponOptions.length; k++){
	                     otherPayLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
	                        text:(chosenGiftCard && (storeObj.Configuration.PayUponOptions[k]==='GIFT'))?storeObj.Configuration.PayUponOptions[k]+'\t\t\t XXXX':storeObj.Configuration.PayUponOptions[k]
	                     }));
	                     otherPayRow = Ti.UI.createTableViewRow({
	                        className:'paymentOptions',
	                        height:ro.ui.relY(43),
	                        width:ro.ui.relX(345),
	                        layout:'horizontal',
	                        isCredit:false,
	                        rightImage:(chosenGiftCard && (storeObj.Configuration.PayUponOptions[k]==='GIFT'))?'/images/check.png':'',
	                        hasChecked:false,
	                        rowName:storeObj.Configuration.PayUponOptions[k],
	                        isGiftCard:storeObj.Configuration.PayUponOptions[k]==='GIFT'?true:false,
	                        backgroundColor:'white'
	                     });
	                     otherPayRow.add(otherPayLbl);
	                     if(!ccOnly || (storeObj.Configuration.PayUponOptions[k]==='GIFT')){
	                     	data1.push(otherPayRow);
	                     }
	                  }*/
	                  hasPayupon = true;
	               }
	               break;
	            case false:
	               if(storeObj.Configuration.AllowCCPickup && storeObj.Configuration.CardTypes){
	                  //data1.push(creditRow);
	                  hasCC = true;
	               }
	               if(storeObj.Configuration.AllowPayUponPickup && storeObj.Configuration.PayUponOptions){
	                  /*for(var k=0; k<storeObj.Configuration.PayUponOptions.length; k++){
	                     otherPayLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
	                        text:(chosenGiftCard && (storeObj.Configuration.PayUponOptions[k]==='GIFT'))?storeObj.Configuration.PayUponOptions[k]+'\t\t XXXX':storeObj.Configuration.PayUponOptions[k]
	                     }));
	                     otherPayRow = Ti.UI.createTableViewRow({
	                        className:'paymentOptions',
	                        height:ro.ui.relY(43),
	                        width:ro.ui.relX(345),
	                        layout:'horizontal',
	                        isCredit:false,
	                        rightImage:(chosenGiftCard && (storeObj.Configuration.PayUponOptions[k]==='GIFT'))?'/images/check.png':'',
	                        hasChecked:false,
	                        rowName:storeObj.Configuration.PayUponOptions[k],
	                        isGiftCard:storeObj.Configuration.PayUponOptions[k]==='GIFT'?true:false,
	                        backgroundColor:'white'
	                     });
	                     otherPayRow.add(otherPayLbl);
	                     if(!ccOnly || (storeObj.Configuration.PayUponOptions[k]==='GIFT')){
	                     	data1.push(otherPayRow);
	                     }
	                  }*/
	                  hasPayupon = true;
	               }
	               break;
	         }
	
				/*var paymentLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(2),
	            left:ro.ui.relX(2),
	            top:ro.ui.relY(5),
	            focusable:false
	         }));
	         
	         
	         paymentLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'PAYMENT',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         })));
	         var paymentView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:ro.ui.relY(15)
	         }));
	
				var levelupRowCount = 0;
				if(!ccOnly && levelUp.isLU && levelUp.isEnabled()){//This will be the check that if true will display levelUp as a payment option.
					var lvlupDone = Ti.App.Properties.getBool('lvlupBool', false);
					var levelupLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		               text:'REWARDS'
		            }));
	            var levelupRow = Ti.UI.createTableViewRow({
	               className:'paymentOptions',
	               height:ro.ui.relY(43),
	               width:ro.ui.relX(345),
	               layout:'horizontal',
	               isCredit:false,
	               isLevelup:true,
	               rightImage:lvlupDone?'/images/check.png':'',
	               hasChecked:lvlupDone?true:false,
	               rowName:'levelup',
	               isGiftCard:false,
	               backgroundColor:'white'
	            });
	            levelupRow.add(levelupLbl);
	            data1.push(levelupRow);
	            levelupRowCount = 1;
	
	            if(lvlupDone){
	            	var test = Ti.App.OrderObj;
	               test.IsOnline = true;
	               test.DisplayOrdPayment = 'LEVELUP';
	               Ti.App.OrderObj = test;
	            }
	       	}
	
	         var payRowCount;
	         if(storeObj.Configuration.PayUponOptions){
	            payRowCount = 1+storeObj.Configuration.PayUponOptions.length + levelupRowCount;
	         }
	         else{
	            payRowCount = 1 + levelupRowCount;
	         }
	
			
				var paymentLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(2),
	            left:ro.ui.relX(2),
	            top:ro.ui.relY(5),
	            focusable:false
	         }));
	         
	         
	         paymentLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'PAYMENT',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         })));
	         var paymentView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:ro.ui.relY(15)
	         }));
	
	         var tableView2 = Ti.UI.createTableView({
	            data:data1,
	            height:Ti.UI.SIZE,
	            separatorColor:ro.ui.theme.separatorColor,
	            borderColor:ro.ui.theme.loginGray,
	            borderWidth:ro.ui.relX(1),
	            scrollable:false,
	            left:ro.ui.relX(2),
	            right:ro.ui.relX(2),
	            backgroundColor:'transparent'
	         });
	         
	         if(ccOnly){
	         	paymentView.add(getThresholdView());
	         }
	         
	         paymentView.add(paymentLblView);
	         paymentView.add(tableView2);
	         
	         var allowMultiPmts = storeObj.Configuration.AllowMultiPmts;
	         var doingMultiPmts = false;
	         var MultiplePmtHelper = require('logic/MultiplePmtHelper');
			 var multiPmts = MultiplePmtHelper.GetMultiPmts();
	         if(allowMultiPmts){
	         	
	         	try{
	         		var MultiPmtView = Ti.UI.createView({
			         	height:Ti.UI.SIZE,
			         	//height:0,
			         	top:0,
			         	width:Ti.UI.FILL,
			         	layout:'horizontal',
			         	backgroundColor:'#eeece6'
			         });
			         var MultiPmtLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
			               text:'Split Payments? (Click Me)'
			            }));
			         var MultiPmtSwitch = Ti.UI.createSwitch(ro.combine(ro.ui.properties.defaultSwitch, {
				        //title:"Split Payments? (Click Me)",
				        //bottom:ro.ui.relY(15),
				        //top:ro.ui.relY(10),
				        backgroundColor:'black',
				        value:multiPmts && multiPmts.DoMultiPmts ? true : false
				     }));
				     MultiPmtSwitch.addEventListener('change', function(e){
				     	//Ti.API.debug('e: ' + JSON.stringify(e));
				     	multiPmts.DoMultiPmts = e.value;
				     	if(!e.value){
				     		multiPmts.MultiPmts = [];
				     		mpView.visible = false;
				     	}
				     	else{
				     		mpView.visible = true;
				     	}
				     	MultiplePmtHelper.SaveMultiPmts();
				     	//doingMultiPmts = e.value;
				     });
				     
				     //MultiPmtSwitch.value = 
			         
			         MultiPmtView.add(MultiPmtLbl);
			         MultiPmtView.add(MultiPmtSwitch);
			         paymentView.add(MultiPmtView);
			         
			         var mp = require('logic/MultiplePmtHelper');
			         var mpView = mp.GetView();				
					 paymentView.add(mpView);
	         	}
	         	catch(ex){
	         		Ti.API.debug('ex: ' + ex);
	         	}
	         	
	         }*/
	         //var 
	         
	         
	         //paymentView.height = ro.ui.relY(35) + (data1.length * ro.ui.relY(43));
	         //////////////////////////////
	         //   PAYMENT OPTIONS END    //
	         //////////////////////////////
	
	
	         //////////////////////////////
	         //  	 		TIPS BEGIN   	 //
	         //////////////////////////////
	
				//chosenCard
				//lvlupDone
				//chosenGiftCard
	         var tipsView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:0
	         }));
	         if(false && ((chosenCard && Config.AllowCCTips) || (lvlupDone && Config.AllowLUTips) || (chosenGiftCard && Config.AllowGiftTips))){
	         	try{
		         	tipsView.top = ro.ui.relY(15);
		         	//tipsView.add(CC_TIPS.getTipView(tipsView));
		         	CC_TIPS.getTipView(tipsView);
		         }
		         catch(ex){
		         	Ti.API.debug('ex: ' + ex);
		         }
	         }
	
	         //////////////////////////////
	         //  	 		TIPS END    	 //
	         //////////////////////////////
	         
	         //////////////////////////////
	         //  	 		MultiPmtsTicket BEGIN   	 //
	         //////////////////////////////
	
				//chosenCard
				//lvlupDone
				//chosenGiftCard
	         /*var multiPmtTicketView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
	            layout:'vertical',
	            height:Ti.UI.SIZE,
	            top:0
	         }));
	         if((chosenCard && Config.AllowCCTips) || (lvlupDone && Config.AllowLUTips) || (chosenGiftCard && Config.AllowGiftTips)){
	         	try{
		         	tipsView.top = ro.ui.relY(15);
		         	//tipsView.add(CC_TIPS.getTipView(tipsView));
		         	CC_TIPS.getTipView(tipsView);
		         }
		         catch(ex){
		         	Ti.API.debug('ex: ' + ex);
		         }
	         }*/
	
	         //////////////////////////////
	         //  	 		MultiPmtsTicket END    	 //
	         //////////////////////////////
	
	
	         var btnSubmit = layoutHelper.getBigButton('SUBMIT ORDER');
	
	         //////////////////////////////
	         //		  FUTURE ORDERS 	  	 //
	         //////////////////////////////
	         if(Ti.App.allowFuture){
	         	var getFuture = Ti.App.Properties.getString('futureOrder');
	         	var futureData = [];
		         var futureLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	               right:ro.ui.relX(2),
	               left:ro.ui.relX(2),
	               top:ro.ui.relY(5),
	               focusable:false
	            }));
	            futureLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	               text:'ORDER TIME',
	               font:{
	                  fontSize:ro.ui.scaleFont(15, 0, 0),
	                  fontWeight:'bold',
	                  fontFamily:ro.ui.fontFamily
	               }
	            })));
	
		         var futureRow = Ti.UI.createTableViewRow({
		            className:'future',
		            height:ro.ui.relY(43),
		            width:ro.ui.relX(345),
		            layout:'horizontal',
		            rightImage:getFuture?'/images/check.png':'',
	               backgroundColor:'white'
		         });
	
		         var futureLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		            text:getFuture?JSON.parse(getFuture).displayTxt:'NOW'
		         }));
		         futureRow.add(futureLbl);
	
		         futureRow.addEventListener('click', function(e){
		         	if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		         	if(!saveFav() || !saveOrdNote() || !saveGateCode()){
		            	return;
		            }
		            //payControl.clearPaymentInfo();
		         	ro.ui.cartShowNext({ addView:true, showing:'futOrd' });
		         });
	
		         var futureView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
		            layout:'vertical',
		            height:Ti.UI.SIZE,
		            top:ro.ui.relY(15)
		         }));
		         futureData.push(futureRow);
	
		         var tableViewFuture = Ti.UI.createTableView({
		            data:futureData,
		            height:Ti.UI.SIZE,
		            borderColor:ro.ui.theme.loginGray,
	               borderWidth:ro.ui.relX(1),
		            scrollable:false,
		            left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
	               backgroundColor:'transparent'
		         });
		         futureView.add(futureLblView);
		         futureView.add(tableViewFuture);
		      }
	         //////////////////////////////
	         //		FUTURE ORDERS END	  	 //
	         //////////////////////////////
	
	
	         //////////////////////////////
	         //	  SPECIAL INSTRUCTIONS   //
	         //////////////////////////////
	         var allowNote = payControl.allowNoteFn();
	         if(allowNote){
		         var tableView3Head = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		            left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
		            top:ro.ui.relY(5)
		         }));
		         var tableView3Title = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		            text:'SPECIAL INSTRUCTIONS:',
		            font:{
		               fontSize:ro.ui.scaleFont(15),
		               fontWeight:'bold',
		               fontFamily:ro.ui.fontFamily
		            }
		         }));
		         tableView3Head.add(tableView3Title);
	
		         var spclInstView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {//Entire Special Instructions View
		            layout:'vertical',
		            height:Ti.UI.SIZE,
		            //height:ro.ui.relY(200),
		            top:ro.ui.relY(15)//,
		            //bottom:ro.ui.relY(75)
		         }));
	
		         var tableView3TA = Ti.UI.createTextArea(ro.combine(ro.ui.properties.allTxtField, {
		            maxLength:32,
		            height:ro.ui.relY(80),
	               backgroundColor:'white',
		            value:'',
		            left:ro.ui.relX(2),
		            right:ro.ui.relX(2),
		            scrollable:false,
		            font:{
		               fontSize:ro.ui.scaleFont(11,0,0),
	            		fontFamily:ro.ui.fontFamily
		            }
		         }));
	
		         spclInstView.add(tableView3Head);
		         spclInstView.add(tableView3TA);
	
		         if(Ti.App.Properties.hasProperty('spclInst')){
		            tableView3TA.value = Ti.App.Properties.getString('spclInst');
		         }
		      }
		      //////////////////////////////
	         //	SPECIAL INSTRUCTIONS END //
	         //////////////////////////////
	
	
			  function isPaymentValid(){
			  	var paymentValid = false;
	
	            if(Ti.App.OrderObj.DisplayOrdPayment){
	               if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'credit'){
	                  paymentValid = payControl.hasChosenCard();//returns true if creditcard object exists and has all neccessary information. Otherwise returns false.
	               }
	               else if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup'){
	               	paymentValid = true;
	               	var test = Ti.App.OrderObj;
	               	test.LUToken = levelUp.getToken();
	               	if(!test.LUToken || !test.LUToken.length){
	               		if(CustInfo.LUToken){
	               			test.LUToken = CustInfo.LUToken;
	               		}
	               	}
	               	Ti.App.OrderObj = test;
	               	test = null;
	               }
	               else{
	                  if(storeObj.Configuration.PayUponOptions){
	                     for(var i=0; i<storeObj.Configuration.PayUponOptions.length; i++){
	                        if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == storeObj.Configuration.PayUponOptions[i].toLowerCase()){
	                           paymentValid = true;
	                           break;
	                        }
	                     }
	                  }
	               }
	            }
				return paymentValid;
			  }
			  
		      function saveFav(){
		      	try{
	               if(switchFav && switchFav.value){
	               	  favVal = favVal || require("validation/favesValidation");
	                  if(!favVal.favNameValidate(favOrdName.value)){
	                  	ro.ui.hideLoader();
	                     return false;
	                  }
	               }
	               return true;
	            }
	            catch(ex){
	               if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('saveFav()-Exception: ' + ex); }
	            }
		      }
		      function saveOrdNote(){
		      	try{
			      	if(allowNote){
			            if(tableView3TA.value && tableView3TA.value.length > 0){
			               if(tableView3TA.value.length > 32){
			                  ro.ui.alert('Error: ', 'Special Instructions must not exceed 32 characters.');
			                  ro.ui.hideLoader();
			                  return false;
			               }
			               //Ti.include('/validation/regexValidation.js');
			               regexVal = regexVal || require("validation/regexValidation");
			               var spSuccess = regexVal.regExValidate({spclInst:tableView3TA.value});
			               if(spSuccess.value){
			                  Ti.App.Properties.setString('spclInst', tableView3TA.value);
			               }
			               else{
			                  ro.ui.alert('Error: ', spSuccess.issues[0]);
			                  ro.ui.hideLoader();
			                  return false;
			               }
			            }
			         }
			         return true;
			      }
			      catch(ex){
			      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('saveOrdNote()-Exception: ' + ex); }
			      }
		      }
		      function saveGateCode(){
		      	 try{
		      	 	if(gateCodeBln && gateCodeTextField.value && gateCodeTextField.value.length > 0){
		      	 		if(gateCodeTextField.value.length > 12){
		                   ro.ui.alert('Error: ', 'Gate Code must not exceed 12 characters.');
		                   ro.ui.hideLoader();
		                   return false;
		                }
		                //Ti.include('/validation/regexValidation.js');
		                regexVal = regexVal || require("validation/regexValidation");
		                var gateCodeSuccess = regexVal.regExValidate({gateCode:gateCodeTextField.value});
			            if(gateCodeSuccess.value){
		                   Ti.App.Properties.setString('gateCode', gateCodeTextField.value);
		                }
		                else{
		                   ro.ui.alert('Error: ', gateCodeSuccess.issues[0]);
		                   ro.ui.hideLoader();
		                   return false;
		                }
		      	 	}
		      	 	else{
		      	 		//payControl.clearGateCode();
		      	 		ro.utils.removeProp('gateCode');
		      	 	}
		      	 	return true;
		      	 }
		      	 catch(ex){
		      	 	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('saveGateCode()-Exception: ' + ex); }
		      	 }
		      }
	
	
		      //////////////////////////////
	         //  	  EVENT LISTENERS     //
	         //////////////////////////////
	
	
	         switchFav.addEventListener('change', function(e){
	            try{
		            if(e.value){
		               favoriteView.add(favOrdTxtRow);
		            }
		            else{
		               //payControl.clearFavoriteProp();
		               ro.utils.removeProp('favName');
		               favOrdName.value = '';
		               favoriteView.remove(favOrdTxtRow);
		               if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		            }
		         }
		         catch(ex){
		         	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('switchFav(event)-Exception: ' + ex); }
		         }
	         });
	
			var paymentLastClickTime = 0;
			tblView2.addEventListener('click', function(e){
				//alert();
				if(new Date().getTime() - paymentLastClickTime < 350){
	      			Ti.API.debug('returning');
	      			return;
	      		}
	      		var thisClickTime = new Date();
	      		paymentLastClickTime = thisClickTime.getTime();
	      		thisClickTime = null;
	
	            if(!saveFav() || !saveOrdNote() || !saveGateCode()){
	            	return;
	            }
	            
	            
	            ro.ui.cartShowNext({addView:true, showing:'addPmt'});
			});
	
				/*var paymentLastClickTime = 0;
	         tableView2.addEventListener('click', function(e){
	
	         	if(new Date().getTime() - paymentLastClickTime < 350){
	      			Ti.API.debug('returning');
	      			return;
	      		}
	      		var thisClickTime = new Date();
	      		paymentLastClickTime = thisClickTime.getTime();
	      		thisClickTime = null;
	
	            if(!saveFav() || !saveOrdNote() || !saveGateCode()){
	            	return;
	            }
	            var DoMultiPmts = false;
	            //SaveMultiPmts();
	            if(multiPmts && multiPmts.DoMultiPmts){
	            	DoMultiPmts = true;
	            	var HRushAlertView = ca.createCustomAlert();
	            }
	            else{
	            	if(e.row.isCredit){
		            	CC_TIPS.clearTip();
		            	Ti.App.Properties.setBool('lvlupBool', false);
		               try{
		                  payControl.clearPaymentInfo();
		                  ro.ui.cartShowNext({addView:true, showing:ccControl.hasSavedCards()?'Payment':'AddPayment'});
		               }
		               catch(ex){
		                  alertDiag.title = 'Error';
		                  alertDiag.message = 'Please try again.';
		                  alertDiag.show();
		               }
		            }
		            else if(e.row.isGiftCard){
		               try{
		               	Ti.App.Properties.setBool('lvlupBool', false);
		                  payControl.clearPaymentInfo();
		                  ro.ui.cartShowNext({addView:true, showing:'GiftC'});
		               }
		               catch(ex){
		                  alertDiag.title = 'Error';
		                  alertDiag.message = 'Please try again.';
		                  alertDiag.show();
		               }
		            }
		            else if(e.row.isLevelup){
		            	try{
		                  payControl.clearPaymentInfo();
		                  var lvlWebBool = true;
		                  if(CustInfo.LUToken){
		                  	lvlWebBool = false;
		                  }
				       	 	if(levelUp.isLU && levelUp.needsWebview() && lvlWebBool){//if this is true, then add webView to currwindow or screen...
				       	 		CC_TIPS.clearTip();
				       	 		ro.ui.cartShowNext({addView:true, showing:'levelup'});
				       	 	}
				       	 	else{//if not true, this returns the LU_TOKEN that should be attached to the OrderObject before sending the order to the store.
				       	 		//Ti.App.OrderObj.Customer.LU_TOKEN = webView;
				       	 		REV_CUSTOMER.changeEClubOptIn(1, true, function(){});
				       	 		if(!Config.AllowLUTips){
				       	 			CC_TIPS.clearTip();
				       	 			tipsView.top = 0;
		            				tipsView.removeAllChildren();
				       	 		}
				       	 		else{
				       	 			if(!tipsView.children || !tipsView.children.length){
				       	 				tipsView.top = ro.ui.relY(15);
				       	 				CC_TIPS.getTipView(tipsView);
				       	 			}
				       	 			else{
				       	 				CC_TIPS.clearTip();
				       	 				//tipsView.top = 0;
		            					tipsView.removeAllChildren();
		            					CC_TIPS.getTipView(tipsView);
				       	 			}
				       	 		}
		
				       	 		creditLbl.text = 'CREDIT CARD';
				               creditRow.hasChecked = false;
				               creditRow.rightImage = '';
		
				       	 		var rowLngth = this.sections[0].rows.length;
		
				               for(var i=0; i<rowLngth; i++){
				                  if(e.row.rowName != this.sections[0].rows[i].rowName){
				                     this.sections[0].rows[i].hasChecked = false;
				                     this.sections[0].rows[i].rightImage = '';
				                     if(this.sections[0].rows[i].rowName === 'GIFT'){
				                        try{
				                           this.sections[0].rows[i].children[0].text = 'GIFT';
				                        }
				                        catch(ex){
				                           if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('giftCard Display Text - Exception: ' + ex); }
				                        }
				                     }
				                  }
				               }
		
				       	 		e.row.hasChecked = true;
				               e.row.rightImage = '/images/check.png';
	
		                     
				               var test = Ti.App.OrderObj;
				               test.IsOnline = true;
				               test.DisplayOrdPayment = 'LEVELUP';//e.row.children[0].text.replace(' ', '');
				               if(!test.LUToken || !test.LUToken.length){
				               	test.LUToken = CustInfo.LUToken?CustInfo.LUToken:'';
				               }
				               Ti.App.OrderObj = test;
		
				       	 	}
		               }
		               catch(ex){
		                  alertDiag.title = 'Error';
		                  alertDiag.message = 'Please try again.';
		                  alertDiag.show();
		               }
		            }
		            else{
		            	//tipsView.height = 0;
		            	tipsView.top = 0;
		            	tipsView.removeAllChildren();
		            	CC_TIPS.clearTip();
		
		            	Ti.App.Properties.setBool('lvlupBool', false);
		               payControl.clearPaymentInfo();
		               creditLbl.text = 'CREDIT CARD';
		               creditRow.hasChecked = false;
		               creditRow.rightImage = '';
		
		               var rowLngth = this.sections[0].rows.length;
		
		               for(var i=0; i<rowLngth; i++){
		                  if(e.row.rowName != this.sections[0].rows[i].rowName){
		                     this.sections[0].rows[i].hasChecked = false;
		                     this.sections[0].rows[i].rightImage = '';
		                     if(this.sections[0].rows[i].rowName === 'GIFT'){
		                        try{
		                           this.sections[0].rows[i].children[0].text = 'GIFT';
		                        }
		                        catch(ex){
		                           if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('giftCard Display Text - Exception: ' + ex); }
		                        }
		                     }
		                  }
		               }
		
		               e.row.hasChecked = true;
		               e.row.rightImage = '/images/check.png';
		
		               var test = Ti.App.OrderObj;
		               test.IsOnline = true;
		               test.DisplayOrdPayment = e.row.children[0].text.replace(' ', '');
		               Ti.App.OrderObj = test;
		            }
	            }
	
	            
	         });*/
	
				var submitLastClickTime = 0;
	         btnSubmit.addEventListener('click', function(e){
	         	if(new Date().getTime() - submitLastClickTime < 350){
	      			Ti.API.debug('returning');
	      			return;
	      		}
	      		var thisClickTime = new Date();
	      		submitLastClickTime = thisClickTime.getTime();
	      		thisClickTime = null;
	      		
	      		ro.ui.showLoader();
	            if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	
					if(doPrivacy){
						if(!privacyPolicy.hasAccepted()){
		         		ro.ui.hideLoader();
		         		return;
		         	}
					}
	
	            if(!saveFav() || !saveOrdNote() || !saveGateCode()){
	            	return;
	            }
	
	            var paymentValid = false;
				
				
	            if(Ti.App.OrderObj.DisplayOrdPayment && (!multiPmts || !multiPmts.DoMultiPmts)){
	               if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'credit'){
	                  paymentValid = payControl.hasChosenCard();//returns true if creditcard object exists and has all neccessary information. Otherwise returns false.
	               }
	               else if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup'){
	               	paymentValid = true;
	               	var test = Ti.App.OrderObj;
	               	test.LUToken = levelUp.getToken();
	               	if(!test.LUToken || !test.LUToken.length){
	               		if(CustInfo.LUToken){
	               			test.LUToken = CustInfo.LUToken;
	               		}
	               	}
	               	Ti.App.OrderObj = test;
	               	test = null;
	               }
	               else{
	                  if(storeObj.Configuration.PayUponOptions){
	                     for(var i=0; i<storeObj.Configuration.PayUponOptions.length; i++){
	                        if(Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == storeObj.Configuration.PayUponOptions[i].toLowerCase()){
	                           paymentValid = true;
	                           break;
	                        }
	                     }
	                  }
	               }
	            }
	            else if(allowMultiPmts && multiPmts && multiPmts.DoMultiPmts){
					paymentValid = MultiplePmtHelper.IsPaymentValid();
					if(paymentValid){
						for(var i=0, iMax=multiPmts.MultiPmts.length; i<iMax; i++){
							multiPmts.MultiPmts[i].PaymentAmt = parseFloat(multiPmts.MultiPmts[i].PaymentAmt);
						}
						var test = Ti.App.OrderObj;
						var ccInfoCol = MultiplePmtHelper.GetCCInfoCol();
						test.ordOnlineOptions.CCInfoCol = ccInfoCol;//multiPmts.MultiPmts;
						test.DisplayOrdPayment = ccInfoCol && ccInfoCol.length ? (ccInfoCol[0].IsGiftCard ? "Gift" : "Credit") : (multiPmts.MultiPmts && multiPmts.MultiPmts.length ? multiPmts.MultiPmts[0].CardInfo : "Cash");
						Ti.App.OrderObj = test;
						test = null;
					}
				}
	
	            if(!paymentValid){
	               ro.ui.alert('Error: ', 'Please select mode of payment.');
	               ro.ui.hideLoader();
	               return;
	            }
	
				if(doNoEClubLoyalty){
					ro.REV_LOYALTY.setNoEClubOrderObject();
				}
				else if(isSpecialLtyNoEclub){
					var optInVal = ro.REV_LOYALTY.setNoEClubOrderObject();
					//var optInVal = ro.REV_LOYALTY.getChosenLtyOptIn();
					//Ti.API.debug('optInVal: ' + optInVal);
					//Ti.API.debug('rs.LtyOptIn: ' + rs.LtyOptIn);
			   	 	/*if(!rs.hasOwnProperty('LtyOptIn') || (rs.LtyOptIn  !== optInVal)){
			   	 		Ti.API.debug('222optInVal: ' + optInVal);	
				   	 	//rs.LtyOptIn = optInVal;
				   	 	//db.updateCustomerObj(Ti.App.Username, rs);
				   	 	//REV_CUSTOMER.changeLtyOptIn(optInVal, true, function(){});
				   	 }*/
				}
				else if(Ti.App.OrderObj.DisplayOrdPayment && Ti.App.OrderObj.DisplayOrdPayment.length && Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup'){
	               ro.REV_LOYALTY.setNoEClubOptOut(1);
	               //sends false for the optout property since they obviously signed up for levelup and are paying with levelup
	            }
	            else{
	               ro.REV_LOYALTY.setNoEClubOptOut(CustInfo.LtyOptIn);
	            }
				
	            if(doLoyalty){
	               ro.REV_LOYALTY.setOrderObject();
	            }
	            else if(Ti.App.OrderObj.DisplayOrdPayment && Ti.App.OrderObj.DisplayOrdPayment.length && Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup'){
	               ro.REV_LOYALTY.setOptOut(1);
	               //sends false for the optout property since they obviously signed up for levelup and are paying with levelup
	            }
	            else{
	               ro.REV_LOYALTY.setOptOut(CustInfo.EClubOptIn);
	            }
	
	            var gateCode = null;
	
	            if(storeObj.Configuration.CHECKOUT_POPUP_TITLE){
	               var popup = Ti.UI.createAlertDialog({});
	               popup.title = storeObj.Configuration.CHECKOUT_POPUP_TITLE;
	               popup.buttonNames = ['OK'];
	               popup.addEventListener('click', payControl.CHK_ALERT);
	               popup.message = payControl.calcAmt(storeObj.Configuration.CHECKOUT_POPUP_MESSAGE && storeObj.Configuration.CHECKOUT_POPUP_MESSAGE.length>0? storeObj.Configuration.CHECKOUT_POPUP_MESSAGE:'');
	               popup.show();
	            }
	            else{
	               payControl.processOrder();
	            }
	         });
	         //////////////////////////////
	         //    EVENT LISTENERS END   //
	         //////////////////////////////
	
	         if(hasCC || hasPayupon){
	            mainScroll.add(ordTypeView);
	            mainScroll.add(ltyNewView);
	            if(isGuest && !isDeliv){
	               mainScroll.add(guestInfoView);
	            }
	            if(isDeliv){
	            	mainScroll.add(custInfoView);
	            }
	
	            if(favCount<5){
	               mainScroll.add(favoriteView);
	            }
	            if(Ti.App.allowFuture){
	            	mainScroll.add(futureView);
	            }
	            mainScroll.add(addPaymentView);
	            //mainScroll.add(paymentView);
	            mainScroll.add(tipsView);
	            if(allowNote){
	            	mainScroll.add(spclInstView);
	            }
	         }
	         else{
	            ////CALL THE STORE TO INFORM
	            doPrivacy = false;
	            var noOptionsLbl = Ti.UI.createLabel({
	               text:storeObj.Name,
	               font:{
	                  fontSize:ro.ui.scaleFont(14,0,0),
	                  fontWeight:'bold',
	            		fontFamily:ro.ui.fontFamily
	               },
	               color:ro.ui.theme.backgroundpngTxt,
	               width:ro.ui.relX(200),
	               left:ro.ui.relX(15),
	               top:ro.ui.relY(50),
	               height:ro.ui.relY(25)
	            });
	            var btnPhone = Ti.UI.createButton({
	               height:ro.ui.relY(24),
	               right:ro.ui.relX(65),
	               width:ro.ui.relX(24),
	               top:ro.ui.relY(50),
	               backgroundImage:'/images/phone.png',
	               backgroundSelectedImage:'/images/phone.png'
	            });
	
	            var noOptionsText = Ti.UI.createLabel({
	               font:{
	                  fontSize:ro.ui.scaleFont(12,0,0),
	            		fontFamily:ro.ui.fontFamily
	               },
	               left:ro.ui.relX(15),
	               top:ro.ui.relY(80),
	               height:Ti.UI.SIZE,
	               text:storeObj.Name + ' has not enabled payment options. Please call the store for further information.',
	               color:ro.ui.theme.noOptionsTxt
	            });
	            btnPhone.addEventListener('click', payControl.phoneClickControl);
	
	            var padding = Ti.UI.createView();
	            padding.add(noOptionsText);
	            padding.add(btnPhone);
	            padding.add(noOptionsLbl);
	            mainScroll.add(padding);
	         }
	
			 if(doLoyalty){
	            var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView();
	            LoyaltyView.top = ro.ui.relY(15);
	            mainScroll.add(LoyaltyView);
	         }
	         if(doNoEClubLoyalty /*&& !specialLtyBln*/){
	         	var LoyaltyNoEClubView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(null, null, true);
	            LoyaltyNoEClubView.top = ro.ui.relY(15);
	            mainScroll.add(LoyaltyNoEClubView);
	         }
	
	         if(doPrivacy){
		         var webViewParent = Ti.UI.createView({
		         	height:0,
		         	width:Ti.UI.FILL
		         });
		         checkoutView.add(webViewParent);
	
		         var policyView = privacyPolicy.getNewPolicyView(webViewParent);
		         policyView.top = ro.ui.relY(15);
					mainScroll.add(policyView);
		      }
	
		      btnSubmit.top = ro.ui.relY(15);
		      if(hasCC || hasPayupon){
		      	mainScroll.add(btnSubmit);
		      	mainScroll.add(emptyView);
		      }
		      checkoutView.add(mainScroll);
		      var postLayoutEvt = function(){
		      	//checkoutView.removeEventListener('postlayout', postLayoutEvt);
		      	
		      	/*if(DoMultiPmts){
		      		
		      	}*/
		      	
		      	if(storeObj.Configuration.LTY_CHK_PTS && storeObj.Configuration.LTY_CHK_PTS.length){
					var foundMatch = false;
					var showEnrollMsg = false;
					
					//if(!Ti.App.isGuest){
					//isLtyNoEclub
					var isCustEnrolled = !isGuest && rs && rs.LtyOptIn==1;	//needs actual logic
					
					switch(storeObj.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase()){
						case 'all':
							showEnrollMsg = !isCustEnrolled;
							foundMatch = true;
							break;
						case 'enrolled':
							showEnrollMsg = false;
							foundMatch = isCustEnrolled;	// will need real logic
							break;
						case 'notenrolled':
							showEnrollMsg = true;
							foundMatch = !isCustEnrolled; // will need real logic
							break;
						case 'none':
							showEnrollMsg = false;
							foundMatch = false; 
							break;
						default:
							//alert('default case: ' + storeObj.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase());
							break;
					}
					if(isGuest){
						showEnrollMsg = false;
					}
					
					var req = {
						Email:isGuest ? null : Ti.App.Username,
						RevKey:'test',
						CompressResponse:false,
						StoreID:storeObj.ID,
						OrderObj:Ti.App.OrderObj
					};
					//Ti.API.debug('foundMatch: ' + foundMatch);
					if(foundMatch){
						ro.ui.showLoader();
						ro.dataservice.post(req, 'GetLtyPoints', function(response){
							//alert('response: ' + JSON.stringify(response));
						    if(response){
						        if(response.Success && response.Points && response.Points > 0){
						        	ShowLtyView(response, showEnrollMsg);
						        }
						        else{
						        	
						        }
						        ro.ui.hideLoader();
						     }
						     else{
						     	ro.ui.hideLoader();
						     }
					    });
					}
				}
		      };
				//checkoutView.addEventListener('postlayout', postLayoutEvt);
				postLayoutEvt();
	         return checkoutView;
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('ro.ui.createNewPayView()-Exception: ' + ex); }
	      }
	   };
	};
	return {
		oldnewpaymentview:oldnewpaymentview
	};
}();
module.exports = OLDNEWPAYMENTVIEW;