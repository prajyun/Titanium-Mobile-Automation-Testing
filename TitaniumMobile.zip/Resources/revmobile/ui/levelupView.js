(function(){
   ro.ui.addLevelupView = function(_args){
      
      var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      
		Ti.App.Properties.setBool('lvlupBool', false);
		
		var firstTimeRegistering = _args && _args.isFirst ? true : false;

      var mainView =  Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'levelup', hid:'levelup', layout:'vertical'}));
      var navBar = Ti.UI.createView(ro.ui.properties.navBar);

      /* if(ro.ui.theme.bannerImg){
         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
         navBar.add(headerImg);
      }
		else{
	      var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'LevelUp'}));
	      navBar.add(headerLbl);
	  } */

      var btnBack = layoutHelper.getBackBtn(Ti.App.atPayScrn?'PAYMENT SCREEN':'ORDER TYPE');
      btnBack.addEventListener('click', function(e){
      	if(Ti.App.atPayScrn){
      	   ro.ui.cartShowNext({ showing:'levelup' });
      	}
      	else{
      	   ro.ui.ordShowNext({ showing:'levelup' });
      	}
      });
      navBar.add(btnBack);

      var webView = levelUp.getWebView(function(e){
      	Ti.App.Properties.setBool('lvlupBool', true);
         if(Ti.App.atPayScrn){
      	   ro.ui.cartShowNext({ showing:'levelup' });
      	}
      	else{

      	   /*levelUp.getQrCode(function(qrCode){
         	   var qrImage = Ti.UI.createImageView({
         	      height:Ti.UI.SIZE,
         	      width:Ti.UI.SIZE,
         	      image:qrCode
         	   });
         	   mainView.remove(webView);
         	   mainView.add(qrImage);
         	});*/
         	if(firstTimeRegistering){
         	   ro.ui.ordShowNext({ showing:'levelup' });
         	}
         	else{
            	ro.ui.showLoader();
            	levelUp.getQrCode();
            	ro.ui.hideLoader();
            }
      	   //ro.ui.ordShowNext({ showing:'levelup' });

      	}
      });

      mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
      mainView.add(webView);
      return mainView;
   };
})();