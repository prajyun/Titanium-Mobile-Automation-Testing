var PASSWORDVIEW = function(){
	var passwordview = function(ro){
	   ro.ui.updatePasswordView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/credentialsForm.js');
	      var forms = ro.forms;
	      var regexVal = require('validation/regexValidation');
	      var credentialsForm = require('formControls/credentialsForm');
	      var pwVal = require('validation/passwordValidation');
	      
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:credentialsForm.getUpdatePasswordForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	      //form.top = ro.ui.relY(10);
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'password', hid:'password'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Reset Password'}));
	         navBar.add(headerLbl);
	      } */
	      
	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      
	      clearBtn.addEventListener('click', function(e){ form.clearFields(); });
	      btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'password'}); });
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
	
	      var btnUpdate = layoutHelper.getBigButton('Update');
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         //Ti.include('/validation/passwordValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         var success = pwVal.pwValidate(values);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	
	               ro.dataservice.post(formRequest(values.newpass), 'UpdatePassword', function(response){
	                  if(response){
	                     if(response.Value){
	                        ro.db.updatePassword(Ti.App.Username, values.newpass);
	                        Ti.App.Password = values.newpass;
	                        ro.ui.settingsShowNext({showing:'password', resetOrder:true});
	                     }
	                     ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
	                  }
	               });
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Reset Password"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Reset Password", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      
	      mainView.add(form);
	      return mainView;
	   };
	
	   function formRequest(newPass){
	      var req  = {};
	      req.UserName = Ti.App.Username;
	      req.Pass = Ti.App.Password;
	      req.RevKey = 'test';
	      req.UpdatedPass = newPass;
	      return req;
	   };
	};
	return {
		passwordview:passwordview
	};
}();
module.exports = PASSWORDVIEW;