var viewLayout = function(){
   var sharedLayout = require('revmobile/ui/sharedLayouts/mainView');
	var navBar = Ti.UI.createView(ro.ui.properties.navBar);

	/* if(ro.ui.theme.bannerImg){
      var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
      navBar.add(headerImg);
   }
   else{
      var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'Password Recovery'}));
      navBar.add(headerLbl);
   } */

	var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
	   layout:'vertical',
	   backgroundImage:ro.ui.properties.defaultPath + 'backgroundImg.png'
	}));
	var btnBack = sharedLayout.getBackBtn('BACK');
	btnBack.addEventListener('click', function(e){
	   if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	   ro.utils.removeProp('digest');
	   ro.ui.closePassRecovery();
	});

	navBar.add(btnBack);
   //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Reset Password"));
   
   if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, null, null, true));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, null, null, true));
			}
   
   return mainView;
};
exports.createUrlResetView = function(){
   var sharedLayout = require('revmobile/ui/sharedLayouts/mainView');
	var mainView = viewLayout();
	var pwRecView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
		top:ro.ui.relY(10),
		bottom:0
	}));
	var btnUpdate = sharedLayout.getBigButton('Submit');
	var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnUpdate);
	
	btnUpdate.addEventListener('click', function(e){
		if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		ro.ui.showLoader();
		var values = ro.forms.getValues(resetPassForm);

		//Ti.include('/validation/resetValidation.js');
		var resetVal = require('validation/resetValidation');
		var success = resetVal.resetValidate(values);
		if(success.value){
			//Ti.include('/validation/regexValidation.js');
			var regexVal = require('validation/regexValidation');
			success = regexVal.regExValidate(values);
			if(success.value){
				contactServer(formRequest(fixObject(values)));

				setTimeout(function(){
					ro.ui.hideLoader();
				}, 2000);
			}
			else{
				ro.ui.alert('Error: ', success.issues[0]);
				ro.ui.hideLoader();
			}
		}
		else{
			ro.ui.alert('Error: ', success.issues[0]);
			ro.ui.hideLoader();
		}
	});

	//var forms = require('/revmobile/ui/forms');
	//Ti.include('/formControls/resetForm.js');
   var resetPassword = require('formControls/resetForm');
   var resetPassForm = ro.forms.createForm({
      style:ro.forms.STYLE_LABEL,
      fields:resetPassword.getNewPasswordForm(),
      settings:ro.ui.properties.myAccountView,
      forgotPass:true
   });
    resetPassForm.bottom = null;
   var padding = Ti.UI.createView({
   	  height:Ti.UI.SIZE,
   	  width:Ti.UI.FILL,
   	  top:0
   });
   resetPassForm.container.add(btnWrapper);
   padding.add(resetPassForm);

   pwRecView.add(padding);
   //pwRecView.add(btnUpdate);
   mainView.add(pwRecView);
	return mainView;
};
exports.createPasswordRecoveryView = function(_args){
   var sharedLayout = require('revmobile/ui/sharedLayouts/mainView');
	var mainView = viewLayout();

	//var forms = require('/revmobile/ui/forms');
	var pwRecView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
		top:ro.ui.relY(10),
		bottom:0
	}));
	var btnUpdate = sharedLayout.getBigButton('Submit');
	var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnUpdate);
		btnUpdate.addEventListener('click', function(e){
		ro.ui.showLoader();
		//Ti.include('/validation/resetValidation.js');
		var resetVal = require('validation/resetValidation');
		var values = null, success;

		if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		//if(tabs[0].)
		//Ti.API.debug('tabs[0]: ' + JSON.stringify(tabs[0]));
		//Ti.API.debug('tabs[1]: ' + JSON.stringify(tabs[1]));
		//if(tabView.children[0].children[0].color == 'yellow'){
		if(tabs[0].ison){
			values = ro.forms.getValues(reqResetForm);
		}
		else{
			values = ro.forms.getValues(finalizeResetForm);
		}
		//Ti.API.debug('values: ' + JSON.stringify(values));
		success = resetVal.resetValidate(values);
		//Ti.API.debug('success: ' + JSON.stringify(success));
		if(success.value){
			//Ti.include('/validation/regexValidation.js');
			var regexVal = require('validation/regexValidation');
			success = regexVal.regExValidate(values);
			//Ti.API.debug('success: ' + JSON.stringify(success));
			if(success.value){
				contactServer(formRequest(fixObject(values)));
				setTimeout(function(){
					ro.ui.hideLoader();
				}, 2000);
			}
			else{
				ro.ui.alert('Error: ', success.issues[0]);
				ro.ui.hideLoader();
			}
		}
		else{
			ro.ui.alert('Error: ', success.issues[0]);
			ro.ui.hideLoader();
		}
	});

	var tabWidth = ro.ui.relX(120);
	var tabs = [];

	function changePwTab(e){
		if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		if(e.rowIndex === 0){
			try{
            padding.remove(finalizeResetForm);
         }
         catch(ex){
            if(Ti.App.DEBUGBOOL) { Ti.API.debug('changePwTab()-Exception #1: ' + ex); }
         }
         padding.add(reqResetForm);
		}
		else if(e.rowIndex === 1){
			try{
            padding.remove(reqResetForm);
         }
         catch(ex){
            if(Ti.App.DEBUGBOOL) { Ti.API.debug('changePwTab()-Exception #2: ' + ex); }
         }
         padding.add(finalizeResetForm);
		}
	}

	function selectIndex(_idx){
		changePwTab({rowIndex:_idx});
	}

	//Ti.include('/controls/tabCtrl.js');
	function tabClick(e){
      if(e.source.id == 0){
         if(!tabs[0].ison){
            selectIndex(0);
            tabs[0].toggle();
            tabs[1].toggle();
         }
      }
      else{
         if(!tabs[1].ison){
            selectIndex(1);
            tabs[1].toggle();
            tabs[0].toggle();
         }
      }
    }

	tabs.push(ro.tabBar.createTab('Request Code', function(e){
	   tabClick(e);
	}, true, 0));

	tabs.push(ro.tabBar.createTab('Enter Code', function(e){
		tabClick(e);
	}, false, 1));

   var tabView = ro.tabBar.getTabView(tabs);

	//Ti.include('/formControls/resetForm.js');
	var resetPassword = require('formControls/resetForm');
   var reqResetForm = ro.forms.createForm({
      style:ro.forms.STYLE_LABEL,
      fields:resetPassword.getResetPasswordForm(0),
      settings:ro.ui.properties.myAccountView,
      forgotPass:true
   });
   var finalizeResetForm = ro.forms.createForm({
      style:ro.forms.STYLE_LABEL,
      fields:resetPassword.getResetPasswordForm(1),
      settings:ro.ui.properties.myAccountView,
      forgotPass:true
   });
   finalizeResetForm.bottom = null;
   finalizeResetForm.top = ro.ui.relY(10);
   
   var hdr = ro.layout.getGenericHdrRowWithHeader("Code Verification", true);
	      hdr.bottom = ro.ui.relY(10);
			finalizeResetForm.container.insertAt({
				view:hdr,
				position:0
			});
   
	reqResetForm.top = ro.ui.relY(10);
	reqResetForm.bottom = null;
	
	var otherhdr = ro.layout.getGenericHdrRowWithHeader("Contact Information", true);
	      otherhdr.bottom = ro.ui.relY(10);
			reqResetForm.container.insertAt({
				view:otherhdr,
				position:0
			});
	
   var padding = Ti.UI.createView({
   	height:Ti.UI.SIZE,
   	width:Ti.UI.FILL,
   	top:0
   });
	reqResetForm.container.add(btnWrapper);
	finalizeResetForm.container.add(btnWrapper);
    padding.add(reqResetForm);
    pwRecView.add(padding);
   //pwRecView.add(btnUpdate);

   mainView.add(tabView);
   mainView.add(pwRecView);
   return mainView;
};

var fixObject = function(vals){
	var valsLength = findLength(vals);

	if(valsLength > 2){
		return {Code:vals.Code, UserName:vals.UserName, NewPassword:vals.newpass, ConfirmPassword:vals.verifynewpass};
	}
	else if(valsLength === 2){
		var digest = Ti.App.Properties.getString('digest');
		return {Digest:digest, NewPassword:vals.newpass, ConfirmPassword:vals.verifynewpass};
	}
	else{
		return vals;
	}
};
var findLength = function(thisObj){
	var length = 0;
	for(var k in thisObj){
		if(k !== "clone"){
			length++;
		}
	}
	return length;
};
var formRequest = function(reqObj){
	if(findLength(reqObj) > 1){
		return {req:ro.combine(reqObj, {
  			RevKey:'test'
  		}), reqApi:'ResetPassword'};
	}
	else{
  		return {req:ro.combine(reqObj, {
  			RevKey:'test',
  			Url:ro.isiOS ? Ti.App.name+'://' : Ti.App.resetURL
  		}), reqApi:'RequestPassword'};
  	}
};
var contactServer = function(obj){
	//Ti.include('/classes/ro.dataservice.js');

	var response;
   ro.dataservice.post(obj.req, obj.reqApi, function(response){
      if(response){
         if(response.Value){
         	var reqLen = findLength(obj.req);
         	
                ro.ui.popup('Reset Password', ['OK'], response.Message, function(e) {
                    if (obj.reqApi !== 'RequestPassword') {
                        Ti.App.passChanged = obj.req.NewPassword;

                        if (obj.req.UserName && obj.req.UserName.length > 0) {
                            Ti.App.Username = obj.req.UserName;
                            Ti.App.Password = obj.req.NewPassword;
                        }
                        var defCust = ro.db.getDefaultCustomer();

                        if (defCust != null) {
                            ro.db.updateCustomer(defCust.Email, obj.req.NewPassword, defCust.storeID, defCust.CustomerObj, defCust.isDefault);
                        }
                    }
                    ro.ui.closePassRecovery((reqLen > 4) ? true : false);
                }); 

            /*var ad = Ti.UI.createAlertDialog({
               buttonNames:['OK'],
               title:'Reset Password',
               message:response.Message
            });
            ad.addEventListener('click', function(){
            	if(obj.reqApi !== 'RequestPassword'){
            		Ti.App.passChanged = obj.req.NewPassword;

            		if(obj.req.UserName && obj.req.UserName.length > 0){
            			Ti.App.Username = obj.req.UserName;
            			Ti.App.Password = obj.req.NewPassword;
            		}
	   				var defCust = ro.db.getDefaultCustomer();

	   				if(defCust != null){
	                   ro.db.updateCustomer(defCust.Email, obj.req.NewPassword, defCust.storeID, defCust.CustomerObj, defCust.isDefault);
	               }
            	}
	            ro.ui.closePassRecovery((reqLen > 4)?true:false);
            });*/

            try{
            	ro.utils.removeProp('digest');
            }
            catch(ex){
            	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('removeProp(\'digest\')-Exception: ' + ex); }
            }
            //ad.show();
         }
         else{
         	ro.ui.alert('Error: ', response.Message);
         }
      }
      else{
      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('shouldnt be here'); }
      }
   });
};