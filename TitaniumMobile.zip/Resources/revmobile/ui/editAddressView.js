var EDITADDRESSVIEW = function(){
	var editaddressview = function(ro){
	   
	
	   ro.ui.editAddressView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      var defaultCustomer = {}, index, Obj, Id;
	      var forms = ro.forms;
	      var addressForm = require('formControls/addressForm');
	      var addrControl = require('controls/addrControl');
	      var regexVal = require('validation/regexValidation');
	      var addrVal = require('validation/addressValidation');
	      //Ti.include('/formControls/addressForm.js');
	      index = _args.rowid;
	      defaultCustomer = ro.db.getCustObj(Ti.App.Username);
	
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:addressForm.getAddrForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	      form.setFields(defaultCustomer.AddressCol[index]);
	      Id = defaultCustomer.AddressCol[index].Id;
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:'editAddress'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Address Details'}));
	         navBar.add(headerLbl);
	      } */
	
	      //var resetBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/clearBtn.png");
	      var deleteBtn = layoutHelper.getNewRightBtn('Delete', null, "/images/navClear.png");
	      deleteBtn.addEventListener('click', function(e){
	         //ro.ui.showLoader();
	         ro.GlobalPicker.hidePicker();
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var delSuccess;
	         /*var dlg = Ti.UI.createAlertDialog({
	            title:'Alert',
	            message:'Are you sure you want to delete this Address?',
	            buttonNames:['Yes', 'No']
	         });
	         dlg.addEventListener('click', function(ev){
	            if(ev.index == 0){
	            	ro.ui.showLoader();
	               //Ti.include('/controls/addrControl.js');
	               var req = {};
	               req.Username = Ti.App.Username;
	               req.Pass = Ti.App.Password;
	               req.Id = Id;
	               req.RevKey = 'test';
	               req.CompressResponse = false;
	               addrControl.contactDeleteServer(req, index, defaultCustomer);
	               //ro.ui.hideLoader();
	            }
	            else{
	               return;
	            }
	         });
	         dlg.show();*/
	        
                ro.ui.popup('Alert', ['Cancel', 'OK'], 'Are you sure you want to delete this Address?', function(e) {
                    ro.ui.showLoader();
                    //Ti.include('/controls/addrControl.js');
                    var req = {};
                    req.Username = Ti.App.Username;
                    req.Pass = Ti.App.Password;
                    req.Id = Id;
                    req.RevKey = 'test';
                    req.CompressResponse = false;
                    addrControl.contactDeleteServer(req, index, defaultCustomer);
                    //ro.ui.hideLoader();
                }); 

	         //ro.ui.hideLoader();
	      });
	
	      var btnBack = layoutHelper.getBackBtn('ADDRESS LIST');
	      btnBack.addEventListener('click', function(e){ 
	      	ro.GlobalPicker.hidePicker();
	      	ro.ui.settingsShowNext({showing:'editAddress'}); 
	      });
	
	      var btnUpdate = layoutHelper.getBigButton('Update');
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	      	ro.GlobalPicker.hidePicker();
	         ro.ui.showLoader();
	         //Ti.include('/validation/addressValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         var success = addrVal.addrValidate(values, defaultCustomer);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               formRequest(values);
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      navBar.add(btnBack);
	
	      navBar.add(deleteBtn);
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Address Details", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      mainView.add(form);
	      
	      
	   function formRequest(modifyAddrObj){
	      var req  = {};
	      var AddressObj = {};
	      try{
	         var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.zip + ', ' + modifyAddrObj.CountryCode;//', US';
	         //var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.zip;
	         Ti.API.debug('addr: ' + addr);
			
			var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	      	if(!cfg){
	      	   cfg = {};
	      	}
	      	var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
	      	
			//Ti.include('/app.geo.js');
			var hrush = {
				geo:require('app.geo')
			};
			hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy/*storeObj.Configuration.AllowPCAccuracy*/);
			hrush.geo.geocode2(addr, function(addresses){
				Ti.API.debug('addresses: ' + JSON.stringify(addresses));
				if(!addresses || !addresses.data || !addresses.data.length){//}|| !addresses.data.StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
			      	ro.ui.hideLoader();
			      	var msg = 'Please check address';
			      	if(addresses && addresses.message){
			      		msg = addresses.message;
			      	}
			      	ro.ui.alert('Error: ', msg);
			      	//ro.ui.alert('Error: ', 'Please check address');
			      	return;
			    }
			    
			    function createReq(addrIndx){
			    	if(!addresses.data[addrIndx].StNumber || !addresses.data[addrIndx].StNumber.length){
			           	   ro.ui.hideLoader();
			           	   ro.ui.alert('Error: ','Street # is required');
			           	   return;
			          }
			    	
			    	
					  //Ti.include('/controls/addrControl.js');
	                  req.UserName = Ti.App.Username;
	                  req.Pass = Ti.App.Password;
	                  req.RevKey = 'test';
	
					      modifyAddrObj.stnum = addresses.data[addrIndx].StNumber;
					      modifyAddrObj.stname = addresses.data[addrIndx].Street;
	
					      if(addresses.data[addrIndx].City && addresses.data[addrIndx].City.length){
					      	modifyAddrObj.city = addresses.data[addrIndx].City;
					      }
	
					      if(addresses.data[addrIndx].State && addresses.data[addrIndx].State.length){
					      	modifyAddrObj.state = addresses.data[addrIndx].State;
					      }
	
					      if(addresses.data[addrIndx].Zip && addresses.data[addrIndx].Zip.length){
					      	modifyAddrObj.zip = addresses.data[addrIndx].Zip;
					      }
	
						//var addrControl = require('controls/addrControl');
	                  AddressObj = addrControl.formAddrObj(modifyAddrObj);
	                  AddressObj.Id = Id;
	                  AddressObj.Lat = addresses.data[addrIndx].Lat;
	                  AddressObj.Lon = addresses.data[addrIndx].Lon;
	
	                  req.Address = AddressObj;
	                  contactServer(req);
						}
				var GEO = require('geo'); 
	           	if(addresses.data.length > 1){
	           		GEO.displayList(addresses.data, createReq);
	           	}
	           	else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
	           		GEO.displayList(addresses.data, createReq);
	           	}
	           	else{
	           		createReq(0);
	           	}
			}, true, GOOG_MAPS_KEY);
			return;
	      }
	      catch(e){
	      	ro.ui.hideLoader();
	         ro.ui.alert('Error: ', e);
	      }
	   }
	
	   function contactServer(req){
		   var response;
		   var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
		   if (savedTokenObj && savedTokenObj.token) {
			   req.CustomerDevice = {};
			   req.CustomerDevice.DeviceID = Ti.Platform.id;
			   req.CustomerDevice.DeviceToken = savedTokenObj.token;
			   req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
		   }
	      ro.dataservice.post(req, 'UpdateCustomerAddress', function(response){
	         if(response){
	            if(response.Value){
	               saveCustomer(req);
	               //Ti.App.fireEvent('resetOrdTypeStk');
	               ro.ui.settingsShowNext({showing:'editAddress', resetOrder:true});
	            }
	            else{
	            	ro.ui.hideLoader();
	            }
	            ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
	         }
	         else{
	         	ro.ui.hideLoader();
	         }
	      });
	   }
	
	   function saveCustomer(req){
	      defaultCustomer.AddressCol[index].AddrTypeName = req.Address.AddrTypeName;
	      defaultCustomer.AddressCol[index].StNum = req.Address.StNum;
	      defaultCustomer.AddressCol[index].St = req.Address.St;
	      defaultCustomer.AddressCol[index].Lat = req.Address.Lat;
	      defaultCustomer.AddressCol[index].Lon = req.Address.Lon;
	      defaultCustomer.AddressCol[index].City = req.Address.City;
	      defaultCustomer.AddressCol[index].State = req.Address.State;
	      defaultCustomer.AddressCol[index].Zip = req.Address.Zip;
	      defaultCustomer.AddressCol[index].CustAddrTypeName = req.Address.CustAddrTypeName;
	      defaultCustomer.AddressCol[index].SUD = req.Address.SUD;
	      defaultCustomer.AddressCol[index].Label = req.Address.Label;
	      defaultCustomer.AddressCol[index].IsDefault = req.Address.IsDefault;
			//Ti.API.debug('222defaultCustomer: ' + JSON.stringify(defaultCustomer));
	      ro.db.updateCustomerObj(Ti.App.Username, defaultCustomer);
	   }
	      
	      
	      return mainView;
	   };
	
	   
	};
	return {
		editaddressview:editaddressview
	};
}();
module.exports = EDITADDRESSVIEW;