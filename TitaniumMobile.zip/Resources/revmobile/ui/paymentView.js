const CCTIPS = require('../../ccTips');

var NEWPAYMENTVIEW = function () {
    var newpaymentview = function (ro) {
        ro.ui.createNewPayView = function () {
            /*function vrfyBilling(){
                return false;
            }*/
            /*function getBillingInfo(){
                
            }*/
            var style = ro.ui.properties;
            var mp = require('logic/MultiplePmtHelper');
            var ccHelper = require('logic/creditCard');
            CC_TIPS.Init('', true, false, false, mp.updateTotals);
            var mpView;
            var priceEngine = require('logic/pricing');
            var func = priceEngine.pricer();
            var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
            if (!cfg) {
                cfg = {};
            }

            var AllowCCTips = false;
            var AllowGCTips = false;

            if(ro.app.Store.Configuration.hasOwnProperty("AllowCCTips")){
                AllowCCTips = ro.app.Store.Configuration.AllowCCTips;
            }else if(cfg && cfg.hasOwnProperty("AllowCCTips")){
                AllowCCTips = cfg.AllowCCTips;
            }

            if(ro.app.Store.Configuration.hasOwnProperty("AllowGCTips")){
                AllowGCTips = ro.app.Store.Configuration.AllowGCTips;
            }else if(cfg && cfg.hasOwnProperty("AllowGCTips")){
                AllowGCTips = cfg.AllowGCTips;
            }

            var checkAndTogglePaymentView = function () {
                if (mp.IsPaymentValid()) {
                    paymentTypeBox.children[0].height = 0;
                    paymentTypeBox.children[0].hide();
                    paymentTypeBox.children[1].height = 0;
                    paymentTypeBox.children[1].hide();
                } else {
                    paymentTypeBox.children[0].height = Ti.UI.SIZE;
                    paymentTypeBox.children[0].show();
                    paymentTypeBox.children[1].height = Ti.UI.SIZE;
                    paymentTypeBox.children[1].show();
                }
                if(surchargePmnts && surchargePmnts.length){
                    refreshPaymentTotals();
                }
            };

            var refreshPaymentTotals = function(pmnt){
                var test = Ti.App.OrderObj;
                test.PaymentsList = [];
                var multiPmts = mp.GetMultiPmts();
                if (multiPmts && multiPmts.DoMultiPmts) {
                    var mpList = multiPmts.MultiPmts ? multiPmts.MultiPmts : [];
                    var pmts = [];
                    for(i = 0; i < mpList.length; i++){
                        if(mpList[i].PaymentType){
                            pmts.push(mpList[i].PaymentType);
                        }
                    }
                    if(pmts){
                        pmts.push(pmnt);
                    }
                    var uniquePmts = pmts.filter((c, index) => {
                        return pmts.indexOf(c) === index;
                    });
                    test.PaymentsList = uniquePmts;
                }else{
                    if(pmnt){
                        test.PaymentsList.push(pmnt);
                    }else if (paymentTypeView.dispordpayment && paymentTypeView.dispordpayment != ""){
                        var payment;
                        var title = paymentTypeView.dispordpayment;
                        if(title == 'use existing card' || title == 'credit card' || title == 'applepay'){
                            payment = 'creditcard';
                        }else if(title =='gift'){
                            payment = 'giftcard'
                        }else{
                            payment = title;
                        }
                        test.PaymentsList.push(payment)
                    }                    
                }
                
                test = func.RepriceOrder(test, ro.app.Store.Menu, test.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                Ti.App.OrderObj = test;
                test = null;
                //if (multiPmts && multiPmts.DoMultiPmts) {
                    mp.updateTotals(CCTIPS.getTip());                             
                //}                        
                //mp.refreshTotal();
            };

            var closePaymentTypesView = function () {
                for (var i = 0, iMax = paymentTypeView.children.length; i < iMax; i++) {
                    if (paymentTypeView.children[i].isDivider || !paymentTypeView.children[i].changeSelection) {
                        continue;
                    }

                    if (paymentTypeView.children[i].isSelected) {
                        paymentTypeView.children[i].changeSelection(false);
                        //paymentTypeView.children[i].removeAllChildren();
                        resetPaymentTypesView();
                    }
                }
                checkAndTogglePaymentView();

            };

            var resetPaymentTypesView = function () {
                var mPmts = mp.GetMultiPmts();
                var foundSelectedRow = false;
                for (var i = 0, iMax = paymentTypeView.children.length; i < iMax; i++) {

                    if (paymentTypeView.children[i].isDivider || !paymentTypeView.children[i].changeSelection) {
                        continue;
                    }

                    // 
                    if (paymentTypeView.children[i].isSelected) {
                        foundSelectedRow = true;
                        var cardObj = paymentTypeView.children[i].cardObj ? paymentTypeView.children[i].cardObj : null;
                        //Ti.API.info('Calling Reset Payemnts: '+ JSON.stringify(paymentTypeView.children[i].cardObj));
                        var title = paymentTypeView.children[i].title.replace('*','');
                        paymentTypeView.dispordpayment = title;
                        switch (title.toLowerCase()) {
                            case "use existing card":
                                //paymentTypeView.children[i] = getSavedCardView(mp, cardObj, title);
                                payForms[paymentTypeView.selectedIndex] = getSavedCardView(mPmts, cardObj);
                                paymentTypeView.children[i].addForm();
                                CC_TIPS.Init('', true, false, false, mp.updateTotals);
                                paymentTypeView.children[i].addForm(payForms[paymentTypeView.selectedIndex]);
                                break;
                            case "applepay":
                                paymentTypeView.children[i].changeSelection(false);
                                paymentTypeView.dispordpayment = "";
                                toggleSubmitButton(false);
                                break;
                            case "credit card":
                                //paymentTypeView.children[i] = GetCreditView(mp);
                                payForms[paymentTypeView.selectedIndex] = GetCreditView(mPmts);
                                paymentTypeView.children[i].addForm();
                                paymentTypeView.children[i].addForm(payForms[paymentTypeView.selectedIndex]);
                                break;
                            case "cash":
                                var cashObj = { "IsCredOrGift": false, "CardInfo": "CASH", "PaymentAmt": 0.00, "PaymentType":"cash"};
                                payForms[paymentTypeView.selectedIndex] = getSavedCardView(mPmts, cashObj);
                                paymentTypeView.children[i].addForm();
                                paymentTypeView.children[i].addForm(payForms[paymentTypeView.selectedIndex]);
                                break;
                            case "gift":
                                payForms[paymentTypeView.selectedIndex] = GetGiftView(mPmts);
                                paymentTypeView.children[i].addForm();
                                paymentTypeView.children[i].addForm(payForms[paymentTypeView.selectedIndex]);
                                break;
                            default:
                                break;
                        }


                        //paymentTypeView.children[i].changeSelection(false);
                        if (!MultiPmtSwitch.thevalue) {
                            paymentTypeView.children[i].changeSelection(false);
                            paymentTypeView.dispordpayment = "";
                        }
                    }

                    if (!foundSelectedRow) {
                        //Ti.API.info('RESET PAYMENTS WAS CALLED AND NO SELECTED ROWS WERE FOUND');
                        paymentTypeView.dispordpayment = "";
                    }

                }
            };

            var getSavedCardView = function (mPmts, cardObj) {

                var multiPayBln = mPmts.DoMultiPmts;
                var formHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,//multiPayBln ? Ti.UI.SIZE : 0,
                    layout: 'vertical'
                });
                formHolder.SubmitForm = function (ccTip, _cb) {

                    var multiPay = mp.GetMultiPmts();
                    var multiPayBln = multiPay.DoMultiPmts;
                    cardObj.Tip = ccTip || 0.00;

                    if (multiPayBln && !mp.IsPaymentValid()) {
                        //Ti.API.info('cardObj: ' + JSON.stringify(cardObj));
                        var values = ro.forms.getValues(amtForm);
                        //Ti.API.info('Values: ' + JSON.stringify(values));
                        if (!values.payAmt)
                            values.payAmt = 0.00;
                        var payWithTip = parseFloat(mp.getDollarFormat(values.payAmt));
                        var paymentAmt = (payWithTip - (ccTip ? ccTip : 0.00)).toFixed(2);
                        var balanceWithTip = parseFloat(mp.getCurrentBalanceDue()) + (ccTip ? ccTip : 0.00);
                        //Ti.API.info("Payment Amount: "+paymentAmt);

                        var min = 0.01;
                        if (cardObj.Tip && parseFloat(cardObj.Tip) > 0) min = parseFloat(cardObj.Tip);
                        if (!paymentAmt || mp.getDollarFormat(payWithTip) < min || mp.getDollarFormat(payWithTip) > mp.getDollarFormat(balanceWithTip)) {

                            ro.ui.alert('Error', "The amount field must be in range " + min.toFixed(2) + " to " + balanceWithTip.toFixed(2));
                            ro.ui.hideLoader();
                            try {
                                amtForm.focusField('payAmt');
                            } catch (ex) {
                                Ti.API.debug('foxusField: ex: ' + ex);
                            }
                            return;
                        }
                        else {

                            if (!ro.isiOS)
                                Ti.UI.Android.hideSoftKeyboard();


                            cardObj.PaymentAmt = parseFloat(paymentAmt);
                            var payObj = cardObj;//payControl.getPaymentObj(cardObj);
                            if(!payObj.PaymentType || (payObj.PaymentType && payObj.PaymentType == '')){
                                payObj.PaymentType = 'creditcard';
                            }
                            
                            if (!multiPay.MultiPmts || !multiPay.MultiPmts.length) {
                                multiPay.MultiPmts = [];
                            }
                            if(ro.app.Store.Configuration.ALLOW_CARD_TOKEN && payObj.TokenID && payObj.TokenID != ""){
                                payObj.OLCardNum = payObj.TokenID;
                                payObj.PayWithToken = true;
                            }
                            var combinedPmtsBln = false;
                            //Ti.API.info('Payment Object ' + JSON.stringify(payObj));
                            //Ti.API.info('Multi Pay obj ' + JSON.stringify(multiPay));
                            
                            for (var i = 0,
                                iMax = multiPay.MultiPmts.length; i < iMax; i++) {
                                var mpObj = multiPay.MultiPmts[i];
                                if (mpObj.CardInfo == payObj.CardInfo && 
                                    ((payObj.CardInfo == "CASH") || 
                                    (mpObj.OLCardNum == payObj.OLCardNum && 
                                        mpObj.PayerName == payObj.PayerName && 
                                        mpObj.OLExpMonth == payObj.OLExpMonth && 
                                        mpObj.OLExpYear == payObj.OLExpYear && 
                                        (!(mpObj.OLSecCode && payObj.OLSecCode) || mpObj.OLSecCode == payObj.OLSecCode) && 
                                        mpObj.CardInfo == payObj.CardInfo)
                                        )) {
                                    multiPay.MultiPmts[i].PaymentAmt = parseFloat((mp.getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + mp.getDollarFormat(payObj.PaymentAmt)).toFixed(2));
                                    // REVISIT THIS AND ADD IT BACK WITH CONDITIONS TO AVAOID NaN VALUES IN TIP.                                
                                    multiPay.MultiPmts[i].Tip = parseFloat((mp.getDollarFormat(multiPay.MultiPmts[i].Tip) + mp.getDollarFormat(payObj.Tip)).toFixed(2));
                                    combinedPmtsBln = true;
                                    break;
                                }
                            }
                            
                            if (!combinedPmtsBln) {
                                if (payObj.CardInfo != "CASH")
                                    payObj.IsCredOrGift = true;

                                multiPay.MultiPmts.push(payObj);
                            }

                            mp.SaveMultiPmts(multiPay);
                            CC_TIPS.setTip(cardObj.Tip);
                            //Ti.API.info('Multi Pmnt: ' + Ti.App.Properties.getString("MultiPmts"));
                            //var mpView = mp.GetView(!multiPmts.DoMultiPmts ? (isPaymentValid() ? true : false) : false, toggleTblView2Vis);

                            mpView.Reprint();
                            closePaymentTypesView();
                        }

                    } else {
                        CC_TIPS.setTip(cardObj.Tip);

                        chooseSavedCard(cardObj, _cb);
                    }
                };

                var amtForm;
                if (multiPayBln) {

                    var addPmntBtn = Ti.UI.createView({
                        bottom: ro.ui.relY(10),
                        width: ro.ui.relX(100),
                        height: ro.ui.relY(40),
                        backgroundColor: ro.ui.theme.btnActive,
                        borderColor: ro.ui.theme.btnActive,
                        borderRadius: ro.ui.relX(20),
                        //bottom:ro.ui.relX(5)
                    });
                    addPmntBtn.add(Ti.UI.createLabel({
                        text: 'Add Payment',
                        font: {
                            //fontWeight:'bold',
                            fontFamily: ro.ui.fonts.button,
                            fontSize: ro.ui.scaleFont(19),
                            //fontFamily:ro.ui.fontFamily
                        },
                        color: ro.ui.theme.loginBtnWhite,
                        textAlign: 'center',
                        touchEnabled: false
                    }));
                    //var forms = require('/revmobile/ui/forms');
                    //Ti.include('/formControls/creditCardForm.js');
                    var creditCardForm = require('formControls/creditCardForm');
                    amtForm = ro.forms.createForm({
                        style: ro.forms.STYLE_LABEL,
                        fields: creditCardForm.getCCForm({
                            IsSavedCard: true,
                            ShowAmountField: multiPayBln
                        }),
                        settings: ro.ui.properties.myAccountView,
                        bottom: ro.ui.relY(5)
                    });

                    amtForm.top = ro.ui.relY(10);
                    amtForm.height = Ti.UI.SIZE;
                    amtForm.bottom = 0;

                    /*  var hdr = ro.layout.getGenericHdrRowWithHeader("Payment Amount", true);
                    hdr.bottom = ro.ui.relY(10);
                    amtForm.container.insertAt({
                        view: hdr,
                        position: 2
                    });*/

                    addPmntBtn.removeEventListener('click', function (e) { });
                    addPmntBtn.addEventListener('click', function (e) {
                        var ccTip = 0;
                        if (AllowCCTips && cardObj.CardInfo != "CASH") {
                            ccTip = CC_TIPS.getTip(ccTip);
                        }
                        formHolder.SubmitForm(ccTip);
                    });

                    formHolder.add(amtForm);

                }

                if (AllowCCTips && cardObj.CardInfo != "CASH") {
                    var tipsView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
                        layout: 'vertical',
                        height: Ti.UI.SIZE,
                        top: 0,
                        bottom: ro.ui.relY(20),
                        backgroundColor: "#f6f6f6",
                        borderRadius: ro.ui.relY(15),
                    }));
                    CC_TIPS.getTipView(tipsView, mp.updateTotals);
                    tipsView.ResetTip();
                    formHolder.add(tipsView);
                }

                if (multiPayBln) formHolder.add(addPmntBtn);

                return formHolder;
            };

            var getApplePayView = function(){
                var formHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,//multiPayBln ? Ti.UI.SIZE : 0,
                    layout: 'vertical'
                });
                formHolder.SubmitForm = function (ccTip, _cb) {  
                    try {                        
                        ro.ui.hideLoader();
                        var ccTip = CC_TIPS.getTip();
                        CC_TIPS.setTip(ccTip);
                        var totalTip = Ti.App.OrderObj.Tip ? parseFloat(Ti.App.OrderObj.Tip) : 0.00;
                        var items = [{
                            itemLabel: cfg.CompanyName ? cfg.CompanyName : '',
                            value: (Ti.App.OrderObj.ActiveTotal + totalTip) * 100
                        }];
                        var hungerrushNotationCards = ['VISA', 'MC', 'AMEX', 'DISC'];
                        var appleNotationCards = ['Visa','MasterCard','AmEx','Discover'];
                        var supportedNetworks = [];
                        for(var i=0; i < appleNotationCards.length; i++){
                            if(ccHelper.isCardAccepted(hungerrushNotationCards[i])){
                                supportedNetworks.push(appleNotationCards[i]);
                            }
                        }
                        Ti.API.info("items : " + JSON.stringify(items));
                        Ti.API.info("supportedNetworks : " + JSON.stringify(supportedNetworks));
                        if(ApplePay.canMakePayments({})){
                            ApplePay.openPaymentDialog({
                                items: items,
                                merchantIdentifier: applePayConfig.merchantIdentifier,
                                countryCode: applePayConfig.countryCode ? applePayConfig.countryCode : 'US',
                                currencyCode: applePayConfig.currencyCode ? applePayConfig.currencyCode : 'USD',
                                supportedNetworks: supportedNetworks
                            });            
                        }else{
                            ApplePay.openPaymentSetup({});
                        }                            
                    } catch (ex) {
                        ro.ui.alert('Apple Pay Error', 'Code:110');
                        Ti.API.info('Apple Pay Error : ' + ex);
                    }                    
                };
                if (AllowCCTips) {
                    var tipsView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
                        layout: 'vertical',
                        height: Ti.UI.SIZE,
                        top: 0,
                        bottom: ro.ui.relY(20),
                        backgroundColor: "#f6f6f6",
                        borderRadius: ro.ui.relY(15),
                    }));
                    CC_TIPS.getTipView(tipsView, mp.updateTotals);
                    tipsView.ResetTip();
                    formHolder.add(tipsView);
                }
                return formHolder;
            };

            var chooseSavedCard = function (cardObj, _cb, paymentAmt) {

                try {

                    ro.ui.showLoader();


                    var ccTip = CC_TIPS.getTip();
                    cardObj.Tip = ccTip || 0;
                    //Ti.API.info("in chose saved card func: "+ JSON.stringify(cardObj));
                    if (payControl.fillOrderObj(cardObj)) {
                        //ro.ui.cartShowNext({ showing:'addPmt' });
                        if (_cb) {
                            _cb();
                        }
                    } else {
                        ro.ui.alert('Error accessing saved card: ', 'Please try again');
                        ro.ui.hideLoader();
                    }
                } catch (ex) {
                    ro.ui.alert('CardList-PaymentScreen Error', 'Code:110' + ex);
                }
            };

            var GetCreditView = function (multiPay) {
                var addPmntBtn = Ti.UI.createView({
                    bottom: ro.ui.relY(10),
                    width: ro.ui.relX(100),
                    height: ro.ui.relY(40),
                    backgroundColor: ro.ui.theme.btnActive,
                    borderColor: ro.ui.theme.btnActive,
                    borderRadius: ro.ui.relX(20),
                    //bottom:ro.ui.relX(5)
                });
                addPmntBtn.add(Ti.UI.createLabel({
                    text: 'Add Payment',
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.button,
                        fontSize: ro.ui.scaleFont(19),
                        //fontFamily:ro.ui.fontFamily
                    },
                    color: ro.ui.theme.loginBtnWhite,
                    textAlign: 'center',
                    touchEnabled: false
                }));
                var payControl = require('controls/paymentControl');
                var ccControl = require('controls/ccControl');
                var credCardVal = require('validation/creditcardValidation');
                var regexVal = require('validation/regexValidation');                

                var multiPayBln = multiPay.DoMultiPmts;
                var rs = ro.db.getAllCustCC(Ti.App.Username);
                var hasSavedCC = rs.length;

                //GUEST ORDERS
                var isGuest = false;
                if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                    isGuest = true;
                }
                //GUEST ORDERS

                var billFlg = 0;
                //Ti.API.debug('ro.app.Store: ' + JSON.stringify(ro.app.Store));
                //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
                //Ti.API.debug('ro.app.Store.Configuration.VerifyBilling: ' + ro.app.Store.Configuration.VerifyBilling);
                if (ro.app.Store.Configuration.VerifyBilling) {
                    if (ro.app.Store.Configuration.VerifyBilling === 1) {
                        billFlg = 1;
                    } else if (ro.app.Store.Configuration.VerifyBilling === 2) {
                        billFlg = 2;
                    }
                }

                //var forms = require('/revmobile/ui/forms');
                //Ti.include('/formControls/creditCardForm.js');
                var creditCardForm = require('formControls/creditCardForm');
                var formHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    layout: 'vertical'
                });
                var form = ro.forms.createForm({
                    style: ro.forms.STYLE_LABEL,
                    fields: creditCardForm.getCCForm({
                        ShowAmountField: multiPayBln,
                        save: isGuest ? false : true,
                        billingFlag: billFlg,
                        noneDefault: /*true */isGuest ? true : false
                    }),
                    settings: ro.ui.properties.myAccountView
                });
                var curDate = new Date();
                var monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                var curMonth = curDate.getMonth();
                //form.fieldRefs['expMonth'].setLblText(monthList[curMonth]);
                form.fieldRefs['expMonth'].setLblText(((curMonth + 1) + " - " + monthList[curMonth]), monthList[curMonth]);
                //form.fieldRefs['expMonth'].text = monthList[curMonth];
                //form.fieldRefs['expMonth'].setSelectedRow(0, curMonth, true);
                /*try{
                 form.fieldRefs['expMonth'].text = monthList[curMonth];
                 }
                 catch(ex){
                 Ti.API.debug('catch: ' + ex);
                 }*/
                curDate = null;
                curMonth = null;
                form.height = Ti.UI.SIZE;
                form.top = ro.ui.relY(10);
                form.bottom = 0;

                formHolder.SubmitForm = function (ccTip, _cb) {
                    //ro.ui.showLoader();
                    var multiPay = mp.GetMultiPmts();
                    var multiPayBln = multiPay.DoMultiPmts;
                    //Ti.include('/validation/creditcardValidation.js');
                    if (!ro.isiOS)
                        Ti.UI.Android.hideSoftKeyboard();
                    var rowid;
                    var values = ro.forms.getValues(form);

                    //Ti.API.debug('values: ' + JSON.stringify(values));

                    var ccTypeStr = ccHelper.ValidateCC(values.ccNum);
                    //Ti.API.debug('ccTypeStr: ' + ccTypeStr);

                    var temp = values;
                    temp.ccType = ccTypeStr;
                    values = temp;
                    temp = null;

                    if (multiPayBln && !mp.IsPaymentValid()) {
                        //Ti.API.info('INSIDE MULTI PAYMENT FOR CREDIT CARD');
                        multiPay = mp.GetMultiPmts();
                        if (!values.payAmt)
                            values.payAmt = 0.00;
                        var payWithTip = parseFloat(mp.getDollarFormat(values.payAmt));
                        var paymentAmt = (payWithTip - (ccTip ? ccTip : 0.00)).toFixed(2);
                        var balanceWithTip = parseFloat(mp.getCurrentBalanceDue()) + (ccTip ? ccTip : 0.00);
                        //Ti.API.info('paymentAmt: ' + paymentAmt);
                        var min = 0.01;
                        if (ccTip && parseFloat(ccTip) > 0) min = parseFloat(ccTip);
                        if (!paymentAmt || mp.getDollarFormat(payWithTip) < min || mp.getDollarFormat(payWithTip) > balanceWithTip) {
                            ro.ui.alert('Error', "The amount field must be in range " + min.toFixed(2) + " to " + balanceWithTip.toFixed(2));
                            ro.ui.hideLoader();
                            try {
                                form.focusField('payAmt');
                            } catch (ex) {
                                Ti.API.debug('foxusField: ex: ' + ex);
                            }
                            return;
                        }
                    }

                    var success = credCardVal.credCardValidate(ro.combine(values, {
                        addNew: values.ccSave
                    }), rs);
                    //Ti.API.info('Success:' + JSON.stringify(success));
                    if (success.value) {
                        //Ti.include('/validation/regexValidation.js');
                        success = regexVal.regExValidate(values);
                        if (success.value) {

                            var newCCObj = ccControl.createCardObj(values);
                            Ti.API.info('Multi CCObj:' + JSON.stringify(newCCObj));
                            newCCObj.Tip = ccTip || 0;
                            newCCObj.PaymentAmt = parseFloat(newCCObj.PaymentAmt) - ccTip;
                            CC_TIPS.setTip(newCCObj.Tip);

                            if (values.ccSave && ccControl.checkUniqueCard(newCCObj)) {
                                // if (ccControl.hasSavedCards(ro)) {
                                //     rowid = ccControl.saveNewCard(newCCObj, ro);
                                // } else {
                                    ccControl.setDefaultCard(ccControl.saveNewCard(newCCObj, ro));
                                //}
                            }

                            if (multiPayBln && !mp.IsPaymentValid()) {
                                var payObj = payControl.getPaymentObj(newCCObj);
                                payObj.PaymentType = 'creditcard';
                                if (!multiPay.MultiPmts || !multiPay.MultiPmts.length) {
                                    multiPay.MultiPmts = [];
                                }
                                var combinedPmtsBln = false;

                                for (var i = 0,
                                    iMax = multiPay.MultiPmts.length; i < iMax; i++) {
                                    var mpObj = multiPay.MultiPmts[i];
                                    if (mpObj.OLCardNum == payObj.OLCardNum && mpObj.PayerName == payObj.PayerName && mpObj.OLExpMonth == payObj.OLExpMonth && mpObj.OLExpYear == payObj.OLExpYear && mpObj.OLSecCode == payObj.OLSecCode && mpObj.CardInfo == payObj.CardInfo) {
                                        multiPay.MultiPmts[i].PaymentAmt = parseFloat((mp.getDollarFormat(multiPay.MultiPmts[i].PaymentAmt) + mp.getDollarFormat(payObj.PaymentAmt)).toFixed(2));
                                        multiPay.MultiPmts[i].Tip = parseFloat((mp.getDollarFormat(multiPay.MultiPmts[i].Tip) + mp.getDollarFormat(payObj.Tip)).toFixed(2));
                                        combinedPmtsBln = true;
                                        break;
                                    }
                                }

                                if (!combinedPmtsBln) {
                                    payObj.IsCredOrGift = true;

                                    multiPay.MultiPmts.push(payObj);
                                }

                                mp.SaveMultiPmts(multiPay);
                                //Ti.API.info('Multi Pmnt: ' + Ti.App.Properties.getString("MultiPmts"));
                                //var mpView = mp.GetView(!multiPmts.DoMultiPmts ? (isPaymentValid() ? true : false) : false, toggleTblView2Vis);

                                mpView.Reprint();
                                closePaymentTypesView();

                            } else {
                                ro.ui.showLoader();
                                if (payControl.fillOrderObj(newCCObj)) {
                                    /*ro.ui.cartShowNext({
                                        showing: 'addPmt'
                                    });*/
                                    if (_cb) {
                                        _cb();
                                    }
                                } else {
                                    ro.ui.alert('Error: ', 'Please try again');
                                    ro.ui.hideLoader();
                                }
                            }
                        } else {
                            ro.ui.alert('Error', success.issues[0]);
                            ro.ui.hideLoader();
                        }
                    } else {
                        ro.ui.alert('Error', success.issues[0]);
                        ro.ui.hideLoader();
                    }
                };

                var hdr = ro.layout.getGenericHdrRowWithHeader("Card Details", true);
                hdr.bottom = ro.ui.relY(10);
                form.container.insertAt({
                    view: hdr,
                    position: 2
                });
                formHolder.bottom = formHolder.top;

                formHolder.add(form);

                if (AllowCCTips) {
                    var tipsView = Ti.UI.createView(ro.combine(ro.ui.properties.hdrViewMargins, {
                        layout: 'vertical',
                        height: Ti.UI.SIZE,
                        top: 0,
                        bottom: ro.ui.relY(20),
                        backgroundColor: "#f6f6f6",
                        borderRadius: ro.ui.relY(15),
                    }));
                    CC_TIPS.getTipView(tipsView, mp.updateTotals);
                    formHolder.add(tipsView);
                }

                if (multiPayBln) {


                    addPmntBtn.addEventListener('click', function (e) {
                        var ccTip = 0;
                        if (AllowCCTips) {
                            ccTip = CC_TIPS.getTip();
                        }
                        formHolder.SubmitForm(ccTip);
                    });
                    formHolder.add(addPmntBtn);
                }

                return formHolder;
            };
            var GetGiftView = function (multiPay) {
                var amtForm;
                var multiPayBln = multiPay && multiPay.DoMultiPmts;
                if (multiPayBln) {

                    var addPmntBtn = Ti.UI.createView({
                        bottom: ro.ui.relY(10),
                        width: ro.ui.relX(100),
                        height: ro.ui.relY(40),
                        backgroundColor: ro.ui.theme.btnActive,
                        borderColor: ro.ui.theme.btnActive,
                        borderRadius: ro.ui.relX(20),
                        //bottom:ro.ui.relX(5)
                    });
                    addPmntBtn.add(Ti.UI.createLabel({
                        text: 'Add Payment',
                        font: {
                            //fontWeight:'bold',
                            fontFamily: ro.ui.fonts.button,
                            fontSize: ro.ui.scaleFont(19),
                            //fontFamily:ro.ui.fontFamily
                        },
                        color: ro.ui.theme.loginBtnWhite,
                        textAlign: 'center',
                        touchEnabled: false
                    }));
                }

                var gcForm = require('formControls/giftCardForm');

                var formHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    layout: 'vertical'
                });

                var form = ro.forms.createForm({
                    style: ro.forms.STYLE_LABEL,
                    fields: gcForm.getGcForm({
                        ShowAmountField: multiPayBln
                    }),
                    settings: ro.ui.properties.myAccountView
                });
                form.height = Ti.UI.SIZE;
                form.top = ro.ui.relY(10);
                form.bottom = 0;

                var payControl = require('controls/paymentControl');
                var regexVal = require('validation/regexValidation');

                formHolder.SubmitForm = function (ccTip, _cb) {
                    ro.ui.showLoader();
                    var gcVal = require('validation/giftCardValidation');
                    if (!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
                    var values = ro.forms.getValues(form);
                    var multiPay = mp.GetMultiPmts();
                    var multiPayBln = multiPay.DoMultiPmts;
                    //multiPay = mp.GetMultiPmts();

                    Ti.API.info('values: ' + JSON.stringify(values));
                    var success = gcVal.gcValidate(values);
                    if (success.value) {
                        success = regexVal.regExValidate(values);

                        if (success.value) {
                            values.Tip = ccTip || 0;
                            //if (!multiPayBln) {
                                
                            //}

                            var req = {
                                StoreID: ro.app.Store.ID,
                                RevKey: 'test',
                                CardNumber: values.giftCardNum
                            };
                            ro.dataservice.post(req, 'CheckBalance', function (response) {
                                Ti.API.info('response: ' + JSON.stringify(response));
                                if (response) {
                                    //response.Value = false;
                                    //response.Message = "O Noes";
                                    if (response.Success) {
                                        //_callback();
                                        try {
                                            var cardBal = mp.getDollarFormat(response.Balance);
                                            if (multiPayBln) {
                                                if (cardBal < mp.getDollarFormat(values.payAmt)) {
                                                    ro.ui.alert('Card Balance is ' + cardBal.toFixed(2));
                                                    values.payAmt = cardBal;
                                                    values.Tip = 0;
                                                    ro.ui.hideLoader();
                                                    return;
                                                } else if (cardBal < (mp.getDollarFormat(values.payAmt) + mp.getDollarFormat(values.Tip))) {
                                                    Ti.API.debug('b4b4b4values.Tip: ' + values.Tip);
                                                    var oldTotal = mp.getDollarFormat(values.payAmt) + mp.getDollarFormat(values.Tip);
                                                    Ti.API.debug('oldTotal: ' + oldTotal);
                                                    var excessAmt = cardBal - oldTotal;
                                                    Ti.API.debug('excessAmt: ' + excessAmt);
                                                    values.Tip = mp.getDollarFormat(values.Tip) - excessAmt;
                                                    Ti.API.debug('b4b4b4values.Tip: ' + values.Tip);
                                                }

                                                multiPay = mp.GetMultiPmts();
                                                if (!values.payAmt) values.payAmt = 0.00;
                                                var paymentAmt = parseFloat(mp.getDollarFormat(values.payAmt).toFixed(2));
                                                //Ti.API.debug('paymentAmt: ' + paymentAmt);
                                                var getCurrentBalanceDue = function () {
                                                    //var MultiplePmtHelper = require('logic/MultiplePmtHelper');
                                                    var currentBalanceDue = Ti.App.OrderObj.ActiveTotal;
                                                    //var multiPmts = MultiplePmtHelper.GetMultiPmts();
                                                    //Ti.API.debug('multiPmts: ' + JSON.stringify(multiPmts));
                                                    for (var i = 0, iMax = multiPay.MultiPmts && multiPay.MultiPmts.length ? multiPay.MultiPmts.length : 0; i < iMax; i++) {
                                                        currentBalanceDue -= multiPay.MultiPmts[i].PaymentAmt;
                                                    }

                                                    //Ti.API.debug('getDollarFormat(currentBalanceDue).toFixed(2): ' + getDollarFormat(currentBalanceDue).toFixed(2));
                                                    return mp.getDollarFormat(currentBalanceDue).toFixed(2);
                                                };

                                                if (!paymentAmt || mp.getDollarFormat(paymentAmt) < 0.01 || mp.getDollarFormat(paymentAmt) > mp.getDollarFormat(getCurrentBalanceDue())) {
                                                    ro.ui.alert('Error', "The amount field must be in range 0.01 to " + mp.getCurrentBalanceDue());
                                                    ro.ui.hideLoader();
                                                    try {
                                                        form.focusField('payAmt');
                                                    } catch (ex) {
                                                        Ti.API.debug('foxusField: ex: ' + ex);
                                                    }
                                                    return;
                                                }
                                                //payControl.fillOrderObjGift(values);
                                                //var newGCObj = ccControl.createCardObj(values);
                                                var payObj = payControl.getGiftCardObj(values);
                                                payObj.PaymentType = 'giftcard';
                                                payObj.IsCredOrGift = true;
                                                multiPay.MultiPmts.push(payObj);
                                                //Ti.API.debug('made it here');

                                                mp.SaveMultiPmts(multiPay);

                                                mpView.Reprint();
                                                closePaymentTypesView();
                                                ro.ui.hideLoader();
                                                //if(cardBal > getDollarFormat())
                                                //payObj.IsCredOrGift = true;
                                            } else {
                                                Ti.API.info("Card Balance : " + cardBal);
                                                Ti.API.info("Active Total : " + Ti.App.OrderObj.ActiveTotal);
                                                if (cardBal >= Ti.App.OrderObj.ActiveTotal) {
                                                    var success = payControl.fillOrderObjGift(values);
                                                    if (success) {
                                                        //ro.ui.cartShowNext({showing:'addPmt'});
                                                        if (_cb) {
                                                            _cb();
                                                        }
                                                    } else {
                                                        ro.ui.alert('Gift Card Error: ', 'Please try again');
                                                        ro.ui.hideLoader();
                                                    }
                                                } else {
                                                    var insuffBalMsg = "The Gift Card Balance is $" + cardBal + ".";
                                                    if (allowMultiPmts) {
                                                        insuffBalMsg = insuffBalMsg + " You can use split payment to complete the transaction."
                                                    }
                                                    ro.ui.alert('Insufficient Balance: ', insuffBalMsg);
                                                    ro.ui.hideLoader();
                                                }
                                             
                                            }
                                        } catch (ex) {
                                            ro.ui.hideLoader();
                                            ro.ui.alert('GiftCard Error', 'Code:110');
                                        }
                                    } else {
                                        ro.ui.alert('Error', response.Message);
                                        ro.ui.hideLoader();
                                    }
                                } else {
                                    ro.ui.alert('Error', 'There was a problem retrieving the card balance.');
                                    ro.ui.hideLoader();
                                }
                            });
                        } else {
                            ro.ui.alert('Error: ', success.issues[0]);
                            ro.ui.hideLoader();
                        }
                    } else {
                        ro.ui.alert('Error: ', success.issues[0]);
                        ro.ui.hideLoader();
                    }
                };
                var hdr = ro.layout.getGenericHdrRowWithHeader("Gift Card Details", true);
                hdr.bottom = ro.ui.relY(10);
                form.container.insertAt({
                    view: hdr,
                    position: 0
                });
                formHolder.bottom = formHolder.top;
                formHolder.add(form);

                if (multiPayBln) {

                    addPmntBtn.addEventListener('click', function (e) {
                        formHolder.SubmitForm();
                    });
                    formHolder.add(addPmntBtn);
                }
                return formHolder;
            };
            var doesTotalExceedThreshold = function () {
                var ttl = Ti.App.OrderObj.ActiveTotal;

                return Config && Config.FORCE_CC_THRESHOLD && !(parseFloat(Config.FORCE_CC_THRESHOLD) > parseFloat(ttl));
            };
            var getThresholdView = function () {
                var ccMsg = Config && Config.FORCE_CC_MSG && Config.FORCE_CC_MSG.length ? Config.FORCE_CC_MSG : "Some payment options are not available for your order.";
                var thresholdView = Ti.UI.createView({
                    layout: 'horizontal',
                    width: Ti.UI.FILL,
                    height: ro.ui.relY(16)
                });
                var alertImg = Ti.UI.createImageView({
                    left: ro.ui.relX(2),
                    height: Ti.UI.FILL,
                    image: '/images/alertImg.png'
                });
                var ccThresholdLbl = Ti.UI.createLabel({
                    text: ccMsg,
                    textAlign: 'left',
                    color: ro.ui.theme.backgroundpngTxt,
                    font: {
                        fontSize: ro.ui.scaleFont(12, 0, 0),
                        fontFamily: ro.ui.fontFamily
                    },
                    left: ro.ui.relX(2)
                });
                thresholdView.add(alertImg);
                thresholdView.add(ccThresholdLbl);
                return thresholdView;
            };

            function saveFav() {
                try {
                    if (!isGuest && favoritesTextBox && favoritesTextBox.value && favoritesTextBox.value.length) {
                        favVal = favVal || require("validation/favesValidation");
                        if (!favVal.favNameValidate(favoritesTextBox.value)) {
                            ro.ui.hideLoader();
                            return false;
                        }
                    }
                    return true;
                } catch (ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('saveFav()-Exception: ' + ex);
                    }
                }
            }

            function saveOrdNote() {
                try {
                    if (allowNote) {
                        if (specialNotesTextBox.value && specialNotesTextBox.value.length) {
                            if (specialNotesTextBox.value.length > 32) {
                                ro.ui.alert('Error: ', 'Special Instructions must not exceed 32 characters.');
                                ro.ui.hideLoader();
                                return false;
                            }
                            //Ti.include('/validation/regexValidation.js');
                            regexVal = regexVal || require("validation/regexValidation");
                            var spSuccess = regexVal.regExValidate({
                                spclInst: specialNotesTextBox.value
                            });
                            if (spSuccess.value) {
                                Ti.App.Properties.setString('spclInst', specialNotesTextBox.value);
                            } else {
                                ro.ui.alert('Error: ', spSuccess.issues[0]);
                                ro.ui.hideLoader();
                                return false;
                            }
                        }
                    }
                    return true;
                } catch (ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('saveOrdNote()-Exception: ' + ex);
                    }
                }
            }

            function saveGateCode() {
                try {
                    if (gateCodeBln && gateCodeTextBox.value && gateCodeTextBox.value.length > 0) {
                        if (gateCodeTextBox.value.length > 12) {
                            ro.ui.alert('Error: ', 'Gate Code must not exceed 12 characters.');
                            ro.ui.hideLoader();
                            return false;
                        }

                        regexVal = regexVal || require("validation/regexValidation");
                        var gateCodeSuccess = regexVal.regExValidate({
                            gateCode: gateCodeTextBox.value
                        });
                        if (gateCodeSuccess.value) {
                            Ti.App.Properties.setString('gateCode', gateCodeTextBox.value);
                        } else {
                            ro.ui.alert('Error: ', gateCodeSuccess.issues[0]);
                            ro.ui.hideLoader();
                            return false;
                        }
                    } else {
                        ro.utils.removeProp('gateCode');
                    }
                    return true;
                } catch (ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('saveGateCode()-Exception: ' + ex);
                    }
                }
            }

            function saveVehicleInfo() {
                if (!isGuest && isCurbside && !hasSavedVehicles) {
                    var vhclInfo = ro.forms.getValues(carForm);                    
                    var validate = require("validation/vehicleValidation");
                    var vehicleSuccess = validate.vehicleValidate(vhclInfo);
                    if (vehicleSuccess.value) {
                        if (vhclInfo.vhclSave) {
                            vhclControl.silentSave(vhclInfo, function (vhclId) {
                                vhclInfo.vehicleId = vhclId;
                                //Writing this code twice as this method can sometimes take time and just needs to be full proof
                                Ti.App.Properties.setString('vhclInfo', JSON.stringify(vhclInfo));
                            });
                        }
                        Ti.App.Properties.setString('vhclInfo', JSON.stringify(vhclInfo));                                              
                    } else {
                        ro.ui.alert('Error: ', vehicleSuccess.issues[0]);
                        ro.ui.hideLoader();
                        return false;
                    }
                } 
                return true;                
            }
            
            function getiOSPicker(Obj) {
			                var pickRows = [];
			                for(i=0; i< Obj.length; i++){
			                	pickRows.push({title: Obj[i].Name, id: i});
			                }			                
			
			                var picker = Ti.UI.createPicker({
			                    selectionIndicator: true,
			                    type: Ti.UI.PICKER_TYPE_PLAIN,
			                    top: ro.isiOS ? 13 : 0
			                });
			                
			                picker.width = Ti.UI.FILL;
			                picker.height = Ti.UI.FILL;		               
			
			                picker.add(pickRows);
			                return picker;
			}

            function getAndroidPicker(defaultText, pickRowData, pickChangeEvt, isFullRowWidth, firstOrLast) {
                //Ti.API.info('pickRowData: ' + JSON.stringify(pickRowData));
                var pickerParent = Ti.UI.createView({
                    width: isFullRowWidth ? '100%' : (ro.ui.properties.wideViewWidth - 2 * innerTablePadding) * .333,
                    height: Ti.UI.FILL
                });
                var picker = Ti.UI.createPicker(ro.combine(ro.ui.properties.allTxtField, {
                    type: Ti.UI.PICKER_TYPE_PLAIN,
                    height: Ti.UI.FILL,
                    focusable: true,
                    //selectionOpens:true,
                    zindex: 5,
                    width: Ti.UI.FILL,
                    opacity: 0,
                    backgroundColor: 'white'
                }));
                picker.add(pickRowData);

                if (pickChangeEvt) {
                    picker.addEventListener('change', pickChangeEvt);
                }

                var fieldObject = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
                    height: ro.ui.relY(50),
                    //width:ro.ui.relX(325),
                    //top:ro.ui.relY(0),
                    //bottom:ro.ui.relY(25),
                    text: defaultText,
                    textData: defaultText,
                    picker: picker,
                    specialType: 'iospicker',
                    width: isFullRowWidth ? '100%' : (firstOrLast ? Ti.UI.FILL : (ro.ui.properties.wideViewWidth - 2 * innerTablePadding) * .31)
                }));
                var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                    text: defaultText,
                    textData: defaultText,
                    left: ro.ui.relX(13),
                    touchEnabled: false
                }));
                var arrowSize = isFullRowWidth ? ro.ui.relX(40) : ro.ui.relY(30);
                var arrowRight = isFullRowWidth ? ro.ui.relX(5) : ro.ui.relX(3);
                var arrowImg = Ti.UI.createImageView({
                    image: '/images/downArrow.png',
                    height: arrowSize,
                    width: arrowSize,
                    right: arrowRight,
                    touchEnabled: false
                });
                fieldObject.add(lbl);
                fieldObject.add(arrowImg);
                fieldObject.add(fieldObject.picker);

                function setLblText(newTxt, newTxtData) {
                    fieldObject.text = newTxt;
                    fieldObject.textData = newTxtData;
                    lbl.text = newTxt;
                    lbl.textData = newTxtData;
                }
                //fieldObject.setLblText = setLblText;
                pickerParent.setLblText = setLblText;
                pickerParent.add(fieldObject);
                pickerParent.getChosenRow = function () {
                    // Ti.API.info('fieldObject.picker.getSelectedRow(0): ' + JSON.stringify(fieldObject.picker.getSelectedRow(0)));
                    return fieldObject.picker.getSelectedRow(0);
                };
                pickerParent.setFutureDate = function (rowIndex) {
                    fieldObject.picker.setSelectedRow(0, rowIndex);
                    var selRow = fieldObject.picker.getSelectedRow(0);

                    setLblText(selRow.title, selRow.title);
                };

                pickerParent.pickRowData = pickRowData;
                return pickerParent;
            }

            function getNowOrLaterRows(rowData) {
                var rows = [];
                for (var i = 0, iMax = rowData && rowData.length ? rowData.length : 0; i < iMax; i++) {
                    rows.push(Ti.UI.createPickerRow({
                        title: rowData[i].toString(),
                        id: i
                    }));
                }

                return rows;
            }

            function getPicker(pickerTxt, isFullRowWidth) {
                var picker = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
                    height: Ti.UI.FILL,
                    width: isFullRowWidth ? '100%' : '45%' //,
                    //top:ro.ui.relY(5),
                    //bottom:ro.ui.relY(25)
                }));
                var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                    text: pickerTxt,
                    left: ro.ui.relX(10),
                    touchEnabled: false
                }));
                var arrowImg = Ti.UI.createImageView({
                    image: '/images/downArrow.png',
                    height: ro.ui.relY(40),
                    width: ro.ui.relY(40),
                    right: ro.ui.relX(5),
                    touchEnabled: false
                });
                picker.add(lbl);
                picker.add(arrowImg);
                picker.setPickText = function (text) {
                    lbl.text = text;
                };
                picker.getCurrentSelection = function () {
                    var returnNum = 0;
                    if (!lbl || !lbl.text || !lbl.text.length) {
                        return returnNum;
                    }

                    if (lbl.text.toLowerCase() == 'now') {
                        returnNum = 0;
                    } else if (lbl.text.toLowerCase() == 'future') {
                        returnNum = 1;
                    }

                    return returnNum;
                };
                return picker;
            }

            function isPaymentValid() {
                var paymentValid = false;

                if (Ti.App.OrderObj.DisplayOrdPayment) {
                    if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'credit') {
                        paymentValid = payControl.hasChosenCard();
                        //returns true if creditcard object exists and has all neccessary information. Otherwise returns false.
                    } else if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup') {
                        paymentValid = true;
                        var test = Ti.App.OrderObj;
                        test.LUToken = levelUp.getToken();
                        if (!test.LUToken || !test.LUToken.length) {
                            if (CustInfo.LUToken) {
                                test.LUToken = CustInfo.LUToken;
                            }
                        }
                        Ti.App.OrderObj = test;
                        test = null;
                    } else if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'applepay'){
                        paymentValid = payControl.hasApplePay();
                        
                    } else {
                        if (paymentTypesObj && paymentTypesObj.PayUponOptions) {
                            for (var i = 0; i < paymentTypesObj.PayUponOptions.length; i++) {
                                if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == paymentTypesObj.PayUponOptions[i].toLowerCase()) {
                                    paymentValid = true;
                                    break;
                                }
                            }
                        }
                    }
                }
                return paymentValid;
            }

            function submitPaymentEvt() {
                try {
                    Ti.API.info("submit Payment called");
                    if (new Date().getTime() - submitLastClickTime < 350) {
                        Ti.API.debug('returning');
                        return;
                    }
                    var thisClickTime = new Date();
                    submitLastClickTime = thisClickTime.getTime();
                    thisClickTime = null;
                    blurTextFields();
                    ro.GlobalPicker.hidePicker();
                    ro.ui.showLoader();
                    var test = Ti.App.OrderObj;
                    test.Tip = 0.00;
                    Ti.App.OrderObj = test;
                    test = null;
                    if (!ro.isiOS)
                        Ti.UI.Android.hideSoftKeyboard();

                    if (allowMultiPmts && MultiPmtSwitch && MultiPmtSwitch.thevalue){
                        if (!mp.IsPaymentValid()) {
                            ro.ui.alert('Error: ', 'The remaining balance of $' + mp.getCurrentBalanceDue() + ' is required to continue.');
                            ro.ui.hideLoader();
                            return;
                        }
                    }
                    if (doPrivacy) {
                        if (!privacyPolicy.hasAccepted()) {
                            ro.ui.hideLoader();
                            return;
                        }
                    }
                    if (!saveVehicleInfo() || !saveFav() || !saveOrdNote() || !saveGateCode()) {
                        return;
                    }
                    var ccTip = 0;

                    if (payForms && payForms[paymentTypeView.selectedIndex] && !(allowMultiPmts && multiPmts && multiPmts.DoMultiPmts)) {
                        payForms[paymentTypeView.selectedIndex].SubmitForm(ccTip, finalizeOrder);
                    } else {
                        var test = Ti.App.OrderObj;
                        test.IsOnline = true;

                        //test.ordOnlineOptions.CCInfo = null;
                        //test.ordOnlineOptions.CCInfoCol = null;
                        var pmntType = paymentTypeView.dispordpayment ? paymentTypeView.dispordpayment.replace(' ', '') : '';
                        if (pmntType && pmntType != '') {
                            pmntType = pmntType.charAt(0).toUpperCase() + pmntType.slice(1).toLowerCase();
                        }
                        test.DisplayOrdPayment = pmntType;
                        Ti.API.info(pmntType);
                        //test.DisplayOrdPayment = paymentTypeView.dispordpayment ? paymentTypeView.dispordpayment.replace(' ', '') : '';
                        Ti.App.OrderObj = test;
                        finalizeOrder();
                    }
                } catch(ex) {
                    
                        Ti.API.info('submit order(Event)-Exception: ' + ex);
                   
                }
            }

            function finalizeOrder() {
                var paymentValid = false;
                if (Ti.App.OrderObj.DisplayOrdPayment && (!multiPmts || !multiPmts.DoMultiPmts)) {
                    if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'credit') {
                        paymentValid = payControl.hasChosenCard();
                        //Ti.API.info("is payment valid:" + JSON.stringify(Ti.App.OrderObj.ordOnlineOptions.CCInfo));
                        //returns true if creditcard object exists and has all neccessary information. Otherwise returns false.
                    } else if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup') {
                        paymentValid = true;
                        var test = Ti.App.OrderObj;
                        test.LUToken = levelUp.getToken();
                        if (!test.LUToken || !test.LUToken.length) {
                            if (CustInfo.LUToken) {
                                test.LUToken = CustInfo.LUToken;
                            }
                        }
                        Ti.App.OrderObj = test;
                        test = null;
                    } else if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'applepay'){
                        paymentValid = payControl.hasApplePay();
                        
                    }
                    else {
                        if (paymentTypesObj && paymentTypesObj.PayUponOptions) {
                            for (var i = 0; i < paymentTypesObj.PayUponOptions.length; i++) {
                                if (Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == paymentTypesObj.PayUponOptions[i].toLowerCase()) {
                                    paymentValid = true;
                                    break;
                                }
                            }
                        }
                    }
                } else if (allowMultiPmts && multiPmts && multiPmts.DoMultiPmts) {
                    paymentValid = mp.IsPaymentValid();

                    if (paymentValid) {
                        for (var i = 0,
                            iMax = multiPmts.MultiPmts.length; i < iMax; i++) {
                            multiPmts.MultiPmts[i].PaymentAmt = parseFloat(multiPmts.MultiPmts[i].PaymentAmt);
                        }
                        var test = Ti.App.OrderObj;
                        var ccInfoCol = mp.GetCCInfoCol();
                        test.ordOnlineOptions.CCInfoCol = ccInfoCol;
                        test.DisplayOrdPayment = ccInfoCol && ccInfoCol.length ? (ccInfoCol[0].IsGiftCard ? "Gift" : "Credit") : (multiPmts.MultiPmts && multiPmts.MultiPmts.length ? multiPmts.MultiPmts[0].CardInfo : "Cash");
                        Ti.App.OrderObj = test;
                        test = null;
                    }
                }

                if (!paymentValid) {
                    ro.ui.alert('Error: ', 'Please select mode of payment.');
                    ro.ui.hideLoader();
                    return;
                }

                if (doNoEClubLoyalty) {
                    ro.REV_LOYALTY.setNoEClubOrderObject();
                }
                /*else if (isSpecialLtyNoEclub) {
                                       var optInVal = ro.REV_LOYALTY.setNoEClubOrderObject();
                                   } */
                else if (Ti.App.OrderObj.DisplayOrdPayment && Ti.App.OrderObj.DisplayOrdPayment.length && Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup') {
                    ro.REV_LOYALTY.setNoEClubOptOut(1);
                    //sends false for the optout property since they obviously signed up for levelup and are paying with levelup
                } else {
                    ro.REV_LOYALTY.setNoEClubOptOut(CustInfo.LtyOptIn);
                }

                if (doLoyalty) {
                    ro.REV_LOYALTY.setOrderObject();
                } else if (Ti.App.OrderObj.DisplayOrdPayment && Ti.App.OrderObj.DisplayOrdPayment.length && Ti.App.OrderObj.DisplayOrdPayment.toLowerCase() == 'levelup') {
                    ro.REV_LOYALTY.setOptOut(1);
                    //sends false for the optout property since they obviously signed up for levelup and are paying with levelup
                } else {
                    ro.REV_LOYALTY.setOptOut(CustInfo.EClubOptIn);
                }

                var gateCode = null;

                if (!ro.isiOS && Ti.App.allowFuture) {
                    if (nowOrLaterPicker && nowOrLaterPicker.getChosenRow && nowOrLaterPicker.getChosenRow().title.toLowerCase() == 'future') {
                        ro.GlobalPicker.hidePicker();
                        if (!ro.isiOS) {
                            Ti.UI.Android.hideSoftKeyboard();
                        }

                        var dayRow = orderTimeView.children[0].getChosenRow();
                        var hrRow = orderTimeView.children[1].getChosenRow();
                        var minRow = orderTimeView.children[2].getChosenRow();

                        futureTimeObj = {};

                        futureTimeObj.day = dayRow.id;
                        futureTimeObj.hr = hrRow.id;
                        futureTimeObj.min = minRow.id;
                        futureTimeObj.dateValue = dayRow.obj.date;
                        futureTimeObj.hrValue = hrRow.val;
                        futureTimeObj.minValue = minRow.title;
                        futureTimeObj.dateText = dayRow.title;

                        var hourParts = hrRow.title.split(" ");
                        var timeText = hourParts[0] + ":" + minRow.title + " " + hourParts[1];

                        futureTimeObj.timeText = timeText;

                        Ti.App.Properties.setString('futureTimeObj', JSON.stringify(futureTimeObj));
                    }
                }

                payControl.processOrder();
                
            }

            function getDateTimePicker(_cb, _cb2) {
                var boundaries;
                futureTimePicker = Ti.UI.createPicker({
                    selectionIndicator: true,
                    type: Ti.UI.PICKER_TYPE_PLAIN,
                    top: ro.isiOS ? 13 : 0,
                    //zIndex:55,
                    useSpinner: true
                });
                if (true) {
                    futureTimePicker.width = Ti.UI.FILL;
                    futureTimePicker.height = Ti.UI.FILL;
                }
                var TIME_PICKER = require('logic/timePicker');
                TIME_PICKER.formDateTime(futureTimePicker, function (dayArray, hrArray, minArray, bounds) {
                    //var minCol = [], hrCol = [], dayCol = [];
                    if (bounds) {
                        boundaries = bounds;
                    }

                    if (dayArray && dayArray.length && _cb2) {

                        //Ti.API.debug('dayArray: ' + JSON.stringify(dayArray));
                        //Ti.API.debug('hrArray: ' + JSON.stringify(hrArray));
                        //Ti.API.debug('minArray: ' + JSON.stringify(minArray));
                        //var dayRow = futureTimePicker.getSelectedRow(0);
                        //var hrRow = futureTimePicker.getSelectedRow(1);
                        //var minRow = futureTimePicker.getSelectedRow(2);
                        futureTimeObj = {};
                        //directSetLbls(dayRow, hrRow, minRow);

                        //futureTimeObj.day = dayRow.id;
                        futureTimeObj.day = 0;
                        //futureTimeObj.hr = hrRow.id;
                        futureTimeObj.hr = dayArray[0].minHrIndex;
                        //futureTimeObj.min = minRow.id;
                        futureTimeObj.min = dayArray[0].minMinIndex;
                        //futureTimeObj.dateValue = dayRow.obj.date;
                        futureTimeObj.dateValue = dayArray[0].date;
                        //futureTimeObj.hrValue = hrRow.val;
                        futureTimeObj.hrValue = hrArray[dayArray[0].minHrIndex].val;
                        //futureTimeObj.minValue = minRow.title;
                        futureTimeObj.minValue = minArray[dayArray[0].minMinIndex].toString();

                        futureTimeObj.dateText = dayArray[0].disp;
                        var hourParts = hrArray[dayArray[0].minHrIndex].disp.split(" ");
                        var timeText = hourParts[0] + ":" + minArray[dayArray[0].minMinIndex].toString() + " " + hourParts[1];
                        futureTimeObj.timeText = timeText;
                        Ti.App.Properties.setString('futureTimeObj', JSON.stringify(futureTimeObj));
                        _cb2(dayArray[0], hrArray, minArray);
                        return;
                    }

                    var dayCol = Ti.UI.createPickerColumn();
                    var hrCol = Ti.UI.createPickerColumn();
                    var minCol = Ti.UI.createPickerColumn();
                    if (!ro.isiOS) {
                        dayCol.width = ro.ui.displayCaps.platformWidth * .33;
                        hrCol.width = ro.ui.displayCaps.platformWidth * .33;
                        minCol.width = Ti.UI.FILL;
                    }

                    if (dayArray.length) {
                        boundaries = dayArray[0];
                        for (var i = 0; i < minArray.length; i++) {
                            minCol.addRow(Ti.UI.createPickerRow({
                                title: minArray[i].toString(),
                                id: i
                            }));
                        }

                        for (var i = 0; i < hrArray.length; i++) {

                            hrCol.addRow(Ti.UI.createPickerRow({
                                title: hrArray[i].disp,
                                val: hrArray[i].val,
                                id: i
                            }));
                        }

                        for (var i = 0; i < dayArray.length; i++) {

                            dayCol.addRow(Ti.UI.createPickerRow({
                                title: dayArray[i].disp,
                                obj: dayArray[i],
                                id: i
                            }));
                        }

                        futureTimePicker.add([dayCol, hrCol, minCol]);
                        ro.GlobalPicker.setPicker(futureTimePicker, getToolbar());
                        _cb(dayArray[0], hrArray, minArray);
                    }

                });




                //return futureTimePicker;
            }

            function getToolbar() {
                var picToolbar = ro.isiOS ? Ti.UI.createToolbar({
                    top: 0,
                    zIndex: 2,
                    width: Ti.UI.FILL
                }) : Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: ro.ui.relY(40),
                    top: 0
                });
                var picCancel = Ti.UI.createButton({
                    title: 'Cancel',
                    id: 1,
                    left: ro.ui.relX(20)
                });
                var picDone = Ti.UI.createButton({
                    title: 'Done',
                    id: 0,
                    right: ro.ui.relX(20)
                });
                picCancel.addEventListener('click', function () {
                    ro.GlobalPicker.hidePicker();
                });
                picDone.addEventListener('click', function () {

                    //Ti.API.debug('futureTimePicker.getSelectedRow(0): ' + JSON.stringify(futureTimePicker.getSelectedRow(0)));
                    //Ti.API.debug('futureTimePicker.getSelectedRow(1): ' + JSON.stringify(futureTimePicker.getSelectedRow(1)));
                    //Ti.API.debug('futureTimePicker.getSelectedRow(2): ' + JSON.stringify(futureTimePicker.getSelectedRow(2)));
                    var dayRow = futureTimePicker.getSelectedRow(0);
                    var hrRow = futureTimePicker.getSelectedRow(1);
                    var minRow = futureTimePicker.getSelectedRow(2);
                    //Ti.API.info("day row Obj: "+JSON.stringify(dayRow.obj));
                    //Ti.API.info("hr row: "+JSON.stringify(hrRow));
                    //Ti.API.info("min row: "+JSON.stringify(minRow));
                    if (hrRow.id < dayRow.obj.minHrIndex
                        || hrRow.id > dayRow.obj.maxHrIndex
                        || (hrRow.id === dayRow.obj.minHrIndex && minRow.id < dayRow.obj.minMinIndex)
                        || (hrRow.id === dayRow.obj.maxHrIndex && minRow.id > dayRow.obj.maxMinIndex)) return;
                    futureTimeObj = {};
                    //directSetLbls(dayRow, hrRow, minRow);
                    datePicker.setPickText(dayRow.title);
                    var hourParts = hrRow.title.split(" ");
                    var timeText = hourParts[0] + ":" + minRow.title + " " + hourParts[1];
                    timePicker.setPickText(timeText);

                    futureTimeObj.day = dayRow.id;
                    futureTimeObj.hr = hrRow.id;
                    futureTimeObj.min = minRow.id;
                    futureTimeObj.dateValue = dayRow.obj.date;
                    futureTimeObj.hrValue = hrRow.val;
                    futureTimeObj.minValue = minRow.title;

                    futureTimeObj.dateText = dayRow.title;
                    var hourParts = hrRow.title.split(" ");
                    var timeText = hourParts[0] + ":" + minRow.title + " " + hourParts[1];

                    futureTimeObj.timeText = timeText;
                    Ti.App.Properties.setString('futureTimeObj', JSON.stringify(futureTimeObj));

                    ro.GlobalPicker.hidePicker();
                    /*if (Ti.App.atPayScrn === true) {
                        ro.ui.cartShowNext({
                            addView : true,
                            showing : 'paymentScreen'
                        });
                    } else {
                        ro.ui.ordShowNext({
                            addView : true,
                            showing : 'grpsItems'
                        });
                    }*/

                });

                if (ro.isiOS) {
                    var picSpacer = Ti.UI.createButton({
                        systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
                    });
                    picDone.style = Ti.UI.iOS.SystemButtonStyle.DONE;
                    picCancel.style = Ti.UI.iOS.SystemButtonStyle.DONE;
                    //picToolbar.add(picSpacer);
                    picToolbar.items = [picCancel, picSpacer, picDone];
                } else {
                    picToolbar.add(picCancel);
                    picToolbar.add(picDone);
                }

                return picToolbar;
            }

            function getNowOrLaterPicker() {
                var pickRows = [];
                if (!Ti.App.futureOnly) {
                    var nowRow = ro.isiOS ? {
                        title: "Now"
                    } : Ti.UI.createPickerRow({
                        title: "Now"
                    });
                    pickRows.push(nowRow);
                }
                var futureRow = ro.isiOS ? {
                    title: "Future"
                } : Ti.UI.createPickerRow({
                    title: "Future"
                });
                pickRows.push(futureRow);

                var picker = Ti.UI.createPicker({
                    selectionIndicator: true,
                    type: Ti.UI.PICKER_TYPE_PLAIN,
                    //useSpinner:true,
                    top: ro.isiOS ? 13 : 0
                });
                if (true) {
                    picker.width = Ti.UI.FILL;
                    picker.height = Ti.UI.FILL;
                }

                picker.add(pickRows);
                return picker;
            }

            function getPaymenyDivider() {
                var paymentDivider = Ti.UI.createView({
                    width: ro.ui.displayCaps.platformWidth,
                    height: ro.ui.relY(2),
                    backgroundColor: '#e4e4e4',
                    isDivider: true,
                    touchEnabled: false
                });
                return paymentDivider;
            }

            function getPaymentRow(paymentObj) {
                var smallRowHeight = ro.ui.relY(50);
                var paymentRow = Ti.UI.createView(ro.combine(paymentObj, {
                    width: ro.ui.displayCaps.platformWidth,
                    height: Ti.UI.SIZE,
                    isSelected: false,
                    layout: 'vertical'
                }));
                var checkLabelView = Ti.UI.createView({
                    width: ro.ui.displayCaps.platformWidth,
                    height: smallRowHeight,
                    touchEnabled: false,
                    top: 0
                });
                var paymentRowLabel = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                    //width:ro.ui.properties.wideViewWidth - (2*innerTablePadding),
                    width: ro.ui.properties.wideViewWidth - (2 * ro.ui.relX(25)),
                    //left:ro.ui.relX(25),
                    //right:innerTablePadding,
                    height: smallRowHeight,
                    textAlign: 'left',
                    text: paymentObj.specialTitle && paymentObj.specialTitle.length ? paymentObj.specialTitle : paymentObj.title,
                    touchEnabled: false
                }));
                checkLabelView.add(paymentRowLabel);

                var checkView = Ti.UI.createImageView({
                    image: '/images/check.png',
                    //height:Ti.UI.FILL,
                    top: ro.ui.relY(10),
                    bottom: ro.ui.relY(10),
                    right: ro.ui.relX(10),
                    touchEnabled: false,
                    visible: false
                });
                //paymentRow.checkView = checkView;
                checkLabelView.add(checkView);

                paymentRow.add(checkLabelView);
                var rowForm = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: ro.ui.displayCaps.platformWidth
                });
                paymentRow.add(rowForm);
                paymentRow.changeSelection = function (selectBln) {
                    //if(selectBln){
                    //Ti.API.info('paymentRow.title: ' + paymentRow.title);
                    //Ti.API.info('selectBln: ' + selectBln);
                    checkView.visible = selectBln;
                    paymentRow.isSelected = selectBln;
                    CC_TIPS.Init('', true, false, false, mp.updateTotals);
                    if (!selectBln) {
                        paymentRow.addForm();
                    }
                    //}
                };
                paymentRow.addForm = function (form) {
                    if (!form) {
                        rowForm.removeAllChildren();
                        //rowForm.height = 0;
                        checkLabelView.height = smallRowHeight;
                        return;
                    }

                    if (form.height == 0) {

                    } else {
                        //checkLabelView.height = 0;
                        // Ti.API.info('FORM Added');
                        rowForm.add(form);
                    }
                    /*checkLabelView.height = 0;
                    rowForm.add(form);*/
                };

                return paymentRow;
            }
            var payControl = require('controls/paymentControl');
            var credCardVal = require('validation/creditcardValidation');
            var regexVal = require('validation/regexValidation');
            var favVal,
                regexVal,
                doPrivacy,
                isGuest,
                Config,
                gateCodeBln,
                rs,
                CustInfo,
                isSpecialLtyNoEclub,
                registerRewards,
                levelUp,
                doLoyalty,
                doNoEClubLoyalty,
                favCount,
                clickTime,
                isDeliv,
                innerTablePadding,
                futureTimePicker,
                hasCC,
                hasPayupon;

            innerTablePadding = ro.ui.relX(15);

            rs = ro.db.getCustObj(Ti.App.Username);
            gateCodeBln = false;

            clickTime = null;
            favCount = 0;
            Ti.API.info('Ti.App.OrderObj.Cpns: ' + JSON.stringify(Ti.App.OrderObj.Cpns));
            //GUEST ORDER 
            isGuest = false;
            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                isGuest = true;
                rs = {};
            }
            //GUEST ORDER

            try {
                if (!isGuest && rs.PrevOrders && rs.PrevOrders.length) {
                    for (var i = 0; i < rs.PrevOrders.length; i++) {
                        if (rs.PrevOrders[i].Name) {
                            favCount++;
                        }
                    }
                }
            } catch (ex) {
                favCount = 5;
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('Error with prevOrd: ' + ex);
                }
            }
            if (isGuest) {
                favCount = 5;
            }

            Config = JSON.parse(Ti.App.Properties.getString('Config'));
            if (!Config) {
                Config = {};
            }
            CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
            if (!CustInfo) {
                CustInfo = {};
            }

            //////////      Privacy Policy      ///////////
            doPrivacy = false;
            privacyPolicy.Init(Config.Docs, Config.PrivacyUrl, Config.TermsUrl, Config.DocsDate, Config.CompanyName, CustInfo.TermsDate ? CustInfo.TermsDate : false, Config.TERMS_PRIVACY_POLICY ? Config.TERMS_PRIVACY_POLICY : false);
            doPrivacy = privacyPolicy.isEnabled() == true ? true : false;
            //////////      Privacy Policy      ///////////

            isSpecialLtyNoEclub = false;
            if (false && ro.app.Store.Configuration.LTY_CHK_PTS && ro.app.Store.Configuration.LTY_CHK_PTS.length) {
                switch (ro.app.Store.Configuration.LTY_CHK_PTS.replace(/ /g, '').toLowerCase()) {
                    case 'notenrolled':
                        isSpecialLtyNoEclub = true;
                        break;
                    case 'all':
                        if (rs.LtyOptIn == 0 || rs.LtyOptIn == 2) {
                            isSpecialLtyNoEclub = true;
                        }
                        break;
                }
            }
            if (isGuest) {
                isSpecialLtyNoEclub = false;
            }

            //////////          LEVELUP         ///////////
            //var cfg = ro.app.Store.Configuration ? ro.app.Store.Configuration : {};
            //Ti.App.Properties.setString('Config', JSON.stringify(cfg));
            registerRewards = false;
            levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
            if (levelUp.isLU) {
                levelUp.Init(ro.app.Store.Configuration);
                registerRewards = levelUp.isSiteRewardsCapable();
            }
            //////////          LEVELUP         ///////////

            //////////        LOYALTY        ///////////
            ro.REV_LOYALTY.init();
            doLoyalty = ro.REV_LOYALTY.isEnabled();
            if (doLoyalty) {
                doLoyalty = ro.REV_LOYALTY.isEnabledAtPayment();
            }
            doNoEClubLoyalty = ro.REV_LOYALTY.isLoyaltyNoEClubEnabled();
            if (isSpecialLtyNoEclub) {
                doNoEClubLoyalty = false;
            }
            if (doNoEClubLoyalty) {
                doNoEClubLoyalty = ro.REV_LOYALTY.isLoyaltyNoEClubEnabledAtPayment();
                if (!doNoEClubLoyalty) {
                    doNoEClubLoyalty = ro.REV_LOYALTY.haveTermsChanged();
                }
            }
            //////////        LOYALTY        ///////////
            var textBoxCol = [];

            function getKeyboardToolbar(keyboardBtnId, doneEvt, nextEvt) {
                var picNext = Ti.UI.createButton({
                    title: 'Next',
                    style: Ti.UI.iOS.SystemButtonStyle.DONE,
                    id: keyboardBtnId
                });
                var picDone = Ti.UI.createButton({
                    title: 'Done',
                    style: Ti.UI.iOS.SystemButtonStyle.DONE,
                    id: keyboardBtnId
                });

                var picSpacer = Ti.UI.createButton({
                    systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
                });

                var picToolbar = Ti.UI.createToolbar({
                    top: 0,
                    items: [picSpacer, picDone],
                    zIndex: 2,
                    width: Ti.UI.FILL
                });

                picDone.addEventListener('click', doneEvt);
                picNext.addEventListener('click', nextEvt);

                return picToolbar;
            };

            //MAINVIEW AND NAVBAR SETUP
            var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                hid: 'paymentScreen'
            }));

            var topNavBar = Ti.UI.createView(ro.ui.properties.navBar);
            var btnContinue = layoutHelper.getBackBtn("Cart", null, true);
            topNavBar.add(btnContinue);
            btnContinue.addEventListener('click', function (e) {
                ro.GlobalPicker.hidePicker();
                blurTextFields();
                payControl.clearPaymentInfo();
                try {
                    ro.utils.removeProp('favName');
                } catch (ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('btnBack(newPaymentView - event)-Exception: ' + ex);
                    }
                }
                ro.ui.cartShowNext({
                    showing: 'paymentScreen'
                });
            });
            //mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));

            if (ro.isiphonex) {
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            } else {
                mainView.add(ro.ui.getNavBar(topNavBar, Ti.App.logoStyle));
            }

            var paymentView = Ti.UI.createScrollView({
                name: 'Summary',
                top: ro.ui.properties.topAfterNavbar,
                bottom: 0,
                disableBounce: ro.isiOS ? true : false,
                contentWidth: Ti.UI.FILL,
                layout: 'vertical'
            });
            //MAINVIEW AND NAVBAR SETUP

            //BOTTOM NAVIGATION
            var bottomNavigationView = Ti.UI.createView({
                height: ro.ui.relY(60),
                width: Ti.UI.FILL,
                bottom: 0
            });
            var leftVw,
                middleVw,
                rightVw;

            leftVw = Ti.UI.createView({
                height: Ti.UI.FILL,
                width: '35%',
                left: 0,
                layout: 'vertical'
                /*,
                                 backgroundColor:'green'*/
            });
            leftVw.add(Ti.UI.createImageView({
                image: '/images/leftArrow.png',
                top: 0,
                height: ro.ui.relY(40)
                //bottom:20
            }));
            leftVw.add(Ti.UI.createLabel({
                text: 'Back',
                height: ro.ui.relY(20),
                color: '#666',
                font: {
                    fontFamily: ro.ui.fontFamily,
                    fontSize: ro.ui.scaleFont(14)
                }
            }));
            leftVw.addEventListener('click', function (e) {
                ro.GlobalPicker.hidePicker();
                blurTextFields();
                ro.ui.cartShowNext({
                    showing: 'Cart'
                });
            });

            middleVw = Ti.UI.createView({
                height: Ti.UI.FILL,
                width: '30%',
                layout: 'vertical'
            });
            middleVw.add(Ti.UI.createImageView({
                image: '/images/clearBtn.png',
                top: 0,
                height: ro.ui.relY(40)
            }));
            middleVw.add(Ti.UI.createLabel({
                text: 'Clear',
                height: ro.ui.relY(20),
                color: '#666',
                font: {
                    fontFamily: ro.ui.fontFamily,
                    fontSize: ro.ui.scaleFont(14)
                }
            }));
            middleVw.addEventListener('click', function () {
                /*a.title = 'Cancel Order';
                 a.message = 'Do you wish to cancel order?';
                 a.buttonNames = ['Yes', 'No'];
                 a.cancel = 1;
                 a.show();*/
            });

            rightVw = Ti.UI.createView({
                height: Ti.UI.FILL,
                width: '35%',
                right: 0,
                layout: 'vertical'
            });
            rightVw.add(Ti.UI.createImageView({
                image: '/images/rightArrow.png',
                top: 0,
                height: ro.ui.relY(40)
            }));
            rightVw.add(Ti.UI.createLabel({
                text: 'Submit',
                height: ro.ui.relY(20),
                color: '#666',
                font: {
                    fontFamily: ro.ui.fontFamily,
                    fontSize: ro.ui.scaleFont(14)
                }
            }));

            var submitLastClickTime = 0;
            rightVw.addEventListener('click', submitPaymentEvt);

            bottomNavigationView.add(leftVw);
            bottomNavigationView.add(middleVw);
            bottomNavigationView.add(rightVw);
            //BOTTOM NAVIGATION
            //END END END END END


            //ORDER TYPE AND LOCATION BLOCK
            if (true) {
                var formattedText = ro.app.Store.Address + '\n' + (ro.app.Store.City + ', ' + ro.app.Store.State + ', ' + ro.app.Store.Zip) + (ro.app.Store.Distance ? '\n(' + ro.app.Store.Distance + ' miles)' : "");
                var estTimeTxt = "";
                for (var x = 0; x < ro.app.Store.Menu.OnlineOptions.OrdTypes.length; x++) {
                    if (ro.app.Store.Menu.OnlineOptions.OrdTypes[x].OrdType == Ti.App.OrderObj.OrdType) {
                        estTimeTxt = ro.app.Store.Menu.OnlineOptions.OrdTypes[x].EstTime + " Minutes";
                        break;
                    }
                }
                var orderTypeBox = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: 0
                });

                var specialTextObj = null;
                if (estTimeTxt != "") {
                    specialTextObj = {
                        specialText: "",
                        specialBoldText: ""
                    };
                    var carryoutLbl = 'Pickup';
                    var deliveryLbl = 'Delivery';
                    if (ro.utils.hasProp(cfg, 'CarryoutLabel')) {
                        carryoutLbl = cfg.CarryoutLabel;
                    }
                    if (ro.utils.hasProp(cfg, 'DeliveryLabel')) {
                        deliveryLbl = cfg.DeliveryLabel;
                    }
                    var specialText = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? deliveryLbl : carryoutLbl) + " - ";
                    //var specialText = "Estimated Order Time: ";
                    var specialBoldText = estTimeTxt;

                    specialTextObj.specialText = specialText;
                    specialTextObj.specialBoldText = specialBoldText;
                }

                //orderTypeBox.add(ro.layout.getGenericHdrRowWithHeader(Ti.App.OrderObj.OrdType + " from", true));
                var orderTypeBoxHdr = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'horizontal'
                });
                var ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.OrdType, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'OrdType');
                var ordName = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName ? ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].RcptName : Ti.App.OrderObj.OrdType;
                var ordTypeHdr = ro.layout.getGenericHdrRowWithHeader(ordName + " from", true);
                ordTypeHdr.width = Ti.UI.SIZE;
                orderTypeBoxHdr.add(ordTypeHdr);
                if (REV_ORD_TYPE.hasMultipleOrdTypes()) {
                    var editLbl = ro.layout.getGenericHdrRowWithHeader("(edit)", false);
                    editLbl.width = Ti.UI.SIZE;
                    editLbl.children[0].left = ro.ui.relX(8);
                    editLbl.children[0].color = ro.ui.theme.itemPriceColor;
                    editLbl.children[0].touchEnabled = true;
                    editLbl.touchEnabled = true;
                    //orderTypeBoxHdr.add(editLbl);
                    editLbl.addEventListener('click', function (e) {
                        REV_ORD_TYPE.promptForSpecificOrdType(function () {
                            ordTypeHdr.children[0].text = Ti.App.OrderObj.OrdType + " from";
                            isCurbside = Ti.App.OrderObj.OrderTypeCategory.toLowerCase() == "curbside";
                            if (isCurbside) {
                                vhclBox.height = Ti.UI.SIZE;
                                vhclBox.top = ro.ui.relY(15);
                            } else {
                                vhclBox.height = 0;
                                vhclBox.top = 0;
                            }
                            if (checkOrdTypeImage()) {
                                
                                orderTypeImage.image = '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png';
                                OrderTypeLabel.text = Ti.App.OrderObj.OrdType; 
                                orderTypeImageHolder.height = Ti.UI.SIZE;
                            } else {
                                orderTypeImageHolder.height = 0;
                            }
                        });

                    });
                }
                orderTypeBox.add(orderTypeBoxHdr);
                orderTypeBox.add(ro.layout.getGenericRowWithHeader({
                    formattedText: formattedText,
                    specialText: specialTextObj,
                    headerText: ro.app.Store.Name,
                    customObj: {
                        borderColor: 'transparent'
                    }
                }));
                var orderTypeImageHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    layout: 'vertical'
                });
                var orderTypeImage = Ti.UI.createImageView({
                    height: ro.ui.relY(51),
                    top: ro.ui.relX(25)
                });
                var OrderTypeLabel = Ti.UI.createLabel({
                    font: {
                        fontSize: ro.ui.scaleFont(22),
                        fontFamily: ro.ui.fonts.titles
                    },
                    touchEnabled: false,
                    top: ro.ui.relX(5),
                    color: '#383938',
                    text: ordName
                });
                var checkOrdTypeImage = function () {
                    Ti.API.info("check Ord Type Image: " + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png').exists());
                    return Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png').exists();                    
                };
                if (checkOrdTypeImage()) {
                    
                    orderTypeImage.image = '/images/' + Ti.App.OrderObj.OrderTypeCategory.toLowerCase() + '_cart.png';
                    orderTypeImageHolder.add(orderTypeImage);
                    orderTypeImageHolder.add(OrderTypeLabel);
                    orderTypeImageHolder.height = Ti.UI.SIZE;
                    orderTypeBox.add(orderTypeImageHolder);
                } else {
                    orderTypeImageHolder.height = '0';
                }
                paymentView.add(orderTypeBox);
            }
            //ORDER TYPE AND LOCATION BLOCK
            //END END END END END END

            var doneFn = function (e) {
                //Ti.API.info('e:' + JSON.stringify(e));
                switch (e.source.id) {
                    case 1:
                        gateCodeTextBox.blur();
                        break;
                    case 2:
                        favoritesTextBox.blur();
                        break;
                    case 3:
                        specialNotesTextBox.blur();
                        break;
                    case 4:
                        otherAmt.blur();
                        break;
                }
            };
            var nextFn = function (e) {
                //Ti.API.info('e:' + JSON.stringify(e));
                var nextNum;

                if (!textBoxCol || !textBoxCol.length) {
                    return;
                }

                if (textBoxCol.length == 1) {
                    var obj = {
                        source: {
                            id: textBoxCol[0]
                        }
                    };
                    doneFn(obj);
                }

                for (var i = 0, iMax = textBoxCol.length; i < iMax; i++) {
                    if (textBoxCol[i] === e.source.id) {
                        if ((i + 1) < iMax) {
                            nextNum = textBoxCol[i + 1];
                            break;
                        } else {
                            nextNum = textBoxCol[0];
                            break;
                        }
                    }
                }
                switch (nextNum) {
                    case 1:
                        gateCodeTextBox.focus();
                        break;
                    case 2:
                        favoritesTextBox.focus();
                        break;
                    case 3:
                        specialNotesTextBox.focus();
                        break;
                }
            };

            function blurTextFields() {

                if (!textBoxCol || !textBoxCol.length) {
                    return;
                }

                for (var i = 0, iMax = textBoxCol.length; i < iMax; i++) {
                    switch (textBoxCol[i]) {
                        case 1:
                            gateCodeTextBox.blur();
                            break;
                        case 2:
                            favoritesTextBox.blur();
                            break;
                        case 3:
                            specialNotesTextBox.blur();
                            break;
                    }
                }
            }


            //CUSTOMER INFORMATION BLOCK
            var prsnlInfoBox = Ti.UI.createView({
                width: ro.ui.properties.wideViewWidth,
                height: Ti.UI.SIZE,
                layout: 'vertical',
                top: ro.ui.relY(15)
            });
            var prsnlInfoTxt = "Personal Information";
            var custEmail, custFN, custLN, custPh;
            if (isGuest) {
                var test = Ti.App.OrderObj;
                custEmail = test.Customer.Email;
                custFN = test.Customer.FName;
                custLN = test.Customer.LName;
                custPh = test.Customer.SelPhone;
                test = null;
            } else {
                custEmail = Ti.App.Username;
                custFN = CustInfo.FirstName;
                custLN = CustInfo.LastName;
                custPh = CustInfo.Phone;
            }
            // Formatting phone number

            function formatPhoneNumber(phoneNumberString) {
                var cleaned = ('' + phoneNumberString).replace(/\D/g, '')
                var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/)
                if (match) {
                    return '(' + match[1] + ') ' + match[2] + '-' + match[3]
                }
                return null
            }

            custPh = formatPhoneNumber(custPh);
            var prsnlInfoHdr = ro.layout.getGenericHdrRowWithHeader(prsnlInfoTxt, true);            
            prsnlInfoHdr.children[0].left = 0;
            prsnlInfoHdr.width = Ti.UI.SIZE;
            prsnlInfoBox.add(prsnlInfoHdr);
            prsnlInfoBox.add(ro.layout.getGenericHdrRowContent(custEmail));
            prsnlInfoBox.add(ro.layout.getGenericHdrRowContent(custFN));
            prsnlInfoBox.add(ro.layout.getGenericHdrRowContent(custLN));
            prsnlInfoBox.add(ro.layout.getGenericHdrRowContent(custPh));
            paymentView.add(prsnlInfoBox);
            //END CUSTOMER INFORMATION BLOCK

            // VEHICLE INFORMATION BLOCK
            var isCurbside = Ti.App.OrderObj.OrderTypeCategory.toLowerCase() == "curbside";            
            var hasSavedVehicles = false;
            var vhclBox = Ti.UI.createView({
                width: ro.ui.properties.wideViewWidth,
                height: isCurbside ? Ti.UI.SIZE : 0,
                layout: 'vertical',
                top: isCurbside ? ro.ui.relY(15) : 0
            });
            var vhclBoxHdr = Ti.UI.createView({
                width: Ti.UI.SIZE,
                height: Ti.UI.SIZE,
                layout: 'horizontal'
            });
            var vhclHdr = ro.layout.getGenericHdrRowWithHeader("Vehicle Information", true);
            vhclHdr.children[0].left = 0;
            vhclHdr.width = Ti.UI.SIZE;
            vhclBoxHdr.add(vhclHdr);
            var vhclImg = Ti.UI.createView({ /*ro.combine(ro.ui.properties.defaultSwitch, {*/
                height: ro.ui.relY(21),
                width: ro.ui.relX(31),
                left: ro.ui.relX(5),
                borderColor: 'transparent',
                backgroundImage: "/images/vehicleIcon.png"
            });
            vhclBoxHdr.add(vhclImg);
            vhclBox.add(vhclBoxHdr);

            var vehicleInfoBox = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: ro.ui.properties.wideViewWidth,
                layout: 'vertical',
                top: ro.ui.relX(10)
            });
            var makeModelBox = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                layout: 'horizontal'
            });
            var colorBox = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                layout: 'horizontal'
            });
            var commentBox = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                layout: 'horizontal'
            });

            var makeModelLabel = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '30%'
            });
            makeModelLabel.add(ro.layout.getMediumRowBoldLbl('Make/Model:'));

            var colorLabel = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '30%'
            });
            colorLabel.add(ro.layout.getMediumRowBoldLbl('Color:'));

            var commentLabel = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '30%'
            });
            commentLabel.add(ro.layout.getMediumRowBoldLbl('Comments:'));

            var makeModelValue = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '70%'
            });
            makeModelValue.add(ro.layout.getMediumRowLbl(''));

            var colorValue = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '70%'
            });
            colorValue.add(ro.layout.getMediumRowLbl(''));

            var commentValue = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: '70%'
            });
            commentValue.add(ro.layout.getMediumRowLbl(''));

            makeModelBox.add(makeModelLabel);
            makeModelBox.add(makeModelValue);

            colorBox.add(colorLabel);
            colorBox.add(colorValue);

            commentBox.add(commentLabel);
            commentBox.add(commentValue);

            vehicleInfoBox.add(makeModelBox);
            vehicleInfoBox.add(colorBox);
            vehicleInfoBox.add(commentBox);

            var vhclButtonHolder = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.SIZE,
                layout: 'horizontal',
                top: ro.ui.relX(10)
            });
            var vhclControl = require("controls/vehicleControl");
            
            if (isGuest) {                
                var guestVhclInfo = JSON.parse(Ti.App.Properties.getString('guestVhclInfo'));
                Ti.API.info("guestVhclInfo: " + JSON.stringify(guestVhclInfo));
                if (!guestVhclInfo) {
                    guestVhclInfo = {};
                } else {
                    setGuestVehicleObj(guestVhclInfo);
                }
                
                function setGuestVehicleObj(vObj) {
                    Ti.App.Properties.setString('vhclInfo', JSON.stringify(vObj));
                    makeModelValue.children[0].text = vObj.make + " " + vObj.model;
                    colorValue.children[0].text = vObj.color;
                    commentValue.children[0].text = vObj.features ? vObj.features : '';
                };

                function fixForVhclControl(obj) {
                    var retObj = {};
                    retObj.Make = obj.make ? obj.make : '';
                    retObj.Model = obj.model ? obj.model : '';
                    retObj.Color = obj.color ? obj.color : '';
                    retObj.Features = obj.features ? obj.features : '';
                    return retObj;
                };

                var vhclEditBtn = vhclControl.getSecondaryButton("Edit");
                
                vhclEditBtn.addEventListener('click', function (e) {
                    vhclControl.openForm(true, fixForVhclControl(guestVhclInfo), function (x) {
                        guestVhclInfo = JSON.parse(Ti.App.Properties.getString('guestVhclInfo'));
                        setGuestVehicleObj(guestVhclInfo);
                    });
                });

                vhclButtonHolder.add(vhclEditBtn);
                
                vhclBox.add(vehicleInfoBox);
                
                vhclBox.add(vhclButtonHolder);
                
            } else {
                var vhclInfoLst = CustInfo.Vehicles;
                hasSavedVehicles = vhclInfoLst && vhclInfoLst.length;
                if (hasSavedVehicles) {
                    function getVhclRows(rowData) {
                        var rows = [];
                        for (i = 0, iMax = rowData && rowData.length ? rowData.length : 0; i < iMax; i++) {
                            rows.push(Ti.UI.createPickerRow({
                                title: rowData[i].Name,
                                id: i
                            }));
                        }
                        return rows;
                    }

                    function setVehicleObj(vObj) {
                        var retObj = {};
                        retObj.make = vObj.Make;
                        retObj.model = vObj.Model;
                        retObj.color = vObj.Color;
                        retObj.features = vObj.Features;
                        retObj.vehicleId = vObj.VehicleID;
                        Ti.App.Properties.setString('vhclInfo', JSON.stringify(retObj));
                        retObj = null;
                        makeModelValue.children[0].text = vObj.Make + " " + vObj.Model;
                        colorValue.children[0].text = vObj.Color;
                        commentValue.children[0].text = vObj.Features;
                    };

                    var vehicleSelectedRowId = 0;                    

                    var vhclSelectFn = function (e) {
                        var selectedRow = e.source.getSelectedRow(0);
                        Ti.API.info('selectedRow: ' + JSON.stringify(selectedRow));
                        if (selectedRow && selectedRow.title) {
                            vhclPicker.setLblText(selectedRow.title, selectedRow.title);
                            setVehicleObj(vhclInfoLst[selectedRow.id]);
                            vehicleSelectedRowId = selectedRow.id;
                            Ti.API.info('Selected Vehicle: ' + JSON.stringify(vhclInfoLst[selectedRow.id]));
                        }
                    };


                    var vhclPicker = ro.isiOS ? getPicker(vhclInfoLst[0].Name, true) : getAndroidPicker(vhclInfoLst[0].Name, getVhclRows(vhclInfoLst), vhclSelectFn, true);
                    vhclPicker.height = Ti.UI.SIZE;
					
                    if (ro.isiOS) {                    	
                        vhclPicker.addEventListener('click', function (e) {
                            blurTextFields();
                            dontDoChangeEvt = true;
                            var vhclValuePicker = getiOSPicker(vhclInfoLst);
                            vhclValuePicker.addEventListener('change', function (ee) {
                                if (dontDoChangeEvt) {
                                    dontDoChangeEvt = false;
                                    return;
                                }
                                //Ti.API.debug('ee: ' + JSON.stringify(ee));
                                var newText;
                                var selectedRow = vhclValuePicker.getSelectedRow(0);
                                newText = selectedRow.title;
                                setVehicleObj(vhclInfoLst[selectedRow.id]);
                                vehicleSelectedRowId = selectedRow.id;
                                //Ti.API.debug('selectedRow: ' + JSON.stringify(selectedRow));
                                if (selectedRow && selectedRow.title) {                                    
                                    vhclPicker.setPickText(newText);
                                }
                            });
                            ro.GlobalPicker.setPicker(vhclValuePicker);
                            
                            ro.GlobalPicker.showPicker();
                            
                            //Ti.API.info('nowOrLaterPicker: ' + JSON.stringify(nowOrLaterPicker));
                            
                            vhclValuePicker.setSelectedRow(0, vehicleSelectedRowId, false);
                            
                        });
                    }                                     
                    var vhclAddBtn = vhclControl.getSecondaryButton("Add");
                    vhclAddBtn.addEventListener('click', function (e) {
                        if (vhclInfoLst.length < 5) {
                            vhclControl.openForm(true, null, function (x) {
                                CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
                                vhclInfoLst = CustInfo.Vehicles;
                                Ti.API.info("returned vhcl list: " + JSON.stringify(vhclInfoLst));
                                vhclPicker = ro.isiOS ? getPicker(vhclInfoLst[vhclInfoLst.length - 1].Name, true) : getAndroidPicker(vhclInfoLst[vhclInfoLst.length - 1].Name, getVhclRows(vhclInfoLst), vhclSelectFn, true);
                                vhclPicker.height = Ti.UI.SIZE;
                                vhclPickerHolder.removeAllChildren();
                                vhclPickerHolder.add(vhclPicker);
                                setVehicleObj(vhclInfoLst[vhclInfoLst.length - 1]);
                                vehicleSelectedRowId = vhclInfoLst.length - 1;
                            });
                        } else {
                            ro.ui.alert('Error: ', 'Only five vehicles may be saved at any given time');
                        }
                    });
                    var vhclEditBtn = vhclControl.getSecondaryButton("Edit");

                    vhclEditBtn.addEventListener('click', function (e) {
                        vhclControl.openForm(true, vhclInfoLst[vehicleSelectedRowId], function (x) {
                            CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
                            vhclInfoLst = CustInfo.Vehicles;
                            vhclPicker = ro.isiOS ? getPicker(vhclInfoLst[vehicleSelectedRowId].Name, true) : getAndroidPicker(vhclInfoLst[vehicleSelectedRowId].Name, getVhclRows(vhclInfoLst), vhclSelectFn, true);
                            vhclPicker.height = Ti.UI.SIZE;
                            vhclPickerHolder.removeAllChildren();
                            vhclPickerHolder.add(vhclPicker);
                            setVehicleObj(vhclInfoLst[vehicleSelectedRowId]);
                        });
                    });                    

                    if (vhclInfoLst.length < 5) {
                        vhclButtonHolder.add(vhclAddBtn);
                        vhclEditBtn.left = ro.ui.relX(10);
                    }
                    vhclButtonHolder.add(vhclEditBtn);
                    setVehicleObj(vhclInfoLst[0]);
                    var vhclPickerHolder = Ti.UI.createView({
                        top: ro.ui.relX(10),
                        height: Ti.UI.SIZE,
                        width: Ti.UI.SIZE
                    });
                    vhclPickerHolder.add(vhclPicker);
                    vhclBox.add(vhclPickerHolder);
                    vhclBox.add(vehicleInfoBox);
                    vhclBox.add(vhclButtonHolder);
                } else {
                    var vhclForm = require('formControls/vehicleForm');
                    var carForm = ro.forms.createForm({
                        style: ro.forms.STYLE_LABEL,
                        fields: vhclForm.getVhclForm({ formType: 2 }),
                        settings: ro.ui.properties.myAccountView
                    });
                    carForm.top = ro.ui.relY(5);
                    carForm.bottom = ro.ui.relY(5);
                    carForm.height = Ti.UI.SIZE;
                    vhclBox.add(carForm);
                }
            }             
            
            paymentView.add(vhclBox);
            // END VEHICLE INFORMATION BLOCK

            //Gate Code BLOCK
            //var allowNote = payControl.allowNoteFn();
            if (true) {
                isDeliv = false;
                if (Ti.App.OrderObj && Ti.App.OrderObj.ordOnlineOptions && Ti.App.OrderObj.ordOnlineOptions.IsDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery == true) {

                    isDeliv = true;
                    gateCodeBln = true;
                    var gateCodeBox = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth,
                        height: Ti.UI.SIZE,
                        layout: 'vertical',
                        top: ro.ui.relY(15)
                    });
                    var gateCodeHdrTxt = "Gate Code";
                    gateCodeBox.add(ro.layout.getGenericHdrRowWithHeader(gateCodeHdrTxt, true));
                    var gateCodeHintTxt = 'Enter Gate Code (Optional)';

                    var gateCodeView = Ti.UI.createView({
                        top: ro.ui.relY(5),
                        height: ro.ui.relY(50),
                        left: innerTablePadding,
                        right: innerTablePadding //,
                        //layout : 'horizontal'
                    });
                    var gateCodeTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                        left: 0,
                        width: Ti.UI.FILL,
                        height: Ti.UI.FILL,
                        hintText: gateCodeHintTxt,
                        font: {
                            fontFamily: ro.ui.fonts.textFields,
                            fontSize: ro.ui.scaleFont(18)
                        }
                    }));
                    gateCodeTextBox.addEventListener('focus', function () {
                        ro.GlobalPicker.hidePicker();
                    });
                    if (ro.isiOS) {
                        textBoxCol.push(1);
                        var gateCodeKeyboardToolbar = getKeyboardToolbar(1, doneFn, nextFn);
                        gateCodeTextBox.keyboardToolbar = gateCodeKeyboardToolbar;
                    }

                    gateCodeView.add(gateCodeTextBox);
                    gateCodeBox.add(gateCodeView);
                    paymentView.add(gateCodeBox);
                }
            }
            //Gate Code BLOCK
            //END END END END END END


            //Favorite Order BLOCK
            if (favCount < 5) {

                var favoritesBox = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(15)
                });
                var favoritesHdrTxt = "Favorites";
                favoritesBox.add(ro.layout.getGenericHdrRowWithHeader(favoritesHdrTxt, true));
                var favoritesHintTxt = "Name Your Order";

                var favoritesView = Ti.UI.createView({
                    top: ro.ui.relY(5),
                    height: ro.ui.relY(50),
                    left: innerTablePadding,
                    right: innerTablePadding,
                    layout: 'horizontal'
                });
                var defFavName = Ti.App.Properties.getString('favName', '');
                var favoritesTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                    left: 0,
                    width: Ti.UI.FILL,
                    height: Ti.UI.FILL,
                    hintText: favoritesHintTxt,
                    font: {
                        fontFamily: ro.ui.fonts.textFields,
                        fontSize: ro.ui.scaleFont(18)
                    },
                    value: defFavName
                }));
                favoritesTextBox.addEventListener('focus', function () {
                    ro.GlobalPicker.hidePicker();
                });
                if (ro.isiOS) {
                    textBoxCol.push(2);
                    var favKeyboardToolbar = getKeyboardToolbar(2, doneFn, nextFn);
                    favoritesTextBox.keyboardToolbar = favKeyboardToolbar;
                }
                /*var favoritesBtn = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : Ti.UI.FILL,
                 right : ro.ui.relX(15),
                 left : ro.ui.relX(15),
                 backgroundColor : ro.ui.theme.btnActive,
                 borderColor : ro.ui.theme.btnActive,
                 borderRadius : ro.ui.relX(25)//,
                 //bottom : ro.ui.relX(5)
                 });
                 favoritesBtn.add(Ti.UI.createLabel({
                 text : 'Add',
                 font : {
                 fontWeight : 'bold',
                 fontSize : ro.ui.scaleFont(19),
                 fontFamily : ro.ui.fontFamily
                 },
                 color : ro.ui.theme.loginBtnWhite,
                 textAlign : 'center',
                 touchEnabled : false
                 }));*/
                favoritesView.add(favoritesTextBox);
                //favoritesView.add(favoritesBtn);

                /*favoritesBtn.addEventListener('click', function(e) {

                 });*/
                favoritesBox.add(favoritesView);
                paymentView.add(favoritesBox);
            }
            //Favorite Order BLOCK
            //END END END END END END


            //Special Instruction BLOCK
            if (true) {
                var allowNote = payControl.allowNoteFn();
                if (allowNote) {
                    var specialNotesBox = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth,
                        height: Ti.UI.SIZE,
                        layout: 'vertical',
                        top: ro.ui.relY(15)
                    });
                    var specialNotesHdrTxt = "Special Instructions";
                    specialNotesBox.add(ro.layout.getGenericHdrRowWithHeader(specialNotesHdrTxt, true));
                    var specialNotesHintTxt = "Fill Requests here";

                    var specialNotesView = Ti.UI.createView({
                        top: ro.ui.relY(5),
                        height: ro.ui.relY(50),
                        left: innerTablePadding,
                        right: innerTablePadding //,
                        //layout : 'horizontal'
                    });
                    var defSpecialNotesValue = Ti.App.Properties.getString('spclInst', '');
                    var specialNotesTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                        left: 0,
                        width: Ti.UI.FILL,
                        height: Ti.UI.FILL,
                        hintText: specialNotesHintTxt,
                        font: {
                            fontFamily: ro.ui.fonts.textFields,
                            fontSize: ro.ui.scaleFont(18)
                        },
                        value: defSpecialNotesValue
                    }));
                    specialNotesTextBox.addEventListener('focus', function () {
                        ro.GlobalPicker.hidePicker();
                    });
                    if (ro.isiOS) {
                        textBoxCol.push(3);
                        var spclInstKeyboardToolbar = getKeyboardToolbar(3, doneFn, nextFn);
                        specialNotesTextBox.keyboardToolbar = spclInstKeyboardToolbar;
                    }

                    specialNotesView.add(specialNotesTextBox);
                    specialNotesBox.add(specialNotesView);
                    paymentView.add(specialNotesBox);
                }
            }
            //Special Instruction BLOCK
            //END END END END END END

            // DELIVERY NOTES BLOCK
            var isDelNoteActive = Ti.App.Properties.getBool('delNote', false);
            var allowDelNote = payControl.allowDelNoteFn();
            if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery && allowDelNote) {

                var DelNotesBox = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    top: ro.ui.relY(20),
                    width: ro.ui.properties.wideViewWidth - innerTablePadding * 2,
                    layout: 'vertical'
                });
                var DelNotesView = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    layout: 'horizontal'
                });

                DelNotesSwitch = Ti.UI.createView({ /*ro.combine(ro.ui.properties.defaultSwitch, {*/
                    height: ro.ui.relY(25),
                    width: ro.ui.relY(25),
                    borderColor: 'transparent',
                    backgroundImage: isDelNoteActive ? "/images/checkedbox.png" : "/images/uncheckedbox.png"
                });

                var DelNotesSwitchHolder = Ti.UI.createView({
                    width: '8%',
                    height: Ti.UI.SIZE,
                    left: ro.ui.relY(5)
                });

                DelNotesSwitchHolder.add(DelNotesSwitch);
                DelNotesView.addEventListener('click', function (e) {
                    ro.GlobalPicker.hidePicker();
                    isDelNoteActive = !isDelNoteActive;
                    Ti.App.Properties.setBool('delNote', isDelNoteActive);
                    DelNotesSwitch.backgroundImage = isDelNoteActive ? "/images/checkedbox.png" : "/images/uncheckedbox.png";
                });

                var delNotesHdrHolderView = ro.layout.getGenericHdrRowWithHeader(ro.app.Store.Configuration.DELIV_NOTES, true);
                delNotesHdrHolderView.children[0].color = ro.ui.theme.itemPriceColor;
                delNotesHdrHolderView.width = '85%';
                delNotesHdrHolderView.children[0].left = ro.ui.relX(10);
                delNotesHdrHolderView.bottom = ro.ui.relY(5);// this is offset the top of 5 in getGenericHdrRowWithHeader

                DelNotesView.add(DelNotesSwitchHolder);
                DelNotesView.add(delNotesHdrHolderView);

                DelNotesBox.add(DelNotesView);

                /*if (ro.app.Store.Configuration.DELIV_NOTES_COMMENT && ro.app.Store.Configuration.DELIV_NOTES_COMMENT != "") {
                    var delNotesTxtHolderView = ro.layout.getGenericHdrRowWithHeader(ro.app.Store.Configuration.DELIV_NOTES_COMMENT, false);                    
                    //delNotesTxtHolderView.bottom = ro.ui.relY(5);// this is offset the top of 5 in getGenericHdrRowWithHeader               
                    DelNotesBox.add(delNotesTxtHolderView);
                }*/
                if (ro.app.Store.Configuration.DELIV_NOTES_COMMENT && ro.app.Store.Configuration.DELIV_NOTES_COMMENTS != "") { 
                    var inst = ro.app.Store.Configuration.DELIV_NOTES_COMMENT.replace(/(\r\n|\n|\r)/gm, "");
                    var instList = inst.split("|");                    
                    var delInstView = Ti.UI.createView({
                        layout: 'vertical',
                        height: Ti.UI.SIZE
                    });
                    for (i = 0; i < instList.length; i++) {
                        if (instList[i] !== '') {
                            var delInstText = Ti.UI.createView({
                                height: Ti.UI.SIZE
                            });
                            delInstText.add(Ti.UI.createLabel({
                                text: '\u2022   ',
                                font: {
                                    fontFamily: ro.ui.fonts.rowHdrTxt,
                                    fontSize: ro.ui.scaleFont(13)
                                },
                                color: ro.ui.theme.noOptionsTxt,
                                textAlign: 'left',
                                left: ro.ui.relX(15),
                                top: ro.ui.relY(5),
                                touchEnabled: false
                            }));
                            delInstText.add(Ti.UI.createLabel({
                                text: instList[i].trim(),
                                font: {
                                    fontFamily: ro.ui.fonts.rowHdrTxt,
                                    fontSize: ro.ui.scaleFont(13)
                                },
                                color: ro.ui.theme.noOptionsTxt,
                                textAlign: 'left',
                                left: ro.ui.relX(30),
                                top: ro.ui.relY(5),
                                touchEnabled: false
                            }));
                            delInstView.add(delInstText);
                        }
                    }                                          
                    DelNotesBox.add(delInstView);
                }

                paymentView.add(DelNotesBox);
            }

            //END DELIVERY NOTES BLOCK

            //Order Time BLOCK
            if (Ti.App.allowFuture) {
                var futureIsSelected = false;
                var futureTimeObj = null;
                if (Ti.App.Properties.hasProperty('futureTimeObj')) {
                    futureTimeObj = JSON.parse(Ti.App.Properties.getString('futureTimeObj', '{}'));
                }
                //Ti.API.debug('futureTimeObj: ' + futureTimeObj);
                //Ti.API.debug('futureTimeObj: ' + JSON.stringify(futureTimeObj));

                var defaultDateText, defaultTimeText;
                var orderTimeViewHeight = ro.ui.relY(0);

                var pickRows = ["Now", "Future"];

                var defaultNowOrLaterText = "Now";
                if (Ti.App.futureOnly) {
                    defaultNowOrLaterText = "Future";
                    pickRows = ["Future"];
                }


                if (futureTimeObj) {
                    /*futureTimeObj.day = futureTimePicker.getSelectedRow(0).id;
                    futureTimeObj.hr = futureTimePicker.getSelectedRow(1).id;
                    futureTimeObj.min = futureTimePicker.getSelectedRow(2).id;
                    futureTimeObj.dateValue = futureTimePicker.getSelectedRow(0).obj.date;
                    futureTimeObj.hrValue = futureTimePicker.getSelectedRow(1).val;
                    futureTimeObj.minValue = futureTimePicker.getSelectedRow(2).title;*/
                    orderTimeViewHeight = ro.ui.relY(50);
                    defaultNowOrLaterText = "Future";

                    defaultDateText = futureTimeObj.dateText;
                    defaultTimeText = futureTimeObj.timeText;
                    //futureIsSelected = true;
                }

                var orderTimeBox = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(15)
                });
                var orderTimeHdrTxt = "Choose your Order Time";
                orderTimeBox.add(ro.layout.getGenericHdrRowWithHeader(orderTimeHdrTxt, true));
                var nowOrLaterView = Ti.UI.createView({
                    top: ro.ui.relY(5),
                    height: ro.ui.relY(50),
                    left: innerTablePadding,
                    right: innerTablePadding //,
                    //layout : 'horizontal'
                });
                var fullRow = true;
                var nowOrLaterFn = function (e) {
                    var selectedRow = e.source.getSelectedRow(0);
                    //Ti.API.debug('selectedRow: ' + JSON.stringify(selectedRow));
                    if (selectedRow && selectedRow.title) {
                        if (selectedRow.title == "Future") {

                            orderTimeView.height = ro.ui.relY(50);
                            newText = "Future";
                        } else {
                            newText = "Now";
                            orderTimeView.height = 0;
                            var payControl = require('controls/paymentControl');
                            ro.utils.removeProp('futureTimeObj');
                            payControl.clearFutureOrder();
                        }
                        nowOrLaterPicker.setLblText(newText, newText);
                    }
                };
                var nowOrLaterPicker = ro.isiOS ? getPicker(defaultNowOrLaterText, fullRow) : getAndroidPicker(defaultNowOrLaterText, getNowOrLaterRows(pickRows), nowOrLaterFn, true);
                var dontDoChangeEvt = false;

                if (ro.isiOS) {
                    nowOrLaterPicker.addEventListener('click', function (e) {
                        blurTextFields();
                        dontDoChangeEvt = true;
                        var whenPicker = getNowOrLaterPicker();
                        whenPicker.addEventListener('change', function (ee) {
                            if (dontDoChangeEvt) {
                                dontDoChangeEvt = false;
                                return;
                            }
                            //Ti.API.debug('ee: ' + JSON.stringify(ee));
                            var newText;
                            var selectedRow = whenPicker.getSelectedRow(0);
                            //Ti.API.debug('selectedRow: ' + JSON.stringify(selectedRow));
                            if (selectedRow && selectedRow.title) {
                                function setLbls(day, hrCol, minCol) {
                                    datePicker.setPickText(day.disp);

                                    var nextHour = hrCol[day.minHrIndex];
                                    //Ti.API.debug('nextHour: ' + JSON.stringify(nextHour));
                                    var hourParts = nextHour.disp.split(" ");
                                    var nextMinute = minCol[day.minMinIndex];
                                    //Ti.API.debug('nextMinute: ' + JSON.stringify(nextMinute));

                                    var timeText = hourParts[0] + ":" + nextMinute + " " + hourParts[1];

                                    timePicker.setPickText(timeText);
                                }
                                if (selectedRow.title == "Future") {
                                    getDateTimePicker(function () {

                                    }, setLbls);
                                    orderTimeView.height = ro.ui.relY(50);
                                    newText = "Future";
                                } else {
                                    newText = "Now";
                                    orderTimeView.height = 0;
                                    var payControl = require('controls/paymentControl');
                                    ro.utils.removeProp('futureTimeObj');
                                    payControl.clearFutureOrder();
                                }
                                nowOrLaterPicker.setPickText(newText);
                            }
                        });
                        ro.GlobalPicker.setPicker(whenPicker);
                        if (!ro.isiOS) {
                            var customHeight = ro.ui.relY(150);
                            ro.GlobalPicker.showPicker(customHeight);
                        } else {
                            ro.GlobalPicker.showPicker();
                        }
                        //Ti.API.info('nowOrLaterPicker: ' + JSON.stringify(nowOrLaterPicker));
                        if (!Ti.App.futureOnly) {
                            whenPicker.setSelectedRow(0, nowOrLaterPicker.getCurrentSelection(), false);
                        }



                    });
                }
                nowOrLaterPicker.left = 0;

                nowOrLaterView.add(nowOrLaterPicker);

                var orderTimeView = Ti.UI.createView({
                    top: ro.ui.relY(5),
                    height: orderTimeViewHeight,
                    left: innerTablePadding,
                    right: innerTablePadding
                });

                if (ro.isiOS) {


                    var datePicker = getPicker(defaultDateText);
                    datePicker.left = 0;
                    datePicker.addEventListener('click', function () {
                        blurTextFields();
                        getDateTimePicker(futureTimePickerCallback);
                    });

                    var timePicker = getPicker(defaultTimeText);
                    timePicker.right = 0;
                    timePicker.addEventListener('click', function () {
                        blurTextFields();
                        getDateTimePicker(futureTimePickerCallback);
                    });

                    function directSetLbls(day, hr, min) {
                        datePicker.setPickText(day.title);

                        var hourParts = hr.title.split(" ");
                        var timeText = hourParts[0] + ":" + min.title + " " + hourParts[1];

                        timePicker.setPickText(timeText);
                    }

                    function futureTimePickerCallback(day, hr, min) {
                        //setLbls(day, hr, min);
                        //Ti.API.debug('e: ' + JSON.stringify(e));
                        //Ti.API.debug('day, hr, min: ' + day + ", " + hr + ", " + min);
                        if (!ro.isiOS) {
                            var customHeight = ro.ui.relY(150);
                            ro.GlobalPicker.showPicker(customHeight);
                        } else {
                            ro.GlobalPicker.showPicker();
                        }

                        setTimeout(function (eee) {
                            futureTimePicker.setSelectedRow(0, 0);
                            futureTimePicker.setSelectedRow(1, day.minHrIndex);
                            futureTimePicker.setSelectedRow(2, day.minMinIndex);
                        }, 10);



                    }

                    orderTimeView.add(datePicker);
                    orderTimeView.add(timePicker);

                    //getDateTimePicker();
                    //orderTimeView.add(specialNotesTextBox);
                } else {
                    var minChangeFn, hrChangeFn, dayChangeFn;

                    orderTimeView.layout = 'horizontal';
                    var TIME_PICKER = require('logic/timePicker');
                    var futureTimePicker = Ti.UI.createView();
                    TIME_PICKER.formDateTime(futureTimePicker, function (dayArray, hrArray, minArray, bounds) {
                        function getDayRows(rowData) {
                            var rows = [];
                            for (var i = 0, iMax = rowData && rowData.length ? rowData.length : 0; i < iMax; i++) {
                                rows.push(Ti.UI.createPickerRow({
                                    title: rowData[i].disp,
                                    obj: rowData[i],
                                    id: i
                                }));
                            }

                            return rows;
                        }

                        function getHrRows(rowData, dayConstraint) {
                            var rows = [];
                            for (var i = dayConstraint.minHrIndex, iMax = dayConstraint.maxHrIndex; i <= iMax; i++) {
                                rows.push(Ti.UI.createPickerRow({
                                    title: rowData[i].disp,
                                    val: rowData[i].val,
                                    id: i,
                                    minMinIndex: i === dayConstraint.minHrIndex ? dayConstraint.minMinIndex : 0,
                                    maxMinIndex: i === dayConstraint.maxHrIndex ? dayConstraint.maxMinIndex : 0
                                }));
                            }
                            return rows;
                        }

                        function getMinRows(rowData, dayConstraint, maxMin) {
                            var rows = [];
                            var maxI = rowData && rowData.length ? rowData.length - 1 : 0;
                            if (maxMin && maxMin.maxMinIndex) {
                                maxI = maxMin.maxMinIndex;
                            }
                            for (var i = dayConstraint.minMinIndex, iMax = maxI; i <= iMax; i++) {
                                rows.push(Ti.UI.createPickerRow({
                                    title: rowData[i].toString(),
                                    id: i
                                }));
                            }

                            return rows;
                        }

                        minChangeFn = function (e) {
                            var selRow = e.source.getSelectedRow(0);
                            var minutePicker = orderTimeView.children[2];
                            minutePicker.setLblText(selRow.title, selRow.title);
                        };
                        hrChangeFn = function (e) {
                            var selRow = e.source.getSelectedRow(0);

                            var minutePicker = orderTimeView.children[2];
                            orderTimeView.remove(minutePicker);

                            var minArrayConstraint = {
                                minMinIndex: selRow.minMinIndex
                            };
                            var maxArrayConstraint = {
                                maxMinIndex: selRow.maxMinIndex
                            };
                            orderTimeView.add(getAndroidPicker(minArray[selRow.minMinIndex].toString(), getMinRows(minArray, minArrayConstraint, maxArrayConstraint), minChangeFn, null, true));

                            var hourPicker = orderTimeView.children[1];
                            hourPicker.setLblText(selRow.title, selRow.title);
                        };
                        dayChangeFn = function (e) {
                            var selRow = e.source.getSelectedRow(0);

                            var hourPicker = orderTimeView.children[1];
                            var minutePicker = orderTimeView.children[2];
                            orderTimeView.remove(minutePicker);
                            orderTimeView.remove(hourPicker);

                            orderTimeView.add(getAndroidPicker(hrArray[selRow.obj.minHrIndex].disp, getHrRows(hrArray, selRow.obj), hrChangeFn));
                            orderTimeView.add(getAndroidPicker(minArray[selRow.obj.minMinIndex].toString(), getMinRows(minArray, selRow.obj), minChangeFn, null, true));

                            var dayPicker = orderTimeView.children[0];
                            dayPicker.setLblText(selRow.title, selRow.title);
                        };


                        if (futureTimeObj) {
                            // Ti.API.info('futureTimeObj: ' + JSON.stringify(futureTimeObj));
                            //Ti.API.info('orderTimeView.children[0].getChosenRow(): ' + JSON.stringify(orderTimeView.children[0].getChosenRow()));
                            // Ti.API.info('orderTimeView.children[0].getChosenRow(): ' + JSON.stringify(orderTimeView.children[1].getChosenRow()));
                            //Ti.API.info('orderTimeView.children[0].getChosenRow(): ' + JSON.stringify(orderTimeView.children[2].getChosenRow()));
                            var defDayIndex, defDayText, defHrText, defMinText;
                            defDayIndex = futureTimeObj.day;
                            defDayText = dayArray[defDayIndex].disp;

                            //defHrText
                            var hourRows = getHrRows(hrArray, dayArray[defDayIndex]);
                            var minuteDayConstraint = dayArray[defDayIndex];
                            var maxMinuteDayConstraint = null;
                            if (hourRows[0].id !== futureTimeObj.hr) {
                                minuteDayConstraint = {
                                    minMinIndex: 0
                                };
                            }
                            //Ti.API.info('hourRows[hourRows.length-1]: ' + JSON.stringify(hourRows[hourRows.length - 1]));
                            if (hourRows[hourRows.length - 1].id === futureTimeObj.hr) {
                                maxMinuteDayConstraint = {
                                    maxMinIndex: hourRows[hourRows.length - 1].maxMinIndex
                                };
                            }

                            var minRows = getMinRows(minArray, minuteDayConstraint, maxMinuteDayConstraint);
                            //Ti.API.info('minRows: ' + JSON.stringify(minRows));
                            orderTimeView.add(getAndroidPicker(defDayText, getDayRows(dayArray), null, /*dayChangeFn,*/ null, true));
                            orderTimeView.add(getAndroidPicker(hrArray[dayArray[0].minHrIndex].disp, hourRows, null /*, hrChangeFn*/));
                            orderTimeView.add(getAndroidPicker(minArray[dayArray[0].minMinIndex].toString(), minRows, null, /*minChangeFn,*/ null, true));

                            //futureIsSelected = true;
                        } else {
                            orderTimeView.add(getAndroidPicker(dayArray[0].disp, getDayRows(dayArray), dayChangeFn, null, true));
                            orderTimeView.add(getAndroidPicker(hrArray[dayArray[0].minHrIndex].disp, getHrRows(hrArray, dayArray[0]), hrChangeFn));
                            orderTimeView.add(getAndroidPicker(minArray[dayArray[0].minMinIndex].toString(), getMinRows(minArray, dayArray[0]), minChangeFn, null, true));
                        }



                    });
                }
                orderTimeBox.add(nowOrLaterView);
                orderTimeBox.add(orderTimeView);
                paymentView.add(orderTimeBox);
            }

            //Round Up Block(Hungry Howies)
            var isRndUpOnly = ro.app.Store.Configuration.DISPLAY_ROUNDUP_CART ? ro.app.Store.Configuration.DISPLAY_ROUNDUP_CART : false;
            if (ro.app.Store.Configuration.ROUNDUP_HDR && ro.app.Store.Configuration.ROUNDUP_HDR != "" && ro.app.Store.Menu.OpenItem) {
                var roundUpBox = Ti.UI.createView({
                    width: ro.ui.displayCaps.platformWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(15)
                });
                var roundUpHdr = ro.layout.getGenericHdrRowWithHeader(ro.app.Store.Configuration.ROUNDUP_HDR, true);
                if (isRndUpOnly) {
                    roundUpHdr.children[0].left = 0;
                    roundUpHdr.width = Ti.UI.SIZE;
                }
                roundUpBox.add(roundUpHdr);
                var msgDict = Object.create(style.genericLbl);
                
                if (isRndUpOnly) {
                    msgDict.left = null;
                    msgDict.textAlign = 'center';
                }
                var addlRoundUp = ro.app.Store.Configuration.ROUNDUP_ADDL_MSG && ro.app.Store.Configuration.ROUNDUP_ADDL_MSG != "";
                var roundUpDescLbl = Ti.UI.createLabel(ro.combine(msgDict,{
                    text : ro.app.Store.Configuration.ROUNDUP_MSG
                }));
                roundUpBox.add(roundUpDescLbl);
                var buttonsHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: Ti.UI.SIZE,
                    layout: 'horizontal'
                });

                if (isRndUpOnly) {
                    var yesBtn = ro.layout.getMediumButton(ro.app.Store.Configuration.ROUNDUP_YES);
                } else {
                    var yesBtn = ro.layout.getSmallButton(ro.app.Store.Configuration.ROUNDUP_YES);
                    yesBtn.right = ro.ui.relX(10);
                }
                var noBtn = ro.layout.getSmallButton(ro.app.Store.Configuration.ROUNDUP_NO);                
                noBtn.left = ro.ui.relX(10);
                
                yesBtn.activated = false;
                
                

                function activateYes() {
                    if (yesBtn.activated) {
                        if (isRndUpOnly) {
                            deactivateYes();
                        }
                        return;
                    }
                    yesBtn.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                    yesBtn.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                    yesBtn.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                    yesBtn.activated = true;
                    if (addlRoundUp && !isRndUpOnly) {
                        priceButtonsHolder.height = Ti.UI.SIZE;
                        priceButtonsHolder.visible = true;
                        roundUpAddlDescLbl.height = Ti.UI.SIZE;
                        roundUpAddlDescLbl.visible = true;
                        otherAmtHolder.height = Ti.UI.SIZE;
                        otherAmtHolder.visible = true;
                    }
                };

                function deactivateYes() {
                    yesBtn.backgroundColor = 'white';
                    yesBtn.borderColor = "#e4e4e4";
                    yesBtn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    yesBtn.activated = false;
                    cancelRoundUp();
                };

                yesBtn.addEventListener('click', function () {
                    noBtn.backgroundColor = 'white';
                    noBtn.borderColor = "#e4e4e4";
                    noBtn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    roundUp(0);
                    activateYes();
                });

                noBtn.addEventListener('click', function () {
                    deactivateYes()
                    noBtn.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                    noBtn.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                    noBtn.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                    if (addlRoundUp) {
                        priceButtonsHolder.visible = false;
                        priceButtonsHolder.height = 0;
                        roundUpAddlDescLbl.height = 0;
                        roundUpAddlDescLbl.visible = false;
                        otherAmtHolder.height = 0;
                        otherAmtHolder.visible = false;
                        resetAddlBtns();
                    }
                    total = 0;
                });
                buttonsHolder.add(yesBtn);
                if (!isRndUpOnly) {
                    buttonsHolder.add(noBtn);
                }
                roundUpBox.add(buttonsHolder);

                //if(addlRoundUp){ ** Moved this further down because it was causing error in iOS, could be issue in way its being parsed, need to revisist and find out.
                var addlDict = Object.create(style.genericLbl);
                addlDict.visible = false;
                addlDict.height = 0;
                addlDict.top = ro.ui.relY(10);

                var roundUpAddlDescLbl = Ti.UI.createLabel(ro.combine(addlDict,{
                    text: ro.app.Store.Configuration.ROUNDUP_ADDL_MSG
                }));
                roundUpBox.add(roundUpAddlDescLbl);

                var priceButtonsHolder = Ti.UI.createView({
                    height: 0,
                    width: Ti.UI.SIZE,
                    layout: 'horizontal',
                    visible: false
                });

                var price1Btn = ro.layout.getSmallButton("+ $1");
                price1Btn.right = ro.ui.relX(10);

                var price2Btn = ro.layout.getSmallButton("+ $5");
                price2Btn.left = ro.ui.relX(10);

                function activatePrice1() {
                    price1Btn.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                    price1Btn.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                    price1Btn.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                };

                price1Btn.addEventListener('click', function () {
                    price2Btn.backgroundColor = 'white';
                    price2Btn.borderColor = "#e4e4e4";
                    price2Btn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    activatePrice1();
                    otherAmt.value = '';
                    addOtherAmt.backgroundColor = 'white';
                    addOtherAmt.borderColor = "#e4e4e4";
                    addOtherAmt.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    roundUp(1);
                });

                function activatePrice2() {
                    price2Btn.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                    price2Btn.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                    price2Btn.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                };

                price2Btn.addEventListener('click', function () {
                    price1Btn.backgroundColor = 'white';
                    price1Btn.borderColor = "#e4e4e4";
                    price1Btn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    activatePrice2();
                    otherAmt.value = '';
                    addOtherAmt.backgroundColor = 'white';
                    addOtherAmt.borderColor = "#e4e4e4";
                    addOtherAmt.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    roundUp(5);
                });

                function resetAddlBtns() {
                    price1Btn.backgroundColor = 'white';
                    price1Btn.borderColor = "#e4e4e4";
                    price1Btn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    price2Btn.backgroundColor = 'white';
                    price2Btn.borderColor = "#e4e4e4";
                    price2Btn.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                    otherAmt.value = '';
                    addOtherAmt.backgroundColor = 'white';
                    addOtherAmt.borderColor = "#e4e4e4";
                    addOtherAmt.children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;
                }
                priceButtonsHolder.add(price1Btn);
                priceButtonsHolder.add(price2Btn);

                var otherAmtHolder = Ti.UI.createView({
                    height: 0,
                    width: Ti.UI.SIZE,
                    layout: 'horizontal',
                    visible: false,
                    top: ro.ui.relY(10)
                });

                var otherAmt = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                    width: ro.ui.relX(100),
                    height: ro.ui.relY(40),
                    hintText: "$ Other",
                    textAlign: Titanium.UI.TEXT_ALIGNMENT_CENTER,
                    maxLength: 6,
                    font: {
                        fontFamily: ro.ui.fonts.textFields,
                        fontSize: ro.ui.scaleFont(15)
                    },
                    keyboardType: Ti.UI.KEYBOARD_TYPE_DECIMAL_PAD
                }));

                otherAmt.addEventListener('focus', function () {
                    ro.GlobalPicker.hidePicker();
                    resetAddlBtns();
                    roundUp(0);
                });
                var menuUtils = require('logic/menuUtils');
                var amtChangeEvt = function () {
                    if (otherAmt.value === '') {
                        return;
                    }
                    otherAmt.removeEventListener('change', amtChangeEvt);
                    var val = otherAmt.value.replace(/\D/g, '');
                    otherAmt.value = menuUtils.decimalizeInt(val);
                    setTimeout(function () {
                        otherAmt.addEventListener('change', amtChangeEvt);
                    }, 100);
                };
                otherAmt.addEventListener('change', amtChangeEvt);
                if (ro.isiOS) {
                    textBoxCol.push(4);
                    var otherAmtKeyboardToolbar = getKeyboardToolbar(4, doneFn, nextFn);
                    otherAmt.keyboardToolbar = otherAmtKeyboardToolbar;
                }
                var addOtherAmt = ro.layout.getSmallButton("Donate");
                addOtherAmt.left = ro.ui.relX(10);
                addOtherAmt.top = null;
                addOtherAmt.addEventListener('click', function () {
                    if (otherAmt.value === '') {
                        ro.ui.alert('Amount Required', 'Please enter an amount in the field.');
                        return;
                    }
                    addOtherAmt.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                    addOtherAmt.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                    addOtherAmt.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                    otherAmt.blur();

                    var val = parseFloat(otherAmt.value);
                    roundUp(val);
                    //paymentView.scrollToBottom();
                });

                otherAmtHolder.add(otherAmt);
                otherAmtHolder.add(addOtherAmt);
                if (addlRoundUp) {
                    roundUpBox.add(priceButtonsHolder);
                    roundUpBox.add(otherAmtHolder);
                }
                if (!isRndUpOnly) {
                    paymentView.add(roundUpBox);
                }
                
                var priceEngine = require('logic/pricing');
                var func = priceEngine.pricer();
                var total;

                function roundUp(AddlAmt) {
                    var roundUpItem = {};
                    var test = Ti.App.OrderObj;
                    var found = false;
                    var foundIdx;
                    for (var i = 0; i < test.Items.length; i++) {
                        if (test.Items[i].ItemType && test.Items[i].ItemType == 5) {
                            found = true;
                            foundIdx = i;
                            break;
                        }
                    }

                    if (found) {
                        test.Items[foundIdx].OrigPrice = total + AddlAmt;
                        test.Items[foundIdx].ActivePrice = test.Items[foundIdx].OrigPrice;
                    } else {
                        roundUpItem = ro.app.Store.Menu.OpenItem;
                        roundUpItem.Name = roundUpItem.Name ? roundUpItem.Name : roundUpItem.ItemName;
                        roundUpItem.RcptName = roundUpItem.RcptName ? roundUpItem.RcptName : roundUpItem.ReceiptName;
                        roundUpItem.KtchName = roundUpItem.KtchName ? roundUpItem.KtchName : roundUpItem.KitchenName;
                        roundUpItem.Size = "None";
                        roundUpItem.Style = "None";
                        roundUpItem.Qty = 1;
                        roundUpItem.NoDisc = true;
                        roundUpItem.OrigPrice = Math.round((Math.ceil(test.ActiveTotal) - test.ActiveTotal) * 100) / 100;
                        total = roundUpItem.OrigPrice;
                        roundUpItem.baseTotal = total;
                        roundUpItem.ActivePrice = roundUpItem.OrigPrice;
                        roundUpItem.ItemType = 5;
                        test.Items.push(roundUpItem);
                    }

                    test = func.RepriceOrder(test, ro.app.Store.Menu, test.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                    Ti.App.OrderObj = test;
                    test = null;
                    mp.updateTotals(CC_TIPS.getTip());
                    checkAndTogglePaymentView();
                }

                function cancelRoundUp() {
                    var test = Ti.App.OrderObj;
                    for (var i = 0; i < test.Items.length; i++) {
                        if (test.Items[i].ItemType && test.Items[i].ItemType == 5) {
                            test.Items.splice(i, 1);
                            test = func.RepriceOrder(test, ro.app.Store.Menu, test.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                            Ti.App.OrderObj = test;
                            test = null;
                            mp.updateTotals(CC_TIPS.getTip());
                            checkAndTogglePaymentView();
                            return;
                        }
                    }
                }

                //Checking the orderObj to see for any current roundUps
                var test = Ti.App.OrderObj;
                var found = false;
                var foundIdx;
                for (var i = 0; i < test.Items.length; i++) {
                    if (test.Items[i].ItemType && test.Items[i].ItemType == 5) {
                        found = true;
                        foundIdx = i;
                        break;
                    }
                }
                if (found) {
                    activateYes();
                    var foundRoundUpItm = test.Items[foundIdx];
                    total = foundRoundUpItm.baseTotal ? foundRoundUpItm.baseTotal : 0;
                    if ((foundRoundUpItm.OrigPrice - foundRoundUpItm.baseTotal).toFixed(2) == 1.00) {
                        activatePrice1();
                    } else if ((foundRoundUpItm.OrigPrice - foundRoundUpItm.baseTotal).toFixed(2) == 5.00) {
                        activatePrice2();
                    } else {
                        otherAmt.value = (foundRoundUpItm.OrigPrice - foundRoundUpItm.baseTotal).toFixed(2);
                        addOtherAmt.backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
                        addOtherAmt.borderColor = ro.ui.theme.sizeBtnBlockBgActive;
                        addOtherAmt.children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;
                    }
                }

            }

            //END Round Up Block

            //PAYMENT BLOCK
            if (true) {
                //Adding logic to handle payment types defined in OrderTypes
                var paymentTypesObj = {};
                paymentTypesObj.AllowCC = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery && ro.app.Store.Configuration.AllowCCDelivery) 
                                            || (!Ti.App.OrderObj.ordOnlineOptions.IsDelivery && ro.app.Store.Configuration.AllowCCPickup);
                paymentTypesObj.AllowPayUpon = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery && ro.app.Store.Configuration.AllowPayUponDelivery) 
                                                || (!Ti.App.OrderObj.ordOnlineOptions.IsDelivery && ro.app.Store.Configuration.AllowPayUponPickup);
                if(ro.app.Store.Configuration.PayUponOptions){
                    paymentTypesObj.PayUponOptions = ro.app.Store.Configuration.PayUponOptions;
                }else{
                    paymentTypesObj.PayUponOptions = [];
                }                           
                var OrdTypeLst = ro.app.Store.Menu.OnlineOptions.OrdTypes;
                for(i=0; i< OrdTypeLst.length; i++){
                    if(OrdTypeLst[i].IsDelivery == Ti.App.OrderObj.ordOnlineOptions.IsDelivery && OrdTypeLst[i].OrdType == Ti.App.OrderObj.OrdType){
                        if(OrdTypeLst[i].hasOwnProperty('AllowCC') && OrdTypeLst[i].hasOwnProperty('AllowPayUpon')){
                            paymentTypesObj.AllowCC = OrdTypeLst[i].AllowCC;
                            paymentTypesObj.AllowPayUpon = OrdTypeLst[i].AllowPayUpon;
                            if(OrdTypeLst[i].PayUponOptions){
                                paymentTypesObj.PayUponOptions = OrdTypeLst[i].PayUponOptions;
                            }else{
                                paymentTypesObj.PayUponOptions = [];
                            }
                        }
                        break;
                    }
                }
                Ti.API.info("Payment Type Object: " + JSON.stringify(paymentTypesObj));
                //End of logic to handle payment types defined in OrderTypes
                //Adding logic to find all payment types with surcharges
                var surchargePmnts = [];
                if (ro.app.Store.Surcharges && ro.app.Store.Surcharges.length) {
                    for (var i = 0; i < ro.app.Store.Surcharges.length; i++) {
                        if (ro.app.Store.Surcharges[i].BusinessSurchargePayments && ro.app.Store.Surcharges[i].BusinessSurchargePayments.length) {
                            for (var j = 0; j < ro.app.Store.Surcharges[i].BusinessSurchargePayments.length; j++) {
                                if (!surchargePmnts.includes(ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase())) {
                                    if (ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase() == 'creditcard') {
                                        if (paymentTypesObj.AllowCC) {
                                            surchargePmnts.push(ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase());
                                        }
                                    }else if(ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase() == 'giftcard') {
                                        if (paymentTypesObj.PayUponOptions.includes('GIFT')) {
                                            surchargePmnts.push(ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase());
                                        }
                                    }else if(paymentTypesObj.PayUponOptions.findIndex(item => item.toLowerCase() == ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase()) != -1) {
                                        surchargePmnts.push(ro.app.Store.Surcharges[i].BusinessSurchargePayments[j].PaymentType.toLowerCase());
                                    }
                                }
                            }
                        }
                    }
                }
                //End of logic to find all payment types with surcharges 
                var ccOnly = doesTotalExceedThreshold() || false;
                var ccControl = require('controls/ccControl');
                var defCardId = ccControl.getDefaultCard();
                var paymentTypesCol = []; 
                var pmntIdxOffset = 0;
                var surchargeMarker = '';
                if (paymentTypesObj.AllowCC && ro.app.Store.Configuration.CardTypes) {
                    hasCC = true;
                    surchargeMarker = surchargePmnts.includes('creditcard') ? '*' : '';
                    
                    if(ro.isiOS){
                        applePayConfig = JSON.parse(Ti.App.Properties.getString('applePayConfig', '{}'));
                    
                        if(applePayConfig && applePayConfig.merchantIdentifier && applePayConfig.merchantIdentifier != ''){
                                paymentTypesCol.push({
                                    title: 'ApplePay',
                                    specialTitle: surchargeMarker + (applePayConfig.displayName && applePayConfig.displayName != ''?  applePayConfig.displayName : 'ApplePay'),                                
                                    index: pmntIdxOffset++
                                });
                        }
                    }
                    
                    if (!isGuest && ccControl.hasSavedCards(ro)) {
                        var ccRs = ro.db.getAllCustCC(Ti.App.Username);
                        if (ccRs && ccRs.length) {
                            //Code to push the default card to the top of the list of cards
                            if(defCardId !== -1){
                                for (var i = 0, iMax = ccRs.length; i < iMax; i++) {
                                    if(defCardId == ccRs[i].rowid){
                                        ccRs[i].CCInfo = payControl.getPaymentObj(ccRs[i].CCInfo);
                                        var paymentTypeColObj = {
                                            title: surchargeMarker + 'USE EXISTING CARD',
                                            specialTitle: surchargeMarker + 'Card Ending in ' + ccControl.getLastFour(ccRs[i].CCInfo.OLCardNum),
                                            cardObj: ccRs[i].CCInfo,
                                            index: pmntIdxOffset++,
                                            id: ccRs[i].rowid
                                        };
                                        paymentTypesCol.push(paymentTypeColObj);
                                        break;
                                    }
                                } 
                            }
                            //Code to push other cards onto the list of cards; need to do this to maintain index
                            for (var i = 0, iMax = ccRs.length; i < iMax; i++) {
                                if(defCardId != ccRs[i].rowid){
                                    ccRs[i].CCInfo = payControl.getPaymentObj(ccRs[i].CCInfo);
                                    var paymentTypeColObj = {
                                        title: surchargeMarker + 'USE EXISTING CARD',
                                        specialTitle: surchargeMarker + 'Card Ending in ' + ccControl.getLastFour(ccRs[i].CCInfo.OLCardNum),
                                        cardObj: ccRs[i].CCInfo,
                                        index: pmntIdxOffset++,
                                        id: ccRs[i].rowid
                                    };
                                    paymentTypesCol.push(paymentTypeColObj);
                                }
                            }
                        }
                    }                   
                    paymentTypesCol.push({
                        title: surchargeMarker + 'CREDIT CARD',
                        index: pmntIdxOffset++
                    });
                }
                if (paymentTypesObj.AllowPayUpon && paymentTypesObj.PayUponOptions) {
                    hasPayupon = true
                    for (var k = 0; k < paymentTypesObj.PayUponOptions.length; k++) {
                        if(paymentTypesObj.PayUponOptions[k] == 'GIFT'){
                            surchargeMarker = surchargePmnts.includes('giftcard') ? '*' : '';
                        }else{
                            surchargeMarker = surchargePmnts.includes(paymentTypesObj.PayUponOptions[k].toLowerCase()) ? '*' : '';                        
                        }
                        if (!ccOnly || (paymentTypesObj.PayUponOptions[k] === 'GIFT')) {
                            paymentTypesCol.push({
                                title: surchargeMarker + paymentTypesObj.PayUponOptions[k],
                                index: pmntIdxOffset++
                            });
                        }
                    }                    
                }           

                var paymentTypeBox = Ti.UI.createView({
                    width: ro.ui.displayCaps.platformWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(15)
                });
                var paymentTypeHdrTxt = "Choose your Payment Type";
                paymentTypeBox.add(ro.layout.getGenericHdrRowWithHeader(paymentTypeHdrTxt, true));

                var paymentTypeView = Ti.UI.createView({
                    top: ro.ui.relY(5),
                    height: Ti.UI.SIZE,
                    width: ro.ui.displayCaps.platformWidth,
                    layout: 'vertical'
                });

                function clearSelection() {
                    for (var i = 0, iMax = paymentTypeView.children.length; i < iMax; i++) {
                        if (paymentTypeView.children[i].isDivider || !paymentTypeView.children[i].changeSelection) {
                            continue;
                        }
                        if (paymentTypeView.children[i].isSelected) {
                            paymentTypeView.children[i].changeSelection(false);
                            break;
                        }

                    }
                }

                function vrfyBilling(card) {
                    var returnFlag = 0;
                    if (ro.app.Store.Configuration.VerifyBilling === 1) {
                        if (!card.AVSZipCode) {
                            returnFlag = 1;
                        }
                    } else if (ro.app.Store.Configuration.VerifyBilling === 2) {
                        if (!card.AVSStreetNum) {
                            returnFlag = 2;
                        }
                    }
                    return returnFlag;
                }

                function getBillingInfo(billingFlag, billCB) {
                    var popupTitle, popupMsg;
                    if (billingFlag === 1) {
                        popupTitle = 'Zip Code Required';
                        popupMsg = 'Please enter your Billing Zip Code:';
                    } else if (billingFlag === 2) {
                        popupTitle = 'Billing Street Required';
                        popupMsg = 'Please enter your Billing St.';
                    }

                    ro.ui.popup("Attention", ['OK'], popupMsg, function (e) {
                        
                    }, function () {

                    }, true, function (verBilling, _successCb) {
                        //Ti.API.info('verBilling: ' + verBilling);
                        var billKey;
                        var billInfoTest = {};
                        if (billingFlag === 1) {
                            billKey = 'AVSZipCode';
                            billInfoTest = {
                                BillingZip: verBilling || ""
                            };
                        } else if (billingFlag === 2) {
                            billKey = 'AVSStreetNum';
                            billInfoTest = {
                                BillingStreet: verBilling || ""
                            };
                        }

                        //Ti.include('/validation/creditcardValidation.js');
                        if (!ro.isiOS)
                            Ti.UI.Android.hideSoftKeyboard();
                        var success = credCardVal.billingVerified(billInfoTest, billingFlag);
                        if (success.value) {
                            //Ti.include('/validation/regexValidation.js');
                            success = regexVal.regExValidate(billInfoTest);
                            if (success.value) {
                                //ro.ca.hide();
                                if (billingFlag === 1) {
                                    billCB({
                                        AVSZipCode: billInfoTest.BillingZip
                                    }, billKey);
                                } else if (billingFlag === 2) {
                                    billCB({
                                        AVSStreetNum: billInfoTest.BillingStreet
                                    }, billKey);
                                }
                                _successCb();
                            } else {
                                ro.ui.alert('Error', success.issues[0], null, true);
                                clearSelection();
                                ro.ui.hideLoader();
                            }
                        } else {
                            ro.ui.alert('Error', success.issues[0], null, true);
                            clearSelection();
                            ro.ui.hideLoader();
                        }
                    });
                }


                //paymentTypeView.add(getPaymenyDivider());
                //changeSelection
                var payRows = [];
                payRows.push(getPaymenyDivider());
                for (var i = 0, iMax = paymentTypesCol.length; i < iMax; i++) {
                    payRows.push(getPaymentRow(paymentTypesCol[i]));
                    payRows.push(getPaymenyDivider());
                    //paymentTypeView.add());
                    //paymentTypeView.add();
                }

                paymentTypeView.add(payRows);
                var paymentLastClickTime = 0;
                var payForms = {};
                var rowToCheck = -1;
                paymentTypeView.addEventListener('click', function (e) {

                    if (e.source.isDivider || !e.source.changeSelection || e.source.isSelected) {

                        return;
                    }
                    var title = e.source.title.replace('*','').toLowerCase();
                    blurTextFields();
                    ro.GlobalPicker.hidePicker();
                    if (new Date().getTime() - paymentLastClickTime < 350) {
                        Ti.API.debug('returning');
                        return;
                    }
                    var thisClickTime = new Date();
                    paymentLastClickTime = thisClickTime.getTime();
                    thisClickTime = null;

                    rowToCheck = -1;

                    //CHANGE SELECTED ROW
                    for (var i = 0, iMax = paymentTypeView.children.length; i < iMax; i++) {
                        if (paymentTypeView.children[i].isDivider || !paymentTypeView.children[i].changeSelection) {
                            continue;
                        }
                        if ((!e.source.id && e.source.title == paymentTypeView.children[i].title) || (e.source.id && e.source.id == paymentTypeView.children[i].id)) {
                            rowToCheck = i;
                            paymentTypeView.children[rowToCheck].changeSelection(true);
                        } else {
                            paymentTypeView.children[i].changeSelection(false);
                        }

                    }
                    // Ti.API.info('Row to check: ' + rowToCheck);

                    paymentTypeView.selectedIndex = e.source.index;
                    paymentTypeView.dispordpayment = title;
                    //CHANGE SELECTED ROW
                    //GetCreditView
                    var newAddPmtBtnVis = false;
                    var mPmts = {}; //WILL NEED TO DEAL WITH THIS LATER
                    var mPmts = mp.GetMultiPmts();
                    //this code is to clear the order tip if for some reasons the submit order fails and the customer switches between payments
                    var isMultiPay = mPmts.DoMultiPmts;
                    if(!isMultiPay && Ti.App.OrderObj.Tip && Ti.App.OrderObj.Tip > 0){
                        var test = Ti.App.OrderObj;
                        test.Tip = 0.0;
                        Ti.App.OrderObj = test;
                        test = null;
                    }
                    //end check code
                    //Reprice for surcharges                    
                    if(surchargePmnts && surchargePmnts.length){
                        var pmnt;
                        if(title == 'use existing card' || title == 'credit card' || title == 'applepay'){
                            pmnt = 'creditcard';
                        }else if(title =='gift'){
                            pmnt = 'giftcard'
                        }else{
                            pmnt = title;
                        }
                        refreshPaymentTotals(pmnt);
                    }
                    toggleSubmitButton(false);
                    var multiPmntRowTtl = e.source.specialTitle && e.source.specialTitle.length ? e.source.specialTitle : title;
                    switch (title) {
                        case "use existing card":
                            var cardObj = e.source.cardObj;
                            var id = e.source.id;
                            var verifiedBilling = vrfyBilling(cardObj);
                            if (verifiedBilling) {
                                getBillingInfo(verifiedBilling, function(billInfo, newKey) {
                                    cardObj[newKey] = billInfo[newKey];
                                    var clone = JSON.parse(JSON.stringify(cardObj));
                                    var ccSuccess = ccControl.updateExistingCard(clone, e.source.id, ro);
                                    if (ccSuccess === -1) {
                                        ro.ui.alert('Error: ', 'Card failed to update.');
                                        return;
                                    }
                                    clone = null;
                                    e.source.cardObj = cardObj;
                                    payForms[e.source.index] = getSavedCardView(mPmts, e.source.cardObj);
                                    e.source.addForm(payForms[e.source.index]);

                                });
                                ro.ui.hideLoader();
                            } else {
                                payForms[e.source.index] = getSavedCardView(mPmts, e.source.cardObj, multiPmntRowTtl);                                
                                e.source.addForm(payForms[e.source.index]);
                            }

                            newAddPmtBtnVis = false;

                            break;
                        case "credit card":                            
                            payForms[e.source.index] = GetCreditView(mPmts);
                            e.source.addForm(payForms[e.source.index]);
                            break;
                        case "gift":                            
                            payForms[e.source.index] = GetGiftView(mPmts);                            
                            e.source.addForm(payForms[e.source.index]);                            
                            break;
                        case "cash":
                            if (mPmts.DoMultiPmts) {
                                var cashObj = {"IsCredOrGift": false, "CardInfo": "CASH", "PaymentAmt":0.00, "PaymentType":"cash"};
                                payForms[e.source.index] = getSavedCardView(mPmts, cashObj, multiPmntRowTtl);
                                e.source.addForm(payForms[e.source.index]);
                            }
                            else{
                                paymentTypeView.selectedIndex = e.source.index;
                                paymentTypeView.dispordpayment = title;
                            }

                            break;                        
                        case "applepay":
                                if (mPmts.DoMultiPmts) {
                                    ro.ui.alert('Alert', 'ApplePay does not allow split payments');
                                    paymentTypeView.children[rowToCheck].changeSelection(false);
                                }
                                else{
                                    toggleSubmitButton(true);
                                    payForms[e.source.index] = getApplePayView();
                                    e.source.addForm(payForms[e.source.index]);
                                    paymentTypeView.selectedIndex = e.source.index;
                                    paymentTypeView.dispordpayment = title;
                                }
    
                            break;
                        default:
                            //tipsView.hide();
                            //tipsView.visible = false;
                            /*if(mPmts.DoMultiPmts)
                                payView.add(GetNonCardView(mPmts, e.source.title));*/
                            break;
                    }


                });

                if(surchargePmnts && surchargePmnts.length){
                    var surchargeWarning = Ti.UI.createLabel({
                        text: '(*) - Payment surcharge will apply',
                        height: Ti.UI.SIZE,
                        top: ro.ui.relY(5),
                        bottom: ro.ui.relY(8),
                        width:Ti.UI.FILL,
                        textAlign:'center',
                        color:'#eb0029',
                        font:{
                            fontFamily:ro.ui.fontFamily,
                            fontWeight:'bold',
                            fontSize:ro.ui.scaleFont(18)
                        }
                    });
                    paymentTypeView.add(surchargeWarning);
                }
                

                paymentTypeBox.add(paymentTypeView);

                var allowMultiPmts = ro.app.Store.Configuration.AllowMultiPmts;
                var doingMultiPmts = false;
                //var MultiplePmtHelper = require('logic/MultiplePmtHelper');
                //var mp = require('logic/MultiplePmtHelper');
                var multiPmts = mp.GetMultiPmts();
                // Ti.API.info('multiPmts: ' + JSON.stringify(multiPmts));

                if (allowMultiPmts) {                    
                    var MultiPmtView = Ti.UI.createView({
                        height: Ti.UI.SIZE,
                        top: ro.ui.relY(13),
                        width: Ti.UI.SIZE,
                        //backgroundColor:ro.isiOS ? "transparent" : '#f6f6f6',
                        layout: 'horizontal'
                    });
                    var MultiPmtLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
                        text: 'Split Payments? (Click Me)',
                        top: 0,
                        width: Ti.UI.SIZE
                    }));
                    MultiPmtSwitch = Ti.UI.createView({ /*ro.combine(ro.ui.properties.defaultSwitch, {*/
                        left: ro.ui.relY(5),
                        height: ro.ui.relY(25),
                        width: ro.ui.relY(25),
                        borderColor: 'transparent',

                        //backgroundColor:ro.isiOS ? null : 'black',
                        backgroundImage: multiPmts && multiPmts.DoMultiPmts ? "/images/checkedbox.png" : "/images/uncheckedbox.png",
                        thevalue: multiPmts && multiPmts.DoMultiPmts ? true : false
                    });
                    MultiPmtSwitch.addEventListener('click', function (e) {
                        //Ti.API.info('e: ' + JSON.stringify(e));
                        ro.GlobalPicker.hidePicker();
                        MultiPmtSwitch.thevalue = !MultiPmtSwitch.thevalue;
                        MultiPmtSwitch.backgroundImage = MultiPmtSwitch.thevalue ? "/images/checkedbox.png" : "/images/uncheckedbox.png";
                        //tipsView.ResetTip();
                        multiPmts.DoMultiPmts = MultiPmtSwitch.thevalue;
                        CC_TIPS.Init('', true, false, false, mp.updateTotals);
                        if (!MultiPmtSwitch.thevalue) {
                            multiPmts.MultiPmts = [];
                            payControl.clearPaymentInfo();
                            //mpView.visible = false;
                            //Ti.API.info("in here 1");
                            mp.SaveMultiPmts(multiPmts);
                            /*if(Ti.App.OrderObj.ordOnlineOptions.CCInfoCol && Ti.App.OrderObj.ordOnlineOptions.CCInfoCol.length){
                            		 //Ti.API.info("in here 2");
                            		var test = Ti.App.OrderObj;
                            		test.ordOnlineOptions.CCInfoCol = null;         
         						delete test.ordOnlineOptions.CCInfo;
         						Ti.App.OrderObj = test;
         						test = null;
                            
                            }*/
                            //clearSelection();
                            //paymentTypeView.hide();
                        } else {
                            //mpView.visible = true;
                            mp.SaveMultiPmts(multiPmts);
                            //paymentTypeView.show();
                            //Ti.App.OrderObj.ordOnlineOptions.CCInfoCol = [];
                        }
                        mpView.Reprint();
                        resetPaymentTypesView();
                        checkAndTogglePaymentView();

                        //payForms[paymentTypeView.selectedIndex] = GetCreditView(MultiPmtSwitch.thevalue);
                        //paymentTypeView.children[paymentTypeView.selectedIndex].changeSelection(true);
                        // paymentTypeView.children[paymentTypeView.selectedIndex].addForm(GetCreditView(MultiPmtSwitch.thevalue));
                        payForms = null;
                        payForms = {};

                        //paymentPicker.setSelectedRow(0, 1, false);
                        //paymentPicker.setSelectedRow(0, 0, false);
                        //_postlayoutevt(paymentPickerRows[0].title ,true);

                        mpView.ToggleLabelVis(MultiPmtSwitch.thevalue);
                    });

                    MultiPmtView.add(MultiPmtSwitch);
                    MultiPmtView.add(MultiPmtLbl);

                    paymentTypeBox.add(MultiPmtView);
                }

                if (isRndUpOnly && roundUpBox) {
                    roundUpBox.top = ro.ui.relX(30);
                    paymentTypeBox.add(roundUpBox);
                }
                    mpView = mp.GetView(!multiPmts.DoMultiPmts ? (isPaymentValid() ? true : false) : false, checkAndTogglePaymentView);
                    mpView.visible = true;
                    mpView.left = innerTablePadding;
                    mpView.right = innerTablePadding;
                    paymentTypeBox.add(mpView);

                    if (multiPmts && multiPmts.DoMultiPmts) {
                        paymentValid = mp.IsPaymentValid();
                        if (paymentValid) {
                            //toggleTblView2Vis(false);
                        }
                    } else {
                        if (isPaymentValid()) {
                            //toggleTblView2Vis(false);
                        }
                    }               

                paymentView.add(paymentTypeBox);
            }
            //PAYMENT BLOCK
            //END END END END END END

            //CHECKOUT POPUP BLOCK

            if (ro.app.Store.Configuration.CHECKOUT_POPUP_TITLE) {
                
                var chkPopupBox = Ti.UI.createView({
                    width: ro.ui.displayCaps.platformWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relY(15)
                });
                var chkPopupHdr = ro.layout.getGenericHdrRowWithHeader(ro.app.Store.Configuration.CHECKOUT_POPUP_TITLE, true);
                chkPopupHdr.width = Ti.UI.SIZE;
                chkPopupHdr.children[0].left = null;
                chkPopupBox.add(chkPopupHdr);
                
                var chkMsgDict = Object.create(style.genericLbl);
                chkMsgDict.left = null;
                chkMsgDict.textAlign = 'center';
                var chkMsgLbl = Ti.UI.createLabel(ro.combine(chkMsgDict,{
                    text: payControl.calcAmt(ro.app.Store.Configuration.CHECKOUT_POPUP_MESSAGE && ro.app.Store.Configuration.CHECKOUT_POPUP_MESSAGE.length > 0 ? ro.app.Store.Configuration.CHECKOUT_POPUP_MESSAGE : '')
                }));
                chkPopupBox.add(chkMsgLbl);
                paymentView.add(chkPopupBox);
            } 

            //CHECKOUT POPUP BLOCK


            //ECLUB BLOCK
            if (doLoyalty) {
                var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView();
                LoyaltyView.top = ro.ui.relY(15);
                paymentView.add(LoyaltyView);
            }
            //ECLUB BLOCK
            //END END END END END END

            //LTYNOECLUB BLOCK
            if (doNoEClubLoyalty /*&& !specialLtyBln*/) {
                var LoyaltyNoEClubView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(null, null, true);
                LoyaltyNoEClubView.top = ro.ui.relY(15);
                paymentView.add(LoyaltyNoEClubView);
            }
            //LTYNOECLUB BLOCK
            //END END END END END END

            //PRIVACY POLICY BLOCK
            if (doPrivacy) {
                var webViewParent = Ti.UI.createView({
                    height: 0,
                    width: Ti.UI.FILL,
                    zIndex: 10
                });
                mainView.add(webViewParent);

                var policyView = privacyPolicy.getNewPolicyView(webViewParent);
                policyView.top = ro.ui.relY(15);
                paymentView.add(policyView);
            }
            //PRIVACY POLICY BLOCK
            //END END END END END END

            //MARKETING BLOCK
            var mktControl = require("controls/marketingControl");
            if(mktControl.showMktMsg()){
                var mktView = mktControl.getMarketingView();
                mktView.top = ro.ui.relY(15);
                paymentView.add(mktView);
            }
            //MARKETING BLOCK END

            //SUBMIT BUTTON BLOCK
            var submitOrderBtn = layoutHelper.getBigButton('Submit');
            
            submitOrderBtn.addEventListener('click', submitPaymentEvt);
            var btnWrapper = ro.layout.getBtnWrapper();
            btnWrapper.add(submitOrderBtn);
            var submitButtonHolder = Ti.UI.createView({
                width : Ti.UI.SIZE,
                height: Ti.UI.SIZE
            });
            submitButtonHolder.add(btnWrapper)
            paymentView.add(submitButtonHolder);

            if(ro.isiOS){
                var ApplePay = require('hungerrush.applepay');
                var appleSubmitOrderBtn = ApplePay.createPaymentButton({
                    type: ApplePay.PAYMENT_BUTTON_TYPE_ORDER,
                    style: ApplePay.PAYMENT_BUTTON_STYLE_BLACK
                });
                var ApplePayWrapper = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: ro.ui.relY(40),
                    bottom: ro.ui.relY(100)
                });
                ApplePayWrapper.add(appleSubmitOrderBtn);
                ApplePay.addEventListener('paymentSuccessful', function processApplePay(e){
                    ApplePay.removeEventListener('paymentSuccessful', processApplePay);
                    var paymentToken = {};
                    paymentToken.paymentData = JSON.parse(e.payment.paymentData);
                    paymentToken.paymentMethod = e.payment.paymentMethod;
                    paymentToken.transactionIdentifier = e.payment.transactionIdentifier;
                    var pmtObj = {};
                    pmtObj.OLCardNum = Ti.Utils.base64encode(JSON.stringify(paymentToken)).toString();
                    //pmtObj.TokenID = JSON.stringify(paymentToken);
                    pmtObj.PayerName = custFN + ' ' + custLN;
                    pmtObj.CardInfo = 'ApplePay';
                    pmtObj.TokenType = 1;
                    pmtObj.PaymentAmt = Ti.App.OrderObj.ActiveTotal;
                    pmtObj.Tip = Ti.App.OrderObj.Tip ? Ti.App.OrderObj.Tip : 0;
                    var test = Ti.App.OrderObj;
                    test.IsOnline = true;
                    test.DisplayOrdPayment = 'ApplePay';
                    test.ordOnlineOptions.CCInfo = pmtObj;                                        
                    Ti.App.OrderObj = test;
                    test = null;
                    finalizeOrder();                        
                });
                appleSubmitOrderBtn.addEventListener('click', submitPaymentEvt);                    
            }
            function toggleSubmitButton(isApplePay){
                if(!ro.isiOS) return;
                submitButtonHolder.removeAllChildren();
                if(isApplePay){                    
                    submitButtonHolder.add(ApplePayWrapper);
                }else{
                    submitButtonHolder.add(btnWrapper);
                }

            };
            //SUBMIT BUTTON BLOCK
            //END END END END END END END

            mainView.add(paymentView);
            //mainView.add(bottomNavigationView);
            if (!ro.isiOS && Ti.App.allowFuture && futureTimeObj) {
                function getSelIndex(selId, rows) {
                    for (var i = 0, iMax = rows.length; i < iMax; i++) {
                        if (selId == rows[i].id) {
                            // Ti.API.info('selId: ' + selId);
                            // Ti.API.info('rows[' + i + '].id: ' + rows[i].id);
                            return i;
                        }
                    }
                    return 0;
                }
                var postLayoutEvt = function () {
                    mainView.removeEventListener('postlayout', postLayoutEvt);
                    //orderTimeViewHeight = ro.ui.relY(50); 
                    //defaultNowOrLaterText = "Future";

                    nowOrLaterPicker.setFutureDate(Ti.App.futureOnly ? 0 : 1);

                    var dayIndex, hourIndex, minuteIndex;
                    dayIndex = getSelIndex(futureTimeObj.day, orderTimeView.children[0].pickRowData);
                    orderTimeView.children[0].setFutureDate(dayIndex);

                    hourIndex = getSelIndex(futureTimeObj.hr, orderTimeView.children[1].pickRowData);
                    orderTimeView.children[1].setFutureDate(hourIndex);

                    minuteIndex = getSelIndex(futureTimeObj.min, orderTimeView.children[2].pickRowData);
                    orderTimeView.children[2].setFutureDate(minuteIndex, true);
                    //Ti.API.info("dayIndex: " + dayIndex);
                    //Ti.API.info("hourIndex: " + hourIndex);
                    //Ti.API.info("minuteIndex: " + minuteIndex);


                    orderTimeView.children[0].addEventListener('change', dayChangeFn);
                    orderTimeView.children[1].addEventListener('change', hrChangeFn);
                    orderTimeView.children[2].addEventListener('change', minChangeFn);
                };
                mainView.addEventListener('postlayout', postLayoutEvt);
            }

            return mainView;
        };
    };
    return {
        newpaymentview: newpaymentview
    };
}();
module.exports = NEWPAYMENTVIEW;
