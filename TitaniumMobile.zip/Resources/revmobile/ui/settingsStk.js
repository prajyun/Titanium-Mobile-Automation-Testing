var SETTINGSSTK = function(){
	//Ti.include('/classes/suds.js');
	var settingsstk = function(ro){
	
		var settingsStk = null;
		var shouldInclude = true;
		var SETTINGSVIEW, PROFILEVIEW, DELPROFILEVIEW, ADDRESSVIEW, CURBSIDEVIEW, NEWADDRESSVIEW, EDITADDRESSVIEW, CREDITCARDVIEW, CREDITCARDDETAILS, NEWCREDITCARDVIEW, USERNAMEVIEW, PASSWORDVIEW;
	
		function includeSettingsFiles(){
			//Ti.include('/revmobile/ui/settingsView.js');
			SETTINGSVIEW = SETTINGSVIEW || require("revmobile/ui/settingsView");
		    SETTINGSVIEW.settingsview(ro);
		    
		    PROFILEVIEW = PROFILEVIEW || require('revmobile/ui/profileView');
		    PROFILEVIEW.profileview(ro);

			DELPROFILEVIEW = DELPROFILEVIEW || require('revmobile/ui/deleteProfileView');
		    DELPROFILEVIEW.delprofileview(ro);
		    
		    ADDRESSVIEW = ADDRESSVIEW || require('revmobile/ui/addressView');
            ADDRESSVIEW.addressview(ro);

            CURBSIDEVIEW = CURBSIDEVIEW || require('revmobile/ui/curbsideView');
            CURBSIDEVIEW.curbsideview(ro);
		    
		    EDITADDRESSVIEW = EDITADDRESSVIEW || require('revmobile/ui/editAddressView');
		    EDITADDRESSVIEW.editaddressview(ro);
		    
		    NEWADDRESSVIEW = NEWADDRESSVIEW || require('revmobile/ui/newAddressView');
		    NEWADDRESSVIEW.newaddressview(ro);
		    
		    CREDITCARDVIEW = CREDITCARDVIEW || require('revmobile/ui/creditCardView');
		    CREDITCARDVIEW.creditcardview(ro);
		    
		    CREDITCARDDETAILS = CREDITCARDDETAILS || require('revmobile/ui/creditCardDetailsView');
		    CREDITCARDDETAILS.creditcarddetails(ro);
		    
		    NEWCREDITCARDVIEW = NEWCREDITCARDVIEW || require('revmobile/ui/newCreditCardView');
		    NEWCREDITCARDVIEW.newcreditcardview(ro);
		    
		    USERNAMEVIEW = USERNAMEVIEW || require('revmobile/ui/updateUserNameView');
		    USERNAMEVIEW.usernameview(ro);
		    
		    PASSWORDVIEW = PASSWORDVIEW || require('revmobile/ui/updatePasswordView');
		    PASSWORDVIEW.passwordview(ro);
		    
		    //PROFILEVIEW, ADDRESSVIEW, CREDITCARDVIEW, USERNAMEVIEW, PASSWORDVIEW
			/*Ti.include('/revmobile/ui/profileView.js');
			Ti.include('/revmobile/ui/addressView.js');
			Ti.include('/revmobile/ui/creditCardView.js');
			Ti.include('/revmobile/ui/updateUserNameView.js');
			Ti.include('/revmobile/ui/updatePasswordView.js');
			Ti.include('/revmobile/ui/creditCardDetailsView.js');
			Ti.include('/revmobile/ui/newCreditCardView.js');
			Ti.include('/revmobile/ui/editAddressView.js');
			Ti.include('/revmobile/ui/newAddressView.js');
	
			Ti.include('/revmobile/ui/levelupOverview.js');
			Ti.include('/revmobile/ui/levelupLoyaltiesView.js');
			Ti.include('/revmobile/ui/levelupCreditView.js');
			Ti.include('/revmobile/ui/levelupCreateCardView.js');
			Ti.include('/revmobile/ui/levelupGiftCardView.js');
			Ti.include('/revmobile/ui/levelupFeedbackView.js');
			Ti.include('/revmobile/ui/levelupHistoryView.js');
			Ti.include('/revmobile/ui/levelupHistoryDetailsView.js');
			Ti.include('/revmobile/ui/rewardsView.js');
			
			Ti.include('/revmobile/ui/honeycombOverview.js');*/
			
			shouldInclude = false;
		}
	
		ro.ui.currentSettingsViewIdx = function(){
			return settingsStk.currentIndex;
		};
        ro.ui.settingsStkViewID = function () {
            if (settingsStk.hasOwnProperty('children') && settingsStk.children.length) {
                return settingsStk.children[0].hid;
            }
            else {
                return '';
            }
		   //return settingsStk.children[0].hid;
		};
		ro.ui.settingsStkSize = function(){
		   return settingsStk.children.length;
		};
		ro.ui.remSettingsStkChildren = function(){
	      settingsStk.removeAllChildren();
	   };
		ro.ui.createSettingsStk = function(_args){
		   settingsStk = ro.ui.createStackView({
		      views:[],
				props:{
				   top:0,
					left:0,
					right:0,
					bottom:0
				}
			});
			ro.ui.settingsShowNext = function(e){
			   try{
	
			   	if(shouldInclude){
			   		includeSettingsFiles();
			   	}
	
			      if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
			      ro.ui.showLoader();
				   var curIndex = settingsStk.currentIndex;
	            var curView = settingsStk.children[curIndex];
	            var nextView = null;
	            var interval = 400;
	            var childrenLength = settingsStk.children.length;
	            settingsStk.removeAllChildren();
	
				   var o = {};
				   var hide = true;
	
				   o.myAccount = true;
				   o.rowid = null;
	
				   if(e.addView){
					   switch(e.showing){
					      case 'settings':
					         nextView = ro.ui.createSettingsView();
					         break;
						   case 'profile':
							   nextView = ro.ui.createProfileView(o);
							   break;
							case 'delProfile':
								nextView = ro.ui.createDeleteProfileView(o);
								break;
						   case 'address':
							   nextView = ro.ui.createAddressView(o);
                               break;
                           case 'curbside':
                               nextView = ro.ui.createCurbsideView(o);
                               break;
						   case 'creditCard':
							   nextView = ro.ui.createCreditCardView(o);
							   break;
						   case 'username':
						   	nextView = ro.ui.updateUserNameView(o);
							   break;
						   case 'password':
							   nextView = ro.ui.updatePasswordView(o);
		   					   break;
						   case 'editCardView':
							   o.rowid = e.rowid;
							   nextView = ro.ui.createCreditCardDetailsView(o);
							   break;
						   case 'addCardBtn':
					   		   nextView = ro.ui.createNewCreditCardView();
							   break;
						   case 'editAddress':
						      o.rowid = e.rowid;
						      nextView = ro.ui.editAddressView(o);
						      break;
						   case 'newAddress':
	                     nextView = ro.ui.newAddressView(o);
	                     break;
	                  case 'levelup': case 'honeycomb':
	                     nextView = ro.ui.getLoyaltiesView();
	                     break;
	                  case 'loyaltiesCredit':
	                     nextView = ro.ui.getLoyaltiesCreditView();
	                     break;
	                  case 'loyaltiesGift':
	                     nextView = ro.ui.getLoyaltiesGiftView();
	                     break;
	                  case 'loyaltiesLoyalty':
	                  	hide = false;
	                     nextView = ro.ui.getLoyaltiesLoyaltyView();
	                     break;
	                  case 'loyaltiesFeedback':
	                     nextView = ro.ui.getLoyaltiesFeedbackView({uuid:e.uuid});
	                     break;
	                  case 'loyaltiesHistory':
	                  	hide = false;
	                     nextView = ro.ui.getLoyaltiesHistoryView();
	                     break;
	                  case 'loyaltiesHistoryDetails':
	                     nextView = ro.ui.getLoyaltiesHistoryDetailsView({order:e.order});
	                     break;
	                  case 'loyaltiesCreateCard':
	                     nextView = ro.ui.getLoyaltiesCreateCardView();
	                     break;
	                  case 'rewards':
	                     ro.ui.hideTabview();
	                     nextView = ro.ui.addRewardsView({settingsBool:true});
	                     break;
	                 
	                  /*case 'honeycomb':
	                     nextView = ro.ui.getHoneycombView();
	                     break;*/
				   	}
				   }
				   else{
				      switch(e.showing){
	                  case 'settings':
	                     ro.ui.changeTab({
	                        tabIndex:0
	                     });
	                     break;
	                  case 'profile':					   
					  case 'address': 
					  case 'curbside': 
					  case 'creditCard': 
					  case 'username': 
					  case 'password': 
					  case 'loyalties': 
					  case 'loyaltiesCredit': 
					  case 'rewards': 
					  case 'honeycomb':
	                     if(e.showing == 'rewards'){
	                        ro.REV_LOYALTY.getCurrentLoyalty().releaseWebview();
	                        ro.ui.showTabview();
	                     }
	                     nextView = ro.ui.createSettingsView();
	                     break;
					  case 'delprofile':
						 nextView = ro.ui.createProfileView(o);
	                     break;
	                  case 'creditCardView': case 'addCardBtn':
	                     nextView = ro.ui.createCreditCardView(o);
	                     break;
	                  case 'editAddress': case 'newAddress': case 'delAddress':
	                     nextView = ro.ui.createAddressView(o);
	                     break;
	                  case 'loyaltiesGift': case 'loyaltiesLoyalty': case 'loyaltiesHistory':
	                     nextView = ro.ui.getLoyaltiesView();
	                     break;
	                  case 'loyaltiesHistoryDetails': case 'loyaltiesFeedback':
	                  	hide = false;
	                     nextView = ro.ui.getLoyaltiesHistoryView();
	                     break;
	                  case 'loyaltiesCreateCard':
	                     nextView = ro.ui.getLoyaltiesCreditView();
	                     break;
	               }
				   }
				   if(nextView && nextView!=null){
				      try{
	                  ro.app.GA.trackPageView(nextView.hid);
	               }
	               catch(ex){
	                  if(Ti.App.DEBUGBOOL) { Ti.API.debug('ro.app.GA.trackPageView(settingsStk.js)-Exception: ' + ex); }
	               }
	
						if(e.resetOrder){
							Ti.App.fireEvent('resetOrdTypeStk');
						}
	
	               settingsStk.add(nextView);
	               settingsStk.children[0].visible = true;
	               ro.ui.hideHomeSelection(true);
	               //tabBar.printStackSizes();
	               if(hide){
	               	ro.ui.hideLoader();
	               }
	            }
				}
				catch(ex){
					ro.ui.alert('Navigation Error','Code:N100' + ex);
				}
			};
	
			ro.ui.settingsRemoveView = function(e){
				settingsStk.remove(e.view);
				settingsStk.currentIndex--;
			};
	
			ro.ui.settingsReset = function(e){
				try{
					if(settingsStk.currentIndex != 0){
						settingsStk.children[0].animate({duration:50, right:0});
				 		settingsStk = ro.ui.popViews({
							parent:settingsStk,
							startIndex:settingsStk.children.length - 1,
							count:settingsStk.children.length - 2
						});
	
						settingsStk.children[1].animate({duration:50, right:0});
						settingsStk.fireEvent('changeStkIndex', {idx:0});
					}
				}
				catch(ex){
			 		ro.ui.alert('Navigation Error', 'Code:N102' + ex);
				}
			};
			return settingsStk;
	   };
	};
	return {
		settingsstk:settingsstk
	};
}();
module.exports = SETTINGSSTK;