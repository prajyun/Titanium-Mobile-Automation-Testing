var CURBSIDEVIEW = function () {
    var curbsideview = function (ro) {
        ro.ui.createCurbsideView = function () {
            var numRows;
            var custInfoObj;
            var vhclControl = require("controls/vehicleControl");
            var view = Ti.UI.createScrollView(ro.combine(ro.ui.properties.contentsSmallView, {
                top: ro.ui.relY(5),
                layout: 'vertical',
                disableBounce: ro.isiOS ? true : false,
                contentWidth: Ti.UI.FILL,
                bottom: ro.ui.relY(70)
            }));

            var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, { name: 'curbside', hid: 'curbside', layout: 'vertical' }));
            var navBar = Ti.UI.createView(ro.ui.properties.navBar);
            var noVhclLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, { text: 'There are no saved vehicles.' }));

            var addVhclBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
            addVhclBtn.addEventListener('click', function (e) {
                try {
                    if (custInfoObj.Vehicles && custInfoObj.Vehicles.length >= 5) {
                        ro.ui.alert('Error: ', 'Only five vehicles may be saved at any given time');
                    }
                    else {
                        vhclControl.openForm(false, null, refreshView);                        
                    }
                }
                catch (ex) {
                    Ti.API.info("Vehicle Error: " + Ti.API.info(ex));
                    ro.ui.alert('Vehicle Error', 'Code:110');
                }
            });

            var btnBack = layoutHelper.getBackBtn('SETTINGS');
            btnBack.addEventListener('click', function (e) { ro.ui.settingsShowNext({ showing: 'curbside' }); });

            navBar.add(btnBack);
            navBar.add(addVhclBtn);

            if (ro.isiphonex) {
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            }
            else {
                mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            }

            var refreshView = function () {
                Ti.API.info("Refresh Curbside View Called");
                view.removeAllChildren();
                custInfoObj = JSON.parse(Ti.App.Properties.getString('Customer', {}));
                if (!custInfoObj.Vehicles) custInfoObj.Vehicles = [];
                Ti.API.info(JSON.stringify(custInfoObj.Vehicles));
                if (!custInfoObj.Vehicles.length) {
                    view.add(noVhclLbl);
                } else {
                    var vhclHdrTxt = "Vehicle Information";
                    view.add(ro.layout.getGenericHdrRowWithHeader(vhclHdrTxt, true));
                    if (custInfoObj.Vehicles && custInfoObj.Vehicles.length > 0) {
                        numRows = custInfoObj.Vehicles.length;
                    }
                    else {
                        numRows = 0;
                    }

                    for (var i = 0, iMax = numRows; i < iMax; i++) {
                        var vhclObject = {};

                        var formattedVehicle = custInfoObj.Vehicles[i].Make + ', ' + custInfoObj.Vehicles[i].Model + ', ' + custInfoObj.Vehicles[i].Color;
                        if (custInfoObj.Vehicles[i].hasOwnProperty('Features') && custInfoObj.Vehicles[i].Features != "") {
                            formattedVehicle = custInfoObj.Vehicles[i].Make + ', ' + custInfoObj.Vehicles[i].Model + ', ' + custInfoObj.Vehicles[i].Color + '\n' + custInfoObj.Vehicles[i].Features;
                        }
                        vhclObject.formattedHdr = custInfoObj.Vehicles[i].Name + ':';
                        vhclObject.formattedText = formattedVehicle;
                        vhclObject.customObj = {
                            obj: custInfoObj.Vehicles[i]
                        };


                        //view.add(ro.layout.getGenericHdrRow(custInfoObj.Vehicles[i].Name));

                        var vehicleRow = ro.layout.getSpecialRow(vhclObject);
                        vehicleRow.addEventListener('click', function (e) {
                            vhclControl.openForm(false, e.source.obj, refreshView);
                        });
                        view.add(vehicleRow);
                    }                    

                }               
                
            }
            refreshView();
            mainView.add(view);
            return mainView;
        };
    };
    return {
        curbsideview: curbsideview
    };
}();
module.exports = CURBSIDEVIEW;