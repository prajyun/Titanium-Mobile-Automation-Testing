var SUGGESTVIEW = function() {
    var suggestview = function(ro) {
        ro.ui.createSuggestView = function(_args) {
            var menuUtils = require('logic/menuUtils');
            var continueHid = 'paymentScreen';
            //GUEST ORDER
            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                continueHid = 'guestDetails';
            }
            //GUEST ORDER

            var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                name: 'Suggest',
                hid: 'Suggest',
                layout: 'vertical'
            }));
            var navBar = Ti.UI.createView(ro.ui.properties.navBar);
            Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
            var suggTitleTxt = 'WOULD YOU LIKE TO ADD?';
            if (ro.app.Store.Configuration.SUGG_TITLE && ro.app.Store.Configuration.SUGG_TITLE.length > 0) {
                suggTitleTxt = ro.app.Store.Configuration.SUGG_TITLE;
            }
            var suggLblTxt = 'Would you like to add one of the following items to your order?';
            if (ro.app.Store.Configuration.SUGG_MSG && ro.app.Store.Configuration.SUGG_MSG.length > 0) {
                suggLblTxt = ro.app.Store.Configuration.SUGG_MSG;
            }
            
            var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
                text: suggTitleTxt
            }));
            //navBar.add(headerLbl);

            var btnSubmit = layoutHelper.getRightBtn('CHECKOUT');
            btnSubmit.addEventListener('click', function(e) {
                ro.ui.cartShowNext({
                    addView: true,
                    showing: continueHid
                });
            });
            //navBar.add(btnSubmit);
            var backBtn = layoutHelper.getBackBtn();
            backBtn.addEventListener('click', function(){
                ro.ui.cartShowNext({
                                addView: true,
                                showing: 'Cart'
                            });
            });
            navBar.add(backBtn);
            //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            
             if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
            
            mainView.add(Ti.UI.createLabel({
                top:ro.ui.relY(15),
                height:Ti.UI.SIZE,
               text:suggTitleTxt,
               textAlign:'center',
               color:'#393839',
               font:{
                  fontSize:ro.ui.scaleFont(30, 0, 0),
                  //fontWeight:'bold',
                  fontFamily:ro.ui.fonts.titles
               }
            }));

            mainView.add(Ti.UI.createLabel({
                top: ro.ui.relY(15),
                height: Ti.UI.SIZE,
                left:ro.ui.relX(15),
                right:ro.ui.relX(15),
                text: suggLblTxt,
                textAlign: 'center',
                color: '#393839',
                font: {
                    fontSize: ro.ui.scaleFont(26, 0, 0),
                    //fontWeight:'bold',
                    fontFamily: ro.ui.fonts.titles
                }
            }));

            //}
            

            
            var tblView = Ti.UI.createTableView({
                height:Ti.UI.FILL,
                top:ro.ui.relY(15),
                width:Ti.UI.FILL,
                separatorColor:'transparent'
            });
            var useToMakeRows = [];
            
            var cancelBtn = ro.layout.getMediumButton("No Thanks");
            cancelBtn.top = null;
            cancelBtn.bottom = null;
            cancelBtn.addEventListener('click', function(){
                ro.ui.cartShowNext({
                    addView: true,
                    showing: continueHid
                });
            });
            var tempRowHeight = ((ro.ui.displayCaps.platformWidth - ro.ui.relX(25)) / 2);
            useToMakeRows = REV_Suggest.getItems();
            Ti.API.debug('useToMakeRows: ' + JSON.stringify(useToMakeRows));
            var btnRow = Ti.UI.createTableViewRow({
                    selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                    height:tempRowHeight//ro.ui.relY(125)//,
                    //width:Ti.UI.FILL
                });
                btnRow.add(cancelBtn);
            var clickEvt = function(e) {
                try {
                    //ro.ui.showLoader();
                    var index;
                    ro.app.group = ro.app.Store.Menu.Groups[e.source.grpIndx];
                    ro.app.itemSelected = ro.app.Store.Menu.Groups[e.source.grpIndx].Items[e.source.itmIndx];

                    if (menuUtils.straightToCart()) {
                        var ITEMOBJ = require('logic/itemObj');
                        ITEMOBJ.itemobj(ro);
                        ro.itemObj.InitializeItemObj();
                        ro.itemObj.setNoSizes();
                        menuUtils.addToCart(ro.app.Store, ro.itemObj.getItemObj());
                        ro.ui.cartShowNext({
                            addView: true,
                            showing: 'Cart'
                        });
                    }
                    else {
                        var itmIndx = e.source.itmIndx;
                        var grpIndx = e.source.grpIndx;
                        var sz = e.source.SuggSizeName && e.source.SuggSizeName.length ? e.source.SuggSizeName : '';
                        var sty = e.source.SuggStyleName && e.source.SuggStyleName.length ? e.source.SuggStyleName : '';
                        ro.App.sugg.suggMode = true;
                        ro.App.sugg.itmIndx = itmIndx;
                        ro.App.sugg.grpIndx = grpIndx;
                        ro.App.sugg.SuggSizeName = sz;
                        ro.App.sugg.SuggStyleName = sty;
                        ro.ui.cartShowNext({
                            showing: 'Cart'
                        });
                    }
                }
                catch(ex) {
                    ro.ui.hideLoader();
                    
                        Ti.API.info('suggTbl-ClickEvent-Exception: ' + ex);
                    
                }
            };
            ro.layout.createNewRows(useToMakeRows, function(rows){
                rows.push(btnRow);
                tblView.appendRow(rows);
            }, clickEvt);
            
            mainView.add(tblView);
            return mainView;
        };


        ro.ui.oldcreateSuggestView = function(_args) {
            var menuUtils = require('logic/menuUtils');
            var continueHid = 'paymentScreen';
            //GUEST ORDER
            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                continueHid = 'guestDetails';
            }
            //GUEST ORDER

            var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                name: 'Suggest',
                hid: 'Suggest',
                layout: 'vertical'
            }));
            var navBar = Ti.UI.createView(ro.ui.properties.navBar);

            var suggTitleTxt = 'WOULD YOU LIKE TO ADD?';
            if (ro.app.Store.Configuration.SUGG_TITLE && ro.app.Store.Configuration.SUGG_TITLE.length > 0) {
                suggTitleTxt = ro.app.Store.Configuration.SUGG_TITLE;
            }
            var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
                text: suggTitleTxt
            }));
            navBar.add(headerLbl);

            var btnSubmit = layoutHelper.getRightBtn('CHECKOUT');
            btnSubmit.addEventListener('click', function(e) {
                ro.ui.cartShowNext({
                    addView: true,
                    showing: continueHid
                });
            });
            navBar.add(btnSubmit);
            mainView.add(navBar);

            function addRow(receiptName, obj, imgPath, isCoupon, idx, itemPrice, grpIndx, itmIndx, SuggSizeName, SuggStyleName) {

                var thisRow;

                var hasImg = (imgPath && imgPath.length > 0);
                var left = ro.ui.relX(7);
                var cls = ( hasImg ? 'item' : 'noitem');
                var hasRightImg = false;

                thisRow = Ti.UI.createTableViewRow({
                    hasChild: false,
                    height: ro.ui.relY(100),
                    itmType: ( isCoupon ? 'coupon' : 'item'),
                    txtObj: obj.txtObj,
                    hasTheCheck: hasRightImg,
                    grpIndx: grpIndx,
                    itmIndx: itmIndx,
                    SuggSizeName: SuggSizeName,
                    SuggStyleName: SuggStyleName,
                	   selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                });

                var rowVw = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: Ti.UI.FILL,
                    top: ro.ui.relY(1),
                    bottom: ro.ui.relY(1),
                    //backgroundImage:'/images/menuItemBg.png',//Ti.App.websiteURL+'/content/images/menu-item.png',
                    //backgroundColor:ro.ui.theme.cpnRowTileColor
                });
                var backgroundImg = Ti.UI.createImageView({
                    image: Ti.App.websiteURL + '/content/images/menu-item.png',
                    defaultImage: '/images/menuItemBg.png',
                    height: Ti.UI.FILL,
                    width: Ti.UI.FILL,
                    zIndex: -1000,
                    touchEnabled: false
                });
                rowVw.add(backgroundImg);

                if (hasImg || (group && group.ImageSource && group.ImageSource.length > 0)) {
                    //left = ro.ui.relX(80);
                    left = Ti.App.picklemansStyle ? ro.ui.relX(110) : ro.ui.relX(105);
                    //80
                    /*rowVw.add(Ti.UI.createImageView({
                     image:hasImg?imgPath:group.ImageSource,
                     defaultImage:ro.ui.properties.defaultImgPath,
                     width:ro.ui.relX(70),
                     height:ro.ui.relY(70),
                     left:ro.ui.relX(5)
                     }));*/
                    rowVw.add(Ti.UI.createImageView({
                        image: hasImg ? imgPath : group.ImageSource,
                        defaultImage: ro.ui.properties.defaultImgPath,
                        width: Ti.App.picklemansStyle ? ro.ui.relX(110) : ro.ui.relX(90), //70
                        height: Ti.App.picklemansStyle ? Ti.UI.FILL : /*ro.ui.relY(70)*/
                        Ti.UI.FILL,
                        left: Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(5),
                        top: Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(15),
                        bottom: Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(15)

                    }));
                }
                /*var labelVw = Ti.UI.createView({
                 height:Ti.UI.FILL,
                 width:Ti.UI.SIZE,
                 right:ro.ui.relX(10),
                 layout:'vertical',
                 left:left
                 });*/
                var labelVw = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: Ti.UI.SIZE,
                    right: ro.ui.relX(10),
                    layout: 'vertical',
                    left: left
                });

                /*labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
                 color:ro.ui.theme.contentsSmallTxtHead,
                 text:(itemPrice != null)?receiptName+'\n'+itemPrice:receiptName,
                 width:Ti.UI.SIZE,
                 top:ro.ui.relY(15),
                 font:{
                 fontSize:ro.ui.scaleFont(13),
                 fontWeight:'bold',
                 fontFamily:ro.ui.fontFamily
                 }
                 })));*/
                var finalString = receiptName;
                // + '\n' + itemPrice;

                var attributesCol = [];
                if (itemPrice && itemPrice.length) {
                    var beginLength = finalString.length;
                    finalString = finalString + ' - ' + itemPrice;
                    Ti.API.debug('finalString: ' + finalString);

                    attributesCol.push({
                        type: Ti.UI.ATTRIBUTE_FONT,
                        value: {
                            fontSize: ro.ui.scaleFont(10),
                            fontWeight: 'normal'
                        },
                        range: [receiptName.length + 1, (itemPrice && itemPrice.length ? itemPrice.length + 2 : 0)]
                    });
                }
                var attr = Ti.UI.createAttributedString({
                    text: finalString,
                    attributes: attributesCol
                });

                labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsName, {
                    color: ro.ui.theme.newGroupsBtnTxt,
                    //text:(itemPrice != null)?receiptName+'\n'+itemPrice:receiptName,
                    //left:left,
                    attributedString: attr,
                    width: Ti.UI.SIZE,
                    top: Ti.App.picklemansStyle ? ro.ui.relY(10) : ro.ui.relY(3),
                    font: {
                        fontSize: ro.ui.scaleFont(16), //11
                        fontWeight: 'bold',
                        fontFamily: ro.ui.fontFamily
                    }
                })));

                /*labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
                 color:ro.ui.theme.contentsSmallTxt,
                 text:obj.description,
                 height:Ti.UI.SIZE,
                 width:Ti.UI.SIZE,
                 top:ro.ui.relY(4),
                 font:{
                 fontSize:ro.ui.scaleFont(11.5),
                 fontFamily:ro.ui.fontFamily
                 }
                 })));*/
                labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsDetails, {
                    color: ro.ui.theme.contentsSmallTxt,
                    text: obj.description,
                    height: Ti.UI.SIZE,
                    width: Ti.UI.SIZE,
                    top: ro.ui.relY(2),
                    font: {
                        fontSize: ro.ui.scaleFont(11.5),
                        fontFamily: ro.ui.fontFamily//10
                    }
                })));

                rowVw.add(labelVw);
                if (hasRightImg) {
                    var rowChk = Ti.UI.createImageView({
                        right: ro.ui.relX(3),
                        image: '/images/check.png'
                    });
                    rowVw.checkMark = rowChk;
                    rowVw.add(rowVw.checkMark);
                }
                thisRow.add(rowVw);
                return thisRow;
            }

            var suggTbl = Ti.UI.createTableView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                separatorColor:'transparent'
            });

            var useToMakeRows = [];
            useToMakeRows = REV_Suggest.getItems();
            Ti.API.debug('useToMakeRows: ' + JSON.stringify(useToMakeRows));
            var rows = [];
            for (var i = 0; i < useToMakeRows.length; i++) {
                var path = '';
                if (useToMakeRows[i].HasImage && useToMakeRows[i].ImageSource && useToMakeRows[i].ImageSource.length) {
                    path = useToMakeRows[i].ImageSource;
                }
                rows.push(addRow(useToMakeRows[i].DisplayName || useToMakeRows[i].ReceiptName || useToMakeRows[i].Name, menuUtils.formItmDesc(useToMakeRows[i], useToMakeRows[i].grpIndx), path, false, i, '', useToMakeRows[i].grpIndx, useToMakeRows[i].itmIndx, useToMakeRows[i].sugg.SuggSizeName, useToMakeRows[i].sugg.SuggStyleName));
            }
            suggTbl.setData(rows);

            suggTbl.addEventListener('click', function(e) {
                try {
                    ro.ui.showLoader();
                    var index;
                    ro.app.group = ro.app.Store.Menu.Groups[e.row.grpIndx];
                    ro.app.itemSelected = ro.app.Store.Menu.Groups[e.row.grpIndx].Items[e.row.itmIndx];

                    if (menuUtils.straightToCart()) {
                        InitializeItemObj();
                        setNoSizes();
                        menuUtils.addToCart(ro.app.Store, ro.itemObj.getItemObj());
                    }
                    else {
                        var itmIndx = e.row.itmIndx;
                        var grpIndx = e.row.grpIndx;
                        var sz = e.row.SuggSizeName && e.row.SuggSizeName.length ? e.row.SuggSizeName : '';
                        var sty = e.row.SuggStyleName && e.row.SuggStyleName.length ? e.row.SuggStyleName : '';
                        ro.App.sugg.suggMode = true;
                        ro.App.sugg.itmIndx = itmIndx;
                        ro.App.sugg.grpIndx = grpIndx;
                        ro.App.sugg.SuggSizeName = sz;
                        ro.App.sugg.SuggStyleName = sty;
                        ro.ui.cartShowNext({
                            showing: 'Cart'
                        });
                    }
                }
                catch(ex) {
                    ro.ui.hideLoader();
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('suggTbl-ClickEvent-Exception: ' + ex);
                    }
                }
            });

            var suggLblTxt = 'Would you like to add one of the following items to your order?';
            if (ro.app.Store.Configuration.SUGG_MSG && ro.app.Store.Configuration.SUGG_MSG.length > 0) {
                suggLblTxt = ro.app.Store.Configuration.SUGG_MSG;
            }

            var suggLbl = Ti.UI.createLabel({
                text: suggLblTxt,
                font: {
                    fontSize: ro.ui.scaleFont(14),
                    fontWeight: 'bold',
                    fontFamily: ro.ui.fontFamily
                },
                color: 'black'
            });
            var suggLblView = Ti.UI.createView({
                height: ro.ui.relY(60),
                width: Ti.UI.FILL,
                borderColor: ro.ui.theme.btnDefault,
                borderWidth: ro.ui.relY(2)
            });
            suggLblView.add(suggLbl);
            mainView.add(suggLblView);
            mainView.add(suggTbl);
            return mainView;
        };
    };
    return {
        suggestview: suggestview
    };
}();
module.exports = SUGGESTVIEW;
