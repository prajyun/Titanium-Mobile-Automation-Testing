Ti.include('/logic/menuUtils.js');
Ti.include('/logic/menuHelper.js');
(function(){
	ro.ui.createItemsViewDemo = function(_args){
var itemsData =[];
var Coupons = [];
var items = null;
var group = null;
var updating = false;
var ItmDisplayLen;
var curSelectedGroup = null;

var itemsView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
   name:'items'
}));

var tblItems = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
   data:[],
   rowHeight:Ti.UI.SIZE,
   minRowHeight:ro.ui.properties.menuRowHeight
}));

var noItemsLbl = Ti.UI.createLabel({					
	font:{
	   fontSize:ro.ui.scaleFontY(11,13),
	   fontWeight:'bold'
	},
	textAlign:'center',
	width:ro.ui.relX(200),
	height:ro.ui.relY(50)
});

var lastDispRowId;
var interval;
tblItems.addEventListener('scroll', function(e){
	if(interval>0 || (items.length-e.totalItemCount ===0)){
		return;
	}
	interval = setTimeout(function(){
		var endRow = e.firstVisibleItem + e.visibleItemCount;
		if(endRow <= lastDispRowId){
			interval = 0;
			return;
		}
		endRow += itmDisplayableLen;
		
		if(endRow > items.length){
	   	endRow = items.length;
		}
		
		if(lastDispRowId+1 != items.length){
   		for(var j=lastDispRowId+1;j<endRow;j++){
		      if(curSelectedGroup != 'Coupons'){
				   var path;
               if(items[j].HasImage){
                  path = items[j].ImageSource;
               }
               addItem(items[j].ReceiptName, formItmDesc(items[j]), path, false, j, menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx) );
				}
			   else{
               var path = ro.ui.properties.defaultPath + 'coupon.png';
               addItem(items[j].RcptName, formCpnDesc(items[j]), path, true, j, null);
            }
         }
         tblItems.setData(itemsData);
         lastDispRowId = endRow-1;
		}
		interval=0;
   },20);
});

tblItems.addEventListener('click',function(e){
   var index;
	if(e.row.itmType == 'coupon'){
      ca.showData(e.row.txtObj);
      return;
   }
   else{
      ro.app.itemSelected = group.Items[e.index];
      itemIndex = e.index;
      ro.ui.demoShowNext({ addView:true, showing:'itemDetails' });
   }  
});

function formItmDesc(Itm){
	var rtnDesc = "";
	if(Itm.ItemDesc){
		rtnDesc = Itm.ItemDesc;
	}
	else{
		var preModsFound=false;
		if(Itm.PreMods){
			if(Itm.PreMods.length > 0){
				if(curSelectedGroup == "Pizza"){
			 		rtnDesc+= "Our " + Itm.ReceiptName + " is topped with ";
				}
				else{
					rtnDesc+= Itm.ReceiptName + " is served with ";
				}
				for(var i=0;i<Itm.PreMods.length;i++){
					if (group.Mods){
						for(var j=0;j<group.Mods.length;j++){
							if(Itm.PreMods[i].Name == group.Mods[j].Name){
								preModsFound=true;
								rtnDesc+= group.Mods[j].ReceiptName;
								if(i!=Itm.PreMods.length-1){
									rtnDesc+= ", ";
								}
							}
						}	
					}
					
				}
				if (preModsFound){
					rtnDesc+= ".";	
				}
				else{
					rtnDesc = "";
				}
				
			}
		}	
	}
	var rtnObj ={};
	rtnObj.description = rtnDesc;
	rtnObj.txtObj = null;
	return rtnObj;
}


function formCpnDesc(coupon){
	var cpnObj ={};
	var cpnDescription = "";
	var cpnInstructions = "";
	if(coupon.CpnScope == 3){
		var itms = [];
		for(j=0;j<coupon.Items.length;j++){
			var itmFound = false;
			var curItm = {};
			curItm.MenuItem = coupon.Items[j].MenuItem;
			curItm.MenuSize = coupon.Items[j].MenuSize;
			curItm.MenuStyle = coupon.Items[j].MenuStyle;
			curItm.MenuGroup = coupon.Items[j].MenuGroup;
			curItm.Qty = 1;
			for(var k=0;k<itms.length;k++){
				if(itms[k].MenuItem == curItm.MenuItem && itms[k].MenuSize == curItm.MenuSize && itms[k].MenuStyle == curItm.MenuStyle){
					itms[k].Qty += 1;
					itmFound = true;
					break;
				}
			}
			if(!itmFound){
				itms.push(curItm);	
			}
							
		}
		for(j=0;j<itms.length;j++){
			cpnDescription+= itms[j].MenuGroup + ': ';
			cpnInstructions+= (j+1) + '. ';
			
			if(itms[j].MenuSize=="All" && itms[j].MenuStyle == "All" && itms[j].MenuItem=="All"){
					cpnDescription +='Any ' + itms[j].Qty + ' of your choice.';		
					cpnInstructions+='Add any '+ itms[j].Qty + ' ' + itms[j].MenuGroup + ' of your choice.';		
			}
			else{
				var tempTxt = 'Add '+ itms[j].Qty + ' ';
				cpnDescription+=itms[j].Qty + ' ';
				
				if(itms[j].MenuSize!="All"){
					cpnDescription += itms[j].MenuSize + ' ';
					tempTxt+= itms[j].MenuSize + ' ';
				}
				if(itms[j].MenuStyle!="All"){
					cpnDescription+= itms[j].MenuStyle + ' ';
					tempTxt+= itms[j].MenuStyle + ' ';
				}
				if(itms[j].MenuItem!="All"){
					cpnDescription+= itms[j].MenuItem + '.';
					tempTxt+= itms[j].MenuItem + '.';
				}
				else{
					cpnDescription = 'Any ' + cpnDescription + 'of your choice.';	
					tempTxt += itms[j].MenuGroup + ' of your choice.';
				}
				cpnInstructions+= tempTxt;
			}
			  
			if(j!=itms.length-1){
				cpnDescription+= '\n';
			}
			cpnInstructions+= '\n';
		}
		cpnInstructions+= (itms.length+1) + '. ' + 'Proceed to Cart.' + '\n';
		cpnInstructions+= (itms.length+2) + '. ' + 'Click on Coupons.' + '\n';
		cpnInstructions+= (itms.length+3) + '. ' + 'Tap on ' + '"' + coupon.RcptName + '"' + ' to apply.';
	}
	else{
		cpnDescription = coupon.CpnDesc;
		cpnInstructions = "";
	}
	cpnTxt = {};
	cpnTxt.RcptName = coupon.RcptName;
	cpnTxt.cpnInstructions = cpnInstructions;
	
	cpnObj.description = coupon.CpnDesc;
	cpnObj.txtObj = cpnTxt;
	return cpnObj;
}

function addItem(receiptName, obj, imgPath, isCoupon, idx, itemPrice){
   var hasImg = (imgPath && imgPath.length > 0);
   var left = ro.ui.relX(7);
   var cls = (hasImg?'item':'noitem');
   
   itemsData[idx] = Ti.UI.createTableViewRow({
	   hasChild:false,
		className:cls,
		itmType:(isCoupon?'coupon':'item'),
		txtObj:obj.txtObj,
		backgroundSelectedColor:ro.ui.theme.tblRowSelected
	});
	
   if(hasImg || (group.ImageSource && group.ImageSource.length > 0)){			
		left = ro.ui.relX(80);
	   itemsData[idx].add(Ti.UI.createImageView({
	      image:hasImg?imgPath:group.ImageSource,
	      defaultImage:ro.ui.properties.defaultImgPath,
	      width:ro.ui.relX(70),
	      height:ro.ui.relY(70),
	      left:0,
	      top:ro.ui.relY(5)
	   }));
	}
         
   itemsData[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName,{
      color:ro.ui.theme.contentsSmallTxtHead,
      text:(itemPrice != null)?receiptName+'\n'+itemPrice:receiptName,
      left:left,
      top:ro.ui.relY(2),
      font:{
         fontSize:ro.ui.scaleFont(11),
         fontWeight:'bold'
      }
   })));
      
   itemsData[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails,{
      color:ro.ui.theme.contentsSmallTxt,
      text:obj.description,
      height:Ti.UI.SIZE,
      width:Ti.UI.FILL,
      top:ro.ui.relY(28),
      bottom:ro.ui.relY(3),
      left:left,
      ellipsize:true,
      font:{
         fontSize:ro.ui.scaleFont(10)
      }
   })));
}

function addCoupons(){
	var j, k;
    var CpnIdx;
    var blnVis;
    var BtnIdx = 0;
    var deliveryType;
    var curOrdType = Ti.App.OrderObj.OrdType ;
	
	for (CpnIdx = 0; CpnIdx < ro.app.Store.Menu.Cpns.length; CpnIdx++) {
		if (!ro.app.Store.Menu.Cpns[CpnIdx].ReqValCode) {
			blnVis = false;
			var curDate = new Date();
			var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
			var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
			
			if (ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All') {
				blnVis = true;
				
				if (ro.app.Store.Menu.Cpns[CpnIdx].HasStartDt) {
					var startDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].StartDt);
					if (startDt.getTime() > timeAtStore.getTime()) {
						blnVis = false;
						continue;
					}
				}
				if (ro.app.Store.Menu.Cpns[CpnIdx].HasExpirDt) {
					var ExpirDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].ExpirDt);
					if (ExpirDt.getTime() < timeAtStore.getTime()) {
						blnVis = false;
						continue;
					}
				}
				if(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays > 0){
					if(blnVis==true){
						if(!menuUtils.WeekdayValid(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays, timeAtStore)){
							blnVis=false;
							continue;
						}
					}
				}
				if(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx > 0){
					if(blnVis==true){
						if(!menuUtils.IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTime, ro.app.Store.Menu.Cpns[CpnIdx].EndTime, timeAtStore)){
							blnVis=false;
							continue;
						}
					}
				}
				if(ro.app.Store.Menu.Cpns[CpnIdx].HasExcldOrdType){
					if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes){
						for(j=0;j<ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length;j++){
							if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[j] == curOrdType){
								blnVis=false;
								continue;
							}
						}
					}
				}
				if(blnVis){
					Coupons.push(ro.app.Store.Menu.Cpns[CpnIdx]);
				}
			}
		}
	}
}

addCoupons();

function setVisibility(){
	if(itemsData.length>0){
		tblItems.visible = true;
		noItemsLbl.visible = false;
		tblItems.setData(itemsData);
      tblItems.scrollToIndex(0);
	}
	else{
		tblItems.visible=false;
		noItemsLbl.text = (curSelectedGroup=='Coupons'?'No coupons available.':'No items available under '+ curSelectedGroup +'.');
		noItemsLbl.visible=true;
      noItemsLbl.color = ro.ui.theme.textColor;
	}	
}

	var th = ro.ui.properties.plHeight - ro.ui.relY(199);
	var tr = ro.ui.relY(20)+(60)*(ro.ui.properties.devDpi/160);
	var div = Math.ceil(th/tr);
	var itmDisplayableLen = (th%tr)==0? div +1:div;

 ro.ui.refreshItems = function (curSelGroup){
	itemsData = [];
	curSelectedGroup = curSelGroup;
	/*var th = ro.ui.properties.plHeight - ro.ui.relY(199);
	var tr = ro.ui.relY(20)+(60)*(ro.ui.properties.devDpi/160);
	var div = Math.ceil(th/tr);
	var itmDisplayableLen = (th%tr)==0? div +1:div;*/
	if(curSelectedGroup != 'Coupons'){
	   for(var i=0; i<ro.app.Store.Menu.Groups.length; i++){
             if(ro.app.Store.Menu.Groups[i].Name == curSelectedGroup){
                group = ro.app.Store.Menu.Groups[i];
                ro.app.group = ro.app.Store.Menu.Groups[i];
                break;
             }
          }
          items = group.Items;
          itmDisplayLen = items.length;
          
          if(itmDisplayLen > itmDisplayableLen){
             itmDisplayLen = itmDisplayableLen;
          }
          lastDispRowId = itmDisplayLen-1;
          for(var j=0;j<itmDisplayLen;j++){
             var path;
             if(items[j].HasImage){
                path = items[j].ImageSource;
             }
             addItem(items[j].ReceiptName, formItmDesc(items[j]), path, false, j, menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
      }
      tblItems.setData(itemsData);
	}
	else{
	   items = Coupons;
          itmDisplayLen = Coupons.length;
          if(itmDisplayLen > itmDisplayableLen){
             itmDisplayLen = itmDisplayableLen;
          }
          lastDispRowId = itmDisplayLen-1;
          
          for(var j=0; j<itmDisplayLen; j++){
             var path = ro.ui.properties.defaultPath + 'coupon.png';
             if(items[j].HasImage){
                path = items[j].ImageSource;
             }
             addItem(items[j].RcptName,formCpnDesc(items[j]),path,true,j, null);
          }
          tblItems.setData(itemsData);
	}
	setVisibility();
};

itemsView.add(tblItems);	
itemsView.add(noItemsLbl);
 return itemsView;
};
}());