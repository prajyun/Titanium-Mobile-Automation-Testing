var CHOOSEORDERTYPEVIEW = function() {
    var chooseordertypeview = function(ro) {
        ro.ui.createChooseOrderTypeView = function(_args) {
            try {
                var backBtn = layoutHelper.getBackBtn('BACK');
                backBtn.addEventListener('click', function(e) {
                    ro.ui.ordShowNext({
                        showing: 'chooseOrderTypeView'
                    });
                });
                var mainView = layoutHelper.getMainView('chooseOrderTypeView'/*hid*/, 'Choose Your Order Type'/*Top Title*/, null, null/*left button*/, true/*vertical or not*/, backBtn/*customBtn*/);
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('chooseOrderTypeView()-Exception: ' + ex);
                }
            }

            var allowDeliv = true;
            var Config = null;
            var carryoutLbl = 'Pickup';
            var deliveryLbl = 'Delivery';
            var storeObj = ro.app.Store;
            if (Ti.App.Properties.hasProperty('Config')) {
                Config = JSON.parse(Ti.App.Properties.getString('Config'));
                if (Config && (Config.AllowDelivery == false || Config.AllowDelivery == 'False')) {
                    allowDeliv = false;
                }
                if (ro.utils.hasProp(Config, 'CarryoutLabel')) {
                    carryoutLbl = Config.CarryoutLabel;
                }
                if (ro.utils.hasProp(Config, 'DeliveryLabel')) {
                    deliveryLbl = Config.DeliveryLabel;

                }
            }
            else if (storeObj && (storeObj.Configuration.AllowDelivery == false || storeObj.Configuration.AllowDelivery == 'False')) {
                allowDeliv = false;
            }

            var view = Ti.UI.createScrollView({
                top:0,
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                disableBounce:true,
                layout: 'vertical',
                contentWidth:Ti.UI.FILL
            });

            //var bannerView = REV_BANNERS.getDefaultBannerView("ordertype.png");
            //bannerView.top = ro.ui.relY(5);
            var bannerView = REV_BANNERS.getBannerView("ordertype.png");
            
            if(!bannerView){
                //view.top = ro.ui.relY(10);
            }
            else{
                
                bannerView.top = ro.ui.relY(5);
                view.add(bannerView);
            }
            
	         

            //mainView.add();

            //var allowDeliv = true;

            
            var bottomView = Ti.UI.createView({
                height:Ti.UI.SIZE,
                width:ro.ui.properties.wideViewWidth,
                layout: 'vertical'//,
                //borderColor:'orange',
                //borderWidth:2
            });
            
            var pickupOrDeliv = allowDeliv ? (carryoutLbl + " or " + deliveryLbl + "?") : (carryoutLbl + "?");

            bottomView.add(Ti.UI.createLabel({
                text: pickupOrDeliv,
                font: ro.ui.font.pathToMenuTitles,
                textAlign: 'center',
                color: ro.ui.theme.orderTypeBgTxt,
                width: Ti.UI.FILL,
                top: ro.ui.relY(10)
            }));

            bottomView.add(Ti.UI.createLabel({
                text: 'Please select your order type',
                font: {
                    fontSize: ro.ui.scaleFont(18),
                    //fontWeight:'bold',
                    fontFamily: ro.ui.fonts.rowBodyTxt
                },
                textAlign: 'center',
                color: ro.ui.theme.orderTypeBgTxt,
                width: Ti.UI.FILL,
                top: ro.ui.relY(7)
            }));

            var buttonView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.SIZE,
                layout: 'horizontal'//,
                //borderColor:'green',
               // borderWidth:2
            });

            var carryoutBtn = Ti.UI.createView({
                top: ro.ui.relY(15),
                height: ro.ui.properties.wideViewWidth * .49,
                width: ro.ui.properties.wideViewWidth * .49,
                backgroundImage: '/images/carryoutBtn.png',
                accessibilityLabel: 'Pick Up',
                accessibilityHint: 'Button'
            });

            var leftView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: ro.ui.properties.wideViewWidth / 2
            });
            leftView.add(carryoutBtn);
            buttonView.add(leftView);

            var deliveryBtn = Ti.UI.createView({
                top: ro.ui.relY(15),
                height: ro.ui.properties.wideViewWidth * .49,
                width: ro.ui.properties.wideViewWidth * .49,
                backgroundImage: '/images/deliveryBtn.png',
                accessibilityLabel: 'Delivery',
                accessibilityHint: 'Button'
            });

            carryoutBtn.addEventListener('click', function(e) {
                try {
                    REV_ORD_TYPE.setOrdType(false);

                    ro.ui.showLoader();
                    Ti.App.RepeatLastOrder = false;
                    nextView();
                }
                catch(ex) {
                    Ti.API.debug('ex: ' + ex);
                    ro.ui.alert('Order Type', 'Code:100');
                }
            });
            deliveryBtn.addEventListener('click', function(e) {
                try {
                    REV_ORD_TYPE.setOrdType(true);

                    ro.ui.showLoader();
                    Ti.App.RepeatLastOrder = false;
                    nextView();
                    //layoutHelper.colorizeBtn(delivBtn, shopBtn);
                }
                catch(ex) {
                    Ti.API.debug('ex: ' + ex);
                    ro.ui.alert('Order Type', 'Code:100');
                }
            });

            var rightView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: ro.ui.properties.wideViewWidth / 2
            });
            rightView.add(deliveryBtn);
            if (allowDeliv) {
                buttonView.add(rightView);
            }

            bottomView.add(buttonView);
            if(Config.ORD_TYPE_INST && Config.ORD_TYPE_INST != ''){
                bottomView.add(Ti.UI.createLabel({
                    text: Config.ORD_TYPE_INST,
                    font: {
                        fontSize: ro.ui.scaleFont(18),
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.rowBodyTxt
                    },
                    textAlign: 'center',
                    color: ro.ui.theme.orderTypeBgTxt,
                    width: Ti.UI.FILL,
                    top: ro.ui.relY(7)
                }));
            }
            
            view.add(bottomView);
            mainView.add(view);

            function nextView() {
                if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                    if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                        ro.ui.ordShowNext({
                            addView: true,
                            showing: 'addNewAddr'
                        });
                    }
                    else {
                        ro.ui.ordShowNext({
                            addView: true,
                            showing: 'newAddrList'
                        });
                    }
                }
                else {
                    ro.ui.ordShowNext({
                        addView: true,
                        showing: 'defaultStore'
                    });
                }
            }
			/*mainView.addEventListener('postlayout', function(){
				Ti.API.info('bannerView: ' + JSON.stringify(bannerView));
				Ti.API.info('bannerView.views[0]: ' + JSON.stringify(bannerView.views[0]));
				Ti.API.info('bannerView: ' + JSON.stringify(bannerView.toImage()));
			});*/
			
			/*bannerView.addEventListener('postlayout', postlayout);
			function postlayout(e){
			    var uiWidth = e.source.rect.height;
			    Ti.API.info('uiWidth: ' + uiWidth);
			    bannerView.removeEventListener('postlayout', postlayout);
			}*/
			
            return mainView;
        };
    };
    return {
        chooseordertypeview: chooseordertypeview
    };
}();
module.exports = CHOOSEORDERTYPEVIEW;
