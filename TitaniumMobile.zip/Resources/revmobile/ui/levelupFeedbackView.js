(function(){
   ro.ui.getLoyaltiesFeedbackView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesFeedback', 'LEVELUP', layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }

      var uuid = _args.uuid;
      var questionTxt = 'How was your experience?';
      var userRating = 0;

      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var loyaltiesFeedbackView =  Ti.UI.createScrollView({
         layout:'vertical',
         top:0,
         bottom:ro.ui.relY(110)
      });
      var loyaltiesFeedbackLbl = Ti.UI.createLabel({
         text:questionTxt,
         font:{
            fontSize:ro.ui.scaleFont(20),
            fontWeight:'bold',
            fontFamily:ro.ui.fontFamily
         },
         textAlign:'center',
         top:ro.ui.relY(25),
         color:'black'
      });
      loyaltiesFeedbackView.add(loyaltiesFeedbackLbl);


      var ratingCollection = [];
      //Add rate view with like circles or stars for the user to click and rate
      var loyaltiesRateView = Ti.UI.createView({
         layout:'horizontal',
         top:ro.ui.relY(10),
         height:ro.ui.relY(55),
         left:0,
         right:0
      });
      var oneStar = Ti.UI.createView({
         height:ro.ui.relY(50),
         width:'14%',
         left:'5%',
         //backgroundColor:'yellow',
         backgroundImage:'/images/feedbackStarEmpty.png',
         starId:1
      });
      ratingCollection.push(oneStar);
      var twoStar = Ti.UI.createView({
         height:ro.ui.relY(50),
         width:'14%',
         left:'5%',
         //backgroundColor:'yellow',
         backgroundImage:'/images/feedbackStarEmpty.png',
         starId:2
      });
      ratingCollection.push(twoStar);
      var threeStar = Ti.UI.createView({
         height:ro.ui.relY(50),
         width:'14%',
         left:'5%',
         //backgroundColor:'yellow',
         backgroundImage:'/images/feedbackStarEmpty.png',
         starId:3
      });
      ratingCollection.push(threeStar);
      var fourStar = Ti.UI.createView({
         height:ro.ui.relY(50),
         width:'14%',
         left:'5%',
         //backgroundColor:'yellow',
         backgroundImage:'/images/feedbackStarEmpty.png',
         starId:4
      });
      ratingCollection.push(fourStar);
      var fiveStar = Ti.UI.createView({
         height:ro.ui.relY(50),
         width:'14%',
         left:'5%',
         //backgroundColor:'yellow',
         backgroundImage:'/images/feedbackStarEmpty.png',
         starId:5
      });
      ratingCollection.push(fiveStar);

      for(var i=0, max=ratingCollection.length; i<max; i++){
         loyaltiesRateView.add(ratingCollection[i]);
      }
      loyaltiesRateView.addEventListener('click', function(e){
         for(var i=5, min=0; i>min; i--){
            if(i>e.source.starId){
               //ratingCollection[i-1].backgroundColor = 'yellow';
               ratingCollection[i-1].backgroundImage = '/images/feedbackStarEmpty.png';
            }
            else{
               //ratingCollection[i-1].backgroundColor = 'blue';
               ratingCollection[i-1].backgroundImage = '/images/feedbackStarSelected.png';
            }
         }
         userRating = e.source.starId;
      });
      loyaltiesFeedbackView.add(loyaltiesRateView);

      var loyaltiesCommentLbl = Ti.UI.createLabel({
         text:'Additional Comments?',
         font:{
            fontSize:ro.ui.scaleFont(20),
            fontWeight:'bold',
            fontFamily:ro.ui.fontFamily
         },
         textAlign:'center',
         top:ro.ui.relY(25),
         color:'black'
      });
      loyaltiesFeedbackView.add(loyaltiesCommentLbl);

      var loyaltiesCommentInput = Ti.UI.createTextArea(ro.combine(ro.ui.properties.allTxtField, {
         top:ro.ui.relY(25),
         left:ro.ui.relX(35),
         right:ro.ui.relX(35),
         height:ro.ui.relY(120),
         backgroundColor:'white',
         hintText:'Optional comments here...'
      }));
      loyaltiesFeedbackView.add(loyaltiesCommentInput);

      var submitBtn = layoutHelper.getBigButton('SUBMIT');
      submitBtn.top = ro.ui.relY(25);
      submitBtn.addEventListener('click', function(e){
         var req = {};
         req.question_text = questionTxt;
         req.rating = userRating;
         req.comment = loyaltiesCommentInput.value;

         //Ti.API.debug('uuid: ' + uuid);
         //Ti.API.debug('req: ' + JSON.stringify(req));
         var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
         levelUp.submitFeedback(req, function(feedbackResp){
            if(feedbackResp.Value){
               ro.ui.settingsShowNext({ showing:'loyaltiesFeedback' });
            }
            else{
               Ti.API.debug('feedback problems');
            }
         }, uuid);
      });
      loyaltiesFeedbackView.add(submitBtn);

      mainView.add(loyaltiesFeedbackView);
      return mainView;
   };
})();