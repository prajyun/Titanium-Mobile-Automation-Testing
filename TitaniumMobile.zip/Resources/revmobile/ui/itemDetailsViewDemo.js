var scrollViewData = [];
var scrollNext;
var checkStyleSize;
var step;
var group;
var itemSelected;
var Store;
var Menu;
(function(){
ro.ui.createItemDetailsViewDemo = function(_args){
	try{
		scrollViewData = [];
		var curPage = 0;
		group = ro.app.group;
		step = 1;
		itemSelected = ro.app.itemSelected;
		Menu = ro.app.Store.Menu;
		var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
			name: 'itemDetails',
			hid:'itemDetails'
		}));
		var navBar = Ti.UI.createView(ro.ui.properties.navBar);
		var headerTxt = 'Customize ' + itemSelected.ReceiptName;
		headerTxt = headerTxt.substr(0,20) + '...';
		var mainHeaderLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:headerTxt}));
		navBar.add(mainHeaderLbl);
		var addItmBtn = Ti.UI.createButton(ro.combine(ro.ui.properties.logoutBtn, {
			backgroundImage:ro.ui.properties.defaultPath + 'additem.png',
			backgroundSelectedImage:ro.ui.properties.defaultPath + 'additemPress.png',
			title: 'Add Item'
		}));
		var backBtn = Ti.UI.createButton(ro.ui.properties.backBtn);
		backBtn.addEventListener('click', function(e){
			ro.ui.demoShowNext({showing:'itemDetails'});
		});
		
		navBar.add(addItmBtn);
		navBar.add(backBtn);
		mainView.add(navBar);
		var count = 1;
		var noOptionView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
		   name: 'No Options'
		}));
		var noOptionLbl = Ti.UI.createLabel({
			text: 'Click "Add Item" to add this item to the cart.',
			font: {
				fontSize: ro.ui.scaleFontY(14,49),
				fontWeight: 'bold'
			},
			textAlign: 'center',
			width: ro.ui.relX(200),
			height: ro.ui.relY(100),
			color: ro.ui.theme.textColor
		});
		noOptionView.add(noOptionLbl);
		
		function CheckItem(){
			var response = {};
			response.isValid = true;
			response.messages = [];
			var i, j;
			var found;
			if (group.HasSizes) {
				if (!itemObj.Size) {
					response.isValid = false;
					response.messages.push('Please select size');
				}
			}
			
			if (group.HasStyles) {
				if (!itemObj.Style) {
					response.isValid = false;
					response.messages.push('Please select style');
				}
			}
			
			if (itemSelected.HasReqMods) {
				for (i = 0; i < itemSelected.ReqMods.length; i++) {
					found = false;
					if (itemObj.Mods) {
						for (j = 0; j < itemObj.Mods.length; j++) {
							if (itemSelected.ReqMods[i] == itemObj.Mods[j].ModCatKey) {
								found = true;
								break;
							}
						}
					}
					
					if (!found) {
						response.isValid = false;
						for (j = 0; j < Menu.ModCategories.length; j++) {
							if (Menu.ModCategories[j].Key == itemSelected.ReqMods[i]) {
								response.messages.push(Menu.ModCategories[j].Msg);
								break;
							}
						}
						
					}
					//newly added (Dec 15, 2010)
					else {
						var whole = false;
						var halfone = false;
						var halftwo = false;
						for (j = 0; j < itemObj.Mods.length; j++) {
							if (itemObj.Mods[j].HalfStatus == 0 && itemSelected.ReqMods[i] == itemObj.Mods[j].ModCatKey) {
								whole = true;
								break;
							}
						}
						if (!whole) {
							for (j = 0; j < itemObj.Mods.length; j++) {
								if (itemObj.Mods[j].HalfStatus == 1 && itemSelected.ReqMods[i] == itemObj.Mods[j].ModCatKey) {
									halfone = true;
									break;
								}
							}
							for (j = 0; j < itemObj.Mods.length; j++) {
								if (itemObj.Mods[j].HalfStatus == 2 && itemSelected.ReqMods[i] == itemObj.Mods[j].ModCatKey) {
									halftwo = true;
									break;
								}
							}
							if (!halfone) {
								response.isValid = false;
								for (j = 0; j < Menu.ModCategories.length; j++) {
									if (Menu.ModCategories[j].Key == itemSelected.ReqMods[i]) {
										response.messages.push(Menu.ModCategories[j].Msg + ' Half1.');
										break;
									}
								}
							}
							if (!halftwo) {
								response.isValid = false;
								for (j = 0; j < Menu.ModCategories.length; j++) {
									if (Menu.ModCategories[j].Key == itemSelected.ReqMods[i]) {
										response.messages.push(Menu.ModCategories[j].Msg + ' Half2.');
										break;
									}
								}
							}
						}
					}
				}
			}
			
			if (itemSelected.HasPrefs) {
				for (i = 0; i < itemSelected.Prefs.length; i++) {
					found = false;
					if (itemObj.PrfMbrs) {
						for (j = 0; j < itemObj.PrfMbrs.length; j++) {
							if (itemSelected.Prefs[i].Name == itemObj.PrfMbrs[j].PrefName) {
								found = true;
								break;
							}
						}
					}
					
					if (!found) {
						response.isValid = false;
						response.messages.push('Please select ' + itemSelected.Prefs[i].Name);
					}
				}
				
			}
			
			return response;
		}
		
		var btnEventListener = addItmBtn.addEventListener('click', function(e){
		 try {
		 	if (itemObj.Mods) {
		 		ModPropFill(itemObj.Mods);
		 	}
		 	if (itemObj.NoMods) {
		 		ModPropFill(itemObj.NoMods);
		 	}
		 	var item = CheckItem();
		 	
		 	if (item.isValid) {
		 		try{
		 			ro.ui.showLoader();
		 			var obj = Ti.App.OrderObj;
		 			if(!obj.Items){
		 				obj.Items = [];
		 			}
		 			obj.Items.push(itemObj);
		 			Ti.App.OrderObj = obj;
						var func = new PricingFunctions();
						Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, Menu, Ti.App.OrderObj.OrdTypePriceIdx);
						ro.ui.showCart();
						ro.ui.hideLoader();
					} 
					catch(ex){
						ro.ui.hideLoader();
						ro.ui.alert('Error', 'CODE:102');
					}
				}
				else{
					var msg = '';
					for(var i=0; i<item.messages.length; i++){
						msg += item.messages[i] + '\n';
					}
					ro.ui.alert('Alert!', msg);
				}
			}
			catch(ex){
				ro.ui.alert('addItem',ex);
			}
		});
		
		
		var leftArrow = Ti.UI.createImageView({
			image:ro.ui.properties.defaultIconPath + 'icon_arrow_left.png',
			left: ro.ui.relX(2),
			width: ro.ui.relX(30),
			height: ro.ui.relY(40)
		});
		
		var rightArrow = Ti.UI.createImageView({
			image:ro.ui.properties.defaultIconPath + 'icon_arrow_right.png',
			right: ro.ui.relX(2),
			width: ro.ui.relX(30),
			height: ro.ui.relY(40)
		});
		
		
		function setArrows(left, right){
			if(left){
				leftArrow.visible = true;
			}
			else{
				leftArrow.visible = false;
			}
			if(right){
				rightArrow.visible = true;
			}
			else{
				rightArrow.visible = false;
			}
		}
		
	  checkStyleSize = function checkStyleSize(Style, Size){
			var matchFound = false;
			var styleIndex;
			var i, j;
			for(i=0; i<group.Styles.length; i++){
				if(group.Styles[i].Name == Style){
					styleIndex = i;
					break;
				}
			}
			for(j=0; j<group.Styles[styleIndex].Sizes.length; j++){
				if(Size == group.Styles[styleIndex].Sizes[j].Name){
					matchFound = true;
					break;
				}
			}
			return matchFound;
		};
		
		var scrollableView = Ti.UI.createScrollableView({
			showPagingControl:true,
			top:ro.ui.relY(110),
			bottom:ro.ui.relY(55),
			right:ro.ui.relX(5),
			left:ro.ui.relX(5)
		});
		var headerView = Ti.UI.createView({
			backgroundImage:ro.ui.properties.defaultPath + 'grpBackground.png',
			height:ro.ui.relY(50),
			top:ro.ui.relY(50)
		});
		
		var headerLabel = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:'',color:ro.ui.theme.grpHeaderColor,width:Ti.UI.SIZE}));
		
		headerView.add(headerLabel);
		headerView.add(leftArrow);
		headerView.add(rightArrow);
		mainView.add(headerView);
		
		leftArrow.addEventListener('click', function(e){
			if(curPage == 0){
				return;
			}
			curPage--;
			scrollableView.scrollToView(curPage);
		});
		rightArrow.addEventListener('click', function(e){
			if(curPage == (scrollableView.views.length - 1)){
				return;
			}
			curPage++;
			scrollableView.scrollToView(scrollableView.views[curPage]);
		});
		
		scrollNext = function scrollNext(){
			if (curPage == (scrollableView.views.length - 1)) {
				return;
			}
			curPage++;
			scrollableView.scrollToView(curPage);
		};
		
		scrollableView.addEventListener('scroll', function(e){
			if(e.source.views && (scrollableView.views.length > 1)){
				headerLabel.text = e.source.views[e.currentPage].name;
				curPage = e.currentPage;
   			switch(e.currentPage){
					case 0:
						setArrows(false, true);
						break;
					case scrollableView.views.length - 1:
						setArrows(true, false);
						break;
					default:
						setArrows(true, true);
						break;
				}
			}
		});
		mainView.add(scrollableView);
		
		function formScrollViewData(){
				if (group.HasSizes) {
					Ti.include('/revmobile/ui/sizesView.js');
					scrollViewData.push(sizesView);
				}
				else {
					setNoSizes();
				}
				
				if (group.HasStyles) {
					Ti.include('/revmobile/ui/stylesView.js');
					scrollViewData.push(stylesView);
				}
				
				if (itemSelected.HasPrefs) {
					Ti.include('/revmobile/ui/prefs.js');
				}
				
				if (itemSelected.HasReqMods) {
					Ti.include('/revmobile/ui/reqMods_new.js');
				}
				
				if (group.HasMods) {
					Ti.include('/revmobile/ui/mods_new.js');
				}
				
				if (scrollViewData.length == 0) {
					scrollViewData.push(noOptionView);
				}
				scrollableView.views = scrollViewData;
				switch (scrollViewData.length) {					
					case 0:
						setArrows(false, false);
						scrollViewData.push(noOptionView);
						scrollableView.views = scrollViewData;
						headerLabel.text = 'No Options.';
						break;
					case 1:
						setArrows(false, false);
						headerLabel.text = scrollViewData[0].name;
						break;
					default:
						setArrows(false, true);
						headerLabel.text = scrollViewData[0].name;
						break;
				}
				if (scrollViewData.length > 1) {
					setArrows(false, true);
					headerLabel.text = scrollViewData[0].name;
				}
			
		}
		InitializeItemObj();
		formScrollViewData();
		return mainView;
	}
	catch(ex){
		ro.ui.alert('itemDetails','CODE 100');
	}
};
}());