var NEWADDRESSVIEW = function(){
	var newaddressview = function(ro){
   
	   ro.ui.newAddressView = function(_args){
	   	  var defaultCustomer = {}, Id;
	      //var forms = require('/revmobile/ui/forms');
	      var forms = ro.forms;
	      //Ti.include('/formControls/addressForm.js');
	      var addressForm = require('formControls/addressForm');
	      var addrVal = require('validation/addressValidation');
	      var regexVal = require('validation/regexValidation');
	      var addrControl = require('controls/addrControl');
	      
	      defaultCustomer = ro.db.getCustObj(Ti.App.Username);
	      Id = defaultCustomer.AddressCol.length;
	
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:addressForm.getAddrForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:'newAddress'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      //var clearBtn = layoutHelper.getRightBtn('CLEAR');
	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      clearBtn.addEventListener('click', function(e){
	      	Ti.API.info('clearing fields'); 
	      	form.clearFields();
	      });
	
	      var btnBack = layoutHelper.getBackBtn('ADDRESS LIST');
	      btnBack.addEventListener('click', function(e){ 
	      	ro.GlobalPicker.hidePicker();
	      	ro.ui.settingsShowNext({showing:'newAddress'}); });
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
	
	      var btnUpdate = layoutHelper.getBigButton('Save');
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         ro.GlobalPicker.hidePicker();
	         //Ti.include('/validation/addressValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         var success = addrVal.addrValidate(values, defaultCustomer);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               formRequest(values);
	            }
	            else{
	               ro.ui.alert('Error', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Add Address"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Address Information", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      mainView.add(form);
	      
	      function formRequest(modifyAddrObj){
		      var req  = {};
		      var AddressObj = {};
		      try{
		         var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.zip + ', ' + modifyAddrObj.CountryCode;//', US';
		         
		         var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
		      	if(!cfg){
		      	   cfg = {};
		      	}
		      	var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
		         
				//Ti.include('/app.geo.js');
				var hrush = {
					geo:require('app.geo')
				};
				hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy/*storeObj.Configuration.AllowPCAccuracy*/);
				hrush.geo.geocode2(addr, function(addresses){
					Ti.API.debug('addresses: ' + JSON.stringify(addresses));
					if(!addresses || !addresses.data || !addresses.data.length){//}|| !addresses.data.StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
				      	ro.ui.hideLoader();
				      	var msg = 'Please check address';
				      	if(addresses && addresses.message){
				      		msg = addresses.message;
				      	}
				      	ro.ui.alert('Error: ', msg);
				      	return;
				    }
				    
				    function getReq(addrIdx){
				    	if(!addresses.data[addrIdx].StNumber || !addresses.data[addrIdx].StNumber.length){
			           	   //addresses.data[index].StNumber = addr.slice(0, addr.indexOf(' '));
			           	   ro.ui.hideLoader();
			           	   ro.ui.alert('Error: ', 'Street # is required');
			           	   return;
			            }
			            
			            //Ti.include('/controls/addrControl.js');
		                  req.UserName = Ti.App.Username;
		                  req.Pass = Ti.App.Password;
		                  req.RevKey = 'test';
								modifyAddrObj.stnum = addresses.data[addrIdx].StNumber;
								modifyAddrObj.stname = addresses.data[addrIdx].Street;
		
								if(addresses.data[addrIdx].City && addresses.data[addrIdx].City.length){
						      	modifyAddrObj.city = addresses.data[addrIdx].City;
						      }
		
						      if(addresses.data[addrIdx].State && addresses.data[addrIdx].State.length){
						      	modifyAddrObj.state = addresses.data[addrIdx].State;
						      }
		
						      if(addresses.data[addrIdx].Zip && addresses.data[addrIdx].Zip.length){
						      	modifyAddrObj.zip = addresses.data[addrIdx].Zip;
						      }
		
		                  AddressObj = addrControl.formAddrObj(modifyAddrObj);
		                  AddressObj.Lat = addresses.data[addrIdx].Lat;
		                  AddressObj.Lon = addresses.data[addrIdx].Lon;
		
		                  req.Address = AddressObj;
		                  contactServer(req);
		               		
		               	}
		               	var GEO = require('geo');
		           	if(addresses.data.length > 1){
		           		GEO.displayList(addresses.data, getReq);
		           	}
		           	else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
		           		GEO.displayList(addresses.data, getReq);
		           	}
		           	else{
		           		getReq(0);
		           	}
		           	
				}, true, GOOG_MAPS_KEY);
				return;
		      }
		      catch(ex){
		         ro.ui.alert('Error: ', ex);
		      }
		   };
	
	   	  function contactServer(req){
	
			  var response;
			  var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
			  if (savedTokenObj && savedTokenObj.token) {
			  		req.CustomerDevice = {};
			  		req.CustomerDevice.DeviceID = Ti.Platform.id;
			  		req.CustomerDevice.DeviceToken = savedTokenObj.token;
			  		req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
			  }
		      ro.dataservice.post(req, 'InsertCustomerAddress', function(response){
		         if(response){
		            if(response.Value){
		               req.Address.Id = response.Id;
		
		               if(!defaultCustomer.AddressCol){
		               	defaultCustomer.AddressCol = [];
		               }
		
		               defaultCustomer.AddressCol.push(req.Address);
		               ro.db.updateCustomerObj(Ti.App.Username, defaultCustomer);
		               ro.ui.settingsShowNext({showing:'newAddress', resetOrder:true});
		            }
		            else{
		            	ro.ui.hideLoader();
		            }
		            ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
		         }
		         else{
		         	ro.ui.hideLoader();
		         }
		      });
		   }
	      
	      return mainView;
	   };
	
	   
	};
	return {
		newaddressview:newaddressview
	};
}();
module.exports = NEWADDRESSVIEW;