var DRAWER = function(){
	var drawer = function(ro){
		ro.ui.showDrawer = null;
		ro.ui.hideDrawer = null;
		ro.ui.createDrawerView = function(_args){
			var drawerView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
			})),
			backdrop = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
				//backgroundImage:ro.ui.properties.defaultPath + 'background.png',
				backgroundColor:'#ffffff',
				opacity:1
			}));
			
			drawerView.add(backdrop);
			var loginView = null;
			
		   	ro.ui.showDrawer = function(e){
		   	   if(loginView === null){
		   	   	ro.ui.showLoader();
		   	   	loginView = ro.ui.createLoginView({orderComplete:e && e.orderComplete ? e.orderComplete : false});
		   	   	/*if(Ti.App.NewHungryHowiesLayout){
		   	   		loginView = ro.ui.createNewLoginView();
		   	   	}
		   	   	else{
		            	loginView = ro.ui.createLoginView();
		            }*/
		         }
		         backdrop.add(loginView);
		         drawerView.visible = true;
		         ro.ui.hideLoader();
		      };
		   	ro.ui.hideDrawer = function(e){
		   	   drawerView.visible=false;
		         backdrop.remove(loginView);
		         loginView = null;
		         //Ti.API.debug('hideDrawer');
		   	};
			return drawerView;
		};
	};
	return {
		drawer:drawer
	};
}();
module.exports = DRAWER;