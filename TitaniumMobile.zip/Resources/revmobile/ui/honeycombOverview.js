(function(){
   ro.ui.getHoneycombView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('honeycomb', 'HONEYCOMB', layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var loyaltiesView =  Ti.UI.createView({
         layout:'vertical',
         top:0,
         bottom:ro.ui.relY(110)
      });

      var currentCredit = '0.00';

      var currentCreditView = Ti.UI.createView({
         top:ro.ui.relY(25),
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL
      });
      var currentCreditViewLbl = Ti.UI.createLabel({
         text:('AVAILABLE CREDIT: ' + currentCredit.toString()),
         font:{
            fontSize:ro.ui.scaleFont(19),
            fontWeight:'bold',
            fontFamily:ro.ui.fontFamily
         },
         textAlign:'center',
         color:ro.ui.theme.lvlupCreditTxt
      });
      currentCreditView.add(currentCreditViewLbl);
      loyaltiesView.add(currentCreditView);

      var properties = [
         ro.combine(ro.ui.properties.lblStoreName, {
            title:' LOYALTY',
            hasChild:true,
            className:'settings',
            height:ro.ui.relY(40),
            showing:'loyaltiesLoyalty',
            leftImage:'/images/loyalty.png',
            rightImage:'/images/details.png'
         })/*,
         ro.combine(ro.ui.properties.lblStoreName, {
            title:' SEND GIFT CARD',
            hasChild:true,
            className:'settings',
            height:ro.ui.relY(40),
            showing:'loyaltiesGift',
            leftImage:'/images/giftcard.png',
            rightImage:'/images/details.png'
         }),
         ro.combine(ro.ui.properties.lblStoreName, {
            title:' TRANSACTION HISTORY',
            hasChild:true,
            className:'settings',
            height:ro.ui.relY(40),
            showing:'loyaltiesHistory',
            leftImage:'/images/rewards.png',
            rightImage:'/images/details.png'
         })*/
      ];
      var unlinkProperties = [
         ro.combine(ro.ui.properties.lblStoreName, {
            title:' UNLINK LOYALTY ACCOUNT',
            hasChild:true,
            className:'settings',
            height:ro.ui.relY(40),
            showing:'loyaltiesUnlink',
            leftImage:'/images/rewards.png',
            rightImage:'/images/details.png'
         })
      ];

      var loyaltiesTbl = Ti.UI.createTableView({
         data:properties,
         scrollable:false,
         separatorColor:ro.ui.theme.separatorColor,
         top:0,
         left:ro.ui.relX(10),
         right:ro.ui.relX(10),
         backgroundColor:'white',
         borderColor:ro.ui.theme.loginGray,
         borderWidth:ro.ui.relX(1),
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL
      });
      var tblHdrView = layoutMenuHelper.menuHeaders({text:'REWARDS SETTINGS'});
      tblHdrView.top = ro.ui.contentsTop*.75;

      loyaltiesTbl.addEventListener('click', function(e){
         try{
            if(!e.rowData.showing || !e.rowData.showing.length){
               return;
            }
            ro.ui.showLoader();
            ro.ui.settingsShowNext({addView:true, showing:e.rowData.showing});
         }
         catch(ex){
            ro.ui.alert('Loyalties', 'Code:100' + ex);
         }
      });

      try{
        /*var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
        levelUp.getCreditAmt(function(e){
            currentCreditViewLbl.text = 'AVAILABLE CREDIT: ' + (parseInt(e.total_amount,10)/100).toFixed(2).toString();
         });*/
         var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
         /*currentLoyalty.getCustomerDetails(Ti.App.Username, Ti.App.Password, function(response){
            //deb.ug(response, 'response');
         });*/
      }
      catch(ex){
         Ti.API.debug('getHoneycombView-Exception: ' + ex);
      }

      loyaltiesView.add(tblHdrView);
      loyaltiesView.add(loyaltiesTbl);

      var unlinkTbl = Ti.UI.createTableView({
         data:unlinkProperties,
         scrollable:false,
         separatorColor:ro.ui.theme.separatorColor,
         top:0,
         left:ro.ui.relX(10),
         right:ro.ui.relX(10),
         backgroundColor:'white',
         borderColor:ro.ui.theme.loginGray,
         borderWidth:ro.ui.relX(1),
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL
      });
      var tblHdrViewUnlink = layoutMenuHelper.menuHeaders({text:' UNLINK REWARDS'});
      tblHdrViewUnlink.top = ro.ui.contentsTop*.75;

      unlinkTbl.addEventListener('click', function(e){
         try{
            var conf = JSON.parse(Ti.App.Properties.getString('Config'));
            if(!conf){
               conf = {};
            }

            var companyName = conf.CompanyName ? conf.CompanyName : '';
            ro.ui.popup('WARNING: ', ['CANCEL', 'UNLINK MY ACCOUNT'], 'This will unlink your account from ' + companyName + ' rewards.', function(e){
               if(e.index === 1){
                  REV_CUSTOMER.changeEClubOptIn(2, false, function(){
                     ro.ui.settingsShowNext({showing:mainView.hid});
                  });
               }
            });
         }
         catch(ex){
            ro.ui.alert('Loyalties', 'Code:100' + ex);
         }
      });

      loyaltiesView.add(tblHdrViewUnlink);
      loyaltiesView.add(unlinkTbl);

      mainView.add(loyaltiesView);
      return mainView;
   };
})();