/*var STYLESVIEW = function(){
	var stylesview = function(ro){*/
		exports.getStylesView = function(group, itemSelected, moveNext){
			var view = Ti.UI.createView({
				//backgroundImage:'/images/invGrpBackground.png',
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				//borderColor:'brown',
				//borderWidth:1,
				layout:'vertical'
			});
			var hdrTxt = group.HasSizes ? 'Please Select Style and Size' : 'Please Select Style';
			var hdr = ro.layout.getGenericMenuHdrRowWithHeader(hdrTxt, true);
			hdr.top = 0;
                    hdr.bottom = 0;
                    hdr.height = Ti.UI.FILL;
            hdr.touchEnabled = false;
			var modRow = Ti.UI.createView({
                height:ro.ui.relY(40),
                //height:Ti.UI.SIZE,
                width:Ti.UI.FILL,
                isHeader:true,
                
                isShowing:true//,
                //backgroundImage:'/images/invGrpBackground.png'
            });
            var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
            greyBar.bottom = 0;
            
            modRow.add(hdr);
            modRow.add(greyBar);
			
			//hdrRow.backgroundColor = '#e4e4e4';
			view.add(modRow);
			//view.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));
			function testStyles(itemObj){
				var returnBool = true, alertString = '';
				if(!itemObj.Style){
					returnBool = false;
					//ro.ui.alert('Required: ', 'Please select style');
					alertString += 'Please select style.\n';
				}
		
				if(group.HasSizes){
					if(!itemObj.Size){
						returnBool = false;
						//ro.ui.alert('Required: ', 'Please select size');
						alertString += 'Please select size.';
					}
				}
				if(!returnBool){
					ro.ui.alert('Required: ', alertString);
				}
				return returnBool;
			}
			
			var prevIndex = -1;
			var rowIdxDefault = -1;
			//var styleData = [], styleTitle, prevIndex = -1;
				//var styleView, titleTxt, rowIdxDefault = -1;
				//var styData, styleTbl;
			
			var styleTbl = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				top:0,
				right:ro.isiOS ? 1 : null,
				left:ro.isiOS ? 1 : null,
				layout:'vertical',
				clicked:false
			});
			var lastClickTime = 0;
			/*clicked:false
			         var lastClickTime = 0;
			         if(styData.length === 1){
			            rowIdxDefault = 0;
			         }
			         if(rowIdxDefault >= 0){
			            styleTbl.curIndex = rowSelected(styData[rowIdxDefault], group.HasSizes);
			            styleTbl.clicked = true;
			         }*/
			
			
			styData = [];
	         var styRow;
	         var styLength = group.Styles.length, offset = 0;
	           var evenOddCtr = 0;
	         for(var i=0; i<styLength; i++){
	            if(group.HasSizes){
	               styRow = getNewStyleRow(group.Styles[i], i, (i-offset), getStySzs(group.Styles[i].Sizes));
	               if(!styRow){
                       offset++;
                       continue;
                    }
	               
	               if(evenOddCtr % 2){
                        styRow.backgroundColor = "#f6f6f6";
                    }
                    evenOddCtr++;
	               
	               if(!i){
	                   styRow.top = ro.ui.relY(3);
	               }
	               else if(i == styLength-1){
	                   styRow.bottom = ro.ui.relY(3);
	               }
	               /*styRow = Ti.UI.createView({height:ro.ui.relY(50),
	               	  left:ro.ui.relX(25),
	               	  width:Ti.UI.FILL
	               });*/
	               styRow.addEventListener('click', function(e){
			         	try{
			         		//Ti.API.info('')
			         		//Ti.API.info('styData: ' + styData.length);
			         		if(new Date().getTime() - lastClickTime < 350){
			         			Ti.API.debug('returning');
			         			return;
			         		}
			         		var thisClickTime = new Date();
			         		lastClickTime = thisClickTime.getTime();
			         		thisClickTime = null;
								//Ti.API.info('styleTbl.curIndex: ' + styleTbl.curIndex);
								if(ro.isiOS){
								    styleTbl.removeAllChildren();
								}
				            if(styleTbl.clicked){
				            	//Ti.API.info('styleTbl.curIndex: ' + JSON.stringify(styleTbl.curIndex));
				            	//Ti.API.info('styData[styleTbl.curIndex]: ' + JSON.stringify(styData[styleTbl.curIndex]));
				            	
				              if(rowDeselected(styData[styleTbl.curIndex], styData[e.source.index].clicked?true:false, group.HasSizes)){
				                  styleTbl.clicked = false;
				                  ro.itemObj.unsetStyles();
				                  if(group.HasSizes){
				                     ro.itemObj.unsetSizes();
				                  }
				                  if(ro.isiOS){
                                        styleTbl.add(styData);
                                    }
				                  
				                  return;
				               }
				               else{
				               	if(group.HasSizes){
				                     ro.itemObj.unsetSizes();
				                  }
				               }
				            }
				            
				            /*Ti.API.debug('rowSelected - group.HasSizes: ' + group.HasSizes);
				            Ti.API.debug('rowSelected - e.row.index: ' + e.row.index);*/
				            styleTbl.curIndex = rowSelected(styData[e.source.index], group.HasSizes);
				            styleTbl.clicked = true;
				            if(ro.isiOS){
				            	
                                styleTbl.add(styData);
                            }
				            //styleTbl.setData(e.section.rows);
				         }
				         catch(ex){
				         	Ti.API.debug('styleTbl-Exception: ' + ex);
				         }
			         });
	               	  
	               
	            }
	            else{
	               //styRow = layoutMenuHelper.getRow(group.Styles[i], i, (i-offset));
	            }
	            //Ti.API.debug('styRow: ' + JSON.stringify(styRow));
	            
	
	            styRow.height = ro.ui.relY(50);
	            if(styRow.onlineDefault){
	            	styRow.height = ro.ui.relY(100);
	               rowIdxDefault = i-offset;
	            }
	           //rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
	            styRow.name = group.Styles[i].Name;
	            
	            styRow.cpnName = group.Styles[i].Name;
	
	            styRow.styPrice = group.Styles[i].Sizes;
	
	            styData.push(styRow);
	            //styleTbl.add(styRow);
	         }
	         styleTbl.add(styData);
	         
			 if(styData.length === 1){
	            rowIdxDefault = 0;
	         }
	         if(rowIdxDefault >= 0){
	            styleTbl.curIndex = rowSelected(styData[rowIdxDefault], group.HasSizes);
	            styleTbl.clicked = true;
	         }
			
			view.testRequired = true;
	         view.itemTest = function(itemObj){
	         	return testStyles(itemObj);
	         };
	         view.add(styleTbl);
	         
	         function getNewStyleRow(rowDetail, id, rowid, rowChildDetail, preSelected, dontGrow){
				var fontWgt = 'normal';
				var rowText = 'Tap To Add';
				var rowHeight = ro.ui.relY(50);
				if(preSelected){
					fontWgt = 'bold';
					rowText = 'Tap To Remove';
					if(!dontGrow){
						rowHeight = ro.ui.relY(100);
					}
				}
			
				var szToUse = [];
				var preSzToUse = [];
				if(rowChildDetail){
					if(rowChildDetail.skipRow){
						return;
					}
					if(rowChildDetail.szs){
						preSzToUse = rowChildDetail.szs;
					}
					//var szToUse = [];
					//Ti.API.info('preSzToUse: ' + JSON.stringify(preSzToUse));
					var menuUtils = require('logic/menuUtils');
					for(var i=0, iMax=preSzToUse && preSzToUse.length ? preSzToUse.length : 0; i<iMax; i++){
					    if(!menuUtils.isSizeOutOfStock(group, itemSelected.Name, rowDetail.Name, preSzToUse[i].Name)){
					        szToUse.push(preSzToUse[i]);
					    }
					}
					if(preSzToUse && preSzToUse.length && (!szToUse || !szToUse.length)){
					    return;
					}
					//Ti.API.info('szToUse: ' + JSON.stringify(szToUse));
				}
				var rowHasSizes = true;
				if(!szToUse.length){
				   rowHasSizes = false;
				}
			
				var row = Ti.UI.createView({
					height:rowHeight,
					width:Ti.UI.FILL,
                    left:ro.ui.relX(10),
                    right:ro.ui.relX(10),
					borderRadius:ro.ui.relX(15),
					layout:'vertical',
					sizes:szToUse,
					clicked:preSelected?true:false,
					id:id,
					index:rowid,
					onlineDefault:rowDetail.OnlineDefault,
					rowHasSizes: rowHasSizes,
					backgroundColor:'white'
				});
				var rowView = Ti.UI.createView({
					height:ro.ui.relY(50),
					width:Ti.UI.FILL,
					layout:'horizontal',
					touchEnabled:false
				});
			
				var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
				labelOneTxt = labelOneTxt;
			
				var labelOne = Ti.UI.createLabel({
					height:ro.ui.relY(50),
					text:labelOneTxt,
					font:{
						//fontWeight:'bold',
						fontSize:ro.ui.scaleFont(14),
							fontFamily:ro.ui.fonts.rowBodyTxt
					},
					left:ro.ui.relX(5),
					color:'#393839',
					width:Ti.UI.SIZE,
					bubbleParent:true,
					touchEnabled:false
				});
				var labelTwo = Ti.UI.createLabel({
					height:ro.ui.relY(50),
					text:rowText,
					font:{
						//fontWeight:fontWgt,
						fontSize:ro.ui.scaleFont(11),
							fontFamily:ro.ui.fonts.rowBodyTxt
					},
					right:ro.ui.relX(10),
					color:ro.ui.theme.loginGray,
					textAlign:'right',
					width:Ti.UI.FILL,
					touchEnabled:false
				});
				rowView.add(Ti.UI.createView({
				   width:ro.ui.relX(35),
				   left:ro.ui.relX(10),
				   height:ro.ui.relY(35),
					touchEnabled:false
				}));
			   var checkView = Ti.UI.createView({
			      height:ro.ui.relY(35),
			      width:ro.ui.relX(35),
			      backgroundImage:preSelected ? '/images/selectedMinus.png' : '/images/unselectedPlus.png',
			      visible:true,
				  touchEnabled:false
			   });
			   row.checkView = checkView;
			   rowView.children[0].add(row.checkView);
			
				rowView.add(labelOne);
				rowView.add(labelTwo);
				row.add(rowView);
				return row;
			};
	         
	         function getStySzs(szCol){
			   var availableSz = itemSelected.AvailableSizes;
			   var finalSzs = [], skipBool = false;
			   var interimSizes = [];
			
			
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			
			   //tHESE CHANGES MAY HAVE BROKEN COUPON WALKTHROUGH?
			   //4CRBERKO@GMAIL.COM CHOOSE STORE 243 AKA 01530
			   //CHOOSE COUPON 15$ DEAL
			
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			
			   for(var i=0; i<szCol.length; i++){
			   	for(var j=0; j<group.Sizes.length||0; j++){
			   		//Ti.API.info('group.Sizes['+j+']: ' + JSON.stringify(group.Sizes[j]));
			   		//.replace(/ /g,'')
			   		if((szCol[i].Name === group.Sizes[j].Name) || (szCol[i].Name.replace(/ /g,'') === group.Sizes[j].Name.replace(/ /g,''))){
			   			interimSizes.push(szCol[i]);
			   			if(group.Sizes[j].DisplayName && group.Sizes[j].DisplayName.length){
			   				interimSizes[interimSizes.length-1].DisplayName = group.Sizes[j].DisplayName;
			   			}
			   			if(group.Sizes[j].OnlineDefault){
			   				interimSizes[interimSizes.length-1].OnlineDefault = true;
			   			}
			   			break;
			   		}
			   	}
			   }
			   
			   //.replace(/ /g,'')
				if(interimSizes && interimSizes.length){
					for(var i=0; i<interimSizes.length; i++){
						//Ti.API.info('interimSizes['+i+']: ' + JSON.stringify(interimSizes[i]));
						for(var j=0; j<availableSz.length; j++){
							if((interimSizes[i].Name === availableSz[j].Name) || (interimSizes[i].Name.replace(/ /g,'') === availableSz[j].Name.replace(/ /g,''))){
								finalSzs.push(availableSz[j]);
								if(interimSizes[i].DisplayName && interimSizes[i].DisplayName.length){
									finalSzs[finalSzs.length-1].DisplayName = interimSizes[i].DisplayName;
								}
								if(interimSizes[i].OnlineDefault){
									finalSzs[finalSzs.length-1].OnlineDefault = true;
								}
			         		break;
							}
						}
					}
				}
			   //Ti.API.debug('finalSzs: ' + JSON.stringify(finalSzs));
			   if(!finalSzs.length){
			      skipBool = true;
			   }
			   return {
			      skipRow:skipBool,
			      szs:finalSzs
			   };
			}
			function getButtonBlock(btns, btnAction, btnBlockCallback, styPrice, group){
				var btnBlock = null;
				if(!styPrice){
					styPrice = false;
				}
				try{
					if(!btns){
						return;
					}
					btnBlock = Ti.UI.createView({
						//width:Ti.UI.FILL,
						height: Ti.UI.SIZE,
						left:'0.5%',//ro.ui.relX(15),
						bottom: ro.ui.relY(5),
						right: '0.5%',//ro.ui.relX(10),
						layout:'horizontal',//'vertical',
						bubbleParent:'false',
						visible:true,
						toggle:function(sizeToToggle){
							for(var i=0, iMax=btnBlock.children.length; i<iMax; i++){
								//for(var j=0, jMax=btnBlock.children[i].children.length; j<jMax; j++){
									if(btnBlock.children[i].id === sizeToToggle){
										btnBlock.children[i].toggle(true);
										btnAction(sizeToToggle);
										
										if(group.HasStyles && group.Styles && group.Styles.length){
											ro.itemObj.setStyles(currentStyleRow);
										}
									}
									else{
										btnBlock.children[i].toggle(false);
									}
								//}
							}
						}
					});
			
					var getBtnBlockChildren = function(btnBlock, btns, currentStyleRow, group, allBtnLength){
						//Ti.API.debug('btnBlockRowIdx: ' + btnBlockRowIdx);
						/*var btnsRow = Ti.UI.createView({
							width:Ti.UI.SIZE,
							layout:'horizontal',
							height:Ti.UI.SIZE,//ro.ui.relY(65)
							horizontalWrap: true,
							left:ro.ui.relX(15)	
						});*/
						
						
						var aBtn, btnLbl, btnLbl2, clickedBool, clickedColor, btnPriceLblClr;
						var defBorderColor = "#e4e4e4";
						for(var i=0; i<btns.length; i++){
							defBorderColor = "#e4e4e4";
							clickedBool = false;
							clickedColor = 'white';
							btnLblClr = ro.ui.theme.sizeBtnBlockNameTxtDefault;
							btnPriceLblClr = ro.ui.theme.sizeBtnBlockPriceTxtDefault;
							
			
							if(btns[i].OnlineDefault || allBtnLength === 1){
								clickedBool = true;
								defBorderColor = ro.ui.theme.sizeBtnBlockBgActive;
								clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
								btnLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
								//btnPriceLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
			
								if(currentStyleRow !== false){
									btnAction(btns[i].Name);
									if(group.HasStyles && group.Styles && group.Styles.length){
										ro.itemObj.setStyles(currentStyleRow);
									}
								}
							}
							aBtn = Ti.UI.createView({
								//btnBlockRowIdx:btnBlockRowIdx,
								//width:ro.ui.relX(105),
								//left:ro.ui.relX(5),
								//height:ro.ui.relY(60),								
								width: '31%',//Ti.UI.SIZE,
                         		height: Ti.UI.SIZE,
								id:btns[i].Name,
								clicked:clickedBool,
								layout:'vertical',
								name:btns[i].ReceiptName || btns[i].Name,
								szName:btns[i].Name,
								idx:i,
								left: '1%',//ro.ui.relX(2),
                        			right: '1%',//ro.ui.relX(2),
                        			top: ro.ui.relX(2),
                        			bottom: ro.ui.relX(2)
							});
			
							var btnName = btns[i].DisplayName || btns[i].ReceiptName || btns[i].Name;
							if(btnName){
								//btnName = btnName.toUpperCase();
							}
			
							var btnLblView = Ti.UI.createView({
								backgroundColor:clickedColor,
								borderColor:defBorderColor,
								borderWidth:ro.ui.relX(2),
								height:ro.ui.relX(35),//Ti.UI.SIZE,//
								width:Ti.UI.FILL,//ro.ui.relX(100),
								borderRadius:ro.ui.relX(17.5),
								top:ro.ui.relY(3),
								touchEnabled:false
							});
							btnLbl = Ti.UI.createLabel({
							   height:Ti.UI.SIZE,
							   //width: Ti.UI.SIZE,
								text:btnName,
								wordWrap:false,
								maxLines:1,
								color:btnLblClr,
								font:{
									//fontWeight:'bold',
									fontSize:ro.ui.scaleFont(12),
                                    fontFamily:ro.ui.fonts.rowBodyTxt
								},
								textAlign:'center',
								touchEnabled:false,
								left: ro.ui.relX(12),
                        			right: ro.ui.relX(12)//,
                        			//top: ro.ui.relX(12),
                        			//bottom: ro.ui.relX(12)//,
								//top:ro.ui.relY(7)
							});
			
							btnLbl2 = Ti.UI.createLabel({
							   height:Ti.UI.SIZE,
							   width:Ti.UI.FILL,
							   top: ro.ui.relY(2),
							   bottom: ro.ui.relY(5),
							   text:styPrice?'$' + parseFloat(getSizePrice(btns[i]) + styPrice[i].Price).toFixed(2):'$' + parseFloat(getSizePrice(btns[i])).toFixed(2),
					         color:btnPriceLblClr,
					         font:{
					            //fontWeight:'bold',
					            fontSize:ro.ui.scaleFont(12),
									fontFamily:ro.ui.fonts.prices.italic
					         },
					         textAlign:'center',
					         touchEnabled:false					         
							});
							btnLblView.add(btnLbl);
							aBtn.add(btnLblView);
							aBtn.add(btnLbl2);
							aBtn.toggle = toggle;
							function toggle(shouldSelect){
								if(shouldSelect){
									this.clicked = true;
									this.children[0].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
									this.children[0].borderColor = ro.ui.theme.sizeBtnBlockBgActive;
									//this.children[0].borderColor = 'transparent';
									this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label1
								}
								else{
									this.clicked = false;
									this.children[0].backgroundColor = 'white';
									this.children[0].borderColor = '#e4e4e4';
									//this.children[0].borderColor = defBorderColor;
									this.children[0].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;//Label1
								}
							}
							aBtn.addEventListener('click', function(e){
								if(e.source.clicked){
									return;
								}
								e.source.parent.toggle(e.source.id);
								
								if(moveNext){
									moveNext();
								}
							});
							btnBlock.add(aBtn);
						}
						//btnBlock.add(btnsRow);
					};
					var btnsPerRow = 3;
					var rowBtns;
					var btnBlockHeight = 0;
					var btnBlockRow = 0;
					/*for(var i=0, iMax=btns.length; i<iMax; i+=btnsPerRow){
						btnBlockHeight += ro.ui.relY(65);
						rowBtns = btns.slice(i, i+btnsPerRow);
						//getBtnBlockChildren(btnBlock, rowBtns, currentStyleRow, group, btns.length);
					}*/
					getBtnBlockChildren(btnBlock, btns, currentStyleRow, group, btns.length);
					//btnBlock.height = btnBlockHeight;
					return btnBlock;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL){ Ti.API.debug('getButtonBlock()-Exception: ' + ex); }
					return btnBlock;
				}
			};
			function getSizePrice(sizesCol){
				var priceFound;
			
				function getNewTierPrices(TierSizeCol){
					for(var j=0; j<TierSizeCol.length; j++){
						if((sizesCol.Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)){
							return TierSizeCol[j].Price;
						}
					}
				}
			
				if(group.UseTieredPricing){
					switch(Ti.App.OrderObj.OrdTypePriceIdx){
						case 0:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT0Sizes);
							break;
						case 1:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT1Sizes);
							break;
						case 2:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT2Sizes);
							break;
					}
				}
				else{
					for(var j=0; j<itemSelected.AvailableSizes.length; j++){
						if(itemSelected.AvailableSizes[j].Name == sizesCol.Name){
							if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
								switch(Ti.App.OrderObj.OrdTypePriceIdx){
									case 1:
										if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
											priceFound = itemSelected.AvailableSizes[j].OrdTypePrice1;
										}
										break;
									case 2:
										if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
											priceFound = itemSelected.AvailableSizes[j].OrdTypePrice2;
										}
										break;
								}
							}
							else{
								priceFound = itemSelected.AvailableSizes[j].Price;
							}
							break;
						}
					}
				}
				return priceFound;
			}
			function rowSelected(row, szs, sizeToChoose){
			   try{
			   	var group = ro.app.group;
			   	if(row.clicked){
			   		Ti.API.debug('rowSelectedAlready: ' + JSON.stringify(row));
			   	}
			      row.clicked = true;
			
			      row.children[0].children[0].children[0].backgroundImage = '/images/selectedMinus.png';	//CheckView check.png image visibility changed to true
			      //row.children[0].children[0].children[0].show();
			
			      row.children[0].children[2].text = 'Tap To Remove';
			      //row.children[0].children[2].font.fontWeight = 'bold';
			      ro.itemObj.setStyles(row.id);
			      currentStyleRow = row.id;
			
			      if(szs){
			        // Ti.API.debug('shouldnt be here - Selected');
			         row.btnBlocks = null;
			         row.btnBlocks = getButtonBlock(row.sizes, ro.itemObj.setSizes, null, row.styPrice, group);
			         //Ti.API.info("button block height: "+row.btnBlocks.height);
			         if(sizeToChoose){
			         	row.btnBlocks.toggle(sizeToChoose);
			         }
			        // row.height = ro.ui.relY(50) + row.btnBlocks.height;
			         row.add(row.btnBlocks);
					 //Ti.API.info('row.btnBlocks.height: ' + row.btnBlocks.height);
			         row.height = Ti.UI.SIZE;
			         
			      }
			      /*Ti.API.debug('row: ' + JSON.stringify(row));
			      Ti.API.debug('row.index: ' + JSON.stringify(row.index));*/
			      return row.index;
			   }
			   catch(ex){
			      Ti.API.debug('rowSelected()-Exception: ' + ex);
			   }
			}
			function rowDeselected(row, clicked, szs){
			   try{
			      row.clicked = false;
				  row.height = ro.ui.relY(50);
			      row.children[0].children[0].children[0].backgroundImage = '/images/unselectedPlus.png';	//CheckView check.png image visibility changed to true
			     // row.children[0].children[0].children[0].hide();
			
			      row.children[0].children[2].text = 'Tap To Add';
			      //row.children[0].children[2].font.fontWeight = 'normal';
			
			      if(szs){
			         //Ti.API.debug('shouldnt be here - deselected');
			         if(row.children[1]){
			            row.remove(row.btnBlocks);
			            row.btnBlocks = null;
			         }
			         
			      }
			      /*Ti.API.debug('row: ' + JSON.stringify(row));
			      Ti.API.debug('row.index: ' + JSON.stringify(row.index));*/
			      return clicked?true:false;
			   }
			   catch(ex){
			      Ti.API.debug('rowDeselected()-Exception: ' + ex);
			   }
			}
	         
	         function reloadStyles(styleChosen, sizeChosen){
				if(styData.length == 1 && styData[0].clicked){
					styData[0].btnBlocks.toggle(sizeChosen);
				}
				else{
					
					if (styleTbl.clicked) {
						/*if(ro.isiOS){
						    styleTbl.removeAllChildren();
						}*/
						Ti.API.info('styleTbl.curIndex: ' + JSON.stringify(styleTbl.curIndex));
						Ti.API.info('styData[styleTbl.curIndex].clicked: ' + JSON.stringify(styData[styleTbl.curIndex].clicked));

						if (rowDeselected(styData[styleTbl.curIndex], true, group.HasSizes)) {
							styleTbl.clicked = false;
							ro.itemObj.unsetStyles();
							if (group.HasSizes) {
								ro.itemObj.unsetSizes();
							}
							/*if (ro.isiOS) {
								styleTbl.add(styData);
							}*/
						}
					}
					
					
					for(var i=0; i<styData.length; i++){
						if(styData[i].name === styleChosen){
							styleTbl.curIndex = rowSelected(styData[i], group.HasSizes, sizeChosen&&sizeChosen.length?sizeChosen:null);
				         	styleTbl.clicked = true;
				         	break;
						}
					}
					//styleTbl.setData(styData);
					/*styleTbl.removeAllChildren();
			         styData = newStyleData;
			         styleTbl.add(styData);*/
				}
			}
			function reloadSuggStyles(styleChosen, sizeChosen, group, itemSelected){
				var suggStyleData = [];
				var selectIdx;
				var shouldSelect = false;
			
				if((!styleChosen || !styleChosen.length || styleChosen.toLowerCase() == 'all') && (!sizeChosen || !sizeChosen.length || sizeChosen.toLowerCase() == 'all')){
					return;
				}
			
				for(var i=0; i<styData.length; i++){
					if(rowDeselected(styData[i], styData[i].clicked?true:false, group.HasSizes)){
						selectIdx = i;
			         styleTbl.clicked = false;
			         delete styleTbl.curIndex;
			         ro.itemObj.unsetStyles();
			         if(group.HasSizes){
			            ro.itemObj.unsetSizes();
			         }
			         break;
			      }
				}
			
			
			
				if(styleChosen.toLowerCase() == 'all'){
					for(var i=0; i<styData.length; i++){
						var thisStyleRow = styData[i];
						for(var j=0; j<thisStyleRow.sizes.length; j++){
							if((thisStyleRow.sizes[j].Name.toLowerCase() == sizeChosen.toLowerCase()) || (thisStyleRow.sizes[j].Name.replace(/ /g,'').toLowerCase() == sizeChosen.replace(/ /g,'').toLowerCase())){
								var theSize = [];
								theSize.push(thisStyleRow.sizes[j]);
								var theRow = thisStyleRow;
								theRow.sizes = null;
								theRow.sizes = theSize;
								suggStyleData.push(theRow);
			
								if(selectIdx == i){
				         		suggStyleData[suggStyleData.length-1].shouldSelect = true;
				         	}
			
								break;
							}
						}
					}
				}
				else{
					var newStyData = [];
					for(var i=0; i<styData.length; i++){
						var breakBool = false;
						//.replace(/ /g,'')
						if((styData[i].cpnName.toLowerCase() == styleChosen.toLowerCase()) || (styData[i].cpnName.replace(/ /g,'').toLowerCase() == styleChosen.replace(/ /g,'').toLowerCase())){ //styData[i].cpnName is the group.Style[idx].Name
							newStyData.push(styData[i]);
							if(sizeChosen.toLowerCase() == 'all'){
								suggStyleData = newStyData;
								suggStyleData[0].shouldSelect = true;
								break;
							}
							else{
								for(var j=0; j<newStyData[0].sizes.length; j++){
									//.replace(/ /g,'')
									if((newStyData[0].sizes[j].Name.toLowerCase() == sizeChosen.toLowerCase()) || (newStyData[0].sizes[j].Name.replace(/ /g,'').toLowerCase() == sizeChosen.replace(/ /g,'').toLowerCase())){
										var theSize = [];
										theSize.push(newStyData[0].sizes[j]);
										newStyData[0].sizes = null;
										newStyData[0].sizes = theSize;
										suggStyleData = newStyData;
										breakBool = true;
										suggStyleData[0].shouldSelect = true;
										break;
									}
								}
							}
						}
						if(breakBool){
							break;
						}
					}
				}
			
				for(var i=0; i<suggStyleData.length; i++){
					suggStyleData[i].index = i;
					if(suggStyleData[i].shouldSelect){
						styleTbl.curIndex = rowSelected(suggStyleData[i], group.HasSizes);
			         styleTbl.clicked = true;
					}
				}
			
				styleTbl.setData(suggStyleData);
			}
			function editStyles(isChosenStyle, isChosenSz, isPick){
				try{
				  Ti.API.info("edit Styles: isChosenStyle: " + JSON.stringify(isChosenStyle));
				  Ti.API.info("edit Styles: isChosenSz: " + JSON.stringify(isChosenSz));	
				   var styleCol = isPick&&isPick==true ? (modifyStyle(true) || []) : (modifyStyle(false) || []);
					Ti.API.info(1);
			      var styleLen = styleCol.length;
			      var newStyleData = [];
			      //Ti.API.info('styleLen: ' + styleLen);
				  //Ti.API.debug('styleCol: ' + JSON.stringify(styleCol));
			      /*if(styleTbl.clicked){
			
				   }
				   else{
				   	Ti.API.debug('not clicked');
				   }*/
			
			
			      for(i=0; i<styData.length; i++){
			      	for(j=0; j<styleCol.length; j++){
				         if(styleLen !== 0 && ((styData[i].name === styleCol[j].Name) || (styData[i].name === styleCol[j].ReceiptName) || (styData[i].cpnName == styleCol[j].Name))){
				         	//Ti.API.info('FOUND MATCH - with styleLen - styData['+i+'] ' + JSON.stringify(styData[i]));
				         	newStyleData.push(styData[i]);
				         	newStyleData[newStyleData.length-1].index = newStyleData.length-1;
				         	newStyleData[newStyleData.length-1].backgroundColor = ((newStyleData.length-1) % 2) ? "#f6f6f6" : "white";
			
				         	if(styleTbl.curIndex == i){
				         		styleTbl.curIndex = newStyleData.length-1;
				         	}
				         }
				         
				      }
						//Ti.API.info('SHOULDNT BE HERE YET');
			         if(!styleLen){
			            for(j=0; j<styData[i].sizes.length; j++){
								var breakBool = false;
			            	if(isPick){
			            		for(k=0; k<isChosenSz.length; k++){
			            			if(styData[i].sizes[j].Name === isChosenSz[k]){
			            			  //  Ti.API.info('FOUND MATCH - without styleLen and WITH ispick - styData['+i+'] ' + JSON.stringify(styData[i]));
			            			    
						               newStyleData.push(styData[i]);
						               newStyleData[newStyleData.length-1].index = newStyleData.length-1;
						               newStyleData[newStyleData.length-1].backgroundColor = (newStyleData.length-1) % 2 ? "#f6f6f6" : "white";
						               breakBool = true;
						               break;
						            }
			            		}
			            		if(breakBool){
			            			breakBool = false;
			            			break;
			            		}
			            	}
			            	else{
					            if(styData[i].sizes[j].Name === isChosenSz){
					              //  Ti.API.info('FOUND MATCH - without styleLen && without isPick - styData['+i+'] ' + JSON.stringify(styData[i]));
					               newStyleData.push(styData[i]);
					               newStyleData[newStyleData.length-1].index = newStyleData.length-1;
					               newStyleData[newStyleData.length-1].backgroundColor = (newStyleData.length-1) % 2 ? "#f6f6f6" : "white";
					               var newSzs = [];
					               newSzs[0] = styData[i].sizes[j];
					               newStyleData[newStyleData.length-1].sizes = newSzs;
					               break;
					            }
					         }
			            }
			         }
			      }
			      if(newStyleData && newStyleData.length > 0){
						var shouldSelect = false;
						var selectIdx = -1;
						if(typeof isChosenSz == 'string'){
							var holder = isChosenSz;
							isChosenSz = [];
							isChosenSz.push(holder);
						}
			      	for(i=0; i<newStyleData.length; i++){
			      		if(rowDeselected(newStyleData[i], newStyleData[i].clicked?true:false, group.HasSizes)){
			      			shouldSelect = true;
			      			selectIdx = i;
			               styleTbl.clicked = false;
			               ro.itemObj.unsetStyles();
			               if(group.HasSizes){
			                  ro.itemObj.unsetSizes();
			               }
			            }
			      		var newSzsArr = [];
			      		var didFind = false;			      		
			      		for(h=0; h<newStyleData[i].sizes.length; h++){
			      			for(k=0; k<isChosenSz.length; k++){
				      			if(newStyleData[i].sizes[h].Name === isChosenSz[k]){
				      				newSzsArr.push(newStyleData[i].sizes[h]);
				      				didFind = true;
				      				break;
				      			}
				      		}
				      	}
				      	if(didFind){
				      		newStyleData[i].sizes = newSzsArr;
				      	}
				      }
					
			         if(shouldSelect && selectIdx != -1){
			         	styleTbl.curIndex = rowSelected(newStyleData[selectIdx], group.HasSizes);
			         	styleTbl.clicked = true;
			         }else{
			         	if(newStyleData.length === 1){
			            	newStyleData[0].index = 0;
			            	styleTbl.curIndex = rowSelected(newStyleData[0], group.HasSizes);
			            	styleTbl.clicked = true;
			         		}
			         	else{
			            	for(j=0; j<newStyleData.length; j++){
			            		Ti.API.info(5);
			               	if(newStyleData[j].cpnName === isChosenStyle){
			                  styleTbl.curIndex = rowSelected(newStyleData[j], group.HasSizes);
			                  styleTbl.clicked = true;
			               }
			               newStyleData[j].index = j;
			            }
			         }
			         }   
			         
					
			         //styleTbl.setData(newStyleData);
			         
			         /*if(ro.isiOS){
			         	view.remove(styleTbl);
			         }*/
			         //Ti.API.info();
			         
			         //styData = null;
			         //styData = newStyleData;
			         //var test =  styData;
			         //test = newStyleData;
			         //styData = test;
			         //test = null;
			         //Ti.API.info('newStyleData: ' + JSON.stringify(newStyleData));
			         if(newStyleData && newStyleData.length){
			         	//Ti.API.info('newStyleData.length: ' + newStyleData.length);
			         }
			        // Ti.API.info('view.children.length: ' + view.children.length);
			         styData = newStyleData;
			         styleTbl.removeAllChildren();
			         styleTbl.add(styData);
			         /*if(ro.isiOS){
			         	view.replaceAt({
			         		view: styleTbl,
			         		position:styleTbl
			         	});
			         }*/
			      }
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('editStyles()-Exception: ' + ex); }
				}
			}
			function modifyStyle(isPickany){
				try{
					if(isPickany){
						var changeGrp = ro.cpnHelper.cpnSpecs('MenuStyles', group.Styles);
						if(changeGrp !== -1){
							var grpStyle = [];
							for(var i=0; i<changeGrp.length; i++){
							   grpStyle.push(group.Styles[changeGrp[i]]);
							}
							return grpStyle;
						}
						else{
							return [];
						}
					}
			
					var changeGrp = ro.cpnHelper.cpnSpecs('MenuStyle', group.Styles);
					if(changeGrp !== -1){
						var grpStyle = [];
						grpStyle.push(group.Styles[changeGrp]);
						return grpStyle;
					}
					else{
						return [];
					}
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('stylesView.js-modifyStyle()-Exception: ' + ex); }
				}
			}
	         
	         view.reloadCpnSelections = editStyles;
			 view.reloadSelections = reloadStyles;
			 view.reloadSuggs = reloadSuggStyles;
	         
			return view;
		};
		exports.oldgetStylesView = function(group, itemSelected){
			try {
				
				//var ITEMOBJ = require('logic/itemObj');
				
				function testStyles(itemObj){
					var returnBool = true, alertString = '';
					if(!itemObj.Style){
						returnBool = false;
						//ro.ui.alert('Required: ', 'Please select style');
						alertString += 'Please select style.\n';
					}
			
					if(group.HasSizes){
						if(!itemObj.Size){
							returnBool = false;
							//ro.ui.alert('Required: ', 'Please select size');
							alertString += 'Please select size.';
						}
					}
					if(!returnBool){
						ro.ui.alert('Required: ', alertString);
					}
					return returnBool;
				}
				var styleData = [], styleTitle, prevIndex = -1;
				var styleView, titleTxt, rowIdxDefault = -1;
				var styData, styleTbl;
				titleTxt = 'Please select a Style:';
			
			    if(group.HasSizes){
			       titleTxt = 'Please select a style and size:';
			       //Ti.include('/revmobile/ui/sizesView.js');
			    }
			
			      styleView = setItemDisplay({text:titleTxt});
			      
			      var a = function(ex){
			         //styleView = ex;
			         styleView.testRequired = true;
			         styleView.itemTest = function(itemObj){
			         	return testStyles(itemObj);
			         };
			         styData = [];
			         var styRow;
			         var styLength = group.Styles.length, offset = 0;
			
			         for(var i=0; i<styLength; i++){
			            if(group.HasSizes){
			               styRow = layoutMenuHelper.getRow(group.Styles[i], i, (i-offset), getStySzs(group.Styles[i].Sizes));
			            }
			            else{
			               styRow = layoutMenuHelper.getRow(group.Styles[i], i, (i-offset));
			            }
			            //Ti.API.debug('styRow: ' + JSON.stringify(styRow));
			            if(!styRow){
			               offset++;
			               continue;
			            }
			
			            styRow.height = ro.ui.relY(50);
			            if(styRow.onlineDefault){
			            	styRow.height = ro.ui.relY(100);
			               rowIdxDefault = i-offset;
			            }
			
			            styRow.name = group.Styles[i].ReceiptName;
			            styRow.cpnName = group.Styles[i].Name;
			
			            styRow.styPrice = group.Styles[i].Sizes;
			
			            styData.push(styRow);
			         }
			         styleTbl = Ti.UI.createTableView({
			            height:Ti.UI.SIZE,
			            width:Ti.UI.FILL,
			            data:styData,
			            separatorColor:ro.ui.theme.separatorColor,
			            borderColor:ro.ui.theme.separatorColor,
			            borderWidth:ro.ui.relX(1),
			            backgroundColor:ro.ui.theme.tableBgColor,
			            clicked:false
			         });
			         var lastClickTime = 0;
			         styleTbl.addEventListener('click', function(e){
			         	try{
			         		if(new Date().getTime() - lastClickTime < 350){
			         			Ti.API.debug('returning');
			         			return;
			         		}
			         		var thisClickTime = new Date();
			         		lastClickTime = thisClickTime.getTime();
			         		thisClickTime = null;
			
				            if(styleTbl.clicked){
				               /*Ti.API.debug('rowDeselected - group.HasSizes: ' + group.HasSizes);
			                  Ti.API.debug('rowDeselected - e.row.clicked: ' + e.row.clicked);
			                  Ti.API.debug('rowDeselected - e.section.rows[styleTbl.curIndex].index: ' + e.section.rows[styleTbl.curIndex].index);*/
				               if(rowDeselected(e.section.rows[styleTbl.curIndex], e.row.clicked?true:false, group.HasSizes)){
				                  styleTbl.clicked = false;
				                  ro.itemObj.unsetStyles();
				                  if(group.HasSizes){
				                     ro.itemObj.unsetSizes();
				                  }
				                  return;
				               }
				               else{
				               	if(group.HasSizes){
				                     ro.itemObj.unsetSizes();
				                  }
				               }
				            }
				            /*Ti.API.debug('rowSelected - group.HasSizes: ' + group.HasSizes);
				            Ti.API.debug('rowSelected - e.row.index: ' + e.row.index);*/
				            styleTbl.curIndex = rowSelected(e.row, group.HasSizes);
				            styleTbl.clicked = true;
				            
				            styleTbl.setData(e.section.rows);
				         }
				         catch(ex){
				         	Ti.API.debug('styleTbl-Exception: ' + ex);
				         }
			         });
			
			         if(styData.length === 1){
			            rowIdxDefault = 0;
			         }
			         if(rowIdxDefault >= 0){
			            styleTbl.curIndex = rowSelected(styData[rowIdxDefault], group.HasSizes);
			            styleTbl.clicked = true;
			         }
			         styleView.add(styleTbl);
			         
			         //return styleView;
			      };
			      
			      a();
			      styleView.reloadCpnSelections = editStyles;
			      styleView.reloadSelections = reloadStyles;
			      styleView.reloadSuggs = reloadSuggStyles;
			}
			catch(ex){
			   Ti.API.debug('stylesview.js()-Exception: ' + ex);
				ro.ui.alert('styles','CODE 100');
			}
			function reloadStyles(styleChosen, sizeChosen){
				if(styData.length == 1 && styData[0].clicked){
					styData[0].btnBlocks.toggle(sizeChosen);
				}
				else{
					for(var i=0; i<styData.length; i++){
						if(styData[i].name === styleChosen){
							styleTbl.curIndex = rowSelected(styData[i], group.HasSizes, sizeChosen&&sizeChosen.length?sizeChosen:null);
				         styleTbl.clicked = true;
				         break;
						}
					}
					styleTbl.setData(styData);
				}
			}
			function reloadSuggStyles(styleChosen, sizeChosen, group, itemSelected){
				var suggStyleData = [];
				var selectIdx;
				var shouldSelect = false;
			
				if((!styleChosen || !styleChosen.length || styleChosen.toLowerCase() == 'all') && (!sizeChosen || !sizeChosen.length || sizeChosen.toLowerCase() == 'all')){
					return;
				}
			
				for(var i=0; i<styData.length; i++){
					if(rowDeselected(styData[i], styData[i].clicked?true:false, group.HasSizes)){
						selectIdx = i;
			         styleTbl.clicked = false;
			         delete styleTbl.curIndex;
			         ro.itemObj.unsetStyles();
			         if(group.HasSizes){
			            ro.itemObj.unsetSizes();
			         }
			         break;
			      }
				}
			
			
			
				if(styleChosen.toLowerCase() == 'all'){
					for(var i=0; i<styData.length; i++){
						var thisStyleRow = styData[i];
						for(var j=0; j<thisStyleRow.sizes.length; j++){
							if((thisStyleRow.sizes[j].Name.toLowerCase() == sizeChosen.toLowerCase()) || (thisStyleRow.sizes[j].Name.replace(/ /g,'').toLowerCase() == sizeChosen.replace(/ /g,'').toLowerCase())){
								var theSize = [];
								theSize.push(thisStyleRow.sizes[j]);
								var theRow = thisStyleRow;
								theRow.sizes = null;
								theRow.sizes = theSize;
								suggStyleData.push(theRow);
			
								if(selectIdx == i){
				         		suggStyleData[suggStyleData.length-1].shouldSelect = true;
				         	}
			
								break;
							}
						}
					}
				}
				else{
					var newStyData = [];
					for(var i=0; i<styData.length; i++){
						var breakBool = false;
						//.replace(/ /g,'')
						if((styData[i].cpnName.toLowerCase() == styleChosen.toLowerCase()) || (styData[i].cpnName.replace(/ /g,'').toLowerCase() == styleChosen.replace(/ /g,'').toLowerCase())){ //styData[i].cpnName is the group.Style[idx].Name
							newStyData.push(styData[i]);
							if(sizeChosen.toLowerCase() == 'all'){
								suggStyleData = newStyData;
								suggStyleData[0].shouldSelect = true;
								break;
							}
							else{
								for(var j=0; j<newStyData[0].sizes.length; j++){
									//.replace(/ /g,'')
									if((newStyData[0].sizes[j].Name.toLowerCase() == sizeChosen.toLowerCase()) || (newStyData[0].sizes[j].Name.replace(/ /g,'').toLowerCase() == sizeChosen.replace(/ /g,'').toLowerCase())){
										var theSize = [];
										theSize.push(newStyData[0].sizes[j]);
										newStyData[0].sizes = null;
										newStyData[0].sizes = theSize;
										suggStyleData = newStyData;
										breakBool = true;
										suggStyleData[0].shouldSelect = true;
										break;
									}
								}
							}
						}
						if(breakBool){
							break;
						}
					}
				}
			
				for(var i=0; i<suggStyleData.length; i++){
					suggStyleData[i].index = i;
					if(suggStyleData[i].shouldSelect){
						styleTbl.curIndex = rowSelected(suggStyleData[i], group.HasSizes);
			         styleTbl.clicked = true;
					}
				}
			
				styleTbl.setData(suggStyleData);
			}
			function editStyles(isChosenStyle, isChosenSz, isPick){
				try{
				   var styleCol = isPick&&isPick==true ? (modifyStyle(true) || []) : (modifyStyle(false) || []);
			
			      var styleLen = styleCol.length;
			      var newStyleData = [];
			
			      if(styleTbl.clicked){
			
				   }
				   else{
				   	Ti.API.debug('not clicked');
				   }
			
			
			      for(var i=0; i<styData.length; i++){
			      	for(var j=0; j<styleCol.length; j++){
				         if(styleLen !== 0 && ((styData[i].name === styleCol[j].Name) || (styData[i].name === styleCol[j].ReceiptName))){
				         	newStyleData.push(styData[i]);
			
				         	if(styleTbl.curIndex == i){
				         		styleTbl.curIndex = newStyleData.length-1;
				         	}
				         }
				      }
			
			         if(!styleLen){
			            for(var j=0; j<styData[i].sizes.length; j++){
								var breakBool = false;
			            	if(isPick){
			            		for(var k=0; k<isChosenSz.length; k++){
			            			if(styData[i].sizes[j].Name === isChosenSz[k]){
						               newStyleData.push(styData[i]);
						               breakBool = true;
						               break;
						            }
			            		}
			            		if(breakBool){
			            			breakBool = false;
			            			break;
			            		}
			            	}
			            	else{
					            if(styData[i].sizes[j].Name === isChosenSz){
					               newStyleData.push(styData[i]);
					               var newSzs = [];
					               newSzs[0] = styData[i].sizes[j];
					               newStyleData[newStyleData.length-1].sizes = newSzs;
					               break;
					            }
					         }
			            }
			         }
			      }
			      if(newStyleData && newStyleData.length > 0){
						var shouldSelect = false;
						var selectIdx = -1;
						if(typeof isChosenSz == 'string'){
							var holder = isChosenSz;
							isChosenSz = [];
							isChosenSz.push(holder);
						}
			      	for(var i=0; i<newStyleData.length; i++){
			      		if(rowDeselected(newStyleData[i], newStyleData[i].clicked?true:false, group.HasSizes)){
			      			shouldSelect = true;
			      			selectIdx = i;
			               styleTbl.clicked = false;
			               ro.itemObj.unsetStyles();
			               if(group.HasSizes){
			                  ro.itemObj.unsetSizes();
			               }
			            }
			      		var newSzsArr = [];
			      		var didFind = false;
			      		for(var h=0; h<newStyleData[i].sizes.length; h++){
			      			for(var k=0; k<isChosenSz.length; k++){
				      			if(newStyleData[i].sizes[h].Name === isChosenSz[k]){
				      				newSzsArr.push(newStyleData[i].sizes[h]);
				      				didFind = true;
				      				break;
				      			}
				      		}
				      	}
				      	if(didFind){
				      		newStyleData[i].sizes = newSzsArr;
				      	}
				      }
			
			         if(newStyleData.length === 1){
			            newStyleData[0].index = 0;
			            styleTbl.curIndex = rowSelected(newStyleData[0], group.HasSizes);
			            styleTbl.clicked = true;
			         }
			         else{
			            for(var j=0; j<newStyleData.length; j++){
			               if(newStyleData[j].cpnName === isChosenStyle){
			                  styleTbl.curIndex = rowSelected(newStyleData[j], group.HasSizes);
			                  styleTbl.clicked = true;
			               }
			               newStyleData[j].index = j;
			            }
			         }
			
			         if(shouldSelect && selectIdx != -1){
			         	styleTbl.curIndex = rowSelected(newStyleData[selectIdx], group.HasSizes);
			         	styleTbl.clicked = true;
			         }
			         styleTbl.setData(newStyleData);
			      }
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('editStyles()-Exception: ' + ex); }
				}
			}
			function modifyStyle(isPickany){
				try{
					if(isPickany){
						var changeGrp = ro.cpnHelper.cpnSpecs('MenuStyles', group.Styles);
						if(changeGrp !== -1){
							var grpStyle = [];
							for(var i=0; i<changeGrp.length; i++){
							   grpStyle.push(group.Styles[changeGrp[i]]);
							}
							return grpStyle;
						}
						else{
							return [];
						}
					}
			
					var changeGrp = ro.cpnHelper.cpnSpecs('MenuStyle', group.Styles);
					if(changeGrp !== -1){
						var grpStyle = [];
						grpStyle.push(group.Styles[changeGrp]);
						return grpStyle;
					}
					else{
						return [];
					}
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('stylesView.js-modifyStyle()-Exception: ' + ex); }
				}
			}
			function rowSelected(row, szs, sizeToChoose){
			   try{
			   	Ti.API.info("RowSelected Called 2");
			   	var group = ro.app.group;
			   	if(row.clicked){
			   		Ti.API.debug('rowSelectedAlready: ' + JSON.stringify(row));
			   	}
			      row.clicked = true;
			
			      row.children[0].children[0].children[0].visible = true;	//CheckView check.png image visibility changed to true
			      row.children[0].children[0].children[0].show();
			
			      row.children[0].children[2].text = 'Tap To Remove';
			      row.children[0].children[2].font.fontWeight = 'bold';
			      ro.itemObj.setStyles(row.id);
			      currentStyleRow = row.id;
			
			      if(szs){
			        // Ti.API.debug('shouldnt be here - Selected');
			         row.btnBlocks = null;
			         row.btnBlocks = getButtonBlock(row.sizes, ro.itemObj.setSizes, null, row.styPrice, group);
			         if(sizeToChoose){
			         	row.btnBlocks.toggle(sizeToChoose);
			         }
			         row.add(row.btnBlocks);
			
			         row.height = ro.ui.relY(110);
			      }
			      /*Ti.API.debug('row: ' + JSON.stringify(row));
			      Ti.API.debug('row.index: ' + JSON.stringify(row.index));*/
			      return row.index;
			   }
			   catch(ex){
			      Ti.API.debug('rowSelected()-Exception: ' + ex);
			   }
			}
			function rowDeselected(row, clicked, szs){
			   try{
			      row.clicked = false;
			
			      row.children[0].children[0].children[0].visible = false;	//CheckView check.png image visibility changed to true
			      row.children[0].children[0].children[0].hide();
			
			      row.children[0].children[2].text = 'Tap To Add';
			      row.children[0].children[2].font.fontWeight = 'normal';
			
			      if(szs){
			         //Ti.API.debug('shouldnt be here - deselected');
			         if(row.children[1]){
			            row.remove(row.btnBlocks);
			            row.btnBlocks = null;
			         }
			         row.height = ro.ui.relY(50);
			      }
			      /*Ti.API.debug('row: ' + JSON.stringify(row));
			      Ti.API.debug('row.index: ' + JSON.stringify(row.index));*/
			      return clicked?true:false;
			   }
			   catch(ex){
			      Ti.API.debug('rowDeselected()-Exception: ' + ex);
			   }
			}
			function setItemDisplay(e, thisCallback){
			   try{
				   	var view = Ti.UI.createView({
				      height:Ti.UI.SIZE,
				      width:Ti.UI.FILL,
				      left:0,
				      right:0,
				      top:ro.ui.relY(5),
				      layout:'vertical'
				   });
				   var itmName = itemSelected.DisplayName || itemSelected.ReceiptName || itemSelected.Name;
				   var hdrTxt = !e.text?'Customize ' + itmName:e.text;
				   hdrTxt = hdrTxt.toUpperCase();
				   var hdrView = Ti.UI.createView({
				      width:Ti.UI.FILL,
				      height:ro.ui.relY(35),
				      backgroundColor:ro.ui.theme.headerBackgroundColor,
				      borderColor:ro.ui.theme.headerBorderColor
				   });
				   var hdrLbl = Ti.UI.createLabel({
				      text:hdrTxt,
				      color:'white',
				      font:{
				         fontSize:ro.ui.scaleFont(15),
				         fontWeight:'bold',
								fontFamily:ro.ui.fontFamily
				      },
				      textAlign:'left',
				      left:ro.ui.relX(5)
				   });
				   hdrView.add(hdrLbl);
				   view.add(hdrView);
			
				   if(e.text === null){
				      var displayImgView = Ti.UI.createView({
				         layout:'vertical',
				         height:Ti.UI.SIZE,
				         width:Ti.UI.FILL,
				         left:0
				      });
				      var imagePath = ro.ui.properties.defaultPath + 'default.png';
				      var imgVw = Ti.UI.createImageView({
				         image:itemSelected.ImageSource,
				         defaultImage:imagePath,
				         top:ro.ui.relY(5),
				         left:ro.ui.relX(5),
				         width:ro.ui.relX(80),
				         height:ro.ui.relY(80)
				      });
				      var itemDesLbl = Ti.UI.createLabel({
				         text:'Create your own Pizza! Start with cheese and add the toppings of your choice!',
				         font:{
				            fontSize:ro.ui.scaleFont(12),
				            fontWeight:'bold',
								fontFamily:ro.ui.fontFamily
				         },
				         color:'black'
				      });
				      displayImgView.add(imgVw);
				      displayImgView.add(itemDesLbl);
				      view.add(displayImgView);
				      return view;
				   }
				   else{
				      //thisCallback(view);
				      return view;
				   }
				}
				catch(ex){
					Ti.API.debug('setItemDisplay()-Exception: ' + ex);
				}
			}
			function getStySzs(szCol){
			   var availableSz = itemSelected.AvailableSizes;
			   var finalSzs = [], skipBool = false;
			   var interimSizes = [];
			
			
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			
			   //tHESE CHANGES MAY HAVE BROKEN COUPON WALKTHROUGH?
			   //4CRBERKO@GMAIL.COM CHOOSE STORE 243 AKA 01530
			   //CHOOSE COUPON 15$ DEAL
			
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			   //LOOK INTO THESE CHANGES TOMORROW 3.11.15
			
			   for(var i=0; i<szCol.length; i++){
			   	for(var j=0; j<group.Sizes.length||0; j++){
			   		//Ti.API.info('group.Sizes['+j+']: ' + JSON.stringify(group.Sizes[j]));
			   		//.replace(/ /g,'')
			   		if((szCol[i].Name === group.Sizes[j].Name) || (szCol[i].Name.replace(/ /g,'') === group.Sizes[j].Name.replace(/ /g,''))){
			   			interimSizes.push(szCol[i]);
			   			if(group.Sizes[j].DisplayName && group.Sizes[j].DisplayName.length){
			   				interimSizes[interimSizes.length-1].DisplayName = group.Sizes[j].DisplayName;
			   			}
			   			if(group.Sizes[j].OnlineDefault){
			   				interimSizes[interimSizes.length-1].OnlineDefault = true;
			   			}
			   			break;
			   		}
			   	}
			   }
			   
			   //.replace(/ /g,'')
				if(interimSizes && interimSizes.length){
					for(var i=0; i<interimSizes.length; i++){
						//Ti.API.info('interimSizes['+i+']: ' + JSON.stringify(interimSizes[i]));
						for(var j=0; j<availableSz.length; j++){
							if((interimSizes[i].Name === availableSz[j].Name) || (interimSizes[i].Name.replace(/ /g,'') === availableSz[j].Name.replace(/ /g,''))){
								finalSzs.push(availableSz[j]);
								if(interimSizes[i].DisplayName && interimSizes[i].DisplayName.length){
									finalSzs[finalSzs.length-1].DisplayName = interimSizes[i].DisplayName;
								}
								if(interimSizes[i].OnlineDefault){
									finalSzs[finalSzs.length-1].OnlineDefault = true;
								}
			         		break;
							}
						}
					}
				}
			   //Ti.API.debug('finalSzs: ' + JSON.stringify(finalSzs));
			   if(!finalSzs.length){
			      skipBool = true;
			   }
			   return {
			      skipRow:skipBool,
			      szs:finalSzs
			   };
			}
			function getButtonBlock(btns, btnAction, btnBlockCallback, styPrice, group){
				var btnBlock = null;
				if(!styPrice){
					styPrice = false;
				}
				try{
					if(!btns){
						return;
					}
					btnBlock = Ti.UI.createView({
						height:ro.ui.relY(55),
						width:Ti.UI.SIZE,
						left:ro.ui.relX(10),
						bottom:ro.ui.relY(10),
						borderColor:ro.ui.theme.btnBorderDefault,
						borderWidth:ro.ui.relX(1),
						layout:'horizontal',
						bubbleParent:'false',
						visible:true,
						toggle:function(sizeToToggle){
							for(var i=0; i<btnBlock.children.length; i++){
								if(btnBlock.children[i].id === sizeToToggle){
									btnBlock.children[i].clicked = true;
									btnBlock.children[i].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
									btnBlock.children[i].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label1
									btnBlock.children[i].children[1].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label2
									btnAction(sizeToToggle);
				
									if(group.HasStyles && group.Styles && group.Styles.length){
										ro.itemObj.setStyles(currentStyleRow);
									}
				
								}
								else{
									btnBlock.children[i].clicked = false;
									btnBlock.children[i].backgroundColor = ro.ui.theme.sizeBtnBlockBgDefault;
									btnBlock.children[i].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;//Label1
									btnBlock.children[i].children[1].color = ro.ui.theme.sizeBtnBlockPriceTxtDefault;//Label2
								}
							}
						}
					});
			
					var getBtnBlockChildren = function(btnBlock, btns, currentStyleRow, group){
						var aBtn, btnLbl, btnLbl2, clickedBool, clickedColor, btnPriceLblClr;
						for(var i=0; i<btns.length; i++){
							clickedBool = false;
							clickedColor = ro.ui.theme.sizeBtnBlockBgDefault;
							//btnLblClr = ro.ui.theme.btnTxtDefault;
							btnLblClr = ro.ui.theme.sizeBtnBlockNameTxtDefault;
							//btnPriceLblClr = ro.ui.theme.loginBtnBackground;
							btnPriceLblClr = ro.ui.theme.sizeBtnBlockPriceTxtDefault;
			
							if(btns[i].OnlineDefault || btns.length === 1){
								clickedBool = true;
								//clickedColor = ro.ui.theme.btnActive;
								clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
								//btnLblClr = ro.ui.theme.btnTxtActive;
								btnLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
								//btnPriceLblClr = ro.ui.theme.btnTxtActive;
								btnPriceLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
			
								if(currentStyleRow !== false){
									btnAction(btns[i].Name);
									if(group.HasStyles && group.Styles && group.Styles.length){
										ro.itemObj.setStyles(currentStyleRow);
									}
								}
							}
							aBtn = Ti.UI.createView({
								width:ro.ui.relX(55),
								height:ro.ui.relY(55),
								id:btns[i].Name,
								borderColor:ro.ui.theme.btnBorderDefault,
								borderWidth:1,
								clicked:clickedBool,
								backgroundColor:clickedColor,
								layout:'vertical',
								name:btns[i].ReceiptName || btns[i].Name,
								szName:btns[i].Name,
								idx:i
							});
			
							var btnName = btns[i].DisplayName || btns[i].ReceiptName || btns[i].Name;
							if(btnName){
								btnName = btnName.toUpperCase();
							}
			
							btnLbl = Ti.UI.createLabel({
							   height:Ti.UI.SIZE,
								text:btnName,
								color:btnLblClr,
								font:{
									fontWeight:'bold',
									fontSize:ro.ui.scaleFont(11),
									fontFamily:ro.ui.fontFamily
								},
								textAlign:'center',
								touchEnabled:false,
								top:ro.ui.relY(7)
							});
			
							btnLbl2 = Ti.UI.createLabel({
							   height:Ti.UI.FILL,
							   text:styPrice?'$' + parseFloat(getSizePrice(btns[i]) + styPrice[i].Price).toFixed(2):'$' + parseFloat(getSizePrice(btns[i])).toFixed(2),
					         color:btnPriceLblClr,
					         font:{
					            fontWeight:'bold',
					            fontSize:ro.ui.scaleFont(11),
									fontFamily:ro.ui.fontFamily
					         },
					         textAlign:'center',
					         touchEnabled:false,
					         bottom:0
							});
							aBtn.add(btnLbl);
							aBtn.add(btnLbl2);
							btnBlock.add(aBtn);
						}
					};
					getBtnBlockChildren(btnBlock, btns, currentStyleRow, group);
			
					btnBlock.addEventListener('click', function(e){
						if(e.source.clicked){
							if(btnBlockCallback){
								btnBlockCallback();
							}
							else{
								return;
							}
						}
						/*if(setMdPerSz){
						   setMdPerSz(e.source.id)
						}*/
						//Ti.API.debug('e.source.id: ' + e.source.id);
						//setModsPerSize(e.source.id);
			
						e.source.parent.toggle(e.source.id);
			
			
						if(btnBlockCallback){
							btnBlockCallback();
						}
					});
					return btnBlock;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL){ Ti.API.debug('getButtonBlock()-Exception: ' + ex); }
					return btnBlock;
				}
			};
			function getSizePrice(sizesCol){
				var priceFound;
			
				function getNewTierPrices(TierSizeCol){
					for(var j=0; j<TierSizeCol.length; j++){
						if((sizesCol.Name == TierSizeCol[j].Size) && (TierSizeCol[j].Price != -0.86)){
							return TierSizeCol[j].Price;
						}
					}
				}
			
				if(group.UseTieredPricing){
					switch(Ti.App.OrderObj.OrdTypePriceIdx){
						case 0:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT0Sizes);
							break;
						case 1:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT1Sizes);
							break;
						case 2:
							priceFound = getNewTierPrices(itemSelected.TierObj.OT2Sizes);
							break;
					}
				}
				else{
					for(var j=0; j<itemSelected.AvailableSizes.length; j++){
						if(itemSelected.AvailableSizes[j].Name == sizesCol.Name){
							if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
								switch(Ti.App.OrderObj.OrdTypePriceIdx){
									case 1:
										if(itemSelected.AvailableSizes[j].OrdTypePrice1 != -0.86){
											priceFound = itemSelected.AvailableSizes[j].OrdTypePrice1;
										}
										break;
									case 2:
										if(itemSelected.AvailableSizes[j].OrdTypePrice2 != -0.86){
											priceFound = itemSelected.AvailableSizes[j].OrdTypePrice2;
										}
										break;
								}
							}
							else{
								priceFound = itemSelected.AvailableSizes[j].Price;
							}
							break;
						}
					}
				}
				return priceFound;
			}
			
			
			return styleView;
		};
	/*};
	return {
		stylesview:stylesview
	};
}();
module.exports = STYLESVIEW;*/