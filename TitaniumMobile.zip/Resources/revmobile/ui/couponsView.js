//Ti.include('/logic/menuUtils.js');
//Ti.include('/classes/utils.js');
//Ti.include('/controls/tabCtrl.js');

var COUPONVIEW = function() {
    var couponview = function(ro) {
        ro.ui.createCouponsView = function(_args) {
            try {
                Ti.API.info("THis is coupons view");
                var menuUtils = require('logic/menuUtils');
                //GUEST ORDERS
                var isGuest = false;
                if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                    isGuest = true;
                }
                //GUEST ORDERS

                var storeObj = ro.app.Store;
                var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                    name: 'Coupons',
                    hid: 'Coupons',
                    layout: 'vertical'
                }));
                var navBar = Ti.UI.createView(ro.ui.properties.navBar);

                var btnBack = layoutHelper.getBackBtn('CART');
                btnBack.addEventListener('click', function(e) {
                    if (!ro.isiOS)
                        Ti.UI.Android.hideSoftKeyboard();
                    if (ro.app.isDemo) {
                        ro.ui.demoCartShowNext({
                            showing: 'Coupons'
                        });
                    }
                    else {
                        ro.ui.cartShowNext({
                            showing: 'Coupons'
                        });
                    }
                });
                var tabWidth = ro.ui.relX(100);
                var tabs = [];

                function selectIndex(_idx) {
                    for (var i = 0,
                        l = tabs.length; i < l; i++) {
                        if (_idx === i) {
                            //if the tab is already selected, do nothing
                            if (!tabs[i].ison) {
                                tabs[i].toggle();
                                /*tab.animate({
                                 duration:1,
                                 right:tabWidth*i//,
                                 //bottom:0
                                 },
                                 function(idx){
                                 return function(){
                                 if(!tabs[idx].ison){
                                 tabs[idx].toggle();
                                 }
                                 };
                                 }(i));*/
                            }
                        }
                        else {
                            if (tabs[i].ison && (_idx !== i)) {
                                tabs[i].toggle();
                            }
                        }
                    }
                    couponChange({
                        rowIndex: _idx
                    });
                }

                function tabClick(e) {
                    if (!ro.isiOS)
                        Ti.UI.Android.hideSoftKeyboard();
                    selectIndex(e.source.id);
                }

                function createTab(_name, _cb, _on, _id) {
                    var view = Ti.UI.createView({
                        width: tabWidth,
                        id: _id,
                        name: _name
                    }),
                        on_color = 'yellow',
                        off_color = '#fff',
                        dimension = ro.ui.relY(20),
                        lbl = Ti.UI.createLabel({
                        text: _name,
                        height: dimension,
                        width: ro.ui.relX(110),
                        textAlign: 'center',
                        id: _id,
                        font: {
                            fontSize: ro.ui.scaleFont(13, 90, 30),
                            fontFamily: ro.ui.fontFamily
                        },
                        color: (_on) ? on_color : off_color
                    });
                    view.ison = _on || false;
                    view.add(lbl);
                    view.addEventListener('click', tabClick);
                    view.toggle = function() {
                        view.ison = !view.ison;
                        view.children[0].color = (view.ison) ? on_color : off_color;
                    };
                    return view;
                }


                navBar.add(btnBack);
                /* if(ro.ui.theme.bannerImg){
                var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
                navBar.add(headerImg);
                } */
                //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));

                if (ro.isiphonex) {
                    var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                    var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                    var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                    navParent.add(topNav);
                    bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                    navParent.add(bottomNav);
                    mainView.add(navParent);
                }
                else {
                    mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                }

                var promoCodeBox = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth,
                    height: Ti.UI.SIZE,
                    layout: 'vertical',
                    top: ro.ui.relX(5)
                });
                //var cpnCodeTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Enter A Coupon Code';
                var cpnCodeTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'ENTER A COUPON CODE';
                var cpnCodeLittleTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'Coupon Code';
                //promoCodeBox.add(ro.layout.getGenericHdrRowWithHeader(cpnCodeTxt, true));
                //var cpnCodeLittleTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Coupon Code';

                var cpnView = Ti.UI.createView({
                    top: ro.ui.relY(5),
                    height: ro.ui.relY(40),
                    width: Ti.UI.SIZE,
                    //left: ro.ui.relX(25),
                    //right: ro.ui.relX(25),
                    layout: 'horizontal'
                });
                var cpnTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                    left: 0,
                    width: ro.ui.properties.wideViewWidth * .6,
                    height: Ti.UI.FILL,
                    hintText: cpnCodeLittleTxt,
                    //bottom:ro.ui.relX(5),
                    font: {
                        fontFamily: ro.ui.fonts.textFields,
                        fontSize: ro.ui.scaleFont(18)
                    },
                        backgroundColor:'#f6f6f6',
                            borderColor:'#cbcbcb',
                            hintTextColor:'#393839'
                }));

                function getKeyboardToolbar(doneEvt) {
                    /*var picNext = Ti.UI.createButton({
                     title : 'Next',
                     style : Ti.UI.iOS.SystemButtonStyle.DONE,
                     id : keyboardBtnId
                     });*/
                    var picDone = Ti.UI.createButton({
                        title: 'Done',
                        style: Ti.UI.iOS.SystemButtonStyle.DONE//,
                        //id : keyboardBtnId
                    });

                    var picSpacer = Ti.UI.createButton({
                        systemButton: Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
                    });

                    var picToolbar = Ti.UI.createToolbar({
                        top: 0,
                        items: [picSpacer, picDone],
                        zIndex: 2,
                        width: Ti.UI.FILL
                    });

                    picDone.addEventListener('click', doneEvt);
                    //picNext.addEventListener('click', nextEvt);

                    return picToolbar;
                };
                var doneFn = function() {
                    cpnTextBox.blur();
                };
                if (ro.isiOS) {

                    cpnTextBox.keyboardToolbar = getKeyboardToolbar(doneFn);
                }

                var cpnBtn = Ti.UI.createView({
                    width: ro.ui.properties.wideViewWidth * .3,
                    height: Ti.UI.FILL,
                    //right: ro.ui.relX(15),
                    left: ro.ui.relX(15),
                    backgroundColor: ro.ui.theme.btnActive,
                    borderColor: ro.ui.theme.btnActive,
                    borderRadius: ro.ui.relX(20),
                    //bottom:ro.ui.relX(5)
                });
                cpnBtn.add(Ti.UI.createLabel({
                    text: 'Add',
                    font: {
                        //fontWeight:'bold',
                        fontFamily: ro.ui.fonts.button,
                        fontSize: ro.ui.scaleFont(19),
                        //fontFamily:ro.ui.fontFamily
                    },
                    color: ro.ui.theme.loginBtnWhite,
                    textAlign: 'center',
                    touchEnabled: false
                }));

                var cpnBtnClickTime = 0;
                cpnBtn.addEventListener('click', function (e) {                    
                    if (new Date().getTime() - cpnBtnClickTime < 1000) {
                        Ti.API.info('returning');
                        return;
                    }
                    var thisClickTime = new Date();
                    cpnBtnClickTime = thisClickTime.getTime();
                    thisClickTime = null;

                    if (!cpnTextBox.value) {
                        ro.ui.alert('Error', 'Please enter a valid coupon code');
                        return;
                    }
                    if (ro.REV_LOYALTY.isValidCode(cpnTextBox.value)) {
                        ro.REV_LOYALTY.validateCoupon(cpnTextBox.value, ro.app.Store.ID, function (newCode, LoyaltyCode) {
                            // menuUtils.testCpnCode(newCode, false, true, LoyaltyCode);


                            menuUtils.testCpnCode(newCode, false, true, LoyaltyCode, null, true);
                        }, false, false, function () {
                            menuUtils.testCpnCode(cpnTextBox.value, false, false, null, null, true); //DYNAMIC CODE NOT FOUND FALLBACK
                        });
                    } else {
                        menuUtils.testCpnCode(cpnTextBox.value, false, false, null, null, true);
                    }
                    //if (ro.REV_LOYALTY.isValidCode(cpnTextBox.value)) {
                    //    ro.REV_LOYALTY.validateCoupon(cpnTextBox.value, ro.app.Store.ID, function(newCode, LoyaltyCode) {
                    //        APPLY_COUPON(newCode, LoyaltyCode);
                    //    }, true);
                    //}
                    //else {
                    //    APPLY_COUPON();
                    //}
                });

                cpnView.add(cpnTextBox);
                cpnView.add(cpnBtn);

                promoCodeBox.add(cpnView);

                var couponsData = [];
                /*var itemsView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
                 name:'items',
                 height:Ti.UI.FILL,
                 top:0,
                 right:0,
                 left:0,
                 bottom:ro.ui.relY(55),
                 layout:'vertical'
                 }));*/
                var itemsView = Ti.UI.createView({
                    name: 'items',
                    layout: 'vertical',
                    top: 0,
                    right: ro.ui.relX(0),
                    left: ro.ui.relX(0),
                    bottom: ro.ui.relY(5),
                    height: Ti.UI.FILL
                });
                tabs.push(ro.tabBar.createTab('Coupons', function() {
                    selectIndex(0);
                }, true, 0));

                tabs.push(ro.tabBar.createTab('Use Code', function() {
                    selectIndex(1);
                }, false, 1));

                var tabView = ro.tabBar.getTabView(tabs);
                var tab = Ti.UI.createView({
                    right: 0,
                    top: 0,
                    height: .1,
                    width: .1,
                    backgroundImage: ro.ui.properties.defaultPath + 'tabHighlight.png'
                });
                //tabView.add(tab);

                /*for(var i=0, l=tabs.length; i<l; i++){
                tabs[i].left = ro.ui.relX(120) * i;
                tabView.add(tabs[i]);
                }*/
                //itemsView.add(tabView);

                itemsView.add(promoCodeBox);

                var tblItems = Ti.UI.createTableView({
                    height: Ti.UI.FILL,
                    backgroundColor: 'white',
                    separatorColor: 'transparent',
                    minRowHeight: ro.ui.properties.menuRowHeight,
                    top: ro.ui.relY(2),
                    left: 3,
                    right: 3
                });

                /*var tblItems = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView,{
                 top:ro.ui.relY(2),
                 //top:0,
                 height:Ti.UI.SIZE,
                 separatorColor:'transparent',
                 left:0,
                 right:0
                 }));*/
                var noCouponsLbl = Ti.UI.createLabel({
                    text: 'No coupons found matching the items in your cart.',
                    font: {
                        fontWeight: 'bold',
                        fontSize: ro.ui.scaleFont(18, 90, 30),
                        fontFamily: ro.ui.fontFamily
                    },
                    textAlign: 'center',
                    width: ro.ui.relX(350),
                    height: Ti.UI.FILL,
                    color: ro.ui.theme.couponsViewTxtColor
                });
                var cpnCodeTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'ENTER A COUPON CODE';
                var cpnCodeLittleTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'Coupon Code';
                var codeLbl = Ti.UI.createLabel({
                    text: cpnCodeTxt,
                    textAlign: 'left',
                    font: {
                        fontWeight: 'bold',
                        fontSize: ro.ui.scaleFont(18, 90, 30),
                        fontFamily: ro.ui.fontFamily
                    },
                    width: ro.ui.relX(250),
                    height: ro.ui.relY(25),
                    top: ro.ui.relY(15),
                    color: ro.ui.theme.couponsViewTxtColor
                });
                var codeTxt = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                    width: ro.ui.relX(250),
                    height: ro.ui.relY(60),
                    font: {
                        fontFamily: ro.ui.fonts.textFields,
                        fontSize: ro.ui.scaleFont(16, 80, 30)
                    },
                    keyboardType: Ti.UI.KEYBOARD_TYPE_DEFAULT,
                    returnKeyType: Ti.UI.RETURNKEY_DONE,
                    borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
                    top: ro.ui.relY(10),
                    hintText: cpnCodeLittleTxt,
                    backgroundColor:'#f6f6f6',
                    borderColor:'#cbcbcb',
                    hintTextColor:'#393839'
                }));
                var applyBtn = layoutHelper.getBigButton('Apply Code');
                //applyBtn.bottom = null;
                applyBtn.top = ro.ui.relY(5);

                function addCoupon(coupon, valcode, LoyaltyCode) {
                    var cpnObj = {};
                    var Ord = Ti.App.OrderObj;
                    if (!Ord.Cpns) {
                        Ord.Cpns = [];
                    }

                    cpnObj.CpnValue = coupon.CpnValue;
                    cpnObj.RcptName = coupon.RcptName;
                    cpnObj.Name = coupon.Name;
                    cpnObj.CpnScope = coupon.CpnScope;
                    cpnObj.CpnType = coupon.CpnType;
                    cpnObj.CpnPct = coupon.CpnPct;
                    cpnObj.MinPrice = coupon.MinPrice ? coupon.MinPrice : 0;
                    cpnObj.MaxValue = coupon.MaxValue ? coupon.MaxValue : 0;
                    cpnObj.AdjItemPrice = coupon.AdjItemPrice;
                    cpnObj.TaxType = coupon.TaxType;
                    cpnObj.ReportGrp = coupon.ReportGrp;
                    cpnObj.FreeDlvy = coupon.FreeDlvy;
                    cpnObj.LeaveTax = coupon.LeaveTax;
                    cpnObj.No2ndItm = coupon.No2ndItm;
                    cpnObj.BeatClock = coupon.BeatClock;
                    cpnObj.DlvyFeeIfZero = coupon.DlvyFeeIfZero;
                    cpnObj.NoModDisc = coupon.NoModDisc;
                    cpnObj.NoStyleDisc = coupon.NoStyleDisc;
                    cpnObj.NoPrefDisc = coupon.NoPrefDisc;

                    var curDate = new Date();
                    var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
                    cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
                    cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));

                    if (coupon.ReqValCode) {
                        cpnObj.ValCode = valcode;
                        if(LoyaltyCode && LoyaltyCode.length){
                            cpnObj.LtyDiscountType = 1;
                            cpnObj.LoyaltyCode = LoyaltyCode;
                            
                            var codeTypeStr = "";
                             if(LoyaltyCode && LoyaltyCode.length > 2){
                                 codeTypeStr = LoyaltyCode[0] + LoyaltyCode[1];
                             }
                             
                             if(ro.app.Store.Configuration.CP_APIKEY && ro.app.Store.Configuration.CP_APIKEY.length && codeTypeStr.toLowerCase() != "hc" && codeTypeStr.toLowerCase() != "ew"){
                                 //menuUtils.testCpnCode(newCode, true, true, LoyaltyCode);
                                 cpnObj.LtyDiscountType = 3;
                             }
                        }
                    }
                    //cpnObj.IsExclusive = coupon.IsExclusive;
                    //cpnObj.MultiQualTtl = coupon.MultiQualTtl?coupon.MultiQualTtl:0;
                    cpnObj.IsExclusive = coupon.IsExclusive;
                    cpnObj.MultiQualTtl = coupon.MultiQualTtl ? coupon.MultiQualTtl : 0;
                    cpnObj.PickAnyCnt = coupon.PickAnyCnt ? coupon.PickAnyCnt : 0;
                    cpnObj.RequireAnyCnt = coupon.RequireAnyCnt ? coupon.RequireAnyCnt : 0;
                    cpnObj.RequiredItem = coupon.RequiredItem;
					cpnObj.MaxModValue = coupon.MaxModValue;
					
                    if (coupon.CpnScope >= 3) {
                        var cpnItmCol = [];
                        for (var i = 0; i < coupon.Items.length; i++) {
                            var cpnItmObj = {};
                            cpnItmObj.MenuGroup = coupon.Items[i].MenuGroup;
                            cpnItmObj.MenuItem = coupon.Items[i].MenuItem;
                            cpnItmObj.MenuSize = coupon.Items[i].MenuSize;
                            cpnItmObj.MenuSizes = coupon.Items[i].MenuSizes;
                            cpnItmObj.MenuStyle = coupon.Items[i].MenuStyle;
                            cpnItmObj.MenuStyles = coupon.Items[i].MenuStyles;
                            cpnItmObj.IsRequired = coupon.Items[i].IsRequired;
                            cpnItmObj.CpnKey = coupon.Key;
                            cpnItmObj.MenuCpnItmKey = coupon.Items[i].MenuCpnItmKey;
                            cpnItmObj.BogoReq = coupon.Items[i].BogoReq;
                            cpnItmObj.MaxModValue = coupon.Items[i].MaxModValue;
                            cpnItmObj.Surcharge = coupon.Items[i].Surcharge;
                            cpnItmCol.push(cpnItmObj);
                        }
                        cpnObj.Items = cpnItmCol;
                    }
                    if (coupon.SingleUse) {
                        cpnObj.SingleUseKey = coupon.Key;
                    }
                    Ord.Cpns.push(cpnObj);
                    Ti.App.OrderObj = Ord;

                    if (ro.app.isDemo) {
                        ro.ui.reloadCartDemo();
                        ro.ui.demoCartShowNext({
                            showing: 'Coupons',
                            reprice: true
                        });
                    }
                    else {
                        ro.ui.reloadCart();
                        ro.ui.cartShowNext({
                            showing: 'Coupons',
                            reprice: true
                        });
                    }
                }


                tblItems.addEventListener('click', function(e) {
                    var CpnIdx = e.row.cpnIdx;
                    
                    //Jan 26, 2011 Coupon validation by order type
                    if (storeObj.Menu.Cpns[CpnIdx].NoDelivery && Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[CpnIdx].Name + ' coupon is not available for delivery orders');
                        ro.ui.hideLoader();
                        return;
                    }

                    var ordPctCpnFound = false;
                    if (Ti.App.OrderObj.Cpns) {
                        if (Ti.App.OrderObj.Cpns.length > 0 && storeObj.Menu.Cpns[CpnIdx].IsExclusive) {
                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[CpnIdx].Name + ' coupon is not valid with any other coupon.');
                            ro.ui.hideLoader();
                            return;
                        }

                        for (var i = 0; i < Ti.App.OrderObj.Cpns.length; i++) {
                            if (Ti.App.OrderObj.Cpns[i].IsExclusive) {
                                ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[i].Name + ' coupon. This is not valid with any other coupon.');
                                ro.ui.hideLoader();
                                return;
                            }

                            if (Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[CpnIdx].Name) {
                                if (storeObj.Menu.Cpns[CpnIdx].CpnScope == 1) {
                                    ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Cpns[i].Name + ' coupon has already been applied to your order.');
                                    ro.ui.hideLoader();
                                    return;
                                }
                            }

                            if (Ti.App.OrderObj.Cpns[i].CpnType == 2) {
                                if (storeObj.Menu.Cpns[CpnIdx].CpnScope == 1 && storeObj.Menu.Cpns[CpnIdx].CpnType == 2) {
                                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[CpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                    ro.ui.hideLoader();
                                    return;
                                }
                            }
                        }
                    }
                    
            if (Ti.App.OrderObj.Items) {
                for (var x = 0; x < Ti.App.OrderObj.Items.length; x++) {
                  if(Ti.App.OrderObj.Items[x].CpnObj){
                    if (storeObj.Menu.Cpns[CpnIdx].IsExclusive) {
                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[CpnIdx].Name + ' coupon is not valid with any other coupon.');
                        ro.ui.hideLoader();
                        return;
                    }
                                      
                    if (Ti.App.OrderObj.Items[x].CpnObj.IsExclusive) {
                        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon. This is not valid with any other coupon.');
                        ro.ui.hideLoader();
                        return;
                    }

                    if (Ti.App.OrderObj.Items[x].CpnObj.Name == storeObj.Menu.Cpns[CpnIdx].Name) {
                        if (storeObj.Menu.Cpns[CpnIdx].CpnScope == 1) {
                            ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon has already been applied to your order.');
                            ro.ui.hideLoader();
                            return;
                        }
                    }

                    if (Ti.App.OrderObj.Items[x].CpnObj.CpnType == 2) {
                        if (parseInt(storeObj.Menu.Cpns[CpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[CpnIdx].CpnType, 10) == 2) {
                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[CpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                            ro.ui.hideLoader();
                            return;
                        }
                    }
                  }
                    
                }                
            }

                    if (storeObj.Menu.Cpns[CpnIdx].Items) {
                    	
                    		if(!menuUtils.isCpnConfiguredProperly(storeObj.Menu.Cpns[CpnIdx])){
                    			ro.ui.alert('Invalid Coupon. ', 'The store has not configured this coupon properly.');
                    			ro.ui.hideLoader();
                    			return;
                    		}
                    	
                        ro.App.cpnCodeMode.Flg = true;
                        ro.App.cpnCodeMode.Key = storeObj.Menu.Cpns[CpnIdx].Key;
                        ro.App.cpnCodeMode.LoyaltyCode = null;
                        ro.ui.cartShowNext({
                            showing: 'Cart'
                        });
                        //cpnFound = false;//this is to prevent the addCoupon function call from still happening? which seems to happen from time to time....
                        return;
                    }
                    else {
                        addCoupon(storeObj.Menu.Cpns[CpnIdx]);
                    }
                });

                function toggleVisibility(tblVisibility, codeVisibility) {
                    codeLbl.visible = codeVisibility;
                    codeTxt.visible = codeVisibility;
                    applyBtn.visible = codeVisibility;

                    if (!codeVisibility) {
                        tblItems.visible = tblVisibility;
                        noCouponsLbl.visible = !tblVisibility;
                        //noCouponsLbl.height = ro.ui.relY(50);

                        codeLbl.visible = false;
                        codeLbl.height = 0;
                        codeLbl.top = 0;

                        codeTxt.value = '';

                        codeTxt.visible = false;
                        codeTxt.height = 0;
                        codeTxt.top = 0;

                        applyBtn.visible = false;
                        applyBtn.height = 0;
                        applyBtn.top = 0;
                        applyBtn.bottom = 0;
                    }
                    else {
                        tblItems.visible = false;
                        noCouponsLbl.visible = false;

                        //noCouponsLbl.height = 0;

                        codeLbl.height = ro.ui.relY(25);
                        codeLbl.top = ro.ui.relY(15);

                        codeTxt.height = ro.ui.relY(40);
                        codeTxt.top = ro.ui.relY(10);

                        applyBtn.height = ro.ui.relY(64);
                        applyBtn.top = ro.ui.relY(5);
                        applyBtn.bottom = ro.ui.relY(55);
                    }
                }

                function DisplayCoupons() {
                    try {
                        var j,
                            k,
                            CpnIdx,
                            blnVis,
                            deliveryType,
                            BtnIdx = 0,
                            curOrdType = Ti.App.OrderObj.OrdType;
                        if (!storeObj.Menu.Cpns) {
                            toggleVisibility(false, false);
                            return;
                        }

                        for ( CpnIdx = 0; CpnIdx < storeObj.Menu.Cpns.length; CpnIdx++) {
                            if (!storeObj.Menu.Cpns[CpnIdx].ReqValCode || storeObj.Menu.Cpns[CpnIdx].VCSupress) {
                                blnVis = false;
                                var curDate = new Date();
                                var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
                                var timeAtStore = menuUtils.getStoreTime(storeObj.TimeZone);

                                if (storeObj.Menu.Name == storeObj.Menu.Cpns[CpnIdx].Menu || storeObj.Menu.Cpns[CpnIdx].Menu == 'All') {
                                    blnVis = true;

                                    if (ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER') {
                                        blnVis = false;
                                        continue;
                                    }

                                    if (ro.app.Store.Menu.Cpns[CpnIdx].CpnScope === 3) {
                                        if (!ro.app.Store.Menu.Cpns[CpnIdx].Items) {
                                            blnVis = false;
                                            continue;
                                        }
                                    }

                                    /*if(ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true && isGuest){
                                     blnVis = false;
                                     continue;
                                     }*/
                                    if (storeObj.Menu.Cpns[CpnIdx].SingleUse == true) {// && isGuest){
                                        ////deb.ug(storeObj.Menu.Cpns[CpnIdx], 'storeObj.Menu.Cpns[CpnIdx]');
                                        if (isGuest) {
                                            blnVis = false;
                                            continue;
                                        }
                                        else {
                                            var rs = ro.db.getCustObj(Ti.App.Username);
                                            if (!rs) {
                                                rs = {};
                                            }
                                            if (!rs.CpnUsage) {
                                                rs.CpnUsage = [];
                                            }
                                            else {
                                                rs.CpnUsage = rs.CpnUsage.split("-");
                                            }

                                            var shouldContinue = false;
                                            for (var cpnUsageIdx = 0,
                                                cpnUsageMax = rs.CpnUsage.length; cpnUsageIdx < cpnUsageMax; cpnUsageIdx++) {
                                                Ti.API.debug('rs.CpnUsage[' + cpnUsageIdx + ']: ' + rs.CpnUsage[cpnUsageIdx]);
                                                if (storeObj.Menu.Cpns[CpnIdx].Key == rs.CpnUsage[cpnUsageIdx]) {
                                                    blnVis = false;
                                                    shouldContinue = true;
                                                    break;
                                                }
                                            }

                                            for (var currCpnIdx = 0,
                                                currCpnMax = Ti.App.OrderObj && Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; currCpnIdx < currCpnMax; currCpnIdx++) {
                                                if (Ti.App.OrderObj.Cpns[currCpnIdx].SingleUseKey == storeObj.Menu.Cpns[CpnIdx].Key) {
                                                    blnVis = false;
                                                    shouldContinue = true;
                                                    break;
                                                }
                                            }

                                            if (shouldContinue) {
                                                Ti.API.debug('continuing due to already having used this single use cpn...IT SHOULD NOT SHOW UP IN CPN LIST');
                                                continue;
                                            }
                                        }
                                    }

                                    if (storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes && storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
                                        for(var exclOrdIdx = 0; exclOrdIdx < storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; exclOrdIdx++){
                                            if(Ti.App.OrderObj.OrdType == storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
                                                blnVis = false;
                                                continue;
                                            }
                                        }
                                    }

                                    if (storeObj.Menu.Cpns[CpnIdx].HasStartDt) {
                                        var startDt = new Date(storeObj.Menu.Cpns[CpnIdx].StartDtStr);
                                        if (startDt.getTime() > timeAtStore.getTime()) {
                                            blnVis = false;
                                            continue;
                                        }
                                    }

                                    if (storeObj.Menu.Cpns[CpnIdx].HasExpirDt) {
                                        var ExpirDt = new Date(storeObj.Menu.Cpns[CpnIdx].ExpirDtStr);
                                        var StoreDate = new Date(timeAtStore);
                                        ExpirDt.setHours(0, 0, 0, 0);
                                        StoreDate.setHours(0, 0, 0, 0);
                                        if (ExpirDt.getTime() < StoreDate.getTime()) {
                                            blnVis = false;
                                            continue;
                                        }
                                    }

                                    /*switch(parseInt(storeObj.Menu.Cpns[CpnIdx].CpnScope, 10)){
                                     case 1:
                                     if(storeObj.Menu.Cpns[CpnIdx].MinPrice > 0){
                                     var dcSubTot = 0;
                                     if(Ti.App.OrderObj.Cpns){
                                     for(j=0; j<Ti.App.OrderObj.Cpns.length; j++){
                                     if(Ti.App.OrderObj.Cpns[j].MinPrice > 0){
                                     blnVis = false;
                                     continue;
                                     }
                                     }
                                     }
                                     dcSubTot = Ti.App.OrderObj.Subtotal;

                                     if(dcSubTot < storeObj.Menu.Cpns[CpnIdx].MinPrice){
                                     blnVis = false;
                                     continue;
                                     }
                                     }
                                     break;
                                     case 2:
                                     break;
                                     case 3:
                                     if(!storeObj.Menu.Cpns[CpnIdx].Items){
                                     blnVis = false;
                                     continue;
                                     }
                                     else{
                                     if(storeObj.Menu.Cpns[CpnIdx].Items.length > 0){
                                     var sTime = new Date();
                                     sTime.setHours(0, 0);
                                     var eTime = sTime;
                                     if(!ro.coupons.ValidateMultiCoupons(storeObj.Menu.Cpns[CpnIdx].Items, 0, 0, false, 0, sTime, eTime)){
                                     //if(!ro.coupons.ValidateMultiCoupons(storeObj.Menu.Cpns[CpnIdx], 0, 0, false, 0, sTime, eTime)){
                                     blnVis = false;
                                     continue;
                                     }
                                     }
                                     else{
                                     blnVis = false;
                                     continue;
                                     }
                                     }
                                     break;
                                     }*/

                                    if (storeObj.Menu.Cpns[CpnIdx].Weekdays > 0) {
                                        if (blnVis == true) {
                                            if (!menuUtils.WeekdayValid(storeObj.Menu.Cpns[CpnIdx].Weekdays, timeAtStore)) {
                                                blnVis = false;
                                                continue;
                                            }
                                        }
                                    }

                                    if (storeObj.Menu.Cpns[CpnIdx].TimeIdx > 0) {
                                        if (blnVis == true) {
                                            //if (!menuUtils.IsTimeValid(storeObj.Menu.Cpns[CpnIdx].TimeIdx, storeObj.Menu.Cpns[CpnIdx].StartTime, storeObj.Menu.Cpns[CpnIdx].EndTime, timeAtStore)) {
                                                if (!menuUtils.IsTimeValid(storeObj.Menu.Cpns[CpnIdx].TimeIdx, storeObj.Menu.Cpns[CpnIdx].StartTimeStr, storeObj.Menu.Cpns[CpnIdx].EndTimeStr, timeAtStore)) {
                                                    blnVis = false;
                                                    continue;
                                                }
                                            //}
                                        }
                                    }

                                    if (storeObj.Menu.Cpns[CpnIdx].HasExcldOrdType) {
                                        if (storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes) {
                                            for ( j = 0; j < storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; j++) {
                                                if (storeObj.Menu.Cpns[CpnIdx].ExcldOrdTypes[j] == curOrdType) {
                                                    blnVis = false;
                                                    continue;
                                                }
                                            }
                                        }
                                    }

                                    if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                                        if (storeObj.Menu.Cpns[CpnIdx].NoDelivery) {
                                            blnVis = false;
                                            continue;
                                        }
                                    }
                                }
                                if (blnVis) {
                                    ro.cpnHelper.findItem(storeObj.Menu.Cpns[CpnIdx].Key);
                                    var cpnItemsArr = ro.cpnHelper.checkCart({
                                        cpnKey: storeObj.Menu.Cpns[CpnIdx].Key
                                    });
                                    if (!cpnItemsArr.allDone) {
                                        continue;
                                    }
                                    //function getCouponRow(receiptName, obj, imgPath, isCoupon, idx, itemPrice, grpIndx){

                                    //couponsData.push(getCouponRow(storeObj.Menu.Cpns[CpnIdx].RcptName, storeObj.Menu.Cpns[CpnIdx].CpnDesc, "", true, CpnIdx, null, null));
                                    //continue;
                                    var title,
                                        desc,
                                        path,
                                        cpnImage,
                                        cpnRow,
                                        backgroundImg;
                                    var labelVw = Ti.UI.createView({
                                        height: Ti.UI.SIZE,
                                        width: Ti.UI.SIZE,
                                        right: ro.ui.relX(10),
                                        layout: 'vertical',
                                        left: ro.ui.relX(7)
                                    });
                                    title = Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsName, {
                                        color: ro.ui.theme.newGroupsBtnTxt,
                                        text: storeObj.Menu.Cpns[CpnIdx].RcptName,
                                        width: Ti.UI.SIZE,
                                        top: Ti.App.picklemansStyle ? ro.ui.relY(10) : ro.ui.relY(1),
                                        font: {
                                            fontSize: ro.ui.scaleFont(18), //11
                                            //fontWeight: 'bold',
                                            fontFamily: ro.ui.fonts.titles
                                        }
                                    }));
                                    desc = Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsDetails, {
                                        color: ro.ui.theme.newGroupsBtnTxt, //ro.ui.theme.contentsSmallTxt,
                                        text: storeObj.Menu.Cpns[CpnIdx].CpnDesc,
                                        height: Ti.UI.SIZE,
                                        width: Ti.UI.SIZE,
                                        top: ro.ui.relY(1),
                                        font: {
                                            fontSize: ro.ui.scaleFont(13),
                                            fontFamily: ro.ui.fonts.rowBodyTxt
                                        }
                                    }));

                                    labelVw.add(title);
                                    labelVw.add(desc);

                                    path = ro.ui.properties.defaultPath + 'coupon.png';
                                    cpnImage = Ti.UI.createImageView({
                                        image: (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png'),
                                        defaultImage: path,
                                        top: ro.ui.relY(10),
                                        bottom: ro.ui.relY(10)
                                    });
                                    cpnRow = Ti.UI.createTableViewRow({
                                        height: ro.ui.relY(100),
                                        className: 'coupon',
                                        cpnIdx: CpnIdx,
                                        backgroundColor: ((couponsData.length % 2) ? '#f6f6f6' : 'white'),
                                        selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                                    });
                                    backgroundImg = Ti.UI.createImageView({
                                        //image:Ti.App.websiteURL+'/content/images/menu-item.png',
                                        //defaultImage:'/images/menuItemBg.png',
                                        height: Ti.UI.FILL,
                                        width: Ti.UI.FILL,
                                        zIndex: -1000,
                                        touchEnabled: false
                                    });
                                    cpnRow.add(backgroundImg);

                                    var imageWrapper = Ti.UI.createView({
                                        width: ro.ui.relX(95),
                                        left: Ti.App.picklemansStyle ? 4 : ro.ui.relX(6),
                                        top: Ti.App.picklemansStyle ? -4 : ro.ui.relX(6),
                                        bottom: ro.ui.relX(6)
                                    });
                                    imageWrapper.add(cpnImage);
                                    //cpnRow.add(imageWrapper);
                                    //cpnRow.add(title);
                                    //cpnRow.add(desc);
                                    cpnRow.add(labelVw);
                                    couponsData.push(cpnRow);
                                }
                            }
                        }
                        try {
                            if (couponsData.length > 0) {
                                toggleVisibility(true, false);
                                tblItems.data = couponsData;
                            }
                            else {
                                toggleVisibility(false, false);
                            }
                        }
                        catch (ex) {
                            Ti.API.info("Exception: " + JSON.stringify(ex));
                            ro.ui.alert('Coupons', 'CODE 100');
                        }
                    }
                    catch (ex) {
                        Ti.API.info("Exception: " + JSON.stringify(ex));
                        ro.ui.alert('Coupons ', 'CODE D100');
                    }
                }

                function getCouponRow(receiptName, desc, imgPath, isCoupon, idx, itemPrice, grpIndx) {
                    var hasImg = (imgPath && imgPath.length > 0);
                    var left = ro.ui.relX(7);
                    var cls = ( hasImg ? 'item' : 'noitem');
                    var hasRightImg = false;

                    var bottom = 30;
                    var theRow = Ti.UI.createTableViewRow({
                        selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                        hasChild: false,
                        height: ro.ui.relY(175), //120
                        itmType: ( isCoupon ? 'coupon' : 'item'),
                        cpnIdx: idx,
                        width: ro.ui.displayCaps.platformWidth,
                        layout: 'horizontal'

                    });
                    var leftVw = Ti.UI.createView({
                        width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7,
                        height: Ti.UI.FILL
                    });
                    var imageHolder = Ti.UI.createView({
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: ro.ui.relY(bottom)
                    });
                    imageHolder.add(Ti.UI.createImageView({
                        image: isCoupon ? (ro.ui.properties.defaultPath + 'myDeals.png') : ( hasImg ? imgPath : group.ImageSource),
                        defaultImage: ro.ui.properties.defaultImgPath,
                        top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : 0, //ro.ui.relX(15),
                        bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
                    }));
                    var labelHolder = Ti.UI.createView({
                        bottom: 20,
                        left: 0,
                        right: 0,
                        height: ro.ui.relY(bottom)
                    });
                    labelHolder.add(Ti.UI.createLabel({
                        text: itemPrice,
                        font: {
                            fontFamily: ro.ui.fontFamily,
                            fontSize: ro.ui.scaleFont(15),
                            fontWeight: 'bold'
                        },
                        color: '#666'
                    }));
                    leftVw.add(imageHolder);
                    leftVw.add(labelHolder);

                    var rightVw = Ti.UI.createView({
                        width: (ro.ui.displayCaps.platformWidth / 2) * (11 / 10), // - 20,
                        height: Ti.UI.FILL,
                        layout: 'vertical'
                    });
                    var titleHolder = Ti.UI.createView({
                        height: ro.ui.relY(40),
                        width: Ti.UI.FILL
                    });
                    titleHolder.add(Ti.UI.createLabel({
                        text: receiptName,
                        color: '#393839',
                        textAlign: 'left',
                        left: 0,
                        font: {
                            fontFamily: ro.ui.fontFamily,
                            fontSize: ro.ui.scaleFont(18),
                            fontWeight: 'bold'
                        }
                    }));
                    ////Ti.API.debug('titleHolder: ' + JSON.stringify(titleHolder));
                    var bodyHolder = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL
                    });
                    bodyHolder.add(Ti.UI.createLabel({
                        text: desc,
                        textAlign: 'left',
                        color: '#393839',
                        left: 0,
                        top: 0,
                        font: {
                            fontFamily: ro.ui.fontFamily,
                            fontSize: ro.ui.scaleFont(13)
                        }
                    }));
                    ////Ti.API.debug('bodyHolder: ' + JSON.stringify(bodyHolder));
                    rightVw.add(titleHolder);
                    rightVw.add(bodyHolder);

                    theRow.add(leftVw);
                    theRow.add(rightVw);
                    //itemsData[idx] = theRow;
                    return theRow;
                    //return theRow;
                }

                function APPLY_COUPON(e, LoyaltyCode) {
                    try {                        
                        var coupon,
                            alertTitle,
                            cpnFound = false,
                            alertMessage = 'No coupon found.';
                        var thisCode = cpnTextBox.value;
                        var isEwomBool = false;
                        var theLoyaltyCode = "";
                        if (e && e.length) {
                            isEwomBool = true;
                            thisCode = e;
                            theLoyaltyCode = LoyaltyCode;
                        }

                        if (thisCode.length > 0) {
                            if (storeObj.Menu.Cpns) {
                                for (var i = 0; i < storeObj.Menu.Cpns.length; i++) {
                                    if (storeObj.Menu.Cpns[i].ReqValCode) {
                                        for (var j = 0, jMax = (storeObj.Menu.Cpns[i].ValCodes && storeObj.Menu.Cpns[i].ValCodes.length ? storeObj.Menu.Cpns[i].ValCodes.length : 0); j < jMax; j++) {
                                            if (thisCode.toUpperCase() == storeObj.Menu.Cpns[i].ValCodes[j].toUpperCase()) {
                                                cpnFound = true;

                                                if (storeObj.Menu.Cpns[i].ConfirmLoyalty) {
                                                    if (!isEwomBool) {
                                                        ro.ui.alert(alertTitle, alertMessage);
                                                        return;
                                                    }
                                                }

                                                var storeTime = menuUtils.getStoreTime(storeObj.TimeZone);
                                                if (storeObj.Menu.Cpns[i].HasStartDt) {
                                                    var startDt = new Date(storeObj.Menu.Cpns[i].StartDtStr);
                                                    if (startDt.getTime() > storeTime.getTime()) {
                                                        ro.ui.alert('Coupon Not Valid', 'This coupon is not valid at this time.');
                                                        return;
                                                    }
                                                }
                                                if (storeObj.Menu.Cpns[i].HasExpirDt) {
                                                    var ExpirDt = new Date(storeObj.Menu.Cpns[i].ExpirDtStr);
                                                    var StoreDate = new Date(storeTime);
                                                    ExpirDt.setHours(0, 0, 0, 0);
                                                    StoreDate.setHours(0, 0, 0, 0);
                                                    if (ExpirDt.getTime() < StoreDate.getTime()) {
                                                        ro.ui.alert('Coupon Not Valid', 'This coupon is not valid at this time.');
                                                        return;
                                                    }
                                                }

                                                if (storeObj.Menu.Cpns[i].SingleUse == true) {
                                                    if (Ti.App.CpnUsageString && Ti.App.CpnUsageString.length) {
                                                        for (var cpnLg = 0; cpnLg < Ti.App.CpnUsageString.length; cpnLg++) {
                                                            if (Ti.App.CpnUsageString[cpnLg] == storeObj.Menu.Cpns[i].Key) {
                                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied to a past order.');
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                                if (storeObj.Menu.Cpns[i].MultiQualTtl) {
                                                    if (Ti.App.OrderObj && Ti.App.OrderObj.Cpns) {
                                                        var ordCpns = Ti.App.OrderObj.Cpns;
                                                        var ordCpnLen = ordCpns.length || 0;
                                                        for (var a = 0; a < ordCpnLen; a++) {
                                                            if (ordCpns[a].MultiQualTtl && ordCpns[a].MultiQualTtl > 0) {
                                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' is not valid with other qualifying amount coupons.');
                                                                //use the i index here because you want to display the coupon name of the coupon that is trying to be added not the coupon from the cart already
                                                                return;
                                                            }
                                                        }
                                                    }

                                                    if (Ti.App.OrderObj && Ti.App.OrderObj.TempCpns) {
                                                        var ordCpns = Ti.App.OrderObj.TempCpns;
                                                        var ordCpnLen = ordCpns.length || 0;
                                                        for (var a = 0; a < ordCpnLen; a++) {
                                                            if (ordCpns[a].MultiQualTtl && ordCpns[a].MultiQualTtl > 0) {
                                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' is not valid with other qualifying amount coupons.');
                                                                //use the i index here because you want to display the coupon name of the coupon that is trying to be added not the coupon from the cart already
                                                                return;
                                                            }
                                                        }
                                                    }

                                                    var currentSubtotal = Ti.App.OrderObj.Subtotal || 0;
                                                    var cpnMinPrice = storeObj.Menu.Cpns[i].MultiQualTtl;
                                                    var cpnVal = storeObj.Menu.Cpns[i].CpnValue;
                                                    /*if(currentSubtotal < cpnMinPrice){
                                                     ro.ui.alert('Coupon Not Valid', 'You must have a minimum of $' + cpnMinPrice + ' in your cart prior to applying this coupon.');
                                                     return;
                                                     }*/
                                                }

                                                if (Ti.App.OrderObj.Cpns) {
                                                    if (Ti.App.OrderObj.Cpns.length > 0 && storeObj.Menu.Cpns[i].IsExclusive) {
                                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' coupon is not valid with any other coupon.');
                                                        return;
                                                    }
                                                    for (var idx = 0; idx < Ti.App.OrderObj.Cpns.length; idx++) {
                                                        if (Ti.App.OrderObj.Cpns[idx].IsExclusive) {
                                                            ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[idx].Name + ' coupon. This is not valid with any other coupon.');
                                                            return;
                                                        }
                                                        if (storeObj.Menu.Cpns[i].SingleUse) {
                                                            if (Ti.App.OrderObj.Cpns[idx].Name == storeObj.Menu.Cpns[i].Name) {
                                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied.');
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }

                                                switch(parseInt(storeObj.Menu.Cpns[i].CpnScope, 10)) {
                                                    case 1:
                                                        if (Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length > 0) {
                                                            for (var idx = 0; idx < Ti.App.OrderObj.Cpns.length; idx++) {
                                                                if (Ti.App.OrderObj.Cpns[idx].Name == storeObj.Menu.Cpns[i].Name) {
                                                                    ro.ui.alert('Coupon Not Valid', 'Your cart already has this coupon. It can only be applied once.');
                                                                    return;
                                                                }

                                                                if (Ti.App.OrderObj.Cpns[idx].CpnType == 2 && storeObj.Menu.Cpns[i].CpnType == 2) {
                                                                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                                                    return;
                                                                }
                                                            }
                                                        }

                                                        if (storeObj.Menu.Cpns[i].MinPrice > 0) {
                                                            var dcSubTot = 0;
                                                            if (Ti.App.OrderObj.Cpns) {
                                                                for (var k = 0; k < Ti.App.OrderObj.Cpns.length; k++) {
                                                                    if (Ti.App.OrderObj.Cpns[k].MinPrice > 0) {
                                                                        cpnFound = false;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                            dcSubTot = Ti.App.OrderObj.Subtotal;

                                                            if (dcSubTot < storeObj.Menu.Cpns[i].MinPrice) {
                                                                cpnFound = false;
                                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                                alertMessage = 'This coupon cannot be applied. Minimum order amount is: $' + storeObj.Menu.Cpns[i].MinPrice.toFixed(2);
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                    //case 2:
                                                    //break;
                                                    case 2:
                                                    case 3:
                                                    case 4:
                                                        if (!storeObj.Menu.Cpns[i].Items) {
                                                            cpnFound = false;
                                                            break;
                                                        }
                                                        else {
                                                        		if(!menuUtils.isCpnConfiguredProperly(storeObj.Menu.Cpns[i])){
									                    			ro.ui.alert('Invalid Coupon. ', 'The store has not configured this coupon properly.');
									                    			ro.ui.hideLoader();
									                    			return;
									                    		}
                                                        	
                                                            if (storeObj.Menu.Cpns[i].Items.length > 0) {
                                                                if (parseInt(storeObj.Menu.Cpns[i].CpnScope, 10) == 4) {
                                                                    if (storeObj.Menu.Cpns[i].SingleUse == true) {
                                                                        if (Ti.App.OrderObj.Items) {
                                                                            for (var itmLg = 0; itmLg < Ti.App.OrderObj.Items.length; itmLg++) {
                                                                                if (Ti.App.OrderObj.Items[itmLg].CpnObj && Ti.App.OrderObj.Items[itmLg].CpnObj.SingleUseKey && (Ti.App.OrderObj.Items[itmLg].CpnObj.SingleUseKey == storeObj.Menu.Cpns[i].Key)) {
                                                                                    ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[i].Name + ' has already been applied.');
                                                                                    return;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                Ti.API.debug('thisCode: ' + thisCode);
                                                                Ti.API.debug('storeObj.Menu.Cpns[i].Key: ' + storeObj.Menu.Cpns[i].Key);
                                                                Ti.API.debug('storeObj.Menu.Cpns[' + i + ']: ' + JSON.stringify(storeObj.Menu.Cpns[i]));
                                                                menuUtils.saveTempValcode(thisCode, storeObj.Menu.Cpns[i].Key);
                                                                ro.App.cpnCodeMode.Flg = true;
                                                                ro.App.cpnCodeMode.Key = storeObj.Menu.Cpns[i].Key;
                                                                ro.App.cpnCodeMode.LoyaltyCode = LoyaltyCode;
                                                                ro.ui.cartShowNext({
                                                                    showing: 'Cart'
                                                                });
                                                                cpnFound = false;
                                                                //this is to prevent the addCoupon function call from still happening? which seems to happen from time to time....
                                                                return;
                                                            }
                                                            else {
                                                                cpnFound = false;
                                                                break;
                                                            }
                                                        }
                                                        break;
                                                }

                                                var curDate = new Date();
                                                var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
                                                var timeAtStore = menuUtils.getStoreTime(storeObj.TimeZone);

                                                if (storeObj.Menu.Cpns[i].Weekdays > 0) {
                                                    if (cpnFound == true) {
                                                        if (!menuUtils.WeekdayValid(storeObj.Menu.Cpns[i].Weekdays, timeAtStore)) {
                                                            var weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                                                            cpnFound = false;
                                                            alertTitle = storeObj.Menu.Cpns[i].Name;
                                                            alertMessage = 'This coupon is not valid on ' + weekDay[timeAtStore.getDay()] + '.';
                                                            break;
                                                        }
                                                    }
                                                }

                                                if (storeObj.Menu.Cpns[i].TimeIdx > 0) {
                                                    if (cpnFound == true) {
                                                        //if (!menuUtils.IsTimeValid(storeObj.Menu.Cpns[i].TimeIdx, storeObj.Menu.Cpns[i].StartTime, storeObj.Menu.Cpns[i].EndTime, timeAtStore)) {
                                                            if (!menuUtils.IsTimeValid(storeObj.Menu.Cpns[i].TimeIdx, storeObj.Menu.Cpns[i].StartTimeStr, storeObj.Menu.Cpns[i].EndTimeStr, timeAtStore)) {
                                                                cpnFound = false;
                                                                var sTime = menuUtils.xmlDateToJavascriptDate(storeObj.Menu.Cpns[i].StartTimeStr);
                                                                var eTime = menuUtils.xmlDateToJavascriptDate(storeObj.Menu.Cpns[i].EndTimeStr);
                                                                var startTime = ro.utils.getFormattedTime(sTime);
                                                                var endTime = ro.utils.getFormattedTime(eTime);
                                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                                alertMessage = 'This coupon is only valid between ' + startTime + '-' + endTime + '.';
                                                                break;
                                                            }
                                                        //}
                                                    }
                                                }

                                                if (storeObj.Menu.Cpns[i].HasExcldOrdType) {
                                                    if (storeObj.Menu.Cpns[i].ExcldOrdTypes) {
                                                        for (var l = 0; l < storeObj.Menu.Cpns[i].ExcldOrdTypes.length; l++) {
                                                            if (storeObj.Menu.Cpns[i].ExcldOrdTypes[l] == curOrdType) {
                                                                cpnFound = false;
                                                                alertTitle = storeObj.Menu.Cpns[i].Name;
                                                                alertMessage = 'The coupon is not valid for ' + curOrdType + ' order type.';
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                coupon = storeObj.Menu.Cpns[i];
                                                break;
                                            }
                                        }// End for j (valcodes)

                                        if (cpnFound) {
                                            break;
                                        }
                                    } // End if ReqValCode
                                } // End for i
                            }
                        }

                        if (cpnFound) {
                            addCoupon(coupon, thisCode, theLoyaltyCode);
                        }
                        else {
                            ro.ui.alert(alertTitle, alertMessage);
                        }
                    }
                    catch(ex) {
                        ro.ui.alert('Coupons', 'CODE AC100');
                    }
                }


                applyBtn.addEventListener('click', function(e) {
                    if (ro.REV_LOYALTY.isValidCode(codeTxt.value)) {
                        ro.REV_LOYALTY.validateCoupon(codeTxt.value, ro.app.Store.ID, function(newCode, LoyaltyCode) {
                            APPLY_COUPON(newCode, LoyaltyCode);
                        }, true, false, function(){
                            APPLY_COUPON();
                        });
                    }
                    else {
                        APPLY_COUPON();
                    }
                });

                function couponChange(e) {
                    if (e.rowIndex == 0) {
                        toggleVisibility((couponsData.length > 0 ? true : false), false);
                    }
                    else {
                        if (e.rowIndex == 1) {
                            toggleVisibility(false, true);
                        }
                    }
                };

                DisplayCoupons();

                if (!tblItems.data || !tblItems.data.length) {
                    itemsView.add(noCouponsLbl);
                }

                //itemsView.add(codeLbl);
                //itemsView.add(codeTxt);
                //itemsView.add(applyBtn);
                itemsView.add(tblItems);
                mainView.add(itemsView);
                return mainView;
            }
            catch(ex) {
                Ti.API.info('ex: ' + ex);
                ro.ui.alert('Coupons', 'CODE 100');
            }
        };
    };
    return {
        couponview: couponview
    };
}();
module.exports = COUPONVIEW;
