var FUTUREORDERVIEW = function(){
	var futureorderview = function(ro){
	   var dateForm = require('formControls/fullDateForm').dateForm(ro);
	   ro.ui.createNewFutureOrdView = function(_args){
	   	  try{
	   	      
            if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
                  //Ti.API.info('Ti.App.OrderObj.Items.length: ' + Ti.App.OrderObj.Items.length);
                  ro.updateCartCount(Ti.App.OrderObj.Items.length);
              }
              else{
                  ro.updateCartCount(0);
              }	   	      
	   	      
	   	  	var futureTimeObj = {};
	   	  	var futureTimePicker;
	   	  	if(ro.isiOS){
	   	  	    futureTimePicker = Ti.UI.createPicker({
                    selectionIndicator: true,
                    type:Ti.UI.PICKER_TYPE_PLAIN,
                    top:ro.isiOS ? 13 : 0,
                    //zIndex:55,
                    //useSpinner:true
                });
	   	  	}
	   	  	else{
	   	  	    futureTimePicker = Ti.UI.createPicker({
                    selectionIndicator: true,
                    type:Ti.UI.PICKER_TYPE_PLAIN,
                    top:ro.isiOS ? 13 : 0
                });
	   	  	}
	   	  	
			//if(true){
				futureTimePicker.width = Ti.UI.FILL;
				futureTimePicker.height = Ti.UI.FILL;
			//}	
	   	  	
	         var backBtn = layoutHelper.getBackBtn('BACK');
	         backBtn.addEventListener('click', function(e){
	         	ro.GlobalPicker.hidePicker();
	            if(Ti.App.atPayScrn){
	               ro.ui.cartShowNext({ showing:'futOrd' });
	            }
	            else{
	               ro.utils.removeProp('futureOrder');
	               ro.ui.ordShowNext({ showing:'futOrd' });
	            }
	         });
	         var mainView = layoutHelper.getMainView('futOrd'/*hid*/, 'Order Time'/*Top Title*/, !Ti.App.atPayScrn?layoutHelper.getLogoutBtn():null/*right Button*/, null/*left button*/, true/*vertical or not*/, backBtn/*customBtn*/);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL) { Ti.API.debug('ordTypeView()-Exception: ' + ex); }
	      }
	      
	      var view = Ti.UI.createScrollView({
                top:0,
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                disableBounce:true,
                layout: 'vertical',
                contentWidth:Ti.UI.FILL
            });
	      
	      var bannerView = REV_BANNERS.getBannerView("futureorder.png");
	        
	        if(!bannerView){
	            
            }
            else{
                
                bannerView.top = ro.ui.relY(5);
                view.add(bannerView);
            }
	        
            var bottomView = Ti.UI.createView({
                height:Ti.UI.SIZE,
                width:ro.ui.properties.wideViewWidth,
                layout: 'vertical'
            });
            
	      var nowOrFutTxt = Ti.App.futureOnly ? "Future?" : "Now or Future?";
	      
	      bottomView.add(Ti.UI.createLabel({
            text:nowOrFutTxt,
            font: ro.ui.font.pathToMenuTitles,
            textAlign:'center',
            color:ro.ui.theme.orderTypeBgTxt,
            width:Ti.UI.FILL,
            top:ro.ui.relY(10)
          }));
	      
	      bottomView.add(Ti.UI.createLabel({
            text:'Choose your time',
            font:{
               fontSize:ro.ui.scaleFont(18),
               fontFamily:ro.ui.fonts.rowBodyTxt
            },
            textAlign:'center',
            color:ro.ui.theme.orderTypeBgTxt,
            width:Ti.UI.FILL,
            top:ro.ui.relY(7)
          }));
          
          var buttonView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.SIZE,
                layout: 'horizontal'
            });
	     var nowBtn = Ti.UI.createView({
	           top:ro.ui.relY(15),
               height:ro.ui.properties.wideViewWidth * .49,
               width:ro.ui.properties.wideViewWidth * .49,
			   backgroundImage: '/images/nowBtn.png',
			   accessibilityLabel: 'Place order now',
			   accessibilityHint: 'Button'
          });
	     
			nowBtn.addEventListener('click', function() {
				ro.GlobalPicker.hidePicker();
				var payControl = require('controls/paymentControl');
				ro.utils.removeProp('futureTimeObj');
				payControl.clearFutureOrder();
				try {
					if (Ti.App.atPayScrn === true) {
						ro.ui.cartShowNext({
							addView : true,
							showing : 'paymentScreen'
						});
					}
					else {
						ro.ui.ordShowNext({
							addView : true,
							showing : 'grpsItems'
						});
					}
				}
				catch(ex) {
					if (Ti.App.DEBUGBOOL) {
						Ti.API.debug('submitBtnEvent-Exception: ' + ex);
					}
				}
			}); 
            if(!Ti.App.futureOnly){
                var leftView =  Ti.UI.createView({
                    height:Ti.UI.SIZE,
                    width:ro.ui.properties.wideViewWidth / 2
                });
                leftView.add(nowBtn);
                buttonView.add(leftView);
	        }
	      
	      var futureBtn = Ti.UI.createView({
	          top:ro.ui.relY(15),
               height:ro.ui.properties.wideViewWidth * .49,
               width:ro.ui.properties.wideViewWidth * .49,
			   backgroundImage: '/images/futureBtn.png',
			   accessibilityLabel: 'Place Order in the Future',
			   accessibilityHint: 'Button'
          });
	      futureBtn.addEventListener('click', function(){
	        if(ro.isiOS){
    			ro.GlobalPicker.setPicker(futureTimePicker, getToolbar());
    			if(!ro.isiOS){
    				var customHeight = ro.ui.relY(150);
    	      	    ro.GlobalPicker.showPicker(customHeight);
    			}
    			else{
    	      	 	ro.GlobalPicker.showPicker();
    			}
    			
    			if(Ti.App.Properties.hasProperty('futureTimeObj')){
                    futureTimeObj = JSON.parse(Ti.App.Properties.getString('futureTimeObj', '{}'));
                    futureTimePicker.setSelectedRow(2, futureTimeObj.min, false);
                    futureTimePicker.setSelectedRow(1, futureTimeObj.hr, false);
                    futureTimePicker.setSelectedRow(0, futureTimeObj.day, false);
                    
                }
                else{
                    futureTimePicker.setSelectedRow(0, 0, false);
                    futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, false);
                    futureTimePicker.setSelectedRow(1, boundaries.minHrIndex, false);
                }
            }
            else{
                //view.add(futureTimePicker);
                bottomFutureView.show();
                btnWrapper.show();
            }
			
	      });
	      var rightView = Ti.UI.createView({
	          height:Ti.UI.SIZE,
              width:ro.ui.properties.wideViewWidth / 2
	      });
	      rightView.add(futureBtn);
	      buttonView.add(rightView);
	     bottomView.add(buttonView);
            view.add(bottomView);
            function getFuturePickers(defaultText, pickRowData, pickChangeEvt){
                //Ti.API.info('pickRowData: ' + JSON.stringify(pickRowData));
                var pickerParent = Ti.UI.createView({
                   width: "33%",//ro.ui.properties.wideViewWidth * .30,
                   height:ro.ui.relY(60)
                });
                var picker = Ti.UI.createPicker(ro.combine(ro.ui.properties.allTxtField,{
                    type:Ti.UI.PICKER_TYPE_PLAIN,
                    height:Ti.UI.FILL,
                    focusable:true,
                    selectionOpens:true,
                    zindex:5,
                    width:Ti.UI.FILL,
                    opacity:0,
                    backgroundColor:'white'
                }));
                picker.add(pickRowData);
                
                if(pickChangeEvt){
                    picker.addEventListener('change', pickChangeEvt);
                }
                
                var fieldObject = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
                    height:ro.ui.relY(40),
                    //width:ro.ui.relX(325),
                    //top:ro.ui.relY(0),
                    //bottom:ro.ui.relY(25),
                    text:defaultText,
                    textData:defaultText,
                    picker:picker,
                    specialType:'iospicker',
                    width: "95%"//ro.ui.properties.wideViewWidth * .31
                }));
                var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                    text:defaultText,
                    textData:defaultText,
                    left:ro.ui.relX(13),
                    touchEnabled:false
                }));
                var arrowImg = Ti.UI.createImageView({
                    image:'/images/downArrow.png',
                    height:ro.ui.relY(30),
                    width:ro.ui.relY(30),
                    right:ro.ui.relX(5),
                    touchEnabled:false
                });
                fieldObject.add(lbl);
                fieldObject.add(arrowImg);
                fieldObject.add(fieldObject.picker);
                
                function setLblText(newTxt, newTxtData){
                    fieldObject.text = newTxt;
                    fieldObject.textData = newTxtData;
                    lbl.text = newTxt;
                    lbl.textData = newTxtData;
                }
                //fieldObject.setLblText = setLblText;
                pickerParent.setLblText = setLblText;
                pickerParent.add(fieldObject);
                pickerParent.getChosenRow = function(){
                    Ti.API.info('fieldObject.picker.getSelectedRow(0): ' + JSON.stringify(fieldObject.picker.getSelectedRow(0)));
                    return fieldObject.picker.getSelectedRow(0);
                };
                return pickerParent;
            }
            if(!ro.isiOS){
                var bottomFutureView = Ti.UI.createView({
                    layout:'horizontal',
                    height:ro.ui.relY(50),
                    width:ro.ui.properties.wideViewWidth,
                    visible:false
                });
                var btnContinue = layoutHelper.getBigButton('Continue');
                  var btnWrapper = ro.layout.getBtnWrapper();
                  btnWrapper.top = ro.ui.relY(20);
                  btnWrapper.hide();
                  btnWrapper.add(btnContinue);
                  
                  
                btnContinue.addEventListener('click', function(e) {
                    ro.GlobalPicker.hidePicker();
                    ro.ui.showLoader();
                    //Ti.include('/validation/addressValidation.js');
                    if (!ro.isiOS)
                        Ti.UI.Android.hideSoftKeyboard();

                    var dayRow = bottomFutureView.children[0].getChosenRow();
                    var hrRow = bottomFutureView.children[1].getChosenRow();
                    var minRow = bottomFutureView.children[2].getChosenRow();

                    futureTimeObj = {};

                    futureTimeObj.day = dayRow.id;
                    futureTimeObj.hr = hrRow.id;
                    futureTimeObj.min = minRow.id;
                    futureTimeObj.dateValue = dayRow.obj.date;
                    futureTimeObj.hrValue = hrRow.val;
                    futureTimeObj.minValue = minRow.title;
                    futureTimeObj.dateText = dayRow.title;

                    var hourParts = hrRow.title.split(" ");
                    var timeText = hourParts[0] + ":" + minRow.title + " " + hourParts[1];

                    futureTimeObj.timeText = timeText;

                    Ti.App.Properties.setString('futureTimeObj', JSON.stringify(futureTimeObj));
                    
                    ro.ui.ordShowNext({
                        addView : true,
                        showing : 'grpsItems'
                    });
                    
                }); 

                  
                view.add(bottomFutureView);
                view.add(btnWrapper);
            }
            
            mainView.add(view);
	      
	      var boundaries;
	      
	      var TIME_PICKER = require('logic/timePicker');
			TIME_PICKER.formDateTime(futureTimePicker, function(dayArray, hrArray, minArray, bounds) {
				//var minCol = [], hrCol = [], dayCol = [];                
				if(ro.isiOS){
				    if(bounds){
                        boundaries = bounds;
                    }
                    var dayCol = Ti.UI.createPickerColumn();
                    var hrCol = Ti.UI.createPickerColumn();
                    var minCol = Ti.UI.createPickerColumn();
                    //if(!ro.isiOS){
                    //    dayCol.width = ro.ui.displayCaps.platformWidth * .33;
                    //    hrCol.width = ro.ui.displayCaps.platformWidth * .33;
                    //    minCol.width = Ti.UI.FILL;
                    //}
                    
                    if (dayArray.length) {
                        boundaries = dayArray[0];
                        for (var i = 0; i < minArray.length; i++) {
                            minCol.addRow(Ti.UI.createPickerRow({
                                title : minArray[i].toString(),
                                id : i
                            }));
                        }
    
                        for (var i = 0; i < hrArray.length; i++) {
    
                            hrCol.addRow(Ti.UI.createPickerRow({
                                title : hrArray[i].disp,
                                val : hrArray[i].val,
                                id : i
                            }));
                        }
    
                        for (var i = 0; i < dayArray.length; i++) {
    
                            dayCol.addRow(Ti.UI.createPickerRow({
                                title : dayArray[i].disp,
                                obj : dayArray[i],
                                id : i
                            }));
                        }
    
                        futureTimePicker.add([dayCol, hrCol, minCol]);
                        //if(ro.isiOS){
                        ro.GlobalPicker.setPicker(futureTimePicker, getToolbar());
                        //}
                        
                    }
				}
				else{
				    function getDayRows(rowData){
				        var rows = [];
				        for(var i=0, iMax=rowData&&rowData.length?rowData.length:0; i<iMax; i++){
				           rows.push(Ti.UI.createPickerRow({
				              // color:'#393839',
				               //backgroundColor:'white',
                                title : rowData[i].disp,
                                obj : rowData[i],
                                id : i
                            }));
				        }
				        
				        return rows;
				    }
				    function getHrRows(rowData, dayConstraint){
				        var rows = [];
                        for(var i=dayConstraint.minHrIndex, iMax=dayConstraint.maxHrIndex; i<=iMax; i++){
                           rows.push(Ti.UI.createPickerRow({
                                title : rowData[i].disp,
                                val : rowData[i].val,
                                id : i,
                                minMinIndex:i===dayConstraint.minHrIndex ? dayConstraint.minMinIndex : 0,
                                maxMinIndex:i === dayConstraint.maxHrIndex ? dayConstraint.maxMinIndex : 0
                           }));
                        }
                        return rows;
                    }
                    function getMinRows(rowData, dayConstraint, maxMin){
                        var rows = [];
                        var maxI = rowData&&rowData.length?rowData.length-1:0;
                         if(maxMin && maxMin.maxMinIndex){
                            maxI = maxMin.maxMinIndex;
                         }
                        if (dayConstraint) {
                            for (var i = dayConstraint.minMinIndex, iMax = maxI; i <= iMax; i++) {
                                rows.push(Ti.UI.createPickerRow({
                                    title: rowData[i].toString(),
                                    id: i
                                }));
                            }
                        }
                        
                        return rows;
                    }
                    var minChangeFn = function(e){
                        var selRow = e.source.getSelectedRow(0);
                        if (selRow) {
                            var minutePicker = bottomFutureView.children[2];
                            minutePicker.setLblText(selRow.title, selRow.title);
                        }
                    };
                    var hrChangeFn = function(e){
                        var selRow = e.source.getSelectedRow(0);
                        if (selRow) {
                            //var maxMin = bottomFutureView.children[0].getChosenRow().obj.maxMinIndex;
                            var minutePicker = bottomFutureView.children[2];
                            bottomFutureView.remove(minutePicker);

                            var minArrayConstraint = { minMinIndex: selRow.minMinIndex };
                            var maxArrayConstraint = { maxMinIndex: selRow.maxMinIndex };
                            bottomFutureView.add(getFuturePickers(minArray[selRow.minMinIndex].toString(), getMinRows(minArray, minArrayConstraint, maxArrayConstraint), minChangeFn));

                            var hourPicker = bottomFutureView.children[1];
                            hourPicker.setLblText(selRow.title, selRow.title);
                        }
                    };
				    var dayChangeFn = function(e){
                        var selRow = e.source.getSelectedRow(0);
                        if (selRow) {
                            var maxMin = selRow.obj.maxMinIndex;
                            var hourPicker = bottomFutureView.children[1];
                            var minutePicker = bottomFutureView.children[2];
                            bottomFutureView.remove(minutePicker);
                            bottomFutureView.remove(hourPicker);

                            bottomFutureView.add(getFuturePickers(hrArray[selRow.obj.minHrIndex].disp, getHrRows(hrArray, selRow.obj), hrChangeFn));
                            bottomFutureView.add(getFuturePickers(minArray[selRow.obj.minMinIndex].toString(), getMinRows(minArray, selRow.obj), minChangeFn));

                            var dayPicker = bottomFutureView.children[0];
                            dayPicker.setLblText(selRow.title, selRow.title);
                        }
				    };
                    //Ti.API.info("dayArray: " + JSON.stringify(dayArray));
                    if (dayArray && dayArray.length) {
                        bottomFutureView.add(getFuturePickers(dayArray[0].disp, getDayRows(dayArray), dayChangeFn));
                        bottomFutureView.add(getFuturePickers(hrArray[dayArray[0].minHrIndex].disp, getHrRows(hrArray, dayArray[0]), hrChangeFn));
                        bottomFutureView.add(getFuturePickers(minArray[dayArray[0].minMinIndex].toString(), getMinRows(minArray, dayArray[0]), minChangeFn));
                    }
				}
				

			});
			
			function getToolbar(){
				var picToolbar = ro.isiOS ? Ti.UI.createToolbar({
						top : 0,
						zIndex : 2,
						width : Ti.UI.FILL
					}) : Ti.UI.createView({
						width:Ti.UI.FILL,
						height:ro.ui.relY(40),
						top:0
				});
				var picCancel = Ti.UI.createButton({
					title : 'Cancel',
					id : 1,
					left:ro.ui.relX(20)
				});
				var picDone = Ti.UI.createButton({
					title : 'Done',
					id : 0,
					right:ro.ui.relX(20)
				});
				picCancel.addEventListener('click', function(){
					ro.GlobalPicker.hidePicker();
				});
				picDone.addEventListener('click', function(){
					
					var dayRow = futureTimePicker.getSelectedRow(0);
					var hrRow = futureTimePicker.getSelectedRow(1);
					var minRow = futureTimePicker.getSelectedRow(2);
					if(hrRow.id < dayRow.obj.minHrIndex 
                    		|| hrRow.id > dayRow.obj.maxHrIndex
                    		|| (hrRow.id === dayRow.obj.minHrIndex && minRow.id < dayRow.obj.minMinIndex)
                    		|| (hrRow.id === dayRow.obj.maxHrIndex && minRow.id > dayRow.obj.maxMinIndex)) return;
					futureTimeObj = {};
					
					futureTimeObj.day = dayRow.id;
					futureTimeObj.hr = hrRow.id;
					futureTimeObj.min = minRow.id;
					futureTimeObj.dateValue = dayRow.obj.date;
					futureTimeObj.hrValue = hrRow.val;
					futureTimeObj.minValue = minRow.title;
					//futureTimeObj.dateText = 
					//futureTimeObj.timeText = 
					futureTimeObj.dateText = dayRow.title;
						var hourParts = hrRow.title.split(" ");
						var timeText = hourParts[0] + ":" + minRow.title + " " + hourParts[1];
					
					//timePicker.setPickText(timeText);
						futureTimeObj.timeText = timeText;
					
					Ti.App.Properties.setString('futureTimeObj', JSON.stringify(futureTimeObj));
					
					
					
					ro.GlobalPicker.hidePicker();
					
					if (Ti.App.atPayScrn === true) {
						ro.ui.cartShowNext({
							addView : true,
							showing : 'paymentScreen'
						});
					}
					else {
						ro.ui.ordShowNext({
							addView : true,
							showing : 'grpsItems'
						});
					}
					
				});
				
				
				if(ro.isiOS){
					var picSpacer = Ti.UI.createButton({
						systemButton : Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
					});
					picDone.style = Ti.UI.iOS.SystemButtonStyle.DONE;
					picCancel.style = Ti.UI.iOS.SystemButtonStyle.DONE;
					//picToolbar.add(picSpacer);
					picToolbar.items = [picCancel, picSpacer, picDone];
				}
				else{
					picToolbar.add(picCancel);
					picToolbar.add(picDone);
				}
				
				
				return picToolbar;
			}
			
	      //Ti.API.debug('returning: futureorder');
	      return mainView;
	   };
	   

		

	   ro.ui.createFutureOrdView = function(_args){
	   	ro.ui.showLoader();
	   	
	      try{
	         var backBtn = layoutHelper.getBackBtn('BACK');
	         backBtn.addEventListener('click', function(e){
	            if(Ti.App.atPayScrn){
	               ro.ui.cartShowNext({ showing:'futOrd' });
	            }
	            else{
	               ro.utils.removeProp('futureOrder');
	               ro.ui.ordShowNext({ showing:'futOrd' });
	            }
	         });
	         var mainView = layoutHelper.getMainView('futOrd'/*hid*/, 'Order Time'/*Top Title*/, !Ti.App.atPayScrn?layoutHelper.getLogoutBtn():null/*right Button*/, null/*left button*/, true/*vertical or not*/, backBtn/*customBtn*/);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL) { Ti.API.debug('ordTypeView()-Exception: ' + ex); }
	      }
	
			var orderTmScroll = Ti.UI.createScrollView({
				top:ro.ui.relY(35),//65
				height:Ti.UI.SIZE,
				//bottom:ro.ui.relY(30),
				layout:'vertical',
				left:ro.ui.relX(5),
				right:ro.ui.relX(5),
				disableBounce:ro.isiOS ? true : false
			});
			var orderTmView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallTblView, {
				layout:'vertical',
				backgroundColor:'transparent'//,
				//backgroundColor:'yellow'
			}));
			var hdrLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:'CHOOSE YOUR ORDER TIME:',
	         left:ro.ui.relX(10),
	         font:{
	            fontSize:ro.ui.scaleFont(15, 0, 0),//16
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }
	      }));
			
			var hdrView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	         focusable:false
	      }));
			var hdrImgView = Ti.UI.createImageView({
				image:'/images/calendar.png',
				height:ro.ui.relY(40),
				width:ro.ui.relY(40),
				left:ro.ui.relX(5)
			});
			hdrView.add(hdrLbl);
	
			var isFut = isFuture() || Ti.App.futureOnly;
			var selectionView = Ti.UI.createView({
				height:Ti.UI.SIZE,
				top:ro.ui.relY(5),
				right:ro.ui.relX(10),
				left:ro.ui.relX(10),
				layout:'vertical'
			});
			mainView.add(orderTmView);
	
			var futRows = [];
			var yesFuture = Ti.UI.createTableViewRow({
				className:'futRow',
				height:ro.ui.relY(50),
				hasCheck:isFut?true:false,
				layout:'vertical',
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
			});
			yesFuture.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
				text:'FUTURE',
				top:ro.ui.relY(7),
				color:ro.ui.theme.contentsTextColor
			})));
			var noFuture = Ti.UI.createTableViewRow({
				className:'futRow',
				height:ro.ui.relY(50),
				hasCheck:isFut?false:true,
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
			});
	
			noFuture.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
				text:'NOW',
				top:ro.ui.relY(7),
				color:ro.ui.theme.contentsTextColor
			})));
			var futureTblHeight = ro.ui.relY(50);
			if(!Ti.App.futureOnly){
				futureTblHeight = ro.ui.relY(100);
				futRows.push(noFuture);
			}
			futRows.push(yesFuture);
	
			var futPickerViewObj = futurePicker();
			var futPickerView = futPickerViewObj.Pick;
			var dispLbl = futPickerViewObj.Display;
			yesFuture.add(dispLbl);
	
	
			var futOrdTbl = Ti.UI.createTableView({
				data:futRows,
				height:futureTblHeight,
				backgroundColor:'white',
				width:Ti.UI.FILL,
				separatorColor:ro.ui.theme.separatorColor,
				borderColor:ro.ui.theme.separatorColor,
				borderWidth:ro.ui.relX(1),
				minRowHeight:ro.ui.relY(40)
			});
	
			if(!Ti.App.futureOnly){
				futOrdTbl.addEventListener('click', function(e){
					try{
						if(e.index === 0){
							if(!e.row.hasCheck){
								var payControl = require('controls/paymentControl');
								e.row.hasCheck = true;
								//e.row.rightImage = '/images/check.png';
								yesFuture.hasCheck = false;
								//yesFuture.rightImage = '';
	
								ro.utils.removeProp('futureOrder');
								payControl.clearFutureOrder();
	
	                    		 timeView.hide();
								futPickerView.hide();
								dispLbl.hide();
								dateForm.resetPickers();
							}
						}
						else{
							if(!e.row.hasCheck){
	
								e.row.hasCheck = true;
								//e.row.rightImage = '/images/check.png';
								noFuture.hasCheck = false;
								//noFuture.rightImage = '';
	
								timeView.show();
								dispLbl.show();
								futPickerView.show();
							}
						}
					}
					catch(ex){
						if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('futOrdTbl-Event-Exception: ' + ex); }
					}
				});
			}
	
			var btnView = Ti.UI.createView({
			   top:ro.ui.relY(25),
			   bottom:ro.ui.relY(15),
				height:Ti.UI.SIZE
			});
			var currBtn = layoutHelper.getBigButton('CHOOSE & CONTINUE');
	
			currBtn.addEventListener('click', function(e){
				try{
					if(Ti.App.futureOnly){
						dateForm.submitClick();
					}
					else{
						if(noFuture.hasCheck === true){
							if(Ti.App.atPayScrn === true){
								ro.ui.cartShowNext({ addView:true, showing:'paymentScreen' });
							}
							else{
								if(Ti.App.RepeatLastOrder){
								   ro.ui.ordShowNext({addView:true, showing:'itemsView'});
								}
								else{
								   ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
								}
							}
						}
						else{
							dateForm.submitClick();
						}
					}
		      }
		      catch(ex){
		      	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('submitBtnEvent-Exception: ' + ex); }
		      }
			});
			btnView.add(currBtn);
	
			var timeView = Ti.UI.createView({
				height:Ti.UI.SIZE,
				top:ro.ui.relY(30),
				width:Ti.UI.FILL,
				layout:'vertical',
				visible:false
			});
	
			timeView.add(futPickerView);
			selectionView.add(hdrView);
			selectionView.add(futOrdTbl);
			orderTmScroll.add(selectionView);
			orderTmScroll.add(timeView);
			orderTmScroll.add(btnView);
			//orderTmScroll.backgroundColor = 'blue';
			orderTmView.add(orderTmScroll);
			//mainView.add(btnView);
			//orderTmView.add(btnView);
	
	
			if(isFut || Ti.App.futureOnly){
			   timeView.show();
				futPickerView.show();
				dispLbl.show();
			}
			return mainView;
		};
		function futurePicker(){
			//Ti.include('/formControls/fullDateForm.js');
			return dateForm.getFullDateForm();
		}
		function isFuture(){
			return Ti.App.Properties.hasProperty('futureOrder')?true:false;
		}
	};
	return {
		futureorderview:futureorderview
	};
}();
module.exports = FUTUREORDERVIEW;
