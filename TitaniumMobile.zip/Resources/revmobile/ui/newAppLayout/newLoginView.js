var LOGIN = function() {
    var loginview = function(ro) {

        ro.ui.createLoginView = function(_args) {
            var defaultCustomer = ro.db.getDefaultCustomer();
            //var defaultCustomer;
            var remember = true;

            var mainView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.stretch, {
                name: 'login',
                layout: 'vertical',
                //backgroundColor: '#ffffff',
                backgroundImage: '/images/backgroundImg.png',
            }));

            var loginView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView, {
                height: Ti.UI.SIZE,
                layout: 'vertical'
            }));

            var navBar = Ti.UI.createView(ro.ui.properties.largeNavBar);
            mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, null, true));
            mainView.add(loginView);

            function getFontTestView(prop, font) {
                var a = Ti.UI.createView({
                    width: Ti.UI.FILL,
                    height: ro.ui.relY(50)
                });
                /*var b = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : ro.ui.relY(50)
                 });
                 var c = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : ro.ui.relY(50)
                 });
                 var d = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : ro.ui.relY(50)
                 });
                 var e = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : ro.ui.relY(50)
                 });
                 var f = Ti.UI.createView({
                 width : Ti.UI.FILL,
                 height : ro.ui.relY(50)
                 });*/
                a.add(Ti.UI.createLabel({
                    text: 'Hello my friend, this is ' + prop + ' font.',
                    color: 'black',
                    font: {
                        fontSize: ro.ui.scaleFont(20),
                        fontFamily: font
                    }
                    //width:Ti.UI.FILL,
                    //height:ro.ui.relY(150)
                }));
                /*b.add(Ti.UI.createLabel({
                 text : 'Hello my friend, this is Gotham Bold',//'Hello my friend, how are you today?',
                 color : 'black',
                 font : {
                 fontSize : ro.ui.scaleFont(20),
                 fontFamily : ro.ui.fontTest.Gotham.bold
                 }
                 //width:Ti.UI.FILL,
                 //height:ro.ui.relY(150)
                 }));
                 c.add(Ti.UI.createLabel({
                 text : 'Hello my friend, this is no font family',//'Hello my friend, how are you today?',
                 color : 'black',
                 font : {
                 fontSize : ro.ui.scaleFont(20)//,
                 //fontFamily : ro.ui.fonts.button
                 }
                 //width:Ti.UI.FILL,
                 //height:ro.ui.relY(150)
                 }));
                 d.add(Ti.UI.createLabel({
                 text : 'Hello my friend, this is Garage Gothic Bold',//'Hello my friend, This is Garage Gothic Bold.',
                 //width:Ti.UI.FILL,
                 color : 'black',
                 font : {
                 fontSize : ro.ui.scaleFont(20),
                 fontFamily:ro.ui.fontTest.GarageGothic.bold
                 }
                 //height:ro.ui.relY(150)
                 }));
                 e.add(Ti.UI.createLabel({
                 text : 'Hello my friend, This is Garage Gothic Black.',
                 //width:Ti.UI.FILL,
                 color : 'black',
                 font : {
                 fontSize : ro.ui.scaleFont(20),
                 fontFamily:ro.ui.fontTest.GarageGothic.black
                 }
                 //height:ro.ui.relY(150)
                 }));
                 f.add(Ti.UI.createLabel({
                 text : 'Hello my friend, This is Garage Gothic regular.',
                 //width:Ti.UI.FILL,
                 color : 'black',
                 font : {
                 fontSize : ro.ui.scaleFont(20),
                 fontFamily:ro.ui.fontTest.GarageGothic.regular
                 }
                 //height:ro.ui.relY(150)
                 }));*/
                loginView.add(a);
                /*loginView.add(b);
                 loginView.add(c);
                 loginView.add(d);
                 loginView.add(e);
                 loginView.add(f);*/

            }

            /*for(var prop in ro.ui.fonts){
             getFontTestView(prop, ro.ui.fonts[prop]);
             }

             return mainView;*/
            var data = [];

            function login(username, pass, openNextView) {
                ro.REV_STORES.clearStore();

                var storeObj = null;
                var req = {};

                req.UserName = username;
                req.Password = pass;
                req.RevKey = 'test';
                req.Version = '';
                req.StoreID = 0;
                req.CompressResponse = false;

                ro.ui.showLoader();
                try {
                    var isDemo = false;
                    if (false && username == 'demo@revention.com') {
                        //var file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, 'demo.json');
                        //var contents = file.read();
                        //storeObj = eval('(' + contents.text + ')');
                        req.StoreID = storeObj.ID;
                        req.Version = storeObj.Version;
                        req.IsDemo = true;
                        isDemo = true;
                        //Ti.App.Properties.setString('DefaultStore', contents.text);
                        ro.REV_STORES.setDefaultStore(JSON.parse(contents.text));
                    }

                    if (Ti.App.Properties.hasProperty('DefaultStore') && !isDemo) {
                        storeObj = ro.REV_STORES.getDefaultStore();
                        req.StoreID = storeObj.ID;
                        req.Version = storeObj.Version;
                        req.IsDemo = false;
                        //Ti.API.debug('storeObj: ' + JSON.stringify(storeObj));
                        //ro.app.Store = storeObj;
                    }
                }
                catch(ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('loginView-Exception: ' + ex);
                    }
                    req.StoreID = 0;
                    req.Version = '';
                }

                ro.dataservice.post(req, 'cLogin_Json', function(response) {
                    if (response) {
                        if (response.Value) {

                            REV_Suggest.resetModule();

                            Ti.App.TimeAtDefStore = null;
                            Ti.App.Username = username;
                            Ti.App.Password = pass;
                            var storeID = req.StoreID;

                            //deb.ug(response, 'response');

                            if (response.Store) {
                                //Ti.App.Properties.setString('DefaultStore', JSON.stringify(response.Store));
                                //ro.app.Store = response.Store;
                                ro.REV_STORES.setDefaultStore(response.Store, true);
                                storeID = response.Store.ID;
                                if (response.Store.Configuration) {
                                    Ti.App.Properties.setString('Config', JSON.stringify(response.Store.Configuration));
                                }
                            }
                            if (response.Holidays) {
                                var currStore = ro.REV_STORES.getDefaultStore();
                                if (!currStore) {
                                    currStore = {};
                                }
                                var tempStore = currStore;
                                tempStore.Holidays = response.Holidays;
                                currStore = tempStore;
                                //Ti.App.Properties.setString('DefaultStore', JSON.stringify(currStore));
                                ro.REV_STORES.setDefaultStore(currStore);
                                tempStore = null;
                            }
                            /*if(response.Hours){
                             Ti.API.debug('response.Hours: ' + JSON.stringify(response.Hours));
                             var strObj = Ti.App.Properties.getString('DefaultStore');

                             }*/
                            if (response.Config) {
                                Ti.App.Properties.setString('Config', JSON.stringify(response.Config));
                                if (Ti.App.Properties.hasProperty('DefaultStore')) {
                                    var defStore = ro.REV_STORES.getDefaultStore();
                                    if (defStore) {
                                        //Ti.API.debug('Config is being overridden');

                                        var test = defStore;
                                        test.Configuration = null;
                                        test.Configuration = response.Config;
                                        defStore = test;
                                        //Ti.App.Properties.setString('DefaultStore', JSON.stringify(defStore));
                                        //ro.app.Store = ro.REV_STORES.getDefaultStore();
                                        ro.REV_STORES.setDefaultStore(defStore, true);
                                        test = null;
                                    }
                                }
                            }
                            if (response.CustomerInfo) {
                                if (response.Config || response.Store) {
                                    if (Ti.App.Properties.hasProperty('DefaultStore')) {
                                        var defStore = ro.REV_STORES.getDefaultStore();
                                        if (defStore) {
                                            //Ti.API.debug('Config is being overridden');

                                            var test = defStore;
                                            //test.Configuration = null;
                                            //test.Configuration = response.Config;
                                            test.Menu.OnlineOptions.DelivOpts.AddDelFee = response.CustomerInfo.AddDelFee;
                                            test.Menu.OnlineOptions.DelivOpts.ZoneName = response.CustomerInfo.ZoneName;
                                            if (response.CustomerInfo.TimeAtDefaultStore) {
                                                test.TimeAtStore = response.CustomerInfo.TimeAtDefaultStore;
                                            }
                                            defStore = test;

                                            ro.REV_STORES.setDefaultStore(defStore, true);
                                            test = null;
                                        }
                                    }
                                }

                                //deb.ug(response.CustomerInfo,'response.CustomerInfo');
                                //Ti.API.debug('response.CustomerInfo: ' + JSON.stringify(response.CustomerInfo));
                                if (response.CustomerInfo.CpnUsage) {
                                    var tmpCpns = response.CustomerInfo.CpnUsage.split("-");
                                    //Ti.API.debug('tmpCpns: ' + JSON.stringify(tmpCpns));
                                    if (tmpCpns && tmpCpns.length) {
                                        Ti.App.CpnUsageString = tmpCpns;
                                    }
                                    else {
                                        Ti.App.CpnUsageString = [];
                                    }
                                    //Ti.App.CpnUsageString = //response.CustomerInfo.CpnUsage.split("-");

                                }
                                else {
                                    Ti.App.CpnUsageString = [];
                                }

                                Ti.App.Properties.setString('Customer', JSON.stringify(response.CustomerInfo));
                                Ti.App.PrevOrders = response.CustomerInfo.PrevOrders;
                                Ti.App.LastOrdCnt = response.CustomerInfo.LastOrdCnt;

                                if (!isDemo && response.CustomerInfo.TimeAtDefaultStore) {
                                    Ti.App.TimeAtDefStore = response.CustomerInfo.TimeAtDefaultStore;
                                }

                                if (ro.db.getCustomer(username) != null) {
                                    ro.db.updateCustomer(username, req.Password, storeID, response.CustomerInfo, remember);
                                }
                                else {
                                    ro.db.createCustomer(username, pass, storeID, response.CustomerInfo, remember);
                                }

                                if (!isDemo && !response.Store) {
                                    if (response.CustomerInfo.Business_ID == 0 || (response.CustomerInfo.Business_ID !== req.StoreID)) {
                                        //ro.utils.removeProp('DefaultStore');
                                        ro.REV_STORES.clearDefaultStore();
                                    }
                                }

                                if(response.CustomerInfo.CardTokens){// Do not check the length and this can be empty list meaning delete all token cards
                                    try{
                                        var ccControl = require('controls/ccControl');
                                        ccControl.tokenUpdate(response.CustomerInfo.CardTokens, true, ro);
                                    }
                                    catch(ex){
                                        Ti.API.info("Card token Exception : " + JSON.stringify(ex));
                                    }
                                }
                            }
                            /*else{
                             Ti.App.CpnUsageString = null;
                             Ti.App.PrevOrders = null;
                             Ti.App.LastOrdCnt = null;
                             Ti.App.TimeAtDefStore = null;
                             }*/

                            

                            try {
                                if (openNextView) {
                                    Ti.App.fireEvent('app:login.success');
                                }
                            }
                            catch(ex) {
                                ro.ui.hideLoader();
                                ro.ui.alert('login.success ', ex);
                                deactivateButtons(activateButtons);
                                //btnSubmit.removeEventListener('click', btnSubmitEvt);
                                //newAccountBtn.removeEventListener('click', newAccountEvt);

                                //activateButtons();
                            }
                        }
                        else {
                            ro.ui.hideLoader();
                            if (openNextView) {
                                ro.ui.alert('Login Failed', response.Message);
                                deactivateButtons(activateButtons);
                            } else {
                                ro.ui.alert('Please Logout and Login', response.Message);
                            }
                            //btnSubmit.removeEventListener('click', btnSubmitEvt);
                            //newAccountBtn.removeEventListener('click', newAccountEvt);
                            

                            //activateButtons();
                        }
                    }
                    else {
                        ro.ui.hideLoader();
                        ro.ui.alert('Login Failed', 'Error occured. CODE:100.');
                        deactivateButtons(activateButtons);

                        //activateButtons();
                    }
                });
            }
            ro.login = login;
            data[0] = Ti.UI.createTableViewRow({
                className: 'login',
                height: ro.ui.relY(65), /*bottom:ro.ui.relY(5), top:ro.ui.relY(5), */
                layout: 'vertical',
                width:ro.ui.properties.wideViewWidth,
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            data[1] = Ti.UI.createTableViewRow({
                className: 'login',
                height: ro.ui.relY(65), /*bottom:ro.ui.relY(5), top:ro.ui.relY(5), */
                layout: 'vertical',
                width:ro.ui.properties.wideViewWidth,
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            /*data[2] = Ti.UI.createTableViewRow({ className:'remember', height:ro.ui.relY(50), bottom:ro.ui.relY(5), top:ro.ui.relY(5), layout:'horizontal' });

             data[0].add(Ti.UI.createLabel({
             text:'Email Address:',
             width:ro.ui.relX(90),
             height:ro.ui.relY(30),
             left:ro.ui.relX(5),
             font:{
             fontSize:ro.ui.scaleFont(15, 90, 30),//12
             fontFamily:ro.ui.fontFamily
             },
             color:ro.ui.theme.loginLittleTxt
             }));*/
            
			var getToolbar = function(keyboardBtnId, doneEvt, nextEvt) {
				var picNext = Ti.UI.createButton({
					title : 'Next',
					style : Ti.UI.iOS.SystemButtonStyle.DONE,
					id : keyboardBtnId
				});
				var picDone = Ti.UI.createButton({
					title : 'Done',
					style : Ti.UI.iOS.SystemButtonStyle.DONE,
					id : keyboardBtnId
				});

				var picSpacer = Ti.UI.createButton({
					systemButton : Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
				});

				var picToolbar = Ti.UI.createToolbar({
					top : 0,
					items : [picNext, picSpacer, picDone],
					zIndex : 2,
					width : Ti.UI.FILL
				});

				picDone.addEventListener('click', doneEvt);
				picNext.addEventListener('click', nextEvt);

				return picToolbar;
			};


            var txtUname = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                height: ro.ui.relY(45),
                width:ro.ui.properties.wideViewWidth,
                //width:ro.ui.relX(330),
                //left: ro.ui.relX(5),
                //right: ro.ui.relX(5),
                font: {
                    fontSize: ro.ui.scaleFont(17, 175, 30), //12
                    fontFamily:ro.ui.fonts.textFields
                },
                borderColor: ro.ui.theme.btnBorderDefault,
                keyboardType: Ti.UI.KEYBOARD_TYPE_EMAIL,
                returnKeyType: Ti.UI.RETURNKEY_NEXT,
                minimumFontSize: 4,
                passwordMask: 'false',
                borderWidth: ro.ui.relX(2),
                textAlign: 'center',
                hintText: 'Email Address',
                hintTextColor: '#e4e4e4'
            }));

            data[0].add(txtUname);

            /*data[1].add(Ti.UI.createLabel({
             text:'Password:',
             width:ro.ui.relX(90),
             height:ro.ui.relY(30),
             left:ro.ui.relX(5),
             font:{
             fontSize:ro.ui.scaleFont(15, 90, 30),//12
             fontFamily:ro.ui.fontFamily
             },
             color:ro.ui.theme.loginLittleTxt
             }));*/

            var txtPass = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                height: ro.ui.relY(45),
                width:ro.ui.properties.wideViewWidth,
                //left: ro.ui.relX(5),
               // right: ro.ui.relX(5),
                font: {
                    fontSize: ro.ui.scaleFont(17, 175, 30), //12
                    fontFamily:ro.ui.fonts.textFields
                },
                borderColor: ro.ui.theme.btnBorderDefault,
                passwordMask: 'true',
                keyboardType: Ti.UI.KEYBOARD_TYPE_DEFAULT,
                returnKeyType: Ti.UI.RETURNKEY_DONE,
                minimumFontSize: 0,
                borderWidth: ro.ui.relX(2),
                textAlign: 'center',
                hintText: 'Password',
                hintTextColor: '#e4e4e4'
            }));

            data[1].add(txtPass);

			var doneFunc = function(e) {
					//Ti.API.debug('DONE e: ' + JSON.stringify(e));
					//Ti.API.debug('e.source.id: ' + e.source.id);
					//Ti.API.debug('e: ' + JSON.stringify(e));
					//switch (e.source.id) {
						//case 1:
							//pickerView.hidePicker();
						
						//	break;
						//case 2:
						//	break;
					//}
						txtUname.blur();
						txtPass.blur();

			};
			var nextFunc = function(e){
				//Ti.API.info('NEXT e: ' + JSON.stringify(e));
				switch(e.source.id){
					case 1:
						txtPass.focus();
						break;
					case 2:
						txtUname.focus();
						break;
				}
			};
			if(ro.isiOS){
				txtUname.keyboardToolbar = getToolbar(1, doneFunc, nextFunc);
				txtPass.keyboardToolbar = getToolbar(2, doneFunc, nextFunc);
			}
			
            var frgtPw = Ti.UI.createLabel({
                text: 'Forgot Password?',
                //left:ro.ui.relX(5),
                textAlign: 'center',
                height: ro.ui.relY(40),
                right: ro.ui.relX(10),
                color: ro.ui.theme.forgotPwTxt,
                font: {
                    fontSize: ro.ui.scaleFont(13, 80, 30), //9.5
                    fontFamily: ro.ui.fontFamily
                },
                width: Ti.UI.FILL
            });
            frgtPw.addEventListener('click', function(e) {
                //Ti.API.debug('frgtPw: ' + JSON.stringify(frgtPw));
                if (!ro.isiOS)
                    Ti.UI.Android.hideSoftKeyboard();
                ro.ui.showPassRecovery();
                //this.removeEventListener('click', arguments.callee);
                //Ti.API.debug('frgtPw-after: ' + JSON.stringify(frgtPw));
            });
            //data[2].add(frgtPw);

            /*data[2].add(Ti.UI.createLabel({
             text:'Remember Me',
             font:{
             fontSize:ro.ui.scaleFont(15, 80, 30),//12
             fontFamily:ro.ui.fontFamily
             },
             width:'35%',
             textAlign:'center',
             height:ro.ui.relY(30),
             color:ro.ui.theme.loginLittleTxt
             }));*/

            var switchRemember = Ti.UI.createSwitch({
                value: true,
                style: ro.isiOS ? null : Ti.UI.Android.SWITCH_STYLE_CHECKBOX,
                height: Ti.UI.FILL,
                left: ro.ui.relX(5)
            });
            if (ro.isiOS) {
                switchRemember.top = ro.ui.relY(6);
            }
            switchRemember.addEventListener('change', function(e) {
                remember = e.value;
            });
            //data[2].add(switchRemember);

            var tblView = Ti.UI.createTableView({
            		scrollable:false,
                data: data,
                height: ro.ui.relY(134),
                top: ro.ui.relY(15),
                backgroundColor: 'transparent',
                separatorColor: 'transparent'
            });

            var padding = Ti.UI.createView({
                top: ro.ui.relY(15),
                layout: 'vertical',
                height: Ti.UI.SIZE
            });

            var titleLbl = Ti.UI.createLabel({
                text: Ti.App.loginGreeting,
                font: ro.ui.font.pathToMenuTitles,
                color: ro.ui.theme.loginTitleTxt, //'#393839',
                textAlign: 'center'
            });
            padding.add(titleLbl);
            padding.add(tblView);
            loginView.add(padding);

            var loginBorderRadius = null;
            if (Ti.App.RoundedButtons) {
                //loginBorderRadius = ro.ui.relX(157.5);
                loginBorderRadius = ro.ui.properties.ldfBool ? ro.ui.relX(27.5) : ro.ui.relX(25);
            }
            var imageOverlayView = Ti.UI.createView({
                height: ro.ui.properties.ldfBool ? ro.ui.relY(62.5) * .7 : ro.ui.relY(50) * .7,
                width: ro.ui.relX(330) * .7,
                top: ro.ui.relY(5),
                //borderColor:'purple',
                //borderWidth:5
            });
            imageOverlayView.add(Ti.UI.createImageView({
                image: '/images/halfLogo.png',
                height: Ti.UI.FILL,
                //borderColor:'green',
                //borderWidth:5,
                //top:0,
                bottom: 0
            }));
            var btnSubmit = Ti.UI.createView({
                height: ro.ui.properties.ldfBool ? ro.ui.relY(55) : ro.ui.relY(50),
                //height:ro.ui.relY(50),
                width: (ro.ui.properties.wideViewWidth),
                //bottom:ro.ui.properties.ldfBool?ro.ui.relY(15):ro.ui.relY(10),
                top: ro.ui.relY(5),
                backgroundColor: ro.ui.theme.loginBtnBackground,
                borderColor: ro.ui.theme.loginBtnBorder,
                //touchEnabled:false,
                borderWidth: ro.ui.relX(1),
                borderRadius: loginBorderRadius
            });
            btnSubmit.add(Ti.UI.createLabel({
                text: 'Log In',
                height: Ti.UI.FILL,
                font: {
                    fontSize: ro.ui.scaleFont(ro.isiOS ? 34 : 34),
                    fontFamily: ro.ui.fonts.button
                },
                color: ro.ui.theme.loginBtnWhite,
                textAlign: 'center'
            }));
            //layoutHelper.animateBtn(btnSubmit, ro.ui.theme.loginBtnBackground, ro.ui.theme.btnDefault, 0, ro.ui.theme.loginBtnWhite, ro.ui.theme.btnTxtDefault, ro.ui.theme.btnActive, ro.ui.theme.btnBorderDefault);

            var btnSubmitEvt = function(e) {
                //btnSubmit.removeEventListener('click', btnSubmitEvt);
                ro.ui.showLoader();
                if (!ro.isiOS)
                    Ti.UI.Android.hideSoftKeyboard();
                if (Ti.Network.networkType == Ti.Network.NETWORK_NONE) {
                    ro.ui.alert('Login Failed', 'Internet connection is required to place an order. Please connect and try again.');
                    ro.ui.hideLoader();
                    return;
                }
                if (!Ti.Network.online) {
                    ro.ui.alert('Login Failed', 'The network is not reachable to the internet.');
                    ro.ui.hideLoader();
                    return;
                }

                if (txtUname.value == '' || txtPass.value == '') {
                    ro.ui.alert('Login Failed', 'Please enter the login credentials');
                    ro.ui.hideLoader();
                    return;
                }
                else {
                    ro.REV_GUEST_ORDER.setIsGuestOrder(false);
                    login(txtUname.value, txtPass.value, true);
                }
            };
            //btnSubmit.addEventListener('click', btnSubmitEvt);

            txtUname.addEventListener('return', function(e) {
                txtPass.focus();
            });
            loginView.add(imageOverlayView);
            loginView.add(btnSubmit);
            var extrasView = Ti.UI.createView({
                width: ro.ui.relX(300),
                height: ro.isiOS ? ro.ui.relY(50) : ro.ui.relY(40),
                top: ro.ui.relY(10),
                layout: 'horizontal'
            });
            var rememberMeLbl = Ti.UI.createLabel({
                text: 'Stay Signed In',
                left: ro.isiOS ? ro.ui.relX(5) : ro.ui.relX(0),
                font: {
                    fontSize: ro.ui.scaleFont(13, 80, 30), //12
                    fontFamily: ro.ui.fontFamily
                },
                width: '35%',
                textAlign: 'left',
                height: ro.ui.relY(40),
                color: ro.ui.theme.loginLittleTxt
            });

            /*extrasView.add(frgtPw);
             extrasView.add(rememberMeLbl);
             extrasView.add(switchRemember);*/
            extrasView.add(switchRemember);
            extrasView.add(rememberMeLbl);
            extrasView.add(frgtPw);
            //loginView.add();
            loginView.add(extrasView);

            var bottomView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: ro.ui.properties.wideViewWidth//,
                //backgroundColor:'purple',
                //bottom:0,
                //layout: 'horizontal'
            });
            var bottomLeftView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                left:0,
                width: '48%'
            });
            var bottomRightView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                right:0,
                width: '48%'
            });

            //              GUEST ORDERS
            var guestOrderBtn;
            ro.REV_GUEST_ORDER.Init();
            if (ro.REV_GUEST_ORDER.getAcceptsGuestOrder()) {
                ro.REV_GUEST_ORDER.setIsGuestOrder(false);
                var guestOrderButton = ro.REV_GUEST_ORDER.getGuestOrderBtn();
                guestOrderButton.bottom = ro.ui.relY(25);
                guestOrderButton.left = 0;
                guestOrderButton.width = "100%";
                bottomLeftView.add(guestOrderButton);
            }
            //              GUEST ORDERS

            var newAccBtn = ro.layout.getMediumButton('Sign Up');
            newAccBtn.bottom = ro.ui.relY(25);
            newAccBtn.width = "100%";
            newAccBtn.right = 0;

            bottomRightView.add(newAccBtn);
            bottomView.add(bottomLeftView);
            bottomView.add(bottomRightView);
            var greyBorder = Ti.UI.createView(ro.ui.properties.greyBorder);
            greyBorder.width = ro.ui.properties.wideViewWidth;
            mainView.add(greyBorder);
            mainView.add(bottomView);

            if (defaultCustomer) {
                txtUname.value = defaultCustomer.Email;
                txtPass.value = defaultCustomer.Password;
            }

            if (Ti.Network.networkType == Ti.Network.NETWORK_NONE) {
                ro.ui.alert(Ti.App.name, 'Internet connection is required to place an order.  Please connect and try again.');
            }

            ro.ui.loginChange = function(e) {
                if (e.rowIndex == 0) {
                    ro.ui.getConfig();
                    ro.ui.showNewAccount();
                }
                else {
                    try {
                        ro.ui.showLoader();
                        Ti.App.fireEvent('app:viewDemo');
                    }
                    catch(ex) {
                        ro.ui.alert('demo click', ex);
                    }
                }
            };

            var newAccountBtnView = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                backgroundColor: ro.ui.theme.newAcctArea,
                layout: 'vertical',
                bottom: ro.ui.relY(0)
            });
            newAccountBtnView.add(Ti.UI.createLabel({
                top: ro.ui.properties.ldfBool ? ro.ui.relY(10) : ro.ui.relY(5),
                text: Ti.App.newAccountLbl,
                font: {
                    fontWeight: 'bold',
                    fontSize: ro.ui.scaleFont(20),
                    fontFamily: ro.ui.fontFamily
                },
                height: Ti.UI.SIZE,
                color: ro.ui.theme.newAcctAreaTxt,
                left: ro.ui.relX(10),
                right: ro.ui.relX(10),
                textAlign: 'center'
            }));
            /*var attr = Ti.UI.createAttributedString({
             text:Ti.App.newAccountDesc,
             attributes:[{
             type:Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
             value:'purple',
             range:[0, (Ti.App.newAccountDesc.length/2)]
             }
             ]
             });*/
            newAccountBtnView.add(Ti.UI.createLabel({
                text: Ti.App.newAccountDesc,
                //attributedString:attr,
                font: {
                    fontSize: ro.ui.scaleFont(14.75),
                    fontFamily: ro.ui.fontFamily
                },
                color: ro.ui.theme.newAcctAreaTxt,
                textAlign: 'center',
                left: ro.ui.relX(10),
                right: ro.ui.relX(10),
                top: ro.ui.properties.ldfBool ? ro.ui.relY(15) : ro.ui.relY(10)
            }));

            var newAccountBorderRadius = null;
            if (Ti.App.RoundedButtons) {
                newAccountBorderRadius = ro.ui.relX(157.5);
            }
            var newAccountBtn = Ti.UI.createView({
                height: ro.ui.relY(45),
                width: ro.ui.relX(330),
                backgroundColor: ro.ui.theme.newAcctBtn,
                top: ro.ui.properties.ldfBool ? ro.ui.relY(15) : ro.ui.relY(10),
                borderColor: ro.ui.theme.btnBorderDefault,
                borderWidth: ro.ui.relX(1),
                bottom: ro.ui.relY(15),
                borderRadius: newAccountBorderRadius
            });
            newAccountBtn.add(Ti.UI.createLabel({
                text: Ti.App.newAccountBtnLbl,
                font: {
                    fontWeight: 'bold',
                    fontSize: ro.ui.scaleFont(20),
                    fontFamily: ro.ui.fontFamily
                },
                color: ro.ui.theme.newAcctBtnTxt,
                textAlign: 'center'
            }));
            //layoutHelper.animateBtn(newAccountBtn, ro.ui.theme.loginGray, ro.ui.theme.btnActive, 0, ro.ui.theme.btnDefault, ro.ui.theme.btnTxtActive, ro.ui.theme.btnBorderDefault, ro.ui.theme.btnBorderActive);
            var newAccountEvt = function(e) {

                ro.ui.showLoader();
                ro.ui.getConfig();
            };
            //newAccountBtn.addEventListener('click', newAccountEvt);
            newAccountBtnView.add(newAccountBtn);

            var paddingView = Ti.UI.createView({
                height: ro.ui.relY(30),
                top: ro.ui.relX(10),
                width: Ti.UI.FILL,
                backgroundColor: 'transparent'
            });
            //mainView.add(paddingView);

            //mainView.add(newAccountBtnView);
            ro.ui.hideLoader();

            //ro.App.GA.trackPageView('loginView' /*name*/);
            var focusOnceBln = false;

            var activateButtons = function() {
                btnSubmit.addEventListener('click', btnSubmitEvt);
                newAccBtn.addEventListener('click', newAccountEvt);
                if (ro.REV_GUEST_ORDER.getAcceptsGuestOrder()) {
                    //Ti.API.debug('accepts Guest Orders');
                    guestOrderButton.canClick = true;
                }
            };
            var deactivateButtons = function(_cb) {
                btnSubmit.removeEventListener('click', btnSubmitEvt);
                newAccBtn.removeEventListener('click', newAccountEvt);
                if (_cb) {
                    _cb();
                }
            };

            var event = function() {
                mainView.removeEventListener('postlayout', event);
                ro.ui.showLoader();                

                    if (_args && _args.orderComplete) {
                        _args.orderComplete = false;

                        Ti.App.focusOnceBln = false;
                    }

                    if (Ti.App.focusOnceBln) {
                        activateButtons();
                        return;
                    }
                    Ti.App.focusOnceBln = true;
                    Ti.API.info("getCurrentStoreVersion");
                    ro.ui.hideLoader();
                    REV_ADS.init();
                    Ti.API.info("Show Ads :" + REV_ADS.showAds());
                    if (REV_ADS.showAds()) {
                        setTimeout(function() {
                            ro.ui.showAdView();
                        }, 1);
                        activateButtons();
                    }
                    else if (!(!ro.isiOS && Ti.Android.currentActivity && Ti.Android.currentActivity.intent.data && Ti.Android.currentActivity.intent.data !== null) && defaultCustomer ) {
                        ro.ui.showLoader();
                        login(defaultCustomer.Email, defaultCustomer.Password, true);
                    }
                    else {
                        activateButtons();
                    }                

            };
            mainView.addEventListener('postlayout', event);

            return mainView;
        };
    };
    return {
        loginview: loginview
    };
}();
module.exports = LOGIN; 