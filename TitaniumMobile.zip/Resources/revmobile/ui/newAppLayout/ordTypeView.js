var ORDTYPEVIEW = function(){
	var ordtypeview = function(ro){
	   ro.ui.createOrdTypeView = function(addView){
	      try{
	          if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
	              //Ti.API.info('Ti.App.OrderObj.Items.length: ' + Ti.App.OrderObj.Items.length);
	              ro.updateCartCount(Ti.App.OrderObj.Items.length);
	          }
	          else{
	              ro.updateCartCount(0);
	          }
             ro.PN.registerDevice();
             var conf = JSON.parse(Ti.App.Properties.getString('Config'));
             Ti.API.info("config: " + JSON.stringify(conf));              

	         var isGuest = false;
	         var showHcPrompt = false;
	         var ordTrackerBtnTxt, hasPhoneNumber = false, phoneNumber;
	         if(!conf){
	            conf = {};
	         }
	         var LTY_BARCODE_BLN = false, LTY_BARCODE_TXT = '', LTY_REGISTER_BLN = false, LTY_REGISTER_TXT = '';
	         var ordTrackerBln = false;
             var hasCurbsideTracker = conf && conf.ENABLE_CURBSIDE ? conf.ENABLE_CURBSIDE : false;;
	         Ti.App.AllowLongSt = conf && conf.AllowLongSt?conf.AllowLongSt:false;
	         Ti.App.AllowPCAccuracy = conf && conf.ALLOW_PC_ACCURACY?conf.ALLOW_PC_ACCURACY:false;
	         
	         if(conf){
	         	if(conf.LTY_BARCODE_TXT && conf.LTY_BARCODE_TXT.length){
	         		LTY_BARCODE_BLN = true;
	         		LTY_BARCODE_TXT = conf.LTY_BARCODE_TXT;
	         	}
	         	if(conf.States && conf.States.length){
	         		Ti.App.Properties.setList('states', conf.States);
	         	}
	         	ordTrackerBtnTxt = conf && conf.HT_NAME && conf.HT_NAME.length ? conf.HT_NAME : (conf.CompanyName + ' Order Tracker').toUpperCase();
	         	ordTrackerBln = conf.ENABLE_TRACKER || false;
	         	
	         }
	         
	         ro.REV_LOYALTY.init();
	         ro.REV_LOYALTY.setCurrentLoyalty();
	         
	         ro.REV_GUEST_ORDER.setGuestAddr();
	         var CustInfo = {};
	         if(!ro.REV_GUEST_ORDER.getIsGuestOrder()){
                 CustInfo = JSON.parse(Ti.App.Properties.getString('Customer'));
                 CustInfo.PrevOrders = null;
                 Ti.API.info("Customer Info: " + JSON.stringify(CustInfo));
			    if(!CustInfo){
			       CustInfo = {};
			    }
			    else{
			    	hasPhoneNumber = true;
			    	phoneNumber = CustInfo.Phone;
			    	
			    	if(ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()){
			         	if(ro.REV_LOYALTY.getLtyOptIn() != 1){
			         		showHcPrompt = true;
			         	}
			         }
			         
			         if(ro.REV_LOYALTY.isEnabled()){
			         	if(ro.REV_LOYALTY.getEClubOptIn() != 1){
			         		showHcPrompt = true;
			         	}
			         }
			    }
			 }
			 else{
			 	isGuest = true;
			 }
			
			 REV_BANNERS.init();	//New Module for Banner ads that will navigate user to menu and immediately begin the coupon walkthrough for them 
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL){ Ti.API.debug('conf-Exception: ' + ex); }
	      }
	      
	
	      var pickupImg = '/images/shop.png';
	      var delivImg = '/images/deliv.png';
	
	      Ti.App.RepeatLastOrder = false;
	      //ro.app.Store = null;
	      //ro.REV_STORES.clearStore();
	      var backButton = layoutHelper.getBackBtn('BACK');
	      try{
	         var mainView = layoutHelper.getMainView('ordTypeView'/*hid*/, 'Order Type'/*Top Title*/, null/*right Button*/, backButton/*left button*/, true/*vertical or not*/);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL) { Ti.API.debug('ordTypeView()-Exception: ' + ex); }
	      }
	
	      var ordTypeView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.contentsView,{
	         layout:'vertical',
	         height:Ti.UI.FILL,
	         width:Ti.UI.FILL,
	         disableBounce:ro.isiOS ? true : false,
	         contentWidth:Ti.UI.FILL,
	         scrollType : 'vertical'
	      }));
	
	      mainView.add(ordTypeView);
	      var storeObj;
	
	      try{
	         if(Ti.App.Properties.hasProperty('DefaultStore')){
	            storeObj = ro.REV_STORES.getDefaultStore();//eval('(' + Ti.App.Properties.getString('DefaultStore') + ')');
	            //ro.app.Store = storeObj;
	            if((!Ti.App.OrderObj.Items || !Ti.App.OrderObj.Items.length) && (!Ti.App.OrderObj.Cpns || !Ti.App.OrderObj.Cpns.length)){
	            	ro.REV_STORES.setStore();
	            }
	         }
	         else if(false && Ti.App.Username == 'demo@revention.com'){//ensure demo
	            //var file = Ti.Filesystem.getFile(Ti.Filesystem.resourcesDirectory, 'demo.json');
	            //var contents = file.read();
	            //storeObj = eval('(' + contents.text + ')');
	         }
	      }
	      catch(e){ }
	
	      try{
	         var allowDeliv = true;
	         var Config = null;
	         var carryoutLbl = '\t Pickup';
	         var deliveryLbl = '\t Delivery';
	
	         if(Ti.App.Properties.hasProperty('Config')){
	            Config = JSON.parse(Ti.App.Properties.getString('Config'));
	            if(Config && (Config.AllowDelivery == false || Config.AllowDelivery == 'False')){
	               allowDeliv = false;
	            }
	            if(ro.utils.hasProp(Config, 'CarryoutLabel')){
	               carryoutLbl = (!ro.isiOS ? ('\t ' + Config.CarryoutLabel) : Config.CarryoutLabel);
	            }
	            if(ro.utils.hasProp(Config, 'DeliveryLabel')){
	               deliveryLbl = (!ro.isiOS ? ('\t ' + Config.DeliveryLabel) : Config.DeliveryLabel);
	               
	            }
	         }
	         else if(storeObj && (storeObj.Configuration.AllowDelivery==false || storeObj.Configuration.AllowDelivery == 'False')){
	            allowDeliv = false;
	         }
	
	         /*var productBanner = Ti.UI.createImageView({
	            height:'35%',
	            width:Ti.UI.FILL,
	            image:Ti.App.websiteURL + 'content/images/slides/ordertype/mobile/banner.png'
	         });
	         ordTypeView.add(productBanner);*/
	         var bannersView = REV_BANNERS.getBannerView();
	         bannersView.top = ro.ui.relY(5);
	         bannersView.addEventListener('click', function(e){
	         	if(e.source.code && e.source.code.length){
	         		//showOrderTypes();
	         		ro.ui.ordShowNext({ addView:true, showing:'chooseOrderTypeView' });
	         	}
	         });
	         ordTypeView.add(bannersView);
	         
	         var padding = Ti.UI.createView({
	         	disableBounce:ro.isiOS ? true : false,
	         	contentWidth:Ti.UI.FILL,
	            height:Ti.UI.SIZE,
	            width:ro.ui.properties.wideViewWidth,//ro.ui.relX(350),
	            layout:'vertical'
	            //scrollType:'vertical'
	         });
	         var padTopPad = Ti.UI.createView({
	            height:0,
	            width:ro.ui.properties.wideViewWidth,
	            layout:'vertical',
	            visible:false,
	            top:0
	         });
	         if(Config && Config.ORD_TYPE_INST && Config.ORD_TYPE_INST.length){
				var ordTypeInstTxt = Config.ORD_TYPE_INST;
				var ordTypeInst = Ti.UI.createLabel({
					top:ro.ui.relY(10),
					textAlign:'center',
					width:Ti.UI.FILL,
				 	text: ordTypeInstTxt,
				 	color:ro.ui.theme.orderTypeBgTxt,
				 	touchEnabled: false,
				 	font:{
		               fontSize:ro.ui.scaleFont(15),
		               fontWeight:'bold',
		               fontFamily:ro.ui.fontFamily
		            }
				 });
				padTopPad.add(ordTypeInst);
			 }
	         padTopPad.add(Ti.UI.createLabel({
	            text:'Please select your order type',
	            font:{
	               fontSize:ro.ui.scaleFont(16),
	               //fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            },
	            textAlign:'center',
	            color:ro.ui.theme.orderTypeBgTxt,
	            width:Ti.UI.FILL,
	            top:ro.ui.relY(7)
	         }));
	
	         var paddingTop = Ti.UI.createView({
	            height:Ti.UI.SIZE,
	            width:Ti.UI.FILL,
	            layout:'horizontal'
	         });
	         padTopPad.add(paddingTop);
	         var shopBtn = Ti.UI.createView({
	            height:ro.ui.properties.wideViewWidth * .52,
	            bottom:ro.ui.relY(30),
	            width:ro.ui.properties.wideViewWidth * .49,
	            left:0,
	            top:ro.ui.relY(10),
	            backgroundImage:'/images/carryoutBtn.png',
	            layout:'vertical',
	            borderRadius:ro.ui.relX(8)
	         });
	         paddingTop.add(shopBtn);	         
	         var isDelivChosen = false;
	         shopBtn.addEventListener('click', function(e){
	            try{
	               REV_ORD_TYPE.setOrdType(false);	
	               ro.ui.showLoader();
	               Ti.App.RepeatLastOrder = false;
	               nextView();
	            }
	            catch(ex){	            	
	               ro.ui.alert('Order Type', 'Code:100');
	            }
	         });
	
	         if(allowDeliv){
	            var delivBtn = Ti.UI.createView({
	               height:ro.ui.properties.wideViewWidth * .52,
	               left:ro.ui.properties.wideViewWidth * .015,
	               width:ro.ui.properties.wideViewWidth * .49,
	               top:ro.ui.relY(10),
	               backgroundImage:'/images/deliveryBtn.png',
	               layout:'vertical',
	               bottom:ro.ui.relY(30),
	               borderRadius:ro.ui.relX(8)
	            });
	            paddingTop.add(delivBtn);
	           shopBtn.addEventListener('click', function(e){
                try{
                   REV_ORD_TYPE.setOrdType(false);
    
                   ro.ui.showLoader();
                   Ti.App.RepeatLastOrder = false;
                   nextView();
                }
                catch(ex){
                   ro.ui.alert('Order Type', 'Code:100');
                }
             });
	            delivBtn.addEventListener('click', function(e){
	               try{
	               	  REV_ORD_TYPE.setOrdType(true);	               
	                  ro.ui.showLoader();
	                  Ti.App.RepeatLastOrder = false;
	                  nextView();
	               }
	               catch(ex){
	                  ro.ui.alert('Order Type', 'Code:100');
	               }
	            });
	         }
	
	         var paddingBot = Ti.UI.createView({
	            height:Ti.UI.SIZE,
	            width:ro.ui.properties.wideViewWidth,
	            visible:true,
	            layout:'vertical',
	            top:ro.ui.relY(5)
	         });
	         padding.add(paddingBot);	         
	         
	         var btnTop = ro.ui.relY(20);
			 var repeatBorderRadius = ro.ui.relX(1);
			 if(Ti.App.RoundedButtons){
			  	repeatBorderRadius = ro.ui.relY(32);
			 }
	         var repeatBtn = Ti.UI.createView({
	            //height:'47%',
	            top:btnTop,
	            height:ro.ui.relY(64),
	            //width:'80%',
	            //left:'10%',
	            left:ro.ui.relX(3),
	            right:ro.ui.relX(3),
	            backgroundColor:ro.ui.theme.repeatOrderButtonColor,
	            borderColor:'transparent',
	            //borderWidth:ro.ui.relX(1),
	            borderRadius:repeatBorderRadius
	         });
	         repeatBtn.add(Ti.UI.createLabel({
	            text:'Repeat Last Order',
	            font:{
	               //fontWeight:'bold',
	               fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
	               fontFamily:ro.ui.fonts.button
	            },
	            color:ro.ui.theme.repeatOrderBtnTxt
	         }));
	         repeatBtn.addEventListener('click', function(e){
	
	            ro.ui.showLoader();
	            ro.utils.removeProp('storeList');
	
	            var testOrder = function(theOrd){	            	
	            	var dateForm = require('formControls/fullDateForm').dateForm(ro);
	               if(dateForm.toFuture(ro.app.Store)){
	                  Ti.App.allowFuture = true;
	               }
	               else{
	                  Ti.App.allowFuture = false;
	               }
	               var ordIdxA = ro.utils.getMatchingIdx(theOrd.OrdType, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'OrdType');
	
	               if(ordIdxA == -1){
	                  ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
	                  ro.ui.hideLoader();
	                  return;
	               }
	
	               var ordTypes = ro.app.Store.Menu.OnlineOptions.OrdTypes;
	               if(ordTypes[ordIdxA].IsDelivery){
	                  var isDeliv = theOrd.Customer && theOrd.Customer.FName && theOrd.Customer.FName.length>0 && theOrd.Customer.LName && theOrd.Customer.LName.length>0 && theOrd.Customer.SelPhone && theOrd.Customer.SelPhone.length>0 && theOrd.Customer.StNum && theOrd.Customer.StNum.length>0 && theOrd.Customer.Street && theOrd.Customer.Street.length>0 && theOrd.Customer.City && theOrd.Customer.City.length>0 && theOrd.Customer.State && theOrd.Customer.State.length>0 && theOrd.Customer.Zip && theOrd.Customer.Zip.length>0;
	                  if(!isDeliv){
	                     ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
	                     ro.ui.hideLoader();
	                     return;
	                  }
	                  else{
	                     var test = Ti.App.OrderObj;
	                     test.ordOnlineOptions = {};
	                     test.ordOnlineOptions.IsDelivery = isDeliv;
	                     test.Customer = theOrd.Customer;
	                     Ti.App.OrderObj = test;
	                     test = null;
	                  }
	               }
				//Ti.API.debug('Ti.App.OrderObj: '	+ JSON.stringify(Ti.App.OrderObj));
					var test = Ti.App.OrderObj;
	               if(!ro.prevOrders.addToCart(theOrd, ro.app.Store.Menu, test)){
	                  //Alert user that this previous order no longer will work...
	                  Ti.App.OrderObj = test;
	                  test = null;
	                  ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
	                  ro.ui.hideLoader();
	               }
	               else{
	                  
	                  test.Menu = ro.app.Store.Menu.Name;
	                  test.CurSplit = 0;
	                  test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdxA].OrdTypePriceIdx;
                      test.OrderTypeCategory = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdxA].OrderTypeCategory;
	                  Ti.App.OrderObj = test;
	                  test = null;
                       REV_ORD_TYPE.setNeedsToCheckSpecificOrdType(false); // no need to do the extra ordTypeCheck on landing on menu page
	                  ////Ti.API.debug('Ti.App.OrderObj: '	+ JSON.stringify(Ti.App.OrderObj));
	                  
	                  ro.ui.setOrdTypeStkState('grpsItems');
	                  ro.ui.showCart();
	               }
	            };
	            var sort_desc = function (date1, date2) {
	               if(date1.TimeStamp > date2.TimeStamp){
	                  return -1;
	               }
	               if(date1.TimeStamp < date2.TimeStamp){
	                  return 1;
	               }
	
	               return 0;
	            };
	            repeatCustomer.PrevOrders.sort(sort_desc);
	
	            var lastOrd = repeatCustomer.PrevOrders[0];
	            var test = Ti.App.OrderObj;
	            test.ordOnlineOptions = {};
	            test.ordOnlineOptions.IsDelivery = false;
	            test.OrdType = lastOrd.OrdType;
	            test.Customer = {};
	            Ti.App.OrderObj = test;
	            test = null;
	
	            if(ro.app.Store && (ro.app.Store.ID == lastOrd.Business_ID)){
	               testOrder(lastOrd);
	            }
	            else{
	               //Call getStore with lastOrd.Business_ID to get store. Then test the previous order.
	               var req = {};
	               req.RevKey = 'test';
	               req.StoreID = lastOrd.Business_ID;
	               req.CompressResponse = false;
	
	               ro.dataservice.post(req, 'GetStore_Json', function(response){
	                  if(response){
	                     if(response.Value){
	                          if(response.Store){
	                           //ro.app.Store = response.Store;
	                           //var tempStore = response.Store;
	                           /*if(isDeliv){
                                   var cust = Ti.App.Properties.getString('Customer', "{}");
                                   tempStore.Menu.OnlineOptions.DelivOpts.AddDelFee = cust.AddDelFee;
                                   tempStore.Menu.OnlineOptions.DelivOpts.ZoneName = cust.ZoneName;
                                   Ti.API.info('INSIDE GETTING STORE - tempStore.Menu.OnlineOptions.DelivOpts:' + JSON.stringify(tempStore.Menu.OnlineOptions.DelivOpts));
	                           }*/
	                           
	                           ro.REV_STORES.setStore(response.Store);
							   if (response.Store.Configuration) {
								Ti.App.Properties.setString('Config', JSON.stringify(response.Store.Configuration));
								}
	                           ro.utils.setStrProp('Store', response.Store);
	                           ro.app.Store = response.Store;
	                       	   testOrder(lastOrd);
	                    }
	                    else{
	                      ro.ui.hideLoader();
	                      ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
	                    }
	                     }
	                     else{
	                        ro.ui.hideLoader();
	                        ro.ui.alert('One-tap Order', response.Message + '\nCODE:500');
	                     }
	                  }
	                  else{
	                     ro.ui.hideLoader();
	                     ro.ui.alert('One-tap Order', 'Error occured. CODE:100.');
	                  }
	               });
	            }
	
	            //Follow this Ti.App.RepeatLastOrder path for the old repeat last orderS method that was in place.
	            /*Ti.App.RepeatLastOrder = true;
	            ro.ui.ordShowNext({addView:true, showing:'itemsView'});*/
	            //Follow this Ti.App.RepeatLastOrder path for the old repeat last orderS method that was in place.
	
	         });
	
			 var continueBorderRadius = ro.ui.relX(1);
			 if(Ti.App.RoundedButtons){
			  	continueBorderRadius = ro.ui.relY(32);
			 }
	         var continueBtn = Ti.UI.createView({
	            height:ro.ui.relY(64),
	            left:ro.ui.relX(3),
	            right:ro.ui.relX(3),
	            top:btnTop,
	            backgroundColor:ro.ui.theme.beginNewOrderBackground,
	            borderColor:ro.ui.theme.beginNewOrderBorder,
	            borderRadius:continueBorderRadius
	         });
	         continueBtn.add(Ti.UI.createLabel({
	            text:'Begin New Order',
	            font:{
	               fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
	               fontFamily:ro.ui.fonts.button
	            },
	            color:ro.ui.theme.beginNewOrderText
	         }));
	         var showOrderTypes = function(e){
	            padTopPad.height = Ti.UI.SIZE;
	            padTopPad.bottom = ro.ui.relY(10);
	            padTopPad.show();
	            Ti.App.RepeatLastOrder = false;
	            padding.scrollToBottom();
	            padding.scrollToBottom();
	         };         
	
			 var lvlupBorderRadius = ro.ui.relX(1);
			 if(Ti.App.RoundedButtons){
			  	lvlupBorderRadius = ro.ui.relY(32);
			 }
	         var levelupBtn = Ti.UI.createView({
	            height:ro.ui.relY(64),
	            top:btnTop,
	            right:ro.ui.relX(3),
	            left:ro.ui.relX(3),
	            backgroundColor:ro.ui.theme.lvlupBtnBg,
	            borderColor:ro.ui.theme.btnTxtActive,
	            borderWidth:ro.ui.relX(1),
	            borderRadius:lvlupBorderRadius
	         });
	         var companyName = conf.CompanyName ? conf.CompanyName.toUpperCase()+' ' : '';
	         levelupBtn.add(Ti.UI.createLabel({
	            text:'PAY',
	            font:{
	               fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
	               fontFamily:ro.ui.fonts.button
	            },
	            color:'#ffffff'
	         }));
	         
	         var optIn = false;
	         if(ro.REV_LOYALTY.isLoyaltyNoEClubEnabled()){
	         	optIn = ro.REV_LOYALTY.getLtyOptIn() == 1;
	         	//conf.LTY_REGISTER_TXT = "One Click Lty Registration!";
	         	if(!optIn && conf.LTY_REGISTER_TXT && conf.LTY_REGISTER_TXT.length){
	         		LTY_REGISTER_BLN = true;
	         		LTY_REGISTER_TXT = conf.LTY_REGISTER_TXT; 
	         	}
	         }
	         else if(ro.REV_LOYALTY.isEnabled()){
	         	optIn = ro.REV_LOYALTY.getEClubOptIn() == 1;
	         }
	         var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
			 var hasLty = false;
	         if(currentLoyalty.isLU && currentLoyalty.isMobileAuthEnabled() && optIn){
	         	levelupBtn.addEventListener('click', function(e){
		            ro.ui.showLoader();
		            ro.ui.ordShowNext({addView:true, showing:'levelup'});
		         });
				 hasLty = true;
	            paddingBot.add(levelupBtn);
	         }
	         else if(LTY_BARCODE_BLN && currentLoyalty.isHC && currentLoyalty.showHcTab() && optIn){
	         	levelupBtn.children[0].text = LTY_BARCODE_TXT;
	         	levelupBtn.addEventListener('click', function(e){
		            ro.ui.showLoader();
		            ro.ui.ordShowNext({addView:true, showing:'qrcode'});
		         });
				 hasLty = true;
	         	paddingBot.add(levelupBtn);
	         }
	         else{
	         	if(LTY_REGISTER_BLN && (currentLoyalty.isHC || currentLoyalty.isEWOM)){
	         		var registerStoreCallback = function(storeChosenBln, chosenStoreID, chosenStoreName){
	         			if(storeChosenBln){
	         				REV_CUSTOMER.changeLtyOptIn(1, true, function(didNotSucceed){
					            if(didNotSucceed){
					            
					            }
					            else{
						            ro.ui.alert("Success", "You are now enrolled at " + chosenStoreName + ".");
					            	ro.ui.ordShowNext({showing:'ordTypeView'});
					            	ro.ui.hideLoader();
					            }
				            }, chosenStoreID);
	         			}
	         			else{
	         				REV_CUSTOMER.changeLtyOptIn(1, true, function(didNotSucceed){
					            if(didNotSucceed){
					            
					            }
					            else{
						            ro.ui.alert("Success", "You are now enrolled.");
					            	ro.ui.ordShowNext({showing:'ordTypeView'});
					            	ro.ui.hideLoader();
					            }
				            });
	         			}
	         			
	         		};
	         		
	         		
	         		levelupBtn.children[0].text = LTY_REGISTER_TXT;
		         	levelupBtn.addEventListener('click', function(e){
			            ro.ui.showLoader();
			            ro.REV_LOYALTY.DoRegisterStores(registerStoreCallback);
			         });
					hasLty = true;
		         	paddingBot.add(levelupBtn);
	         	}
	            else if(!currentLoyalty.isLU){
	               currentLoyalty = null;
	            }
	         }
			 
	           continueBtn.addEventListener('click', function(){
	               ro.ui.ordShowNext({ addView:true, showing:'chooseOrderTypeView' });
	           }); 
	         function nextView(){
	            if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
	               if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	                  ro.ui.ordShowNext({ addView:true, showing:'addNewAddr' });
	               }
	               else{
	                  ro.ui.ordShowNext({ addView:true, showing:'newAddrList' });
	               }
	            }
	            else{
	               ro.ui.ordShowNext({ addView:true, showing:'defaultStore' });
	            }
	         }

             if (hasCurbsideTracker) {
                 var placeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.genericHdrLblWithHeaderHuge, {
                     text: 'PLACE AN ORDER'
                 }));
                 paddingBot.add(placeLbl);
             }

	         if(!ro.REV_GUEST_ORDER.getIsGuestOrder()){
	            var repeatCustomer = JSON.parse(Ti.App.Properties.getString('Customer', ''));
	            if(repeatCustomer && repeatCustomer.PrevOrders && repeatCustomer.PrevOrders.length>0){
	               paddingBot.add(repeatBtn);
	            }
	         }
              paddingBot.add(continueBtn);              
	         
	         var ordTrackerBorderRadius = ro.ui.relX(1);
			 if(Ti.App.RoundedButtons){
			  	ordTrackerBorderRadius = ro.ui.relY(32);
			 }
	         var ordTrackerBtn;
	         if((Ti.App.serviceURL === 'https://hungryhowies.hungerrush.com/RevService.asmx' || Ti.App.serviceURL === 'https://hhtraining.hungerrush.com/RevService.asmx')){
	         	ordTrackerBtn = Ti.UI.createView({
		            height:ro.ui.relY(64),
		            right:ro.ui.relX(3),
		            left:ro.ui.relX(3),
                    top: btnTop,
                    bottom: btnTop,
		            borderWidth:ro.ui.relX(2),
		            borderRadius:ordTrackerBorderRadius,
		            backgroundColor:ro.ui.theme.ordTrackerBtnBackground,
					borderColor:ro.ui.theme.ordTrackerBtnBorder
		         });
		         
		         if(ordTrackerBtnTxt && ordTrackerBtnTxt.length && ordTrackerBtnTxt.toLowerCase().indexOf("track®") >= 0){
		         	var attributesCol = [];
	                    attributesCol.push({
	                        type: Ti.UI.ATTRIBUTE_FONT,
			                value: {
			                    fontFamily:ro.ui.fonts.orderTrackerBold,
			                    fontSize:ro.ui.scaleFont(ro.isiOS ? 28 : 28)
			                },
	                        range: [ordTrackerBtnTxt.toLowerCase().indexOf("track®"), ("track®").length]
	                    });
	                    var attr = Ti.UI.createAttributedString({
	                        text: ordTrackerBtnTxt,
	                        attributes: attributesCol
	                    });
	                    
	                    ordTrackerBtn.add(Ti.UI.createLabel({
				            attributedString:attr,
				            font:{
				               fontSize:ro.ui.scaleFont(ro.isiOS ? 28 : 28),
				               fontFamily:ro.ui.fonts.orderTrackerBold
				            },
				            color:'#393839'
				         }));
	                //}
		         }
		         else{
		         	ordTrackerBtn.add(Ti.UI.createLabel({
			            text:ordTrackerBtnTxt,
			            font:{
			               fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
			               fontFamily:ro.ui.fonts.button
			            },
			            color:'#393839'
			         }));
		         }
	         }
	         else{	         	
	         	ordTrackerBtn = Ti.UI.createView({
		            height:ro.ui.relY(64),
		            right:ro.ui.relX(3),
		            left:ro.ui.relX(3),
		            top:btnTop,
		            borderWidth:ro.ui.relX(2),
		            borderRadius:ordTrackerBorderRadius,
		            backgroundColor:ro.ui.theme.ordTrackerBtnBackground,
					borderColor:ro.ui.theme.ordTrackerBtnBorder
		         });
		         
		         ordTrackerBtn.add(Ti.UI.createLabel({
		            text:ordTrackerBtnTxt,
		            font:{
		               fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
		               fontFamily:ro.ui.fonts.button
		            },
		            color:'#393839'
		         }));
		     }
	         
              function openOrdTracker(trackStr) {	         	
	         	var url = Ti.App.websiteURL + trackStr + '?&hidemenu=1';
	         	
	         	if(hasPhoneNumber){
					  url = Ti.App.websiteURL + trackStr + '?phone='+phoneNumber.replace(/-/g,'')+'&hidemenu=1';
	         	}
	         	var ordTrackerObj = JSON.parse(Ti.App.Properties.getString('ordTrackObj', '{}'));
	         		ro.utils.removeProp('ordTrackObj');
	         		
	         	var theUrl = (ordTrackerObj && ordTrackerObj.id && ordTrackerObj.id.length && (isGuest == ordTrackerObj.wasGuest)) ? (Ti.App.websiteURL + 'ordertracker?TrackerID='+ordTrackerObj.id+'&hidemenu=1') : url;
	         	
				var webview, webWindow;
				webWindow = Ti.UI.createWindow({
						layout:'vertical',
						top:0,
						left:0,
						right:0,
						bottom:0
					});					
					if(!ro.isiOS){
						webWindow.addEventListener('open', function(){
							webWindow.activity.actionBar.hide();
						});
					}
					
					var navBar = Ti.UI.createView(ro.ui.properties.navBar);
					
					if(ro.isiphonex){
						var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
						var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
						var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
						navParent.add(topNav);
						bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
						navParent.add(bottomNav);
						webWindow.add(navParent);
					}
					else{
						webWindow.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
					}
					
					var sharedLayout = require('revmobile/ui/sharedLayouts/mainView');
					var btnBack = sharedLayout.getBackBtn('BACK');
					navBar.add(btnBack);
					webView = Ti.UI.createWebView({
						disableBounce:ro.isiOS ? true : null,
						top:0,
						height:Ti.UI.FILL,
						width:Ti.UI.FILL,
						borderRadius:1,
						url:theUrl
					});
					
				function closeWin(){
						webWindow.close();
						webWindow = null;	
				};
				btnBack.addEventListener('click', closeWin);
			
				webWindow.add(webView);
			 	webWindow.open();
			 }
	         
             if (ordTrackerBln) {
                  if (hasCurbsideTracker) {
                      paddingBot.add(Ti.UI.createView(ro.ui.properties.greySeperator));
                      var trackLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.genericHdrLblWithHeaderHuge, {
                          text: 'TRACK YOUR ORDER'
                      }));
                      paddingBot.add(trackLbl);
                  }
                 paddingBot.add(ordTrackerBtn);
                 ordTrackerBtn.addEventListener('click', function () {
                     openOrdTracker('OrderTracker');
                 });
                 if (hasCurbsideTracker) {
                     ordTrackerBtn.bottom = 0;
                     var curbTrackerBtn = Ti.UI.createView({
                         height: ro.ui.relY(64),
                         right: ro.ui.relX(3),
                         left: ro.ui.relX(3),
                         top: btnTop,
                         bottom: btnTop,
                         borderWidth: ro.ui.relX(2),
                         borderRadius: ordTrackerBorderRadius,
                         backgroundColor: ro.ui.theme.ordTrackerBtnBackground,
                         borderColor: ro.ui.theme.ordTrackerBtnBorder
                     });

                     curbTrackerBtn.add(Ti.UI.createLabel({
                         text: 'Curbside',
                         font: {
                             fontSize: ro.ui.scaleFont(ro.isiOS ? 26 : 28),
                             fontFamily: ro.ui.fonts.button
                         },
                         color: '#393839'
                     }));
                     paddingBot.add(curbTrackerBtn);
                     curbTrackerBtn.addEventListener('click', function () {
                         openOrdTracker('Curbside');
                     });
                 }	         	
	         }
	         
	         ordTypeView.add(padding);
	         var postlayoutEvt = function(){
				Ti.API.info("Banner: " + JSON.stringify(bannersView));
	         	mainView.removeEventListener('postlayout', postlayoutEvt);				
				var bannersViewHeight = 0;
				if(bannersView && bannersView.rect && bannersView.rect.height){
					bannersViewHeight = bannersView.rect.height;
				}
				REV_BANNERS.setBannerHeight(bannersViewHeight);				
	         	ro.ui.hideHomeSelection(false);	         	
	         	if(ordTrackerBln){
		         	var ordTrackerObj = JSON.parse(Ti.App.Properties.getString('ordTrackObj', '{}'));
		         	if(ordTrackerObj && ordTrackerObj.id && ordTrackerObj.id.length){
		         		openOrdTracker('OrderTracker');
		         	}
		        }
				if(ro.REV_GUEST_ORDER.getIsGuestOrder() && !ordTrackerBln && !hasLty){
					if(addView)	
					{
						ro.ui.ordShowNext({ addView:true, showing:'chooseOrderTypeView' });
					}
					else 
					{
						ro.ui.exitApp();
					}
				   }		
	         };
	         mainView.addEventListener('postlayout', postlayoutEvt);
	
	         return mainView;
	      }
	      catch(ex){
	         Ti.API.debug('ordTypeView.js-Exception: ' + ex);
	      }
	   };		
	};
	return {
		ordtypeview:ordtypeview
	};
}();
module.exports = ORDTYPEVIEW;