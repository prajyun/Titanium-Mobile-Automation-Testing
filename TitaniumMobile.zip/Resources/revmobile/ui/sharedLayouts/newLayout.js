var LAYOUT = function(){
	var layout = function(ro){
		var style = ro.ui.properties; 
		/*var osname = Ti.Platform.osname;
		var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;
		if(isiOS){
			style = require('/styles/style');
		}
		else{
			style = $$;
		}*/
		
		var getBigSecondaryButton = function(ttl){
		   var thisBtn = Ti.UI.createView(style.secondaryBigButton);
		   var lbl = Ti.UI.createLabel(style.secondaryBigButtonLbl);
		   lbl.text = ttl;
		   thisBtn.add(lbl);
		   return thisBtn;
		};
		var getSettingsButton = function(ttl, image){
		   var thisBtn = Ti.UI.createView(style.settingsButton);
		
			var leftVw = Ti.UI.createView({
				layout:'horizontal',
				width:Ti.UI.FILL,
				height:Ti.UI.FILL
			});
			
		   leftVw.add(Ti.UI.createImageView({
				image:image,
				//height:Ti.UI.FILL
				left:ro.ui.relX(10),
				width:ro.ui.relX(48)
		   }));
		
		   var lbl = Ti.UI.createLabel(style.settingsButtonLbl);
		   lbl.text = ttl;
		
		   leftVw.add(lbl);
		   thisBtn.add(leftVw);
		   arrowView = Ti.UI.createView(style.arrowView);
			arrowView.add(Ti.UI.createImageView({
				image:'/images/rightArrow.png',
				touchEnabled:false
			}));
			thisBtn.add(arrowView);
		   
		   return thisBtn;
		};
		
		var getMediumButton = function(ttl, largerTextBln){
		   var thisBtn = Ti.UI.createView(style.mediumButton);
            var lbl = Ti.UI.createLabel(style.mediumButtonLblLgTxt);
		   lbl.text = ttl;
		   thisBtn.add(lbl);
		   return thisBtn;
        };

        var getPrimaryButton = function (ttl) {
            var thisBtn = Ti.UI.createView(style.primaryButton);
            var lbl = Ti.UI.createLabel(style.primaryButtonLbl);
            lbl.text = ttl;
            thisBtn.add(lbl);
            return thisBtn;
        };

        var getSecondaryButton = function (ttl) {
            var thisBtn = Ti.UI.createView(style.secondaryButton);
            var lbl = Ti.UI.createLabel(style.secondaryButtonLbl);
            lbl.text = ttl;
            thisBtn.add(lbl);
            return thisBtn;
        };

        var getFilledButton = function (ttl) {
            var thisBtn = Ti.UI.createView(style.filledButton);
            var lbl = Ti.UI.createLabel(style.filledButtonTxt);
            lbl.text = ttl;
            thisBtn.add(lbl);
            return thisBtn;
        };

        var getSmallButton = function (ttl) {
            var thisBtn = Ti.UI.createView(style.smallButton);
            var lbl = Ti.UI.createLabel(style.mediumButtonLblMdTxt);            
            lbl.text = ttl;
            thisBtn.add(lbl);
            return thisBtn;
        };
		
		var getStoreRowStoreSelect = function(store, storeStatusObj){
			//var storeStatusTxtColor = storeStatusObj.label == "OPEN" ? "green" : (storeStatusObj.label == "");
            //Ti.API.info("Store Details: " + JSON.stringify(store));
			var isOpen = false;
			var future = false;
			if(storeStatusObj.label == "OPEN"){
				isOpen = true;
				storeStatusTxtColor = "#1fd311";
			}
			else if(storeStatusObj.label == "CLOSED"){
				storeStatusTxtColor = "#eb0029";	
			}
			else if(storeStatusObj.label == "FUTURE"){
				future = true;
				storeStatusTxtColor = "blue";
			}
			var storeStatusText = storeStatusObj.label,
			storeDistanceText = store.Distance;
			
			var storeHeaderTxt = store.Name,
			storeAddrTxt1 = store.Address,
			storeAddrTxt2 = store.City + ",",
			storeAddrTxt3 = store.State + ", " + store.Zip;
			var row =  Ti.UI.createTableViewRow(style.storeRowRow);
			var storeRow = Ti.UI.createView(style.storeRowView);
			row.isOpen = isOpen;
			row.future = storeStatusObj.futureBool;
			row.store = store;
			row.isMobile = store.IsMobile;
			row.storeName = store.Name;
			
			var storeStatusView, storeLocView;
			
			storeStatusView = Ti.UI.createView(style.storeStatusView);
			var statusLbl, locLbl;
			var imageView = Ti.UI.createImageView(style.storeImageView);
			
			statusLbl = Ti.UI.createLabel(style.storeStatusLbl);
			statusLbl.color = storeStatusTxtColor;
			statusLbl.text = storeStatusText;
			
			locLbl = Ti.UI.createLabel(style.storeDistanceLbl);
			locLbl.text = storeDistanceText + " miles";
			
			
			storeStatusView.add(imageView);
			storeStatusView.add(statusLbl);
			storeStatusView.add(locLbl);
			
			storeLocView = Ti.UI.createView({
				//width:Ti.UI.FILL,
				left:ro.ui.relX(90),
				right:ro.ui.relX(56),
				height:Ti.UI.SIZE,
				layout:'vertical'
			});
			var HdrLbl, AddrLbl1, AddrLbl2, AddrLbl3, EstTime;
			
			HdrLbl = Ti.UI.createLabel(style.storeAddressHdr);
			HdrLbl.text = storeHeaderTxt;// && storeHeaderTxt.length ? storeHeaderTxt.toUpperCase() : storeHeaderTxt;
			
			AddrLbl1 = Ti.UI.createLabel(style.storeAddressBody);
			AddrLbl1.text = storeAddrTxt1;
			
			AddrLbl2 = Ti.UI.createLabel(style.storeAddressBody);
			AddrLbl2.text = storeAddrTxt2; 
			
			AddrLbl3 = Ti.UI.createLabel(style.storeAddressBody);
            AddrLbl3.text = storeAddrTxt3;            
			
			storeLocView.add(HdrLbl);
			storeLocView.add(AddrLbl1);
			storeLocView.add(AddrLbl2);
            storeLocView.add(AddrLbl3);

            if (store.EstTime && store.EstTime != 0) {
                var Config = JSON.parse(Ti.App.Properties.getString('Config'));
                var carryoutLbl = 'Pickup';
                var deliveryLbl = 'Delivery';
                if (ro.utils.hasProp(Config, 'CarryoutLabel')) {
                    carryoutLbl = Config.CarryoutLabel;
                }
                if (ro.utils.hasProp(Config, 'DeliveryLabel')) {
                    deliveryLbl = Config.DeliveryLabel;
                }                
                var ordType = (Ti.App.OrderObj.ordOnlineOptions.IsDelivery ? deliveryLbl : carryoutLbl) + " - ";
                var estTime = store.EstTime + " Minutes";
                var text = ordType + estTime;
                var attributesCol = [];
                attributesCol.push(
                    {
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: '#eb0029',
                        range: [text.indexOf(estTime), estTime.length]
                    }
                );
                var attr = Ti.UI.createAttributedString({
                    text: text,
                    attributes: attributesCol
                });
                var timeStyle = JSON.parse(JSON.stringify(style.storeAddressBody));
                timeStyle.font.fontFamily = ro.ui.fonts.rowHdrTxt;
                EstTime = Ti.UI.createLabel(timeStyle);
                EstTime.attributedString = attr;                
                storeLocView.add(EstTime);
            }
			
			storeRow.add(storeStatusView);
			storeRow.add(storeLocView);
			var arrowView = Ti.UI.createView(style.arrowView);
			arrowView.add(Ti.UI.createImageView({
				image:'/images/rightArrow.png',
				touchEnabled:false
			}));
			storeRow.add(arrowView);
			row.add(storeRow);
			return row;
		};
		
		var getStoreRow = function(store, storeStatusObj){
			//var storeStatusTxtColor = storeStatusObj.label == "OPEN" ? "green" : (storeStatusObj.label == "");
			var isOpen = false;
			var future = false;
			if(storeStatusObj.label == "OPEN"){
				isOpen = true;
				storeStatusTxtColor = "#1fd311";
			}
			else if(storeStatusObj.label == "CLOSED"){
				storeStatusTxtColor = "#eb0029";	
			}
			else if(storeStatusObj.label == "FUTURE"){
				future = true;
				storeStatusTxtColor = "blue";
			}
			var storeStatusText = storeStatusObj.label,
			storeDistanceText = store.Distance;
			
			var storeHeaderTxt = store.Name,
			storeAddrTxt1 = store.Address,
			storeAddrTxt2 = store.City + ",",
			storeAddrTxt3 = store.State + ", " + store.Zip;
			
			var storeRow = Ti.UI.createTableViewRow(style.storeRow);
			storeRow.isOpen = isOpen;
			storeRow.future = future;
			storeRow.store = store;
			
			var storeStatusView, storeLocView;
			
			storeStatusView = Ti.UI.createView(style.storeStatusView);
			var statusLbl, locLbl;
			var imageView = Ti.UI.createImageView(style.storeImageView);
			
			statusLbl = Ti.UI.createLabel(style.storeStatusLbl);
			statusLbl.color = storeStatusTxtColor;
			statusLbl.text = storeStatusText;
			
			locLbl = Ti.UI.createLabel(style.storeDistanceLbl);
			locLbl.text = storeDistanceText + " miles";
			
			
			storeStatusView.add(imageView);
			storeStatusView.add(statusLbl);
			//storeStatusView.add(locLbl);
			
			storeLocView = Ti.UI.createView({
				//width:Ti.UI.FILL,
				left:ro.ui.relX(90),
                right:ro.ui.relX(56),
				height:Ti.UI.SIZE,
				layout:'vertical'
			});
			var HdrLbl, AddrLbl1, AddrLbl2, AddrLbl3;
			
			HdrLbl = Ti.UI.createLabel(style.storeAddressHdr);
			HdrLbl.text = storeHeaderTxt;// && storeHeaderTxt.length ? storeHeaderTxt.toUpperCase() : storeHeaderTxt;
			
			AddrLbl1 = Ti.UI.createLabel(style.storeAddressBody);
			AddrLbl1.text = storeAddrTxt1;
			
			AddrLbl2 = Ti.UI.createLabel(style.storeAddressBody);
			AddrLbl2.text = storeAddrTxt2; 
			
			AddrLbl3 = Ti.UI.createLabel(style.storeAddressBody);
			AddrLbl3.text = storeAddrTxt3;
			
			storeLocView.add(HdrLbl);
			storeLocView.add(AddrLbl1);
			storeLocView.add(AddrLbl2);
			storeLocView.add(AddrLbl3);
			
			storeRow.add(storeStatusView);
			storeRow.add(storeLocView);
			var arrowView = Ti.UI.createView(style.arrowView);
            arrowView.add(Ti.UI.createImageView({
                image:'/images/rightArrow.png',
                touchEnabled:false
            }));
            storeRow.add(arrowView);
			return storeRow;
		};
		
		var getBtnWrapper = function(){
			var wrapper = Ti.UI.createView(style.btnWrapper);
			wrapper.add(Ti.UI.createImageView({
				top:ro.ui.relY(5),
				image:'/images/halfLogo.png',
				height:'40%',
				bottom:ro.ui.relX(5)
				
			}));
			return wrapper;
		};
		
		//ADDRESS
		var getGenericHdrRow = function(label, autoSizeBool){
			var hdrRow = Ti.UI.createView(style.genericHdrRowView);
			if(autoSizeBool){
				hdrRow.height = Ti.UI.SIZE;
			}
			var hdrLblDict = style.genericHdrLbl;
			hdrLblDict.text = label;
			
			var hdrLbl = Ti.UI.createLabel(hdrLblDict);
			hdrRow.add(hdrLbl);
			
			return hdrRow;
		};
		var getEmptyGenericRow = function(obj){
			var rowViewDict = style.genericRowView;
			/*for(var props in obj.customObj){
				rowViewDict[props] = obj.customObj[props];
			}*/
			
			var genericRow = Ti.UI.createView(rowViewDict);
			genericRow.top = ro.ui.relY(20);
			
			
			var genericTxtView, arrowView;
			var genericLbl; 
			//var genericLblDict;//, genericTxtViewDict = style.genericTxtView;
			
			//genericLblDict = style.genericLbl;
			//genericLblDict.text = obj.formattedText;
			
			//genericTxtView = Ti.UI.createView(genericTxtViewDict);
			//genericLbl = Ti.UI.createLabel(genericLblDict);
			//genericTxtView.add(genericLbl);
			arrowView = Ti.UI.createView(style.arrowView);
			arrowView.add(Ti.UI.createImageView({
				image:'/images/rightArrow.png',
				touchEnabled:false
			}));
			
			//genericRow.add(genericTxtView);
			//if(!hideRowArrow){
				genericRow.add(arrowView);
			//}
			
			
			return genericRow;
        };
        var getRedLabel = function (txt) {
            return Ti.UI.createLabel(ro.combine(style.genericHdrLblWithHeader,{
                text: txt,
                color: '#eb0029'
            }));
        };
		var getGenericRow = function(obj, hideRowArrow){
			var rowViewDict = style.genericRowView;
			for(var props in obj.customObj){
				rowViewDict[props] = obj.customObj[props];
			}
			
			var genericRow = Ti.UI.createView(rowViewDict);
			
			
			var genericTxtView, arrowView;
			var genericLbl; 
			var genericLblDict, genericTxtViewDict = style.genericTxtView;
			
			genericLblDict = style.genericLbl;
			genericLblDict.text = obj.formattedText;
			
			genericTxtView = Ti.UI.createView(genericTxtViewDict);
			genericLbl = Ti.UI.createLabel(genericLblDict);
			genericTxtView.add(genericLbl);
			arrowView = Ti.UI.createView(style.arrowView);
			arrowView.add(Ti.UI.createImageView({
				image:'/images/rightArrow.png',
				touchEnabled:false
			}));
			
			genericRow.add(genericTxtView);
			if(!hideRowArrow){
				genericRow.add(arrowView);
			}
			
			
			return genericRow;
        };
        var getSpecialRow = function (obj, showDelete) {
            var rowViewDict = style.genericRowView;
            if(obj.customObj){
                for (var props in obj.customObj) {
                    rowViewDict[props] = obj.customObj[props];
                }
            }

            var genericRow = Ti.UI.createView(rowViewDict);
            genericRow.height = ro.ui.relY(80);    
            genericRow.top = ro.ui.relY(10);

            var genericTxtView, rightImgView;
            var genericHdr, genericLbl;
            var genericHdrDict, genericLblDict, genericTxtViewDict = style.genericTxtView;

            genericHdrDict = style.specialHdrLbl;
            genericHdrDict.bottom = 0;
            genericHdrDict.text = obj.formattedHdr;

            genericLblDict = style.genericLbl;
            genericLblDict.text = obj.formattedText;

            genericTxtView = Ti.UI.createView(genericTxtViewDict);
            genericTxtView.layout = 'vertical';
            genericTxtView.height = Ti.UI.SIZE;

            genericHdr = Ti.UI.createLabel(genericHdrDict);
            genericLbl = Ti.UI.createLabel(genericLblDict);
            genericLbl.text = obj.formattedText;

            genericTxtView.add(genericHdr);
            genericTxtView.add(genericLbl);

            rightImgView = Ti.UI.createView(style.arrowView);
            rightImgView.touchEnabled = showDelete;
            rightImgView.add(Ti.UI.createImageView({
                image: showDelete ? '/images/clearBtn.png' : '/images/rightArrow.png',
                touchEnabled: false
            }));            

            genericRow.add(genericTxtView);
            genericRow.add(rightImgView);


            return genericRow;
        };
		var getGenericMenuHdrRowWithHeader = function(label, fillLabelBln){
            var hdrRow = Ti.UI.createView(style.genericMenuHdrRowViewWithHeader);
            var hdrLblDict = style.genericMenuHdrLblWithHeader;
            hdrLblDict.text = label;
            
            var hdrLbl = Ti.UI.createLabel(hdrLblDict);
            if(fillLabelBln){
                hdrLbl.height = Ti.UI.FILL;
            }
            hdrRow.add(hdrLbl);
            
            return hdrRow;
        };
		var getGenericHdrRowWithHeader = function(label, largerBool){
			var hdrRow = Ti.UI.createView(style.genericHdrRowViewWithHeader);
			var hdrLblDict = largerBool ? style.genericHdrLblWithHeaderLarge : style.genericHdrLblWithHeader;
			hdrLblDict.text = label;
			
			var hdrLbl = Ti.UI.createLabel(hdrLblDict);
			hdrRow.add(hdrLbl);
			
			return hdrRow;
        };
        var getGenericHdrRowContent = function (label) {
            var hdrRow = Ti.UI.createView(style.genericHdrRowViewWithHeader);
            var hdrLblDict = style.genericHdrLblContent;
            hdrLblDict.text = label;

            var hdrLbl = Ti.UI.createLabel(hdrLblDict);
            hdrRow.add(hdrLbl);

            return hdrRow;
        };
		var getGenericRowWithHeader = function(obj){
			var rowViewDict = style.genericRowViewWithHeader;
			for(var props in obj.customObj){
				rowViewDict[props] = obj.customObj[props];
			}
			
			var genericRow = Ti.UI.createView(rowViewDict);
			
			var genericTxtView;
			var genericLbl, genericLblHdr; 
			var genericLblDict, genericHdrLblDict, genericTxtViewDict = style.genericTxtViewWithHeader;
			genericHdrLblDict = style.genericLblHdr;
			genericHdrLblDict.text = obj.headerText;
			genericLblDict = style.genericLblWithHeader;
			genericLblDict.text = obj.formattedText;
			
			genericTxtView = Ti.UI.createView(genericTxtViewDict);
			genericLblHdr = Ti.UI.createLabel(genericHdrLblDict);
			genericLbl = Ti.UI.createLabel(genericLblDict);
			genericTxtView.add(genericLblHdr);
			genericTxtView.add(genericLbl);
			
			if(obj.specialText && obj.specialText.specialBoldText && obj.specialText.specialBoldText.length){
				var attributesCol = [];
				var text = obj.specialText.specialText + obj.specialText.specialBoldText;
                attributesCol.push(
                    //{
      //              type: Ti.UI.ATTRIBUTE_FONT,
      //              value: {
      //              		fontSize:ro.ui.scaleFont(14),
						//fontFamily:ro.ui.fonts.rowHdrTxt
      //              },
      //              range: [text.indexOf(obj.specialText.specialBoldText), obj.specialText.specialBoldText.length]
      //          },
                    {
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: '#eb0029',
                        range: [text.indexOf(obj.specialText.specialBoldText), obj.specialText.specialBoldText.length]
                    }
                );
	            var attr = Ti.UI.createAttributedString({
	                text: text,
	                attributes: attributesCol
	            });
				var specialLbl = Ti.UI.createLabel({
					attributedString:attr,
					textAlign:'left',
					font:{
						fontSize:ro.ui.scaleFont(14),
                        fontFamily: ro.ui.fonts.rowHdrTxt                        
					},
					left:ro.ui.relX(25),
                    touchEnabled: false,
                    color: '#393839'
				});
				genericTxtView.add(specialLbl);
			}
			
			genericRow.add(genericTxtView);
			return genericRow;
		};
        var getMediumRowLbl = function (label) {            
            var lblDict = style.genericMediumLbl;
            lblDict.text = label;
            lblDict.textAlign = 'left';
            lblDict.left = ro.ui.relX(10);
            var lbl = Ti.UI.createLabel(lblDict);
            return lbl;
        };
        var getMediumRowBoldLbl = function (label) {
            var lblDict = style.genericMediumBoldLbl;
            lblDict.text = label;
            lblDict.textAlign = 'right';
            lblDict.right = 0;
            var lbl = Ti.UI.createLabel(lblDict);
            return lbl;
        };

        var getCustomMenuRow = function(hdrTxt, bodyTxt, url, _callback) {
            var campaignRowVw = getEmptyGenericRow();
            //campaignRowVw.hcCode = hcCode;
            var imageHolderWidth = ro.isiOS ? ro.ui.relX(40) : ro.ui.relX(40);

            //Ti.API.debug('noteTxt: ' + noteTxt);
            //Ti.API.debug('currRewardExpirTxt: ' + currRewardExpirTxt);

            var fontSize = ro.ui.scaleFont(18);
            var imageHolder = Ti.UI.createView({
                left: 0,
                width: imageHolderWidth,
                height: Ti.UI.FILL,
                touchEnabled: false
            });
            var theImage = Ti.UI.createImageView({
                image: url,
                touchEnabled: false
            });
            if(ro.isiOS){
            	theImage.left = 2;
            }
            imageHolder.add(theImage);
            var labelHolder = Ti.UI.createView({
                left: imageHolderWidth,
                right: ro.ui.relX(65),
                height: Ti.UI.FILL,
                layout: 'vertical',
                touchEnabled: false
            });
            var topLblHolder,
                bottomLblHolder;
            var topLblHolder = Ti.UI.createView({
                touchEnabled: false,
                width: Ti.UI.FILL,
                height: '50%'
            });
            topLblHolder.add(Ti.UI.createLabel({
                touchEnabled: false,
                color: '#393839',
                font: {
                    fontFamily: ro.ui.fonts.rowHdrTxt,
                    fontSize: fontSize
                },
                text: hdrTxt,
                left: ro.ui.relX(5),
                bottom: 0
            }));

            var bottomLblHolder = Ti.UI.createView({
                touchEnabled: false,
                width: Ti.UI.FILL,
                layout: 'horizontal',
//                height:Ti.UI.SIZE
                height: Ti.UI.FILL
            });
            bottomLblHolder.add(Ti.UI.createLabel({
                touchEnabled: false,
                color: '#393839',
                font: {
                    fontFamily: ro.ui.fonts.rowBodyTxt,
                    fontSize: fontSize
                },
                text: bodyTxt,
                height:ro.ui.relY(15),
                left: ro.ui.relX(5)
            }));
            /*bottomLblHolder.add(Ti.UI.createLabel({
                touchEnabled: false,
                color: '#393839',
                font: {
                    fontFamily: ro.ui.fonts.rowBodyTxt,
                    fontSize: fontSize
                },
                text: currRewardExpirTxt || "",
                left: ro.ui.relX(10)
            }));*/

            labelHolder.add(topLblHolder);
            labelHolder.add(bottomLblHolder);

            campaignRowVw.add(imageHolder);
            campaignRowVw.add(labelHolder);

            if (_callback) {
                //Ti.API.debug('added Event');
                campaignRowVw.addEventListener('click', _callback);
            }
            
            return campaignRowVw;
        };

        var getGuestInfoRowHeader = function (label) {
            var hdrRow = Ti.UI.createView(style.genericHdrRowViewWithHeader);
            var hdrLblDict = style.guestInfoHeaderBoldLbl;
            hdrLblDict.text = label;

            var hdrLbl = Ti.UI.createLabel(hdrLblDict);
            hdrRow.add(hdrLbl);

            return hdrRow;
        };

		//ADDRESS
		function createNewRows(totalGroupCol, _rowCallback, clickEvt){
                try{
                    var thisGrpRow, rowData = [], GrpLngth, favoriteOrders, cpnObj;
                  
                  //var totalGroupCol = [];
                    
                    //totalGroupCol = totalGroupCol.concat(Groups);
                    //totalGroupCol = Groups.concat(totalGroupCol);
                    GrpLngth = totalGroupCol.length;
                    var oddEvenCtr = 1;
                    for(var i=0; i < GrpLngth; i+=2){               //GROUPS ROW
                        if(i+1 < GrpLngth){
                            thisGrpRow = addNewRow(totalGroupCol[i], totalGroupCol[i+1], (oddEvenCtr%2 != 0), clickEvt);
                        }
                        else{
                            thisGrpRow = addNewRow(totalGroupCol[i], null, (oddEvenCtr%2 != 0), clickEvt);
                        }
                        rowData.push(thisGrpRow);
                        oddEvenCtr++;
                    }
                    _rowCallback(rowData);
                }
                catch(ex){
                    if(Ti.App.DEBUGBOOL)    { Ti.API.debug('createNewRows()-Exception' + ex); }
                }
            }
            function circleView(moreTop, isOdd, invisCircle){
                return Ti.UI.createView({
                    borderRadius:ro.ui.relX(2.5),
                    height:ro.ui.relX(6),
                    width:ro.ui.relX(6),
                    backgroundColor:invisCircle ? ('transparent') : (isOdd ? '#e4e4e4' : '#f6f6f6'),
                    //backgroundColor:isOdd ? "#e4e4e4" : "#f6f6f6",
                    top:moreTop ? (ro.isiOS ? ro.ui.relY(2) : ro.ui.relY(7)) : ro.ui.relY(5)
                });
            }
            function getMiddleBorder(isOdd){
                var middleBorder = Ti.UI.createView({
                    height:Ti.UI.FILL,
                    width:'2%',
                    layout:'vertical'
                });
                
                //if(isOdd){
                    var moreTop = false;
                    var invisCircle = false;
                    for(var i=0, iMax=ro.isiOS ? 15 : 17; i<iMax; i++){
                        moreTop = false;
                        invisCircle = false;
                        if(i==0) moreTop = true;
                        if(i==0 || (i+1 == iMax)) invisCircle = true;
                        middleBorder.add(circleView(moreTop, isOdd, invisCircle));
                    }
                //}
                
                return middleBorder;
            }
            
		function addNewRow(GRP1, GRP2, isOdd, clickEvt){
                var stretchRowImg = function(GRPName){
                    if(Ti.App.picklemansStyle){
                        return GRPName != 'Coupons' && GRPName != 'My Rewards' && GRPName != 'Orders';
                    }
                    return false;
                };
                
                function createBtns(GRP, clickEvt){
                    var rowView, rowImg, label;
                    var imagePath = GRP.defImg?GRP.defImg:ro.ui.properties.defaultPath + 'default.png';
                    var theRow = Ti.UI.createView({
                        name:GRP.Name,
                        hasBadge:GRP.IsLoyalty?true:false,
                       //backgroundImage:'/images/menuItemBg.png',
                        //height:ro.ui.relY(120),
                        //width:'48%'
                        width:'48%',
                        height:Ti.UI.FILL
                    });
                    /*useToMakeRows[i].grpIndx, 
                    useToMakeRows[i].itmIndx, 
                    useToMakeRows[i].sugg.SuggSizeName, 
                    useToMakeRows[i].sugg.SuggStyleName*/
                    rowView = Ti.UI.createView({
                        name:GRP.Name,
                        label:GRP.Name,
                        //backgroundImage:'/images/menuItemBg.png',
                        height:Ti.UI.FILL,
                        top:ro.ui.relY(3),
                        bottom:ro.ui.relY(3),
                        right:ro.ui.relX(1),
                        left:ro.ui.relX(1),
                        width:Ti.UI.FILL,
                        grpIndx: GRP.grpIndx,
                        itmIndx: GRP.itmIndx,
                        SuggSizeName: GRP.sugg.SuggSizeName,
                        SuggStyleName: GRP.sugg.SuggStyleName
                    });
                    
                    /*backgroundImg = Ti.UI.createImageView({
                        image:Ti.App.websiteURL+'/content/images/menu-item.png',
                        defaultImage:'/images/menuItemBg.png',
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL,
                        zIndex: -1000,
                        touchEnabled: false,
                        borderRadius:Ti.App.JETSDEMO ? ro.ui.relX(7) : null,
                        borderColor:Ti.App.JETSDEMO ? ro.ui.theme.jetsdemo : null,
                        borderWidth:Ti.App.JETSDEMO ? ro.ui.relX(1.5) : null
                    });*/
                    /*backgroundImg = Ti.UI.createImageView({
                        image:Ti.App.websiteURL+'/content/images/menu-item.png',
                        defaultImage:'/images/menuItemBg.png',
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL,
                        zIndex: -1000,
                        touchEnabled: false
                    });*/
                    //rowView.add(backgroundImg);
                    
                    var imgHolder = Ti.UI.createView({
                        top:stretchRowImg(GRP.Name) ? ro.ui.relY(0) : ro.ui.relX(5),
                       //top:stretchRowImg(GRP.Name) ? ro.ui.relY(0) : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? ro.ui.relY(5) : ro.ui.relY(5)),//ro.ui.relY(20),
                       height:stretchRowImg(GRP.Name) ? ro.ui.relY(95) : '95%',
                       //height:stretchRowImg(GRP.Name) ? ro.ui.relY(95) : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? (GRP.Name == 'My Rewards' ? '80%' : '80%') : '80%'),//60/////87
                       width:stretchRowImg(GRP.Name) ? Ti.UI.FILL : '95%',
                       label:GRP.Name,
                       //borderColor:'green',
                       //borderWidth:3,
                       touchEnabled:false
                       //width:stretchRowImg(GRP.Name) ? Ti.UI.FILL : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? (GRP.Name == 'My Rewards' ? '80%' : '80%') : '80%')
                    });
                    
                    
                    rowImg = Ti.UI.createImageView({
                        //borderColor:'purple',
                        //borderWidth:2,
                        image:GRP.ImageSource,
                        defaultImage:imagePath,
                        label:GRP.Name,
                        touchEnabled:false,
                        //width:Ti.UI.SIZE,
                        //height:Ti.UI.SIZE
                        //width:Ti.UI.FILL,
                        left:ro.ui.relX(10),
                        right:ro.ui.relX(10),
                        bottom:ro.ui.relY(55),
                        //bottom:ro.ui.relY(10)
                        //height:Ti.UI.FILL
                    });
                    var gpNm = GRP.DisplayName || GRP.ReceiptName || GRP.Name;
                    /*if(gpNm){
                       gpNm = gpNm.toUpperCase();
                    }*/
                    label = Ti.UI.createLabel({
                        text:gpNm && gpNm.length ? gpNm.toUpperCase() : gpNm,
                        width:Ti.UI.FILL,
                        textAlign:'center',
                        color:ro.ui.theme.newGroupsBtnTxt,
                        font:{
                            fontSize:ro.ui.scaleFontY(24,14),
                            //fontWeight:'bold',
                             fontFamily:ro.ui.fonts.titles
                        },
                        touchEnabled:false,
                        //top:ro.ui.relY(5),
                        //height:Ti.UI.SIZE,
                        bottom:ro.ui.relY(30)
                    });
                    
                    if(false){
                        imgHolder.height = ro.ui.relY(65);
                        imgHolder.width = ro.ui.relY(105);
                        label.bottom = ro.ui.relY(5);
                        //label.color = ''
                        rowView.layout = 'vertical';
                        //label
                        //label.
                    }
                    else{
                        label.height = Ti.UI.SIZE;
                    }
                    
                    if(clickEvt){
                        rowView.addEventListener('click', function(e){
                            clickEvt(e);
                        });
                    }
                    else{
                        rowView.addEventListener('click', function(ex){
                            //Ti.API.debug('ex: ' + JSON.stringify(ex));
                            Ti.App.grpIndex = ex.source.label;
                            Ti.App.cpnGrpIndex = ex.source.label;
                            ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
                        });
                    }
    
                    imgHolder.add(rowImg);
                    rowView.add(imgHolder);
                    rowView.add(label);
                    theRow.add(rowView);
                    //return rowView;
                    
                    if(GRP.IsLoyalty){
                        theRow.badge = getBadge();
                        theRow.add(theRow.badge);
                        var newRow = theRow;
                        newRow.hasBadge = true;
                        theRow = newRow;
                        newRow = null;
                        //theRow.hasBadge = true;
                        theRow.badge.setBadge();
                    }
                    
                    return theRow;
                }
    
                var thisRow = Ti.UI.createView({
                    //borderColor:'green',
                    //borderWidth:2,
                    layout:'horizontal',
                    width:Ti.UI.FILL
                });
    
                var rowView = createBtns(GRP1, clickEvt);
                //rowView.left = ro.ui.relX(3);
                thisRow.add(rowView);
    
                var rowView1;
                if(GRP2){
                    rowView1 = createBtns(GRP2, clickEvt);
                    //rowView1.left = ro.ui.relX(10);
                    var middleBorder = getMiddleBorder(isOdd);
                    if(isOdd){
                        //thisRow.backgroundColor = 'blue';
                        thisRow.backgroundColor = '#f6f6f6';
                    }
                    thisRow.add(middleBorder);
                    thisRow.add(rowView1);
                }
                
                var tempRowHeight = ((ro.ui.displayCaps.platformWidth - ro.ui.relX(25)) / 2);
                var rowHeight = ((ro.ui.displayCaps.platformWidth - ro.ui.relX(6)) / 2);
                Ti.API.debug('ro.ui.displayCaps.displayWidth: ' + ro.ui.displayCaps.platformWidth);
                Ti.API.debug('rowHeight: ' + rowHeight);
                Ti.API.debug('oldRowHeight: ' + ro.ui.relY(125));
                grpRow = Ti.UI.createTableViewRow({
                    selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                    height:tempRowHeight//ro.ui.relY(125)//,
                    //width:Ti.UI.FILL
                });
                grpRow.add(thisRow);
                return grpRow;
            }
		
		ro.layout = {
			getBigSecondaryButton: getBigSecondaryButton,
            getSettingsButton: getSettingsButton,
            getPrimaryButton: getPrimaryButton,
            getSecondaryButton: getSecondaryButton,
            getMediumButton: getMediumButton,
            getSmallButton: getSmallButton,
            getFilledButton: getFilledButton,
			getBtnWrapper: getBtnWrapper,
			
			getStoreRow: getStoreRow,
			getStoreRowStoreSelect: getStoreRowStoreSelect,
			
			getEmptyGenericRow:getEmptyGenericRow,
			
			getGenericRow: getGenericRow,
            getGenericHdrRow: getGenericHdrRow,
            getSpecialRow: getSpecialRow,
			
			getGenericRowWithHeader: getGenericRowWithHeader,
            getGenericHdrRowWithHeader: getGenericHdrRowWithHeader,
            getGenericHdrRowContent: getGenericHdrRowContent,
            getGenericMenuHdrRowWithHeader: getGenericMenuHdrRowWithHeader,
            getGuestInfoRowHeader: getGuestInfoRowHeader,
			
			getCustomMenuRow: getCustomMenuRow,
            createNewRows: createNewRows,
            getRedLabel: getRedLabel,
            getMediumRowLbl: getMediumRowLbl,
            getMediumRowBoldLbl: getMediumRowBoldLbl
		};
	};
	return {
		layout:layout
	};
	/*return {
		getBigSecondaryButton: getBigSecondaryButton,
		getSettingsButton: getSettingsButton,
		getMediumButton: getMediumButton,
		getStoreRow: getStoreRow,
		getBtnWrapper: getBtnWrapper
	};*/
}();
module.exports = LAYOUT;