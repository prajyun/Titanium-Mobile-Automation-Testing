 // "Constants"
var FORMS = function(){
    var forms = function(ro){
    
        var STYLE_HINT = 'hint';
        var STYLE_LABEL = 'label';
        
        var TYPE_DATE = 'date';
        var TYPE_EMAIL = 'email';
        var TYPE_NUMBER = 'number';
        var TYPE_PASSWORD = 'password';
        var TYPE_PHONE = 'phone';
        var TYPE_PICKER = 'picker';
        var TYPE_TEXT = 'text';
        var TYPE_SUBMIT = 'submit';
        var TYPE_CHECKBOX = 'checkbox';
        var TYPE_EXPIRY = 'exDate';
        var TYPE_INSTRUCTIONS = 'spclInst';
        var TYPE_LABEL = 'lbl';
        var TYPE_CARDIMAGES = 'cardImages';
        
        var focusField = function(fieldToFocus){
            
            var form = this;
            if(!form || !form.fieldRefs) return;
            //Ti.API.debug('form: ' + JSON.stringify(form));
            //Ti.API.debug('form.fieldRefs: ' + JSON.stringify(form.fieldRefs));
            for(var field in form.fieldRefs){
                //Ti.API.debug('field: ' + JSON.stringify(field));
                if(field == fieldToFocus){
                    form.fieldRefs[field].focus();
                }
            }
            //for(var i=0)
        };
        var phoneField, creditField;
        var phoneDash = function(){
           phoneField.removeEventListener('change', phoneDash);
           var trimmedStr = phoneField.value.replace(/-/g,'');
           changePhoneValue(trimmedStr);
        };
        
        var changePhoneValue = function(value){
           var length = value.length;
           var newVal = value;
           if(length > 3 && length < 7){
              newVal = value.substr(0,3) + '-' + value.substr(3);
           }
           else if(length > 6 && length <= 10){
              newVal = value.substr(0,3) + '-' + value.substr(3,3) + '-' + value.substr(6);
           }
           else if(length > 10){
              newVal = phoneField.value.slice(0, 12);
           }
           phoneField.value = newVal;
           phoneField.setSelection(phoneField.value.length, phoneField.value.length);
           setTimeout(function(){
              phoneField.addEventListener('change', phoneDash);
           }, 100);
        };
        //Ti.include('/logic/creditCard.js');
        var ccHelper = require('logic/creditCard');
        var ccChangeEvt = function(){
           creditField.removeEventListener('change', ccChangeEvt);
           var trimmedStr = this.value.replace(/-/g,'');
           
           
           if(trimmedStr && trimmedStr.length == 1){//General credit card beginning check
              if(trimmedStr != 3 && trimmedStr != 4 && trimmedStr != 5 && trimmedStr != 6){
                   creditField.value = '';
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
              }
           }
           
           if(trimmedStr && trimmedStr.length == 2){//General mastercard amex and discover middle check
              if(trimmedStr[0] == 5){//mastercard
                if(trimmedStr[1] == 0 || trimmedStr[1] > 5){
                   creditField.value = trimmedStr[0];
                   creditField.setSelection(creditField.value.length, creditField.value.length);
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
                }
              }
              else if(trimmedStr[0] == 3){//amex
                if(trimmedStr[1] != 4 && trimmedStr[1] != 7){
                   creditField.value = trimmedStr[0];
                   creditField.setSelection(creditField.value.length, creditField.value.length);
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
                }
              }
              else if(trimmedStr[0] == 6){//discover
                if(trimmedStr[1] != 0 && trimmedStr[1] != 5){
                   creditField.value = trimmedStr[0];
                   creditField.setSelection(creditField.value.length, creditField.value.length);
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
                }
              }
           }
           
           if(trimmedStr && trimmedStr.length == 3){//general discover late check one
              if(trimmedStr[0] == 6 && trimmedStr[1] == 0 && trimmedStr[2] != 1){
                creditField.value = trimmedStr[0] + trimmedStr[1];
                creditField.setSelection(creditField.value.length, creditField.value.length);
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
              }
           }
           
           if(trimmedStr && trimmedStr.length == 4){//general discover late check two
              if(trimmedStr[0] == 6 && trimmedStr[1] == 0 && trimmedStr[2] == 1 && trimmedStr[3] != 1){
                creditField.value = trimmedStr[0] + trimmedStr[1] + trimmedStr[2];
                creditField.setSelection(creditField.value.length, creditField.value.length);
                   setTimeout(function(){
                      creditField.addEventListener('change', ccChangeEvt);
                   }, 100);
                   return;
              }
           }
           
           
           //Ti.API.debug('trimmedStr: ' + trimmedStr);
            var cardType = ccHelper.FindLikelyPattern(trimmedStr);
            //Ti.API.debug('cardType: ' + cardType);
            if(cardType == 'amex'){
               this.maxLength = 17;
            }
            else{
               this.maxLength = 19;
            }
            this.parent.children[1].toggle(cardType);
           
           if(this.maxLength === 19){
              ccDashes(trimmedStr);
           }
           else{
              amexDashes(trimmedStr);
           }
        };
        var ccDashes = function(value){
           var length = value.length;
           var newVal = value;
           var totalLength = creditField.maxLength;
        
           if(length > 4 && length <= 8){
              newVal = value.substr(0,4) + '-' + value.substr(4);
           }
           else if(length > 8 && length <= 12){
              newVal = value.substr(0,4) + '-' + value.substr(4,4) + '-' + value.substr(8);
           }
           else if(length > 12 && length < 16){
              newVal = value.substr(0,4) + '-' + value.substr(4,4) + '-' + value.substr(8,4) + '-' + value.substr(12);
           }
           else if(length > 15){
              newVal = creditField.value.slice(0, totalLength);
           }
        
           creditField.value = newVal;
        
           //Ensure cursor correctness
           creditField.setSelection(creditField.value.length, creditField.value.length);
        
           //Reinit change evt
           setTimeout(function(){
              creditField.addEventListener('change', ccChangeEvt);
           }, 100);
           //_callback();
        };
        var amexDashes = function(value/*, _callback*/){
           //Ti.API.debug('amexDashes - value: ' + value);
        
           var length = value.length;
           var newVal = value;
           var totalLength = creditField.maxLength;//3 for the hyphens
        
           if(length > 4 && length <= 10){
              newVal = value.substr(0,4) + '-' + value.substr(4);
           }
           else if(length > 10 && length < 15){
              newVal = value.substr(0,4) + '-' + value.substr(4,6) + '-' + value.substr(10);
           }
           else if(length > 14){
              newVal = creditField.value.slice(0, totalLength);
           }
        
           creditField.value = newVal;
        
           //Ensure cursor correctness
           creditField.setSelection(creditField.value.length, creditField.value.length);
        
           //Reinit change evt
           setTimeout(function(){
              creditField.addEventListener('change', ccChangeEvt);
           }, 100);
           //_callback();
        };
        
        //WOULD IT BE BETTER TO LEAVE IT AS A LOCAL OBJECT?
        var date = new Date();
        var MONTHS_LIST = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var YEAR_LIST = [];
        for(var i=0; i<8; i++){
           YEAR_LIST[i] = date.getFullYear()+i;
        }
        //WOULD IT BE BETTER TO LEAVE IT AS A LOCAL OBJECT?
        
        var isAndroid = true;//Ti.Platform.osname === 'android';
        var textFieldDefaults = ro.combine(ro.ui.properties.allTxtField, {
            height:ro.ui.relY(40),
            //width:ro.ui.relX(325),
            top:ro.ui.relY(10),
            bottom:ro.ui.relY(25),//15
            returnKeyType:Ti.UI.RETURNKEY_NEXT,
            borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
            padding:{
                left:ro.ui.relX(9)
            }
        });
        var lgTextFieldDefaults = {
           borderColor:ro.ui.theme.txtFieldBrdrClr,
           height:ro.ui.relY(130),
           //width:Ti.UI.FILL,//ro.ui.relX(250),
           right:ro.ui.relX(5),
           left:ro.ui.relX(5),
           top:ro.ui.relY(0),
           color:'#222',
           scrollable:false,
           font:{
              fontSize:ro.ui.scaleFont(11, 0, 0),
                    fontFamily:ro.ui.fontFamily
           },
           borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
           backgroundColor:'white'
        };
        
        var thisForm = {forgotPass:false};
        
        var keyboardMap = {};
        keyboardMap[TYPE_EMAIL] = Ti.UI.KEYBOARD_TYPE_EMAIL;
        keyboardMap[TYPE_NUMBER] = Ti.UI.KEYBOARD_TYPE_NUMBER_PAD;
        //keyboardMap[TYPE_NUMBER] = Ti.UI.KEYBOARD_TYPE_DEFAULT;
        keyboardMap[TYPE_PASSWORD] = Ti.UI.KEYBOARD_TYPE_DEFAULT;
        keyboardMap[TYPE_PHONE] = Ti.UI.KEYBOARD_TYPE_NUMBER_PAD;
        //keyboardMap[TYPE_PHONE] = Ti.UI.KEYBOARD_TYPE_DEFAULT;
        keyboardMap[TYPE_TEXT] = Ti.UI.KEYBOARD_TYPE_DEFAULT;
        
        
        var handleStyle = function(form, textField, title){
            if(form.fieldStyle === STYLE_HINT && textField){
                textField.hintText = title;
            }
            else{
                /*form.container.add(Ti.UI.createLabel({
                    text:title,
                    top:ro.ui.relY(15),
                    left:ro.ui.relX(35),
                    color:title==='Special Instructions'?ro.ui.theme.contentsSmallTxt:thisForm.forgotPass?ro.ui.theme.forgotPassHdrs:ro.ui.theme.settingsHdrs,
                    font:{
                        fontSize:ro.ui.scaleFont(16,0,0),
                        fontWeight:'bold',
                    fontFamily:ro.ui.fontFamily
                    },
                    height:Ti.UI.SIZE,
                    width:Ti.UI.SIZE
                }));*/
                var lblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
                   //width:Ti.UI.FILL,
                   height:0,
                   width:ro.ui.relX(250),
                   borderColor:'transparent',
                   backgroundColor:'transparent'
                }));
                lblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
                 //text:'SELECT YOUR ADDRESS:',
                 color:ro.ui.theme.formsJsHeadersTxt,
                 font:{
                    fontSize:ro.ui.scaleFont(12.5, 0, 0),
                    fontWeight:'bold',
                    fontFamily:ro.ui.fontFamily
                 },
                 //text:title?title.toUpperCase():''
              })));
                form.container.add(lblView);
                if(textField){
                    textField.top = 0;
                }
            }
        };
        
        var setupPickerTextField = function(textField, pickerType, data) {
            textField.editable = false;
            textField.rightButton = Ti.UI.createButton({
                //style: Ti.UI.iPhone.SystemButton.DISCLOSURE,
                transform: Ti.UI.create2DMatrix().rotate(90)
            });
            textField.rightButtonMode = Ti.UI.INPUT_BUTTONMODE_ALWAYS;
        
            textField.addEventListener('focus', function(e) {
                e.source.blur();
                require('semiModalPicker').createSemiModalPicker({
                    textField: textField,
                    value: textField.value,
                    type: pickerType,
                    data: data
                }).open({animated:true});
            });
        };
        
        var clearFields = function(){
           try{
              ro.GlobalPicker.hidePicker();
              var date = new Date();
              var form = this;
              for(var itm in form.fieldRefs){
                 if(itm === 'addrtype' || itm === 'title' || itm === 'state' || itm === 'ccType' || itm === 'expYear' || itm === 'expMonth'){
                    //form.fieldRefs[itm].setSelectedRow(0, (itm==='expMonth'?date.getMonth():0), true);
                    form.fieldRefs[itm].picker.setSelectedRow(0, (itm==='expMonth'?date.getMonth():0), true);
                    //form.fieldRefs[itm].setLblText(itm==='expMonth'?date.getMonth():0);
                 }
                 else if(itm === 'unitnum' || itm === 'unitname'){
                    form.fieldRefs[itm].value = 'N/A';
                 }
                 else if(itm === 'isDefault' || itm === 'ccDefault' || itm === 'ccSave' || itm === 'addrSave'){
                    form.fieldRefs[itm].value = false;
                 }
                 else if(itm === 'ccAccepted'){
                    for(var i=0, iMax=form.fieldRefs[itm].children.length; i<iMax; i++){
                        form.fieldRefs[itm].children[i].image = '/images/' + form.fieldRefs[itm].children[i].id + '.png'; 
                    }
                 }
                 else{
                    form.fieldRefs[itm].value = null;
                 }
              }
              date = null;
           }
           catch(e){
              ro.ui.alert('Error: Method clearFields' + e);
           }
        };
        var mapStates = function(states){
            return states.slice(0).map(function(state){
                return state.StateAbbreviation;
            });
        };
        var setFields = function(dbVal){
          try{
             var states = mapStates(Ti.App.Properties.getList('states'));
             var types = Ti.App.Properties.getList('addrTypes');
             var titles = Ti.App.Properties.getList('titles');
             var creditCards = Ti.App.Properties.getList('creditcards', ['VISA', 'MC', 'AMEX', 'DISC']);
             var form = this;
             for(var itm in form.fieldRefs){
                switch(itm){
                   case 'label':
                      form.fieldRefs[itm].value = dbVal.Label;
                      break;
                   case 'addrtype':
                      try{
                         if(true || ro.isiOS){
                            //form.fieldRefs[itm].text = dbVal.AddrTypeName;
                            form.fieldRefs[itm].setLblText(dbVal.AddrTypeName);
                            form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(dbVal.AddrTypeName, types), true);
                         }
                         else{
                            form.fieldRefs[itm].setSelectedRow(0, setPickerValue(dbVal.AddrTypeName, types), true);
                         }
                      }
                      catch(ex){
                         if(Ti.App.DEBUGBOOL)   { Ti.API.debug('form.setFields()-Exception: ' + ex); }
                      }
                      break;
                   case 'unitnum':
                      if(dbVal.AddrTypeName && dbVal.AddrTypeName != 'House'){
                         form.fieldRefs[itm].value = dbVal.SUD;
                      }
                      break;
                   case 'unitname':
                      if(dbVal.AddrTypeName && dbVal.AddrTypeName != 'House'){
                         form.fieldRefs[itm].value = dbVal.CustAddrTypeName;
                      }
                      break;
                   case 'stnum':
                      form.fieldRefs[itm].value = dbVal.StNum;
                      break;
                   case 'stname':
                      form.fieldRefs[itm].value = dbVal.St;
                      break;
                   case 'city':
                      form.fieldRefs[itm].value = dbVal.City;
                      break;
                   case 'state':
                      if(true || ro.isiOS){
                         //form.fieldRefs[itm].text = dbVal.State;
                         Ti.API.debug('dbVal: ' + JSON.stringify(dbVal));
                         form.fieldRefs[itm].setLblText(dbVal.State);
                         form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(dbVal.State, states), true);
                      }
                      else{
                         form.fieldRefs[itm].setSelectedRow(0, setPickerValue(dbVal.State, states), true);
                      }
                      break;
                   case 'zip':
                      form.fieldRefs[itm].value = dbVal.Zip;
                      break;
                   case 'email'://NEWLY ADDED FOR GUEST ORDER INFO FILL
                      form.fieldRefs[itm].value = dbVal.Email;
                      break;
                   case 'title':
                      if(true || ro.isiOS){
                         //form.fieldRefs[itm].text = dbVal.Title;
                         form.fieldRefs[itm].setLblText(dbVal.Title);
                         form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(dbVal.Title, titles), true);
                      }
                      else{
                         form.fieldRefs[itm].setSelectedRow(0, setPickerValue(dbVal.Title, titles), true);
                      }
                      break;
                   case 'firstname':
                      form.fieldRefs[itm].value = dbVal.FirstName;
                      break;
                   case 'lastname':
                      form.fieldRefs[itm].value = dbVal.LastName;
                      break;
                   case 'phone':
                      var phoneWithDashes = dbVal.Phone;
                      if(dbVal && dbVal.Phone && dbVal.Phone.length){
                         if(dbVal.Phone.length == 10){
                            phoneWithDashes = dbVal.Phone.slice(0,3) + '-' + dbVal.Phone.slice(3,6) + '-' + dbVal.Phone.slice(6,10);
                            //phoneWithDashes = dbVal.Phone.slice(0,3) + '-' + dbVal.Phone.slice(4,7) + '-' + dbVal.Phone.slice(8,12);
                         }
                        // Ti.API.debug('phoneWithDashes: ' + phoneWithDashes);
                      }
                      form.fieldRefs[itm].value = phoneWithDashes;
                      break;
                   case 'extension':
                      form.fieldRefs[itm].value = dbVal.Ext;
                      break;
                   case 'ccAccepted':
                      for(var i=0, iMax=form.fieldRefs[itm].children.length; i<iMax; i++){
                         if(form.fieldRefs[itm].children[i].id === dbVal.CardInfo){
                            form.fieldRefs[itm].children[i].image = '/images/' + dbVal.CardInfo + 'Chosen.png';
                            break;
                         }
                         /*else{
                            form.fieldRefs[itm].children[i].image = '/images/' + form.fieldRefs[itm].children[i].id + '.png';
                         }*/
                      }
                      
                      break;
                   case 'ccType':
                      if(true || ro.isiOS){
                         //form.fieldRefs[itm].text = dbVal.CardInfo;
                         form.fieldRefs[itm].setLblText(dbVal.CardInfo);
                         form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(dbVal.CardInfo, creditCards), true);
                      }
                      else{
                         form.fieldRefs[itm].setSelectedRow(0, setPickerValue(dbVal.CardInfo, creditCards), true);
                      }
                      break;
                   case 'ccNum':
                      form.fieldRefs[itm].value = dbVal.OLCardNum;
                      break;
                   case 'ccName':
                      form.fieldRefs[itm].value = dbVal.PayerName;
                      break;
                   case 'expMonth':
                      if(true || ro.isiOS){
                         //form.fieldRefs[itm].text = dbVal.OLExpMonth;//MONTHS_LIST[dbVal.OlExpMonth];
                         form.fieldRefs[itm].setLblText(dbVal.OLExpMonth);
                         form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(dbVal.OLExpMonth, MONTHS_LIST), true);//Before calling this setFields function...must split apart and assign month todbVal.ccMonth
                      }
                      else{
                         form.fieldRefs[itm].setSelectedRow(0, setPickerValue(dbVal.OLExpMonth, MONTHS_LIST), true);//Before calling this setFields function...must split apart and assign month todbVal.ccMonth
                      }
                      break;
                   case 'expYear':
                      if(true || ro.isiOS){
                         //form.fieldRefs[itm].text = dbVal.OLExpYear;
                         form.fieldRefs[itm].setLblText(dbVal.OLExpYear);
                         form.fieldRefs[itm].picker.setSelectedRow(0, setPickerValue(parseInt(dbVal.OLExpYear, 10), YEAR_LIST), true);//Before calling this setFields function...must split apart and assign year todbVal.ccYear
                      }
                      else{
                        form.fieldRefs[itm].setSelectedRow(0, setPickerValue(parseInt(dbVal.OLExpYear, 10), YEAR_LIST), true);//Before calling this setFields function...must split apart and assign year todbVal.ccYear
                      }
                      break;
                   case 'cvvNum':
                      form.fieldRefs[itm].value = dbVal.OLSecCode;
                      break;
                   case 'ccDefault':
                      //form.fieldRefs[itm].value = (dbVal.ccDefault)?true:false;
                      form.fieldRefs[itm].toggle(dbVal.ccDefault);
                      break;
                   case 'BillingZip':
                      form.fieldRefs[itm].value = dbVal.AVSZipCode;
                      break;
                   case 'BillingStreet':
                      form.fieldRefs[itm].value = dbVal.AVSStreetNum;
                      break;
                   case 'stnumname':
                      form.fieldRefs[itm].value = dbVal.StNum + ' ' +  dbVal.St;
                      break;
                   //case 'payAmt':
                      //form.fieldRefs[itm].value = dbVal.payAmt
                   default:
                      break;
                }
             }
           }
           catch(ex){
              ro.ui.alert('Error: Method setFields \n' + ex);
              if(Ti.App.DEBUGBOOL)  { Ti.API.debug('form.setValues()-Exception: \n' + ex); }
           }
        };
        
        var setPickerValue = function(val, allPickerVal){
           var row;
           //Ti.API.debug('val: ' + val);
           for(row=0; row<allPickerVal.length; row++){
              //Ti.API.debug('allPickerVal['+row+']: ' + JSON.stringify(allPickerVal[row]));
              if(val === allPickerVal[row]){
                 return row;
              }
           }
           return 0;
        };
        
        var ctr = 1;
        var addField = function(field, fieldRefs, fieldNum){
            var title = field.title || ('field' + ctr++);
            var id = field.id || title;
            var type = field.type || TYPE_TEXT;
            var form = this;
            var fieldObject = undefined;
        
            if(type === TYPE_TEXT ||
                type === TYPE_EMAIL ||
                type === TYPE_NUMBER ||
                type === TYPE_PHONE ||
                type === TYPE_PASSWORD){
                   fieldObject = Ti.UI.createTextField(textFieldDefaults);
                   if(field.returnKeyType && field.returnKeyType === 9) fieldObject.returnKeyType = field.returnKeyType;
                   fieldObject.hintText = title;
                   fieldObject.keyboardType = keyboardMap[type];
                   /*if(type == TYPE_NUMBER || type == TYPE_PHONE){
                      fieldObject.keyboardToolbar = getToolbar();
                   }*/
                   fieldObject.passwordMask = type === TYPE_PASSWORD;
                   if(!isNaN(field.charLimit)){
                    fieldObject.maxLength = field.charLimit;
                   }
                   if(field.defaultValue && field.defaultValue.length){
                      fieldObject.value = field.defaultValue;
                   }
                   if(field.cantEdit){
                      fieldObject.editable = false;
                   }
                   if(type === TYPE_PHONE){
                      phoneField = fieldObject;
                      fieldObject.addEventListener('change', phoneDash);
                   }
                   if(id && id.length && id === 'ccNum'){
                      
                      fieldObject.maxLength = 19;
                      fieldObject.addEventListener('change', ccChangeEvt);
                      creditField = fieldObject;
                      /*fieldObject.addEventListener('change', function(e){
                       Ti.API.debug('CreditCard field is changing: ' + JSON.stringify(e));
                    });*/
                   }
                   handleStyle(form, fieldObject, title);
                   //Ti.API.debug('fieldObject: ' + JSON.stringify(fieldObject));
                   fieldObject.fieldNum = fieldNum;
                   fieldObject.addEventListener('return', function(e){
                    try{
                          if((e.source.fieldNum+1) >= ((e.source.parent.TOTAL_FIELDS * 2)-1)){
                            //Ti.API.debug('returning because end of form.');
                            return;
                          }
                          
                          
                          if(form.container.children[e.source.fieldNum+2].apiName == "Ti.UI.Picker"){
                             form.container.children[e.source.fieldNum+2].setSelectedRow(0,0);
                             form.container.children[e.source.fieldNum+4].blur();
                          }
                          else{
                             //form.container.children[e.source.fieldNum+2].focus();
                             form.container.children[e.source.fieldNum+2].focus();
                          }
                    }
                    catch(ex){
                        //Ti.API.debug('couldnt focus next field');
                    }
                      ////deb.ug(e, 'e');
                   });
            }
            else if(type === TYPE_DATE){
                if (isAndroid) {
                    fieldObject = Ti.UI.createPicker({
                       height:ro.ui.relY(40),
                        type: Ti.UI.PICKER_TYPE_DATE,
                        bottom:ro.ui.relY(15)
                    });
                    handleStyle(form, undefined, title);
                } else {
                    fieldObject = Ti.UI.createTextField(textFieldDefaults);
                    if(field.returnKeyType && field.returnKeyType === 9) fieldObject.returnKeyType = field.returnKeyType;
                    fieldObject.hintText = title;
                    handleStyle(form, fieldObject, title);
                    setupPickerTextField(fieldObject, Ti.UI.PICKER_TYPE_DATE);
                }
            }
            else if (type === TYPE_PICKER || type == "expirationCol") {
                if (true) {
                    if(true || Ti.Platform.osname != 'android'){
                        var loopMax, outerData = [];
                        if(type == "expirationCol"){
                            loopMax = field.data.length;
                            //fieldData = 
                            outerData = field.data;
                        }
                        else{
                            loopMax = 1;
                            outerData.push(field);
                        }
                        
                        //var loopMax = (type == "expirationCol" ? field.data.length : 1);
                        
                        //var specialFieldObject = 
                        
                        if(field.id !== 'expPicker'){
                            
                            
                            for (var j = 0, jMax = loopMax; j < jMax; j++) {

                                var pickRows = [];
                                for (var i = 0; i < outerData[j].data.length; i++) {
                                    var pckRow = ro.isiOS ? {
                                        title: outerData[j].data[i],
                                        CountryCode: field.countryData && field.countryData.length && field.countryData[i] && field.countryData[i].length ? field.countryData[i] : "US"
                                    } : Ti.UI.createPickerRow({
                                        title: outerData[j].data[i],
                                        CountryCode: field.countryData && field.countryData.length && field.countryData[i] && field.countryData[i].length ? field.countryData[i] : "US"
                                    });
                                    pickRows.push(pckRow);
                                    //Ti.UI.createPickerRow({title:outerData[j].data[i], CountryCode:field.countryData && field.countryData.length && field.countryData[i] && field.countryData[i].length ? field.countryData[i] : "US"}));
                                }
                                var picker = Ti.UI.createPicker({
                                    type: Ti.UI.PICKER_TYPE_PLAIN,
                                    //useSpinner: true,
                                    top: ro.isiOS ? 13 : 0
                                });
                                if (!ro.isiOS) {
                                    picker.width = Ti.UI.FILL;
                                    picker.height = Ti.UI.FILL;
                                    /*for(var i=0, iMax=pickRows.length; i<iMax; i++){
                                     picker.add(pickRows[i]);
                                     }*/
                                }

                                picker.add(pickRows);

                                fieldObject = Ti.UI.createView(ro.combine(ro.ui.properties.allTxtField, {
                                    height: field.id == 'title' ? 0 : ro.ui.relY(40),
                                    //width:ro.ui.relX(325),
                                    top: ro.ui.relY(0),
                                    bottom: field.id == 'title' ? 0 : ro.ui.relY(25),
                                    text: outerData[j].data[0],
                                    picker: picker,
                                    specialType: 'iospicker'

                                }));
                                var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.pickerTxtFieldLbl, {
                                    text: outerData[j].data[0],
                                    left: ro.ui.relX(10),
                                    touchEnabled: false
                                }));
                                var arrowImg = Ti.UI.createImageView({
                                    image: '/images/downArrow.png',
                                    height: ro.ui.relY(40),
                                    width: ro.ui.relY(40),
                                    right: ro.ui.relX(5),
                                    touchEnabled: false
                                });
                                fieldObject.add(lbl);
                                fieldObject.add(arrowImg);
                                function setLblText(newTxt, cc) {
                                    //Ti.API.debug('oldText: ' + lbl.text);
                                    //Ti.API.debug('setLblText: ' + newTxt);
                                    fieldObject.countryCode = cc && cc.length ? cc : null;

                                    fieldObject.text = newTxt;
                                    lbl.text = newTxt;
                                }


                                fieldObject.setLblText = setLblText;

                                picker.addEventListener('change', function(e) {
                                    //Ti.API.debug('changing: ' + JSON.stringify(e));
                                    var pck = picker.getSelectedRow(0);
                                    var selectedType = pck.title;
                                    fieldObject.text = selectedType;
                                    //Ti.API.debug('pck: ' + JSON.stringify(pck));
                                    if (pck.CountryCode && pck.CountryCode.length) {
                                        fieldObject.setLblText(selectedType, pck.CountryCode);
                                    }
                                    else {
                                        fieldObject.setLblText(selectedType);
                                    }

                                    if (field.id == 'addrtype') {
                                        switch(selectedType) {
                                            case "House":
                                                form.fieldRefs['unitnum'].value = 'N/A';
                                                form.fieldRefs['unitnum'].editable = false;
                                                form.fieldRefs['unitname'].value = 'N/A';
                                                form.fieldRefs['unitname'].editable = false;
                                                break;
                                            default:
                                                if (form.fieldRefs['unitnum']) {
                                                    form.fieldRefs['unitnum'].value = '';
                                                    form.fieldRefs['unitnum'].editable = true;
                                                }
                                                if (form.fieldRefs['unitname']) {
                                                    form.fieldRefs['unitname'].value = '';
                                                    form.fieldRefs['unitname'].editable = true;
                                                }
                                                break;
                                        }
                                    }

                                });
                                fieldObject.addEventListener('click', function(e) {
                                    ro.GlobalPicker.setPicker(fieldObject.picker);
                                    if (!ro.isiOS) {
                                        var customHeight = ro.ui.relY(150);
                                        ro.GlobalPicker.showPicker(customHeight);
                                    }
                                    else {
                                        ro.GlobalPicker.showPicker();
                                    }
                                });
                                handleStyle(form, undefined, title);
                                if(fieldObject){
                                    form.container.add(fieldObject);
                                    fieldRefs[outerData[j].id] = fieldObject;
                                }
                            }
                            return;
                            
                            
                            //fieldObject.setSelectedRow(0,0);
                        }
                    }
                    else{
                        fieldObject = Ti.UI.createPicker({
                            type:Ti.UI.PICKER_TYPE_PLAIN,
                            height:ro.ui.relY(40),
                            //width:ro.ui.relX(325),
                            width:ro.ui.properties.wideViewWidth,
                            backgroundColor:ro.ui.theme.pickerColor,
                            bottom:ro.ui.relY(25),
                            focusable:true,
                            selectionOpens:true
                        });
                        if(field.id == 'addrtype'){
                            fieldObject.addEventListener('change', function(e){
                                var selectedType = fieldObject.getSelectedRow(0).title;
                                   switch(selectedType){
                                       case "House":
                                        form.fieldRefs['unitnum'].value = 'N/A';
                                        form.fieldRefs['unitnum'].editable = false;
                                    form.fieldRefs['unitname'].value = 'N/A';
                                    form.fieldRefs['unitname'].editable = false;
                                        break;
                                      default:
                                      form.fieldRefs['unitnum'].value = '';
                                      form.fieldRefs['unitnum'].editable = true;
                                      form.fieldRefs['unitname'].value = '';
                                       form.fieldRefs['unitname'].editable = true;
                                      break;
                                  }
                            });
                        }
                        handleStyle(form, undefined, title);
                        if(field.id !== 'expPicker'){
                            for (var i=0; i< field.data.length; i++) {
                                fieldObject.add(Ti.UI.createPickerRow({title:field.data[i], CountryCode:field.countryData && field.countryData.length && field.countryData[i] && field.countryData[i].length ? field.countryData[i] : "US"}));
                            }
                            fieldObject.setSelectedRow(0,0);
                        }
                    }
                    
                 }
                 else {
                    fieldObject = Ti.UI.createTextField(textFieldDefaults);
                    if(field.returnKeyType && field.returnKeyType === 9) fieldObject.returnKeyType = field.returnKeyType;
                    fieldObject.hintText = title;
                    handleStyle(form, fieldObject, title);
                    setupPickerTextField(fieldObject, Ti.UI.PICKER_TYPE_PLAIN, field.data);
                 }
             }
             else if (type === TYPE_SUBMIT) {
                var button = Ti.UI.createButton({
                    title: title,
                    height:ro.ui.relY(40),
                    width:ro.ui.relX(100),
                    top:ro.ui.relY(10)
                });
                button.addEventListener('click', function(e){
                    var values = {};
                    for (var i=0; i<fieldRefs.length; i++){
                        if(isAndroid && fieldRefs[i].type === Ti.UI.PICKER_TYPE_PLAIN){
                            values[i] = fieldRefs[i].getSelectedRow(0).title;
                        }
                        else{
                            values[i] = fieldRefs[i].value;
                        }
                    }
                    form.fireEvent(id, {values:values});
                });
                form.container.add(button);
            }
            else if (type === TYPE_CHECKBOX) {
                //Ti.API.debug('CREATING SWITCH NOW');
               /*fieldObject = Ti.UI.createSwitch(ro.combine(ro.ui.properties.defaultSwitch, {
                  title:title?title.toUpperCase():'',
                  //bottom:ro.ui.relY(15),
                  top:ro.ui.relY(10)
               }));
              fieldObject.addEventListener('click', function(e){
                ////Ti.API.debug('e: ' + JSON.stringify(e));
                //Ti.API.debug('switch is switching to ' + e.value);
              });*/
               fieldObject = Ti.UI.createView({
                  height:ro.ui.relY(50),
                  //width:ro.ui.relX(325),
                  width:ro.ui.properties.wideViewWidth,
                  top:ro.ui.relY(10),
                  bottom:ro.ui.relY(25),
                  layout:'horizontal',
                  theValue:false,
                  value:false
               });
               var lbl, checkbox, leftVw, rightVw;
               
                leftVw = Ti.UI.createView({
                    //borderColor:'blue',
                    //borderWidth:1,
                    top:0,
                    left:0,
                    width:ro.ui.relX(40),
                    height:ro.ui.relY(120),
                    //height:Ti.UI.FILL
                });
                
                rightVw = Ti.UI.createView({
                    //borderColor:'green',
                    //borderWidth:1,
                    top:0,
                    left:0,
                    width:ro.ui.relX(274)//,
                    //height:Ti.UI.FILL
                });
                
                checkbox = Ti.UI.createView({
                     top:ro.ui.relX(5),
                     width:ro.ui.relX(20),
                     height:ro.ui.relY(20),
                     borderRadius:ro.ui.relX(10),
                     borderColor:'#f2f2f2',
                     borderWidth:ro.ui.relX(2),
                     theValue:false,
                     backgroundImage:'/images/switch_offFAKE.png'
                  }),
                  lbl = Ti.UI.createLabel({
                    text:title,
                    font:{
                        fontSize:ro.ui.scaleFont(16),
                        //fontWeight:'bold',
                        fontFamily:ro.ui.fonts.policyText
                    },
                     height:Ti.UI.SIZE,
                     width:Ti.UI.FILL,
                     color:ro.ui.theme.privacyPolicyTxtLbl,
                     left:ro.ui.relX(10),
                     top:ro.ui.relX(5)
                  });
                
                leftVw.add(checkbox);
                rightVw.add(lbl);
                fieldObject.addEventListener('click', function(e){
                    
                    fieldObject.theValue = !fieldObject.theValue;
                    fieldObject.value = fieldObject.theValue;
                    checkbox.backgroundImage = fieldObject.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
                    //Ti.API.debug('fieldObject.theValue: ' + fieldObject.theValue);
                });
                fieldObject.add(leftVw);
                fieldObject.add(rightVw);
                fieldObject.toggle = function(newValue){
                    fieldObject.theValue = newValue;
                    fieldObject.value = newValue;
                    checkbox.backgroundImage = fieldObject.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
                };
                
              /*lbl.addEventListener('click', function(e){
                 checkbox.theValue = !checkbox.theValue;
                 checkbox.backgroundImage = checkbox.theValue ? "/images/switch_on.png" : "/images/switch_off.png";
              });
              checkbox.addEventListener('click', function(){
                checkbox.theValue = !checkbox.theValue;
                checkbox.backgroundImage = checkbox.theValue ? "/images/switch_on.png" : "/images/switch_off.png";
              });*/
               
            }
            else if (type === TYPE_EXPIRY){
              var curDate = new Date();
              var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
              fieldObject = Ti.UI.createLabel(ro.ui.properties.ccDateStyle);
              var defaultDate = monthNames[curDate.getMonth()] + ', ' + curDate.getFullYear();
              handleStyle(form, fieldObject, title);
              fieldObject.text = defaultDate;
           }
           else if (type === TYPE_INSTRUCTIONS){
              //fieldObject = Ti.UI.createTextField(lgTextFieldDefaults);
              fieldObject = Ti.UI.createTextArea(lgTextFieldDefaults);
              fieldObject.keyboardType = keyboardMap[TYPE_TEXT];
              handleStyle(form, fieldObject, title);
           }
           else if(type === TYPE_LABEL){
              fieldObject = Ti.UI.createLabel(ro.combine(ro.ui.properties.guestOrLbl, {
                 text:title
              }));
              //handleStyle(form, fieldObject, title);
           }
           else if(type === TYPE_CARDIMAGES){
              fieldObject = Ti.UI.createView({
                 left:0,
                 height:ro.ui.relY(40),
                 width:ro.ui.relX(250),
                 top:ro.ui.relY(10),
                 bottom:ro.ui.relY(25),//15
                 borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
                 layout:'horizontal',
                 toggle:function(type){
                    //Ti.API.debug('type: ' + type);
                    //Ti.API.debug('this.children.length: ' + this.children.length);
                    //for(var i=0, iMax=)
                    if(type == 'invalid'){
                        for(var i=0, iMax=this.children.length; i<iMax; i++){
                            this.children[i].image = '/images/' + this.children[i].id + '@2x.png';
                        }
                    }
                    else{
                        for(var i=0, iMax=this.children.length; i<iMax; i++){
                            if(this.children[i].id == type){
                                this.children[i].image = '/images/' + type + 'Chosen.png';
                            }
                            else{
                                this.children[i].image = '/images/' + this.children[i].id + '@2x.png';
                            }
                        }
                    }
                 }
              });
              //fieldObject
              for(var i=0, iMax=field.data.length; i<iMax; i++) {
                
                 fieldObject.add(Ti.UI.createImageView({
                    image:'/images/' + field.data[i].toLowerCase() + '@2x.png',
                    width:'22%',
                    borderRadius:ro.ui.relX(5),
                    left:!i ? 0 : ((8/(field.data.length-1))+'%'),
                    id:field.data[i].toLowerCase()
                 }));
              }
              //Ti.API.debug('field.data: ' + JSON.stringify(field.data));
              handleStyle(form, fieldObject, title);
           }
        
            // Add our prepared UI component to the form
            if(fieldObject){
                form.container.add(fieldObject);
                fieldRefs[id] = fieldObject;
            }
        };
        
        var addFields = function(fields, fieldRefs){
            for(var i=0, iMax=fields.length; i<iMax; i++){
                //Ti.API.debug('fields['+i+']: ' + JSON.stringify(fields[i]));
                this.addField(fields[i], fieldRefs, ((2*i)+1));
            }
        };
        
        var getValues = function(frm){
            var values = {};
            var countryCode = null;
            for(var i in frm.fieldRefs){
               //Ti.API.debug('frm.fieldRefs['+i+']: ' + JSON.stringify(frm.fieldRefs[i]));
                if(frm.fieldRefs[i].type === Ti.UI.PICKER_TYPE_PLAIN){
                    
                    //Ti.API.debug('frm.fieldRefs[i].getSelectedRow(0): ' + JSON.stringify(frm.fieldRefs[i].getSelectedRow(0)));
                    var row = frm.fieldRefs[i].getSelectedRow(0);
                    //Ti.API.debug('row: ' + JSON.stringify(row));
                    values[i] = row.title;
                    if(row.CountryCode && row.CountryCode.length){
                        countryCode = row.CountryCode;
                    } 
                }
                else if(frm.fieldRefs[i].specialType == 'iospicker'){
                    values[i] = frm.fieldRefs[i].text;
                    
                    //var row = frm.fieldRefs[i].getSelectedRow(0);
                    Ti.API.debug('frm.fieldRefs[i]: ' + JSON.stringify(frm.fieldRefs[i]));
                    if(frm.fieldRefs[i].countryCode && frm.fieldRefs[i].countryCode.length){
                        countryCode = frm.fieldRefs[i].countryCode;
                    }
                }
                else{
                   if(i == 'ccNum' || i == 'phone'){
                      values[i] = frm.fieldRefs[i].value.replace(/-/g,'');
                   }
                   else{
                       values[i] = frm.fieldRefs[i].value;
                    }
                }
            }
            if(countryCode){
                values.CountryCode = countryCode;
                
            }
            //Ti.API.debug('values: ' + JSON.stringify(values));
            return values;
        };
        //ro.forms = {};
        //var forms = {};
        var createForm = function(o){
            if(o.forgotPass === true){
                thisForm.forgotPass = true;
            }
            else{
                thisForm.forgotPass = false;
            }
            var top = ro.ui.platHeight * (50 / 480);
            top = top > (2 * 50)?(2 * 50):top;
            var container = Ti.UI.createView({
                layout:'vertical',
                height:Ti.UI.SIZE,
                top:ro.ui.relY(10),
                //borderColor:'blue',
                //borderWidth:5
            });
            var fieldRefs = {};
            var form = Ti.UI.createScrollView(ro.combine(o.settings, {
                //borderColor:'green',
                //borderWidth:5,
                bottom:ro.isiOS ? 5 : ro.ui.relY(59),
                //bottom:0,
                contentHeight:Ti.UI.SIZE,
                //contentWidth:Ti.UI.SIZE,
                showVerticalScrollIndicator:true,
                //showHorizontalScrollIndicator:true,
                // new stuff
                container:container,
                fieldStyle:o.style || STYLE_HINT,
                addField:addField,
                addFields:addFields,
                clearFields:clearFields,
                setFields:setFields,
                setPickerValue:setPickerValue/*,
                disableBounce:ro.isiOS ? true : false*/
            }));
            form.addFields(o.fields, fieldRefs);
            form.TOTAL_FIELDS = o.fields.length;
            container.TOTAL_FIELDS = o.fields.length;
            form.add(container);
        
            // Add this so each field can be accessed directly, if necessary
            form.fieldRefs = fieldRefs;
            form.focusField = focusField;
            return form;
        };
        var formsObj = {
            getValues: getValues,
            //setFields: setFields,
            createForm: createForm,
            STYLE_HINT: STYLE_HINT,
            STYLE_LABEL: STYLE_LABEL
        };
        ro.forms = formsObj;
        //forms.getValues = getValues;
        //forms.setFields = setFields;
    };
    return {
        forms:forms
    };
}();
module.exports = FORMS;