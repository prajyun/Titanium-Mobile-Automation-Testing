exports.getMainView = function(hid, title, btn2, btn1, vertLayout, customBtn){
	var mainView = {};
	try{
		////Ti.API.debug('ro.ui.properties.stretch: ' + JSON.stringify(ro.ui.properties.stretch));
		mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
			name:hid,
			hid:hid,
			width:ro.ui.displayCaps.platformWidth,
			bottom:ro.ui.relX(59)
		}));
		if(vertLayout){
			mainView.layout = 'vertical';
		}
		var navBar = Ti.UI.createView(ro.ui.properties.navBar);
		//var navBarParent;
		
		

		/* if(ro.ui.theme.bannerImg){
			var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
			navBar.add(headerImg);
		}
		else{
			var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{text:title}));
			navBar.add(headerLbl);
		} */
		
		if(btn1){
			btn1.addEventListener('click', function(e){
				ro.ui.ordShowNext({showing:mainView.hid});
			});
			navBar.add(btn1);
		}
		if(btn2 && btn2.notlogout){
			if(btn2.needsEvent){

			}
			navBar.add(btn2);
		}
		else if(btn2){
			navBar.add(btn2);
			//if(!ro.REV_GUEST_ORDER.getIsGuestOrder())
				btn2.hide();
		}
		if(customBtn){
		   navBar.add(customBtn);
		}
		if(ro.isiphonex){
			var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
			var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
			var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
			navParent.add(topNav);
			bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			navParent.add(bottomNav);
			mainView.add(navParent);
		}
		else{
			mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
		}
		
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getMainView()-Exception: ' + ex); }
	}
	return mainView;
};
exports.getLogoutBtn = function(){
   //GUEST ORDER
   var btnTxt = 'SIGN OUT', isGuest = false;
   if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
      btnTxt = 'START OVER';
      isGuest = true;
   }
   var txtSize = 13;
   if(btnTxt.length >= 10){
      txtSize -=1;
   }
   //GUEST ORDER
   
	var logoutBtn = {};
	try{
		logoutBtn = Ti.UI.createView(ro.combine(ro.ui.properties.logoutBtn, {
		   width:ro.isiOS ? ro.ui.relX(78) : ro.ui.relX(58)//68
		}));
		logoutBtn.add(Ti.UI.createLabel({
			color:ro.ui.theme.navBtns,
			right:0,
			font:{
				fontFamily:ro.ui.fontFamily,
				fontWeight:'bold',
				fontSize:ro.ui.scaleFont(txtSize)
			},
			text:btnTxt,
			textAlign:'center'
		}));
		logoutBtn.addEventListener('click', function(e){
			if(isGuest){
				ro.REV_GUEST_ORDER.setIsGuestOrder(false);
			}
		   ro.ui.ordShowNext({ showing:'ordTypeView' });
		});
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getLogoutBtn()-Exception: ' + ex); }
	}
	return logoutBtn;
};
exports.getRightBtn = function(ttl, customProps){
	var btn = {};
	try{
	   var txtSize = 13;
      if(ttl && ttl.length >= 10){
         txtSize -=1;
      }
		if(customProps){
			btn = Ti.UI.createView(ro.combine(ro.ui.properties.logoutBtn, {
			   width:ro.isiOS ? ro.ui.relX(78) : ro.ui.relX(58),//68
				height:Ti.UI.FILL,
				top:ro.ui.relY(2),
				bottom:ro.ui.relY(2),
				borderColor:'black',
				borderWidth:1
			}));
		}
		else{
			btn = Ti.UI.createView(ro.ui.properties.logoutBtn);
		}
		btn.add(Ti.UI.createLabel({
			//color:ro.ui.theme.btnTxtActive,
			color:ro.ui.theme.navBtns,
			font:{
				fontFamily:ro.ui.fontFamily,
				fontWeight:'bold',
				fontSize:ro.ui.scaleFont(txtSize)
			},
			text:ttl,
         textAlign:'center'
		}));
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getLogoutBtn()-Exception: ' + ex); }
	}
	return btn;
};
exports.getCustomBtn = function(title, event){
	var backBtn = {};
	try{
	   var txtSize = 13;
      if(title && title.length >= 10){
         txtSize -=1;
      }
		backBtn = Ti.UI.createView(ro.combine(ro.ui.properties.backBtn, {
		   width:ro.isiOS ? ro.ui.relX(78) : ro.ui.relX(58)
		}));
		backBtn.add(Ti.UI.createLabel({
			//color:ro.ui.theme.btnTxtActive,
			color:ro.ui.theme.navBtns,
			left:0,
			font:{
				fontFamily:ro.ui.fontFamily,
				fontWeight:'bold',
				fontSize:ro.ui.scaleFont(txtSize)
			},
			text:title?title:'BACK',
         textAlign:'center'
		}));
		if(event){
			backBtn.addEventListener('click', event);
		}
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getBackBtn()-Exception: ' + ex); }
	}
	return backBtn;
};
exports.getBackBtn = function(title, event, showCustomText){
	var backBtn = {};
	try{
		var imgHolder, lblHolder;
		
		backBtn = Ti.UI.createView({
		   layout:'vertical',
		   left:ro.ui.relX(10),
		   height:ro.ui.relY(70),
		   width:ro.ui.relX(60),
		  // bottom:ro.ui.relY(5)//,
		   //borderColor:'blue',
		   //borderWidth:1
		});
		imgHolder = Ti.UI.createView({
			top:0,
			width:Ti.UI.FILL,
			height:ro.ui.relX(55)//,
			//borderColor:'red',
			//borderWidth:1
		});
		imgHolder.add(Ti.UI.createImageView({
			bottom:0,
			image:'/images/back.png'
		}));
		
		lblHolder = Ti.UI.createView({
			top:ro.isiOS ? ro.ui.relXX(-5) : ro.ui.relXX(-20),
			//borderColor:'brown',
			//borderWidth:1,
			height:Ti.UI.FILL,
			width:Ti.UI.FILL
		});
		lblHolder.add(Ti.UI.createLabel({
			text:showCustomText ? title : "Back",
			font:{
				fontFamily:ro.ui.fonts.navBtns,
				//fontWeight:'bold',
				fontSize:ro.ui.scaleFont(15)
			},
			textAlign:'center',
			color:ro.ui.theme.navBtns
		}));
		
		backBtn.add(imgHolder);
		backBtn.add(lblHolder);
		
		/*backBtn.add(Ti.UI.createLabel({
			color:ro.ui.theme.navBtns,
			left:0,
			font:{
				fontFamily:ro.ui.fontFamily,
				fontWeight:'bold',
				fontSize:ro.ui.scaleFont(txtSize)
			},
			text:title?title:'BACK',
         textAlign:'center'
		}));*/
		if(event){
			backBtn.addEventListener('click', event);
		}
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getBackBtn()-Exception: ' + ex); }
	}
	return backBtn;
};
exports.getNewRightBtn = function(title, event, img, smallerHeight){
	var backBtn = {};
	try{
		var imgHolder, lblHolder;
		var imageHolderHeight = smallerHeight ? smallerHeight : 55;
		var btnHeight = smallerHeight ? (70 - (55-smallerHeight)) : 70;
		var lblTop = smallerHeight ? 0 : -7;
		if(!ro.isiOS){
			lblTop = smallerHeight ? -10 : -20;
		}
		backBtn = Ti.UI.createView({
		   layout:'vertical',
		   right:ro.ui.relX(10),
		   height:ro.ui.relY(btnHeight),
		   width:ro.ui.relX(60),
		   //bottom:ro.ui.relY(17)
		   //borderColor:'blue',
		   //borderWidth:1
		});
		imgHolder = Ti.UI.createView({
			top:0,
			width:Ti.UI.FILL,
			height:ro.ui.relX(imageHolderHeight),
			touchEnabled:false
			//borderColor:'red',
			//borderWidth:1
		});
		imgHolder.add(Ti.UI.createImageView({
			bottom:0,
			image:img,
			touchEnabled:false
		}));
		
		lblHolder = Ti.UI.createView({
			top:ro.ui.relXX(lblTop),//-20),
			//borderColor:'brown',
			//borderWidth:1,
			height:Ti.UI.FILL,
			width:Ti.UI.FILL,
			touchEnabled:false
		});
		lblHolder.add(Ti.UI.createLabel({
			text:title&&title.length ? title : "",
			font:{
				fontFamily:ro.ui.fonts.navBtns,
				//fontWeight:'bold',
				fontSize:ro.ui.scaleFont(15)
			},
			textAlign:'center',
			color:ro.ui.theme.navBtns,
			touchEnabled:false
		}));
		
		backBtn.add(imgHolder);
		backBtn.add(lblHolder);
		
		/*backBtn.add(Ti.UI.createLabel({
			color:ro.ui.theme.navBtns,
			left:0,
			font:{
				fontFamily:ro.ui.fontFamily,
				fontWeight:'bold',
				fontSize:ro.ui.scaleFont(txtSize)
			},
			text:title?title:'BACK',
         textAlign:'center'
		}));*/
		if(event){
			backBtn.addEventListener('click', event);
		}
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('getBackBtn()-Exception: ' + ex); }
	}
	return backBtn;
};
exports.getBigButton = function(ttl, fillWidth, notRound){
   var borderRadius = null;
   if(Ti.App.RoundedButtons && !notRound){
   	  //borderRadius = ro.ui.relX(125);
   	  borderRadius = ro.ui.relY(32);
   }
   var thisBtn = Ti.UI.createView({
      height:ro.ui.relY(64),
      width:fillWidth ? Ti.UI.FILL : ro.ui.relX(250),
      bottom:ro.ui.relY(55),
      backgroundColor:ro.ui.theme.bigBtnBackground,
      borderColor:ro.ui.theme.bigBtnBorder,
	  borderRadius:borderRadius,
      borderWidth:ro.ui.relX(1)
   });
   if(fillWidth){
   	  thisBtn.left = notRound ? 0 : ro.ui.relX(10);
   	  thisBtn.right = notRound ? 0 : ro.ui.relX(10);
   }
   //if(notRound)
   thisBtn.add(Ti.UI.createLabel({
      text:ttl,
      font:{
         //fontWeight:'bold',
         fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
         fontFamily:ro.ui.fonts.button
      },
      color:ro.ui.theme.bigBtnTxt,
      textAlign:'center'
   }));
   exports.animateBtn(thisBtn, ro.ui.theme.bigBtnBackground, ro.ui.theme.btnDefault, 0, ro.ui.theme.bigBtnTxt, ro.ui.theme.btnTxtDefault, ro.ui.theme.bigBtnBorder, ro.ui.theme.btnBorderDefault);
   return thisBtn;
};
exports.animateBtn = function(btn, clr, newClr, _idx, clr2, newClr2, borderClr, borderClrActive, img, imgOn){
	try{
		btn.addEventListener('touchstart', function(e){
			btn.backgroundColor = newClr;
			btn.children[_idx].color = newClr2;
			btn.borderColor = borderClrActive;
			if(img){
				btn.children[0].image = '/images/' + imgOn;
			}
		});
		btn.addEventListener('touchend', function(e){
			btn.backgroundColor = clr;
			btn.children[_idx].color = clr2;
			btn.borderColor = borderClr;
			if(img){
				btn.children[0].image = '/images/' + img;
			}
		});
		btn.addEventListener('touchcancel', function(e){
			btn.backgroundColor = clr;
			btn.children[_idx].color = clr2;
			btn.borderColor = borderClr;
			if(img){
				btn.children[0].image = '/images/' + img;
			}
		});
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('animateBtn()-Exception: ' + ex); }
	}
};
exports.colorizeBtn = function(btn, btn2){
   try{
      var label = btn.children[1];
      var imgView = btn.children[0].children[0];
      btn.backgroundColor = btn.bgSelected;
      label.color = label.selColor;
      btn.borderColor = btn.borderSel;
      imgView.image = imgView.imgSel;

      var label2 = btn2.children[1];
      var imgView2 = btn2.children[0].children[0];
      btn2.backgroundColor = btn2.bgNotSel;
      label2.color = label2.notSelcolor;
      btn2.borderColor = btn2.borderNotSel;
      imgView2.image = imgView2.imgNotSel;

   }
   catch(ex){
      if(Ti.App.DEBUGBOOL) { Ti.API.debug('animateBtn()-Exception: ' + ex); }
   }
};