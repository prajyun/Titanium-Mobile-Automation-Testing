(function(){
	var demoStk = null;
	var shouldInclude = true;
	
	function includeDemoFiles(){
		Ti.include('/revmobile/ui/menuViewDemo.js');
		Ti.include('/revmobile/ui/itemDetailsViewDemo.js');
		shouldInclude = false;
	}
	
	ro.ui.currentDemoViewIdx=function(){
		return demoStk.currentIndex;
	};
	ro.ui.demoStkViewID = function(){
      return demoStk.children[0].hid;
   };
   ro.ui.demoStkExplode = function(){
      demoStk.removeAllChildren();
   };
	
	ro.ui.createDemoStk = function(_args){
		demoStk = ro.ui.createStackView({
			views:[],
			props:{
				top:0,
				left:0,
				right:0,
				bottom:0,
			}
		});
		
		ro.ui.demoShowNext = function(e){
		   try{
		   	
		   	if(shouldInclude){
		   		includeDemoFiles();
		   	}
		   	
		      ro.ui.showLoader();
   			var curIndex = demoStk.currentIndex;
            var curView = demoStk.children[curIndex];
            var nextView = null;
            var interval = 400;
            var childrenLength = demoStk.children.length;
            demoStk.removeAllChildren();

   			if(e.addView){
   				switch(e.showing){
   				   case 'menuView':
   				      //Ti.include('/revmobile/ui/menuViewDemo.js');
   				      nextView = ro.ui.createMenuViewDemo();
   				      break;
   					case 'itemDetails':
   					   //Ti.include('/revmobile/ui/itemDetailsViewDemo.js');
   						nextView = ro.ui.createItemDetailsViewDemo();
   						//ro.ui.hideLoader();					
   						break;
   				}
   			}
   			else{
   			   switch(e.showing){
   			      case 'menuView':
   			         ro.ui.exitApp();
   			         break;
   			      case 'itemDetails':
   			         //Ti.include('/revmobile/ui/menuViewDemo.js');
   			         nextView = ro.ui.createMenuViewDemo();
   			         break;  
   			   }
   			}
   			
   			if(nextView && nextView!=null){
               demoStk.add(nextView);
               demoStk.children[0].visible = true;
               ro.ui.hideLoader();
            }
            //ro.ui.hideLoader();
		   }
		   catch(ex){
			   ro.ui.alert('Navigation Error','Code:N100');
		   }
		};
		
		ro.ui.demoRemoveView = function(e){
			demoStk.remove(e.view);
			demoStk.currentIndex--;
		};
		
		ro.ui.demoReset = function(e){
			try{
            demoStk.removeAllChildren();
         }              
         catch(ex){
            ro.ui.alert('Navigation Error','Code:N102'+ ex);
         }  
		};
		return demoStk;
	};
}());