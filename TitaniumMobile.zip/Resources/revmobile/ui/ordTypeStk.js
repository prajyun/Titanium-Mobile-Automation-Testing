var ORDTYPESTK = function(){
	//Ti.include('/classes/suds.js');
	var ordtypestk = function(ro){
		
		var ordTypeStk = null;
		var shouldInclude = true;
		var goToGrpItems = false;
		
		var VALIDATEEMAILVIEW, ORDTYPEVIEW, CHOOSEORDERTYPEVIEW, DEFAULTSTOREVIEW, FUTUREORDERVIEW, GUESTFINDSTOREVIEW, STORESELECTIONVIEW, ORDTYPEADDRVIEW, ORDTYPENEWADDRVIEW, QRCODEVIEW;
	
		var ITEMSVIEW, NEWITEMSVIEW, GROUPSVIEW, NEWGROUPSVIEW, ITEMDETAILSVIEW, COUPONSELECTIONVIEW;
		
		function includeOrdFiles(){
		   //Ti.include(Ti.App.NewHungryHowiesLayout?'/revmobile/ui/newAppLayout/ordTypeView.js':'/revmobile/ui/ordTypeView.js');
		   VALIDATEEMAILVIEW = VALIDATEEMAILVIEW || require("revmobile/ui/validateEmailView");
		   VALIDATEEMAILVIEW.validateemailview(ro);

		   ORDTYPEVIEW = ORDTYPEVIEW || require("revmobile/ui/newAppLayout/ordTypeView");
		   ORDTYPEVIEW.ordtypeview(ro);
		   
		   QRCODEVIEW = QRCODEVIEW || require("revmobile/ui/qrCodeView");
           QRCODEVIEW.qrcodeview(ro);
		   //Ti.include('/revmobile/ui/qrCodeView.js');
		   
		   CHOOSEORDERTYPEVIEW = CHOOSEORDERTYPEVIEW || require('revmobile/ui/chooseOrderTypeView');
		   CHOOSEORDERTYPEVIEW.chooseordertypeview(ro);
		   
		   DEFAULTSTOREVIEW = DEFAULTSTOREVIEW || require("revmobile/ui/defaultStoreView");
		   DEFAULTSTOREVIEW.defaultstoreview(ro);
		   
		   FUTUREORDERVIEW = FUTUREORDERVIEW || require("revmobile/ui/futureOrdView");
		   FUTUREORDERVIEW.futureorderview(ro);
		   
		   STORESELECTIONVIEW = STORESELECTIONVIEW || require("revmobile/ui/storeSelectionView");
		   STORESELECTIONVIEW.storeselectionview(ro);
		   
		   ORDTYPEADDRVIEW = ORDTYPEADDRVIEW || require("revmobile/ui/ordTypeAddrView");
		   ORDTYPEADDRVIEW.ordtypeaddrview(ro);
		   
		   ORDTYPENEWADDRVIEW = ORDTYPENEWADDRVIEW || require("revmobile/ui/ordTypeNewAddrView");
		   ORDTYPENEWADDRVIEW.ordtypenewaddrview(ro);
		   
		   ITEMDETAILSVIEW = ITEMDETAILSVIEW || require('revmobile/ui/menu/itemDetailsView');
		   ITEMDETAILSVIEW.itemdetailsview(ro);
		   
		   ITEMSVIEW = ITEMSVIEW || require('revmobile/ui/menu/itemsView');
		   ITEMSVIEW.itemsview(ro);
		   
		   NEWITEMSVIEW = NEWITEMSVIEW || require('revmobile/ui/menu/newItemsView');
		   NEWITEMSVIEW.newitemsview(ro);
		   
		   GROUPSVIEW = GROUPSVIEW || require("revmobile/ui/menu/grpsItemsView");
		   GROUPSVIEW.groupsview(ro);
		   
		   NEWGROUPSVIEW = NEWGROUPSVIEW || require("revmobile/ui/menu/newGrpsItemsView");
		   NEWGROUPSVIEW.newgroupsview(ro);
		   
		   COUPONSELECTIONVIEW = COUPONSELECTIONVIEW || require('revmobile/ui/menu/couponSelectionView');
		   COUPONSELECTIONVIEW.couponselectionview(ro);
		   
		   GUESTFINDSTOREVIEW = GUESTFINDSTOREVIEW || require('revmobile/ui/guestFindStoreView');
		   GUESTFINDSTOREVIEW.guestfindstoreview(ro);
		   
		   /*Ti.include('/revmobile/ui/newAppLayout/ordTypeView.js');	DONE
		   Ti.include('/revmobile/ui/defaultStoreView.js');				DONE
		   Ti.include('/revmobile/ui/ordTypeNewAddrView.js');			DONE
		   Ti.include('/revmobile/ui/ordTypeAddrView.js');				DONE
		   Ti.include('/revmobile/ui/storeSelectionView.js');			DONE
		   Ti.include('/revmobile/ui/futureOrdView.js');				DONE
		   Ti.include('/revmobile/ui/levelupView.js');
		   Ti.include('/revmobile/ui/guestFindStoreView.js');
		   Ti.include('/revmobile/ui/qrCodeView.js');
	
		   Ti.include('/revmobile/ui/menu/itemDetailsView.js');			DONE
		   Ti.include('/revmobile/ui/menu/grpsItemsView.js');			DONE
		   Ti.include('/revmobile/ui/menu/newGrpsItemsView.js');		DONE
		   Ti.include('/revmobile/ui/menu/newItemsView.js');			DONE
		   Ti.include('/revmobile/ui/menu/couponSelectionView.js');*/	//TODO
	
		   shouldInclude = false;
		};
	
		ro.ui.currentOrdTypeViewIdx = function(){
			return ordTypeStk.currentIndex;
		};
		ro.ui.currentOrdTypeStkSize = function(){
		   return ordTypeStk.children.length;
		};
		ro.ui.ordTypeStkViewID = function(){
		  if(ordTypeStk.hasOwnProperty('children') && ordTypeStk.children.length){
		  	return ordTypeStk.children[0].hid;
		  }
		  else{
		  	return '';
		  }		  	      
	   };
	    ro.ui.remOrdTypeStkChildren = function(){
	      ro.ui.setOrdTypeStkState('');
	      ordTypeStk.removeAllChildren();
	      goToGrpItems = false;
	   };
	    ro.ui.clrOrdTypeStkChildren = function(){
	      ordTypeStk.removeAllChildren();
	   };
	    ro.ui.setOrdTypeStkState = function(currState){
	      ordTypeStk.currentState = currState;
	      Ti.API.debug('ordTypeStk.currentState: ' + currState);
	   };
	    
		ro.ui.getOrdTypeStkState = function() {
			try {
				var custInfo = JSON.parse(Ti.App.Properties.getString('Customer', "{}"));
				var emailVerified = true;				
				if (!ro.REV_GUEST_ORDER.getIsGuestOrder() && custInfo.hasOwnProperty("EmailVerificationStatus")) {
					if (custInfo.EmailVerificationStatus == 'Required' || custInfo.EmailVerificationStatus == 1) {
						emailVerified = false;
					} 
                }
				if(ordTypeStk && ordTypeStk.currentState && ordTypeStk.currentState.length){
					if (ordTypeStk.currentState == 'grpsItems' || ordTypeStk.currentState == 'itemDetails' || ordTypeStk.currentState == 'newItemDetails' || ordTypeStk.currentState == 'itemsView' || ordTypeStk.currentState == 'cpnSelView' || ordTypeStk.currentState == 'cpnSelViewToCart' || ordTypeStk.currentState == 'cpnDetails' || ordTypeStk.currentState == 'cpnItems' || ordTypeStk.currentState == 'prefsView') {
						return 'grpsItems';
					} 
					else {
						return ordTypeStk.currentState && ordTypeStk.currentState.length ? ordTypeStk.currentState : 'ordTypeView';
					}
				}
				else{
					return emailVerified ? 'ordTypeView' : 'validateEmailView';
				}
			}
			catch(ex) {
				Ti.API.info('ro.ui.getOrdTypeStkState - Ex: ' + ex);
				return 'ordTypeView';
			}
		};

		ro.ui.ordStackDeepLink = function(){
			try{
				//Ti.API.info('attempting same page deep link 2');
				if(ordTypeStk){
					if(ordTypeStk.deepLink){
						ordTypeStk.deepLink();
					}
				}
			}
			catch(ex){
				Ti.API.info('ordStackDeepLink - ex: ' + ex);
			}
		};
		ro.ui.createOrdTypeStk = function(_args){
			//Ti.API.debug('ordTypeStk');
			ordTypeStk = ro.ui.createStackView({
				views:[],
				currentState:'',
				props:{
					top:0,
					left:0,
					right:0,
					bottom:0
				}
			});
			ro.ui.ordShowNext = function(e){
			   try{
				   	if(shouldInclude){
				   		//Ti.API.debug('including');
				   		includeOrdFiles();
				   	}
		
				      if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
				      ro.ui.showLoader();
		   			var curIndex = ordTypeStk.currentIndex;
		            var curView = ordTypeStk.children[curIndex];
		            var nextView = null;
		            var interval = 400;
		            var childrenLength = ordTypeStk.children.length;
		            ordTypeStk.removeAllChildren();
		
		   			if(e.addView){
						switch (e.showing) {
						   case 'validateEmailView':
							  nextView = ro.ui.createValidateEmailView();
						      break;
		   				   case 'ordTypeView':
		   				   	  //Ti.API.debug('ordTypeView: b4');
		   				      nextView = ro.ui.createOrdTypeView(e.addView);
		   				      //Ti.API.debug('ordTypeView: after');
		   				      
		   				      break;
		   				   case 'chooseOrderTypeView':
		   				       nextView = ro.ui.createChooseOrderTypeView();
		   				       break;
		   				   case 'defaultStore':
		   				      nextView = ro.ui.createDefaultStoreView();
		   				      ro.ui.refreshDefaultStore();
		   				      break;
		   				   case 'addNewAddr':
		   				      //nextView = ro.ui.addNewAddr();
		   				      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
		   				          nextView = ro.ui.addNewAddr();
		   				      }
		   				      else{
		   				          nextView = ro.ui.newAddrList();
		   				      }
		   				      
		   				      break;
		   				   case 'newAddrList':
		   				   	  if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
		   				          nextView = ro.ui.addNewAddr();
		   				      }
		   				      else{
		   				      	nextView = ro.ui.newAddrList();
		   				      }
		   				      break;
		   					case 'storeSelection':
		   					   if(!e.stores || !e.stores.length){
		   					   	  var test = e;
		   					   	  test.stores = JSON.parse(Ti.App.Properties.getString('storeList', '{}'));
		   					   	  e = test;
		   					   	  test = null;
		   					   }
		   					   else{
		   					   	  Ti.App.Properties.setString('storeList', JSON.stringify(e.stores));
		   					   }
		   					   //Ti.App.Properties.setString('storeList', JSON.stringify(e.stores));
		   					   if(e.geo === 1){
		   						   nextView = ro.ui.createStoreSelectionView({ stores:e.stores, geo:1, checkMatchingStore:(e.checkMatchingStore ? true : false) });
		   						}
		   						else{
		   						   nextView = ro.ui.createStoreSelectionView({ stores:e.stores, checkMatchingStore:(e.checkMatchingStore ? true : false) });
		   						}
		   						break;
		   					case 'grpsItems':
		   					   try{
		
		   					   	if(ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.MenuLayout){
		   					   		Ti.App.newMenu = ro.app.Store.Configuration.MenuLayout;
		   					   	}
		   					   	else{
		   					   		Ti.App.newMenu = 0;
		   					   	}
		
										////
		   					   	//Ti.App.newMenu = 2;
										////
		
		   					   	if(Ti.App.newMenu >= 1){
		   					   		nextView = ro.ui.createNewGrpsItemsView();
		   					   	}
		   					   	else{
		   						   	nextView = ro.ui.creategrpsItemsView();
		   						   }
		   					   }
		   					   catch(ex){
		   					   	if(Ti.App.DEBUGBOOL){ Ti.API.debug('ordTypeStk(grpsItems)-Exception: ' + ex); }
		   					   	alert(ex);
		   					   }
		   					   break;
		   					case 'itemDetails':
		   						nextView = ro.ui.createItemDetailsView();
		   						break;
		   					case 'newItemDetails':
		   						nextView = ro.ui.createNewItemDetailsView(e.startItem);
		   						break;
		   					case 'futOrd':
		   					   ro.utils.removeProp('futureOrder');
		
							//nextView = ro.ui.createNewFutureOrdView();
							Ti.API.debug('ro.app.Store.Hours: ' + JSON.stringify(ro.app.Store.Hours));
							if (ro.utils.skipOrderTime(ro.app.Store)) {
								if (ro.app.Store && ro.app.Store.Configuration && ro.app.Store.Configuration.MenuLayout) {
									Ti.App.newMenu = ro.app.Store.Configuration.MenuLayout;
								} else {
									Ti.App.newMenu = 0;
								}

								////
								//Ti.App.newMenu = 2;
								////

								if (Ti.App.newMenu >= 1) {
									nextView = ro.ui.createNewGrpsItemsView();
								} else {
									nextView = ro.ui.creategrpsItemsView();
								}
							}
							else{
								nextView = ro.ui.createNewFutureOrdView();
							}

		   						break;
		   					case 'itemsView': case 'cpnItems':
		   						goToGrpItems = false;
		   						nextView = ro.ui.createNewItemsView();
		   						break;
		   					case 'cpnSelView':
		   						if(e.backToGrps){
		   							goToGrpItems = true;
		   						}
		   						if(e.goBackToCart){
		
		   						}
		   						Ti.App.Properties.setString('cpnKey', JSON.stringify(e.cpnKey));
		   						nextView = ro.ui.createCpnSelectionView(e.cpnKey, e.cpnValcode, e.goBackToCart&&e.goBackToCart==true ? true : false);
		   						break;
		   					case 'prefsView':
		   						nextView = ro.ui.createNewPrefsView();
		   						break;
		   					case 'newModsView':
		   						nextView = ro.ui.createNewModsView();
		   						break;
		   					case 'newReqModsView':
		   						nextView = ro.ui.createNewReqModsView();
		   						break;
		   					case 'levelup':
		                     nextView = ro.ui.addLevelupView({isFirst:e.isFirst ? e.isFirst : false});
		                     ro.ui.hideTabview();
		                     break;
		                  case 'guestFindStore':
		                     nextView = ro.ui.getGuestFindStoreView();
		                     break;
		                  case 'qrcode':
		                  	 nextView = ro.ui.getQrView();
		                  	 break;
		   				}
		   			}
		   			else{
						switch(e.showing){
						  case 'validateEmailView':
								ro.ui.exitApp();
						  	break;
		                  case 'ordTypeView':
		                     ro.ui.exitApp({orderComplete:e.orderComplete});
		                     break;
		                  
                               //break;
		                  case 'chooseOrderTypeView':
		                     nextView = ro.ui.createOrdTypeView(e.addView);
		                     break;
		                  case 'defaultStore': case 'guestFindStore':
		                      nextView = ro.ui.createChooseOrderTypeView();
		                      break;
		                  case 'addNewAddr': case 'storeSelection':
    		                  if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
                                  nextView = ro.ui.addNewAddr();
                              }
                              else{
                                  nextView = ro.ui.newAddrList();
                              }
		                     //nextView = ro.ui.newAddrList();
		                     break;
		                  case 'newAddrList':
		                     if(!Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
		                        nextView = ro.ui.createDefaultStoreView();
		                        ro.ui.refreshDefaultStore();
		                     }
		                     else{
		                        nextView = ro.ui.createChooseOrderTypeView(true);
		                     }
		                     break;
		                  case 'grpsItems': case 'futOrd':
		                     try{
		                        if(Ti.App.OrderObj.ordOnlineOptions.IsDelivery){
		                        	var strs = JSON.parse(Ti.App.Properties.getString('storeList'));
		                        	//Ti.API.debug('strs: ' + JSON.stringify(strs));
		                        	if(!strs){
		                        		nextView = ro.ui.createChooseOrderTypeView(true);
		                        	}
		                        	else{
		                           		nextView = ro.ui.createStoreSelectionView({ stores:strs });
		                            }
		                        }
		                        else{
		                           nextView = ro.ui.createDefaultStoreView();
		                           ro.ui.refreshDefaultStore();
		                        }
		                     }
		                     catch(e){
		                        alert(e);
		                     }
		                     break;
		                  case 'itemDetails':
		                  	if(Ti.App.newMenu === 1 || Ti.App.newMenu === 2){
		                  	   ro.ui.showTabview();
		   					   	nextView = ro.ui.createNewItemsView();
		   					   }
		   					   else{
		                     	nextView = ro.ui.creategrpsItemsView();
		                     	ro.ui.showTabview();
		                     }
		                     break;
		                  case 'newItemDetails':
		                  	nextView = ro.ui.createNewItemsView();
		                  	break;
		                  case 'cpnSelView':
		                    	ro.cpnHelper.setCpnBool(false);
		
		                  	if(goToGrpItems){
		                  		goToGrpItems = false;
		                  		nextView = ro.ui.createNewGrpsItemsView();
		                  	}
		                  	else if(Ti.App.newMenu >= 1){
		   					   	nextView = ro.ui.createNewItemsView();
		   					   }
		   					   else{
		                     	nextView = ro.ui.creategrpsItemsView();
		                     	ro.ui.showTabview();
		                     }
		                  	    break;
		                    case 'itemsView':
		                        ro.ui.showTabview();
		                  	    nextView = ro.ui.createNewGrpsItemsView();
		                  	    break;
		                    case 'cpnDetails': case 'cpnItems':
                                goToGrpItems = true;
		                        ro.ui.showTabview();
		   						nextView = ro.ui.createCpnSelectionView(JSON.parse(Ti.App.Properties.getString('cpnKey')));
		   						break;
		   					case 'prefsView': case 'newModsView': case 'newReqModsView':
		   						nextView = ro.ui.createNewItemDetailsView();
		   						break;
		   					case 'levelup':
		                       nextView = ro.ui.createOrdTypeView();
		                       ro.REV_LOYALTY.getCurrentLoyalty().releaseWebview();
		                       ro.ui.showTabview();
		                       break;
		                   	case 'qrcode':
		                   	   nextView = ro.ui.createOrdTypeView();
		                   	   break;
		               }
		   			}
		   			if((!e.addView && e.showing != 'prefsView' && e.showing != 'newReqModsView' && e.showing != 'newModsView' && e.showing != 'itemDetails' && e.showing != 'newItemDetails' && e.showing != 'ordTypeView' && e.showing != 'itemsView' && e.showing != 'cpnSelView' && e.showing != 'cpnDetails' && e.showing != 'cpnItems') || (e.addView && e.showing != 'prefsView' && e.showing != 'newReqModsView' && e.showing != 'newModsView' && e.showing != 'grpsItems' && e.showing != 'itemDetails'  && e.showing != 'newItemDetails' && e.showing != 'itemsView' && e.showing != 'cpnSelView'  && e.showing != 'cpnDetails' && e.showing != 'cpnItems')){
		   			   //ro.ui.clearCart();
		   			}
		   			if(nextView && nextView!=null){
		
		   			   try{
		   			      ro.app.GA.trackPageView(nextView.hid);
		   			   }
		   			   catch(ex){
		   			      if(Ti.App.DEBUGBOOL) { Ti.API.debug('ro.app.GA.trackPageView(ordTypeStk.js)-Exception: ' + ex); }
		   			   }
		   			   
		   			   if(ro.isiOS){
		   			   	  //nextView.left = -ro.ui.displayCaps.platformWidth;
		   			   }
		   			   
		   			   
		   			   ro.ui.hideHomeSelection(true);
		   			   
		   			   if(nextView.deepLink){
		   			   	ordTypeStk.deepLink = nextView.deepLink;
		   			   }
		   			   else{
		   			   	ordTypeStk.deepLink = null;
		   			   }
		   			   
		               ordTypeStk.add(nextView);
		               
		               	if(ro.isiOS){
		               		/*var slide_in = Ti.UI.createAnimation({
								left:0,
								duration : 200,
							});
							nextView.animate(slide_in);*/
						}
		               
		               ro.ui.setOrdTypeStkState(ro.ui.ordTypeStkViewID());
		               ordTypeStk.children[0].visible = true;
		               
		
		               if(e.addView && (e.showing == 'itemDetails' || e.showing == 'qrcode')){
		               	
		               }
		               else{
		               	  ro.ui.hideLoader();
		               }
		            }
		   		}
		   		catch(ex){
		   		   Ti.API.info('ex: ' + JSON.stringify(ex));
		   		   if(ex && ex.alertPrompt){
		   		      ro.ui.alert('Invalid Coupon. ', 'The store has not configured this coupon properly.');
		   		      ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
		
		   		   }
		   		   else{
		   			   ro.ui.alert('Navigation Error', 'Code:N100');
		   			}
		   		}
		    };
	
	   		ro.ui.ordShowPrevious = function(e){
		   	   try{
		   	      var count = (e.count && e.count>0)?e.count:1;
		   	      var childrenLength = ordTypeStk.children.length;
		   			var prevView = ordTypeStk.children[childrenLength-count-1];
		
		   			for(var i=childrenLength-1; i>childrenLength - count - 1; i--){
		               ordTypeStk.remove(ordTypeStk.children[i]);
		               ordTypeStk.children[i] = null;
		               ordTypeStk.currentIndex--;
		            }
		   			prevView.visible = true;
		   		}
		   		catch(ex){
		   		   ro.ui.alert('Navigation Error', 'Code:N101');
		   		}
		   	};
	
			ro.ui.ordRemoveView = function(e){
				ordTypeStk.remove(e.view);
				ordTypeStk.currentIndex--;
			};
	
			ro.ui.ordReset = function(e){
				try{
				   ordTypeStk.removeAllChildren();
				}
			 	catch(ex){
			 		ro.ui.alert('Navigation Error','Code:N102'+ ex);
				}
			};
			return ordTypeStk;
	   };
	};
	return {
		ordtypestk:ordtypestk
	};
}();
module.exports = ORDTYPESTK;