exports.getNewReqModsView = function(group, itemSelected){
	
    try {
        Ti.API.info("This is reqMods_new");
	    var evenOddCtr = 0;
	   if(group.Mods){
		   var grpModLngth = group.Mods.length || 0;
		}
		if(itemSelected.ReqMods){
		   var selItemReqModLngth = itemSelected.ReqMods.length || 0;
		}
		var preModLngth = 0;
        if (itemSelected.HasPreMods) {            
            if (itemSelected.PreMods) {               
			   preModLngth = itemSelected.PreMods.length || 0;
			}
		}
		if(Menu.ModCategories){
		   var modCatLngth = Menu.ModCategories.length || 0;
		}
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('LoopLimiters: ' + ex); }
	}
		
		var Confg = {};
		if(Ti.App.Properties.hasProperty('Config')){
			Confg = JSON.parse(Ti.App.Properties.getString('Config'));
			//Ti.API.debug('Confg: ' + JSON.stringify(Confg));
		}
		var reqModsArray = [];
		var AllowLite = Confg && Confg.AllowLite ? true : false;
		var UseModQtyTxt = Confg && Confg.USE_MOD_QTY_TXT ? true : false;
		var AllowHalf = group.AllowHalf;
		var defRowHidden = false;
		var preCount = 0;
		for(var i=0; i<selItemReqModLngth; i++){
			preCount = 0;
			reqMdRows = [];
		   var reqModsData = [];
			var title;
			var maxReqMds = 0;
			var modIndex = -1;
            
			if(group.HasMaxReqMds && !isNaN(itemSelected.ReqMods[i].MaxReqMds)){
                maxReqMds = itemSelected.ReqMods[i].MaxReqMds;                
			}
	
			var reqModKeys = !isNaN(itemSelected.ReqMods[i].Key) ? itemSelected.ReqMods[i].Key : itemSelected.ReqMods[i];
	
			for(var j=0; j<modCatLngth; j++){
				if(Menu.ModCategories[j].Key == reqModKeys){
					title = Menu.ModCategories[j].Msg;
					break;
				}
			}
	
			var reqMods_view = Ti.UI.createView({
				id:i,
				//backgroundImage:'/images/invGrpBackground.png',
				//name:(title==""?'Step ' + step++ :'Step ' + step++ + ': ' + title ),
				color:ro.ui.theme.grpItemColor,
				maxReqMds:maxReqMds,
				modsCnt:0,
				layout:'vertical',
				testIndex:i,
				reqModKeys: reqModKeys,
				testRequired:true,
				isReqModView:true,
				reloadSelections:reloadReqMods,
				reloadCpnSelections:editRqMods,
				height:Ti.UI.SIZE,
				itemTest:function(itemObj, e){
					return testReqMods(itemObj, e);
				}
			});
			var modCtIdx, rqMdKy;
			if(!isNaN(itemSelected.ReqMods[i].Key)){
				modCtIdx = ro.utils.getMatchingIdx(itemSelected.ReqMods[i].Key, Menu.ModCategories, 'Key');
				rqMdKy = itemSelected.ReqMods[i].Key;
			}
			else{
				modCtIdx = ro.utils.getMatchingIdx(itemSelected.ReqMods[i], Menu.ModCategories, 'Key');
				rqMdKy = itemSelected.ReqMods[i];
			}
	
			//var hdr = layoutMenuHelper.menuHeaders({text:title==""?'Please select ' + Menu.ModCategories[modCtIdx].Name + ':' : title, leftRightBool:true});
			var hdr = ro.layout.getGenericMenuHdrRowWithHeader(title==""?'Please select ' + Menu.ModCategories[modCtIdx].Name + ':' : title, true);
			hdr.top = 0;
                    hdr.bottom = 0;
                    hdr.height = Ti.UI.FILL;
			hdr.touchEnabled = false;
			var modRow = Ti.UI.createView({
				height:ro.ui.relY(40),
				//height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				isHeader:true,
				
				isShowing:true//,
				//backgroundImage:'/images/invGrpBackground.png'
			});
			var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
            greyBar.bottom = 0;
            
			modRow.add(hdr);
			modRow.add(greyBar);
			
			reqMods_view.add(modRow);
        	//reqMods_view.add(Ti.UI.createView(ro.ui.properties.fullGreyBar));
            var reqModsLst = [];
            for (var j = 0; j < grpModLngth; j++) {
                var idx = 1;
                var isPreselected = false;
                var halfOptions = 1;

                if (group.Mods[j].ModCatKey == rqMdKy) {

                    var thisModValid = true;
                    if (itemSelected.ExcldMods) {
                        for (var c = 0; c < itemSelected.ExcldMods.length; c++) {
                            if (itemSelected.ExcldMods[c] == group.Mods[j].Name) {
                                thisModValid = false;
                                break;
                            }
                        }
                    }
                    if (!thisModValid) {
                        continue;
                    }

                    modIndex++;
                    if (itemSelected.PreMods) {
                        for (var k = 0; k < preModLngth; k++) {
                            if (itemSelected.PreMods[k].Name == group.Mods[j].Name) {
                                idx = 0;
                                isPreselected = true;
                                break;
                            }
                        }
                    }

                    var enable = false;

                    if (group.AllowHalf) {
                        enable = (group.Mods[j].NoHalf ? false : true);
                        if (enable) {
                            if (idx != 0) {
                                idx = 3;
                            }
                            halfOptions = 3;
                        }
                    }
                    try {
                        var halfOptionsFlag;
                        if (halfOptions > 1) {
                            halfOptions = 4;
                        }
                        else {
                            halfOptions = 2;
                        }
                        halfOptionsFlag = halfOptions;
                    }
                    catch (ex) {
                        if (Ti.App.DEBUGBOOL) { Ti.API.debug('halfOptions.length: ' + ex); }
                    }                    

                    var defQtyAllowed = Menu.ExtraModMax > 0 ? Menu.ExtraModMax : 4;

                    if (group.Mods[j].ModMaxQty > 0) {
                        defQtyAllowed = group.Mods[j].ModMaxQty;
                    }



                    //Ti.API.debug('group.Mods[j]: ' + JSON.stringify(group.Mods[j]));
                    var dontGrow = !AllowLite && !enable && defQtyAllowed < 2 ? true : false;
                    var isToppingBlockVisible = false;
                    if (isPreselected) {
                        if (!dontGrow) {
                            isToppingBlockVisible = true;
                        }
                        preCount++;
                    }
                    var custModRowProps = {
                        isPreselected: isPreselected,
                        idx: idx,
                        name: group.Mods[j].Name,
                        halfOptionsFlag: halfOptionsFlag,
                        remModIdx: AllowHalf ? 3 : 1,
                        AllowHalf: enable,
                        AllowLite: AllowLite,
                        dontGrow: dontGrow,
                        defQtyAllowed: defQtyAllowed,
                        PosPage: group.Mods[j].PosPage,
                        parentId: i,
                        j: j,
                        enable: enable,
                        isToppingBlockVisible: isToppingBlockVisible
                    };                    
                    reqModsLst.push(custModRowProps);
                }
            }
            if (ro.app.Store.Configuration.SORT_MODS_PS && reqModsLst.length) {
                reqModsLst = reqModsLst.sort(function (a, b) {
                    if (a.isPreselected > b.isPreselected) return -1;
                    else if (a.isPreselected < b.isPreselected) return 1;
                    else if (a.PosPage > b.PosPage) return 1;
                    else if (a.PosPage < b.PosPage) return -1;
                    else return 0;
                });
            }
            for (var r = 0; r < reqModsLst.length; r++) {
                var rm = reqModsLst[r];
                var reqRow = layoutMenuHelper.getPrefModRow(group.Mods[rm.j], rm.j, rm.j, rm.isPreselected, rm.dontGrow, rm, layoutMenuHelper.getNewToppingsBlock(reqModClick, reqExtraClick, group.Mods[rm.j].Name, rm.enable, null, rm.defQtyAllowed, UseModQtyTxt, rm.AllowLite, rm.isToppingBlockVisible), defRowHidden);
					//reqRow = layoutMenuHelper.getPrefModRow(group.Mods[j], j, j, isPreselected, dontGrow, custModRowProps, layoutMenuHelper.getNewToppingsBlock(reqModClick, reqExtraClick, group.Mods[j].Name, enable, null, defQtyAllowed, UseModQtyTxt, AllowLite, isToppingBlockVisible), defRowHidden);
					if(evenOddCtr % 2){
					    reqRow.backgroundColor = "#f6f6f6";
					}
					evenOddCtr++;
					
					if(!reqMdRows || !reqMdRows.length){
					    reqRow.top = 0;
					}
					/*reqRow = layoutMenuHelper.getRow(group.Mods[j], j, j, null, isPreselected, dontGrow);
					//reqRow = layoutMenuHelper.getPrefModRow(group.Mods[j], j, j, null, isPreselected, dontGrow);
					reqRow.isPreselected = isPreselected;
					reqRow.name = group.Mods[j].Name;
					reqRow.PosPage = group.Mods[j].PosPage;
					reqRow.idx = idx;
					reqRow.parentId = i;
					reqRow.halfOptionsFlag = halfOptionsFlag;
					reqRow.remModIdx = enable?3:1;
					reqRow.AllowHalf = enable;
					reqRow.AllowLite = AllowLite;
					reqRow.dontGrow = dontGrow;
					reqRow.defQtyAllowed = defQtyAllowed;
					
					//Ti.API.debug('defQtyAllowed: ' + defQtyAllowed);
					//Ti.API.debug('AllowLite: ' + AllowLite);
					
					var thisTopBlock = layoutMenuHelper.getToppingsBlock(reqModClick, reqExtraClick, group.Mods[j].Name, enable, null, defQtyAllowed, UseModQtyTxt, AllowLite);
					if(isPreselected){
						if(!dontGrow){
							thisTopBlock.visible = true;
						}
						preselectedCount++;
					}
	
					reqRow.topBlock = thisTopBlock;
					reqRow.add(reqRow.topBlock);
					reqRow.className = reqRow.AllowHalf ? 'FullReqModRowLayout' : 'HalfReqModRowLayout';*/
					/*if(reqRow.AllowHalf){
		         	reqRow.className = 'FullReqModRowLayout';
		         }
		         else{
		         	reqRow.className = 'HalfReqModRowLayout';
		         }*/
					reqMdRows.push(reqRow);				
			}
			
			//reqModCollection.push(reqMdRows);
			/*var reqMdTbl = Ti.UI.createTableView({
				width:Ti.UI.FILL,
				data:reqMdRows,
				separatorColor:ro.ui.theme.separatorColor,
				//borderColor:ro.ui.theme.separatorColor,
				borderWidth:ro.ui.relX(1),
				clicked:preselectedCount,
				backgroundColor:ro.ui.theme.tableBgColor,
				//borderColor:'red'//,
				//borderWidth:1
			});*/
			
			var reqMdTbl = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				layout:'vertical',
				//borderColor:ro.ui.theme.separatorColor,
				//borderWidth:ro.ui.relX(1),
				clicked:preCount,
				backgroundColor:ro.ui.theme.tableBgColor,
				visible:true,
				//prefName:isPrefMods&&prefName&&prefName.name ? prefName.name : '',
				disableBounce:ro.isiOS ? true : false,
				ignoreclick:true
				//touchEnabled:false
			});
			/*for( var m=0, mMax=reqMdRows.length; m<mMax; m++){
				reqMdTbl.add(reqMdRows[m]);
			}*/
			reqMdTbl.add(reqMdRows);
			
			//modsView.add(reqMdTbl);
//reqMdRows
			//_cb(modsView);
			//return modsView;
			
			reqMdTbl.addEventListener('click', function(e){
				var row = {};
				if(e.source.ignoreclick){
					Ti.API.debug('e.source.ignoreclick: ' + e.source.ignoreclick);
				}
				if(e.source.isHalfOptView || e.source.isHeader || e.source.ignoreclick){
					return;
				}
				
				if(e.source.isRowView){
					row = e.source.parent;
				}
				else if(e.source.isRow){
					row = e.source;
				}
				else{
					row = e.source.parent.parent;
				}
				
				try{
					if(row.isHeader){
						return;
					}
					if(reqMdTbl.clicked){
					    if(layoutMenuHelper.newRowDeselected(row, row.clicked?true:false)){
							ro.itemObj.setMods(row.name, row.remModIdx, row.isPreselected, 1);
							reqMdTbl.clicked--;
							return;
						}
					}
					reqMdTbl.curIndex = layoutMenuHelper.newRowSelected(row);
					ro.itemObj.setMods(row.name, 0, row.isPreselected, 1);
					reqMdTbl.clicked++;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('reqMods_new.js-reqMdTable.EVENT()-Exception: ' + ex); }
				}
			});
			/*reqMdTbl.addEventListener('click', function(e){
				try{
					if(reqMdTbl.clicked){
						//if(layoutMenuHelper.rowDeselected(e.row, e.row.clicked?true:false)){
						if(layoutMenuHelper.rowDeselected.call(e.row, e.row.clicked?true:false, e.row.dontGrow)){
							
							ro.itemObj.setMods(e.row.name, e.row.remModIdx, e.row.isPreselected, 1);
							reqMdTbl.clicked--;
							return;
						}
					}
					//reqMdTbl.curIndex = layoutMenuHelper.rowSelected(e.row);
					reqMdTbl.curIndex = layoutMenuHelper.rowSelected.call(e.row, e.row.dontGrow);
					ro.itemObj.setMods(e.row.name, 0, e.row.isPreselected, 1);
					reqMdTbl.clicked++;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('newReqMods.js-reqMdTbl.EVENT()-Exception: ' + ex); }
				}
			});*/
			reqMods_view.add(reqMdTbl);
			reqModsArray.push(reqMods_view);
		}
		
		try{
			/*for(var i=0; i<reqModsArray.length; i++){
				if(ro.app.Store.Configuration.SORT_MODS_PS){
		            var thisTbl = reqModsArray[i].children[1];
		            var thisTblRows = reqModsArray[i].children[1].sections[0].rows;
		            thisTblRows = thisTblRows.sort(function(a, b) {
		               if (a.isPreselected > b.isPreselected ) return -1;
		               else if (a.isPreselected < b.isPreselected ) return 1;
		               else if (a.PosPage > b.PosPage ) return 1;
		               else if (a.PosPage < b.PosPage ) return -1;
		               else return 0;
		            });
		            thisTbl.setData(thisTblRows);
		            reqModsArray[i].children[1] = thisTbl;
		            //scrollViewData[i].children[1] = thisTbl;
		            thisTbl = null;
		            thisTblRows = null;
		         }
	         	//scrollViewData.push(reqModsArray[i]);
			}*/
			Ti.API.debug('returning reqModsArray: ' + reqModsArray.length);
			return reqModsArray;
		}
		catch(ex){
			if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('reqMods_new.js - reqModsArray.length-: ' + ex); }
		}
		
	function sortMods(mod1, mod2){
			if(mod1.isPreselected && !mod2.isPreselected){
				return -1;
			}
			else
				if(!mod1.isPreselected && mod2.isPreselected){
					return 1;
				}
			return 0;
		}
	function sortModsPosPage(mod1, mod2){
      return mod1.isPreselected == mod2.isPreselected
         ? parseInt(mod1.PosPage,10) - parseInt(mod2.PosPage,10)
         : mod1.isPreselected < mod2.isPreselected;
   }
    function fieldSorter(fields) {
      return function (a, b) {
         return fields
            .map(function (o) {
               var dir = 1;
               if(o[0] === '-'){
                  dir = -1;
                  o=o.substring(1);
               }
               if(a[o] > b[o]) return dir;
               if(a[o] < b[o]) return -(dir);
               return 0;
            })
            .reduce(function firstNonZeroValue (p,n) {
               return p ? p : n;
            }, 0);
      };
   }

	function validateMaxReqMds(i){
	   var res='';
	   if(reqModsArray[i].maxReqMds>0 && reqModsArray[i].modsCnt>=reqModsArray[i].maxReqMds){
	      res += 'Max ' + reqModsArray[i].maxReqMds + ' selections allowed';
	   }
	   return res;
	}
	function getHalfOptions(rw){
	   try{
			var halfBlock = rw.children[1].children[0];
			var returnBool = 0;
			for(var i=0; i<halfBlock.children.length; i++){
				if(halfBlock.children[i].clicked){
					returnBool = halfBlock.children[i].idx;
					break;
				}
			}
			return returnBool;
		}
		catch(ex){
		   if(Ti.App.DEBUGBOOL)  { Ti.API.debug('getHalfOptions()-ReqMods_new.js-Exception: ' + ex); }
		}
	}
	function reqExtraClick(e){
		try{
			var tblRow = e.source.parent.parent;
			var row = e.source.getSelectedRow(0);

			var name = e.source.name;
			var preSel = tblRow.isPreselected;
			var qty = row.index;
			var halfOptns = getHalfOptions(tblRow);
			ro.itemObj.setMods(name, halfOptns, preSel, qty);
		}
		catch(ex){
			ro.ui.alert('Required Modifiers-QtyChangeEvent: '+ ex);
		}
	}
	function reqModClick(e, cpnEdit, halfOptn, xtra, nm, pId, rIdx){
		try{
			if(cpnEdit){
			   var row = e,
			       rowName = nm,
			       parentId = pId,
			       index = rIdx,
			       halfOpt = halfOptn,
			       extraRowQty = xtra;
			}
			else{
				var extraRowQty = 1;
   				var row = e.source.parent.parent.parent;
   				var rowName = row.name;
   				var parentId = row.parentId;
   				var extraPicker = e.source.parent.parent.children[0];
   				var index = row.idx;
   				var halfOpt = e.source.idx;
   				try{
   					//extraRowQty = extraPicker.children[1].clicked?2:1;
   					var maxQty = extraPicker.children && extraPicker.children.length ? extraPicker.children.length : 0;
	              	for(var i=0, iMax=maxQty; i<iMax; i++){
	              		if(extraPicker.children[i].clicked){
	              			//Ti.API.debug('i: ' + i);
	              			if(row.AllowLite){
	              				extraRowQty = i;
	              			}
	              			else{
	              				extraRowQty = i+1;
	              			}
	              			
	              			break;
	              		}
	              	}
	              	if(!maxQty){
	              		extraRowQty = 1;
	              	}
   				}
   				catch(ex){
   					extraRowQty = 1;
   				}
   				var preSel = row.isPreselected;
   			}

			var noneIndex;
			var remModIndex;
			var extraQty;

			ro.itemObj.setMods(rowName, halfOpt, preSel, extraRowQty);
		}
		catch(ex){
			ro.ui.alert('req mod click', ex);
			Ti.API.debug('reqModClick()-Exception: ' + ex);
		}
    }

    // This function adds PreMods to the Mods used for checking the required mods conditions 
    function AddPreModsToMods(itemObj) {        
        if (itemObj.PreMods && itemObj.PreMods.length) {
            var itmObjPreModLngth = ((itemObj.PreMods) ? itemObj.PreMods.length : 0);   
            if (!itemObj.Mods) itemObj.Mods = [];
            for (var x = 0; x < itmObjPreModLngth; x++) {
                for (var y = 0; y < grpModLngth; y++) {
                    if (itemObj.PreMods[x].Name == group.Mods[y].Name) {
                        var mod = {};
                        var NoModHalfStatus = -1;
                        mod.ModCatKey = group.Mods[y].ModCatKey;
                        mod.Name = group.Mods[y].Name;
                        // Checking NoMods for any changes in the PreMods
                        if (itemObj.NoMods) {
                            var noModsLngth = itemObj.NoMods.length;
                            for (var z = 0; z < noModsLngth; z++) {
                                if (itemObj.NoMods[z].Name == mod.Name) {
                                    NoModHalfStatus = itemObj.NoMods[z].HalfStatus;
                                    break;
                                }
                            }
                        }
                        // This can be optimized further
                        if (NoModHalfStatus == -1) {
                            mod.HalfStatus = 0;
                        } else {
                            if (NoModHalfStatus == 1) mod.HalfStatus = 2;
                            if (NoModHalfStatus == 2) mod.HalfStatus = 1;
                        }
                        // This checks if we need to add the PreMod to the mods or not, don't add it only when its 0 
                        if (NoModHalfStatus != 0) itemObj.Mods.push(mod);                        
                        mod = null;
                        break;
                    }
                }
            }
        }
        return itemObj;
    }

	function testReqMods(itmObj, testIdx){
        try {
            var itemObj = JSON.parse(JSON.stringify(itmObj));
         	if(!itemSelected || !itemSelected.ReqMods || !itemSelected.ReqMods.length) return false;
         	
			if(itemObj.Mods){
		 		ro.itemObj.ModPropFill(itemObj.Mods);
		 	}

		 	if(itemObj.NoMods){
		 		ro.itemObj.ModPropFill(itemObj.NoMods);
            }

            if (itemObj.PreMods) {
                itemObj = AddPreModsToMods(itemObj);                
            }

			var itmObjModLngth, menuModCtgLngth, reqModLngth = itemSelected.ReqMods.length;
			var found, returnBool = true;
			var i=testIdx;

			var reqModKey = !isNaN(itemSelected.ReqMods[i].Key) ? itemSelected.ReqMods[i].Key : itemSelected.ReqMods[i];

			found = false;
			if(itemObj.Mods){
			   itmObjModLngth = ((itemObj.Mods)?itemObj.Mods.length:0);
				for(var j=0; j<itmObjModLngth; j++){
					if(reqModKey == itemObj.Mods[j].ModCatKey){
						found = true;
						break;
					}
				}
            }            
			if(!found){
				returnBool = false;
				menuModCtgLngth = ((Menu.ModCategories)?Menu.ModCategories.length:0);
				for(var j=0; j<menuModCtgLngth; j++){
					if(Menu.ModCategories[j].Key == reqModKey){
						ro.ui.alert('Required:', ((Menu.ModCategories[j].Msg!=="")?Menu.ModCategories[j].Msg:'Please select ' + Menu.ModCategories[j].Name));
						break;
					}
				}
			}
			//newly added (Dec 15, 2010)
			else{
				var whole = false;
				var halfone = false;
				var halftwo = false;
				var	itmObjModLngth = itemObj.Mods?itemObj.Mods.length:0;
				for(var j=0; j<itmObjModLngth; j++){
					if(itemObj.Mods[j].HalfStatus == 0 && reqModKey == itemObj.Mods[j].ModCatKey){
						whole = true;
						break;
					}
                }                
				if(!whole){
				   itmObjModLngth = itemObj.Mods?itemObj.Mods.length:0;
					for(var j=0; j<itmObjModLngth; j++){
						if(itemObj.Mods[j].HalfStatus == 1 && reqModKey == itemObj.Mods[j].ModCatKey){
							halfone = true;
							break;
						}
					}
					itmObjModLngth = itemObj.Mods?itemObj.Mods.length:0;
					for(var j=0; j<itmObjModLngth; j++){
						if(itemObj.Mods[j].HalfStatus == 2 && reqModKey == itemObj.Mods[j].ModCatKey){
							halftwo = true;
							break;
						}
					}
					if(!halfone){
						returnBool = false;
						menuModCtgLngth = Menu.ModCategories?Menu.ModCategories.length:0;
						for(var j=0; j<menuModCtgLngth; j++){
							if(Menu.ModCategories[j].Key == reqModKey){
								ro.ui.alert('Required:', Menu.ModCategories[j].Msg + ' Half1.');
								break;
							}
						}
					}
					if(!halftwo){
						returnBool = false;
						menuModCtgLngth = Menu.ModCategories?Menu.ModCategories.length:0;
						for(var j=0; j<menuModCtgLngth; j++){
							if(Menu.ModCategories[j].Key == reqModKey){
								ro.ui.alert('Required:', Menu.ModCategories[j].Msg + ' Half2.');
								break;
							}
						}
					}
				}
			}

			if(itemSelected.ReqMods[i].MaxReqMds && itemSelected.ReqMods[i].MaxReqMds > 0){
                itmObjModLngth = itemObj.Mods ? itemObj.Mods.length : 0;                
				var reqModCounter = 0;
				var reqModHalfOne = 0;
				var reqModHalfTwo = 0;
                for (var j = 0; j < itmObjModLngth; j++){                    
					if(itemObj.Mods[j].ModCatKey == itemSelected.ReqMods[i].Key){
						if(itemObj.Mods[j].HalfStatus && itemObj.Mods[j].HalfStatus == 1){
							//reqModHalfOne++;
                            reqModHalfOne += itemObj.Mods[j].Qty ? itemObj.Mods[j].Qty : 1;
						}
						else if(itemObj.Mods[j].HalfStatus && itemObj.Mods[j].HalfStatus == 2){
							//reqModHalfTwo++;
                            reqModHalfTwo += itemObj.Mods[j].Qty ? itemObj.Mods[j].Qty : 1;
						}
						else{
                            reqModHalfOne += itemObj.Mods[j].Qty ? itemObj.Mods[j].Qty : 1;
                            reqModHalfTwo += itemObj.Mods[j].Qty ? itemObj.Mods[j].Qty : 1;
						}
					}
                }                
				if((reqModHalfOne > itemSelected.ReqMods[i].MaxReqMds) || (reqModHalfTwo > itemSelected.ReqMods[i].MaxReqMds)){
					returnBool = false;
					ro.ui.alert('Error: ','Max ' + itemSelected.ReqMods[i].MaxReqMds + ' selections allowed');
				}
			}

			return returnBool;
		}
		catch(ex){
			Ti.API.debug('testReqMods-Exception: ' + ex);
		}
	}
		
	function editRqMods(reqModViewIdx){
		try{
			var isPrefMods = false;
	   	var cpnMods, cpnRowBool = false;
	   	//var reqMRows = reqModsArray[reqModViewIdx].children[1].sections[0].rows;
	   	var mRows = reqModsArray[reqModViewIdx].children[1].children;
	   	Ti.API.debug('mRows.length: ' + mRows.length);
	   	//var reqModTable = reqModsArray[reqModViewIdx].children[1];
	   	var mdTable = reqModsArray[reqModViewIdx].children[1];
	
			var rowsCount = mRows.length;
		      var ctr = 0;
	
			  function doWork(){
			  	 var i = ctr;
			  	 if(mRows[i].isHeader){
					ctr += 1;
					setTimeout(doWork, 1);
				 }
				 else{
				 	cpnMods = ro.cpnHelper.chosenMods(mRows[i].name);
	
			         if(cpnMods.isChosen){
			            var mRow = mRows[i];
		
			            if(!mRow.clicked){
			               cpnRowBool = true;
			               layoutMenuHelper.newRowSelected(mRow);//Changes text, rowSize, backgroundImage, item customization control visibility
		
			               /*if(mRow.children[1].children[0].isHalf){
				               mRow.children[1].children[0].toggle(cpnMods.HalfStatus);
				               mRow.children[1].children[1].toggle(cpnMods.Qty, cpnMods.IsLite);
				            }
			               else{
			                  mRow.children[1].children[0].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              /*if(mRow.children[1].children[0].isHalf){
				               //mRow.children[1].children[1].toggle(cpnMods.HalfStatus);	index switched from above due to new layout...and i believe the following line is the new way to call
				               mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				               mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
				            }
			               else{
			                  mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				          mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
		
			               mdTable.clicked++;
			                
			               if(isPrefMods){
							  ro.itemObj.setPrefMods(mRow.name, cpnMods.HalfStatus, false, (cpnMods.IsLite ? 0 : cpnMods.Qty), ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
						   }
						   else{
			               	  ro.itemObj.setMods(mRow.name, cpnMods.HalfStatus, false, cpnMods.IsLite ? 0 : cpnMods.Qty);
			               }
			            }
			            else{//Row is clicked ( meaning it is preselected mod ) &&&& its returning true being in the mods collection ... this means it is preselected and the user chose extra
		
			              	//NOTE:
			              	//No need to check no mods here because this section will only occur when a preselected modifier was changed to extra! If so, the correct halfstatus is returned here as part of this mod and therefore we can properly set the itemObj with this information
			              	//NOTE:
		
			               cpnRowBool = true;
		
			               /*if(mRow.children[1].children[0].isHalf){
			                  mRow.children[1].children[0].toggle(cpnMods.HalfStatus);
			                  mRow.children[1].children[1].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }
			               else{
			                  mRow.children[1].children[0].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				          mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
		
						   if(isPrefMods){
							  ro.itemObj.setPrefMods(mRows[i].name, cpnMods.HalfStatus, true, (cpnMods.IsLite ? 0 : cpnMods.Qty), ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
						   }
						   else{
			               	  ro.itemObj.setMods(mRows[i].name, cpnMods.HalfStatus, true, cpnMods.IsLite ? 0 : cpnMods.Qty);
			               }
			            }
			         }
			         else{
			            if(mRows[i].clicked){
			               	var NoMd = ro.cpnHelper.getNoMods(mRows[i].name);
				               if(NoMd){
				               	cpnRowBool = true;
			                  	var mRow = mRows[i];
								var realHalfStatus = 0;
		
				                  if(NoMd.HalfStatus === 0){
				                  	realHalfStatus = mRow.remModIdx;
				                  }
				                  else if(NoMd.HalfStatus === 1){
				                  	realHalfStatus = 2;
				                  }
				                  else if(NoMd.HalfStatus === 2){
				                  	realHalfStatus = 1;
				                  }
		
		
								  if(isPrefMods){
									 ro.itemObj.setPrefMods(mRow.name, realHalfStatus, true, 1, ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
								  }
								  else{
				                  	 ro.itemObj.setMods(mRow.name, realHalfStatus, true, 1);
				                  }
		
				                   /*if(mRow.children[1].children[0].isHalf){
					                  mRow.children[1].children[0].toggle(realHalfStatus);
					               }*/
					              mRow.topBlock.toggleHalfOpts(realHalfStatus);
		
				                  if(NoMd.HalfStatus == 0){
				                  	layoutMenuHelper.newRowDeselected(mRow, true);
			                  		mdTable.clicked--;
				                  }
				               }
				               else{
				               	//continue;
				               }
			            }
			         }
			         
			         ctr += 1;
					 if(ctr < rowsCount){
						setTimeout(doWork, 1);
					 }
				 }
			  }
			  setTimeout(doWork, 1);
	
	      /*for(var i=0; i<reqMRows.length; i++){
	         cpnMods = ro.cpnHelper.chosenMods(reqMRows[i].name);
	         if(cpnMods.isChosen){
	            var reqMRow = reqMRows[i];
	
	            if(!reqMRow.clicked){
	               cpnRowBool = true;
	               //layoutMenuHelper.rowSelected(reqMRow);
	               layoutMenuHelper.rowSelected.call(reqMRow);
	
	               if(reqMRow.children[1].children[0].isHalf){
		               reqMRow.children[1].children[0].toggle(cpnMods.HalfStatus);
		               reqMRow.children[1].children[1].toggle(cpnMods.Qty);
		            }
	               else{
	                  reqMRow.children[1].children[0].toggle(cpnMods.Qty);
	               }
	
	               ro.itemObj.setMods(reqMRow.name, cpnMods.HalfStatus, false, cpnMods.Qty);
	
	               reqModTable.clicked++;
	               reqModsArray[reqModViewIdx].modsCnt++;
	            }
	            else{
	               //This should only occur if there was a preChosen required mod from the store itself....
	            }
	         }
	         else{
					//If !cpnMods.isChosen
	         }
	      }
	
	      if(cpnRowBool){
	         reqModTable.setData(reqMRows);
	      }*/
		}
		catch(ex){
			if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('reqMods_new.js-EditMods()-Exception: ' + ex); }
		}
	}
	function reloadReqMods(addMods, reqModViewIdx, reqModPage, addNoMods){
		try{
			//var newModLength = addMods?addMods.length:0;
			//var reqMRows = reqModsArray[reqModViewIdx].children[1].sections[0].rows;
			//var reqModTable = reqModsArray[reqModViewIdx].children[1];
			//var ctrMax = reqMRows.length;
	
			var newModLength = addMods?addMods.length:0;
			var noModLength = addNoMods?addNoMods.length:0;
			var mdRows = reqModsArray[reqModViewIdx].children[1].children;
			
			var gIdx = reqModsArray[reqModViewIdx].children[1].gIdx;
			//var prefName = this.children[0].prefName || '';
			var isPrefMods = false;
			
			var rowsCount = mdRows.length;
			
			var ctr = 0;
	
			function doWork(){
					var i = ctr;
					var mRow = mdRows[i];
					if(mRow.isHeader){
						ctr += 1;
						setTimeout(doWork, 1);
					}
					else{
						for(var j=0; j<noModLength; j++){
							if(addNoMods[j].Name === mRow.name){
								var noModHalf = mRow.children[1].children[0];
								var noModQuant = mRow.children[1].children[1];
								var halfLength = addNoMods[j].HalfStatus;
							   if(noModHalf.isHalf){
								   if(addNoMods[j].HalfStatus === 1){
					               	  	halfLength = 2;
					               }
					               if(addNoMods[j].HalfStatus === 2){
					               		halfLength = 1;
					               }
					               mRow.topBlock.toggleHalfOpts(halfLength);
				          		   mRow.topBlock.toggleQty(addNoMods[j].Qty, addNoMods[j].IsLite);
				                  //noModHalf.toggle(halfLength);
				                  //noModQuant.toggle(addNoMods[j].Qty, addNoMods[j].IsLite);
				               }
				               else{
				               	  mRow.topBlock.toggleQty(addNoMods[j].Qty, addNoMods[j].IsLite);
				                  //noModHalf.toggle(addNoMods[j].Qty, addNoMods[j].IsLite);
				               }
				               //var halfLength = addNoMods[j].HalfStatus;
				               
				               if(addNoMods[j].HalfStatus === 0){
				                  try{
				                     if(noModHalf.isHalf){
				                        halfLength = noModHalf.children.length || 1;
				                     }
				                     else{
				                     	if(AllowHalf){
				                     		halfLength = 3;
				                     	}
				                     	else{
				                        	halfLength = 1;
				                        }
				                     }
				                  }
				                  catch(ex){
				                     Ti.API.debug('halfLength-Exception: ' + ex);
				                     halfLength = 1;
				                  }
				                  layoutMenuHelper.newRowDeselected(mRow, true);
				               }
				               
				               
				               if(isPrefMods){
								  ro.itemObj.setPrefMods(mRow.name, halfLength, true, addNoMods[j].IsLite? 0 : addNoMods[j].Qty, ro.app.Store.Menu.Groups[gIdx], prefName);
							   }
							   else{
				               	  ro.itemObj.setMods(mRow.name, halfLength, true, addNoMods[j].IsLite ? 0 : addNoMods[j].Qty);
				               }
				               
				               noModHalf = null;
				               noModQuant = null;
							}
						}
						for(var j=0, jMax=newModLength; j<jMax; j++){
							if(addMods[j].Name === mRow.name){
								var half = mRow.children[1].children[0];
								var quant = mRow.children[1].children[1];
							   layoutMenuHelper.newRowSelected(mRow);
							   //if(half.isHalf){
							   	mRow.topBlock.toggleHalfOpts(addMods[j].HalfStatus);
				         		 mRow.topBlock.toggleQty(addMods[j].Qty, addMods[j].IsLite);
		
			                  	  //half.toggle(addMods[j].HalfStatus);
			                  	  //quant.toggle(addMods[j].Qty, addMods[j].IsLite);
			                   /*}
			               	   else{
			               	   	  mRow.topBlock.toggleQty(addMods[j].Qty, addMods[j].IsLite);
			                  	  //half.toggle(addMods[j].Qty, addMods[j].IsLite);
			                   }*/
			                   if(isPrefMods){
								  ro.itemObj.setPrefMods(mRow.name, addMods[j].HalfStatus, addMods[j].IsPreSel, addMods[j].IsLite ? 0 : addMods[j].Qty, ro.app.Store.Menu.Groups[gIdx], prefName);
							   }
							   else{
			                   	  ro.itemObj.setMods(mRow.name, addMods[j].HalfStatus, addMods[j].IsPreSel, addMods[j].IsLite ? 0 : addMods[j].Qty);
			                   }
			                   half = null;
			                   quant = null;
							}
						}
	
						ctr += 1;
						if(ctr < rowsCount){
							setTimeout(doWork, 1);
						}
					}
				}
			//for(var i=0, iMax=reqMRows.length; i<iMax; i++){
				//var ctr = 0;
			/*function doWork(){
				var i=ctr;
				var reqMRow = reqMRows[i];
				for(var j=0; j<newModLength; j++){
					if(addMods[j].Name === reqMRows[i].name){
					   
					   layoutMenuHelper.newRowSelected.call(reqMRow);
		               if(!reqMRow.topBlock){
		               	
		               	reqMRow.topBlock = layoutMenuHelper.getToppingsBlock(reqModClick, reqExtraClick, reqMRow.name, reqMRow.AllowHalf, addMods[j].Qty);
		               	reqMRow.add(reqMRow.topBlock);
		               }
		               else{
		               	
		               	reqMRow.topBlock.visible = true;
		               }
	
					  		if(reqMRow.children[1].children[0].isHalf){
		                  reqMRow.children[1].children[0].toggle(addMods[j].HalfStatus);
		                  reqMRow.children[1].children[1].toggle(addMods[j].Qty);
		               }
		               else{
		                  reqMRow.children[1].children[0].toggle(addMods[j].Qty);
		               }
		               ro.itemObj.setMods(reqMRow.name, addMods[j].HalfStatus, addMods[j].IsPreSel, addMods[j].Qty);
					}
				}
				reqMRows[i] = reqMRow;
				ctr += 1;
				if(ctr < ctrMax){
					setTimeout(doWork, 1);
				}
			}*/
			setTimeout(doWork, 1);
			//reqModTable.setData(reqMRows);
		}
		catch(ex){
			Ti.API.debug('reloadReqMods()-Exception: ' + ex);
		}
	}

	
};