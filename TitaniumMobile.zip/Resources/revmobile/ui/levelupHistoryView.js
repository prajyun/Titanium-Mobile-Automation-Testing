(function(){
   ro.ui.getLoyaltiesHistoryView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesHistory', 'LEVELUP', layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }

      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var loyaltiesHistoryView = Ti.UI.createView({
         //layout:'vertical',
         top:0,
         bottom:ro.ui.relY(90),//110
         backgroundColor:ro.ui.theme.lvlupHistoryBg
      });
      
      var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      levelUp.getOrderHistory(function(ordHist){
         ordHist = ordHist || {};
         if(!ordHist || !ordHist.length){
         	var noHistoryView = getNoHistoryView();
         	loyaltiesHistoryView.add(noHistoryView);
         	ro.ui.hideLoader();
         }
         else{
         	loyaltiesHistoryView.layout = 'vertical';
         	formHistoryTblRows(ordHist);
         }
      });

      var historyTbl = Ti.UI.createTableView({
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL,
         separatorColor:'gray',
      });
      var histRows = [];

		function getNoHistoryView(){
			var noHistView = Ti.UI.createView({
				height:Ti.UI.SIZE,
				right:ro.ui.relX(15),
				left:ro.ui.relX(15)//,
				//borderColor:'black',
				//borderWidth:6
			});
			var noHistLbl = Ti.UI.createLabel({
				text:'No History Available',
				font:{
					fontSize:ro.ui.scaleFont(18),
					fontWeight:'bold',
					fontFamily:ro.ui.fontFamily
				},
				color:'black',
				textAlign:'center'//,
				//height:ro.ui.relY(40)
			});
			noHistView.add(noHistLbl);

			return noHistView;
		}
      function formHistoryTblRows(historyCol){
      	//ro.ui.showLoader();
         for(var i=0, max=historyCol.length; i<max; i++){

            var thatdate = historyCol[i].order.transacted_at;
            var thatdt = new Date(thatdate);
            var dateStr = (thatdt.getMonth()+1)+'/'+thatdt.getDate()+'/'+thatdt.getFullYear();

            var textColor = ro.ui.theme.lvlupHistoryTxt;
            var storeNameTxt = (historyCol[i].order.merchant_name ? historyCol[i].order.merchant_name : '');
            var amountTxt = '$' + (historyCol[i].order.total_amount ? parseFloat(historyCol[i].order.total_amount/100, 10).toFixed(2).toString() : '0');

            if(historyCol[i].order.refunded_at){//If null, then it was not refunded. Otherwise, lets change a few things so the refund is better visualized.
               textColor = '#eb0029';
               storeNameTxt = 'REFUNDED - ' + (historyCol[i].order.merchant_name ? historyCol[i].order.merchant_name : '');
            }

            var row = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.lblStoreName, {
               //backgroundColor:'white',
               layout:'horizontal',
               rightImage:'/images/details.png',
               height:ro.ui.relY(40),
               thisOrd:historyCol[i].order
            }));
            var dateLbl = Ti.UI.createLabel({
               text:dateStr,
               height:Ti.UI.FILL,
               font:{
                  fontSize:ro.ui.scaleFont(12),
                  fontFamily:ro.ui.fontFamily,
                  fontWeight:'bold'
               },
               color:textColor,
               left:ro.ui.relX(10),
               textAlign:'left',
               width:'25%'
            });
            var storeNameLbl = Ti.UI.createLabel({
               text:storeNameTxt,
               height:Ti.UI.FILL,
               font:{
                  fontSize:ro.ui.scaleFont(12),
                  fontFamily:ro.ui.fontFamily,
                  fontWeight:'bold'
               },
               color:textColor,
               left:ro.ui.relX(10),
               textAlign:'left',
               width:'45%'
            });
            var totalLbl = Ti.UI.createLabel({
               text:amountTxt,
               height:Ti.UI.FILL,
               font:{
                  fontSize:ro.ui.scaleFont(12),
                  fontFamily:ro.ui.fontFamily,
                  fontWeight:'bold'
               },
               color:textColor,
               left:ro.ui.relX(10),
               textAlign:'left'
            });
            row.add(dateLbl);
            row.add(storeNameLbl);
            row.add(totalLbl);

            histRows.push(row);
         }
         historyTbl.setData(histRows);

         /*setTimeout(function(){
         	Ti.API.debug('this happened');
         	ro.ui.hideLoader();
         }, 2000);*/
        ro.ui.hideLoader();
      }

      historyTbl.addEventListener('click', function(e){
         try{
            //ro.ui.showLoader();
            ro.ui.settingsShowNext({addView:true, showing:'loyaltiesHistoryDetails', order:e.rowData.thisOrd});
            //ro.ui.hideLoader();
         }
         catch(ex){
            ro.ui.alert('Loyalties', 'Code:100' + ex);
         }
      });

      loyaltiesHistoryView.add(historyTbl);
      mainView.add(loyaltiesHistoryView);
      return mainView;
   };
})();