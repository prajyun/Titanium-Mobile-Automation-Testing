var QRCODEVIEW = function() {
    var qrcodeview = function(ro) {
        ro.ui.getQrView = function(_args) {
            var hid = 'qrcode',
                titleTxt = 'Qr View';
            var theQrCode;
            var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();

            var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                name: titleTxt,
                hid: hid
            }));
            var navBar = Ti.UI.createView(ro.ui.properties.navBar);

            var hasHappened = false;

            var getBarcode = function() {
                ro.ui.showLoader();
                ro.ui.showLoader();
                
                var protocol = ro.isiOS ? "http://" : "https://";
                
                var store = ro.app.Store ? ro.app.Store : ro.REV_STORES.getDefaultStore();
                currentLoyalty.getLtyCustomerDetails(Ti.App.Username, (store.ID ? store.ID : null), function(response) {
                    Ti.API.info("response: " + JSON.stringify(response));
                    if(response.Success){
                    	theQrCode = (response.Customers && response.Customers.length) ? response.Customers[0].LoyaltyID: null;
                    	var localCfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
                    	//var url = 'http://r-enterprise.com/common/getbarcode?data='+theQrCode+'&Format=4&ImageFormat=1';
                    	var url = protocol + 'r-enterprise.com/common/getbarcode?data=' + theQrCode + '&Format=' + (localCfg && localCfg.LTY_BARCODE_FMT >= 0 ? localCfg.LTY_BARCODE_FMT : 4) + '&ImageFormat=1&height=' + urlHeight + '&width=' + urlWidth;
                        barcodeView.image = url;
                        Ti.API.info("url: " + url);
                    }else{
                    	ro.ui.alert("Loyalty",response.Message);
                    	
                        	if (Ti.App.atPayScrn) {
                    			ro.ui.cartShowNext({
                        		showing: 'levelup'
                    			});
                			}
                			else {
                    			ro.ui.ordShowNext({
                        		showing: hid
                    			});
                			}
                          
                    	}                    
                    ro.ui.hideLoader();
                	});
            	};
            mainView.addEventListener('postlayout', getBarcode);

            var btnBack = layoutHelper.getBackBtn(Ti.App.atPayScrn ? 'PAYMENT SCREEN' : 'ORDER TYPE');
            btnBack.addEventListener('click', function(e) {
                if (Ti.App.atPayScrn) {
                    ro.ui.cartShowNext({
                        showing: 'levelup'
                    });
                }
                else {
                    ro.ui.ordShowNext({
                        showing: hid
                    });
                }
            });
            navBar.add(btnBack);

            var ldf = Ti.Platform.displayCaps.logicalDensityFactor;
            var qrHeight = 300;
            var qrWidth = 300;
            /*var urlHeight = qrHeight * ldf;
             var urlWidth = qrWidth * ldf;*/
            var urlHeight = qrHeight * ldf;
            var urlWidth = qrWidth * ldf;

            var barcodeView = Ti.UI.createImageView({
                /*width:Ti.UI.SIZE,
                 height:Ti.UI.SIZE*/
                width: ro.ui.relX(qrWidth),
                height: ro.ui.relY(qrHeight)
                //width:ro.ui.relX(175)
                /*width:Ti.UI.FILL,
                 right:ro.ui.relX(30),
                 left:ro.ui.relX(30)*/
            });

            //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            
          if(ro.isiphonex){
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            }
            else{
                mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            }
            mainView.add(barcodeView);
            return mainView;
        };

    };
    return {
        qrcodeview: qrcodeview
    };
}();
module.exports = QRCODEVIEW; 