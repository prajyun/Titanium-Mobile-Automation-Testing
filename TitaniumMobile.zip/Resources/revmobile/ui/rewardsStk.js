var REWARDSSTK = function(){
	//Ti.include('/classes/suds.js');
	var rewardsstk = function(ro){
		
		var rewardsStk = null;
		var shouldInclude = true;
		var REWARDSVIEW;

		function includeRewardsFiles() {

			//Ti.include('/revmobile/ui/levelupOverview.js');
			REWARDSVIEW = REWARDSVIEW || require("revmobile/ui/levelupOverview");
		    REWARDSVIEW.rewardsview(ro);
			shouldInclude = false;
		}


		ro.ui.currentRewardsViewIdx = function() {
			return rewardsStk.currentIndex;
		};
        ro.ui.rewardsStkViewID = function () {
            if (rewardsStk.hasOwnProperty('children') && rewardsStk.children.length) {
                return rewardsStk.children[0].hid;
            }
            else {
                return '';
            }
			//return rewardsStk.children[0].hid;
		};
		ro.ui.rewardsStkSize = function() {
			return rewardsStk.children.length;
		};
		ro.ui.remRewardsStkChildren = function() {
			rewardsStk.removeAllChildren();
		};
		ro.ui.createRewardsStk = function(_args) {
			rewardsStk = ro.ui.createStackView({
				views : [],
				props : {
					top : 0,
					left : 0,
					right : 0,
					bottom : 0
				}
			});
			ro.ui.rewardsShowNext = function(e) {
				try {

					if (shouldInclude) {
						includeRewardsFiles();
					}

					if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
					ro.ui.showLoader();
					var curIndex = rewardsStk.currentIndex;
					var curView = rewardsStk.children[curIndex];
					var nextView = null;
					var interval = 400;
					var childrenLength = rewardsStk.children.length;
					rewardsStk.removeAllChildren();

					if (e.addView) {
						switch(e.showing) {
							case 'honeycomb':
		                     //ro.ui.hideTabview();
		                     nextView = ro.ui.getLoyaltiesView({fromRewardsTab:true});
		                     break;

						}
					} else {
						switch(e.showing) {
							case 'honeycomb':
		                     ro.ui.changeTab({
		                        tabIndex:0
		                     });
		                     break;

						}
					}
					if (nextView && nextView != null) {
						try {
							ro.app.GA.trackPageView(nextView.hid);
						} catch(ex) {
							if (Ti.App.DEBUGBOOL) {
								Ti.API.debug('ro.app.GA.trackPageView(rewardsStk.js)-Exception: ' + ex);
							}
						}

						rewardsStk.add(nextView);
						ro.ui.hideHomeSelection(true);
						rewardsStk.children[0].visible = true;
					}
				} catch(ex) {
					ro.ui.alert('Navigation Error', 'Code:N100' + ex);
				}
			};

			ro.ui.rewardsRemoveView = function(e) {
				rewardsStk.remove(e.view);
				rewardsStk.currentIndex--;
			};

			ro.ui.rewardsReset = function(e) {
				try {
					if (rewardsStk.currentIndex != 0) {
						rewardsStk.children[0].animate({
							duration : 50,
							right : 0
						});
						rewardsStk = ro.ui.popViews({
							parent : rewardsStk,
							startIndex : rewardsStk.children.length - 1,
							count : rewardsStk.children.length - 2
						});

						rewardsStk.children[1].animate({
							duration : 50,
							right : 0
						});
						rewardsStk.fireEvent('changeStkIndex', {
							idx : 0
						});
					}
				} catch(ex) {
					ro.ui.alert('Navigation Error', 'Code:N102' + ex);
				}
			};
			return rewardsStk;
		};
	};
	return {
		rewardsstk:rewardsstk
	};
}();
module.exports = REWARDSSTK;
