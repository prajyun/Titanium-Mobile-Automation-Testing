(function(){
   ro.ui.getLoyaltiesLoyaltyView = function(_args){
      var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
      var titleTxt = 'REWARDS';
      
      try{
         var mainView = layoutHelper.getMainView('loyaltiesLoyalty', titleTxt, layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      if(!currentLoyalty.isHC){
         var creditBanner = Ti.UI.createView({
            top:0,
            height:ro.ui.relY(50),
            width:Ti.UI.FILL,
            backgroundColor:ro.ui.theme.headerBackgroundColor//
         });
         var creditBannerLbl = Ti.UI.createLabel({
            text:'You have $0.00 in credit.',
            font:{
               fontSize:ro.ui.scaleFont(15),
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'white',
            visible:currentLoyalty.isHC ? false : true
         });
         creditBanner.add(creditBannerLbl);
         mainView.add(creditBanner);
      }


      var loyaltiesView =  Ti.UI.createScrollView({
         layout:'vertical',
         top:0
      });
      
      //var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      if(currentLoyalty.isLU){
      	ro.ui.showLoader();
         currentLoyalty.getLoyalties(function(e){
            e = e || {};
            if(e.merchant_loyalty_enabled){
               var vertical = false, horizontal = false, circular = true;
               if(vertical){
                  createVerticalLoyaltyDisplay(e);
                  ro.ui.hideLoader();
               }
               else if(horizontal){
                  createHorizontalLoyaltyDisplay(e);
                  ro.ui.hideLoader();
               }
               else if(circular){
                  createCircularLoyaltyDisplay(e);
               }
   
            }
            else{
               createNoCampaignView();
               ro.ui.hideLoader();
            }
            
         });
         //ro.ui.hideLoader();
      }
      else if(currentLoyalty.isHC){
         currentLoyalty.getCustomerDetails(Ti.App.Username, Ti.App.Password, function(response){
            if(!response.Success){
               createNoCampaignViewHc(response.Message);
               return;
            }
            
            var loyaltyObj = response.Customers[0];
            
            loyaltyObj.progress_percentage = ((loyaltyObj.PointsBalance / (loyaltyObj.PointsBalance + loyaltyObj.PointsReqForReward))*100).toFixed(0);
            
            
            ////deb.ug(response, 'response');
            if(response.Success){
               createCircularLoyaltyDisplay(loyaltyObj);
            }
            /*else{
               createNoCampaignView();
            }*/
         });
         ro.ui.hideLoader();
      }

      function createNoCampaignViewHc(customMessage){
         loyaltiesView.add(Ti.UI.createLabel({
            text:customMessage,
            top:ro.ui.relY(100),
            font:{
               fontSize:ro.ui.scaleFont(20),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'black'
         }));
      }

      function createNoCampaignView(){
         loyaltiesView.add(Ti.UI.createLabel({
            text:'There are no current rewards campaigns',
            top:ro.ui.relY(100),
            font:{
               fontSize:ro.ui.scaleFont(20),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'black'
         }));
      }

      function createHorizontalLoyaltyDisplay(rewardsObj){
         var fillChartHeight = ro.ui.relY(200);
         var fillChartWidth = ro.ui.relY(300);
         var percentComp = rewardsObj.progress_percentage;
         var animateRight = (1 - (percentComp/100)) * fillChartWidth;

         var fillChart = Ti.UI.createView({
            top:ro.ui.relY(40),
            height:fillChartHeight,
            //left:ro.ui.relX(50),
            //right:ro.ui.relX(50),
            width:fillChartWidth,
            backgroundColor:'#dcdcdc'
         });
         var fillLine = Ti.UI.createView({
            height:fillChartHeight,
            //top:fillChartHeight,
            width:fillChartWidth,
            right:fillChartWidth,
            backgroundColor:'#71CB3A'
         });
         fillChart.add(fillLine);
         fillLine.animate({right:animateRight}, function(){

         });

         var completionPercentLbl = Ti.UI.createLabel({
            text:percentComp + '%',
            font:{
               fontSize:ro.ui.scaleFont(50),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            top:ro.ui.relY(10),
            color:'black'
         });
         var campaignDetailsLbl = Ti.UI.createLabel({
            text:'Every time you spend $' + (rewardsObj.merchant_spend_amount/100).toFixed(2) + ', you earn $' + (rewardsObj.merchant_earn_amount/100).toFixed(2),
            font:{
               fontSize:ro.ui.scaleFont(20),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'black',
            top:ro.ui.relY(5),
            left:ro.ui.relX(10),
            right:ro.ui.relX(10)
         });

         loyaltiesView.add(fillChart);
         loyaltiesView.add(completionPercentLbl);
         loyaltiesView.add(campaignDetailsLbl);
         ro.ui.hideLoader();
      }

      function createVerticalLoyaltyDisplay(rewardsObj){
         var fillChartHeight = ro.ui.relY(300);
         var percentComp = rewardsObj.progress_percentage;
         var animateTop = (1 - (percentComp/100)) * fillChartHeight;

         var fillChart = Ti.UI.createView({
            top:ro.ui.relY(20),
            height:fillChartHeight,
            left:ro.ui.relX(50),
            right:ro.ui.relX(50),
            backgroundColor:'#dcdcdc'
         });
         var fillLine = Ti.UI.createView({
            height:fillChartHeight,
            top:fillChartHeight,
            backgroundColor:'#71CB3A'
         });
         fillChart.add(fillLine);
         fillLine.animate({top:animateTop}, function(){

         });

         var completionPercentLbl = Ti.UI.createLabel({
            text:percentComp + '%',
            font:{
               fontSize:ro.ui.scaleFont(50),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'black',
            top:ro.ui.relY(10)
         });
         var campaignDetailsLbl = Ti.UI.createLabel({
            text:'Every time you spend $' + (rewardsObj.merchant_spend_amount/100).toFixed(2) + ', you earn $' + (rewardsObj.merchant_earn_amount/100).toFixed(2),
            font:{
               fontSize:ro.ui.scaleFont(20),
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            top:ro.ui.relY(5),
            color:'black',
            left:ro.ui.relX(10),
            right:ro.ui.relX(10)
         });

         loyaltiesView.add(fillChart);
         loyaltiesView.add(completionPercentLbl);
         loyaltiesView.add(campaignDetailsLbl);
         ro.ui.hideLoader();
      }

      function createCircularLoyaltyDisplay(rewardsObj){
         var fillChartHeight = ro.ui.relY(300);
         var percentComp = rewardsObj.progress_percentage;
         var animateTop = (1 - (percentComp/100)) * fillChartHeight;


         var circularWebview = Ti.UI.createWebView({
            url:'/levelUp/example/circleChart.html',
            top:ro.ui.relY(40),
            height:fillChartHeight,
            backgroundColor:'transparent'
         });
         circularWebview.addEventListener('load', function(){
            Ti.App.fireEvent('createCircle', {
               completedPercentage:percentComp
            });
            ro.ui.hideLoader();
         });

         var campaignDetailsTxt = currentLoyalty.isHC ? 'You have ' + rewardsObj.PointsBalance + ' points. Only ' + rewardsObj.PointsReqForReward + ' more points until your next reward!' : 'Every time you spend $' + (rewardsObj.merchant_spend_amount/100).toFixed(2) + ', you earn $' + (rewardsObj.merchant_earn_amount/100).toFixed(2); 
         var campaignDetailsLbl = Ti.UI.createLabel({
            text:campaignDetailsTxt,
            font:{
               fontSize:ro.ui.scaleFont(20),
               fontWeight:'bold',
               fontFamily:ro.ui.fontFamily
            },
            textAlign:'center',
            color:'black',
            top:ro.ui.relY(5),
            left:ro.ui.relX(10),
            right:ro.ui.relX(10)
         });

         loyaltiesView.add(circularWebview);
         loyaltiesView.add(campaignDetailsLbl);
         //ro.ui.hideLoader();
      }

      if(currentLoyalty.isLU){
         currentLoyalty.getCreditAmt(function(e){
            creditBannerLbl.text = 'You have $' + (parseInt(e.total_amount,10)/100).toFixed(2).toString() + ' in credit.';
         });
      }
      else if(currentLoyalty.isHC){
         
      }

      mainView.add(loyaltiesView);
      return mainView;
   };
})();