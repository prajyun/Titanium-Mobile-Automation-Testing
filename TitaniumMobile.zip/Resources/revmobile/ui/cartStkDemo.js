(function(){
	var cartStk = null;
	var shouldInclude = true;
	
	function includeDemoCartFiles(){
		Ti.include('/revmobile/ui/cartViewDemo.js');
		Ti.include('/revmobile/ui/paymentView.js');
		Ti.include('/revmobile/ui/couponsView.js');
		shouldInclude = false;
	}
	
	ro.ui.currentCartDemoViewIdx = function(){
	   return cartStk.currentIndex;
	};
	ro.ui.demoCartStkViewID = function(){
      return cartStk.children[0].hid;
   };
   ro.ui.demoCartStkExplode = function(){
      cartStk.removeAllChildren();
   };
	ro.ui.createCartStkDemo = function(_args){
		try{
			cartStk = ro.ui.createStackView({
				views:[],
				props:{
				   top:0,
					left:0,
					right:0,
					bottom:0,
				}
			});
		}
		catch(e){
		   ro.ui.alert('cart demo ', e);
		}
		
		ro.ui.demoCartShowNext = function(e){
		   try{
		   	
		   	if(shouldInclude){
		   		includeDemoCartFiles();
		   	}
		   	
		      ro.ui.showLoader();
		      var curIndex = cartStk.currentIndex;
			   var curView = cartStk.children[curIndex];
			   var nextView = null;
			   var interval = 400;
			   var childrenLength = cartStk.children.length;
            cartStk.removeAllChildren();
			   
			   if(e.addView){
			      switch(e.showing){
			         case 'demoCart':
			            //Ti.include('/revmobile/ui/cartViewDemo.js');
			            nextView = ro.ui.createDemoCartView();
			            break;
			         case 'Payment':
			            //Ti.include('/revmobile/ui/paymentView.js');
							nextView = ro.ui.createPaymentView();
							break;
					   case 'Coupons':
					      //Ti.include('/revmobile/ui/couponsView.js');
					      nextView = ro.ui.createCouponsView();
							break;
					}
				}
				else{
				   switch(e.showing){
				      case 'demoCart':
				         ro.ui.changeTab({
                        tabIndex:0
                     });
				         break;
				      case 'Payment': case 'Coupons':
				         //Ti.include('/revmobile/ui/cartViewDemo.js');
				         nextView = ro.ui.createDemoCartView();
				         break;
				   }
				}
				
				if(nextView && nextView!=null){
               cartStk.add(nextView);
               cartStk.children[0].visible = true;
               if(e.addView && e.showing == 'demoCart'){
                  ro.ui.reloadCartDemo();
               }
               else if(!e.addView && (e.showing == 'Payment' || e.showing == 'Coupons')){
                  ro.ui.reloadCartDemo();
               }
               ro.ui.hideLoader();
            }
            //ro.ui.hideLoader();
			}
			catch(ex){
			   ro.ui.alert('Navigation Error', 'Code:N300');
			}
		};

		ro.ui.demoCartRemoveView = function(e){
		   cartStk.remove(e.view);
			cartStk.currentIndex--;
		};
		
		ro.ui.demoCartReset = function(e){
		   try{
		      if(cartStk.currentIndex != 0){
		         cartStk.children[0].animate({
		            duration:50,
		            right:0
		         });
			 		
			 		cartStk = ro.ui.popViews({
			 		   parent:cartStk,
						startIndex:cartStk.children.length - 1,
						count:cartStk.children.length - 2
					});

					cartStk.children[1].animate({
					   duration:50,
					   right:0
					});
					cartStk.fireEvent('changeStkIndex', {idx:0});
				}
			}
			catch(ex){
			   ro.ui.alert('Navigation Error', 'Code:N302');
			}
		};
		return cartStk;
	};
}());