var NEWGROUPSVIEW = function(){
	var newgroupsview = function(ro){
        ro.ui.createNewGrpsItemsView = function (_args) {
			//var globalSetBadge;// = badge.setBadge;
			var globalSetBadge = function(){
		
            };            
            Ti.API.info("This is newGrpsItemsView.js");
			var getBadge = function(){
				var numRewards = 0;
				var lbl = Ti.UI.createLabel({
					text:numRewards,
					color:'white',
					textAlign:'center',
					font:{
						fontSize:ro.ui.scaleFont(18),//18
						fontWeight:'bold',
						fontFamily:ro.ui.fontFamily
					}
				});
				var badge = Ti.UI.createView({
					borderRadius:ro.ui.relX(25),
					height:ro.ui.relY(25),//25
					width:ro.ui.relX(25),//25
					backgroundColor:'#eb0029',
					right:2,
					top:2,
					visible:false
				});
				badge.add(lbl);
				badge.setBadge = function(){
					var curLty = ro.REV_LOYALTY.getCurrentLoyalty();
					if(curLty && curLty.isHC){
						curLty.getLtyCustomerDetails(Ti.App.Username, ro.app.Store.ID, function(e){
							var numRewards = e && e.Customers && e.Customers.length && e.Customers[0].Rewards && e.Customers[0].Rewards.length ? e.Customers[0].Rewards.length : 0;
							var newNumRewards = numRewards;
							for(var i=0,iMax=numRewards; i<iMax; i++){
								var itmCpnBreak = false, cpnBreak = false;
								if(e.Customers[0].Rewards[i].hasOwnProperty("RewardID") && e.Customers[0].Rewards[i].RewardID && e.Customers[0].Rewards[i].RewardID.length){
									for(var j=0, jMax=Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0; j<jMax; j++){
										if(Ti.App.OrderObj.Items[j].hasOwnProperty("CpnObj") && Ti.App.OrderObj.Items[j].CpnObj && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode.length && (Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode == e.Customers[0].Rewards[i].RewardID)){
											itmCpnBreak = true;
											newNumRewards--;
											break;
										}
									}
									if(!itmCpnBreak){
										for(var k=0, kMax=Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; k<kMax; k++){
											if(Ti.App.OrderObj.Cpns[k].LoyaltyCode && Ti.App.OrderObj.Cpns[k].LoyaltyCode.length && (Ti.App.OrderObj.Cpns[k].LoyaltyCode == e.Customers[0].Rewards[i].RewardID)){
												newNumRewards--;
												break;
											}
										}
									}
									
								}
							}
							if(newNumRewards){
								badge.children[0].text = newNumRewards;
								badge.visible = true;
							}
							else{
								badge.visible = false;
							}
							ro.ui.hideLoader();
						});
					}
				};
				globalSetBadge = badge.setBadge;
				return badge;
			};
			if(!ro.app.Store){
			  // require('controls/paymentControl');
			   //ro.app.Store = ro.app.Store;
			}
			////deb.ug(ro.app.Store.Configuration, 'ro.app.Store.Configuration');
			var rs = ro.db.getCustObj(Ti.App.Username);
			
			var isGuest = false;
			if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
			   isGuest = true;
			}
			
			ro.REV_LOYALTY.init();
	        ro.REV_LOYALTY.setCurrentLoyalty();
	        
	        var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
			
			try{
			   var menuUtils = require('logic/menuUtils');
	         var menuHelper = require('logic/menuHelper');
			   var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
	         var Groups = menuHelper.getGroups(ro.app.Store.Menu, timeAtStore);
	         
	         ro.cpnHelper.addAutoCpns(ro.app.Store);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('ro.ui.createNewGrpsItemsView()-Exception' + ex); }
	      }
	      ////deb.ug(ro.app.Store, 'ro.app.Store');
	
			if(Ti.App.OrderObj && ro.app.Store && ro.app.Store.Menu){
				var priceEngine = require('logic/pricing');
	        	var func = priceEngine.pricer();
	     	    Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
	     	    //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
	     	}
	     	else{
	     		if(Ti.App.DEBUGBOOL) {
	     			Ti.API.debug('Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
	     			Ti.API.debug('ro.app.Store: ' + JSON.stringify(ro.app.Store));
	     			Ti.API.debug('Ti.App.OrderObj.OrdTypePriceIdx: ' + JSON.stringify(Ti.App.OrderObj.OrdTypePriceIdx));
	     		}
	     	}
	
			function getMainView(){
				var mainView, navBar, headerLbl, logoutBtn, backBtn;
	
				mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
					name:'grpsItems',
					hid:'grpsItems',
					layout:'vertical'
				}));
				navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
			   logoutBtn = layoutHelper.getLogoutBtn();
				backBtn = layoutHelper.getBackBtn();
                backBtn.addEventListener('click', function (e) {
                    ro.ui.ordShowNext({ showing: 'grpsItems' });
					//if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length > 0){
					//	/*ro.ui.popup('WARNING: ', ['CANCEL', 'OK'], 'You are about to leave the menu and this will reset your cart. Would you like to continue?', function(e){
					//		if(e.index === 1){
					//			ro.ui.ordShowNext({showing:'grpsItems'});
					//		}
					//	});*/
					//	ro.ui.ordShowNext({showing:'grpsItems'});
					//}
					//else{
					//	ro.ui.ordShowNext({showing:'grpsItems'});
					//}
				});
				navBar.add(backBtn);
				//navBar.add(logoutBtn);
				//mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				if(ro.isiphonex){
					var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
					var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
					var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
					navParent.add(topNav);
					bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
					navParent.add(bottomNav);
					mainView.add(navParent);
				}
				else{
					mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				}
				return mainView;
			}
            function setOrderObj() {
                if (REV_ORD_TYPE.needsSpecificOrdType()) {
                    REV_ORD_TYPE.promptForSpecificOrdType();
                }
                else {
                    var ordIdx, test;
                    test = Ti.App.OrderObj;
                    if (!Ti.App.OrderObj.OrdType || Ti.App.OrderType == "") {
                        ordIdx = ro.utils.getMatchingIdx(Ti.App.OrderObj.ordOnlineOptions.IsDelivery, ro.app.Store.Menu.OnlineOptions.OrdTypes, 'IsDelivery');
                        test.OrdType = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdType;
                        test.OrderTypeCategory = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrderTypeCategory;
                        test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[ordIdx].OrdTypePriceIdx;
                    }
                    test.Menu = ro.app.Store.Menu.Name;
                    test.CurSplit = 0;
                    if (!test.Items || !test.Items.length) {
                        test.Items = [];
                    }
                    if (!test.Cpns || !test.Cpns.length) {
                        test.Cpns = [];
                    }
                    Ti.App.OrderObj = test;
                    test = null;
                }
				
			}
			function createRows(_rowCallback){
				var thisGrpRow, rowData = [], GrpLngth, favoriteOrders, cpnObj, rewards;
		      GrpLngth = Groups.length;
	
	         var totalGroupCol = [];
	         
	         //var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
	         if(currentLoyalty.isHC && currentLoyalty.showHcTab(ro.app.Store.Configuration) && currentLoyalty.showMenuGroup()){
	         	var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
		        var rewardsDisplayName = cfg.LTY_ACCT_HDR && cfg.LTY_ACCT_HDR.length ? cfg.LTY_ACCT_HDR : 'My Reward Account';
	         	rewards = {
	   				//DisplayName:'My Rewards',
	   				DisplayName:rewardsDisplayName,
	   				ImageSource:Ti.App.websiteURL + '/content/images/myltyaccount.png',
	   				//ImageSource:ro.ui.properties.defaultPath + 'loyalty.png',
	   				Name:'My Rewards'
	   			};
	   			//thisGrpRow = addRow(favoriteOrders);		//FAVORITEORDERS ROW
	   			//rowData.push(thisGrpRow);
	   			totalGroupCol.push(rewards);
	         }
	         
	         if(!isGuest && rs.PrevOrders && rs.PrevOrders.length){
	         	//MY_ORD_HDR
	         	var storeObj = ro.app.Store;
	         	var dispName = 'My Orders';
	         	if(storeObj && storeObj.Configuration && storeObj.Configuration.MY_ORD_HDR && storeObj.Configuration.MY_ORD_HDR.length){
	         		dispName = storeObj.Configuration.MY_ORD_HDR;
	         	}
	   			favoriteOrders = {
	   				DisplayName:dispName,
	   				ImageSource:ro.ui.properties.defaultPath + 'favorite.png',
	   				Name:'Orders'
	   			};
	   			//thisGrpRow = addRow(favoriteOrders);		//FAVORITEORDERS ROW
	   			//rowData.push(thisGrpRow);
	   			totalGroupCol.push(favoriteOrders);
	   		}
	
	         if(menuUtils.hasDispCoupons()){
	   			cpnObj = {
	   				DisplayName:'Coupons',
	   				ImageSource:ro.ui.properties.defaultPath + 'coupon.png',
	   				Name:'Coupons'
	   			};
	   			//thisGrpRow = addRow(cpnObj);					//COUPON ROW
	   			//rowData.push(thisGrpRow);
	   			totalGroupCol.push(cpnObj);
	   		}
	   		
	   		totalGroupCol = totalGroupCol.concat(Groups);
	   		 //totalGroupCol = Groups.concat(totalGroupCol);
	         GrpLngth = totalGroupCol.length;
	
				for(var i=0; i < GrpLngth; i++){				//GROUPS ROW
					//thisGrpRow = addRow(Groups[i]);
					thisGrpRow = addRow(totalGroupCol[i]);
					rowData.push(thisGrpRow);
				}
				_rowCallback(rowData);
			}
			function addRow(GRP){
				var rowView, rowImg, label, imagePath = ro.ui.properties.defaultPath + 'default.png';
	
				rowView = Ti.UI.createView({
					height:Ti.UI.FILL,
					width:Ti.UI.FILL,
					layout:'horizontal'
				});
				rowImg = Ti.UI.createImageView({
					image:GRP.ImageSource,
					defaultImage:imagePath,
					label:GRP.Name,
					top:ro.ui.relY(5),
					bottom:ro.ui.relY(5),
					width:ro.ui.relX(70),
					height:ro.ui.relX(70),
					zIndex:100
				});
				label = Ti.UI.createLabel({
					text:GRP.DisplayName || GRP.ReceiptName,
					top:ro.ui.relY(27),
					left:ro.ui.relX(15),
					width:Ti.UI.FILL,
					textAlign:'left',
					color:ro.ui.theme.newGroupsBtnTxt,
					zIndex:200,
					font:{
						fontSize:ro.ui.scaleFontY(20,14),
						fontWeight:'bold',
	            		fontFamily:ro.ui.fontFamily
					}
				});
				rowView.add(rowImg);
				rowView.add(label);
				grpRow = Ti.UI.createTableViewRow({
					selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
					height:ro.ui.relY(80),
					width:Ti.UI.FILL,
					Name:GRP.Name
				});
				grpRow.add(rowView);
				return grpRow;
			}
			function createNewRows(_rowCallback){
				try{
					var thisGrpRow, rowData = [], GrpLngth, favoriteOrders, cpnObj;
			      
			      var totalGroupCol = [];
	
		         if(currentLoyalty.isHC && currentLoyalty.showHcTab(ro.app.Store.Configuration) && currentLoyalty.showMenuGroup()){
		         	var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
		         	var rewardsDisplayName = cfg.LTY_ACCT_HDR && cfg.LTY_ACCT_HDR.length ? cfg.LTY_ACCT_HDR : 'My Reward Account';
		         	rewards = {
		   				DisplayName:rewardsDisplayName,
		   				ImageSource:Ti.App.websiteURL + '/content/images/myltyaccount.png',
		   				Name:'My Rewards',
		   				IsLoyalty:true
		   			};
		   			//totalGroupCol.push(rewards);
		         }
	
	            if(!isGuest && rs.PrevOrders && rs.PrevOrders.length){
	            	var storeObj = ro.app.Store;
		         	var dispName = 'My Orders';
		         	if(storeObj && storeObj.Configuration && storeObj.Configuration.MY_ORD_HDR && storeObj.Configuration.MY_ORD_HDR.length){
		         		dispName = storeObj.Configuration.MY_ORD_HDR;
		         	}
	   				favoriteOrders = {
	   					DisplayName:dispName,
	   					ImageSource:Ti.App.websiteURL + '/content/images/favorite.png',
	   					Name:'Orders',
	   					defImg:'/images/favorite.png'
	   				};
					   //totalGroupCol.push(favoriteOrders);
					}
	
	            if(menuUtils.hasDispCoupons()){
	   				cpnObj = {
	   					DisplayName:'DEALS',
	   					ImageSource:Ti.App.websiteURL + '/site/groupimages/tabs/deals.png',
	   					//ImageSource:ro.ui.properties.defaultPath + 'coupon.png',
	   					defImg:ro.ui.properties.defaultPath + 'coupon.png',
	   					Name:'Coupons'
	   				};
	   				//totalGroupCol.push(cpnObj);
	   			}
					
					totalGroupCol = totalGroupCol.concat(Groups);
					//totalGroupCol = Groups.concat(totalGroupCol);
					GrpLngth = totalGroupCol.length;
					var oddEvenCtr = 1;
					for(var i=0; i < GrpLngth; i+=2){				//GROUPS ROW
						if(i+1 < GrpLngth){
							thisGrpRow = addNewRow(totalGroupCol[i], totalGroupCol[i+1], (oddEvenCtr%2 != 0));
						}
						else{
							thisGrpRow = addNewRow(totalGroupCol[i], null, (oddEvenCtr%2 != 0));
						}
						rowData.push(thisGrpRow);
						oddEvenCtr++;
					}
					_rowCallback(rowData);
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('createNewRows()-Exception' + ex); }
				}
			}
			function circleView(moreTop, isOdd, invisCircle){
				return Ti.UI.createView({
					borderRadius:ro.ui.relX(2.5),
					height:ro.ui.relX(6),
					width:ro.ui.relX(6),
					backgroundColor:invisCircle ? (ro.ui.theme.circleViewColors.transparent) : (isOdd ? ro.ui.theme.circleViewColors.background : ro.ui.theme.circleViewColors.altBackground),
					//backgroundColor:isOdd ? "#e4e4e4" : "#f6f6f6",
					top:moreTop ? (ro.isiOS ? ro.ui.relY(2) : ro.ui.relY(7)) : ro.ui.relY(5)
				});
			}
			function getMiddleBorder(isOdd){
				var middleBorder = Ti.UI.createView({
					height:Ti.UI.FILL,//CHANGED THIS TO FILL INSTEAD OF Fill
					width:'2%',
					layout:'vertical'
				});
				
				//if(isOdd){
					var moreTop = false;
					var invisCircle = false;
					for(var i=0, iMax=ro.isiOS ? (ro.isiphonex ? 15 : 16) : 17; i<iMax; i++){
						moreTop = false;
						invisCircle = false;
						if(i==0) moreTop = true;
						if(i==0 || (i+1 == iMax)) invisCircle = true;
						middleBorder.add(circleView(moreTop, isOdd, invisCircle));
					}
				//}
				
				return middleBorder;
			}
			function addNewRow(GRP1, GRP2, isOdd){
				var stretchRowImg = function(GRPName){
					if(Ti.App.picklemansStyle){
						return GRPName != 'Coupons' && GRPName != 'My Rewards' && GRPName != 'Orders';
					}
					return false;
				};
				
				function createBtns(GRP){
					var rowView, rowImg, label;
					var imagePath = GRP.defImg?GRP.defImg:ro.ui.properties.defaultPath + 'default.png';
					var theRow = Ti.UI.createView({
						name:GRP.Name,
						hasBadge:GRP.IsLoyalty?true:false,
					   //backgroundImage:'/images/menuItemBg.png',
						//height:ro.ui.relY(120),
						//width:'48%'
						width:'48%',
						height:Ti.UI.FILL
					});
					
					rowView = Ti.UI.createView({
						name:GRP.Name,
						label:GRP.Name,
					    //backgroundImage:'/images/menuItemBg.png',
						height:Ti.UI.FILL,
						top:ro.ui.relY(3),
						bottom:ro.ui.relY(3),
						right:ro.ui.relX(1),
						left:ro.ui.relX(1),
						width:Ti.UI.FILL
					});
					
					/*backgroundImg = Ti.UI.createImageView({
						image:Ti.App.websiteURL+'/content/images/menu-item.png',
						defaultImage:'/images/menuItemBg.png',
						height: Ti.UI.FILL,
						width: Ti.UI.FILL,
						zIndex: -1000,
						touchEnabled: false,
						borderRadius:Ti.App.JETSDEMO ? ro.ui.relX(7) : null,
						borderColor:Ti.App.JETSDEMO ? ro.ui.theme.jetsdemo : null,
						borderWidth:Ti.App.JETSDEMO ? ro.ui.relX(1.5) : null
					});*/
					/*backgroundImg = Ti.UI.createImageView({
						image:Ti.App.websiteURL+'/content/images/menu-item.png',
						defaultImage:'/images/menuItemBg.png',
						height: Ti.UI.FILL,
						width: Ti.UI.FILL,
						zIndex: -1000,
						touchEnabled: false
					});*/
					//rowView.add(backgroundImg);
					
					var imgHolder = Ti.UI.createView({
						top:stretchRowImg(GRP.Name) ? ro.ui.relY(0) : ro.ui.relX(5),
					   //top:stretchRowImg(GRP.Name) ? ro.ui.relY(0) : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? ro.ui.relY(5) : ro.ui.relY(5)),//ro.ui.relY(20),
					   height:stretchRowImg(GRP.Name) ? ro.ui.relY(95) : '95%',
					   //height:stretchRowImg(GRP.Name) ? ro.ui.relY(95) : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? (GRP.Name == 'My Rewards' ? '80%' : '80%') : '80%'),//60/////87
					   width:stretchRowImg(GRP.Name) ? Ti.UI.FILL : '95%',
					   label:GRP.Name,
					   //borderColor:'green',
					   //borderWidth:3,
					   touchEnabled:false
					   //width:stretchRowImg(GRP.Name) ? Ti.UI.FILL : (GRP.Name == 'Coupons' || GRP.Name == 'My Rewards' || GRP.Name == 'Orders' ? (GRP.Name == 'My Rewards' ? '80%' : '80%') : '80%')
					});
					
					
					rowImg = Ti.UI.createImageView({
					    //borderColor:'purple',
					    //borderWidth:2,
						image:GRP.ImageSource,
						defaultImage:imagePath,
						label:GRP.Name,
						//width:Ti.UI.SIZE,
						//height:Ti.UI.SIZE
						//width:Ti.UI.FILL,
						left:ro.ui.relX(10),
						right:ro.ui.relX(10),
						bottom:ro.ui.relY(55),
						//bottom:ro.ui.relY(10)
						//height:Ti.UI.FILL
					});
					var gpNm = GRP.DisplayName || GRP.ReceiptName || GRP.Name;
					/*if(gpNm){
					   gpNm = gpNm.toUpperCase();
					}*/
					label = Ti.UI.createLabel({
						text:gpNm && gpNm.length ? gpNm.toUpperCase() : gpNm,
						width:Ti.UI.FILL,
						textAlign:'center',
						color:ro.ui.theme.newGroupsBtnTxt,
						font:{
							fontSize:ro.ui.scaleFontY(24,14),
							//fontWeight:'bold',
	            		     fontFamily:ro.ui.fonts.titles
						},
						touchEnabled:false,
						//top:ro.ui.relY(5),
						//height:Ti.UI.SIZE,
						bottom:ro.ui.relY(30)
					});
					
					if(false){
						imgHolder.height = ro.ui.relY(65);
						imgHolder.width = ro.ui.relY(105);
						label.bottom = ro.ui.relY(5);
						//label.color = ''
						rowView.layout = 'vertical';
						//label
						//label.
					}
					else{
						label.height = Ti.UI.SIZE;
					}
	
					rowView.addEventListener('click', function(ex){
						//Ti.API.debug('ex: ' + JSON.stringify(ex));
						Ti.App.grpIndex = ex.source.label;
						Ti.App.cpnGrpIndex = ex.source.label;
						ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
					});
	
					imgHolder.add(rowImg);
					rowView.add(imgHolder);
					rowView.add(label);
					theRow.add(rowView);
					//return rowView;
					
					if(GRP.IsLoyalty){
						theRow.badge = getBadge();
						theRow.add(theRow.badge);
						var newRow = theRow;
						newRow.hasBadge = true;
						theRow = newRow;
						newRow = null;
						//theRow.hasBadge = true;
						theRow.badge.setBadge();
					}
					
					return theRow;
				}
	
				var thisRow = Ti.UI.createView({
				    //borderColor:'green',
				    //borderWidth:2,
					layout:'horizontal',
					width:Ti.UI.FILL,
					backgroundColor: ro.ui.theme.menuItemRowColors.altBackground
				});
	
				var rowView = createBtns(GRP1);
				//rowView.left = ro.ui.relX(3);
				thisRow.add(rowView);
	
				var rowView1;
				if(GRP2){
					rowView1 = createBtns(GRP2);
					//rowView1.left = ro.ui.relX(10);
					var middleBorder = getMiddleBorder(isOdd);
					if(isOdd){
						//thisRow.backgroundColor = 'blue';
						thisRow.backgroundColor = ro.ui.theme.menuItemRowColors.background;//'#f6f6f6';
					}
					else{
					    
					}
					thisRow.add(middleBorder);
					thisRow.add(rowView1);
				}
				
				var tempRowHeight = ((ro.ui.displayCaps.platformWidth - ro.ui.relX(25)) / 2);
	            var rowHeight = ((ro.ui.displayCaps.platformWidth - ro.ui.relX(6)) / 2);
				grpRow = Ti.UI.createTableViewRow({
					selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
					height:tempRowHeight//ro.ui.relY(125)//,
					//width:Ti.UI.FILL
				});
				grpRow.add(thisRow);
				return grpRow;
			}
	
			var mainView = getMainView();
			/*var secondMainView = Ti.UI.createView({
				backgroundColor:'blue',
				height:Ti.UI.FILL,
				width:Ti.UI.FILL
			});
			mainView.add(secondMainView);*/
			setOrderObj();
	
			if(Ti.App.newMenu === 1){
				createRows(function(rows){
					var grpView, grpsTbl;
	
					grpView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
						height:Ti.UI.FILL,
						top:0
						//top:ro.ui.relY(50)
					}));
					grpsTbl = Ti.UI.createTableView({
						data:rows,
						height:Ti.UI.FILL,
						width:Ti.UI.FILL,
						top:ro.ui.relY(12),
						bottom:ro.ui.relY(12),
						right:ro.ui.relX(12),
						left:ro.ui.relX(12),
						separatorColor:ro.ui.theme.separatorColorMenuTypeOne,
						backgroundColor:ro.ui.theme.menuTableBgColor
					});
					grpsTbl.addEventListener('click', function(e){
						Ti.App.grpIndex = e.row.Name;
						Ti.App.cpnGrpIndex = e.row.Name;
						ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
					});
				   grpView.add(grpsTbl);
				   mainView.add(grpView);
				});
			}
			else{
				createNewRows(function(rows){
					var grpView, grpsTbl;
	
					var showCpnCode = menuUtils.hasValidCpnCode(ro.app.Store.Menu);
	
					grpView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
						height:Ti.UI.FILL,
						//top:showCpnCode ? ro.ui.relY(220) : ro.ui.relY(180),
						top:0,
						right:ro.ui.relX(3),
						left:ro.ui.relX(3)
					}));
					grpsTbl = Ti.UI.createTableView({
						//sdata:rows,
						height:Ti.UI.FILL,
						//width:Ti.UI.FILL,
						top:ro.ui.relY(6),
						bottom:ro.ui.relY(4),
						right:ro.ui.relX(4),
						left:ro.ui.relX(4),
						backgroundColor:'transparent',
						separatorColor:'transparent'
					});
					grpsTbl.appendRow(rows);
				   grpView.add(grpsTbl);
	
				   if(showCpnCode){
					   var cpnBigView = Ti.UI.createView({
					   	//top:ro.ui.relY(106),
					   	top:ro.ui.relY(10),
					   	//height:ro.ui.relY(117),//80
					   	height:Ti.UI.SIZE,
					   	width:Ti.UI.FILL,
					   	left:ro.ui.relX(10),//8
					   	right:ro.ui.relX(7),
					   	//layout:'vertical',
					   	//backgroundImage:'/images/menuItemBg.png'
					   });
					   /*var backgroundImg = Ti.UI.createImageView({
						image:Ti.App.websiteURL+'/content/images/menu-item.png',
						defaultImage:'/images/menuItemBg.png',
						height: Ti.UI.FILL,
						width: Ti.UI.FILL,
						zIndex: -1000,
						touchEnabled: false
					});
					var cpnViewHolder = Ti.UI.createView({
						layout:'vertical',
						height:Ti.UI.FILL,
						width:Ti.UI.FILL
					});
					cpnBigView.add(backgroundImg);
					cpnBigView.add(cpnViewHolder);*/
					
					   var txtView = Ti.UI.createView({
					   	   height:ro.ui.relY(40),
					   	   width:Ti.UI.FILL
					   });
	                   var cpnCodeTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'ENTER A COUPON CODE';
	                   var cpnCodeLittleTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'Coupon Code';
					   txtView.add(Ti.UI.createLabel({
    					   	text:cpnCodeTxt,
    					   	color:ro.ui.theme.newGroupsBtnTxt,
    				      	textAlign:'left',
    				      	left:ro.ui.relX(10),
    				      	width:Ti.UI.FILL,
    					   	font:{
    					   		fontSize:ro.ui.scaleFont(18),
    					   		fontWeight:'bold',
    					   		fontFamily:ro.ui.fontFamily
    					   	}
    				   }));
					   //cpnViewHolder.add(txtView);
					   var cpnView = Ti.UI.createView({
					   	top:ro.ui.relY(5),
					   	height:ro.ui.relY(40),
					   	width:Ti.UI.FILL,
					   	layout:'horizontal'
					   });
					   var cpnTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
    					   	left:ro.ui.relX(9),
    					   	width:'60%',
    					   	height:Ti.UI.FILL,
    					   	hintText:cpnCodeLittleTxt,
    					   	font: {
    					   		fontFamily:ro.ui.fonts.textFields,
                                fontSize: ro.ui.scaleFont(18)
                            },
                            backgroundColor:'#f6f6f6',
                            borderColor:'#cbcbcb',
                            hintTextColor:'#393839',
    					   	padding:{
    					   	    left:ro.ui.relX(9)
    					   	}
    				   }));
					   var cpnBtn = Ti.UI.createView({
					   	width:Ti.UI.FILL,
					   	height:Ti.UI.FILL,
					   	right:ro.ui.relX(15),
					   	left:ro.ui.relX(15),
					   	backgroundColor:ro.ui.theme.btnActive,
		      			borderColor:ro.ui.theme.btnActive,
		      			borderRadius:ro.ui.relX(20)
					   });
					   cpnBtn.add(Ti.UI.createLabel({
					   	text:'Apply',
					   	font:{
					   		//fontWeight:'bold',
					   		fontSize:ro.ui.scaleFont(20),
					   		fontFamily:ro.ui.fonts.button
					   	},
		      			color:ro.ui.theme.loginBtnWhite,
				      	textAlign:'center',
				      	touchEnabled:false
					   }));
					   cpnView.add(cpnTextBox);
					   cpnView.add(cpnBtn);
					   cpnBigView.add(cpnView);

                       var cpnBtnClickTime = 0;
					   cpnBtn.addEventListener('click', function(e){
                           if (new Date().getTime() - cpnBtnClickTime < 1000) {
                               Ti.API.info('returning');
                               return;
                           }
                           var thisClickTime = new Date();
                           cpnBtnClickTime = thisClickTime.getTime();
                           thisClickTime = null;

                           if (!cpnTextBox.value) {
					   	    	ro.ui.alert('Error','Please enter a valid coupon code');
					   	    	return;
					   	    }
	                  
	                        if(ro.REV_LOYALTY.isValidCode(cpnTextBox.value)){
	                           ro.REV_LOYALTY.validateCoupon(cpnTextBox.value, ro.app.Store.ID, function(newCode, LoyaltyCode){
	                                   menuUtils.testCpnCode(newCode, true, true, LoyaltyCode);
	                           }, false, false, function(){
	                               menuUtils.testCpnCode(cpnTextBox.value, true, false);//DYNAMIC CODE NOT FOUND FALLBACK
	                           });
	                        }
	                        else{
					         	   menuUtils.testCpnCode(cpnTextBox.value, true, false);
					         	}
					         });
	
					         mainView.add(cpnBigView);
					    }
					
					if(true){
						var specialView = Ti.UI.createView({
							layout:'horizontal',
							//top:showCpnCode ? ro.ui.relY(160) : ro.ui.relY(120),
							top:showCpnCode ? ro.ui.relY(10) : 0,
							height:ro.ui.relY(60),
							width:Ti.UI.FILL
						});
						var boxOne, boxTwo, boxThree;
						
						boxOne = Ti.UI.createView(ro.ui.properties.menuBox);
						boxTwo = Ti.UI.createView(ro.ui.properties.menuBox);
						boxThree = Ti.UI.createView(ro.ui.properties.menuBox);
							
							
						if(!isGuest && rs.PrevOrders && rs.PrevOrders.length){
	            			var storeObj = ro.app.Store;
		         			var dispName = 'My Orders';
		         			if(storeObj && storeObj.Configuration && storeObj.Configuration.MY_ORD_HDR && storeObj.Configuration.MY_ORD_HDR.length){
		         				dispName = storeObj.Configuration.MY_ORD_HDR;
		         			}
			   				
							var ordImg = Ti.UI.createImageView({
								//image:Ti.App.websiteURL + '/content/images/favorite.png',
								image:'/images/myOrders.png',
								//defaultImage:'/images/myOrders.png',
								height:ro.ui.relY(40),
								top:0
							});
							var ordTxt = Ti.UI.createLabel({
								text:dispName,
								top:0,
								color:ro.ui.theme.newGroupsBtnTxt,
								font:{
									fontWeight:'bold',
						   			fontSize:ro.ui.scaleFontY(14,14),
						   			fontFamily:ro.ui.fontFamily
								}
							});
							boxOne.add(ordImg);
							boxOne.add(ordTxt);
							boxOne.addEventListener('click', function(ex){
								Ti.App.grpIndex = "Orders";
								Ti.App.cpnGrpIndex = "Orders";
								ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
							});
						}
						
						ro.REV_LOYALTY.init();
				        ro.REV_LOYALTY.setCurrentLoyalty();
				        
				        var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
						
						////Ti.API.debug('currentLoyalty.isHC: ' + currentLoyalty.isHC);
						////Ti.API.debug('currentLoyalty.showHcTab(ro.app.Store.Configuration): ' + currentLoyalty.showHcTab(ro.app.Store.Configuration));
						////Ti.API.debug('currentLoyalty.showMenuGroup(): ' + currentLoyalty.showMenuGroup());
						if(currentLoyalty.isHC && currentLoyalty.showHcTab(ro.app.Store.Configuration) && currentLoyalty.showMenuGroup()){
							//Ti.API.debug('should Show menu rewards');
				         	var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
				         	var rewardsDisplayName = cfg.LTY_ACCT_HDR && cfg.LTY_ACCT_HDR.length ? cfg.LTY_ACCT_HDR : 'My Reward Account';
				         	var rewardNumLbl;
				         	var setBadge = function(){
								var curLty = ro.REV_LOYALTY.getCurrentLoyalty();
								if(curLty && curLty.isHC){
									curLty.getLtyCustomerDetails(Ti.App.Username, ro.app.Store.ID, function(e){
										var numRewards = e && e.Customers && e.Customers.length && e.Customers[0].Rewards && e.Customers[0].Rewards.length ? e.Customers[0].Rewards.length : 0;
										var newNumRewards = numRewards;
										for(var i=0,iMax=numRewards; i<iMax; i++){
											var itmCpnBreak = false, cpnBreak = false;
											if(e.Customers[0].Rewards[i].hasOwnProperty("RewardID") && e.Customers[0].Rewards[i].RewardID && e.Customers[0].Rewards[i].RewardID.length){
												for(var j=0, jMax=Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0; j<jMax; j++){
													if(Ti.App.OrderObj.Items[j].hasOwnProperty("CpnObj") && Ti.App.OrderObj.Items[j].CpnObj && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode.length && (Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode == e.Customers[0].Rewards[i].RewardID)){
														itmCpnBreak = true;
														newNumRewards--;
														break;
													}
												}
												if(!itmCpnBreak){
													for(var k=0, kMax=Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; k<kMax; k++){
														if(Ti.App.OrderObj.Cpns[k].LoyaltyCode && Ti.App.OrderObj.Cpns[k].LoyaltyCode.length && (Ti.App.OrderObj.Cpns[k].LoyaltyCode == e.Customers[0].Rewards[i].RewardID)){
															newNumRewards--;
															break;
														}
													}
												}
												
											}
										}
										if(newNumRewards){
											rewardNumLbl.text = newNumRewards;
										}
										else{
											rewardNumLbl.text = "0";
										}
										ro.ui.hideLoader();
									});
								}
							};
						
							var rewardVw = Ti.UI.createView({
								height:ro.ui.relY(40),
								top:0
							});
							rewardNumLbl = Ti.UI.createLabel({
								text:'0',
								textAlign:'center',
								color:'white',
								font:{
									fontSize:ro.ui.scaleFontY(17,14),//14
									//fontWeight:'bold',
						   			fontFamily:ro.ui.fonts.titles
								}
							});
							globalSetBadge = setBadge;
							globalSetBadge();
							//rewardNumLbl.setBadge();
							var rewardImg = Ti.UI.createImageView({
								//image:Ti.App.websiteURL + '/content/images/myltyaccount.png',
								image:'/images/myltyaccount.png',
								defaultImage:'/images/myltyaccount.png',
								height:ro.ui.relY(40),
								top:0
							});
							rewardVw.add(rewardImg);
							rewardVw.add(rewardNumLbl);
							
							var rewardTxt = Ti.UI.createLabel({
								text:rewardsDisplayName,
								height:ro.ui.relY(20),
								top:0,
								textAlign:'center',
								color:ro.ui.theme.newGroupsBtnTxt,
								font:{
									fontSize:ro.ui.scaleFontY(14,14),
									fontWeight:'bold',
						   			fontFamily:ro.ui.fontFamily
								}
							});
							boxTwo.add(rewardVw);
							boxTwo.add(rewardTxt);
							boxTwo.addEventListener('click', function(ex){
								Ti.App.grpIndex = "My Rewards";
								Ti.App.cpnGrpIndex = "My Rewards";
								ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
							});
						}
						
						
						
						if(menuUtils.hasDispCoupons()){
							var dealImg = Ti.UI.createImageView({
								//image:Ti.App.websiteURL + '/site/groupimages/tabs/deals.png',
								image:ro.ui.properties.defaultPath + 'myDeals.png',
								height:ro.ui.relY(40),
								//defaultImage:ro.ui.properties.defaultPath + 'myDeals.png',
								top:0
							});
							var dealTxt = Ti.UI.createLabel({
								text:'Deals',
								height:ro.ui.relY(20),
								top:0,
								textAlign:'center',
								color:ro.ui.theme.newGroupsBtnTxt,
								font:{
									fontSize:ro.ui.scaleFontY(14,14),
									fontWeight:'bold',
						   			fontFamily:ro.ui.fontFamily
								}
							});
							boxThree.add(dealImg);
							boxThree.add(dealTxt);
							boxThree.addEventListener('click', function(ex){
								Ti.App.grpIndex = "Coupons";
								Ti.App.cpnGrpIndex = "Coupons";
								ro.ui.ordShowNext({ addView:true, showing:'itemsView' });
							});
						}
						
						
						specialView.add(boxOne);
						specialView.add(boxTwo);
						specialView.add(boxThree);
						mainView.add(specialView);
					}
	
				   mainView.add(grpView);
				   mainView.tbl = grpsTbl;
				});
			}
	
			function chkFirstOLOrder(){
			   var CpnIdx;
	  		   Ti.App.firstOLOrdCpnExists = false;
	 		   for(CpnIdx=0; CpnIdx<ro.app.Store.Menu.Cpns.length; CpnIdx++){
				 	if(ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All'){
						if(ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER' || ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST MOBILE ORDER'){
							if(Ti.App.LastOrdCnt == 0){
								Ti.App.firstOLOrdCpnExists = true;
							}
							break;
						}
					}
			   }
			}
		   chkFirstOLOrder();
		   
		   function addFOLCoupon(coupon){
		   	   var storeObj = ro.app.Store;
	    	   var cpnObj = {};
	    	   var Ord = Ti.App.OrderObj;
	
	    	   if(!Ord.Cpns){
	    	      Ord.Cpns = [];
	    	   }
	
	    	   cpnObj.CpnValue = coupon.CpnValue;
	    	   cpnObj.RcptName = coupon.RcptName;
	    	   cpnObj.Name = coupon.Name;
	    	   cpnObj.CpnScope = coupon.CpnScope;
	    	   cpnObj.CpnType = coupon.CpnType;
	    	   cpnObj.CpnPct = coupon.CpnPct;
	    	   cpnObj.MinPrice = coupon.MinPrice;
	    	   cpnObj.MaxValue = coupon.MaxValue;
	    	   cpnObj.AdjItemPrice = coupon.AdjItemPrice;
	    	   cpnObj.TaxType = coupon.TaxType;
	    	   cpnObj.ReportGrp = coupon.ReportGrp;
	    	   cpnObj.FreeDlvy = coupon.FreeDlvy;
	    	   cpnObj.LeaveTax = coupon.LeaveTax;
	    	   cpnObj.No2ndItm = coupon.No2ndItm;
	    	   cpnObj.BeatClock = coupon.BeatClock;
	    	   var curDate = new Date();
	    	   var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
	    	   cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	    	   cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	    	   cpnObj.IsExclusive = coupon.IsExclusive;
	    	   cpnObj.MaxModValue = coupon.MaxModValue;
	    	   Ord.Cpns.push(cpnObj);
	    	   Ti.App.OrderObj = Ord;
	    	   //ro.ui.reloadCart();
	    	}
	
	    	function firstOnlineOrder(){
	    	   var storeObj = ro.app.Store;
	    	   var CpnIdx;
	    	   for(CpnIdx=0; CpnIdx<storeObj.Menu.Cpns.length; CpnIdx++){
	    	      if(storeObj.Menu.Name == storeObj.Menu.Cpns[CpnIdx].Menu || storeObj.Menu.Cpns[CpnIdx].Menu == 'All'){
	    	         if(storeObj.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER'){
	    	            addFOLCoupon(storeObj.Menu.Cpns[CpnIdx]);
	    	            Ti.App.firstOLOrdCpnApplied = true;
	    	            /*var firstOLOrder = Ti.UI.createAlertDialog();
	    	            firstOLOrder.title = 'FIRST ONLINE ORDER';
	    	            firstOLOrder.buttonNames = ['OK'];
	    	            firstOLOrder.message = storeObj.Menu.Cpns[CpnIdx].CpnDesc;
	    	             firstOLOrder.show();*/
	    	            ro.ui.popup('FIRST ONLINE ORDER', ['OK'], storeObj.Menu.Cpns[CpnIdx].CpnDesc, function(e) {
                            //win.close();
                        });
	    	            break;
	    	         }
	    	      }
	    	   }
	    	}
		   
			ro.cpnHelper.setCpnBool(false);
			var checkForBannerCode = function(){
				mainView.removeEventListener('postlayout', checkForBannerCode);
				
				if(Ti.App.firstOLOrdCpnExists && !Ti.App.firstOLOrdCpnApplied && !isGuest){
		          firstOnlineOrder();
		        }
		        else{
					
					var bannerCode = REV_BANNERS.getSelectedBannerCode(); 
					if(bannerCode && bannerCode.length){
						menuUtils.testCpnCode(bannerCode, true, false);
					}
					if(Ti.App.newMenu == 2 && currentLoyalty.isHC){
						var currCode = currentLoyalty.getTempCode();
						if(currCode && currCode.length){
							ro.REV_LOYALTY.validateCoupon(currCode, ro.app.Store.ID, function(){
				     			  ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
				     			  ro.ui.hideLoader();
				     		}, null, function(cpnCode, LoyaltyCode){
				     			menuUtils.testCpnCode(cpnCode, true, true, LoyaltyCode, function(msg){
				     				var title = 'Success!';
				     				ro.ui.alert(title, msg);
				     				
				     				globalSetBadge();
				     			});
				     		});
						}
					}
				}
				//var lty = ro.REV_LOYALTY.getCurrentLoyalty();
				/*if(Ti.App.newMenu == 2 && lty.isHC){
					ro.REV_LOYALTY.getCurrentLoyalty().getLtyCustomerDetails(Ti.App.Username, ro.app.Store.ID, function(e){
						Ti.API.debug('e: ' + JSON.stringify(e));
						var numRewards = e.Customers[0].Rewards && e.Customers[0].Rewards.length ? e.Customers[0].Rewards.length : 0;
						Ti.API.debug('mainView.tbl.data: ' + JSON.stringify(mainView.tbl.data));
						var row;
						for(var i=0, iMax=mainView.tbl.data[0].rows.length; i<iMax; i++){
							row = mainView.tbl.data[0].rows[i];
							
							if(row.hasBadge){
								Ti.API.debug('row['+i+']: ' + JSON.stringify(row));
								row.badge.setBadge(numRewards);
							}
						} 
					});
				}*/
				
			};
			mainView.addEventListener('postlayout', checkForBannerCode);
			var deepLinkFn = function(){
				Ti.API.info('attempting same page deep link 3');
				var bannerCode = REV_BANNERS.getSelectedBannerCode(); 
				if(bannerCode && bannerCode.length){
					menuUtils.testCpnCode(bannerCode, true, false);
				}
			};
			mainView.deepLink = deepLinkFn;
			
			ro.REV_STORES.setChosenStoreId(ro.app.Store.ID);
			return mainView;
		};
	};
	return {
		newgroupsview:newgroupsview
	};
}();
module.exports = NEWGROUPSVIEW;