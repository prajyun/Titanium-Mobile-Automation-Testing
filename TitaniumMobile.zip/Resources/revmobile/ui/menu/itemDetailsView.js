//WORK ON MOVING ALL OF THESE OUT OF THE GLOBAL SCOPE. THIS COULD BE THE CAUSE BEHIND POOR PERFORMANCE AND/OR CRASHES FROM DEV STORE.

var ITEMDETAILSVIEW = function() {
    var itemdetailsview = function(ro) {
        ro.ui.createItemDetailsView = function(_args) {
            try {
                var ITEMOBJ = require('logic/itemObj');
                ITEMOBJ.itemobj(ro);
                var itemObj;
                var scrollViewData = [],
                    group,
                    itemSelected,
                    Store,
                    Menu,
                    bottomTabView,
                    currentStyleRow;
                var menuUtils = require('logic/menuUtils');
                ro.ui.hideTabview();

                var cpnGuidedBool = ro.cpnHelper.isCpn();
                scrollViewData = [];
                var curPage = 0;
                var editItemNote = '';
                var editItemTempCpnKey = null;
                var editItemRealCpnKey = null;
                var showSwitchArrows = true;
                var itemNext,
                    itemAdd;

                if (ro.App.edit.editMode) {
                    showSwitchArrows = false;                    
                    cpnGuidedBool = false;
                    var itemToEdit = Ti.App.OrderObj.Items[ro.App.edit.editIndex];
                    if (itemToEdit.hasOwnProperty('CpnObj') && itemToEdit.CpnObj.CpnScope && itemToEdit.CpnObj.CpnScope == 2) {
                        if (itemToEdit.CpnObj.Key) {
                            ro.cpnHelper.findItem(itemToEdit.CpnObj.Key);
                            cpnGuidedBool = true;
                        }
                    }
                    editItemNote = itemToEdit.Notes && itemToEdit.Notes.length && itemToEdit.Notes[0].NoteText ? itemToEdit.Notes[0].NoteText : '';
                    editItemTempCpnKey = itemToEdit.tempCpnKey && itemToEdit.tempCpnKey.length ? itemToEdit.tempCpnKey : null;
                    editItemRealCpnKey = itemToEdit.realCpnKey && itemToEdit.realCpnKey.length ? itemToEdit.realCpnKey : null;
                    for (var i = 0; i < ro.app.Store.Menu.Groups.length; i++) {
                        if (itemToEdit.GroupName === ro.app.Store.Menu.Groups[i].Name) {
                            ro.app.group = ro.app.Store.Menu.Groups[i];
                            group = ro.app.group;
                            break;
                        }
                    }
                    for (var i = 0; i < group.Items.length; i++) {
                        if (itemToEdit.Name === group.Items[i].Name) {
                            ro.app.itemSelected = group.Items[i];
                            itemSelected = ro.app.itemSelected;
                            break;
                        }
                    }
                }
                else if (ro.App.sugg.suggMode) {
                    showSwitchArrows = false;
                    cpnGuidedBool = false;
                    group = ro.app.Store.Menu.Groups[ro.App.sugg.grpIndx];
                    itemSelected = ro.app.Store.Menu.Groups[ro.App.sugg.grpIndx].Items[ro.App.sugg.itmIndx];
                }
                else {
                    group = JSON.parse(JSON.stringify(ro.app.group));
                    itemSelected = ro.app.itemSelected;
                }

                if (cpnGuidedBool || group.length == 1) {
                    showSwitchArrows = false;
                }

                //step = 1;
                Menu = ro.app.Store.Menu;

                
                var noOptionView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
                    name: 'No Options',
                    height:Ti.UI.SIZE,
                    width:ro.ui.properties.wideViewWidth
                }));
                var noOptionLbl = Ti.UI.createLabel({
                    text: 'Click "Add To Cart" to add this item to the cart.',
                    font: {
                        fontSize: ro.ui.scaleFontY(14, 49),
                        fontWeight: 'bold',
                        fontFamily: ro.ui.fontFamily
                    },
                    textAlign: 'center',
                    width: ro.ui.relX(200),
                    height: ro.ui.relY(50),
                    color: ro.ui.theme.textColor
                });
                noOptionView.add(noOptionLbl); 


                var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                    name: cpnGuidedBool ? 'cpnDetails' : 'itemDetails',
                    hid: cpnGuidedBool ? 'cpnDetails' : 'itemDetails',
                    layout: 'vertical'
                }));
                var navBar = Ti.UI.createView(ro.ui.properties.navBar);

                function goBack() {
                    var itmName = itemSelected.DisplayName || itemSelected.ReceiptName || itemSelected.Name;
                    itmName = itmName ? itmName.toUpperCase() : itmName;

                    ro.ui.popup('Attention: ', ['Cancel', 'OK'], 'Current item will not be added to the cart', function(e) {
                        /*if (e.source.index === -1 || e.index === -1) {
                         return;
                         }

                         if (e.index === 1) {*/
                        if (ro.App.sugg.suggMode) {
                            ro.App.sugg.suggMode = false;
                            ro.App.sugg.grpIndx = null;
                            ro.App.sugg.itmIndx = null;
                            ro.App.sugg.SuggSizeName = null;
                            ro.App.sugg.SuggStyleName = null;
                            ro.ui.showCart();
                        }
                        else if (ro.App.edit.editMode) {
                            ro.App.edit.editMode = false;
                            ro.App.edit.editIndex = null;
                            ro.ui.showCart();
                        }
                        else {
                            ro.ui.ordShowNext({
                                showing: cpnGuidedBool ? 'cpnDetails' : 'itemDetails'
                            });
                        }
                        //}

                        ro.windowpopup.hideWindowpopup();
                    });

                }

                var backBtn = layoutHelper.getBackBtn();
                if (ro.App.edit.editMode) {
                    backBtn.addEventListener('click', function(e) {
                        ro.App.edit.editMode = false;
                        ro.App.edit.editIndex = null;
                        ro.ui.showCart();
                    });
                }
                else if (ro.App.sugg.suggMode) {
                    backBtn.addEventListener('click', function(e) {
                        ro.App.sugg.suggMode = false;
                        ro.App.sugg.grpIndx = null;
                        ro.App.sugg.itmIndx = null;
                        ro.App.sugg.SuggSizeName = null;
                        ro.App.sugg.SuggStyleName = null;
                        ro.ui.showCart();
                    });
                }
                else {

                    backBtn = layoutHelper.getBackBtn("Menu", null, true);
                    try {
                        backBtn.addEventListener('click', goBack);
                    }
                    catch(ex) {
                        Ti.API.debug('ex: ' + ex);
                    }
                }
                navBar.add(backBtn);
                //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                if(ro.isiphonex){
					var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
					var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
					var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
					navParent.add(topNav);
					bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
					navParent.add(bottomNav);
					mainView.add(navParent);
				}
				else{
					mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				}

                var itmString = '';
                var itmTtl = '';
                try {
                    itmTtl = itemSelected.DisplayName || itemSelected.ReceiptName || itemSelected.Name;
                    itmString = itemSelected.ItemDesc ? itemSelected.ItemDesc : '';
                }
                catch(ex) {
                    Ti.API.debug('itmString-Exception: ' + ex);
                }

                var allowItemNote = false;
                if (ro.app.Store.Configuration.AllowItemNote) {
                    allowItemNote = true;
                }
                //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));

                /*var displayView = layoutMenuHelper.setItemDisplay({
                 ttl:itmTtl,
                 text:itmString,
                 orderNote:allowItemNote ? 'Click to add special notes.' : '',
                 itemNote:editItemNote,
                 itemSelected:itemSelected
                 });
                 mainView.add(displayView);*/
                var scrollView = Ti.UI.createScrollView({
                    top: 0,
                    layout: 'vertical',
                    disableBounce: ro.isiOS ? true : false,
                    //width:ro.ui.displayCaps.platformWidth -2,
                    contentWidth: Ti.UI.FILL,
                    height: ro.isiOS ? (ro.isiphonex ? (ro.ui.displayCaps.platformHeight - ro.ui.relY(85) - (ro.ui.properties.topAfterNavbar)) : (ro.ui.displayCaps.platformHeight - ro.ui.relY(75) - (ro.ui.properties.topAfterNavbar))) : (ro.ui.displayCaps.platformHeight - ro.ui.relY(90) - (ro.ui.properties.topAfterNavbar))//,
                    //bottom:ro.ui.relY(55)
                    //borderColor:'red',
                    //borderWidth:2
                });
                if(ro.isiOS){
                	scrollView.width = ro.ui.displayCaps.platformWidth;
                }
                mainView.add(scrollView);

                //TOP SWITCH VIEW ARROWS AND PIZZA IMAGE
                var topView = Ti.UI.createView({
                    layout: 'horizontal',
                    height: ro.isiphonex ? ((ro.ui.displayCaps.platformHeight - ro.ui.relY(50)) / 5) : ro.ui.displayCaps.platformHeight / 4,
                    width: Ti.UI.FILL,
                    top: ro.ui.relY(0)//,
                    //borderColor:'green',
                    //borderWidth:2
                });
                if(ro.isiOS){
                	topView.left = ro.ui.relX(15);
                	topView.right = ro.ui.relX(15);
                }
                var topLeftView,
                    topRightView,
                    topMiddleView;
                topLeftView = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: ro.isiOS ? (ro.ui.displayCaps.platformWidth - ro.ui.relX(30))* .12 : ro.ui.displayCaps.platformWidth * .13
                });
                topRightView = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: ro.isiOS ? (ro.ui.displayCaps.platformWidth - ro.ui.relX(30))* .12 : ro.ui.displayCaps.platformWidth * .13
                });
                topMiddleView = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: ro.isiOS ? (ro.ui.displayCaps.platformWidth - ro.ui.relX(30)) * .72 : ro.ui.displayCaps.platformWidth * .74
                });
                topView.add(topLeftView);
                topView.add(topMiddleView);
                topView.add(topRightView);

                var itemImageView = Ti.UI.createImageView({
                    image: itemSelected.ImageSource,//'https://hhtraining.hungerrush.com/site/MenuItemImage/create.png',//itemSelected.ImageSource,//'https://hhtraining.hungerrush.com/site/MenuItemImage/create.png',
                    left: ro.isiOS ? null : ro.ui.relX(10),
                    right: ro.isiOS ? null : ro.ui.relX(10),
                    height: '100%'
                    //left: ro.ui.relX(10),
                    //right: ro.ui.relX(10),
                    //borderColor:'brown',
                    //borderWidth:2
                });
                topMiddleView.add(itemImageView);
                var newItemIndex;
                if (showSwitchArrows) {
                    topLeftView.add(Ti.UI.createImageView({
                        image: '/images/leftArrow.png'
                    }));
                    topRightView.add(Ti.UI.createImageView({
                        image: '/images/rightArrow.png'
                    }));
                    topRightView.addEventListener('click', function() {
                        
                        ro.ui.popup('Attention: ', ['Cancel', 'OK'], 'Current item will not be added to the cart', function(e) {
                            for (var i = 0, iMax = group.Items.length; i < iMax; i++) {
                                if (itemSelected.Name === group.Items[i].Name) {
                                    newItemIndex = ((i + 1 == group.Items.length) ? 0 : (i + 1));
    
                                    ro.app.itemSelected = group.Items[newItemIndex];
                                    ro.ui.ordShowNext({
                                        addView: true,
                                        showing: 'itemDetails'
                                    });
                                    break;
                                }
                            }
                            ro.windowpopup.hideWindowpopup();
                         });
                        
                        
                    });
                    topLeftView.addEventListener('click', function() {
                        
                        ro.ui.popup('Attention: ', ['Cancel', 'OK'], 'Current item will not be added to the cart', function(e) {
                            for (var i = 0, iMax = group.Items.length; i < iMax; i++) {
                                if (itemSelected.Name === group.Items[i].Name) {
                                    newItemIndex = (i == 0 ? group.Items.length - 1 : (i - 1));
    
                                    ro.app.itemSelected = group.Items[newItemIndex];
                                    ro.ui.ordShowNext({
                                        addView: true,
                                        showing: 'itemDetails'
                                    });
                                    break;
                                }
                            }
                            ro.windowpopup.hideWindowpopup();
                         });
                        
                        
                    });
                }
                scrollView.add(topView);
                //TOP SWITCH VIEW ARROWS AND PIZZA IMAGE

                //DESCRIPTION VIEW

                var middleView = Ti.UI.createView({
                    layout: 'vertical',
                    //height:ro.ui.displayCaps.platformHeight * .25,
                    height: Ti.UI.SIZE,
                    width: Ti.UI.FILL
                });
                var hdrLblView,
                    descriptionLblView,
                    hdrLbl,
                    descriptionLbl;
                hdrLblView = Ti.UI.createView({
                    //height:'30%',
                    left:ro.ui.relX(15),
                    height: Ti.UI.SIZE,
                    width:ro.ui.properties.wideViewWidth + ro.ui.relX(5)
                });
                descriptionLblView = Ti.UI.createView({
                    //height:Ti.UI.FILL,
                    top: ro.ui.relY(5),
                    height: Ti.UI.SIZE,
                    left:ro.ui.relX(15),
                    width: ro.ui.properties.wideViewWidth + ro.ui.relX(5),
                    //borderColor:'blue',
                    //borderWidth:2
                });

                hdrLblView.add(Ti.UI.createLabel({
                    text: itmTtl,
                    textAlign: 'left',
                    left: ro.ui.relX(0),
                    color: ro.ui.theme.backgroundpngTxt,
                    font: {
                        fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(28),
                        //fontWeight:'bold'
                    }
                }));

                descriptionLblView.add(Ti.UI.createLabel({
                    color: '#393839',
                    text: itmString,
                    textAlign: 'left',
                    left: ro.ui.relX(0),
                    right: ro.ui.relX(0),
                    top: 0,
                    font: {
                        fontFamily: ro.ui.fonts.rowBodyTxt,
                        fontSize: ro.ui.scaleFont(15)
                    }
                }));

                middleView.add(hdrLblView);
                middleView.add(descriptionLblView);

                scrollView.add(middleView);
                //DESCRIPTION VIEW

                //TABS
                var tempTabView = Ti.UI.createView({
                    height: ro.ui.relX(50),
                    width: Ti.UI.FILL,
                    pageIdx: 0,
                    toggle: function() {

                    }

                });
                scrollView.add(tempTabView);
                //TABS

                //SCROLLABLE ITEM OPTIONSVIEW
                var scrollableView = Ti.UI.createView({
                    //showPagingControl:true,
                    height: Ti.UI.SIZE,
                    //height:ro.ui.relY(200),
                    top: 0,
                    //bottom:ro.isiOS ? null : ro.ui.relY(5),
                    right: 0, //ro.ui.relX(5),
                    left: 0, //ro.ui.relX(5),
                    PrevsViewIdx: 0//,
                    //clipViews:ro.isiOS ? true : null
                });
                scrollView.add(scrollableView);
                //SCROLLABLE ITEM OPTIONSVIEW
                var bottomTabView = getBottomBar();

                function formScrollViewData(_callback) {
                    function getSzs(szCol) {
                        var availableSz = itemSelected.AvailableSizes;
                        var finalSzs = [],
                            skipBool = false;
                        for (var i = 0; i < szCol.length; i++) {
                            for (var j = 0; j < availableSz.length; j++) {
                                //.replace(/ /g,'')
                                if (szCol[i].Name === availableSz[j].Name || szCol[i].Name.replace(/ /g, '') === availableSz[j].Name.replace(/ /g, '')) {
                                    finalSzs.push(availableSz[j]);
                                    break;
                                }
                            }
                        }

                        if (!finalSzs.length) {
                            skipBool = true;
                        }
                        return {
                            skipRow: skipBool,
                            szs: finalSzs
                        };
                    }

                    var tabCol = [],
                        selectedTabBool = false;
                    if (group.HasStyles && group.Styles && group.Styles.length && group.HasSizes && group.Sizes && group.Sizes.length) {
                        //Ti.include('/revmobile/ui/stylesView.js');
                        var STYLEVIEW = require('revmobile/ui/stylesView');

                        includeTracker.Style = true;
                        //scrollViewData.push(styleView);
                        scrollViewData.push(STYLEVIEW.getStylesView(group, itemSelected, scrollRight));
                        var ttl;
                        if (group.HasSizes) {
                            ttl = 'Style/Size';
                        }
                        else {
                            ttl = 'Style';
                        }
                        tabCol.push({
                            btnTitle: ttl,
                            btnClr: ro.ui.theme.btnActive,
                            btnTxt: ro.ui.theme.btnTxtActive
                        });
                        selectedTabBool = true;
                        //Ti.API.debug('styles/size');
                    }
                    else {
                        if (group.HasSizes && (!group.HasStyles || !group.Styles || !group.Styles.length)) {
                            //Ti.include('/revmobile/ui/sizesView.js');
                            includeTracker.Size = true;

                            var SIZESVIEW = require('revmobile/ui/sizesView');

                            scrollViewData.push(SIZESVIEW.getNewSizesView(group, itemSelected, scrollRight));

                            tabCol.push({
                                btnTitle: 'Sizes',
                                btnClr: ro.ui.theme.btnActive,
                                btnTxt: ro.ui.theme.btnTxtActive
                            });
                            selectedTabBool = true;
                            //Ti.API.debug('size');
                        }
                    }

                    if (!group.HasSizes) {
                        ro.itemObj.setNoSizes();
                    }
                    if (itemSelected.HasPrefs && itemSelected.Prefs && itemSelected.Prefs.length) {
                        var bg = 'transparent';
                        var txtClr = ro.ui.theme.btnTxtDefault;
                        if (!selectedTabBool) {
                            bg = ro.ui.theme.btnActive;
                            txtClr = ro.ui.theme.btnTxtActive;
                            selectedTabBool = true;
                        }
                        //Ti.include('/revmobile/ui/prefs.js');

                        var PREFVIEW = require('revmobile/ui/prefs');
                        //scrollViewData.push(PREFVIEW.getPrefsView(group, itemSelected));
                       // setTimeout(function(){
                        	scrollViewData.push(PREFVIEW.newgetPrefsView(group, itemSelected));
                        //}, 1500);
                        

                        includeTracker.Prefs = true;
                        tabCol.push({
                            btnTitle: 'Preferences',
                            btnClr: bg,
                            btnTxt: txtClr
                        });
                        //Ti.API.debug('prefs');
                    }

                    if (itemSelected.HasReqMods && (itemSelected.ReqMods && itemSelected.ReqMods.length > 0) && (group.Mods && group.Mods.length > 0)) {
                        try {
                            var checkGrpForMods = function(mKey){
                                if(group.Mods && group.Mods.length){
                                    for(var i = 0; i < group.Mods.length; i++){
                                        if(group.Mods[i].ModCatKey == mKey){
                                            return true;
                                        }
                                    }
                                }
                                return false;
                            }
                            var REQMODSVIEW = require('revmobile/ui/reqMods_new');
                            //scrollViewData.push(PREFVIEW.getPrefsView(group, itemSelected));

                            includeTracker.RqMods = itemSelected.ReqMods.length;
                            //Ti.include('/revmobile/ui/reqMods_new.js');
                            for (var i = 0; i < itemSelected.ReqMods.length; i++) {
                                var bg = 'transparent';
                                var txtClr = ro.ui.theme.btnTxtDefault;
                                if (!selectedTabBool) {
                                    bg = ro.ui.theme.btnActive;
                                    txtClr = ro.ui.theme.btnTxtActive;
                                    selectedTabBool = true;
                                }
                                var modKey = !isNaN(itemSelected.ReqMods[i].Key) ? itemSelected.ReqMods[i].Key : itemSelected.ReqMods[i];
                                var modCatIdx = ro.utils.getMatchingIdx(modKey, Menu.ModCategories, 'Key');
                                //Check if mods exist in the group
                                if(checkGrpForMods(modKey)){
                                    tabCol.push({
                                        btnTitle: Menu.ModCategories[modCatIdx].Name,
                                        btnClr: bg,
                                        btnTxt: txtClr
                                    });
                                }
                            }
                           	var rModViews = REQMODSVIEW.getNewReqModsView(group, itemSelected);
	                        for(var x=0, xMax=rModViews.length; x<xMax; x++){
                                if(checkGrpForMods(rModViews[x].reqModKeys)){
	                        	    scrollViewData.push(rModViews[x]);
                                }
	                        }                            
                        }
                        catch(ex) {
                            Ti.API.debug("includeTracker.ReqMods - Exception: " + ex);
                        }
                    }

                    if (group.HasMods) {
                        try {
                            var grpMdLength = group.Mods && group.Mods.length ? group.Mods.length : 0;
                            var showMods = false;
                            for (var b = 0; b < grpMdLength; b++) {
                                if (menuUtils.isModValid(group.Mods[b], null)) {
                                    showMods = true;
                                    break;
                                }
                            }
                            if (showMods) {
                                //Ti.API.debug('tabCol: ' + JSON.stringify(tabCol));
                                var bg = 'transparent';
                                var txtClr = ro.ui.theme.btnTxtDefault;
                                if (!selectedTabBool) {
                                    bg = ro.ui.theme.btnActive;
                                    txtClr = ro.ui.theme.btnTxtActive;
                                    selectedTabBool = true;
                                }
                                //Ti.include('/revmobile/ui/mods_new.js');

                                var MODSVIEW = require('revmobile/ui/mods_new');

                                includeTracker.Mods = true;

                                //scrollView.add(getModsView());
                               	//setTimeout(function(){
		                        
	                                var mdView = MODSVIEW.getModsView(group, itemSelected, null, function(modView) {
	                                    //Ti.API.debug('Callback');
	                                    //Ti.API.debug('scrollViewData.length: ' + scrollViewData.length);
	                                    scrollViewData.push(modView);
	
	                                    //scrollableView.views = scrollViewData;
	                                }, null, null, ro.App.edit.editMode ? true : false, cpnGuidedBool ? true : false);
	                                scrollViewData.push(mdView);
                                
                               // }, 1500);

                                tabCol.push({
                                    btnTitle: 'Toppings',
                                    btnClr: bg,
                                    btnTxt: txtClr
                                });
                                //Ti.API.debug('tabCol: ' + JSON.stringify(tabCol));

                            }
                        }
                        catch(ex) {
                            Ti.API.debug('group.HasMods - Exception: ' + ex);
                        }
                    }

                    if (tabCol && tabCol.length > 0) {
                        getTabView(tabCol, function(tabView/*, underlay*/) {
                            tempTabView.add(tabView);
                            tempTabView.toggle = tabView.toggle;

                            for (var i = 0, iMax = scrollViewData.length; i < iMax; i++) {
                                scrollViewData[i].pageIdx = i;
                            }
                            //scrollableView.scrollViewData = scrollViewData;
                            //scrollableView.add(scrollableView.scrollViewData[0]);
                            scrollableView.add(scrollViewData[0]);

                            if (scrollViewData.length == 1) {
                                bottomTabView.toggleBtn();
                            }
                            //tempTabView.add(underlay);
                        });
                    }

                    if (scrollViewData.length == 0) {
                        scrollViewData.push(noOptionView);
                        scrollableView.add(scrollViewData[0]);
                        bottomTabView.toggleBtn();
                    }

                    //scrollableView.views = scrollViewData;

                    switch(scrollViewData.length) {
                        case 0:
                            scrollViewData.push(noOptionView);
                            //scrollableView.views = scrollViewData;
                            break;
                        case 1:
                            break;
                        default:
                            break;
                    }

                    if (scrollViewData.length > 1) {

                    }
                    //_callback();
                    if (cpnGuidedBool || ro.App.edit.editMode || ro.App.sugg.suggMode) {
                        setTimeout(function(){
                        _callback();
                        }, 100);
                    }
                    else {
                        ro.ui.hideLoader();
                    }
                }

                var includeTracker = {
                    Size: false,
                    Style: false,
                    Prefs: false,
                    Mods: false,
                    RqMods: false
                };
                ////Ti.API.debug('itemSelected: ' + JSON.stringify(itemSelected));
                ro.itemObj.InitializeItemObj();
                formScrollViewData(function(e) {
                    try {
                        if (cpnGuidedBool) {
                            var isPickReq = ro.cpnHelper.isPickAnyCpn();
                            if (includeTracker.Size) {
                                
                                if (isPickReq) {
                                    // Had to overwrite this fucniton to work properly with non pick any with req cases
                                    //var ItemSize = ro.cpnHelper.getPickSize();                                    
                                    var ItemSize = ro.cpnHelper.getItemSize(group.Name, itemSelected.Name);
                                    scrollViewData[0].reloadCpnSelections(ro.cpnHelper.chosenSize(), ItemSize);                                    
                                }
                                else {
                                    var cpon = ro.cpnHelper.getSelectedCpn();
                                    var ItemSize;
                                    if (cpon.Items) {
                                        var cponIdx = Ti.App.Cpon;
                                        if (cpon.Items[cponIdx].MenuSize !== "All") {
                                            ItemSize = cpon.Items[cponIdx].MenuSize;
                                        }
                                    }
                                    scrollViewData[0].reloadCpnSelections(ro.cpnHelper.chosenSize(), ItemSize);
                                }
                            }

                            if (includeTracker.Style) {                                
                                if (isPickReq) {
                                    // Well I tried to fix the way the old way works, but couldn't so wrote a new function to make it work
                                    //var ItemSize = ro.cpnHelper.getPickSize();
                                    var ItemSize = ro.cpnHelper.getItemSize(group.Name, itemSelected.Name);
                                    Ti.API.info('ItemSize: ' + ItemSize);
                                    ItemSize = ItemSize.split("__");
                                    Ti.API.info('ItemSize: ' + ItemSize);
                                    var ItemSty = ro.cpnHelper.getPickStyle();
                                    Ti.API.info('ItemSty: ' + ItemSty);
                                    scrollViewData[0].reloadCpnSelections(ro.cpnHelper.chosenStyle(), ItemSize, true);
                                }
                                else {
                                    var cpon = ro.cpnHelper.getSelectedCpn();
                                    var ItemSize;
                                    if (cpon.Items) {
                                        var cponIdx = Ti.App.Cpon;
                                        if (cpon.Items[cponIdx].MenuSize !== "All") {
                                            ItemSize = cpon.Items[cponIdx].MenuSize;
                                        }
                                    }
                                    scrollViewData[0].reloadCpnSelections(ro.cpnHelper.chosenStyle(), ItemSize);
                                }
                            }

                            if (includeTracker.Prefs) {
                                for (var i = 0, iMax = scrollViewData.length; i < iMax; i++) {
                                    if (scrollViewData[i].isPrefView) {
                                        scrollViewData[i].reloadCpnSelections(ro.cpnHelper.chosenPrefs());
                                        break;
                                    }
                                }
                            }

                            if (includeTracker.Mods) {
                                scrollViewData[scrollViewData.length - 1].cpnEdit();
                            }

                            if (includeTracker.RqMods) {
                                var reqModCounts = 0;
                                for (var i = 0, iMax = scrollViewData && scrollViewData.length ? scrollViewData.length : 0; i < iMax; i++) {
                                    if (scrollViewData[i].isReqModView) {//TODO TODO TODO
                                        scrollViewData[i].reloadCpnSelections(reqModCounts);
                                        reqModCounts++;
                                    }
                                }
                            }
                        }
                        if (ro.App.edit.editMode) {
                            if (includeTracker.Size) {
                                scrollViewData[0].reloadSelections(itemToEdit.Size);
                            }

                            if (includeTracker.Style) {
                                scrollViewData[0].reloadSelections(itemToEdit.Style, itemToEdit.Size ? itemToEdit.Size : null);
                            }

                            if (includeTracker.Prefs) {
                                
                                for (var i = 0, iMax = scrollViewData && scrollViewData.length ? scrollViewData.length : 0; i < iMax; i++) {
                                    if (scrollViewData[i].isPrefView) {
                                        scrollViewData[i].reloadSelections(itemToEdit.PrfMbrs);
                                        break;
                                    }
                                }
                            }

                            if (includeTracker.Mods) {
                                
                                scrollViewData[scrollViewData.length - 1].edit(itemToEdit.Mods, itemToEdit.NoMods);
                                
                            }

                            if (includeTracker.RqMods) {
                                var reqModCounts = 0;
                                for (var i = 0, iMax = scrollViewData && scrollViewData.length ? scrollViewData.length : 0; i < iMax; i++) {
                                    if (scrollViewData[i].isReqModView) {
                                        scrollViewData[i].reloadSelections(itemToEdit.Mods, reqModCounts, scrollViewData[i]);
                                        reqModCounts++;
                                    }
                                }
                            }
                        }
                        if (ro.App.sugg.suggMode) {
                            ////Ti.API.debug('ro.App.sugg.SuggStyleName: ' + ro.App.sugg.SuggStyleName);
                            if (!ro.App.sugg.SuggStyleName) {
                                ro.App.sugg.SuggStyleName = 'all';
                            }
                            ////Ti.API.debug('ro.App.sugg.SuggSizeName: ' + ro.App.sugg.SuggSizeName);
                            if (!ro.App.sugg.SuggSizeName) {
                                ro.App.sugg.SuggSizeName = 'all';
                            }
                            if (includeTracker.Size) {
                                //reloadSizes(itemToEdit.Size);
                                if (ro.App.sugg.SuggSizeName && ro.App.sugg.SuggSizeName.length) {
                                    scrollViewData[0].reloadSuggs(ro.App.sugg.SuggSizeName, group, itemSelected);
                                    //Ti.API.debug('ro.App.sugg.SuggSizeName: ' + ro.App.sugg.SuggSizeName);
                                }
                            }
                            if (includeTracker.Style) {
                                if (ro.App.sugg.SuggStyleName && ro.App.sugg.SuggStyleName.length) {
                                    //Ti.API.debug('ro.App.sugg.SuggStyleName: ' + ro.App.sugg.SuggStyleName);
                                    scrollViewData[0].reloadSuggs(ro.App.sugg.SuggStyleName, ro.App.sugg.SuggSizeName, group, itemSelected);
                                }
                            }
                        }
                        ro.ui.hideLoader();
                    }
                    catch(ex) {
                        
                            Ti.API.info('itemDetailsView.js-RefillingSpecificItem-Exception: ' + ex);
                        
                    }
                });
                function shouldIScroll(currPg) {
                    var returnBool = true;
                    //Ti.API.debug('scrollableView.PrevsViewIdx: ' + scrollableView.PrevsViewIdx);
                    if (scrollableView.children[0].pageIdx === currPg) {
                        return false;
                    }
                    else if (scrollableView.children[0].pageIdx > currPg) {

                    }
                    else {
                        for (var i = scrollableView.children[0].pageIdx; i < currPg; i++) {
                            if (scrollViewData[i].testRequired) {
                                if (scrollViewData[i].itemTest(ro.itemObj.getItemObj(), scrollViewData[i].testIndex)) {

                                }
                                else {
                                    return false;
                                }
                            }
                        }
                    }
                    return true;
                }

                function scrollLeft() {
                    try {
                        var currPage = scrollableView.children[0].pageIdx;
                        if (scrollableView.children[0].pageIdx === 0) {
                            return;
                        }
                        ro.ui.showLoader();
                        //scrollableView.setCurrentPage(scrollableView.pageIdx-1);
                        scrollableView.removeAllChildren();
                        tempTabView.toggle(currPage - 1);
                        //scrollableView.add(scrollableView.scrollViewData[currPage - 1]);
                        scrollableView.add(scrollViewData[currPage - 1]);

                        if (currPage + 1 == scrollViewData.length) {
                            bottomTabView.toggleBtn();
                        }
                        ro.ui.hideLoader();

                    }
                    catch(ex) {
                        Ti.API.debug('scrollLeft()-Exception: ' + ex);
                    }
                }

                function scrollRight() {
                    try {
                    	   
                        var currPage = scrollableView.children[0].pageIdx;
                        if (currPage === (scrollViewData.length - 1)) {
                            return;
                        }
                        ro.ui.showLoader();
                        scrollableView.removeAllChildren();
                        tempTabView.toggle(currPage + 1);
                        //scrollableView.add(scrollableView.scrollViewData[currPage + 1]);
                        scrollableView.add(scrollViewData[currPage + 1]);

                        if (scrollableView.children[0].pageIdx == scrollViewData.length - 1) {
                            bottomTabView.toggleBtn();
                        }
                        ro.ui.hideLoader();
                        //scrollableView.setCurrentPage(scrollableView.pageIdx+1);
                    }
                    catch(ex) {
                        Ti.API.debug('scrollRight()-Exception: ' + ex);
                    }
                }

                function getTabView(tabsCol, tabViewCallback) {
                    var tabVw = Ti.UI.createView({
                        height: ro.ui.relY(50),
                        width: Ti.UI.SIZE,
                        pageIdx: 0,
                        layout: 'horizontal',
                        zIndex: 20
                    });

                    var numTabs = tabsCol.length,
                        tbWidth = Math.floor((100 / numTabs) - .25) + '%',
                        tab,
                        tabDividerWidth = Math.floor(100 / numTabs) + '%';
                    var fontSiz = ro.ui.scaleFont(14);
                    //(numTabs > 3)?ro.ui.scaleFont(9):ro.ui.scaleFont(10);
                    for (var i = 0; i < numTabs; i++) {
                        //Ti.API.debug('tabsCol['+i+']: ' + JSON.stringify(tabsCol[i]));
                        if ((i + 1) < numTabs) {

                        }
                        tab = null;
                        var tabLeft = i ? ro.ui.relX(5) : 0;
                        tab = Ti.UI.createView({
                            height: ro.ui.relY(30),
                            top: ro.ui.relX(10),
                            width: Ti.UI.SIZE, //ro.ui.relX(90),
                            borderRadius: ro.ui.relX(15),
                            borderColor: !i ? ro.ui.theme.toptbSelBg : '#e4e4e4',
                            borderWidth: ro.ui.relX(2),
                            backgroundColor: !i ? ro.ui.theme.toptbSelBg : ro.ui.theme.toptbBg,
                            left: tabLeft,
                            idx: i,
                            origText: ro.isiOS ? ("" + tabsCol[i].btnTitle + "    ") : ("  " + tabsCol[i].btnTitle + "  ")
                        });
                        tab.add(Ti.UI.createLabel({
                            height: Ti.UI.SIZE,
                            text: ro.isiOS ? ("" + tabsCol[i].btnTitle + "    ") : ("  " + tabsCol[i].btnTitle + "  "),
                            textAlign: 'center',
                            font: {
                                fontSize: fontSiz,
                                fontFamily: !i ? ro.ui.fonts.tabs.on : ro.ui.fonts.tabs.off
                            },
                            color: !i ? ro.ui.theme.toptbSelTxt : ro.ui.theme.toptbTxt,
                            idx: i
                        }));
                        function changeLbl(theTab, isSelected) {
                            
                            var newLbl = Ti.UI.createLabel({
                                height: Ti.UI.SIZE,
                                text: theTab.origText,
                                textAlign: 'center',
                                font: {
                                    fontSize: fontSiz,
                                    fontFamily: isSelected ? ro.ui.fonts.tabs.on : ro.ui.fonts.tabs.off
                                },
                                color: isSelected ? ro.ui.theme.toptbSelTxt : ro.ui.theme.toptbTxt,
                                idx: theTab.idx
                            });
                            theTab.removeAllChildren();
                            theTab.add(newLbl);
                            //theTab.children[0] = newLbl;

                        }

                        function toggle(newIdx) {
                            var currIdx = tabVw.pageIdx;
                            
                            

                            changeLbl(tabVw.children[newIdx], true);
                            tabVw.children[newIdx].backgroundColor = ro.ui.theme.toptbSelBg;
                            tabVw.children[newIdx].borderColor = ro.ui.theme.toptbSelBg;
                            //!i ? ro.ui.theme.toptbSelBg : '#e4e4e4'
                            //tabVw.children[newIdx].children[0].color = ro.ui.theme.toptbSelTxt;
                            
                            //tabVw.children[newIdx].children[0].font.fontFamily = ro.ui.fonts.tabs.on;
                            //tabVw.children[newIdx].children[0].font.fontWeight = 'bold';
                            
                            changeLbl(tabVw.children[currIdx], false);
                            tabVw.children[currIdx].backgroundColor = ro.ui.theme.toptbBg;
                            tabVw.children[currIdx].borderColor = '#e4e4e4';
                            //tabVw.children[currIdx].children[0].color = ro.ui.theme.toptbTxt;
                            
                            //tabVw.children[currIdx].children[0].font.fontFamily = ro.ui.fonts.tabs.off;
                            //tabVw.children[currIdx].children[0].font.fontWeight = 'normal';
                            tabVw.pageIdx = newIdx;
                        }


                        tabVw.toggle = toggle;
                        tab.addEventListener('click', function(e) {
                            //var curPg = scrollableView.getCurrentPage();
                            var curPg = scrollableView.children[0].pageIdx;
                            var scrollBool = shouldIScroll(e.source.idx);
                            if (!scrollBool) {
                                return;
                            }

                            if (e.source.idx === curPg) {
                                return;
                            }
							ro.ui.showLoader();
                            if ((curPg == scrollViewData.length - 1) || (e.source.idx == scrollViewData.length - 1)) {
                                bottomTabView.toggleBtn();
                            }

                            toggle(e.source.idx);

                            e.source.selected = true;

                            scrollableView.removeAllChildren();
                            //scrollableView.add(scrollableView.scrollViewData[e.source.idx]);
                            scrollableView.add(scrollViewData[e.source.idx]);
							ro.ui.hideLoader();
                        });
                        tabVw.add(tab);
                        
                    }
                    function fixTabs(){
                        //Ti.API.debug('tabVw.children.length: ' + tabVw.children.length);
                        //Ti.API.debug('tabVw.children[0]: ' + JSON.stringify(tabVw.children[0]));
                        /*for(var props in tabVw.children[0]){
                            Ti.API.debug('tabVw.children[0]['+props+']: ' + JSON.stringify(tabVw.children[0][props]))
                        }*/
                       for(var i=0, iMax=tabVw.children.length; i<iMax; i++){
                           //Ti.API.debug('tabVw.children['+i+'].size.width: ' + tabVw.children[i].size.width);
                           tabVw.children[i].width = tabVw.children[i].size.width;
                       }
                    }
                    tabVw.fixTabs = fixTabs;
                    tabViewCallback(tabVw/*, tabVwUnderlay*/);
                }

                function getBottomBar() {
                	var fullBottomDict = {
                        width: Ti.UI.FILL,
                        top: ro.ui.relY(10),
                        layout: 'vertical',
                        
                    };
                    var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
                    var fullView = Ti.UI.createView(fullBottomDict);
                    fullView.add(greyBar);
                    var bottomTabDict = {
                        width: Ti.UI.FILL,
                        top: 0,
                        layout: 'horizontal'
                    };
                    var bottomBtnWidth = ro.ui.displayCaps.platformWidth / 3;
                    if (!ro.isiOS) {
                        bottomTabDict.height = Ti.UI.FILL;
                    }
                    
                    var botTabView = Ti.UI.createView(bottomTabDict);

                    //return botTabView;
                    var itemBack,
                        itemCancel;
                    itemBack = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: bottomBtnWidth,
                        backgroundColor: ro.ui.theme.menuBtnBackground,
                        //borderColor: ro.ui.theme.btnBorderDefault,
                        //borderWidth: ro.ui.relX(1),
                        layout: 'vertical',
                        idx: 0
                    });
                    var backView = Ti.UI.createView({
                        height: '60%',
                        idx: 0
                    });
                    backView.add(Ti.UI.createView({
                        backgroundImage: '/images/leftArrow.png',
                        height: ro.ui.relY(30),
                        width: ro.ui.relX(30),
                        idx: 0
                    }));
                    itemBack.add(backView);
                    itemBack.add(Ti.UI.createLabel({
                        text: 'Back',
                        color: ro.ui.theme.menuOtherBtnTxt,
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL,
                        textAlign: 'center',
                        bottom:ro.isiOS ? ro.ui.relX(5) : null,
                        font: {
                            //fontWeight: 'bold',
                            fontSize: ro.ui.scaleFont(17),
                            fontFamily: ro.ui.fonts.navBtns
                        },
                        idx: 0
                    }));
                    itemCancel = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: bottomBtnWidth,
                        backgroundColor: ro.ui.theme.menuBtnBackground,
                       //borderColor: ro.ui.theme.btnBorderDefault,
                       // borderWidth: ro.ui.relX(1),
                        layout: 'vertical',
                        idx: 1
                    });
                    var cancelView = Ti.UI.createView({
                        height: '60%',
                        idx: 1
                    });
                    cancelView.add(Ti.UI.createView({
                        backgroundImage: '/images/clearBtn.png',
                        height: ro.ui.relY(25),
                        width: ro.ui.relX(25),
                        idx: 1
                    }));
                    itemCancel.add(cancelView);
                    itemCancel.add(Ti.UI.createLabel({
                        text: 'Clear',
                        color: ro.ui.theme.menuOtherBtnTxt,
                        //top:0,
                        textAlign: 'center',
                        height: Ti.UI.FILL,
                        width: Ti.UI.FILL,
                        bottom:ro.isiOS ? ro.ui.relX(5) : null,
                        font: {
                            //fontWeight: 'bold',
                            fontSize: ro.ui.scaleFont(17),
                            fontFamily: ro.ui.fonts.navBtns
                        },
                        idx: 1
                    }));
                    itemNext = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: bottomBtnWidth,
                        backgroundColor: ro.ui.theme.menuBtnBackground,
                        //borderColor: ro.ui.theme.btnBorderDefault,
                        //borderWidth: ro.ui.relX(1),
                        layout: 'vertical',
                        idx: 2
                    });
                    var nextView = Ti.UI.createView({
                        height: '60%',
                        idx: 2
                    });
                    nextView.add(Ti.UI.createView({
                        backgroundImage: '/images/redRightArrow.png',
                        height: ro.ui.relY(30),
                        width: ro.ui.relX(30),
                        idx: 2
                    }));
                    itemNext.add(nextView);

                    itemNext.add(Ti.UI.createLabel({
                        text: 'Continue',
                        color: '#eb0029',
                        textAlign: 'center',
                        height: Ti.UI.FILL,
                        bottom:ro.isiOS ? ro.ui.relX(5) : null,
                        width: Ti.UI.FILL,
                        font: {
                            //fontWeight: 'bold',
                            fontSize: ro.ui.scaleFont(17),
                            fontFamily: ro.ui.fonts.navBtns
                        },
                        idx: 2
                    }));
                    itemAdd = Ti.UI.createView({
                        height: Ti.UI.FILL,
                        width: bottomBtnWidth,
                        backgroundColor: ro.ui.theme.menuBtnBackground,
                        //borderColor: ro.ui.theme.btnBorderDefault,
                        //borderWidth: ro.ui.relX(1),
                        layout: 'vertical',
                        idx: 3
                    });
                    var addView = Ti.UI.createView({
                        height: '60%',
                        //height:Ti.UI.FILL,
                        idx: 3
                    });
                    addView.add(Ti.UI.createView({
                        backgroundImage: '/images/cart_blk.png',
                        height: ro.ui.relY(30),
                        width: ro.ui.relX(30),
                        idx: 3
                    }));
                    itemAdd.add(addView);

                    itemAdd.add(Ti.UI.createLabel({
                        text: 'Add To Cart',
                        color: '#eb0029',
                        textAlign: 'center',
                        height: Ti.UI.FILL,
                        bottom:ro.isiOS ? ro.ui.relX(5) : null,
                        width: Ti.UI.FILL,
                        font: {
                            //fontWeight: 'bold',
                            fontSize: ro.ui.scaleFont(17),
                            fontFamily: ro.ui.fonts.navBtns
                        },
                        idx: 3
                    }));
                    botTabView.add(itemBack);
                    botTabView.add(itemCancel);
                    botTabView.add(itemNext);

                    botTabView.addEventListener('click', function(e) {
                        if (e.source.idx === 0) {
                            if (scrollableView.children[0].pageIdx === 0) {
                                goBack();
                            }
                            else {
                                scrollLeft();
                            }
                        }
                        else if (e.source.idx === 1) {

                            ro.ui.popup('Attention: ', ['Cancel', 'OK'], 'Reset current item selections?', function(e) {
                                /*if (e.source.index === -1 || e.index === -1) {
                                 return;
                                 }

                                 if (e.index === 1) {*/
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'itemDetails'
                                });
                                //}
                                ro.windowpopup.hideWindowpopup();
                            });

                        }
                        else if (e.source.idx === 2) {
                            var curPg = scrollableView.children[0].pageIdx;
                            var scrollBool = shouldIScroll(curPg + 1);
                            if (scrollBool) {
                                scrollRight();
                            }
                        }
                        else if (e.source.idx === 3) {
                            addItemEvent();
                        }
                    });
                    function toggleBtn() {
                        if (botTabView.children[2].idx == 2) {
                            botTabView.remove(itemNext);
                            botTabView.add(itemAdd);
                        }
                        else if (botTabView.children[2].idx == 3) {
                            botTabView.remove(itemAdd);
                            botTabView.add(itemNext);
                        }
                    }


                    fullView.toggleBtn = toggleBtn;

                    //mainView.add(botTabView);
                    fullView.add(botTabView);
                    return fullView;
                }

                function addItemEvent(e) {
                    try {
                        var tempSelectedItemCpnObj = {},
                            isSelectedItemCpn = false;
                        var itemObj = ro.itemObj.getItemObj();
                        if (itemObj.Mods) {
                            ro.itemObj.ModPropFill(itemObj.Mods);
                        }
                        if (itemObj.NoMods) {
                            ro.itemObj.ModPropFill(itemObj.NoMods);
                        }
                        var item = CheckItem(itemObj);

                        if (item.isValid) {
                            
                            if(itemObj.PrfMbrs && itemObj.PrfMbrs.length){
                                function sortPrefs(a, b){
                                    return a.PrefIndex > b.PrefIndex;
                                }
                                itemObj.PrfMbrs.sort(sortPrefs);
                            }
                            
                            if (cpnGuidedBool || ro.App.edit.editMode) {
                                try {
                                    var obj = Ti.App.OrderObj;
                                    if (!obj.Items) {
                                        obj.Items = [];
                                    }
                                    var bogoBool = false;
                                    if (ro.App.edit.editMode) {
                                        var existingItem = ro.App.edit.editIndex;
                                        
                                        if(obj.Items[ro.App.edit.editIndex].tempCpnKey){
                                            editItemTempCpnKey = obj.Items[ro.App.edit.editIndex].tempCpnKey;
                                        }
                                        
                                        if(obj.Items[ro.App.edit.editIndex].realCpnKey){
                                            editItemRealCpnKey = obj.Items[ro.App.edit.editIndex].realCpnKey;
                                        }
                                        
                                        var bogo = {
                                            boVal: 0,
                                            goVal: 0

                                        },
                                            idItemIdx,
                                            cpnObjIdx;

                                        if (obj.Items[ro.App.edit.editIndex].BogoID) {
                                            bogoBool = true;
                                            bogo.boVal = Ti.App.OrderObj.Items[ro.App.edit.editIndex].BogoID;

                                            idItemIdx = ro.App.edit.editIndex;

                                            for (var i = 0; i < obj.Items.length; i++) {
                                                if (obj.Items[i].CpnObj && (obj.Items[i].CpnObj.BogoID == bogo.boVal)) {
                                                    cpnObjIdx = i;
                                                    bogo.goVal = obj.Items[i].CpnObj;
                                                    break;
                                                }
                                            }
                                        }
                                        else if (obj.Items[ro.App.edit.editIndex].hasOwnProperty('CpnObj') && (parseInt(obj.Items[ro.App.edit.editIndex].CpnObj.CpnScope, 10) !== 2)) {
                                            bogoBool = true;
                                            bogo.goVal = obj.Items[ro.App.edit.editIndex].CpnObj;
                                            bogo.boVal = bogo.goVal.BogoID;

                                            cpnObjIdx = ro.App.edit.editIndex;

                                            for (var i = 0; i < obj.Items.length; i++) {
                                                if (obj.Items[i].BogoID && (obj.Items[i].BogoID == bogo.goVal.BogoID)) {
                                                    idItemIdx = i;
                                                    bogo.boVal = obj.Items[i].BogoID;
                                                }
                                            }
                                        }
                                        else {
                                            if (obj.Items[ro.App.edit.editIndex].hasOwnProperty('CpnObj')) {//THIS LOOKS LIKE ITS BOGO BUT ITS NOT, BECAUSE OF ABOVE
                                                //THIS IS ACTUALLY CPNSCOPE 2 COUPONS: SELECTED ITEM
                                                tempSelectedItemCpnObj = obj.Items[ro.App.edit.editIndex].CpnObj;
                                                isSelectedItemCpn = true;
                                            }
                                        }
                                    }
                                    else {
                                        var existingItem = ro.cpnHelper.existingItem();
                                    }

                                    if (existingItem !== -1 && existingItem >= 0) {
                                        if (bogoBool == true) {
                                            if (false && ro.app.Store.Configuration.AllowItemNote && displayView.ItemNote && displayView.ItemNote.length) {
                                                itemObj.Notes = [];
                                                itemObj.Notes.push({
                                                    NoteText: displayView.ItemNote
                                                });
                                            }
                                            else {
                                                itemObj.Notes = null;
                                                itemObj.Notes = [];
                                            }
                                            obj.Items[existingItem] = itemObj;

                                            Ti.App.OrderObj = obj;
                                            //var func = new PricingFunctions();
                                            var priceEngine = require('logic/pricing');
                                            var func = priceEngine.pricer();
                                            Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                                            //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);
                                            obj = Ti.App.OrderObj;

                                            var propToCompare = bogo.goVal.NoModDisc ? 'ActivePrice' : 'InclusivePrice';
                                            if (obj.Items[idItemIdx][propToCompare] < obj.Items[cpnObjIdx][propToCompare]) {
                                                if (obj.Items[idItemIdx].BogoID) {
                                                    delete obj.Items[idItemIdx].BogoID;
                                                }
                                                if (obj.Items[cpnObjIdx].CpnObj) {
                                                    delete obj.Items[cpnObjIdx].CpnObj;
                                                }
                                                obj.Items[idItemIdx].CpnObj = bogo.goVal;
                                                obj.Items[cpnObjIdx].BogoID = bogo.boVal;
                                            }
                                            else {
                                                if (obj.Items[idItemIdx].CpnObj) {
                                                    delete obj.Items[idItemIdx].CpnObj;
                                                }
                                                if (obj.Items[cpnObjIdx].BogoID) {
                                                    delete obj.Items[cpnObjIdx].BogoID;
                                                }
                                                obj.Items[cpnObjIdx].CpnObj = bogo.goVal;
                                                obj.Items[idItemIdx].BogoID = bogo.boVal;
                                            }

                                        }
                                        else {
                                            if (false && ro.app.Store.Configuration.AllowItemNote && displayView.ItemNote && displayView.ItemNote.length) {
                                                itemObj.Notes = [];
                                                itemObj.Notes.push({
                                                    NoteText: displayView.ItemNote
                                                });
                                            }
                                            else {
                                                itemObj.Notes = null;
                                                itemObj.Notes = [];
                                            }
                                            if (isSelectedItemCpn) {
                                                itemObj.CpnObj = tempSelectedItemCpnObj;
                                            }
                                            if(editItemTempCpnKey){
                                                itemObj.tempCpnKey = editItemTempCpnKey;
                                            }
                                            
                                            if(editItemRealCpnKey){
                                                itemObj.realCpnKey = editItemRealCpnKey;
                                            }
                                            obj.Items[existingItem] = itemObj;
                                        }
                                    }
                                    else {
                                        //Order Item Notes
                                        if (false && ro.app.Store.Configuration.AllowItemNote && displayView.ItemNote && displayView.ItemNote.length) {
                                            itemObj.Notes = [];
                                            itemObj.Notes.push({
                                                NoteText: displayView.ItemNote
                                            });
                                        }
                                        else {
                                            itemObj.Notes = null;
                                            itemObj.Notes = [];
                                        }
                                        //Order Item Notes

                                        obj.Items.push(itemObj);
                                    }
                                    Ti.App.OrderObj = obj;

                                    //var func = new PricingFunctions();
                                    var priceEngine = require('logic/pricing');
                                    var func = priceEngine.pricer();
                                    Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                                    //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);

                                    if (ro.App.edit.editMode) {
                                        ro.App.edit.editMode = false;
                                        ro.App.edit.editIndex = null;
                                        ro.ui.showCart();
                                    }
                                    else {
                                        ro.ui.ordShowNext({
                                            showing: 'cpnDetails'
                                        });
                                    }
                                }
                                catch(ex) {
                                    ro.ui.hideLoader();
                                    if (Ti.App.DEBUGBOOL) {
                                        Ti.API.debug('addItem-itemDetailsView-Exception: ' + ex);
                                    }
                                    ro.ui.alert('Error', 'CODE:102');
                                }
                            }
                            else if (ro.App.sugg.suggMode) {
                                try {
                                    var obj = Ti.App.OrderObj;
                                    if (!obj.Items) {
                                        obj.Items = [];
                                    }

                                    //Order Item Notes
                                    if (false && ro.app.Store.Configuration.AllowItemNote && displayView.ItemNote && displayView.ItemNote.length) {
                                        itemObj.Notes = [];
                                        itemObj.Notes.push({
                                            NoteText: displayView.ItemNote
                                        });
                                    }
                                    else {
                                        itemObj.Notes = null;
                                        itemObj.Notes = [];
                                    }
                                    //Order Item Notes

                                    obj.Items.push(itemObj);
                                    Ti.App.OrderObj = obj;
                                    //var func = new PricingFunctions();
                                    var priceEngine = require('logic/pricing');
                                    var func = priceEngine.pricer();
                                    Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                                    //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);

                                    ro.App.sugg.suggMode = false;
                                    ro.App.sugg.grpIndx = null;
                                    ro.App.sugg.itmIndx = null;
                                    ro.App.sugg.SuggSizeName = null;
                                    ro.App.sugg.SuggStyleName = null;

                                    ro.ui.showLoader();
                                    ro.ui.showCart();
                                    ro.ui.hideLoader();
                                }
                                catch(ex) {
                                    ro.ui.hideLoader();
                                    if (Ti.App.DEBUGBOOL) {
                                        Ti.API.debug('addItem-itemDetailsView-Exception: ' + ex);
                                    }
                                }
                            }
                            else {
                                var alertView = Ti.UI.createView({
                                    height: ro.ui.relY(150),
                                    width: Ti.UI.FILL,
                                    layout: 'vertical'
                                });
                                alertView.add(createAddOptions());
                                var alertVw = createAddOptions();
                                alertVw.addEventListener('click', function(e) {

                                    if (e.source.index === -1 || e.index === -1) {
                                        return;
                                    }
                                    if (e.index === 0 || e.index === 1) {
                                        if (REV_Suggest.CheckForMatchingSuggItmOpts(itemObj, group)) {
                                            REV_Suggest.HHOfferSuggestion(FinishAddItem, e.index, itemObj.Size, group);
                                        }
                                        else {
                                            FinishAddItem(e.index);
                                        }
                                    }
                                    ro.windowpopup.hideWindowpopup();
                                });

                                ro.ui.alert(null, null, alertVw);

                                if (false && ro.isiOS) {

                                    additemAlert.cancel = 2;
                                    additemAlert.buttonNames = ['Add Item to Cart', 'Add Item and Checkout', 'Cancel'];
                                    additemAlert.addEventListener('click', function(e) {
                                        if (e.index === 0 || e.index === 1) {
                                            /*if(REV_Suggest.CheckForMatchingSuggItmOpts(itemObj, group)){
                                             REV_Suggest.HHOfferSuggestion(FinishAddItem, e.index, itemObj.Size);
                                             }
                                             else{*/
                                            FinishAddItem(e.index);
                                            //}
                                        }
                                        additemAlert.hide();
                                    });
                                }
                                //additemAlert.show();
                            }
                        }
                        else {
                            var msg = '';
                            var itmMsgLngth = item.messages ? item.messages.length : 0;
                            for (var i = 0; i < itmMsgLngth; i++) {
                                msg += item.messages[i] + '\n';
                            }
                            ro.ui.alert('Alert!', msg);
                        }
                    }
                    catch(ex) {
                        ro.ui.alert('addItem', ex);
                    }
                }

                function CheckItem(itemObj) {
                    var response = {};
                    response.isValid = true;
                    response.messages = [];
                    var i,
                        j;
                    var found;

                    if (group.HasSizes && group.Sizes && group.Sizes.length > 0) {
                        if (!itemObj.Size) {
                            response.isValid = false;
                            response.messages.push('Please select size');
                        }
                    }

                    if (group.HasStyles && group.Styles && group.Styles.length > 0 && group.HasSizes && group.Sizes && group.Sizes.length) {
                        if (!itemObj.Style) {
                            response.isValid = false;
                            response.messages.push('Please select style');
                        }
                    }

                    if (itemSelected.HasPrefs) {
                        found = false;
                        found = ro.itemObj.chkPrefs();
                        if (found.foundError) {
                            response.isValid = false;
                            response.messages.push(found.Message);
                            //response.messages.push('Please select ' + itemSelected.Prefs[0].Name);
                        }
                    }
                    return response;
                }

                function createAddOptions() {
                    var alertRows = [];
                    alertRows[0] = Ti.UI.createTableViewRow({
                        height: ro.ui.relY(50),
                        width: Ti.UI.FILL,
                		   selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                    });
                    alertRows[0].add(Ti.UI.createLabel({
                        text: 'Add Item to Cart',
                        color: '#393839',
                        font: {
                            //fontWeight:'bold',
                            fontSize: ro.ui.scaleFont(16, 0, 0),
                            fontFamily: ro.ui.fonts.alerts.body
                        },
                        textAlign: 'center'
                    }));

                    alertRows[1] = Ti.UI.createTableViewRow({
                        height: ro.ui.relY(50),
                        width: Ti.UI.FILL,
                			selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                    });
                    alertRows[1].add(Ti.UI.createLabel({
                        text: 'Add Item and Checkout',
                        color: '#393839',
                        font: {
                            //fontWeight:'bold',
                            fontSize: ro.ui.scaleFont(16, 0, 0),
                            fontFamily: ro.ui.fonts.alerts.body
                        },
                        textAlign: 'center'
                    }));

                    alertRows[2] = Ti.UI.createTableViewRow({
                        height: ro.ui.relY(50),
                        width: Ti.UI.FILL,
                			selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
                    });
                    alertRows[2].add(Ti.UI.createLabel({
                        text: 'Cancel',
                        color: '#393839',
                        font: {
                            //fontWeight:'bold',
                            fontSize: ro.ui.scaleFont(16, 0, 0),
                            fontFamily: ro.ui.fonts.alerts.body
                        },
                        textAlign: 'center'
                    }));
                    var alertTable = Ti.UI.createTableView({
                        data: alertRows,
                        height: Ti.UI.SIZE,
                        width: Ti.UI.FILL,
                        backgroundColor: 'white',
                        separatorColor: '#e4e4e4'
                    });

                    var alertVw = Ti.UI.createView(ro.isiOS ? ro.ui.properties.popupAlertView2ios : ro.ui.properties.popupAlertView2);
                    /*Ti.UI.createView({
                     layout:'vertical',
                     height:Ti.UI.SIZE,
                     width:Ti.UI.FILL,
                     backgroundColor:'white',
                     borderRadius:ro.ui.relX(15)
                     });*/
                    var headerRow = Ti.UI.createView({
                        //touchEnabled:false,
                        index: -1,
                        height: ro.ui.relY(50),
                        width: Ti.UI.FILL
                    });
                    var hdrLbl = Ti.UI.createLabel({
                        text: 'Please select an option:',
                        touchEnabled: false,
                        font: {
                            fontFamily: ro.ui.fonts.alerts.title,
                            fontSize: ro.ui.scaleFont(28)
                        },
                        color: '#393839',
                        width: Ti.UI.FILL,
                        height: Ti.UI.SIZE,
                        textAlign: 'center'
                    });
                    headerRow.add(Ti.UI.createView(ro.combine(ro.ui.properties.fullGreyBar, {
                        bottom: 0,
                        touchEnabled: false
                    })));
                    headerRow.add(hdrLbl);
                    alertVw.add(headerRow);
                    alertVw.add(alertTable);
                    return alertVw;
                }

                function FinishAddItem(selectedIndex) {
                    try {
                        var obj = Ti.App.OrderObj;
                        if (!obj.Items) {
                            obj.Items = [];
                        }
                        var itemObj = ro.itemObj.getItemObj();
                        //Order Item Notes
                        if (false && ro.app.Store.Configuration.AllowItemNote && displayView.ItemNote && displayView.ItemNote.length) {
                            itemObj.Notes = [];
                            itemObj.Notes.push({
                                NoteText: displayView.ItemNote
                            });
                        }
                        else {
                            itemObj.Notes = null;
                            itemObj.Notes = [];
                        }
                        //Order Item Notes

                        obj.Items.push(itemObj);
                        Ti.App.OrderObj = obj;
                        //var func = new PricingFunctions();
                        var priceEngine = require('logic/pricing');
                        var func = priceEngine.pricer();

                        Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                        //ro.updateCartCount(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0);

                        if (selectedIndex === 1) {
                            ro.ui.showLoader();
                            ro.ui.showCart();
                            ro.ui.hideLoader();
                        }
                        else if (selectedIndex === 0) {
                            if (Ti.App.newMenu) {
                                ro.ui.ordShowNext({
                                    showing: 'itemsView'
                                });
                            }
                            else {
                                ro.ui.ordShowNext({
                                    showing: 'itemDetails'
                                });
                            }
                        }
                    }
                    catch(ex) {
                        ro.ui.hideLoader();
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('addItem-itemDetailsView-alertView-Exception: ' + ex);
                        }
                        ro.ui.alert('Error', 'CODE:102');
                    }

                }


                mainView.add(bottomTabView);
                //ro.ui.hideLoader();
            }
            catch(ex) {
                Ti.API.debug('ex: ' + ex);
            }
            mainView.addEventListener('postlayout', function(){
                if(tempTabView && tempTabView.children && tempTabView.children.length){
                    tempTabView.children[0].fixTabs();
                }
               
            });
            return mainView;
        };

    };
    return {
        itemdetailsview: itemdetailsview
    };
}();
module.exports = ITEMDETAILSVIEW; 