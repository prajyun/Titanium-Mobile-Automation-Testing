var COUPONSELECTIONVIEW = function() {
    var couponselectionview = function(ro) {
        var itemsInCart,
            logoutBtn,
            switchEventBool,
            cpnValcode,
            addBtn;
        ro.ui.createCpnSelectionView = function(cpnKey, cpnVal, goBackToCart) {
            var menuUtils = require('logic/menuUtils');
            var menuHelper = require('logic/menuHelper');
            if (!goBackToCart) {
                goBackToCart = false;
            }
            switchEventBool = false;
            cpnValcode = cpnVal;
            try {
                var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
                var Groups = menuHelper.getGroups(ro.app.Store.Menu, timeAtStore);
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('ro.ui.createCpnSelectionView()-Exception' + ex);
                }
            }

            var rows;

            var logoutEvent = function(e) {
                ro.ui.ordShowNext({
                    showing: 'ordTypeView'
                });
            };
            addBtn = layoutHelper.getBigButton('ADD COUPON');
            addBtn.visible = false;
            addBtn.top = 0;
            delete addBtn.bottom;

            addBtn.addEventListener('click', addToOrder);

            var rowString = Ti.App.Properties.getString('SelectedCoupon');
            if (rowString && rowString.length > 0) {
                rows = JSON.parse(rowString);
            }
            else {
                rows = ro.cpnHelper.findItem(cpnKey);
                Ti.App.Properties.setString('SelectedCoupon', JSON.stringify(rows));
            }
            var cpnItmLngth;
            var mainView = getMainView(goBackToCart);
            mainView.changeBtns = changeBtn;

            //Checks if item is in cart and then adds check mark to item row!
            var itemsArr = ro.cpnHelper.checkCart({
                cpnKey: cpnKey
            });
            itemsInCart = itemsArr.completedItems;
            if (itemsArr.allDone) {
                addToOrder(function(e) {
                    if (!switchEventBool) {
                        switchEventBool = true;
                        mainView.changeBtns(true);
                    }
                });
            }
            else {
                switchEventBool = false;
            }

            //itemsInCart should be an array the size of the coupons.Items.length and each index should have a true or false value correlating to whether the given item has been added to cart yet.
            var numItems;
            var interv = 0;

            createRows(rows, itemsInCart, function(tblRows) {
                var grpView,
                    grpsTbl,
                    editBtnView,
                    editBtn,
                    visibleValue = false;
                var itemsInCartLength = itemsInCart ? itemsInCart.length : 0;

                for (var i = 0; i < itemsInCartLength; i++) {
                    if (itemsInCart[i].found) {
                        visibleValue = true;
                        break;
                    }
                }

                grpView = Ti.UI.createScrollView(ro.ui.properties.couponSelectionView);
                /*grpView = Ti.UI.createView(ro.combine(ro.ui.properties.couponSelectionView, {
                 height:Ti.UI.FILL,
                 layout:'vertical',
                 top:ro.ui.relY(0),
                 bottom:ro.ui.relY(45)
                 }));*/
                editBtnView = Ti.UI.createView({
                    height: visibleValue ? 0 : 0,
                    width: Ti.UI.FILL,
                    top: visibleValue ? ro.ui.relY(5) : 0,
                    left: ro.ui.relX(5),
                    right: ro.ui.relX(5),
                    backgroundColor: ro.ui.theme.editBtnDefault,
                    visible: visibleValue,
                    borderRadius: ro.ui.relX(6)
                });
                editBtn = Ti.UI.createLabel({
                    text: 'EDIT',
                    color: ro.ui.theme.editTxtDefault, //'white',
                    font: {
                        fontSize: ro.ui.scaleFont(15),
                        fontWeight: 'bold',
                        fontFamily: ro.ui.fontFamily
                    },
                    editMode: false
                });
                editBtnView.add(editBtn);

                editBtnView.addEventListener('click', function(e) {
                    try {
                        if (interv > 0) {
                            return;
                        }
                        interv = setTimeout(function() {
                            try {
                                if (editBtn.editMode) {
                                    editBtn.text = 'EDIT';
                                    numItems = 0;
                                    editBtn.editMode = false;
                                    editBtn.color = 'white';
                                    editBtnView.backgroundColor = ro.ui.theme.loginGray;

                                    for (var i = 0; i < grpsTbl.data[0].rowCount; i++) {
                                        grpsTbl.data[0].rows[i].children[0].image = Ti.App.websiteURL + 'content/images/menu-item.png';
                                    }
                                }
                                else {
                                    numItems = 0;
                                    for (var i = 0; i < grpsTbl.data[0].rowCount; i++) {
                                        if (!grpsTbl.data[0].rows[i].inCart) {
                                            grpsTbl.data[0].rows[i].children[0].image = '/images/grpBackground.png';
                                        }
                                        else {
                                            numItems++;
                                        }
                                    }
                                    grpsTbl.setData(grpsTbl.data[0].rows);
                                    editBtnView.backgroundColor = ro.ui.theme.editBtnActive;
                                    editBtn.text = 'DONE';
                                    editBtn.editMode = true;
                                    editBtn.color = ro.ui.theme.editTxtActive;
                                }
                                interv = 0;
                            }
                            catch(ex) {
                                if (Ti.App.DEBUGBOOL) {
                                    Ti.API.debug('EditBtnToggleEvent-Exception' + ex);
                                }
                            }
                        }, 200);
                    }
                    catch(ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('editBtnView-EventListener-Exception: ' + ex);
                        }
                    }
                });

                grpsTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
                    data: [],
                    height: Ti.UI.SIZE,
                    rowHeight: Ti.UI.SIZE,
                    minRowHeight: ro.ui.properties.menuRowHeight,
                    top: ro.ui.relY(5),
                    left: ro.ui.relX(0),
                    right: ro.ui.relX(0),
                    backgroundColor: 'transparent',
                    separatorColor: 'transparent'
                }));
                delete grpsTbl.bottom;

                grpsTbl.setData(tblRows);
                grpsTbl.addEventListener('click', function(e) {
                    try {
                        Ti.API.info('calling coupons from couponselectionview. ');
                        var existingItemIndex = ro.cpnHelper.getItemIdx(e.row.preChosen);
                        var couponIdx = e.index;
                        if (ro.cpnHelper.isPickAnyCpn()) {

                        }
                        else {
                            ro.app.group = JSON.parse(JSON.stringify(ro.app.Store.Menu.Groups[rows[e.index].grpIdx]));
                            ro.cpnHelper.setCpIdx(e.index);
                        }

                        ro.cpnHelper.setSelection(e.row.preChosen);
                        ro.cpnHelper.setExistingItem(existingItemIndex);

                        if (editBtn.editMode) {
                            if (e.row.inCart) {

                                deletePopup(Ti.App.OrderObj.Items[existingItemIndex].Name || Ti.App.OrderObj.Items[existingItemIndex].ReceiptName, function(ee) {
                                    //if(ee.index === 0){
                                    try {
                                        ro.ui.showLoader();
                                        if (switchEventBool) {
                                            mainView.changeBtns(false);
                                            switchEventBool = false;
                                        }

                                        ro.cpnHelper.deleteItem(existingItemIndex);
                                        ro.cpnHelper.clearSelection();
                                        e.row.preChosen = {
                                            Mods: []
                                        };
                                        e.row.toggle();
                                        //e.row.children[1].toggle();//rowVw.label

                                        //e.row.children[0].children[1].toggle();
                                        e.row.inCart = false;
                                        e.row.children[0].backgroundImage = '/images/grpBackground.png';
                                        numItems--;
                                        e.row.children[0].remove(e.row.children[0].checkMark);

                                        if (numItems == 0) {
                                            editBtn.editMode = false;
                                            editBtn.color = 'white';
                                            editBtnView.visible = false;
                                            editBtnView.height = 0;

                                            for (var i = 0; i < grpsTbl.data[0].rowCount; i++) {
                                                grpsTbl.data[0].rows[i].children[0].image = Ti.App.websiteURL + 'content/images/menu-item.png';
                                            }
                                        }
                                        grpsTbl.setData(grpsTbl.data[0].rows);
                                        ro.ui.hideLoader();
                                    }
                                    catch(ex) {
                                        if (Ti.App.DEBUGBOOL) {
                                            Ti.API.debug('deletePopup()-CallbackFunc-Exception' + ex);
                                        }
                                    }
                                    //}
                                });
                            }
                        }
                        else {
                            Ti.App.Cpon = e.index;
                            if (rows[e.index].isItem && !e.row.isSpecialMulti) {
                                ro.app.itemSelected = ro.app.group.Items[rows[e.index].itmIdx];
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'itemDetails'
                                });
                            }
                            else if (e.row.specialIsItem) {

                                ro.cpnHelper.setCurrIsReq(e.row.Name == 'Required Item' ? true : false);
                                ro.cpnHelper.setCurrPickIndex(0);
                                ro.app.group = ro.app.Store.Menu.Groups[e.row.gi];
                                ro.app.itemSelected = ro.app.Store.Menu.Groups[e.row.gi].Items[e.row.ii];
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'itemDetails'
                                });
                            }
                            else if (e.row.isSpecialMulti) {
                                ro.app.group = ro.app.Store.Menu.Groups[e.row.gi];
                                ro.app.itemSelected = ro.app.group.Items[rows[e.index].itmIdx];
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'itemDetails'
                                });
                            }
                            else {
                                //Ti.API.debug('e.row: ' + JSON.stringify(e.row));
                                ////deb.ug(e.row, 'e.row');
                                //Ti.API.debug('ro.app.Store.Menu.Groups[e.row.gi].Name: ' + ro.app.Store.Menu.Groups[e.row.gi].Name);
                                //Ti.API.debug('e.row.Name: ' + e.row.Name);
                                Ti.App.cpnGrpIndex = e.row.Name;
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'cpnItems'
                                });
                            }
                        }
                    }
                    catch(ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('rowClickEvent-Exception' + ex);
                        }
                    }
                });
                grpView.add(editBtnView);
                grpView.add(grpsTbl);
                grpView.add(addBtn);
                mainView.add(grpView);
            });
            return mainView;
        };
        function changeBtn(changeBool) {
            try {
                if (changeBool) {
                    addBtn.show();
                }
                else {
                    addBtn.hide();
                }
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('changeBtn() - Exception: ' + ex);
                }
            }
        }

        function deletePopup(itmName, _delCB) {
            try {
                var delItemAlert = Ti.UI.createAlertDialog({
                    title: 'Remove ' + itmName,
                    message: 'Would you like to remove this item from the cart?',
                    buttonNames: ['YES', 'NO'],
                    height: Ti.UI.SIZE,
                    width: '80%'
                });
                delItemAlert.addEventListener('click', _delCB);
                //delItemAlert.show();
                ro.ui.popup('Remove ' + itmName, ['Cancel', 'OK'], 'Would you like to remove this item from the cart?', function(e) {
                    _delCB();
                });
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('deletePopup() - Exception: ' + ex);
                }
            }
        }

        function getMainView(goBackToCart) {
            var mainView,
                navBar,
                headerLbl,
                backBtn;

            mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
                name: 'cpnSelView',
                hid: goBackToCart && goBackToCart == true ? 'cpnSelViewToCart' : 'cpnSelView',
                layout: 'vertical'
            }));
            /* navBar = Ti.UI.createView(ro.ui.properties.navBar);

            if(ro.ui.theme.bannerImg){
            var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
            navBar.add(headerImg);
            }
            else{
            headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
            text:cpnHelper.getSelectedCpnNm()
            }));
            navBar.add(headerLbl);
            } */
            //var sharedLayout = require('/revmobile/ui/sharedLayouts/mainView');
            //logoutBtn = layoutHelper.getLogoutBtn();
            backBtn = layoutHelper.getBackBtn();
            backBtn.addEventListener('click', function(e) {
                if (goBackToCart) {
                    //ro.ui.showCart();
                    /*ro.ui.changeTab({
                     tabIndex:2
                     });*/
                    ro.ui.changeTab({
                        tabIndex: ro.REV_GUEST_ORDER.getIsGuestOrder() ? 1 : (ro.REV_LOYALTY.getCurrentLoyalty().isHC ? 3 : 2)
                    });
                }
                else {
                    ro.ui.ordShowNext({
                        showing: 'cpnSelView'
                    });
                }
            });
            navBar = Ti.UI.createView(ro.ui.properties.navBar);
            navBar.add(backBtn);
            //navBar.add(logoutBtn);
            //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            if (ro.isiphonex) {
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            }
            else {
                mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            }
            return mainView;
        }

        function createRows(cpnItems, itemsInCart, _rowCallback) {
            var thisItmRow,
                rowData = [],
                itmLngth,
                favoriteOrders,
                cpnObj,
                cpnItmLngth = cpnItems.length;
            try {
                for (var i = 0; i < cpnItmLngth; i++) {
                    cpnItems[i].inCart = false;

                    if (itemsInCart && (itemsInCart.length === cpnItmLngth)) {
                        cpnItems[i].inCart = itemsInCart[i].found;
                        cpnItems[i].chosenPrefs = itemsInCart[i].tempItem;
                    }
                    cpnItems[i].stepIdx = i;
                    thisItmRow = addRow(cpnItems[i], (i % 2));
                    rowData.push(thisItmRow);
                }
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('ro.ui.createCpnSelectionView()-createRows()-Exception' + ex);
                }
            }
            _rowCallback(rowData);
        }

        function newAddRow(rowDetails, receiptName, obj, imgPath, isCoupon, idx, itemPrice, grpIndx) {
            Ti.API.debug('idx: ' + idx);
            var hasImg = (imgPath && imgPath.length > 0);
            var left = ro.ui.relX(7);
            var cls = ( hasImg ? 'item' : 'noitem');
            var hasRightImg = false;

            var bottom = 30;
            var theRow = Ti.UI.createTableViewRow({
                selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                hasChild: false,
                height: ro.ui.relY(175), //120
                itmType: ( isCoupon ? 'coupon' : 'item'),
                txtObj: obj.txtObj,
                hasTheCheck: hasRightImg,
                grpIndex: grpIndx,
                width: ro.ui.displayCaps.platformWidth,
                layout: 'horizontal',
                backgroundColor: ((idx % 2) ? '#f6f6f6' : 'white')
            });
            var leftVw = Ti.UI.createView({
                width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7,
                height: Ti.UI.FILL
            });
            var imageHolder = Ti.UI.createView({
                top: 0,
                left: 0,
                right: 0,
                bottom: ro.ui.relY(bottom)
            });
            imageHolder.add(Ti.UI.createImageView({
                image: isCoupon ? (ro.ui.properties.defaultPath + 'myDeals.png') : ( hasImg ? imgPath : group.ImageSource),
                defaultImage: ro.ui.properties.defaultImgPath,
                top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null, //ro.ui.relX(15),
                bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
            }));
            var labelHolder = Ti.UI.createView({
                bottom: ro.ui.relY(15),
                left: 0,
                right: 0,
                height: ro.ui.relY(bottom)
            });
            labelHolder.add(Ti.UI.createLabel({
                text: itemPrice,
                font: {
                    fontFamily: ro.ui.fonts.prices.newItemsView,
                    fontSize: ro.ui.scaleFont(20),
                    //fontWeight:'bold'
                },
                color: '#b5b5b5'
            }));
            leftVw.add(imageHolder);
            leftVw.add(labelHolder);
            /*Ti.API.debug('(ro.ui.displayCaps.platformWidth/2)*(11/10): ' + (ro.ui.displayCaps.platformWidth/2)*(11/10));
             Ti.API.debug('(9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7: ' + ((9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7));
             var xx = (9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7;
             var yy = (ro.ui.displayCaps.platformWidth/2)*(11/10);
             Ti.API.debug('zz: ' + (xx + yy));
             Ti.API.debug('ro.ui.displayCaps: ' + JSON.stringify(ro.ui.displayCaps));
             */
            var rightVw = Ti.UI.createView({
                width: (ro.ui.displayCaps.platformWidth / 2) * (11 / 10),
                //width:Ti.UI.FILL,
                height: Ti.UI.SIZE,
                layout: 'vertical'
            });
            var titleHolder = Ti.UI.createView({
                height: ro.ui.relY(35),
                width: Ti.UI.FILL
            });
            titleHolder.add(Ti.UI.createLabel({
                text: receiptName,
                color: '#393839',
                textAlign: 'left',
                left: 0,
                font: {
                    fontFamily: ro.ui.fonts.titles,
                    fontSize: ro.ui.scaleFont(18),
                    //fontWeight:'bold'
                }
            }));
            ////Ti.API.debug('titleHolder: ' + JSON.stringify(titleHolder));
            var bodyHolder = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL
            });
            bodyHolder.add(Ti.UI.createLabel({
                color: '#393839',
                text: obj.description,
                right: ro.isiOS ? ro.ui.relX(5) : null,
                textAlign: 'left',
                left: 0,
                top: 0,
                font: {
                    fontFamily: ro.ui.fonts.rowBodyTxt,
                    fontSize: ro.ui.scaleFont(13)
                }
            }));
            ////Ti.API.debug('bodyHolder: ' + JSON.stringify(bodyHolder));
            rightVw.add(titleHolder);
            rightVw.add(bodyHolder);

            theRow.add(leftVw);
            theRow.add(rightVw);
            itemsData[idx] = theRow;
            //return theRow;
        }

        function addRow(rowDetails, isOdd) {
            //Ti.API.info('isOdd: ' + isOdd);
            var rowView,
                rowImg,
                label,
                imagePath = ro.ui.properties.defaultPath + 'coupon.png';

            //Ti.API.debug('rowDetails: ' + JSON.stringify(rowDetails));

            //var btnImage = ro.ui.properties.btnImg;
            var dynamicStr = rowDetails.isItem ? ('Select ' + (rowDetails.DisplayName ? rowDetails.DisplayName : rowDetails.ReceiptName)) : rowDetails.isPickAny || rowDetails.isReqAny ? 'Pick Any Item' : ('Choose ' + (rowDetails.DisplayName ? rowDetails.DisplayName : rowDetails.Name));
            var stepStr = 'Step ' + (rowDetails.stepIdx + 1);
            // + ' - ' + dynamicStr;
            var stepDetailString = dynamicStr;

            var rowVw = Ti.UI.createView({
                height: Ti.UI.FILL,
                bottom: ro.ui.relY(1),
                top: ro.ui.relY(1),
                width: Ti.UI.FILL,
                layout: 'horizontal',
                //backgroundImage:Ti.App.websiteURL+'/content/images/menu-item.png',
                backgroundColor: ro.ui.theme.cpnRowTileColor
            });
            var backgroundImg = Ti.UI.createView({
                //image:Ti.App.websiteURL+'/content/images/menu-item.png',
                //defaultImage:'/images/menuItemBg.png',
                height: Ti.UI.FILL,
                width: Ti.UI.FILL,
                zIndex: 3,
                touchEnabled: false
            });
            var strr = rowDetails.chosenPrefs.DisplayName ? rowDetails.chosenPrefs.DisplayName : (rowDetails.chosenPrefs.RcptName ? rowDetails.chosenPrefs.RcptName : rowDetails.chosenPrefs.Name);
            var lblFontSz = (stepStr && stepStr.length && stepStr.length > 30) || (rowDetails.inCart && strr && strr.length && strr.length > 20) ? ro.ui.scaleFontY(15, 14) : ro.ui.scaleFontY(17, 14);

            /*var leftVw = Ti.UI.createView({
             width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7,
             height: Ti.UI.FILL
             });
             var imageHolder = Ti.UI.createView({
             top: 0,
             left: 0,
             right: 0,
             bottom: ro.ui.relY(bottom)
             });
             imageHolder.add(Ti.UI.createImageView({
             image: isCoupon ? (ro.ui.properties.defaultPath + 'myDeals.png') : ( hasImg ? imgPath : group.ImageSource),
             defaultImage: ro.ui.properties.defaultImgPath,
             top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null, //ro.ui.relX(15),
             bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
             }));*/
            Ti.API.info('rowDetails.chosenPrefs.ImageSource: ' + rowDetails.chosenPrefs.ImageSource);
            var pickImageSource = rowDetails.chosenPrefs.ImageSource;
            if (ro.isiOS && !pickImageSource) {
                pickImageSource = (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png');

            }
            rowImg = Ti.UI.createImageView({
                image: rowDetails.isPickAny || rowDetails.isReqAny ? pickImageSource : rowDetails.ImageSource,
                //image:rowDetails.ImageSource,
                defaultImage: rowDetails.isPickAny || rowDetails.isReqAny ? (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png') : imagePath,
                OrigImage: rowDetails.isPickAny || rowDetails.isReqAny ? (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png') : rowDetails.ImageSource,
                //top:ro.ui.relY(25),
                top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null, //ro.ui.relX(15),
                bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
                //width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7//,
                //height:ro.ui.relX(70),
                //left:ro.ui.relX(5)
            });
            if (rowDetails.cpnDetails && rowDetails.cpnDetails.isSpecial) {
                Ti.API.info('rowDetails.cpnDetails.img: ' + rowDetails.cpnDetails.img);
                rowImg.image = rowDetails.cpnDetails.img;
                rowImg.OrigImage = rowDetails.cpnDetails.img;
                stepStr = 'Step ' + (rowDetails.stepIdx + 1);
                // + ' - ' + rowDetails.cpnDetails.str;
                stepDetailString = rowDetails.cpnDetails.str;
            }
            /*if(rowDetails.cpnDetails && rowDetails.cpnDetails.isSpecial){
             rowImg.image = rowDetails.cpnDetails.img;
             rowImg.OrigImage = rowDetails.cpnDetails.img;
             stepStr = 'Step ' + (rowDetails.stepIdx+1) + ' - ' + rowDetails.cpnDetails.str;
             }
             else if(rowDetails.cpnDetails && !rowDetails.cpnDetails.isSpecial && (!rowDetails.cpnDetails.img || !rowDetails.cpnDetails.img.length)){
             rowImg.image = (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png');
             rowImg.OrigImage = (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png');
             }*/

            label = Ti.UI.createLabel({
                toggle: function() {
                    label.parent.children[0].image = label.parent.children[0].OrigImage;
                    //rowImg.image = rowImg.OrigImage;
                    label.text = label.OrigText;
                },
                //text:(rowDetails.DisplayName) || (rowDetails.isItem ? rowDetails.ReceiptName : rowDetails.Name),
                text: stepStr,
                OrigText: stepStr,
                top: ro.ui.relY(15),
                left: ro.ui.relX(10),
                width: Ti.UI.SIZE,
                height: Ti.UI.FILL,
                right: ro.ui.relX(3),
                textAlign: 'left',
                color: ro.ui.theme.contentsSmallTxtHead,
                font: {
                    fontSize: lblFontSz,
                    fontWeight: 'bold',
                    fontFamily: ro.ui.fontFamily
                }
            });

            var leftVw = Ti.UI.createView({
                width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7,
                height: Ti.UI.FILL
            });
            var imageHolder = Ti.UI.createView({
                top: 0,
                left: 0,
                right: 0,
                bottom: ro.ui.relY(0)
            });
            imageHolder.add(rowImg);
            leftVw.add(imageHolder);
            rowVw.add(leftVw);
            //rowVw.label = label;
            //rowVw.add(rowVw.label);
            //rowVw.add(label);
            /*var labelTwo = Ti.UI.createLabel({
             text:stepDetailString,

             });*/

            var rightVw = Ti.UI.createView({
                //width: (ro.ui.displayCaps.platformWidth / 2) * (11 / 10),
                left: ro.ui.relX(5),
                width: Ti.UI.FILL,
                height: Ti.UI.SIZE//,
                //layout: 'vertical'
            });
            var titleHolder = Ti.UI.createView({
                height: ro.ui.relY(35),
                width: Ti.UI.FILL,
                //borderColor:'green',
                //borderWidth:1,
                top: 0,
                right: ro.isiOS ? ro.ui.relX(25) : ro.ui.relX(20)
            });
            titleHolder.add(Ti.UI.createLabel({
                text: stepStr,
                color: '#393839',
                textAlign: 'left',
                left: 0,
                right: 0,
                font: {
                    fontFamily: ro.ui.fonts.titles,
                    fontSize: ro.ui.scaleFont(27)
                    //fontWeight:'bold'
                }
            }));
            ////Ti.API.debug('titleHolder: ' + JSON.stringify(titleHolder));
            var bodyHolder = Ti.UI.createView({
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                top: ro.ui.relY(35),
                //borderColor:'red',
                //borderWidth:1,
                right: ro.isiOS ? ro.ui.relX(25) : ro.ui.relX(20)
            });
            bodyHolder.add(Ti.UI.createLabel({
                color: '#393839',
                text: stepDetailString,
                textAlign: 'left',
                left: 0,
                right: 0,
                //top: ro.ui.relY(35),
                font: {
                    fontFamily: ro.ui.fonts.rowBodyTxt,
                    fontSize: ro.ui.scaleFont(17)
                }
            }));
            ////Ti.API.debug('bodyHolder: ' + JSON.stringify(bodyHolder));
            rightVw.add(titleHolder);
            rightVw.add(bodyHolder);
            rowVw.add(rightVw);

            if (rowDetails.inCart) {
                //Ti.API.debug('rowDetails: ' + JSON.stringify(rowDetails));
                //Ti.API.debug('rowDetails.chosenPrefs.Name: ' + JSON.stringify(rowDetails.chosenPrefs.Name));
                //rowImg.image = rowDetails.chosenPrefs.

                label.text = 'Customize ' + strr;
                var rowChk = Ti.UI.createImageView({
                    right: ro.ui.relX(3),
                    height: ro.ui.relY(25),
                    image: '/images/check.png',
                    zIndex: 3,
                    touchEnabled: false
                });
                backgroundImg.checkMark = rowChk;
                backgroundImg.add(backgroundImg.checkMark);
            }

            grpRow = Ti.UI.createTableViewRow({
                specialIsItem: rowDetails.cpnDetails.isSpecial && rowDetails.cpnDetails.isItem ? true : false,
                isSpecialMulti: rowDetails.cpnDetails.isSpecialMulti ? true : false,
                height: ro.ui.relY(175),
                Name: rowDetails.isItem ? rowDetails.ReceiptName : rowDetails.Name,
                width: ro.ui.displayCaps.platformWidth,
                //rightImage:rowDetails.inCart?'/images/check.png':'',
                inCart: rowDetails.inCart ? true : false,
                preChosen: rowDetails.chosenPrefs,
                toggle: toggle,
                backgroundColor: isOdd ? '#f6f6f6' : 'white',
                separatorColor: 'transparent',
                selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            function toggle() {
                label.parent.children[0].image = label.parent.children[0].OrigImage;
                //rowImg.image = rowImg.OrigImage;
                label.text = label.OrigText;
            }

            if (grpRow.isSpecialMulti) {
                grpRow.gi = rowDetails.cpnDetails.gi;
            }
            if (grpRow.specialIsItem == true) {
                grpRow.ii = rowDetails.cpnDetails.ii;
                grpRow.gi = rowDetails.cpnDetails.gi;
            }
            if (rowDetails.isPickAny || rowDetails.isReqAny) {
                grpRow.Name = rowDetails.Name;
            }
            grpRow.add(backgroundImg);
            grpRow.add(rowVw);
            return grpRow;
        }

        function addToOrder(_callBackFn) {
            /*var alertView = Ti.UI.createView({
             height:ro.ui.relY(150),
             width:Ti.UI.FILL,
             layout:'vertical'
             });
             alertView.add(createAddOptions());
             alertView.addEventListener('click', function(e){
             try{
             if(e.index === 0 || e.index === 1){
             addCpnToCart(e.index);
             }
             additemAlert.hide();
             }
             catch(ex){
             if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('alertView-EventListener-Exception: ' + ex); }
             }
             });*/

            var alertVw = createAddOptions();
            alertVw.addEventListener('click', function(e) {

                if (e.source.index === -1 || e.index === -1) {
                    return;
                }
                if (e.index === 0 || e.index === 1) {
                    ro.windowpopup.hideWindowpopup();
                    addCpnToCart(e.index);
                }
                else{
                    ro.windowpopup.hideWindowpopup();
                }
                
            });

            ro.ui.alert(null, null, alertVw);

            /*var additemAlert = Ti.UI.createAlertDialog({
             androidView:alertView,
             title:'Please select an option:',
             height:Ti.UI.SIZE,
             width:'80%'
             });*/
            if (false && ro.isiOS) {
                additemAlert.cancel = 2;
                additemAlert.buttonNames = ['Add Coupon to Cart', 'Add Coupon and Checkout', 'Cancel'];
                additemAlert.addEventListener('click', function(e) {
                    if (e.index === 0 || e.index === 1) {
                        /*if(REV_Suggest.CheckForMatchingSuggItmOpts(itemObj, group)){
                         REV_Suggest.HHOfferSuggestion(FinishAddItem, e.index, itemObj.Size);
                         }
                         else{*/
                        addCpnToCart(e.index);
                        //}
                    }
                    additemAlert.hide();
                });
            }

            try {//This takes care of the _callback not firing when android:back is pressed
                if (!switchEventBool) {
                    _callBackFn();
                }
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('addToOrder()-Exception: ' + ex);
                }
            }

            //additemAlert.show();
        }

        function createAddOptions() {
            var alertRows = [];
            alertRows[0] = Ti.UI.createTableViewRow({
                height: ro.ui.relY(50),
                width: Ti.UI.FILL,
                selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            alertRows[0].add(Ti.UI.createLabel({
                text: 'Add Coupon to Cart',
                color: '#393839',
                font: {
                    //fontWeight:'bold',
                    fontSize: ro.ui.scaleFont(16, 0, 0),
                    fontFamily: ro.ui.fonts.alerts.body
                },
                textAlign: 'center'
            }));

            alertRows[1] = Ti.UI.createTableViewRow({
                height: ro.ui.relY(50),
                width: Ti.UI.FILL,
                selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            alertRows[1].add(Ti.UI.createLabel({
                text: 'Add Coupon and Checkout',
                color: '#393839',
                font: {
                    //fontWeight:'bold',
                    fontSize: ro.ui.scaleFont(16, 0, 0),
                    fontFamily: ro.ui.fonts.alerts.body
                },
                textAlign: 'center'
            }));

            alertRows[2] = Ti.UI.createTableViewRow({
                height: ro.ui.relY(50),
                width: Ti.UI.FILL,
                selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
            });
            alertRows[2].add(Ti.UI.createLabel({
                text: 'Cancel',
                color: '#393839',
                font: {
                    //fontWeight:'bold',
                    fontSize: ro.ui.scaleFont(16, 0, 0),
                    fontFamily: ro.ui.fonts.alerts.body
                },
                textAlign: 'center'
            }));
            var alertTable = Ti.UI.createTableView({
                data: alertRows,
                height: Ti.UI.SIZE,
                width: Ti.UI.FILL,
                backgroundColor: 'white',
                separatorColor: '#e4e4e4'
            });

            var alertVw = Ti.UI.createView(ro.isiOS ? ro.ui.properties.popupAlertView2ios : ro.ui.properties.popupAlertView2);
            /*Ti.UI.createView({
             layout:'vertical',
             height:Ti.UI.SIZE,
             width:Ti.UI.FILL,
             backgroundColor:'white',
             borderRadius:ro.ui.relX(15)
             });*/
            var headerRow = Ti.UI.createView({
                //touchEnabled:false,
                index: -1,
                height: ro.ui.relY(50),
                width: Ti.UI.FILL
            });
            var hdrLbl = Ti.UI.createLabel({
                text: 'Please select an option:',
                touchEnabled: false,
                font: {
                    fontFamily: ro.ui.fonts.alerts.title,
                    fontSize: ro.ui.scaleFont(28)
                },
                color: '#393839',
                width: Ti.UI.FILL,
                height: Ti.UI.SIZE,
                textAlign: 'center'
            });
            headerRow.add(Ti.UI.createView(ro.combine(ro.ui.properties.fullGreyBar, {
                bottom: 0,
                touchEnabled: false
            })));
            headerRow.add(hdrLbl);
            alertVw.add(headerRow);
            alertVw.add(alertTable);
            return alertVw;
        }

        function addCpnToCart(_eidx) {
            try {
                                Ti.API.debug('_eidx: ' + _eidx);
                if (ro.cpnHelper.validateCpn()) {
                    Ti.API.info('coupon Validated: ');
                    Ti.API.debug('cpnValcode: ' + cpnValcode);
                    
                    var isTempCpn = false;

                    var currentSubtotal = Ti.App.OrderObj.Subtotal || 0;
                    var selCoupon = ro.cpnHelper.getSelectedCpn();
                    if(selCoupon.MultiQualTtl && selCoupon.MultiQualTtl > 0){
                        var cpnMinPrice = selCoupon.MultiQualTtl;
                        
                        var cpnItemsArr = ro.cpnHelper.checkCart({
                            cpnKey: selCoupon.Key
                        });
                        
                        //var currItmIdx = -1;
                        Ti.API.info('cpnItemsArr: ' + JSON.stringify(cpnItemsArr));
                        var priceToSubtract = 0;
                        for(var i=0, iMax=cpnItemsArr.completedItems.length; i<iMax; i++){
                            Ti.App.OrderObj.Items[cpnItemsArr.completedItems[i].tempItem.orderObjItmIdx].realCpnKey = selCoupon.Key;
                            priceToSubtract += cpnItemsArr.completedItems[i].tempItem.RollupPrice;
                        }
                        /*for(var i=0, iMax=Ti.App.OrderObj.Items.length; i<iMax; i++){
                            if(cpnItemsArr.completedItems[0].tempItem === Ti.App.OrderObj.Items[i]){
                                Ti.API.info('THIS IS THE ITEM INDEX: ' + i);
                                currItmIdx = i;
                            }
                        }*/

                        if ((currentSubtotal - priceToSubtract).toFixed(2) < cpnMinPrice) {
                            Ti.API.info('priceToSubtract: ' + JSON.stringify(priceToSubtract));
                            //ro.cpnHelper.addTempCpn(cpnValcode);
                            //Ti.API.debug('coupon Added: ');
                            isTempCpn = true;
                            
                            /*ro.ui.popup('Coupon', ['OK'], (selCoupon.CpnDesc + ' coupon will be added to cart automatically when the minimum purchase requirements are met.'), function(e) {
                               //win.close();
                            });*/
                        }
                    }
                    
                    if(isTempCpn){
                        ro.ui.popup('Coupon', ['OK'], (selCoupon.CpnDesc + ' coupon will be added to cart automatically when the minimum purchase requirements are met.'), function(e) {
                           //win.close();
                           if(_eidx === 0 || _eidx === 1){
                               var test = Ti.App.OrderObj;
                                for(var i=0, iMax=cpnItemsArr.completedItems.length; i<iMax; i++){
                                    //priceToSubtract += cpnItemsArr.completedItems[i].tempItem.RollupPrice;
                                    test.Items[cpnItemsArr.completedItems[i].tempItem.orderObjItmIdx].tempCpnKey = selCoupon.Key;
                                    test.Items[cpnItemsArr.completedItems[i].tempItem.orderObjItmIdx].realCpnKey = selCoupon.Key;
                                }
                                Ti.App.OrderObj = test;
                                test = null;
                                Ti.API.info('selCoupon: ' + JSON.stringify(selCoupon));
                               
                               ro.cpnHelper.addCpn(cpnValcode, isTempCpn);
                                
                                var priceEngine = require('logic/pricing');
                                var func = priceEngine.pricer();
                                Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                                
                           }
                           
                           if (_eidx === 0) {
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'grpsItems'
                                });
                            }
                            else if (_eidx === 1) {
                                ro.ui.showLoader();
                                ro.ui.showCart();
                                ro.ui.hideLoader();
                            }
                        });
                    }
                    else{
                        ro.cpnHelper.addCpn(cpnValcode, isTempCpn);
                                
                                var priceEngine = require('logic/pricing');
                                var func = priceEngine.pricer();
                                Ti.App.OrderObj = func.RepriceOrder(Ti.App.OrderObj, ro.app.Store.Menu, Ti.App.OrderObj.OrdTypePriceIdx, (ro.app.Store.Surcharges || []));
                                
                        
                        if (_eidx === 0) {
                            ro.ui.ordShowNext({
                                addView: true,
                                showing: 'grpsItems'
                            });
                        }
                        else if (_eidx === 1) {
                            ro.ui.showLoader();
                            ro.ui.showCart();
                            ro.ui.hideLoader();
                        }
                    }
                }
                else {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('cpnHelper.validateCpn() Failed to Validate.');
                    }
                }
            }
            catch(ex) {
                ro.ui.hideLoader();
                Ti.API.info('AlertView-CouponValidation-Exception: ' + ex);
                ro.ui.alert('Error', 'Coupon Validation Error');
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('AlertView-CouponValidation-Exception: ' + ex);
                }
            }
        }

        function isBogo() {

        }

    };
    return {
        couponselectionview: couponselectionview
    };
}();
module.exports = COUPONSELECTIONVIEW; 