var GROUPSVIEW = function(){
	var groupsview = function(ro){
		ro.ui.creategrpsItemsView = function(_args){
		   //Ti.include('/revmobile/ui/menu/itemsView.js');
            Ti.API.info("This is grpsItemsView.js");
		   	
			if(!ro.app.Store){
			   //Ti.include('/controls/paymentControl.js');
			   require('controls/paymentControl');
			   //ro.app.Store = ro.app.Store;
			}
			try{
			   var menuUtils = require('logic/menuUtils');
	         var menuHelper = require('logic/menuHelper');
			   var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
	         var Groups = menuHelper.getGroups(ro.app.Store.Menu, timeAtStore);
	         
	         ro.cpnHelper.addAutoCpns(ro.app.Store);
	      }
	      catch(ex){
	         if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('ro.ui.creategrpsItemsView()-Exception: ' + ex); }
	      }
	
			ro.REV_LOYALTY.init();
	        ro.REV_LOYALTY.setCurrentLoyalty();
	
			var center = {
				x:ro.ui.relX(110),
				y:0
			};
			var prevSelectedGroup = null;
			var prevSelectedIndice = null;
			var curSelectedGroup = null;
			var n;
			var visibleView = ro.ui.relX(4);
			var grpItemViewWidth = ro.ui.relX(75);
			var customAlertView = ro.ca.createCustomAlert();
			var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
				name: 'grpsItems',
				hid:'grpsItems'
			}));
			var rs = {};
	      var custObj = ro.db.getCustObj(Ti.App.Username);
	
	
	
	
			var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
	            text: 'Menu'
	         }));
	         navBar.add(headerLbl);
	      } */
	
			var logoutBtn = layoutHelper.getLogoutBtn();
			logoutBtn.addEventListener('click', function(e){
			   ro.ui.ordShowNext({ showing:'ordTypeView' });
			});
			var backBtn = layoutHelper.getBackBtn('BACK');
			backBtn.addEventListener('click', function(e){
				if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length > 0){
					
                    ro.ui.popup('Warning: ', ['Cancel', 'OK'], 'You are about to leave the menu and this will reset your cart. Would you like to continue?', function(e) {
                        /*if (e.source.index === -1 || e.index === -1) {
                            return;
                        }

                        if (e.index === 1) {*/
                            ro.ui.ordShowNext({
                                showing: 'grpsItems'
                            });
                        //}

                        ro.windowpopup.hideWindowpopup();
                    }); 

				}
				else{
					ro.ui.ordShowNext({showing:'grpsItems'});
				}
			});
	
			n = Groups.length;
			//  Set order obj order type
            if (REV_ORD_TYPE.needsSpecificOrdType()) {
                REV_ORD_TYPE.promptForSpecificOrdType();
            }
            else {
                for (var i = 0; i < ro.app.Store.Menu.OnlineOptions.OrdTypes.length; i++) {
                    if (ro.app.Store.Menu.OnlineOptions.OrdTypes[i].IsDelivery == Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                        var test = Ti.App.OrderObj;
                        test.OrdType = ro.app.Store.Menu.OnlineOptions.OrdTypes[i].OrdType;
                        test.OrderTypeCategory = ro.app.Store.Menu.OnlineOptions.OrdTypes[i].OrderTypeCategory;
                        test.OrdTypePriceIdx = ro.app.Store.Menu.OnlineOptions.OrdTypes[i].OrdTypePriceIdx;
                        test.Menu = ro.app.Store.Menu.Name;
                        test.CurSplit = 0;
                        Ti.App.OrderObj = test;
                        test = null;
                        break;
                    }
                }
            }			
			navBar.add(backBtn);
			//navBar.add(logoutBtn);
			//mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			if(ro.isiphonex){
					var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
					var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
					var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
					navParent.add(topNav);
					bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
					navParent.add(bottomNav);
					mainView.add(navParent);
				}
				else{
					mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				}
	
			var grpView = Ti.UI.createView({
				height: ro.ui.relY(75),
				top: ro.ui.properties.topAfterNavbar,
				backgroundImage:ro.ui.properties.defaultPath + 'grpBackground.png'
			});
			var leftImage = Ti.UI.createView({
				backgroundImage:ro.ui.properties.defaultIconPath + 'icon_arrow_left.png',
				height: ro.ui.relX(20),
				width: ro.ui.relX(20),
				top: ro.ui.relY(35),
				left: ro.ui.relX(2),
				visible: false
			});
	
			grpView.add(leftImage);
			var rightImage = Ti.UI.createView({
				backgroundImage:ro.ui.properties.defaultIconPath + 'icon_arrow_right.png',
				height: ro.ui.relX(20),
				width: ro.ui.relX(20),
				top: ro.ui.relY(35),
				right: ro.ui.relX(2)
			});
	
			grpView.add(rightImage);
	
	     // Ti.API.debug('contentWidth(n+2): ' + (ro.ui.relX(75) * (n+2)));
			var grpsScroll = Ti.UI.createScrollView({
				contentWidth: ro.ui.relX(75) * (n + 2),
				disableBounce: ro.isiOS ? true : false,
				contentHeight: ro.ui.relY(75),
				top: ro.ui.relY(2),
				height: ro.ui.relY(75),
				width: ro.isiOS ? Ti.UI.FILL : Ti.UI.SIZE,
				borderRadius: 10,
				backgroundColor: 'transparent',
				scrollType: 'horizontal'
			});
	
			grpsScroll.addEventListener('click', function(e){
	         if(e.source.label){
	
	            curSelectedGroup = e.source.label;
	            var parent = e.source.parent;
	            var diff = center.x - parent.left;
	            grpsScroll.scrollTo(-diff, 0);
	
	            if(e.source.label != prevSelectedGroup){
	               e.source.animate({
	                  transform:Ti.UI.create2DMatrix().scale(1),
	                  duration:200
	               },
	               function(){
	                  ro.ui.refreshItems(curSelectedGroup);
	               });
	
	               grpsScroll.children[prevSelectedIndice].children[0].animate({
	                  transform:Ti.UI.create2DMatrix().scale(0.8),
	                  duration:200
	               });
	               prevSelectedGroup = e.source.label;
	               prevSelectedIndice = e.source.parent.indice;
	            }
	
	            if(itemsView.visible == false){
	               defaultLabel.visible = false;
	               itemsView.visible = true;
	            }
	         }
	      });
	
			grpsScroll.addEventListener('scroll', function(e){
				if(e.x > ro.ui.relX(50)){
					leftImage.show();
				}
				else{
					leftImage.hide();
				}
	
				if(e.x > ((n - displayableItems) + 1.6) * grpItemViewWidth){
					rightImage.hide();
				}
				else{
					rightImage.show();
				}
			});
			var showLoyalty = 0;
			var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
	      if(false && currentLoyalty.isHC && currentLoyalty.showHcTab(ro.app.Store.Configuration)){
	         //currentLoyalty.addLoyaltyCodes(Ti.App.OrderObj.Cpns);
	         var loyaltyView = Ti.UI.createView({
	            name:'My Rewards',
	            indice:0,
	            left:ro.ui.relX(5),
	            width:ro.ui.relX(80),
	            height:ro.ui.relY(85),
	            top:0,
	            borderRadius:6
	         });
	      
	         //create a button for the group
	         var loyaltyButton = Ti.UI.createImageView({
	            //image:'/images/loyalty.png',
	            image:Ti.App.websiteURL + '/content/images/myltyaccount.png',
	            defaultImage:'/images/default.png',
	            label:'My Rewards',
	            width:ro.ui.relX(55),
	            height:ro.ui.relX(55),
	            top:ro.ui.relY(15),
	            borderRadius:6
	         });
	      	 var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
		     var rewardsDisplayName = cfg.LTY_ACCT_HDR && cfg.LTY_ACCT_HDR.length ? cfg.LTY_ACCT_HDR : 'My Reward Account';
		     
	         var loyaltyLabel = Ti.UI.createLabel({
	            text:rewardsDisplayName,
	            top:0,
	            textAlign:'center',
	            width:ro.ui.relX(57),
	            height:ro.ui.relY(15),
	            color:ro.ui.theme.grpItemColor,
	            font:{
	               fontSize:ro.ui.scaleFontY(11,14),
	               fontWeight:'bold',
	               fontFamily:ro.ui.fontFamily
	            }
	         });
	      
	         loyaltyButton.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
	         loyaltyView.add(loyaltyButton);
	         loyaltyView.add(loyaltyLabel);
	         //loyaltyIndice = 0;
	         //indiceExtra++;
	         grpsScroll.add(loyaltyView);
	         showLoyalty = 1;
	         
	         
	         //favoriteIndice = 2;
	      }
	
			var favOrdView = Ti.UI.createView({
	         name:'Orders',
	         indice:showLoyalty,
	         left:(ro.ui.relX(5) + (showLoyalty*ro.ui.relX(75))),
	         width:ro.ui.relX(80),
	         height:ro.ui.relY(85),
	         top:0,
	         borderRadius:6
	      });
	
	      //create a button for the group
	      var favOrdButton = Ti.UI.createImageView({
	         image:ro.ui.properties.defaultPath + 'favorite.png',
	         label:'Orders',
	         width:ro.ui.relX(55),
	         height:ro.ui.relX(55),
	         top:ro.ui.relY(15),
	         borderRadius:6
	      });
	
		  var storeObj = ro.app.Store;
	 	  var dispName = 'My Orders';
	 	  if(storeObj && storeObj.Configuration && storeObj.Configuration.MY_ORD_HDR && storeObj.Configuration.MY_ORD_HDR.length){
	 		 dispName = storeObj.Configuration.MY_ORD_HDR;
	 	  }
	      var favOrdLabel = Ti.UI.createLabel({
	         text:dispName,
	         top:0,
	         textAlign:'center',
	         width:ro.ui.relX(57),
	         height:ro.ui.relY(15),
	         color:ro.ui.theme.grpItemColor,
	         font:{
	            fontSize:ro.ui.scaleFontY(11,14),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }
	      });
	
	      favOrdButton.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
	      favOrdView.add(favOrdButton);
	      favOrdView.add(favOrdLabel);
	      
	      var indiceExtra = 0, favoriteIndice = 0, cpnIndice = 0, loyaltyIndice = 0;
	      var ltyIndice = 0, cpnIndice = 0, favIndice = 0;
	      
	      if(!ro.REV_GUEST_ORDER.getIsGuestOrder() && custObj.PrevOrders && custObj.PrevOrders.length){
	         indiceExtra++;
	         grpsScroll.add(favOrdView);
	         favoriteIndice = 1;
	      }
	
			var cpnView = Ti.UI.createView({
				name:'Coupons',
				indice:indiceExtra==0?0:1,
				left:indiceExtra ? (ro.ui.relX(80) + (ro.ui.relX(75) * showLoyalty)) : (ro.ui.relX(5) + (ro.ui.relX(75) * showLoyalty)),
				width:ro.ui.relX(80),
				height:ro.ui.relY(85),
				top:0,
				borderRadius:6
	
			});
			if(showLoyalty){
			   cpnView.indice = cpnView.indice+1;
			   indiceExtra = indiceExtra+1;
			}
	
			//create a button for the group
			var cpnButton = Ti.UI.createImageView({
				image:ro.ui.properties.defaultPath + 'coupon.png',
				label:'Coupons',
				width:ro.ui.relX(55),
				height:ro.ui.relX(55),
				top:ro.ui.relY(15),
				borderRadius:6
			});
	
			var cpnLabel = Ti.UI.createLabel({
				text:'Coupons',
				top:0,
				textAlign:'center',
				width:ro.ui.relX(57),
				height:ro.ui.relY(15),
				color:ro.ui.theme.grpItemColor,
				font:{
					fontSize:ro.ui.scaleFontY(11, 14),
					fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
				}
			});
	
			cpnButton.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
			cpnView.add(cpnButton);
			cpnView.add(cpnLabel);
			var noCpns = true;
			if(menuUtils.hasDispCoupons()){
			   noCpns = false;
			   indiceExtra++;
			   grpsScroll.add(cpnView);
			}
			
			//grpsScroll.contentWidth = (ro.ui.relX(75) * (n + indiceExtra));
			//Ti.API.debug('contentWidth(n+2): ' + (ro.ui.relX(75) * (n+indiceExtra)));
	
	
			var grpName;
	      var imagePath = ro.ui.properties.defaultPath + 'default.png';
	      var startLoc = indiceExtra == 3 ? ro.ui.relX(233) : indiceExtra == 2 ? ro.ui.relX(155) : (indiceExtra == 1 ? ro.ui.relX(78) : 0);
	      
	      //Groups = Groups.concat(Groups);
	      
	      var GrpLngth = Groups.length;
			for(var i=0; i < GrpLngth; i++){
				grpName = Groups[i].Name;
	
				var view = Ti.UI.createView({
					name: grpName,
					//indice:(i+2),
					indice:(i+indiceExtra),
					left: startLoc + (ro.ui.relX(75) * i),
					width: ro.ui.relX(80),
					height: ro.ui.relY(85),
					top: 0,
					borderRadius: 6
	
				});
				//create a button for the group
				var button = Ti.UI.createImageView({
					image:Groups[i].HasImage?Groups[i].ImageSource:imagePath,
					defaultImage:'/images/default.png',
					label:grpName,
					width:ro.ui.relX(55),
					height:ro.ui.relX(55),
					top:ro.ui.relY(15),
					borderRadius:6,
					zIndex:100
	
				});
				var labelTxt = Groups[i].DisplayName || Groups[i].Name || '';
	
				var label = Ti.UI.createLabel({
					text:labelTxt,
					top:0,
					textAlign:'center',
					//width:ro.ui.relX(57),
					width:Ti.UI.SIZE,
					height:ro.ui.relY(15),
					color:ro.ui.theme.grpItemColor,
					zIndex:200,
					font:{
						//fontSize:labelTxt.length>9 ? ro.ui.scaleFontY(9,14) : ro.ui.scaleFontY(11,14),
						fontSize:ro.ui.scaleFontY(11,14),
						fontWeight:'bold',
	            		fontFamily:ro.ui.fontFamily
					}
				});
				if(label.text && label.text.length && label.text.length > 9){
					//Ti.API.debug('large label');
					 //label.font.fontSize = ro.ui.scaleFontY(9,14);
					//label.height = Ti.UI.SIZE;
					label.ellipsize = Ti.UI.TEXT_ELLIPSIZE_TRUNCATE_END;
				}
	
				button.animate({transform:Ti.UI.create2DMatrix().scale(0.8)});
				view.add(button);
				view.add(label);
	
				grpsScroll.add(view);
			}
	
			var scrollPadding = Ti.UI.createView({
				width:Ti.UI.FILL,
				left:ro.ui.relX(25),
				right:ro.ui.relX(25)
			});
	
			scrollPadding.add(grpsScroll);
			grpView.add(scrollPadding);
			mainView.add(grpView);
	
			var displayableItems = (ro.ui.displayCaps.platformWidth - scrollPadding.left - scrollPadding.right)/grpItemViewWidth;
			
			if(displayableItems > (GrpLngth + indiceExtra)){
			   rightImage.visible = false;
			}
	
			try{
				var itemsView = ro.ui.createItemsView();
			}
			catch(e){
				ro.ui.alert('items', e);
			}
			mainView.add(itemsView);
			mainView.add(customAlertView);
	
			function chkFirstOLOrder(){
			  var CpnIdx;
	  		  Ti.App.firstOLOrdCpnExists = false;
	 		  for (CpnIdx = 0; CpnIdx < ro.app.Store.Menu.Cpns.length; CpnIdx++) {
				 if (ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All'){
					if (ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER' || ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST MOBILE ORDER'){
						if(Ti.App.LastOrdCnt == 0){
							Ti.App.firstOLOrdCpnExists = true;
						}
					break;
					}
				}
			  }
			}
		   chkFirstOLOrder();
		   
		   function addFOLCoupon(coupon){
		   	   var storeObj = ro.app.Store;
	    	   var cpnObj = {};
	    	   var Ord = Ti.App.OrderObj;
	
	    	   if(!Ord.Cpns){
	    	      Ord.Cpns = [];
	    	   }
	
	    	   cpnObj.CpnValue = coupon.CpnValue;
	    	   cpnObj.RcptName = coupon.RcptName;
	    	   cpnObj.Name = coupon.Name;
	    	   cpnObj.CpnScope = coupon.CpnScope;
	    	   cpnObj.CpnType = coupon.CpnType;
	    	   cpnObj.CpnPct = coupon.CpnPct;
	    	   cpnObj.MinPrice = coupon.MinPrice;
	    	   cpnObj.MaxValue = coupon.MaxValue;
	    	   cpnObj.AdjItemPrice = coupon.AdjItemPrice;
	    	   cpnObj.TaxType = coupon.TaxType;
	    	   cpnObj.ReportGrp = coupon.ReportGrp;
	    	   cpnObj.FreeDlvy = coupon.FreeDlvy;
	    	   cpnObj.LeaveTax = coupon.LeaveTax;
	    	   cpnObj.No2ndItm = coupon.No2ndItm;
	    	   cpnObj.BeatClock = coupon.BeatClock;
	    	   var curDate = new Date();
	    	   var UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
	    	   cpnObj.TimeApplied = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	    	   cpnObj.TimeAppliedStr = new Date(UTCTime + (storeObj.TimeZone * 3600000));
	    	   cpnObj.IsExclusive = coupon.IsExclusive;
	    	   cpnObj.MaxModValue = coupon.MaxModValue;
	    	   Ord.Cpns.push(cpnObj);
	    	   Ti.App.OrderObj = Ord;
	    	   //ro.ui.reloadCart();
	    	}
	
	    	function firstOnlineOrder(){
	    	   var storeObj = ro.app.Store;
	    	   var CpnIdx;
	    	   for(CpnIdx=0; CpnIdx<storeObj.Menu.Cpns.length; CpnIdx++){
	    	      if(storeObj.Menu.Name == storeObj.Menu.Cpns[CpnIdx].Menu || storeObj.Menu.Cpns[CpnIdx].Menu == 'All'){
	    	         if(storeObj.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER'){
	    	            addFOLCoupon(storeObj.Menu.Cpns[CpnIdx]);
	    	            Ti.App.firstOLOrdCpnApplied = true;
	    	            /*var firstOLOrder = Ti.UI.createAlertDialog();
	    	            firstOLOrder.title = 'FIRST ONLINE ORDER';
	    	            firstOLOrder.buttonNames = ['OK'];
	    	            firstOLOrder.message = storeObj.Menu.Cpns[CpnIdx].CpnDesc;
	    	            firstOLOrder.show();*/
	    	            ro.ui.popup('FIRST ONLINE ORDER', ['OK'], storeObj.Menu.Cpns[CpnIdx].CpnDesc, function(e) {
                            //win.close();
                        });
	    	            break;
	    	         }
	    	      }
	    	   }
	    	}
		   
		   /*if(Ti.App.firstOLOrdCpnExists && !Ti.App.firstOLOrdCpnApplied && !isGuest){
	          firstOnlineOrder();
	       }*/
	
	      //var indiceExtra = 0, favoriteIndice = 0, cpnIndice = 0;
	      var grpIndice = indiceExtra;
	
			//Ti.include('/logic/prevOrders.js');
			if(showLoyalty){
			   grpsScroll.children[0].children[0].animate({
	            transform:Ti.UI.create2DMatrix().scale(1),
	            duration:200
	         });
	         curSelectedGroup = grpsScroll.children[0].children[0].label;
	         prevSelectedGroup = grpsScroll.children[0].children[0].label;
	         prevSelectedIndice = grpsScroll.children[0].children[0].parent.indice;
	
	         try{
	            ro.ui.refreshItems(curSelectedGroup);
	         }
	         catch(e){
	            ro.ui.alert('grpsItemsView.js - ro.ui.refreshItems() - Exception: ', ' CODE 100');
	         }
			}
			else if(grpsScroll.children.length > 0 && !ro.REV_GUEST_ORDER.getIsGuestOrder() && custObj.PrevOrders && custObj.PrevOrders.length > 0){
			   grpsScroll.children[favoriteIndice].children[0].animate({
	            transform:Ti.UI.create2DMatrix().scale(1),
	            duration:200
	         });
	         curSelectedGroup = grpsScroll.children[favoriteIndice].children[0].label;
	         prevSelectedGroup = grpsScroll.children[favoriteIndice].children[0].label;
	         prevSelectedIndice = grpsScroll.children[favoriteIndice].children[0].parent.indice;
	
	         try{
	            ro.ui.refreshItems(curSelectedGroup);
	         }
	         catch(e){
	            ro.ui.alert('grpsItemsView.js - ro.ui.refreshItems() - Exception: ', ' CODE 100');
	         }
	      }
			else if(grpsScroll.children.length > 0 && !noCpns && ro.app.Store.Menu.Cpns.length > 0){
				grpsScroll.children[favoriteIndice].children[0].animate({
					transform:Ti.UI.create2DMatrix().scale(1),
					duration:200
				});
				curSelectedGroup = grpsScroll.children[favoriteIndice].children[0].label;
				prevSelectedGroup = grpsScroll.children[favoriteIndice].children[0].label;
				prevSelectedIndice = grpsScroll.children[favoriteIndice].children[0].parent.indice;
	
				try{
					ro.ui.refreshItems(curSelectedGroup);
				}
				catch(e){
					ro.ui.alert('grpsItemsView.js - ro.ui.refreshItems() - Exception: ', ' CODE 100');
				}
			}
			else if(grpsScroll.children.length > 1){
				grpsScroll.children[grpIndice].children[0].animate({
				   transform:Ti.UI.create2DMatrix().scale(1),
				   duration:200
				});
				curSelectedGroup = grpsScroll.children[grpIndice].children[0].label;
				prevSelectedGroup = grpsScroll.children[grpIndice].children[0].label;
				prevSelectedIndice = grpsScroll.children[grpIndice].children[0].parent.indice;
	
				try{
					ro.ui.refreshItems(curSelectedGroup);
				}
				catch(e){
					ro.ui.alert('grpsItemsView.js - ro.ui.refreshItems() - Exception: ', ' CODE 100');
				}
			}
			else if(grpsScroll.children.length == 1){
				//Ti.API.debug('it === 1');
				grpsScroll.children[grpIndice].children[0].animate({
				   transform:Ti.UI.create2DMatrix().scale(1),
				   duration:200
				});
				curSelectedGroup = grpsScroll.children[grpIndice].children[0].label;
				prevSelectedGroup = grpsScroll.children[grpIndice].children[0].label;
				prevSelectedIndice = grpsScroll.children[grpIndice].children[0].parent.indice;
	
				try{
					ro.ui.refreshItems(curSelectedGroup);
				}
				catch(e){
					ro.ui.alert('grpsItemsView.js - ro.ui.refreshItems() - Exception: ', ' CODE 100');
				}
			}
			//Ti.API.debug('grpsScroll.children[0]: ' + JSON.stringify(grpsScroll.children[0]));
			ro.REV_STORES.setChosenStoreId(ro.app.Store.ID);
			
			var checkForBannerCode = function(e){
				////deb.ugg(e, 'e', e.length);
				/*for(var item in e){
					Ti.API.debug('item: ' + item); 
				}
				for(var item in e.source){
					Ti.API.debug('e.source - item: ' + item); 
				}*/
				//Ti.API.debug('checkForBannerCode - E' + JSON.stringify(e));
				mainView.removeEventListener('postlayout', checkForBannerCode);
				
				if(Ti.App.firstOLOrdCpnExists && !Ti.App.firstOLOrdCpnApplied && !isGuest){
		          firstOnlineOrder();
		        }
		        else{
		        	var bannerCode = REV_BANNERS.getSelectedBannerCode(); 
					if(bannerCode && bannerCode.length){
						menuUtils.testCpnCode(bannerCode, true, false);
					}
					else if(currentLoyalty && currentLoyalty.isHC){
						var currCode = currentLoyalty.getTempCode();
						//Ti.API.debug('currCode: ' + currCode);
						if(currCode && currCode.length){
							ro.REV_LOYALTY.validateCoupon(currCode, ro.app.Store.ID, function(){
				     			  ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
				     			  ro.ui.hideLoader();
				     		}, null, function(cpnCode, LoyaltyCode){
				     			//Ti.API.debug('LoyaltyCode: ' + LoyaltyCode);
				     			menuUtils.testCpnCode(cpnCode, true, true, LoyaltyCode, function(msg){
				     				var title = 'Success!';
				     				ro.ui.alert(title, msg);
				     				
				     				//globalSetBadge();
				     			});
				     		});
						}
					}
		        }
			};
			mainView.addEventListener('postlayout', checkForBannerCode);
			
			return mainView;
		};
	};
	return {
		groupsview:groupsview
	};
}();
module.exports = GROUPSVIEW;