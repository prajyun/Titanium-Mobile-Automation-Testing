exports.getMainView = function(hid, title){
	var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {
		name:hid,
		hid:hid
	}));
	var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	if(title && title.length){
		headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
			text:title
		}));
		navBar.add(headerLbl);
	}
	var addItmBtn = Ti.UI.createButton(ro.combine(ro.ui.properties.logoutBtn, {
		backgroundImage:ro.ui.properties.defaultPath + 'additem.png',
		backgroundSelectedImage:ro.ui.properties.defaultPath + 'additemPress.png',
		title: 'Add Item'
	}));
	var backBtn = Ti.UI.createButton(ro.ui.properties.backBtn);
	backBtn.addEventListener('click', function(e){
		ro.ui.ordShowNext({showing:mainView.hid});
	});
	navBar.add(addItmBtn);
	navBar.add(backBtn);
	mainView.add(navBar);
	return mainView;
};
exports.getNoOptionView = function(){
	var noOptionView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
	   name:'No Options',
	   height:Ti.UI.FILL,
	   top:0,
	   left:0,
	   right:0,
	   width:Ti.UI.FILL
	}));
	var noOptionLbl = Ti.UI.createLabel({
		text:'Click "Add Item" to add this item to the cart.',
		font:{
			fontSize:ro.ui.scaleFontY(14,49),
			fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
		},
		textAlign:'center',
		width:ro.ui.relX(200),
		height:ro.ui.relY(50),
		color:ro.ui.theme.textColor
	});
	noOptionView.add(noOptionLbl);
	return noOptionView;
};
exports.getExtraQty = function(event, newTry, defQtyAllowed, UseModQtyTxt, AllowLite){
	
	var widthNum = defQtyAllowed;
	var totalWidthNum = 4;
	if(AllowLite){
		totalWidthNum += 1;
		widthNum += 1;
	}
		
	var c = Ti.UI.createView({
      bubbleParent:false,
      left:ro.ui.relX(5),
      height:ro.ui.relY(30),
      bottom:ro.ui.relY(5),
      //width:ro.ui.relX(95),
      //width:widthNum * ro.ui.relX(35.1),
      width:Ti.UI.SIZE,
      backgroundColor:'transparent',
      layout:'horizontal',
      borderWidth:ro.ui.relX(1),
      borderRadius:ro.ui.relX(6),
      borderColor:ro.ui.theme.extraQtyBorder,
      viewType:'parent',
      visible:false
   });
   c.toggle = function(selIdx, IsLite){
   	  if(IsLite){
   	  	selIdx = 0;
   	  }
   	  
      for(var i=0; i<c.children.length; i++){
         if(c.children[i].index === selIdx){
            c.children[i].backgroundColor = ro.ui.theme.extraQtyBackgroundActive;
            c.children[i].clicked = true;
            c.children[i].children[0].color = ro.ui.theme.extraQtyTxtActive;
         }
         else{
            c.children[i].clicked =false;
            c.children[i].backgroundColor = ro.ui.theme.extraQtyBackgroundDefault;
            c.children[i].children[0].color = ro.ui.theme.extraQtyTxtDefault;
         }
      }
   };

		var defIdx = 0;
		var lbls = UseModQtyTxt ? ['x1', 'x2', 'x3', 'x4'] : ['Nml', 'Xtra', 'x3', 'x4'];
		lbls = lbls.splice(0, defQtyAllowed);
		if(AllowLite){
			lbls = ['Lite'].concat(lbls);
			defIdx = 1;
		}
		
		if(lbls && lbls.length > 1){
			c.visible = true;
		}
		if(lbls && lbls.length){
			for(var i=0, iMax=lbls.length; i<iMax; i++){
				var idx = AllowLite ? i : i+1;
				var qtyView = Ti.UI.createView({
			      viewType:'child',
			      title:lbls[i],
			      index:idx,
			      height:Ti.UI.FILL,
			      width:ro.ui.relX(35),
			      borderWidth:ro.ui.relX(1),
			      borderColor:ro.ui.theme.extraQtyBorder,
			      backgroundColor:defIdx != i?ro.ui.theme.extraQtyBackgroundDefault:ro.ui.theme.extraQtyBackgroundActive,
			      clicked:defIdx != i?false:true
			  });
			  qtyView.add(Ti.UI.createLabel({
			  	text:lbls[i],
			  	viewType:'grandchild',
			
			  	color:defIdx != i?ro.ui.theme.extraQtyTxtDefault:ro.ui.theme.extraQtyTxtActive,
			  	font:{
			  	   fontWeight:'bold',
			  	   fontSize:ro.ui.scaleFont(12),
			  	   fontFamily:ro.ui.fontFamily
			  	},
			  	index:idx,
			  	touchEnabled:false
			  }));
			  c.add(qtyView);
			}
		}
  
  		function getHalfOptions(rw){
			var halfBlock = rw.children[1].children[0];
			var returnBool = 0;
			for(var i=0; i<halfBlock.children.length; i++){
				if(halfBlock.children[i].clicked){
					returnBool = halfBlock.children[i].idx;
					break;
				}
			}
			return returnBool;
		}
  
  c.addEventListener('click', function(e){
   	 var tblRow = e.source.parent.parent.parent;
   	 if(e.source.clicked){
   	 	return;
   	 }

       var parView;
   	 if(e.source.viewType === 'child'){
   	    parView = e.source.parent;
   	 }
   	 else if(e.source.viewType === 'grandchild'){
   	    parView = e.source.parent.parent;
   	 }
   	 else{
   	    parView = e.source;
   	 }

   	 parView.toggle(e.source.index);
   	 var hlf = 0;
   	 try{
   	    hlf = getHalfOptions(tblRow);
   	 }
   	 catch(ex){
   	    hlf = 0;
   	    if(Ti.App.DEBUGBOOL){ Ti.API.debug('extraQty.eventListener-Exception: ' + ex); }
   	 }
   	 if(!hlf){
   	    hlf = 0;
   	 }

	 if(tblRow.isPrefMods){
	 	ro.itemObj.setPrefMods(e.source.parent.name, hlf, tblRow.isPreselected, e.source.index, ro.app.Store.Menu.Groups[tblRow.gIdx], tblRow.prefName);
	 }
	 else{
	 	ro.itemObj.setMods(e.source.parent.name, hlf, tblRow.isPreselected, e.source.index);
	 }
   	 

   });
   return c;
};
exports.getNewExtraQty = function(event, newTry, defQtyAllowed, UseModQtyTxt, AllowLite){
	
	var widthNum = defQtyAllowed;
	var totalWidthNum = 4;
	if(AllowLite){
		totalWidthNum += 1;
		widthNum += 1;
	}
		
	var c = Ti.UI.createView({
      bubbleParent:false,
      left:ro.ui.relX(10),
      height:ro.ui.relY(30),
      bottom:ro.ui.relY(5),
      width:Ti.UI.SIZE,
      backgroundColor:'transparent',
      layout:'horizontal',
      viewType:'parent',
      visible:false,
      toggleQty:toggleQty,
      ignoreclick:true
      //touchEnabled:false
   });
   function toggleQty(selIdx, IsLite){
   	  if(IsLite){
   	  	selIdx = 0;
   	  }
   	  
      for(var i=0; i<c.children.length; i++){
         if(c.children[i].index === selIdx){
            c.children[i].backgroundColor = ro.ui.theme.newextraQtyBackgroundActive;
            c.children[i].borderColor =  ro.ui.theme.newextraQtyBackgroundActive;
            c.children[i].clicked = true;
            c.children[i].children[0].color = ro.ui.theme.newextraQtyTxtActive;
         }
         else{
            c.children[i].clicked =false;
            c.children[i].backgroundColor = ro.ui.theme.newextraQtyBackgroundDefault;
            c.children[i].borderColor =  '#e4e4e4';
            c.children[i].children[0].color = ro.ui.theme.newextraQtyTxtDefault;
         }
      }
   };

		var defIdx = 0;
		var lbls = UseModQtyTxt ? ['x1', 'x2', 'x3', 'x4'] : ['Nml', 'Xtra', 'x3', 'x4'];
		lbls = lbls.splice(0, defQtyAllowed);
		if(AllowLite){
			lbls = ['Lite'].concat(lbls);
			defIdx = 1;
		}
		
		if(lbls && lbls.length > 1){
			c.visible = true;
		}
		if(lbls && lbls.length){
			for(var i=0, iMax=lbls.length; i<iMax; i++){
				var idx = AllowLite ? i : i+1;
				var qtyView = Ti.UI.createView({
			      viewType:'child',
			      title:lbls[i],
			      index:idx,
			      height:Ti.UI.FILL,
			      width:ro.isiOS ? (ro.ui.displayCaps.platformWidth / 6.5) : (ro.ui.displayCaps.platformWidth / 6),//ro.ui.relX(55),
			      left:ro.ui.relX(3),
			      borderRadius:ro.ui.relX(15),
			      borderWidth:ro.ui.relX(2),
			      borderColor:defIdx != i ? ro.ui.theme.newextraQtyBorder : ro.ui.theme.newextraQtyBackgroundActive,
			      backgroundColor:defIdx != i?ro.ui.theme.newextraQtyBackgroundDefault:ro.ui.theme.newextraQtyBackgroundActive,
			      clicked:defIdx != i?false:true
			  });
			  qtyView.add(Ti.UI.createLabel({
			  	text:lbls[i],
			  	viewType:'grandchild',
			
			  	color:defIdx != i?ro.ui.theme.newextraQtyTxtDefault:ro.ui.theme.newextraQtyTxtActive,
			  	font:{
			  	   //fontWeight:'bold',
			  	   fontSize:ro.ui.scaleFont(14),
			  	   fontFamily:ro.ui.fonts.rowBodyTxt
			  	},
			  	index:idx,
			  	touchEnabled:false
			  }));
			  c.add(qtyView);
			}
		}
  
  		function getHalfOptions(rw){
  			if(rw.children[1].children.length < 2){
  				return 0;
  			}
			var halfBlock = rw.children[1].children[1];
			var returnBool = 0;
			for(var i=0; i<halfBlock.children.length; i++){
				if(halfBlock.children[i].clicked){
					returnBool = halfBlock.children[i].idx;
					break;
				}
			}
			return returnBool;
		}
  
  c.addEventListener('click', function(e){
  	 if(e.source.ignoreclick){
  	 	return;
  	 }
   	 var tblRow = e.source.parent.parent.parent;
   	 if(e.source.clicked){
   	 	return;
   	 }

       var parView;
   	 if(e.source.viewType === 'child'){
   	    parView = e.source.parent;
   	 }
   	 else if(e.source.viewType === 'grandchild'){
   	    parView = e.source.parent.parent;
   	 }
   	 else{
   	    parView = e.source;
   	 }

   	 parView.toggleQty(e.source.index);
   	 var hlf = 0;
   	 try{
   	    hlf = getHalfOptions(tblRow);
   	 }
   	 catch(ex){
   	    hlf = 0;
   	    if(Ti.App.DEBUGBOOL){ Ti.API.debug('extraQty.eventListener-Exception: ' + ex); }
   	 }
   	 if(!hlf){
   	    hlf = 0;
   	 }

	 if(tblRow.isPrefMods){
	 	ro.itemObj.setPrefMods(e.source.parent.name, hlf, tblRow.isPreselected, e.source.index, ro.app.Store.Menu.Groups[tblRow.gIdx], tblRow.prefName);
	 }
	 else{
	 	ro.itemObj.setMods(e.source.parent.name, hlf, tblRow.isPreselected, e.source.index);
	 }
   	 

   });
   return c;
};

exports.getOptionsBlock = function(btnAction){
	var optionsView = Ti.UI.createView({
		height:ro.ui.relY(55),
		width:Ti.UI.SIZE,
		borderColor:'black',
		borderWidth:ro.ui.relX(1),
		layout:'horizontal',
		bubbleParent:'false'
	});

	return optionsView;
};
exports.getToppingsBlock = function(_event, _event2, rowName, halfOptFlag, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite, isVisible){
	if(halfOptFlag){
		var view = Ti.UI.createView({
			isHalfOptViewChild:true,
			height:Ti.UI.SIZE,
			width:ro.ui.relX(140),
			layout:'horizontal',
			bubbleParent:false,
			left:ro.ui.relX(5),
	      isImg:false,
	      isHalf:true
	   });
		var halfOne = Ti.UI.createView({
			height:ro.ui.relY(35),
			width:ro.ui.relX(35),
			backgroundImage:'/images/halfone.png',
			onImg:'/images/halfoneChosen.png',
			offImg:'/images/halfone.png',
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			clicked:false,
			eventIdx:0,
	      idx:1,
	      isImg:true
		});
		var full = Ti.UI.createView({
			height:ro.ui.relY(35),
			width:ro.ui.relX(35),
			backgroundImage:'/images/fullChosen.png',
			onImg:'/images/fullChosen.png',
			offImg:'/images/full.png',
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			clicked:true,
			eventIdx:1,
	      idx:0,
	      isImg:true
		});
		var halfTwo = Ti.UI.createView({
			height:ro.ui.relY(35),
			width:ro.ui.relX(35),
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			backgroundImage:'/images/halftwo.png',
			onImg:'/images/halftwoChosen.png',
			offImg:'/images/halftwo.png',
			clicked:false,
			eventIdx:2,
			idx:2,
			isImg:true
		});
		view.add(halfOne);
		view.add(full);
		view.add(halfTwo);
		view.toggle = function(selIdx){
		   for(var i=0; i<3; i++){
		      if(view.children[i].idx === selIdx){
		         view.children[i].backgroundImage = view.children[i].onImg;
		         view.children[i].clicked = true;
		      }
		      else{
		         view.children[i].clicked = false;
		         view.children[i].backgroundImage = view.children[i].offImg;
		      }
		   }
		};

		view.addEventListener('click', function(e){
		   if(!e.source.isImg){
	         return;
	      }
		   if(e.source.clicked){
		      return;
		   }

		   view.toggle(e.source.idx);

			if(_event){
			   _event(e);
			}
		});

		var halfOptView = Ti.UI.createView({
		  isHalfOptView:true,
	      height:ro.ui.relY(40),
	      left:ro.ui.relX(5),
	      //width:Ti.UI.FILL,
	      width:Ti.UI.SIZE,
	      layout:'horizontal',
	      visible:isVisible ? isVisible : false,
	      toggleVis: function(visibleBool){
	      	try{
	      		this.visible = visibleBool;
	      		if(this.children && this.children.length && this.children[1] && this.children[1].children.length > 1){
	      			this.children[1].visible = visibleBool;
	      		}
	      	}
	      	catch(ex){
	      		Ti.API.debug('toggleVis()-Exception: ' + ex);
	      	}
	      },
	      reset: function(e){//Call this reset function ( row.children[1].reset() ) upon row selection and it will reset the HalfOptions and ExtraQty controls to their default position.
	      	try{
	      		this.children[0].toggle(0);
	      		this.children[1].toggle(1);
	      	}
	      	catch(ex){
	      		Ti.API.debug('reset()-Exception: ' + ex);
	      	}
	      }
	   });
	   halfOptView.add(view);
	   if(_event2){
	   	var extraQty = exports.getExtraQty(_event2, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.add(extraQty);
	   }
	   else{
	   	var extraQty = exports.getExtraQty(null, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.add(extraQty);
	   }
	}
	else{
		var halfOptView = Ti.UI.createView({
		  isHalfOptView:true,
	      height:ro.ui.relY(40),
	      left:ro.ui.relX(5),
	      //width:Ti.UI.FILL,
	      width:Ti.UI.SIZE,
	      bottom:ro.ui.relY(10),
	      layout:'horizontal',
	      visible:isVisible ? isVisible : false,
	      toggleVis: function(visibleBool){
	      	try{
	      		if(visibleBool){
	      			this.visible = true;
	      			this.show();
	      		}
	      		else{
	      			this.visible = false;
	      			this.hide();
	      		}

	      	}
	      	catch(ex){
	      		Ti.API.debug('toggleVis()-Exception: ' + ex);
	      	}
	      },
	      reset:function(e){//Call this reset function ( row.children[1].reset() ) upon row selection and it will reset the ExtraQty control to its default position.
	      	try{
	      		this.children[0].toggle(1);
	      	}
	      	catch(ex){
	      		Ti.API.debug('reset()-Exception: ' + ex);
	      	}
	      }
	   });
	   if(_event2){
	   	var extraQty = exports.getExtraQty(_event2, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.add(extraQty);
	   }
	   else{
	   	var extraQty = exports.getExtraQty(null, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.add(extraQty);
	   }
	}
   return halfOptView;
};

function toggleVis(visibleBool){
	      	try{
	      		this.visible = visibleBool;
	      		/*if(visibleBool){
	      			this.height = ro.ui.relY(80);
	      		}
	      		else{
	      			//this.hide();
	      			this.height = 0;
	      		}*/
	      	}
	      	catch(ex){
	      		Ti.API.debug('toggleVis()-Exception: ' + ex);
	      	}
	      }
exports.getNewToppingsBlock = function(_event, _event2, rowName, halfOptFlag, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite, isVisible){
	if(halfOptFlag){
		var view = Ti.UI.createView({
			isHalfOptViewChild:true,
			height:ro.ui.relX(55),
			width:ro.isiOS ? ro.ui.relY(155) : ro.ui.relX(170),
			layout:'horizontal',
			bubbleParent:false,
			left:ro.ui.relX(10),
			top:ro.ui.relY(5),
	      isImg:false,
	      isHalf:true
	   });
		var halfOne = Ti.UI.createView({
			height:ro.isiOS ? ro.ui.relY(40) : ro.ui.relY(45),
			width:ro.isiOS ? ro.ui.relY(40) : ro.ui.relX(45),
			backgroundImage:'/images/halfone.png',
			onImg:'/images/halfoneChosen.png',
			offImg:'/images/halfone.png',
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			clicked:false,
			eventIdx:0,
	      idx:1,
	      isImg:true
		});
		var full = Ti.UI.createView({
			height:ro.isiOS ? ro.ui.relY(40) : ro.ui.relY(45),
			width:ro.isiOS ? ro.ui.relY(40) : ro.ui.relX(45),
			backgroundImage:'/images/fullChosen.png',
			onImg:'/images/fullChosen.png',
			offImg:'/images/full.png',
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			clicked:true,
			eventIdx:1,
	      idx:0,
	      isImg:true
		});
		var halfTwo = Ti.UI.createView({
			height:ro.isiOS ? ro.ui.relY(40) : ro.ui.relY(45),
			width:ro.isiOS ? ro.ui.relY(40) : ro.ui.relX(45),
			left:ro.ui.relX(5),
			right:ro.ui.relX(5),
			backgroundImage:'/images/halftwo.png',
			onImg:'/images/halftwoChosen.png',
			offImg:'/images/halftwo.png',
			clicked:false,
			eventIdx:2,
			idx:2,
			isImg:true
		});
		view.add(halfOne);
		view.add(full);
		view.add(halfTwo);
		view.toggleHalfOpts = toggleHalfOpts;
		function toggleHalfOpts(selIdx){
		   for(var i=0; i<3; i++){
		      if(view.children[i].idx === selIdx){
		         view.children[i].backgroundImage = view.children[i].onImg;
		         view.children[i].clicked = true;
		      }
		      else{
		         view.children[i].clicked = false;
		         view.children[i].backgroundImage = view.children[i].offImg;
		      }
		   }
		};

		view.addEventListener('click', function(e){
		   if(!e.source.isImg){
	         return;
	      }
		   if(e.source.clicked){
		      return;
		   }

		   view.toggleHalfOpts(e.source.idx);

			if(_event){
			   _event(e);
			}
		});

		var halfOptView = Ti.UI.createView({
		  isHalfOptView:true,
	      height:ro.ui.relX(85),
	      left:ro.ui.relX(5),
	      //width:Ti.UI.FILL,
	      width:Ti.UI.SIZE,
	      layout:'vertical',
	      visible:isVisible ? isVisible : false,
	      toggleHalfOpts: toggleHalfOpts,
	      toggleQty:function(){
	      	
	      },
	      toggleVis:toggleVis,
	      reset: reset
	   });
	   function reset(e){//Call this reset function ( row.children[1].reset() ) upon row selection and it will reset the HalfOptions and ExtraQty controls to their default position.
		  	try{
		  		this.toggleHalfOpts(0);
		  		this.toggleQty(1);
		  	}
		  	catch(ex){
		  		Ti.API.debug('reset()-Exception: ' + ex);
		  	}
		  }
	   function toggleVVis(visibleBool){
	   	try{
	      		halfOptView.visible = visibleBool;
	      		if(visibleBool){
	      			//halfOptView.show();
	      			//halfOptView.height = ro.ui.relY(80);
	      		}
	      		else{
	      			//halfOptView.hide();
	      			//halfOptView.height = 0;
	      		}
	      		/*if(this.children && this.children.length && this.children[1] && this.children[1].children.length > 1){
	      			this.children[1].visible = visibleBool;
	      		}*/
	      	}
	      	catch(ex){
	      		Ti.API.debug('toggleVis()-Exception: ' + ex);
	      	}
	   }
	   if(_event2){
	   	var extraQty = exports.getNewExtraQty(_event2, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.toggleQty = extraQty.toggleQty;
	   	halfOptView.add(extraQty);
	   }
	   else{
	   	var extraQty = exports.getNewExtraQty(null, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.toggleQty = extraQty.toggleQty;
	   	halfOptView.add(extraQty);
	   }
	   halfOptView.add(view);
	}
	else{
		var halfOptView = Ti.UI.createView({
		  isHalfOptView:true,
	      height:ro.ui.relY(40),
	      left:ro.ui.relX(5),
	      //width:Ti.UI.FILL,
	      width:Ti.UI.SIZE,
	      bottom:ro.ui.relY(10),
	      layout:'horizontal',
	      visible:isVisible ? isVisible : false,
	      toggleVis: toggleVis,
	      reset:reset,
	      toggleHalfOpts:function(){
	      	
	      },
	      toggleQty:function(){
	      	
	      }
	   });
	   function reset(e){//Call this reset function ( row.children[1].reset() ) upon row selection and it will reset the HalfOptions and ExtraQty controls to their default position.
		  	try{
		  		this.toggleHalfOpts(0);
		  		this.toggleQty(1);
		  	}
		  	catch(ex){
		  		Ti.API.debug('reset()-Exception: ' + ex);
		  	}
		  }
	   if(_event2){
	   	var extraQty = exports.getNewExtraQty(_event2, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.toggleQty = extraQty.toggleQty;
	   	halfOptView.add(extraQty);
	   }
	   else{
	   	var extraQty = exports.getNewExtraQty(null, presetQty, defQtyAllowed, UseModQtyTxt, AllowLite);
	   	extraQty.name = rowName;
	   	halfOptView.toggleQty = extraQty.toggleQty;
	   	halfOptView.add(extraQty);
	   }
	}
   return halfOptView;
};

exports.getButtonBlock = function(itemSelected, getSizePrice, btns, btnAction, btnBlockCallback, styPrice, group){
	var currentStyleRow;
	var btnBlock = null;
	if(!styPrice){
		styPrice = false;
	}
	try{
		if(!btns){
			return;
		}
		btnBlock = Ti.UI.createView({
			height:ro.ui.relY(55),
			width:Ti.UI.SIZE,
			left:ro.ui.relX(10),
			bottom:ro.ui.relY(10),
			borderColor:ro.ui.theme.btnBorderDefault,
			borderWidth:ro.ui.relX(1),
			layout:'horizontal',
			bubbleParent:'false',
			visible:true,
			toggle:function(sizeToToggle){
				for(var i=0; i<btnBlock.children.length; i++){
					if(btnBlock.children[i].id === sizeToToggle){
						btnBlock.children[i].clicked = true;
						btnBlock.children[i].backgroundColor = ro.ui.theme.sizeBtnBlockBgActive;
						btnBlock.children[i].children[0].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label1
						btnBlock.children[i].children[1].color = ro.ui.theme.sizeBtnBlockTxtActive;//Label2
						btnAction(sizeToToggle);
	
						if(group.HasStyles && group.Styles && group.Styles.length){
							ro.itemObj.setStyles(currentStyleRow);
						}
	
					}
					else{
						btnBlock.children[i].clicked = false;
						btnBlock.children[i].backgroundColor = ro.ui.theme.sizeBtnBlockBgDefault;
						btnBlock.children[i].children[0].color = ro.ui.theme.sizeBtnBlockNameTxtDefault;//Label1
						btnBlock.children[i].children[1].color = ro.ui.theme.sizeBtnBlockPriceTxtDefault;//Label2
					}
				}
			}
		});

		var getBtnBlockChildren = function(btnBlock, btns, currentStyleRow, group){
			var aBtn, btnLbl, btnLbl2, clickedBool, clickedColor, btnPriceLblClr;
			for(var i=0; i<btns.length; i++){
				clickedBool = false;
				clickedColor = ro.ui.theme.sizeBtnBlockBgDefault;
				//btnLblClr = ro.ui.theme.btnTxtDefault;
				btnLblClr = ro.ui.theme.sizeBtnBlockNameTxtDefault;
				//btnPriceLblClr = ro.ui.theme.loginBtnBackground;
				btnPriceLblClr = ro.ui.theme.sizeBtnBlockPriceTxtDefault;

				if(btns[i].OnlineDefault || btns.length === 1){
					clickedBool = true;
					//clickedColor = ro.ui.theme.btnActive;
					clickedColor = ro.ui.theme.sizeBtnBlockBgActive;
					//btnLblClr = ro.ui.theme.btnTxtActive;
					btnLblClr = ro.ui.theme.sizeBtnBlockTxtActive;
					//btnPriceLblClr = ro.ui.theme.btnTxtActive;
					btnPriceLblClr = ro.ui.theme.sizeBtnBlockTxtActive;

					if(currentStyleRow !== false){
						btnAction(btns[i].Name);
						if(group.HasStyles && group.Styles && group.Styles.length){
							ro.itemObj.setStyles(currentStyleRow);
						}
					}
				}
				aBtn = Ti.UI.createView({
					width:ro.ui.relX(55),
					height:ro.ui.relY(55),
					id:btns[i].Name,
					borderColor:ro.ui.theme.btnBorderDefault,
					borderWidth:1,
					clicked:clickedBool,
					backgroundColor:clickedColor,
					layout:'vertical',
					name:btns[i].ReceiptName || btns[i].Name,
					szName:btns[i].Name,
					idx:i
				});

				var btnName = btns[i].DisplayName || btns[i].ReceiptName || btns[i].Name;
				if(btnName){
					btnName = btnName.toUpperCase();
				}

				btnLbl = Ti.UI.createLabel({
				   height:Ti.UI.SIZE,
					text:btnName,
					color:btnLblClr,
					font:{
						//fontWeight:'bold',
						fontSize:ro.ui.scaleFont(11),
						fontFamily:ro.ui.fonts.rowBodyTxt
					},
					textAlign:'center',
					touchEnabled:false,
					top:ro.ui.relY(7)
				});

				btnLbl2 = Ti.UI.createLabel({
				   height:Ti.UI.FILL,
				   text:styPrice?'$' + parseFloat(getSizePrice(btns[i], group, itemSelected) + styPrice[i].Price).toFixed(2):'$' + parseFloat(getSizePrice(btns[i], group, itemSelected)).toFixed(2),
		         color:btnPriceLblClr,
		         font:{
		            //fontWeight:'bold',
		            fontSize:ro.ui.scaleFont(11),
						fontFamily:ro.ui.fonts.prices.italic
		         },
		         textAlign:'center',
		         touchEnabled:false,
		         bottom:0
				});
				aBtn.add(btnLbl);
				aBtn.add(btnLbl2);
				btnBlock.add(aBtn);
			}
		};
		getBtnBlockChildren(btnBlock, btns, currentStyleRow, group);

		btnBlock.addEventListener('click', function(e){
			if(e.source.clicked){
				if(btnBlockCallback){
					btnBlockCallback();
				}
				else{
					return;
				}
			}
			e.source.parent.toggle(e.source.id);


			if(btnBlockCallback){
				btnBlockCallback();
			}
		});
		return btnBlock;
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL){ Ti.API.debug('getButtonBlock()-Exception: ' + ex); }
		return btnBlock;
	}
};
exports.getNewRow = function(rowDetail, id, rowid, rowChildDetail, preSelected, dontGrow){
	var fontWgt = 'normal';
	var rowText = 'Tap To Add';
	//var bgImage = '/images/invGrpBackground.png';
	var rowHeight = ro.ui.relY(50);
	//preSelected?ro.ui.relY(100):ro.ui.relY(50)
	if(preSelected){
	   //bgImage = '/images/invGrpBackground.png';
		fontWgt = 'bold';
		rowText = 'Tap To Remove';
		if(!dontGrow){
			rowHeight = ro.ui.relY(100);
		}
	}

	var szToUse = [];
	if(rowChildDetail){
		if(rowChildDetail.skipRow){
			return;
		}
		if(rowChildDetail.szs){
			szToUse = rowChildDetail.szs;
		}
	}
	var rowHasSizes = true;
	if(!szToUse.length){
	   rowHasSizes = false;
	}

	var row = Ti.UI.createView({
		height:rowHeight,
		//backgroundImage:bgImage,
		width:Ti.UI.FILL,
		layout:'vertical',
		sizes:szToUse,
		clicked:preSelected?true:false,
		id:id,
		index:rowid,
		onlineDefault:rowDetail.OnlineDefault,
		rowHasSizes: rowHasSizes,
		//selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	});
	var rowView = Ti.UI.createView({
		height:ro.ui.relY(50),
		width:Ti.UI.FILL,
		layout:'horizontal'
	});

	var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
	labelOneTxt = labelOneTxt.toUpperCase();

	var labelOne = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:labelOneTxt,
		font:{
			fontWeight:'bold',
			fontSize:ro.ui.scaleFont(13),
				fontFamily:ro.ui.fontFamily
		},
		left:ro.ui.relX(5),
		color:ro.ui.theme.darkerGray,
		width:Ti.UI.SIZE,
		bubbleParent:true
	});
	var labelTwo = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:rowText,
		font:{
			fontWeight:fontWgt,
			fontSize:ro.ui.scaleFont(10),
				fontFamily:ro.ui.fontFamily
		},
		right:ro.ui.relX(5),
		color:ro.ui.theme.loginGray,
		textAlign:'right',
		width:Ti.UI.FILL,
		touchEnabled:false
	});
	rowView.add(Ti.UI.createView({
	   width:ro.ui.relX(10),
	   left:ro.ui.relX(10),
	   height:ro.ui.relY(10)
	}));
   var checkView = Ti.UI.createView({
      height:ro.ui.relY(10),
      width:ro.ui.relX(10),
      backgroundImage:'/images/check.png',
      visible:preSelected?true:false
   });
   row.checkView = checkView;
   rowView.children[0].add(row.checkView);

	rowView.add(labelOne);
	rowView.add(labelTwo);
	row.add(rowView);
	return row;
};
exports.getRModRow = function(rowDetail, id, rowid, rowChildDetail, preSelected, dontGrow){
	var fontWgt = 'normal';
	var rowText = 'Tap To Add';
	//var bgImage = '/images/invGrpBackground.png';
	var rowHeight = ro.ui.relY(50);
	if(preSelected){
	  // bgImage = '/images/invGrpBackground.png';
		fontWgt = 'bold';
		rowText = 'Tap To Remove';
		if(!dontGrow){
			rowHeight = ro.ui.relY(100);
		}
	}

	var szToUse = [];
	if(rowChildDetail){
		if(rowChildDetail.skipRow){
			return;
		}
		if(rowChildDetail.szs){
			szToUse = rowChildDetail.szs;
		}
	}
	var rowHasSizes = true;
	if(!szToUse.length){
	   rowHasSizes = false;
	}

	var row = Ti.UI.createTableViewRow({
		height:rowHeight,
		//backgroundImage:bgImage,
		width:Ti.UI.FILL,
		layout:'vertical',
		sizes:szToUse,
		clicked:preSelected?true:false,
		id:id,
		index:rowid,
		onlineDefault:rowDetail.OnlineDefault,
		rowHasSizes: rowHasSizes,
		selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	});
	var rowView = Ti.UI.createView({
		height:ro.ui.relY(50),
		width:Ti.UI.FILL,
		layout:'horizontal'
	});

	var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
	labelOneTxt = labelOneTxt.toUpperCase();

	var labelOne = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:labelOneTxt,
		font:{
			fontWeight:'bold',
			fontSize:ro.ui.scaleFont(13),
				fontFamily:ro.ui.fontFamily
		},
		left:ro.ui.relX(5),
		color:ro.ui.theme.darkerGray,
		width:Ti.UI.SIZE,
		bubbleParent:true
	});
	var labelTwo = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:rowText,
		font:{
			fontWeight:fontWgt,
			fontSize:ro.ui.scaleFont(10),
				fontFamily:ro.ui.fontFamily
		},
		right:ro.ui.relX(5),
		color:ro.ui.theme.loginGray,
		textAlign:'right',
		width:Ti.UI.FILL,
		touchEnabled:false
	});
	rowView.add(Ti.UI.createView({
	   width:ro.ui.relX(35),
	   left:ro.ui.relX(10),
	   height:ro.ui.relY(35),
	   touchEnabled:false
	}));
   var checkView = Ti.UI.createView({
      height:ro.ui.relY(35),
      width:ro.ui.relX(35),
      backgroundImage:preSelected ? '/images/selectedMinus.png' : '/images/unselectedPlus.png',
      visible:true,
	  touchEnabled:false
   });
   row.checkView = checkView;
   rowView.children[0].add(row.checkView);

	rowView.add(labelOne);
	rowView.add(labelTwo);
	row.add(rowView);
	return row;
};
exports.getRow = function(rowDetail, id, rowid, rowChildDetail, preSelected, dontGrow){
	var fontWgt = 'normal';
	var rowText = 'Tap To Add';
	var bgImage = '/images/invGrpBackground.png';
	var rowHeight = ro.ui.relY(50);
	//preSelected?ro.ui.relY(100):ro.ui.relY(50)
	if(preSelected){
	   bgImage = '/images/invGrpBackground.png';
		fontWgt = 'bold';
		rowText = 'Tap To Remove';
		if(!dontGrow){
			rowHeight = ro.ui.relY(100);
		}
	}

	var szToUse = [];
	if(rowChildDetail){
		if(rowChildDetail.skipRow){
			return;
		}
		if(rowChildDetail.szs){
			szToUse = rowChildDetail.szs;
		}
	}
	var rowHasSizes = true;
	if(!szToUse.length){
	   rowHasSizes = false;
	}

	var row = Ti.UI.createTableViewRow({
		height:rowHeight,
		backgroundImage:bgImage,
		width:Ti.UI.FILL,
		layout:'vertical',
		sizes:szToUse,
		clicked:preSelected?true:false,
		id:id,
		index:rowid,
		onlineDefault:rowDetail.OnlineDefault,
		rowHasSizes: rowHasSizes,
		selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	});
	var rowView = Ti.UI.createView({
		height:ro.ui.relY(50),
		width:Ti.UI.FILL,
		layout:'horizontal'
	});

	var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
	labelOneTxt = labelOneTxt.toUpperCase();

	var labelOne = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:labelOneTxt,
		font:{
			fontWeight:'bold',
			fontSize:ro.ui.scaleFont(13),
				fontFamily:ro.ui.fontFamily
		},
		left:ro.ui.relX(5),
		color:ro.ui.theme.darkerGray,
		width:Ti.UI.SIZE,
		bubbleParent:true
	});
	var labelTwo = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:rowText,
		font:{
			fontWeight:fontWgt,
			fontSize:ro.ui.scaleFont(10),
				fontFamily:ro.ui.fontFamily
		},
		right:ro.ui.relX(5),
		color:ro.ui.theme.loginGray,
		textAlign:'right',
		width:Ti.UI.FILL,
		touchEnabled:false
	});
	rowView.add(Ti.UI.createView({
	   width:ro.ui.relX(10),
	   left:ro.ui.relX(10),
	   height:ro.ui.relY(10)
	}));
   var checkView = Ti.UI.createView({
      height:ro.ui.relY(10),
      width:ro.ui.relX(10),
      backgroundImage:'/images/check.png',
      visible:preSelected?true:false
   });
   row.checkView = checkView;
   rowView.children[0].add(row.checkView);

	rowView.add(labelOne);
	rowView.add(labelTwo);
	row.add(rowView);
	return row;
};
exports.getPrefModRow = function(rowDetail, id, rowid, preSelected, dontGrow, custModRowProps, toppingBlock, defRowHidden){
	var fontWgt = 'normal';
	var rowText = 'Tap To Add';
	var rowHeight = ro.ui.relY(50);
	if(preSelected){
		fontWgt = 'bold';
		rowText = 'Tap To Remove';
		if(!dontGrow){
			rowHeight = ro.ui.relY(100);
		}
	}

	//var row = Ti.UI.createTableViewRow({
		//row.height = row.AllowHalf ? ro.ui.relY(130) : ro.ui.relY(80);
	var row = Ti.UI.createView(ro.combine(custModRowProps, {
		borderRadius:ro.ui.relY(15),
		height:defRowHidden ? 0 : (preSelected ? (custModRowProps.AllowHalf ? ro.ui.relX(145) : ro.ui.relX(90)) : ro.ui.relX(50)) ,
		top:defRowHidden ? 0 : ro.ui.relY(5),
		width:Ti.UI.FILL,
		left:ro.ui.relX(10),
		right:ro.ui.relX(10),
		layout:'vertical',
		clicked:preSelected?true:false,
		id:id,
		index:rowid,
		onlineDefault:rowDetail.OnlineDefault,
		isRow:true,
		topBlock:toppingBlock,
        //backgroundColor:((id%2) ? "#e4e4e4" : "white"),
        oldTop:defRowHidden ? ro.ui.relY(5) : 0,
		oldHeight:defRowHidden ? (preSelected ? (custModRowProps.AllowHalf ? ro.ui.relX(145) : ro.ui.relX(90)) : ro.ui.relX(50)) : 0
	}));
	//Ti.API.debug('row.height: ' + row.height + ' and row.oldHeight: ' + row.oldHeight);
	
	var rowView = Ti.UI.createView({
		height:ro.ui.relY(50),
		width:Ti.UI.FILL,
		layout:'horizontal',
		isRowView:true
	});

	var labelOneTxt = rowDetail.DisplayName || rowDetail.ReceiptName || rowDetail.Name;
	//labelOneTxt = labelOneTxt.toUpperCase();

	var labelOne = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:labelOneTxt,
		font:{
			fontWeight:'bold',
			fontSize:ro.ui.scaleFont(14),
				fontFamily:ro.ui.fontFamily
		},
		left:ro.ui.relX(0),
		color:ro.ui.theme.darkerGray,
		width:Ti.UI.SIZE,
		bubbleParent:true
	});
	var labelTwo = Ti.UI.createLabel({
		height:ro.ui.relY(50),
		text:rowText,
		font:{
			fontWeight:fontWgt,
			fontSize:ro.ui.scaleFont(11),
			fontFamily:ro.ui.fontFamily
		},
		right:ro.ui.relX(10),
		color:ro.ui.theme.loginGray,
		textAlign:'right',
		width:Ti.UI.FILL,
		touchEnabled:false
	});
	rowView.add(Ti.UI.createView({
	   width:ro.ui.relX(35),
	   left:ro.ui.relX(10),
	   height:ro.ui.relY(35),
		touchEnabled:false
	}));
   var checkView = Ti.UI.createView({
      height:ro.ui.relY(35),
      width:ro.ui.relX(35),
      backgroundImage:preSelected ? '/images/selectedMinus.png' : '/images/unselectedPlus.png',
      visible:true,
	  touchEnabled:false
   });
   row.checkView = checkView;
   rowView.children[0].add(row.checkView);

	rowView.add(labelOne);
	rowView.add(labelTwo);
	row.add(rowView);
	
	row.add(row.topBlock);
	
	return row;
};
exports.newRowSelected = function(row, dontGrow){
	if(!row.dontGrow){
		row.topBlock.toggleVis(true);
		row.height = row.AllowHalf ? ro.ui.relY(145) : ro.ui.relY(90);
	}
	row.clicked = true;
	var rowChild = row.children[0];
    rowChild.children[1].bubbleParent = false;
	rowChild.children[2].text = 'Tap To Remove';
	rowChild.children[2].font.fontWeight = 'bold';
	
    rowChild.children[0].children[0].backgroundImage = '/images/selectedMinus.png';
	return row.index;
};
exports.newRowDeselected = function(row, clicked, dontGrow){
	if(clicked){
		if(!dontShrink){
    		row.height = ro.ui.relY(50);
    		row.topBlock.toggleVis(false);
			row.topBlock.reset();
		}
		var dontShrink = row.dontGrow;
		row.clicked = false;
		var rowChild = row.children[0];
		rowChild.children[0].children[0].backgroundImage = '/images/unselectedPlus.png';

		rowChild.children[2].text = 'Tap To Add';
		rowChild.children[2].font.fontWeight = 'normal';
		rowChild.children[1].bubbleParent = true;
	}
	return clicked ? true : false;
};
exports.rowSelected = function(dontGrow){
	//try{
		var row = this;
		var rowChild = row.children[0];
		row.clicked = true;
        rowChild.children[1].bubbleParent = false;
		rowChild.children[2].text = 'Tap To Remove';
		rowChild.children[2].font.fontWeight = 'bold';
		
        rowChild.children[0].children[0].visible = true;	//CheckView check.png image visibility changed to true
        rowChild.children[0].children[0].show();

		if(!row.dontGrow){
			row.height = ro.ui.relY(100);
			row.children[1].toggleVis(true);
		}

		return row.index;
};
exports.rowDeselected = function(clicked, dontGrow){
	//try{
		if(clicked){
			
			var row = this;
			var dontShrink = row.dontGrow;
			row.clicked = false;
			var rowChild = row.children[0];
			rowChild.children[0].children[0].visible = false;		//CheckView check.png image visibility changed to false
			rowChild.children[0].children[0].hide();

			rowChild.children[2].text = 'Tap To Add';
			rowChild.children[2].font.fontWeight = 'normal';
			rowChild.children[1].bubbleParent = true;
			
			if(!dontShrink){
        		row.children[1].toggleVis(false);
				row.height = ro.ui.relY(50);
				row.children[1].reset();
			}
		}
		return clicked ? true : false;
};
exports.modRowSelected = function(dontGrow){
	//try{
		var row = this;
		var rowChild = row.children[0];
		row.clicked = true;
		//row.backgroundImage = '/images/shadow.png';
		//row.backgroundImage = '/images/invGrpBackground.png';
        rowChild.children[1].bubbleParent = false;
		rowChild.children[2].text = 'Tap To Remove';
		rowChild.children[2].font.fontWeight = 'bold';
		
        //rowChild.children[0].children[0].visible = true;	//CheckView check.png image visibility changed to true
        //rowChild.children[0].children[0].show();
        rowChild.children[0].children[0].backgroundImage = '/images/selectedMinus.png';

		if(!row.dontGrow){
			row.height = ro.ui.relY(100);
			row.children[1].toggleVis(true);
		}

		return row.index;
};
exports.modRowDeselected = function(clicked, dontGrow){
	//try{
		if(clicked){
			
			var row = this;
			var dontShrink = row.dontGrow;
			row.clicked = false;
			var rowChild = row.children[0];
			rowChild.children[0].children[0].backgroundImage = '/images/unselectedPlus.png';
			//rowChild.children[0].children[0].visible = false;		//CheckView check.png image visibility changed to false
			//rowChild.children[0].children[0].hide();

			rowChild.children[2].text = 'Tap To Add';
			rowChild.children[2].font.fontWeight = 'normal';
			rowChild.children[1].bubbleParent = true;
			
			if(!dontShrink){
        		row.children[1].toggleVis(false);
				row.height = ro.ui.relY(50);
				row.children[1].reset();
			}
		}
		return clicked ? true : false;
};
exports.setItemDisplay = function(e, thisCallback){
	var view = Ti.UI.createView({
		height:ro.ui.relY(110),
		left:ro.ui.relX(1),
		right:ro.ui.relX(1),
		top:0,
		layout:'vertical',
		contentWidth:Ti.UI.FILL,
		ItemNote:e.itemNote && e.itemNote.length ? e.itemNote : null
	});
	var displayImgView = Ti.UI.createView({
		layout:'horizontal',
		height:ro.ui.relY(110),
		left:ro.ui.relX(1),
		right:ro.ui.relX(1)
	});
	var finalString = e.ttl + '\n' + e.text;
	
	var attributesCol = [{
        type:Ti.UI.ATTRIBUTE_FONT,
        value:{ fontSize: ro.ui.scaleFont(16), fontWeight:'bold' },
        range:[0, (e.ttl?e.ttl.length:0)]
    }];
    
    if(e.orderNote && e.orderNote.length){
    	var beginLength = finalString.length;
    	finalString = finalString + ' ' + e.orderNote;
    	attributesCol.push({
        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
            value: ro.ui.theme.orderItemNoteTxtItemDetailsView,
            range: [beginLength+1, e.orderNote.length]
        });
    }
    
	var imagePath = ro.ui.properties.defaultPath + 'default.png';
	var imgHolder = Ti.UI.createView({
		width:ro.ui.relX(95),
		top:0,
		bottom:0,
		left:0
	});
	
	var imgVw = Ti.UI.createImageView({
		image:e.itemSelected.ImageSource,
		defaultImage:imagePath,
		top:ro.ui.relY(0),
		left:ro.ui.relX(5),
		width:ro.ui.relX(95),
		height:ro.ui.relY(95),
		id:'imgChild'
	});
	imgHolder.add(imgVw);
	var attr = Ti.UI.createAttributedString({
      text:finalString,
      attributes:attributesCol
   });
   var itemDesVw = Ti.UI.createView({
   		width:ro.ui.relX(ro.ui.displayCaps.platformWidth - 70)
   });
   
	var itemDesLbl = Ti.UI.createLabel({
		attributedString:attr,
		width:ro.ui.relX(ro.ui.displayCaps.platformWidth - 70),
		clipMode:ro.isiOS ? Titanium.UI.iOS.CLIP_MODE_ENABLED : null,
		top:ro.ui.relY(1),
		left:ro.ui.relX(1),
		font:{
			fontSize:ro.ui.scaleFont(11.5),
			fontFamily:ro.ui.fontFamily
		},
		color:ro.ui.theme.itemDetailsDescriptionTxt,
		textAlign:'left',
		id:'LblChild'
	});
	itemDesVw.add(itemDesLbl);
	displayImgView.add(imgHolder);
	displayImgView.add(itemDesVw);
	if(e.orderNote && e.orderNote.length){
		displayImgView.addEventListener('click', function(e){
			getItemNoteView(view.ItemNote, function(itemNote){
				view.ItemNote = itemNote && itemNote.length ? itemNote : null;
			});
		});
	}
	view.add(displayImgView);
	return view;
};
exports.getPrefModView = function(prefModView){
	var modal = exports.modalPrefWin;
		var popupWin = new modal();
		popupWin.open();
};
exports.modalSuggWin = function(prefModsView){	
	//Popup win
	var popupWin = Ti.UI.createWindow({
		//layout:'vertical',
		backgroundColor: 'transparent',
		//height:Ti.UI.SIZE
		//opacity: 0.7,
		//fullscreen: true,
		//navBarHidden:true,
		//windowSoftInputMode:Ti.UI.Android.SOFT_INPUT_STATE_VISIBLE 
	});
	popupWin.addEventListener('open', function(e) {
	    //popupWin.activity.actionBar.hide();
	});
	var opaqueView = Ti.UI.createView(ro.ui.properties.OpaqueView);
	opaqueView.layout = 'vertical';
	var fullView = Ti.UI.createView(ro.ui.properties.OpaqueFullView);
	popupWin.add(fullView);
	popupWin.add(opaqueView);
	
	//View that used to show the msg
	/*var popupView = Ti.UI.createView(ro.ui.properties.orderItemNoteBox);
	var hdrView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		top:0
	}));
	
	
	//A message label is added to the view
	//popupView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	hdrView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	popupView.add(hdrView);
	popupWin.add(popupView);*/
	
	//Event to close the popup window
	opaqueView.addEventListener('click', function(e){
	   if(e.source.id == 'popupWin'){
		  //popupWin.close();
		  this.parent.close();
	   }
	});
	return popupWin;
};
exports.modalPrefWin = function(prefModsView){	
	//Popup win
	var popupWin = Ti.UI.createWindow({
	});
	popupWin.addEventListener('open', function(e) {
	    //popupWin.activity.actionBar.hide();
	});
	var opaqueView = Ti.UI.createView(ro.ui.properties.prefModsOpaqueView);
	opaqueView.layout = 'vertical';
	var fullView = Ti.UI.createView(ro.ui.properties.prefModsFullView);
	popupWin.add(fullView);
	popupWin.add(opaqueView);
	
	//View that used to show the msg
	/*var popupView = Ti.UI.createView(ro.ui.properties.orderItemNoteBox);
	var hdrView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		top:0
	}));
	
	
	//A message label is added to the view
	//popupView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	hdrView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	popupView.add(hdrView);
	popupWin.add(popupView);*/
	
	//Event to close the popup window
	opaqueView.addEventListener('click', function(e){
	   if(e.source.id == 'popupWin'){
		  //popupWin.close();
		  this.parent.close();
	   }
	});
	popupWin.addEventListener('close', function(){
		popupWin = null;
		
	});
	//popupWin.
	return popupWin;
}; 
function getItemNoteView(note, _callback){
	    var modal = exports.modalWin;
		var popupWin = new modal(note, _callback);
		popupWin.open();
		//popupWin.children[1].children[1].focus();
		var textField = popupWin.children[1].children[1];
		popupWin.children[1].children[1].setSelection(textField.value.length, textField.value.length);
}
exports.getItemNoteView = getItemNoteView;
exports.modalWin = function(note, _callback){	
	//Popup win
	var popupWin = Ti.UI.createWindow({
		backgroundColor: 'transparent',
		//opacity: 0.7,
		fullscreen: true,
		navBarHidden:true,
		windowSoftInputMode:!ro.isiOS ? Ti.UI.Android.SOFT_INPUT_STATE_VISIBLE : null 
	});
	if(!ro.isiOS){
		popupWin.addEventListener('open', function(e) {
	    	if(!ro.isiOS) popupWin.activity.actionBar.hide();
		});
	}
	var opaqueView = Ti.UI.createView(ro.ui.properties.orderItemNoteOpaqueView);
	popupWin.add(opaqueView);
	
	//View that used to show the msg
	var popupView = Ti.UI.createView(ro.ui.properties.orderItemNoteBox);
	var hdrView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		top:0
	}));
	
	
	//A message label is added to the view
	//popupView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	hdrView.add(Ti.UI.createLabel(ro.ui.properties.orderItemNoteTxt));
	popupView.add(hdrView);
	var textArea = Ti.UI.createTextField(ro.ui.properties.orderItemNoteTextArea);
	if(note && note.length){
		textArea.value = note;
	}
	popupView.add(textArea);
	/*var submitBtn = Ti.UI.createView(ro.ui.properties.orderItemNoteSubmitBtn);
	var submitBtnTxt = Ti.UI.createLabel(ro.ui.properties.orderItemNoteSubmitBtnTxt);
	submitBtn.add(submitBtnTxt);*/
	var submitBtn = layoutHelper.getBigButton('SAVE');
	//submitBtn.left = ro.ui.relX(10);
	//submitBtn.right = ro.ui.relX(10);
	//submitBtn.bottom = ro.ui.relX(10);
	submitBtn.addEventListener('click', function(e){
		var specialInstruction = textArea.value && textArea.value.length ? textArea.value : '';
		
		var itemNoteExp = new RegExp("^[A-Za-z0-9 !$&'(),.:;?#*%\n\r-]+$");
		var foundProblem = false;
		if(specialInstruction && specialInstruction.length && !itemNoteExp.test(specialInstruction)){
           foundProblem = true;
           ro.ui.alert('Error', 'Special Instructions contains invalid characters.');
           _callback('');
        }
		if(!foundProblem){
			_callback(specialInstruction);
			popupWin.close();
		}
		
	});
	
	popupView.add(submitBtn);
	
	popupWin.add(popupView);
	
	//Event to close the popup window
	opaqueView.addEventListener('click', function(e){
	   if(e.source.id != null){
		  popupWin.close();
	   }
	});
	return popupWin;
};
exports.menuHeaders = function(e){
	try{
		var hdrTxt = e.text;
		if(!hdrTxt){
			hdrTxt = '';
		}
		hdrTxt = hdrTxt.toUpperCase();
		var lft = ro.ui.relX(10);
		var rgt = ro.ui.relX(10);
		if(e.leftRightBool){
		   lft = 0;
		   rgt = 0;
		}

		var hdrView = Ti.UI.createView({
			//width:Ti.UI.FILL,
			right:rgt,
			left:lft,
			height:ro.ui.relY(35),
			backgroundColor:e.backgroundColor?e.backgroundColor:ro.ui.theme.headerBackgroundColor,
			borderColor:e.borderColor?e.borderColor:ro.ui.theme.headerBorderColor,
			borderWidth:ro.ui.relX(1),
			iAm:'view',
			isHeader:true
		});
		var hdrLbl = Ti.UI.createLabel({
			text:hdrTxt,
			color:e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt,
			font:{
				fontSize:e.smallerFont ? ro.ui.scaleFont(12) : ro.ui.scaleFont(15),
				fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
			},
			textAlign:'left',
			left:ro.ui.relX(5),
			touchEnabled:false,
			iAm:'label',
			isHeader:true
		});
		hdrView.add(hdrLbl);
	}
	catch(ex){
		if(Ti.App.DEBUGBOOL){ Ti.API.debug('menuHeaders()-Exception: ' + ex); }
	}
	return hdrView;
};