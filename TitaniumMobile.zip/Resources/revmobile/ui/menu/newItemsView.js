var NEWITEMSVIEW = function() {
    var newitemsview = function(ro) {
        ro.ui.createNewItemsView = function() {            
            //GUEST ORDERS
            var isGuest = false;
            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                isGuest = true;
            }
            //GUEST ORDERS

            //Ti.include('/logic/prevOrders.js');
            //Ti.include('/controls/tabCtrl.js');
            var menuUtils = require('logic/menuUtils');
            var menuHelper = require('logic/menuHelper');
            var itemViewCpnBoole = ro.cpnHelper.isCpn();
            var itemsViewHid = itemViewCpnBoole ? 'cpnItems' : Ti.App.RepeatLastOrder ? 'defaultStore' : 'itemsView';
            var logoutBtn,
                backBtn,
                navBar,
                headerLbl,
                customAlertView = ro.ca.createCustomAlert();

            try {
                var mainView = layoutHelper.getMainView(itemsViewHid, Ti.App.grpIndex, layoutHelper.getLogoutBtn(), layoutHelper.getBackBtn("Menu", null, true), true);
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('newItemsView()-Exception: ' + ex);
                }
            }

            var itemsData = [],
                Coupons = [],
                ordTab = [],
                rs = {};
            var items = null,
                group = null,
                curSelectedGroup = null;
            var itmDisplayLen,
                prevOrdObj,
                timeAtStore;

            try {
                if (!Ti.App.RepeatLastOrder) {
                    timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
                }
                else {
                    if (ro.app.Store) {
                        ro.app.Store.Menu = (ro.app.Store && ro.app.Store.Menu) ? ro.app.Store.Menu : null;
                    }
                    else {
                        ro.app.Store = {
                            Menu: null
                        };
                    }
                }
            }
            catch(ex) {
                if (Ti.App.DEBUGBOOL) {
                    Ti.API.debug('newItemsView()-TimeZone-Exception: ' + ex);
                }
            }

            function tabClick(e) {
                if (e.source.id == 0) {
                    if (!ordTab[0].ison) {
                        ordTab[0].toggle();
                        ordTab[1].toggle();
                    }
                }
                else {
                    if (!ordTab[1].ison) {
                        ordTab[1].toggle();
                        ordTab[0].toggle();
                    }
                }
                toggleVisibility((e.source.id === 0));
            };

            ordTab.push(ro.tabBar.createTab('Favorites', function(e) {
                tabClick(e);
            }, true, 0));

            ordTab.push(ro.tabBar.createTab('Previous', function(e) {
                tabClick(e);
            }, false, 1));

            var ordTabView = ro.tabBar.getTabView(ordTab);

            var itemsView = Ti.UI.createView({
                name: 'items',
                layout: 'vertical',
                top: 0,
                right: ro.ui.relX(0),
                left: ro.ui.relX(0),
                bottom: ro.ui.relY(5)
            });

            var tblItems = Ti.UI.createTableView({
                height: Ti.UI.FILL,
                backgroundColor: 'white',
                separatorColor: 'transparent',
                minRowHeight: ro.ui.properties.menuRowHeight,
                top: ro.ui.relY(2),
                left: 3,
                right: 3
            });

            var refreshGrp;
            if (Ti.App.RepeatLastOrder) {
                refreshGrp = 'Orders';
            }
            else {
                refreshGrp = itemViewCpnBoole ? Ti.App.cpnGrpIndex : Ti.App.grpIndex;
            }
            if (refreshGrp === 'Orders') {
                /*var tblHead = layoutMenuHelper.menuHeaders({
                    text: 'MY ORDERS'
                });*/
                /*tblItems = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
                    data: [],
                    height: Ti.UI.SIZE,
                    rowHeight: Ti.UI.SIZE,
                    minRowHeight: ro.ui.properties.menuRowHeight,
                    top: 0,
                    bottom: ro.ui.relY(4),
                    left: ro.ui.relX(10),
                    right: ro.ui.relX(10),
                    backgroundColor: 'white',
                    borderWidth: ro.ui.relX(1),
                    borderColor: ro.ui.theme.loginGray,
                    separatorColor: ro.ui.theme.separatorColor
                }));*/
           
                tblItems = Ti.UI.createScrollView(ro.combine(ro.ui.properties.myRewardsScrollView, {
                    //bottom: false ? ro.ui.relY(50) : null,
                    scrollToIndex:function(){
                        Ti.API.debug("scrollToIndex");
                    },
                    //borderColor:'green',
                    //borderWidth:2,
                    visible:true
                }));


               
            }

            var noItemsLbl = Ti.UI.createLabel(ro.ui.properties.noItemsLbl);

            var lastDispRowId;
            var interval;
            var updating = false,
                reachedEnd,
                lastDistance = 0,
                lastRow = 0;
                
            
            if (refreshGrp !== 'Orders') {               
                if (!ro.isiOS) {
                    tblItems.addEventListener('scroll', function(e) {
                        try {
                            //Ti.API.info('e: ' + JSON.stringify(e));
                            // Ti.API.info('items.length: ' + items.length);
                            // Ti.API.info('e.totalItemCount: ' + e.totalItemCount);
                            // Ti.API.info('e.firstVisibleItem: ' + e.firstVisibleItem);
                            // Ti.API.info('e.visibleItemCount: ' + e.visibleItemCount);
                            // Ti.API.info('lastDispRowId: ' + lastDispRowId);

                            if (interval > 0 || (items.length - e.totalItemCount === 0)) {
                                return;
                            }
                            //interval = 1;
                            
                            var endRow = e.firstVisibleItem + e.visibleItemCount;
                            if (endRow < lastDispRowId) {
                                return;
                            }
                            endRow += itmDisplayableLen;
                            if (endRow > items.length) {
                                endRow = items.length;
                            }

                            interval = setTimeout(function() {
                                try {
                                    if (lastDispRowId + 1 != items.length) {
                                        var path; 
                                        var hasSurcharge;
                                        for (var j = lastDispRowId + 1; j < endRow; j++) {
                                            hasSurcharge = false;
                                            if (items[j].hasSurcharge) {
                                                hasSurcharge = true;
                                            }
                                            if (curSelectedGroup == 'Orders') {
                                                tblItems.appendRow(addToPrev(j));
                                            }
                                            else if (curSelectedGroup.toLowerCase() == 'pick any' || curSelectedGroup.toLowerCase() == 'required item') {
                                                var _gIdx = items[j].PickAnyGrpIdx;
                                                group = ro.app.Store.Menu.Groups[_gIdx];
                                                if (items[j].HasImage) {
                                                    path = items[j].ImageSource;
                                                }
                                                else if (group.HasImage) {
                                                    path = group.ImageSource;
                                                }
                                                tblItems.appendRow(newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, ''/*menuHelper.getItemPrice(items[j],  group,Ti.App.OrderObj.OrdTypePriceIdx)*/, _gIdx, hasSurcharge));
                                            }
                                            else if (curSelectedGroup != 'Coupons') {
                                                tblItems.appendRow(newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), items[j].HasImage ? items[j].ImageSource : path, false, j, menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx), null, hasSurcharge));
                                            }
                                            else {                                                
                                                tblItems.appendRow(newAddItem(items[j].RcptName, formCpnDesc(items[j]), (items[j].UseImage) ? items[j].ImageName : ro.ui.properties.defaultPath + 'myDeals.png', true, j, null));
                                            }
                                        }
                                        
                                        //}
                                        lastDispRowId = endRow - 1;
                                    }
                                    interval = 0;
                                }
                                catch(ex) {
                                    if (Ti.App.DEBUGBOOL) {
                                        Ti.API.debug('ScrollEvent-InsideInterval: ' + ex);
                                    }
                                }
                            }, 20);
                        }
                        catch(ex) {
                            if (Ti.App.DEBUGBOOL) {
                                Ti.API.debug('ScrollEvent-OutsideInterval: ' + ex);
                            }
                        }
                    });
                }
                else {
                    tblItems.style = Ti.UI.iOS.TableViewStyle.PLAIN;
                    tblItems.addEventListener('scroll', function(e) {
                        if (!reachedEnd) {
                            var offset = e.contentOffset.y;
                            var height = e.size.height;
                            var total = offset + height;
                            var theEnd = e.contentSize.height;
                            var distance = theEnd - total;

                            if (distance < lastDistance) {
                                var nearEnd = theEnd * .75;
                                if (!updating && (total >= nearEnd)) {
                                    beginUpdate();
                                }
                            }
                            lastDistance = distance;
                        }
                    });

                    function addRows(start, end) {

                        if (curSelectedGroup.toLowerCase() == 'pick any' || curSelectedGroup.toLowerCase() == 'required item') {
                            //var items = (curSelectedGroup.toLowerCase() == 'pick any') ? cpnHelper.getPickAnyItems() : cpnHelper.getRequireAnyItems();//group.Items;
                            ////Ti.API.debug('items: ' + JSON.stringify(items));
                            for (var j = start; j < end; j++) {
                                //var _gIdx = getMatchingIdx(items[j].ReportGrp, storeObj.Menu.Groups, 'ReportGrp');
                                var _gIdx = items[j].PickAnyGrpIdx;
                                var path;
                                group = ro.app.Store.Menu.Groups[_gIdx];
                                if (items[j].HasImage) {
                                    path = items[j].ImageSource;
                                }
                                else if (group.HasImage) {
                                    path = group.ImageSource;
                                }
                                var hasSurcharge = false;
                                if (items[j].hasSurcharge) {
                                    hasSurcharge = true;
                                }
                                //price = arrayToPrice(menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
                                price = menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx);
                                newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, null, _gIdx, hasSurcharge);
                            }
                            tblItems.data = itemsData;
                        }
                        else if (curSelectedGroup == 'Orders') {
                            //Check if there are any fav orders, if not highlight prev orders
                            //toggleVisibility(true);
                        }
                        else if (curSelectedGroup != 'Coupons') {
                            for (var j = start; j < end; j++) {
                                var path;
                                if (items[j].HasImage) {
                                    path = items[j].ImageSource;
                                }
                                else if (group.HasImage) {
                                    path = group.ImageSource;
                                }
                                price = menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx);
                                var hasSurcharge = false;
                                if (items[j].hasSurcharge) {
                                    hasSurcharge = true;
                                }
                                newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, price, null, hasSurcharge);
                                //addItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), items[j].HasImage?items[j].ImageSource:path, false, j, menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
                            }
                            tblItems.data = itemsData;
                        }
                        else {
                            for (var j = start; j < end; j++) {
                                var path;
                                path = (Coupons[j].UseImage) ? Coupons[j].ImageName : ro.ui.properties.defaultPath + 'myDeals.png';
                                price = null;
                                newAddItem(Coupons[j].RcptName, formCpnDesc(Coupons[j]), path, true, j, price);
                            }
                            tblItems.data = itemsData;
                        }
                    }

                    function beginUpdate() {
                        updating = true;
                        if(lastRow == 0)	lastRow = items.length > visibleRowCount ? visibleRowCount : items.length;
                        if ((lastRow + visibleRowCount) > items.length) {
                            /*if(curSelectedGroup == 'Orders'){
                             for(var i= lastRow;i<items.length;i++){
                             addToPrev(i);
                             }
                             tblItems.data = itemsData;
                             }
                             else{*/
                            addRows(lastRow, items.length);
                            //}
                            reachedEnd = true;
                            lastRow = items.length;
                        }
                        else {
                            /*if(curSelectedGroup == 'Orders'){
                             for(var i= lastRow;i<items.length;i++){
                             addToPrev(i);
                             }
                             tblItems.data = itemsData;
                             }
                             else{*/
                            addRows(lastRow, (lastRow + visibleRowCount));
                            //}
                            lastRow += visibleRowCount;

                        }
                        setTimeout(endUpdate, 150);
                    }

                    function endUpdate() {
                        updating = false;
                    }

                }

                tblItems.addEventListener('click', function(e) {
                    try {
                        ro.ui.showLoader();
                        var index;
                        if (e.row.itmType == 'prev') {
                            if (Ti.App.RepeatLastOrder) {
                                Ti.App.prevIdx = e.row.index;
                                if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                                    ro.ui.ordShowNext({
                                        addView: true,
                                        showing: 'newAddrList'
                                    });
                                }
                                else {
                                    ro.ui.ordShowNext({
                                        addView: true,
                                        showing: 'defaultStore'
                                    });
                                }
                            }
                            else {
                                if (!(ro.prevOrders.addToCart(prevOrdObj[e.row.index], ro.app.Store.Menu, Ti.App.OrderObj))) {
                                    ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
                                }
                                else {
                                    ro.ui.showCart();
                                }
                                ro.ui.hideLoader();
                                return;
                            }
                        }
                        else if (e.row.itmType == 'coupon') {
                            try {
                                //Ti.API.info('Coupon has been clicked');
                                //for (var idx = 0, idxMax = (Ti.App.OrderObj && Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0); idx < idxMax; idx++) {
                                //    if (Ti.App.OrderObj.Cpns[idx].IsExclusive) {
                                //        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[idx].Name + ' coupon. This is not valid with any other coupon.');
                                //        ro.ui.hideLoader();
                                //        return;
                                //    }
                                //}
                                
                                //for (var idx = 0, idxMax = (Ti.App.OrderObj && Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length ? Ti.App.OrderObj.TempCpns.length : 0); idx < idxMax; idx++) {
                                //    if (Ti.App.OrderObj.TempCpns[idx].IsExclusive) {
                                //        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.TempCpns[idx].Name + ' coupon. This is not valid with any other coupon.');
                                //        ro.ui.hideLoader();
                                //        return;
                                //    }
                                //}
                                
                                //for (var idx = 0, idxMax = (Ti.App.OrderObj && Ti.App.OrderObj.Items ? Ti.App.OrderObj.Items.length : 0); idx < idxMax; idx++) {
                                //    if(Ti.App.OrderObj.Items[idx].CpnObj){
                                //        if (Ti.App.OrderObj.Items[idx].CpnObj.IsExclusive) {
                                //            ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Items[idx].CpnObj.Name + ' coupon. This is not valid with any other coupon.');
                                //            ro.ui.hideLoader();
                                //            return;
                                //        }
                                //    }
                                //}
                 
                              
                                var storeObj = ro.app.Store;
                                for (var cpnIdx = 0, iMax = storeObj.Menu.Cpns.length; cpnIdx < iMax; cpnIdx++) {
                                    if (ro.app.Store.Menu.Cpns[cpnIdx].Key == e.row.cpnKey) {                                        
                                        if (Ti.App.OrderObj.Cpns) {
                                            if (Ti.App.OrderObj.Cpns.length > 0 && storeObj.Menu.Cpns[cpnIdx].IsExclusive) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
                                                ro.ui.hideLoader();
                                                return;
                                            }

                                            for (var i = 0; i < Ti.App.OrderObj.Cpns.length; i++) {
                                                if (Ti.App.OrderObj.Cpns[i].IsExclusive) {
                                                    ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Cpns[i].Name + ' coupon. This is not valid with any other coupon.');
                                                    ro.ui.hideLoader();
                                                    return;
                                                }

                                                if (Ti.App.OrderObj.Cpns[i].Name == storeObj.Menu.Cpns[cpnIdx].Name) {
                                                    if (storeObj.Menu.Cpns[cpnIdx].CpnScope == 1) {
                                                        ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Cpns[i].Name + ' coupon has already been applied to your order.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }
                                                }

                                                if (Ti.App.OrderObj.Cpns[i].CpnType == 2) {
                                                    if (parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2) {
                                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        if (Ti.App.OrderObj.TempCpns) {
                                            if (Ti.App.OrderObj.TempCpns.length > 0 && storeObj.Menu.Cpns[cpnIdx].IsExclusive) {
                                                ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
                                                ro.ui.hideLoader();
                                                return;
                                            }

                                            for (var i = 0; i < Ti.App.OrderObj.TempCpns.length; i++) {
                                                if (Ti.App.OrderObj.TempCpns[i].IsExclusive) {
                                                    ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.TempCpns[i].Name + ' coupon. This is not valid with any other coupon.');
                                                    ro.ui.hideLoader();
                                                    return;
                                                }

                                                if (Ti.App.OrderObj.TempCpns[i].Name == storeObj.Menu.Cpns[cpnIdx].Name) {
                                                    if (storeObj.Menu.Cpns[cpnIdx].CpnScope == 1) {
                                                        ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.TempCpns[i].Name + ' coupon has already been applied to your order.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }
                                                }

                                                if (Ti.App.OrderObj.TempCpns[i].CpnType == 2) {
                                                    if (parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2) {
                                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        if (Ti.App.OrderObj.Items) {
                                            for (var x = 0; x < Ti.App.OrderObj.Items.length; x++) {
                                                if (Ti.App.OrderObj.Items[x].CpnObj) {
                                                    if (storeObj.Menu.Cpns[cpnIdx].IsExclusive) {
                                                        ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' coupon is not valid with any other coupon.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }

                                                    if (Ti.App.OrderObj.Items[x].CpnObj.IsExclusive) {
                                                        ro.ui.alert('Coupon Not Valid', 'Your cart has ' + Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon. This is not valid with any other coupon.');
                                                        ro.ui.hideLoader();
                                                        return;
                                                    }

                                                    if (Ti.App.OrderObj.Items[x].CpnObj.Name == storeObj.Menu.Cpns[cpnIdx].Name) {
                                                        if (storeObj.Menu.Cpns[cpnIdx].CpnScope == 1) {
                                                            ro.ui.alert('Coupon Not Valid', Ti.App.OrderObj.Items[x].CpnObj.Name + ' coupon has already been applied to your order.');
                                                            ro.ui.hideLoader();
                                                            return;
                                                        }
                                                    }

                                                    if (Ti.App.OrderObj.Items[x].CpnObj.CpnType == 2) {
                                                        if (parseInt(storeObj.Menu.Cpns[cpnIdx].CpnScope, 10) == 1 && parseInt(storeObj.Menu.Cpns[cpnIdx].CpnType, 10) == 2) {
                                                            ro.ui.alert('Coupon Not Valid', storeObj.Menu.Cpns[cpnIdx].Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
                                                            ro.ui.hideLoader();
                                                            return;
                                                        }
                                                    }
                                                }

                                            }
                                        }

                                        if (!menuUtils.isCpnConfiguredProperly(ro.app.Store.Menu.Cpns[cpnIdx])) {
									   	   ro.ui.alert('Invalid Coupon. ', 'The store has not configured this coupon properly.');
                                            ro.ui.hideLoader();
                                            return;
									   }
                                        //Ti.API.debug('ro.app.Store.Menu.Cpns['+i+']: ' + JSON.stringify(ro.app.Store.Menu.Cpns[i]));                                        
                                        if (ro.app.Store.Menu.Cpns[cpnIdx].CpnScope === 1) {
                                            if (ro.cpnHelper.validatePctCpn(cpnIdx)) {
                                                ro.cpnHelper.addPctCpn(ro.app.Store.Menu.Cpns[cpnIdx]);
                                            }
                                            ro.ui.hideLoader();
                                            return;
                                        }                                        
                                        break;
                                    }
                                }
                                ro.cpnHelper.setCpnBool(true);
                                ro.utils.removeProp('SelectedCoupon');
                                ro.utils.removeProp('nrq');
                                ro.utils.removeProp('rq');
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'cpnSelView',
                                    cpnKey: e.row.cpnKey
                                });
                                //ca.showData(e.row.txtObj);
                            }
                            catch(ex) {
                                ro.ca.showData(e.row.txtObj);
                                ro.ui.hideLoader();
                            }
                            return;
                        }
                        else {
                            //Ti.API.debug('cpnHelper.isPickAnyCpn(): ' + cpnHelper.isPickAnyCpn());
                            //Ti.API.debug('refreshGrp: ' + refreshGrp);
                            //Ti.API.debug('cpnHelper.isPickAnyCpn(): ' + cpnHelper.isPickAnyCpn());                            
                            if (ro.cpnHelper.isPickAnyCpn() && (refreshGrp.toLowerCase() == "pick any" || refreshGrp.toLowerCase() == 'required item')) {
                                //Ti.API.debug('e.index: ' + e.index);
                                //Ti.API.debug('e.row.grpIndex: ' + e.row.grpIndex);
                                group = ro.app.Store.Menu.Groups[e.row.grpIndex];
                                ro.app.group = ro.app.Store.Menu.Groups[e.row.grpIndex];
                                itemIndex = ro.cpnHelper.getActualIdx(e.row.idx, (refreshGrp.toLowerCase() == 'required item') ? true : false);
                                ro.app.itemSelected = group.Items[itemIndex];
                            }
                            else {
                                ro.app.itemSelected = group.Items[e.row.idx];
                                //itemIndex = e.index;
                            }
                            if (itemViewCpnBoole && !e.row.hasTheCheck) {
                                ro.cpnHelper.clearSelection();
                            }
                            if (!itemViewCpnBoole && menuUtils.straightToCart()) {
                                var ITEMOBJ = require('logic/itemObj');
                                ITEMOBJ.itemobj(ro);
                                ro.itemObj.InitializeItemObj();
                                //InitializeItemObj();
                                ro.itemObj.setNoSizes();
                                menuUtils.addToCart(ro.app.Store, ro.itemObj.getItemObj(), true);
                            }
                            else {
                                ro.ui.ordShowNext({
                                    addView: true,
                                    showing: 'itemDetails'
                                });
                            }
                        }
                    }
                    catch(ex) {
                        if (Ti.App.DEBUGBOOL) {
                            Ti.API.debug('tblItems-ClickEvent-Exception: ' + ex);
                        }
                    }
                });

            }


            function formItmDesc(Itm) {
                var rtnDesc = "";
                if (Itm.ItemDesc) {
                    rtnDesc = Itm.ItemDesc;
                }
                else {
                    var preModsFound = false;
                    if (Itm.PreMods) {
                        if (Itm.PreMods.length > 0) {
                            if (curSelectedGroup == "Pizza") {
                                rtnDesc += "Our " + Itm.ReceiptName + " is topped with ";
                            }
                            else {
                                rtnDesc += Itm.ReceiptName + " is served with ";
                            }

                            for (var i = 0; i < Itm.PreMods.length; i++) {
                                if (group.Mods) {
                                    for (var j = 0; j < group.Mods.length; j++) {
                                        if (Itm.PreMods[i].Name == group.Mods[j].Name) {
                                            preModsFound = true;
                                            rtnDesc += group.Mods[j].ReceiptName;
                                            if (i != Itm.PreMods.length - 1) {
                                                rtnDesc += ", ";
                                            }
                                        }
                                    }
                                }
                            }

                            if (preModsFound) {
                                rtnDesc += ".";
                            }
                            else {
                                rtnDesc = "";
                            }
                        }
                    }
                }
                var rtnObj = {};
                rtnObj.description = rtnDesc;
                rtnObj.txtObj = null;
                return rtnObj;
            }

            function formCpnDesc(coupon) {
                var cpnObj = {};
                cpnObj.cpnKey = coupon.Key;
                var cpnDescription = "";
                var cpnInstructions = "";
                if (coupon.CpnScope == 3) {
                    var itms = [];
                    var itmLngth = itms.length;
                    var itmFound;
                    var curItm;
                    var couponCount = coupon.Items ? coupon.Items.length : 0;
                    for (var j = 0; j < couponCount; j++) {
                        itmFound = false;
                        curItm = {};
                        curItm.MenuItem = coupon.Items[j].MenuItem;
                        curItm.MenuSize = coupon.Items[j].MenuSize;
                        curItm.MenuStyle = coupon.Items[j].MenuStyle;
                        curItm.MenuGroup = coupon.Items[j].MenuGroup;
                        curItm.Qty = 1;
                        for (var k = 0; k < itmLngth; k++) {
                            if (itms[k].MenuItem == curItm.MenuItem && itms[k].MenuSize == curItm.MenuSize && itms[k].MenuStyle == curItm.MenuStyle) {
                                itms[k].Qty += 1;
                                itmFound = true;
                                break;
                            }
                        }
                        if (!itmFound) {
                            itms.push(curItm);
                        }

                    }
                    var tempTxt;
                    for (var j = 0; j < itmLngth; j++) {
                        cpnDescription += itms[j].MenuGroup + ': ';
                        cpnInstructions += (j + 1) + '. ';
                        if (itms[j].MenuSize == "All" && itms[j].MenuStyle == "All" && itms[j].MenuItem == "All") {
                            cpnDescription += 'Any ' + itms[j].Qty + ' of your choice.';
                            cpnInstructions += 'Add any ' + itms[j].Qty + ' ' + itms[j].MenuGroup + ' of your choice.';
                        }
                        else {
                            tempTxt = 'Add ' + itms[j].Qty + ' ';
                            cpnDescription += itms[j].Qty + ' ';

                            if (itms[j].MenuSize != "All") {
                                cpnDescription += itms[j].MenuSize + ' ';
                                tempTxt += itms[j].MenuSize + ' ';
                            }

                            if (itms[j].MenuStyle != "All") {
                                cpnDescription += itms[j].MenuStyle + ' ';
                                tempTxt += itms[j].MenuStyle + ' ';
                            }

                            if (itms[j].MenuItem != "All") {
                                cpnDescription += itms[j].MenuItem + '.';
                                tempTxt += itms[j].MenuItem + '.';
                            }
                            else {
                                cpnDescription = 'Any ' + cpnDescription + 'of your choice.';
                                tempTxt += itms[j].MenuGroup + ' of your choice.';
                            }
                            cpnInstructions += tempTxt;
                        }

                        if (j != itmLngth - 1) {
                            cpnDescription += '\n';
                        }
                        cpnInstructions += '\n';
                    }
                    cpnInstructions += (itmLngth + 1) + '. ' + 'Proceed to Cart.' + '\n';
                    cpnInstructions += (itmLngth + 2) + '. ' + 'Click on Coupons.' + '\n';
                    cpnInstructions += (itmLngth + 3) + '. ' + 'Tap on ' + '"' + coupon.RcptName + '"' + ' to apply.';
                }
                else {
                    cpnDescription = coupon.CpnDesc;
                    cpnInstructions = "";
                }
                cpnTxt = {};
                cpnTxt.RcptName = coupon.RcptName;
                cpnTxt.cpnInstructions = cpnInstructions;

                cpnObj.description = coupon.CpnDesc;
                cpnObj.txtObj = cpnTxt;
                return cpnObj;
            }

            var stretchRowImg = function(GRPName) {
                if (Ti.App.picklemansStyle) {
                    return GRPName != 'Coupons' && GRPName != 'My Rewards' && GRPName != 'Orders';
                }
                return false;
            };
            function newAddItem(receiptName, obj, imgPath, isCoupon, idx, itemPrice, grpIndx, hasSurcharge) {
                //ro.cpnHelper.checkIfSizesExist();
                var hasImg = (imgPath && imgPath.length > 0);
                var left = ro.ui.relX(7);
                var cls = ( hasImg ? 'item' : 'noitem');
                var hasRightImg = false;

                var bottom = 30;
                
                if(!itemPrice || !itemPrice.length){
                    bottom = 0;                    
                }
                
                var theRow = Ti.UI.createTableViewRow({
                    selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                    hasChild: false,
                    height: ro.ui.relY(175), //120
                    itmType: ( isCoupon ? 'coupon' : 'item'),
                    txtObj: obj.txtObj,
                    hasTheCheck: hasRightImg,
                    idx: idx,
                    grpIndex: grpIndx,
                    width: ro.ui.displayCaps.platformWidth,
                    layout: 'horizontal',
                    backgroundColor: ((idx % 2) ? ro.ui.theme.menuItemRowColors.background : ro.ui.theme.menuItemRowColors.altBackground)
                });
                if (isCoupon) {
                    theRow.cpnKey = obj.cpnKey;
                }
                var leftVw = Ti.UI.createView({
                    width: (9 / 10) * (ro.ui.displayCaps.platformWidth / 2) - 7,
                    height: Ti.UI.FILL
                });
                var imageHolder = Ti.UI.createView({
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: ro.ui.relY(bottom)
                });
                
                var bottomAlignPrice = true;
			   	if(Ti.App.serviceURL === 'https://hungryhowies.hungerrush.com/RevService.asmx' || Ti.App.serviceURL === 'https://hhtraining.hungerrush.com/RevService.asmx' || Ti.App.serviceURL === 'https://demo.hungerrush.com/RevService.asmx'){
			   	   bottomAlignPrice = false;
                }

                imageHolder.add(Ti.UI.createImageView({
                    image: hasImg ? imgPath : (isCoupon ? (ro.ui.properties.defaultPath + 'myDeals.png') : group.ImageSource),
                    defaultImage: ro.ui.properties.defaultImgPath,
                    top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null, //ro.ui.relX(15),
                    bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
                }));
                var labelHolder = Ti.UI.createView({
                    bottom: bottomAlignPrice ? ro.ui.relY(0) : ro.ui.relY(15),
                    left: 0,
                    right: 0,
                    height: ro.ui.relY(bottom)
                });
                labelHolder.add(Ti.UI.createLabel({
                    text: itemPrice,
                    font: {
                        fontFamily: ro.ui.fonts.prices.newItemsView,
                        fontSize: ro.ui.scaleFont(20),
                        //fontWeight:'bold'
                    },
                    color: ((idx % 2) ? ro.ui.theme.menuItemRowColors.priceColor : ro.ui.theme.menuItemRowColors.altPriceColor)
                }));
                //if(!isCoupon){
                		leftVw.add(imageHolder);
                //}
                
                leftVw.add(labelHolder);
                /*Ti.API.debug('(ro.ui.displayCaps.platformWidth/2)*(11/10): ' + (ro.ui.displayCaps.platformWidth/2)*(11/10));
                 Ti.API.debug('(9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7: ' + ((9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7));
                 var xx = (9/10)*(ro.ui.displayCaps.platformWidth / 2) - 7;
                 var yy = (ro.ui.displayCaps.platformWidth/2)*(11/10);
                 Ti.API.debug('zz: ' + (xx + yy));
                 Ti.API.debug('ro.ui.displayCaps: ' + JSON.stringify(ro.ui.displayCaps));
                 */
                var rightVw = Ti.UI.createView({
                    width: (ro.ui.displayCaps.platformWidth / 2) * (11 / 10),
                    //width:Ti.UI.FILL,
                    height: Ti.UI.SIZE,
                    layout: 'vertical'
                });
                var titleHolder = Ti.UI.createView({
                    height: ro.ui.relY(35),
                    width: Ti.UI.FILL
                });
                titleHolder.add(Ti.UI.createLabel({
                    text: receiptName,
                    color: ((idx % 2) ? ro.ui.theme.menuItemRowColors.titleColor : ro.ui.theme.menuItemRowColors.altTitleColor),
                    textAlign: 'left',
                    left: 0,
                    font: {
                        fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(18),
                        //fontWeight:'bold'
                    }
                }));
                ////Ti.API.debug('titleHolder: ' + JSON.stringify(titleHolder));
                var bodyHolder = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: Ti.UI.FILL
                });
                bodyHolder.add(Ti.UI.createLabel({
                    color: ((idx % 2) ? ro.ui.theme.menuItemRowColors.titleColor : ro.ui.theme.menuItemRowColors.altTitleColor),
                    text: obj.description,
                    textAlign: 'left',
                    left: 0,
                    top: 0,
                    font: {
                        fontFamily: ro.ui.fonts.rowBodyTxt,
                        fontSize: ro.ui.scaleFont(13)
                    }
                }));
                
                ////Ti.API.debug('bodyHolder: ' + JSON.stringify(bodyHolder));
                rightVw.add(titleHolder);
                rightVw.add(bodyHolder);
                if (hasSurcharge) {
                    var Config = JSON.parse(Ti.App.Properties.getString('Config'));
                    if (!Config) {
                        Config = {};
                    }
                    var surchargeTxt = 'Surcharge may apply';
                    if (Config.hasOwnProperty('CPN_SCHG_INFO_TXT') && Config.CPN_SCHG_INFO_TXT != '') {
                        surchargeTxt = Config.CPN_SCHG_INFO_TXT;
                    }
                    var surchargeHolder = Ti.UI.createView({
                        height: Ti.UI.SIZE,
                        width: Ti.UI.FILL
                    });
                    surchargeHolder.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.surchargeLbl, {                        
                        text: surchargeTxt,
                        textAlign: 'left',
                        left: 0,
                        top: 0
                    })));
                    rightVw.add(surchargeHolder);
                }

                theRow.add(leftVw);
                theRow.add(rightVw);
                itemsData.push(theRow);
                //itemsData[idx] = theRow;
                return theRow;
            }

            function addItem(receiptName, obj, imgPath, isCoupon, idx, itemPrice, grpIndx) {                    
                var hasImg = (imgPath && imgPath.length > 0);
                var left = ro.ui.relX(7);
                var cls = ( hasImg ? 'item' : 'noitem');
                var hasRightImg = false;

                if (itemViewCpnBoole) {
                    if (ro.cpnHelper.chosenItem(receiptName)) {
                        hasRightImg = true;
                    }
                }

                var theRow = Ti.UI.createTableViewRow({
                    selectionStyle: ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
                    hasChild: false,
                    height: ro.ui.relY(100), //120
                    itmType: ( isCoupon ? 'coupon' : 'item'),
                    txtObj: obj.txtObj,
                    hasTheCheck: hasRightImg,
                    grpIndex: grpIndx

                });
                if (isCoupon) {
                    theRow.cpnKey = obj.cpnKey;
                }
                var rowVw = Ti.UI.createView({
                    height: Ti.UI.FILL,
                    width: Ti.UI.FILL,
                    top: ro.ui.relY(1),
                    bottom: ro.ui.relY(1),
                    backgroundColor:((idx % 2) ? ro.ui.theme.menuItemRowColors.background : ro.ui.theme.menuItemRowColors.altBackground)
                    //backgroundImage:'/images/menuItemBg.png'//,//Ti.App.websiteURL+'/content/images/menu-item.png',//ro.ui.theme.menuItemImg
                    //backgroundColor:ro.ui.theme.cpnRowTileColor
                });
                /*var backgroundImg = Ti.UI.createImageView({
                 image:Ti.App.websiteURL+'/content/images/menu-item.png',
                 defaultImage:'/images/menuItemBg.png',
                 height: Ti.UI.FILL,
                 width: Ti.UI.FILL,
                 zIndex: -1000,
                 touchEnabled: false,
                 borderRadius:Ti.App.JETSDEMO ? ro.ui.relX(7) : null,
                 borderColor:Ti.App.JETSDEMO ? ro.ui.theme.jetsdemo : null,
                 borderWidth:Ti.App.JETSDEMO ? ro.ui.relX(1.5) : null
                 });
                 rowVw.add(backgroundImg);*/

                if (hasImg && !isCoupon) {//} || (group && group.ImageSource && group.ImageSource.length > 0)){
                    left = Ti.App.picklemansStyle ? ( isCoupon ? ro.ui.relX(100) : ro.ui.relX(110)) : ro.ui.relX(105);
                    //80
                    var imageWrapper = Ti.UI.createView({
                        width: ro.ui.relX(95),
                        left: Ti.App.picklemansStyle ? 4 : ro.ui.relX(6),
                        top: Ti.App.picklemansStyle ? -4 : ro.ui.relX(6),
                        bottom: ro.ui.relX(6)
                    });
                    var oldCpnImg = Ti.App.websiteURL + '/site/groupimages/tabs/deals.png';

                    imageWrapper.add(Ti.UI.createImageView({
                        image: isCoupon ? (ro.ui.properties.defaultPath + 'myDeals.png') : ( hasImg ? imgPath : group.ImageSource),
                        defaultImage: ro.ui.properties.defaultImgPath,
                        top: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null, //ro.ui.relX(15),
                        bottom: Ti.App.picklemansStyle ? ( isCoupon ? null : ro.ui.relX(0)) : null//ro.ui.relX(15)
                    }));
                    /*imageWrapper.add(Ti.UI.createImageView({
                     image:isCoupon ? (Ti.App.websiteURL + '/site/groupimages/tabs/deals.png') : (hasImg?imgPath:group.ImageSource),
                     defaultImage:isCoupon ? ro.ui.properties.defaultPath + 'coupon.png' : ro.ui.properties.defaultImgPath,
                     width:Ti.App.picklemansStyle ? ro.ui.relX(110) : (isCoupon ? ro.ui.relY(60) : ro.ui.relY(103)),//ro.ui.relX(87), //70
                     height:Ti.App.picklemansStyle ? Ti.UI.FILL : (isCoupon ? ro.ui.relY(60) : ro.ui.relY(90)),//ro.ui.relY(90),//Ti.UI.FILL,
                     left:Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(5),
                     top:Ti.App.picklemansStyle ? ro.ui.relX(0) : null,//ro.ui.relX(15),
                     bottom:Ti.App.picklemansStyle ? ro.ui.relX(0) : null//ro.ui.relX(15)
                     }));*/
                    rowVw.add(imageWrapper);
                }
                var labelVw = Ti.UI.createView({
                    height: Ti.UI.SIZE,
                    width: Ti.UI.SIZE,
                    right: ro.ui.relX(10),
                    layout: 'vertical',
                    left: left
                });

                var finalString = receiptName;
                // + '\n' + itemPrice;

                var attributesCol = [];
                if (itemPrice && itemPrice.length) {
                    var beginLength = finalString.length;
                    finalString = finalString + ' - ' + itemPrice;
                    //Ti.API.debug('finalString: ' + finalString);

                    attributesCol.push({
                        type: Ti.UI.ATTRIBUTE_FONT,
                        value: {
                            fontSize: ro.ui.scaleFont(10),
                            fontWeight: 'normal'
                        },
                        range: [receiptName.length + 1, (itemPrice && itemPrice.length ? itemPrice.length + 2 : 0)]
                    });
                    attributesCol.push({
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: ro.ui.theme.itemPriceColor,
                        range: [receiptName.length + 2, (itemPrice && itemPrice.length ? itemPrice.length + 1 : 0)]
                    });
                }
                var attr = Ti.UI.createAttributedString({
                    text: finalString,
                    attributes: attributesCol
                });

                labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsName, {
                    color: ro.ui.theme.newGroupsBtnTxt,
                    attributedString: attr,
                    width: Ti.UI.SIZE,
                    top: Ti.App.picklemansStyle ? ro.ui.relY(10) : ro.ui.relY(1),
                    font: {
                    		fontFamily: ro.ui.fonts.titles,
                        fontSize: ro.ui.scaleFont(18)//,
                        //fontSize: ro.ui.scaleFont(16), //11
                        //fontWeight: 'bold',
                        //fontFamily: ro.ui.fontFamily
                    }
                })));

                labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsDetails, {
                    color: ro.ui.theme.newGroupsBtnTxt, //ro.ui.theme.contentsSmallTxt,
                    text: obj.description,
                    height: Ti.UI.SIZE,
                    width: Ti.UI.SIZE,
                    top: ro.ui.relY(1),
                    font: {
                    		fontFamily: ro.ui.fonts.rowBodyTxt,
                        fontSize: ro.ui.scaleFont(13)
                        //fontSize: ro.ui.scaleFont(11),
                       // fontFamily: ro.ui.fontFamily//10
                    }
                })));
                rowVw.add(labelVw);
                if (hasRightImg) {
                    var rowChk = Ti.UI.createImageView({
                        //left:ro.ui.relX(5),
                        right: ro.ui.relX(3),
                        image: '/images/check.png'//,
                        //visible:false
                    });
                    rowVw.checkMark = rowChk;
                    rowVw.add(rowVw.checkMark);
                }
                theRow.add(rowVw);
                itemsData[idx] = theRow;
                ////Ti.API.debug('itemsData['+idx+']: ' + JSON.stringify(itemsData[idx]));
            }

            function addCoupons() {
                var j,
                    k,
                    CpnIdx,
                    blnVis,
                    deliveryType,
                    curDate,
                    UTCTime,
                    startDt,
                    ExpirDt;
                var BtnIdx = 0;
                var curOrdType = Ti.App.OrderObj.OrdType;
                var cpnLngth = ro.app.Store.Menu.Cpns.length;

                for ( CpnIdx = 0; CpnIdx < cpnLngth; CpnIdx++) {
                    if (!ro.app.Store.Menu.Cpns[CpnIdx].ReqValCode || ro.app.Store.Menu.Cpns[CpnIdx].VCSupress) {//&& parseInt(ro.app.Store.Menu.Cpns[CpnIdx].CpnScope, 10) != 1){
                        blnVis = false;
                        curDate = new Date();
                        UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);

                        if (ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All') {
                            blnVis = true;
                            if (ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER') {
                                blnVis = false;
                                continue;
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].CpnScope === 3) {
                                if (!ro.app.Store.Menu.Cpns[CpnIdx].Items) {
                                    blnVis = false;
                                    continue;
                                }
                            }
                            /*if(ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true && isGuest){
                             blnVis = false;
                             continue;
                             }*/
                            if(ro.app.Store.Menu.Cpns[CpnIdx].MultiQualTtl && ro.app.Store.Menu.Cpns[CpnIdx].MultiQualTtl > 0){
                                var cpnCols = [];
                                var shouldContinue = false;
                                if(Ti.App.OrderObj){
                                    if(Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length){
                                        cpnCols.push('Cpns');
                                    }
                                    if(Ti.App.OrderObj.TempCpns && Ti.App.OrderObj.TempCpns.length){
                                        cpnCols.push('TempCpns');
                                    }
                                }
                                for(var i=0, iMax=cpnCols.length; i<iMax; i++){
                                    var cpnCol = Ti.App.OrderObj[cpnCols[i]];
                                    for(var j=0, jMax = cpnCol.length; j<jMax; j++){
                                        if(cpnCol[j].MultiQualTtl && cpnCol[j].MultiQualTtl > 0){
                                            blnVis = false;
                                            shouldContinue = true;
                                            break;
                                        }
                                    }
                                    if (shouldContinue) {
                                        break;
                                    }
                                }
                                if (shouldContinue) {
                                    continue;
                                }
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true) {// && isGuest){
                                if (isGuest) {
                                    blnVis = false;
                                    continue;
                                }
                                else {
                                    var rs = ro.db.getCustObj(Ti.App.Username);
                                    if (!rs) {
                                        rs = {};
                                    }
                                    if (!rs.CpnUsage) {
                                        rs.CpnUsage = [];
                                    }
                                    else {
                                        rs.CpnUsage = rs.CpnUsage.split("-");
                                    }

                                    var shouldContinue = false;
                                    for (var cpnUsageIdx = 0, cpnUsageMax = rs.CpnUsage.length; cpnUsageIdx < cpnUsageMax; cpnUsageIdx++) {
                                        //Ti.API.debug('rs.CpnUsage['+cpnUsageIdx+']: ' + rs.CpnUsage[cpnUsageIdx]);
                                        if (ro.app.Store.Menu.Cpns[CpnIdx].Key == rs.CpnUsage[cpnUsageIdx]) {
                                            blnVis = false;
                                            shouldContinue = true;
                                            break;
                                        }
                                    }

                                    for (var currCpnIdx = 0, currCpnMax = Ti.App.OrderObj && Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; currCpnIdx < currCpnMax; currCpnIdx++) {
                                        if (Ti.App.OrderObj.Cpns[currCpnIdx].SingleUseKey == ro.app.Store.Menu.Cpns[CpnIdx].Key) {
                                            blnVis = false;
                                            shouldContinue = true;
                                            break;
                                        }
                                    }

                                    if (shouldContinue) {
                                        // Ti.API.debug('continuing due to already having used this single use cpn...IT SHOULD NOT SHOW UP IN CPN LIST');
                                        continue;
                                    }
                                }
                            }

                            if (ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes && ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
                                for(var exclOrdIdx = 0; exclOrdIdx < ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; exclOrdIdx++){
                                    if(Ti.App.OrderObj.OrdType == ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
                                        blnVis = false;
                                        continue;
                                    }
                                }
                            }

                            if (ro.app.Store.Menu.Cpns[CpnIdx].HasStartDt) {
                                startDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].StartDtStr);
                                if (startDt.getTime() > timeAtStore.getTime()) {
                                    blnVis = false;
                                    continue;
                                }
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].HasExpirDt) {
                                ExpirDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].ExpirDtStr);
                                var StoreDate = new Date(timeAtStore);
                                ExpirDt.setHours(0, 0, 0, 0);
                                StoreDate.setHours(0, 0, 0, 0);
                                if (ExpirDt.getTime() < StoreDate.getTime()) {
                                    //Ti.API.debug('ExpirDt: ' + JSON.stringify(ExpirDt));
                                    blnVis = false;
                                    continue;
                                }
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].Weekdays > 0) {
                                if (blnVis == true) {
                                    if (!menuUtils.WeekdayValid(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays, timeAtStore)) {
                                        blnVis = false;
                                        continue;
                                    }
                                }
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx > 0) {
                                if (blnVis == true) {                                    
                                    //if (!menuUtils.IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTime, ro.app.Store.Menu.Cpns[CpnIdx].EndTime, timeAtStore)) {
                                        if (!menuUtils.IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTimeStr, ro.app.Store.Menu.Cpns[CpnIdx].EndTimeStr, timeAtStore)) {
                                            blnVis = false;
                                            continue;
                                        }
                                    //}
                                }
                            }
                            if (ro.app.Store.Menu.Cpns[CpnIdx].HasExcldOrdType) {
                                if (ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes) {
                                    for ( j = 0; j < ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; j++) {
                                        if (ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[j] == curOrdType) {
                                            blnVis = false;
                                            continue;
                                        }
                                    }
                                }
                            }
                            if (Ti.App.OrderObj.ordOnlineOptions.IsDelivery) {
                                if (ro.app.Store.Menu.Cpns[CpnIdx].NoDelivery) {
                                    blnVis = false;
                                    continue;
                                }
                            }
                            if (blnVis) {
                                Coupons.push(ro.app.Store.Menu.Cpns[CpnIdx]);
                            }
                        }
                    }
                }
            }
			//function addToPrev
			
			function addToPrev(i, isFav) {
				
				var idx = itemsData.length;
				
				var hdrTxt = prevOrdObj[i].Name ? prevOrdObj[i].Name : 'Order #' + (i + 1),
					bodyTxt = formDescription(i),
					url = isFav ? '/images/favorite.png' : '/images/prevFavorite.png';
				
				var campaignRowVw = ro.layout.getEmptyGenericRow();
				campaignRowVw.itmType = 'prev';
				campaignRowVw.index = i;
				
				var imageHolderWidth = ro.ui.relX(40);

				var imagePadding = ro.ui.relX(6);
				var fontSize = ro.ui.scaleFont(15);
				var imageHolder = Ti.UI.createView({
					left : imagePadding,
					width : imageHolderWidth,
					height : Ti.UI.FILL,
					touchEnabled : false
				});
				imageHolder.add(Ti.UI.createImageView({
					image : url,
					touchEnabled : false
				}));
				var labelHolder = Ti.UI.createView({
					left : imageHolderWidth + (2 * imagePadding),
					right : ro.ui.relX(50),
					height : Ti.UI.SIZE,
					layout : 'vertical',
					touchEnabled : false
				});
				var topLblHolder,
				    bottomLblHolder;

				var topLbl = Ti.UI.createLabel({
					height : Ti.UI.SIZE,
					touchEnabled : false,
					color : '#393839',
					font : {
						fontFamily : ro.ui.fonts.rowHdrTxt,
						fontSize : fontSize
					},
					text : hdrTxt,
					left : 0
				});

				var bottomLblHolder = Ti.UI.createView({
					touchEnabled : false,
					width : Ti.UI.FILL,
					layout : 'horizontal',
					height : Ti.UI.SIZE
				});
				bottomLblHolder.add(Ti.UI.createLabel({
					touchEnabled : false,
					color : '#393839',
					font : {
						fontFamily : ro.ui.fonts.rowBodyTxt,
						fontSize : fontSize
					},
					text : bodyTxt,
					left : 0
				}));
				/*bottomLblHolder.add(Ti.UI.createLabel({
					touchEnabled : false,
					color : '#393839',
					font : {
						fontFamily : ro.ui.fonts.rowBodyTxt,
						fontSize : fontSize
					},
					text : currRewardExpirTxt || "",
					left : ro.ui.relX(10)
				}));*/

				//labelHolder.add(topLblHolder);
				labelHolder.add(topLbl);
				labelHolder.add(bottomLblHolder);

				campaignRowVw.add(imageHolder);
				campaignRowVw.add(labelHolder);

				if(!idx){
                    campaignRowVw.top = 0;
                }
                
                campaignRowVw.addEventListener('click', function(e){
                    //Ti.API.debug('e: ' + JSON.stringify(e));
                    //Ti.API.debug('e.source: ' + JSON.stringify(e.source));
                    //Ti.API.debug('e.source.index: ' + e.source.index);

                    if (!(ro.prevOrders.addToCart(prevOrdObj[e.source.index], ro.app.Store.Menu, Ti.App.OrderObj))) {
                        ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
                    }
                    else {
                        ro.ui.showCart();
                    }
                    ro.ui.hideLoader();
                    return;
                });
                
                itemsData[idx] = campaignRowVw;
				return campaignRowVw;
				
				
			}; 

            function oldAddToPrev(i, isFav) {
                try {
                    var idx = itemsData.length;
                    
                    //getCustomMenuRow = function(hdrTxt, bodyTxt, url, _callback) 
                    var hdrTxt = prevOrdObj[i].Name ? prevOrdObj[i].Name : 'Order #' + (i + 1);
                    var bodyTxt = formDescription(i);
                    var pastOrdRow = ro.layout.getCustomMenuRow(hdrTxt, bodyTxt, (isFav ? '/images/favorite.png' : '/images/prevFavorite.png'));
                    pastOrdRow.itmType = 'prev';
                    pastOrdRow.index = i;
                    
                    if(!idx){
                        pastOrdRow.top = 0;
                    }
                    
                    pastOrdRow.addEventListener('click', function(e){
                        //Ti.API.debug('e: ' + JSON.stringify(e));
                        //Ti.API.debug('e.source: ' + JSON.stringify(e.source));
                        //Ti.API.debug('e.source.index: ' + e.source.index);

                        if (!(ro.prevOrders.addToCart(prevOrdObj[e.source.index], ro.app.Store.Menu, Ti.App.OrderObj))) {
                            ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
                        }
                        else {
                            ro.ui.showCart();
                        }
                        ro.ui.hideLoader();
                        return;
                    });
                    
                    itemsData[idx] = pastOrdRow;
                    Ti.API.debug('addToPrev - i: ' + i);
                }
                catch(ex) {
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('addToPrev()-Exception: ' + ex);
                    }
                }
            }

            function formDescription(index) {
                var str = '';

                for (var i = 0; i < prevOrdObj[index].LastOrdItemCol.length; i++) {
                    str = str + '' + prevOrdObj[index].LastOrdItemCol[i].Qty + ' ' + prevOrdObj[index].LastOrdItemCol[i].RcptName;
                    if (i === prevOrdObj[index].LastOrdItemCol.length - 1) {

                    }
                    else {
                        str = str + ', ';
                    }
                }
                return str;
            }

            if (!Ti.App.RepeatLastOrder && refreshGrp == 'Coupons') {
                addCoupons();
            }

            var th = ro.ui.properties.plHeight - ro.ui.relY(199);
            var tr = ro.ui.relY(20) + (60) * (ro.ui.properties.devDpi / 160);
            var div = Math.ceil(th / tr);
            var itmDisplayableLen = (th % tr) == 0 ? div + 2 : div + 1;
            itmDisplayableLen += (ro.isiOS ? 1 : 0);
            var visibleRowCount = itmDisplayableLen;
            var showFav = false;

            
           		   var promoCodeBox = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth,
                        height: Ti.UI.SIZE,
                        layout: 'vertical',
                        top: ro.ui.relX(5)
                    });
                    //var cpnCodeTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Enter A Coupon Code';
                    var cpnCodeTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'ENTER A COUPON CODE';
            		    var cpnCodeLittleTxt = ro.app.Store.Configuration.CPN_HDR && ro.app.Store.Configuration.CPN_HDR.length ? ro.app.Store.Configuration.CPN_HDR : 'Coupon Code';
                    //promoCodeBox.add(ro.layout.getGenericHdrRowWithHeader(cpnCodeTxt, true));
                    //var cpnCodeLittleTxt = storeObj.Configuration.CPN_HDR && storeObj.Configuration.CPN_HDR.length ? storeObj.Configuration.CPN_HDR : 'Coupon Code';

                    var cpnView = Ti.UI.createView({
                        top: ro.ui.relY(5),
                        height: ro.ui.relY(40),
                        width: Ti.UI.SIZE,
                        //left: ro.ui.relX(25),
                        //right: ro.ui.relX(25),
                        layout: 'horizontal'
                    });
                    var cpnTextBox = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                        left: 0,
                        width: ro.ui.properties.wideViewWidth * .6,
                        height: Ti.UI.FILL,
                        hintText:cpnCodeLittleTxt,
                        //bottom:ro.ui.relX(5),
                        font: {
                        		fontFamily:ro.ui.fonts.textFields,
                            fontSize: ro.ui.scaleFont(18)
                        },
                        backgroundColor:'#f6f6f6',
                            borderColor:'#cbcbcb',
                            hintTextColor:'#393839'
                    }));
                    
                    function getKeyboardToolbar(doneEvt) {
						/*var picNext = Ti.UI.createButton({
							title : 'Next',
							style : Ti.UI.iOS.SystemButtonStyle.DONE,
							id : keyboardBtnId
						});*/
						var picDone = Ti.UI.createButton({
							title : 'Done',
							style : Ti.UI.iOS.SystemButtonStyle.DONE//,
							//id : keyboardBtnId
						});
		
						var picSpacer = Ti.UI.createButton({
							systemButton : Ti.UI.iOS.SystemButton.FLEXIBLE_SPACE
						});
		
						var picToolbar = Ti.UI.createToolbar({
							top : 0,
							items : [picSpacer, picDone],
							zIndex : 2,
							width : Ti.UI.FILL
						});
		
						picDone.addEventListener('click', doneEvt);
						//picNext.addEventListener('click', nextEvt);
		
						return picToolbar;
					};
		                var doneFn = function(){
		                		cpnTextBox.blur();
		                };
		                if(ro.isiOS){
		                	
	                    	  cpnTextBox.keyboardToolbar = getKeyboardToolbar(doneFn);
	                    }
		                   
                    var cpnBtn = Ti.UI.createView({
                        width: ro.ui.properties.wideViewWidth * .3,
                        height: Ti.UI.FILL,
                        //right: ro.ui.relX(15),
                        left: ro.ui.relX(15),
                        backgroundColor: ro.ui.theme.btnActive,
                        borderColor: ro.ui.theme.btnActive,
                        borderRadius: ro.ui.relX(20),
                        //bottom:ro.ui.relX(5)
                    });
                    cpnBtn.add(Ti.UI.createLabel({
                        text: 'Add',
                        font: {
                            //fontWeight:'bold',
                            fontFamily: ro.ui.fonts.button,
                            fontSize: ro.ui.scaleFont(19),
                            //fontFamily:ro.ui.fontFamily
                        },
                        color: ro.ui.theme.loginBtnWhite,
                        textAlign: 'center',
                        touchEnabled: false
                    }));

                     var cpnBtnClickTime = 0;
                     cpnBtn.addEventListener('click', function(e) {
                         if (new Date().getTime() - cpnBtnClickTime < 1000) {
                             Ti.API.info('returning');
                             return;
                         }
                         var thisClickTime = new Date();
                         cpnBtnClickTime = thisClickTime.getTime();
                         thisClickTime = null;
                         if (!cpnTextBox.value) {
                            ro.ui.alert('Error', 'Please enter a valid coupon code');
                            return;
                        }
                        /*if(EWOM.isEwomCode(codeTxt.value)){
                         EWOM.validateEwomCode(codeTxt.value, ro.app.Store.ID, function(newCode){
                         menuUtils.testCpnCode(newCode, false, true);
                         });
                         }
                         else{
                         menuUtils.testCpnCode(codeTxt.value, false, false);
                         }*/
                        if (ro.REV_LOYALTY.isValidCode(cpnTextBox.value)) {
                            ro.REV_LOYALTY.validateCoupon(cpnTextBox.value, ro.app.Store.ID, function(newCode, LoyaltyCode) {
                                         menuUtils.testCpnCode(newCode, false, true, LoyaltyCode);
                                     
                            }, false, false, function(){
                                     menuUtils.testCpnCode(cpnTextBox.value, false, false);//DYNAMIC CODE NOT FOUND FALLBACK
                                 });
                        }
                        else {
                            menuUtils.testCpnCode(cpnTextBox.value, false, false);
                        }
                     });
                    
                    cpnView.add(cpnTextBox);
                    cpnView.add(cpnBtn);

                    promoCodeBox.add(cpnView);
            
           
            //cpnTbl.add(applyBtn);

            function cpnVisibility(favVisibility) {
                try {
                    if (!favVisibility) {
                        itemsView.remove(tblItems);
                        //itemsView.remove(noItemsLbl);
                        itemsView.add(cpnTbl);
                    }
                    else {
                        itemsView.remove(cpnTbl);
                        itemsView.add(tblItems);
                        // itemsView.add(noItemsLbl);
                    }
                }
                catch(ex) {
                    Ti.API.debug('cpnVisibility()-Exception: ' + ex);
                }
            }

            function toggleVisibility(favVisibility) {
                try {
                    var pastOrderString = "";
                    itemsData = [];
                    tblItems.removeAllChildren();
                    items = prevOrdObj;
                    showFav = false;
                    itmDisplayLen = items.length;
                    if (itmDisplayLen > itmDisplayableLen) {
                        itmDisplayLen = itmDisplayableLen;
                    }
                    lastDispRowId = itmDisplayLen - 1;

                    if (!favVisibility && prevOrdObj) {
                        Ti.API.debug('!favVisibility: ' + !favVisibility);
                        var foundSome = false;
                        pastOrderString = "Your Recent Orders";
                        for (var i = 0; i < itmDisplayLen; i++) {
                        		if(!prevOrdObj[i].Name || !prevOrdObj[i].Name.length){
                        			addToPrev(i);
                            		foundSome = true;
                        		}
                            
                        }
                        if(!foundSome){
                            	
                            		var nonehdr = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitleBg, {
						           text:"No Orders Found",
						           font:ro.ui.font.pathToMenuTitles
						        }));
					         	nonehdr.top = ro.ui.relY(10);
					         	tblItems.add(nonehdr);
                            		return;
                            }
                    }
                    else {
                        if (prevOrdObj) {
                            pastOrderString = "Your Favorite List";
                            var foundSome = false;
                            for (var i = 0; i < itmDisplayLen; i++) {
                                if (!favVisibility || (favVisibility && prevOrdObj[i].Name)) {
                                    addToPrev(i, true);
                                    foundSome = true;
                                }
                            }
                            if(!foundSome){
                            	
                            		var nonehdr = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitleBg, {
							          text:"No Orders Found",
							          font:ro.ui.font.pathToMenuTitles
							       }));
					         //	view.add(nonehdr);
					         	nonehdr.top = ro.ui.relY(10);
                            		
                            		/*var nonehdr = ro.layout.getGenericHdrRow("No Orders Found");
                            		nonehdr.left = null;
                            		nonehdr.right = null;
                            		nonehdr.textAlign = 'center';
		                         nonehdr.top = ro.ui.relY(30);
		                         nonehdr.height = Ti.UI.SIZE;*/
		                        //tblItems
		                        tblItems.add(nonehdr);
                            		return;
                            }
                        }
                    }

                    if (prevOrdObj) {
                        
                        var hdr = ro.layout.getGenericHdrRowWithHeader(pastOrderString, true);
                        hdr.top = ro.ui.relY(10);
                        hdr.height = Ti.UI.SIZE;
                        
                        tblItems.add(hdr);
                        tblItems.add(itemsData);
                        /*if (ro.isiOS) {
                            tblItems.data = itemsData;
                        }
                        else {
                            tblItems.setData(itemsData);
                        }*/
                    }

                    setVisibility(true);
                }
                catch(e) {
                    Ti.API.debug('setVisibility - EXception: ' + e);

                }
            }

            function setVisibility(showOrd, showLoyalty) {
                if (showOrd) {
                    ordTabView.show();
                    ordTabView.height = ro.ui.relY(35);
                    ordTabView.top = ro.ui.relY(7.5);
                }
                else {
                    ordTabView.hide();
                    ordTabView.height = 0;
                    ordTabView.top = ro.ui.relY(0);
                }
                //Ti.API.debug('itemsData: ' + JSON.stringify(itemsData));
                if (itemsData && itemsData.length > 0) {
                    //itemsView.add(tblItems);
                    //tblItems.show();
                    //tblItems.visible = true;
                    //noItemsLbl.top = 0;
                    //noItemsLbl.height = 0;
                    // noItemsLbl.visible = false;
                    /*if(ro.isiOS){
                     tblItems.data = null;
                     tblItems.appendRow(itemsData);
                     }
                     else{
                     tblItems.setData(itemsData);
                     }
                     tblItems.scrollToIndex(0);*/
                    tblItems.scrollToIndex(0);
                }
                else {
                		if(!showOrd)
                    	   itemsView.remove(tblItems);
                    if (!showLoyalty) {
                        noItemsLbl.text = (curSelectedGroup == 'Coupons' ? 'No coupons available.' : 'No items available under ' + curSelectedGroup + '.');
                        noItemsLbl.visible = true;
                        itemsView.layout = 'composite';
                        //itemsView.add(noItemsLbl);
                    }
                }
            }


            ro.ui.refreshNewItems = function(curSelGroup) {
                try {
                    if (!curSelGroup) {
                        curSelGroup = 'Coupons';
                    }

                    itemsData = [];
                    curSelectedGroup = curSelGroup;
                    var showOrd = false;
                    var ordTabBool = false;
                    var loyaltyBln = false;

                    //Ti.API.debug('curSelectedGroup: ' + curSelectedGroup);

                    if (curSelectedGroup.toLowerCase() == 'pick any' || curSelectedGroup.toLowerCase() == 'required item') {

                        if (ro.app.Store && ro.app.Store.Menu && ro.app.Store.Menu.Groups) {
                            items = (curSelectedGroup.toLowerCase() == 'pick any') ? ro.cpnHelper.getPickAnyItems() : ro.cpnHelper.getRequireAnyItems();
                            //group.Items;
                            itmDisplayLen = items.length;

                            if (itmDisplayLen > itmDisplayableLen) {
                                itmDisplayLen = itmDisplayableLen;
                            }
                            lastDispRowId = itmDisplayLen - 1;
                            var path, hasSurcharge;
                            for (var j = 0; j < itmDisplayLen; j++) {                                
                                //var _gIdx = ro.utils.getMatchingIdx(items[j].ReportGrp, ro.app.Store.Menu.Groups, 'Name');
                                //Ti.API.debug('items[j].PickAnyGrpIdx: ' + items[j].PickAnyGrpIdx);
                                //Ti.API.debug('_gIdx: ' + _gIdx);
                                var _gIdx = items[j].PickAnyGrpIdx;
                                //var _gIdx = ro.utils.getMatchingIdx(items[j].ReportGrp, ro.app.Store.Menu.Groups, 'Name');
                                //var _gIdx = ro.utils.getMatchingIdx(items[j].ReportGrp, ro.app.Store.Menu.Groups, 'ReportGrp');

                                group = ro.app.Store.Menu.Groups[_gIdx];
                                ro.app.group = group;
                                //Ti.API.debug('group: ' + JSON.stringify(group));

                                path = null;
                                if (items[j].HasImage) {
                                    path = items[j].ImageSource;
                                }
                                /*else{
                                 path = '/images/default.png';
                                 }*/
                                hasSurcharge = false;
                                if (items[j].hasSurcharge) {
                                    hasSurcharge = true;
                                }
                                newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, ''/*menuHelper.getItemPrice(items[j], group,Ti.App.OrderObj.OrdTypePriceIdx)*/, _gIdx, hasSurcharge);
                            }
                        }
                        //if(ro.isiOS){
                        //tblItems.data = null;
                        //tblItems.data = itemsData;
                        /*}
                         else{
                         tblItems.setData(itemsData);
                         }
                         itemsView.add(tblItems);
                         if(curSelectedGroup != 'Coupons'){
                         setVisibility(showOrd);
                         }*/
                        if (ro.isiOS) {
                            //tblItems.data = [];
                            tblItems.data = itemsData;
                        }
                        else {
                            //Ti.API.debug('NOT IOS');
                            tblItems.setData(itemsData);
                        }
                        itemsView.add(tblItems);
                        //if(curSelectedGroup != 'Coupons'){
                        setVisibility(showOrd, loyaltyBln);
                        //}
                        tblItems.scrollToIndex(0);
                        return;
                    }

                    if (curSelectedGroup == 'My Rewards') {
                        var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
                        menuLoyaltyView = currentLoyalty.getTabLoyaltyMenuView(ro.app.Store.ID);
                        itemsView.add(menuLoyaltyView);
                        loyaltyBln = true;
                    }
                    else if (curSelectedGroup == 'Orders') {

                        /*var myRewardsView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.myRewardsScrollView, {
                         bottom : cpnEvtBln ? ro.ui.relY(50) : null,
                         totalItemCount : lastDispRowId,
                         firstVisibleItem : 0,
                         visibleItemCount : itmDisplayableLen
                         }));*/
                        

                        var cst = JSON.parse(Ti.App.Properties.getString('Customer', ''));
                        prevOrdObj = cst && cst.PrevOrders && cst.PrevOrders.length ? cst.PrevOrders : [];
                        showOrd = true;
                        if (prevOrdObj && prevOrdObj.length > 0) {
                            for (var i = 0; i < prevOrdObj.length; i++) {
                                if (prevOrdObj[i].Name) {
                                    ordTabBool = true;
                                }
                            }

                            ro.prevOrders.fillItmRcptNames(prevOrdObj, ro.app.Store.Menu || null);
                            if (ordTabBool) {
                                toggleVisibility(true);
                                if (!ordTab[0].ison) {
                                    ordTab[0].toggle();
                                    ordTab[1].toggle();
                                }
                            }
                            else {
                                toggleVisibility(false);
                                if (!ordTab[1].ison) {
                                    ordTab[1].toggle();
                                    ordTab[0].toggle();
                                }
                            }
                        }
                    }
                    else if (curSelectedGroup != 'Coupons') {
                        if (ro.app.Store && ro.app.Store.Menu && ro.app.Store.Menu.Groups) {
                            for (var i = 0; i < ro.app.Store.Menu.Groups.length; i++) {
                                if (ro.app.Store.Menu.Groups[i].Name == curSelectedGroup) {
                                    group = ro.app.Store.Menu.Groups[i];
                                    ro.app.group = ro.app.Store.Menu.Groups[i];
                                    break;
                                }
                            }
                            items = [];
                            for (i = 0; i < group.Items.length; i++) {
                                if (ro.cpnHelper.IsSizeValid(group.Name, group.Items[i])) {
                                    group.Items[i].idx = i;
                                    items.push(group.Items[i]);
                                }                                
                            }                           
                            //items = group.Items;
                            itmDisplayLen = items.length;

                            if (itmDisplayLen > itmDisplayableLen) {
                                itmDisplayLen = itmDisplayableLen;
                            }
                            lastDispRowId = itmDisplayLen - 1;
                            var path, hasSurcharge;
                            
                            for (var j = 0; j < itmDisplayLen; j++) {
                                path = null;
                                if (items[j].HasImage) {
                                    path = items[j].ImageSource;
                                }
                                hasSurcharge = false;
                                if (items[j].hasSurcharge) {
                                    hasSurcharge = true;
                                }
                                newAddItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, items[j].idx, menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx), null, hasSurcharge);
                            }
                        }
                    }
                    else {
                        try {
                            //Ti.API.debug('Coupons.length: ' + Coupons.length);
                            items = Coupons;
                            //Ti.API.debug('items.length: ' + items.length);
                            itmDisplayLen = Coupons.length;
                        }
                        catch(ex) {
                            Ti.API.debug('refreshNewItems-Coupon-Exception: ' + JSON.stringify(Coupons));
                            itmDisplayLen = 0;
                        }

                        if (itmDisplayLen > itmDisplayableLen) {
                            itmDisplayLen = itmDisplayableLen;
                        }
                        lastDispRowId = itmDisplayLen - 1;
                        var path = ro.ui.properties.defaultPath + 'myDeals.png';
                        for (var j = 0; j < itmDisplayLen; j++) {
                            try {
                                newAddItem(items[j].RcptName, formCpnDesc(items[j]), (items[j].UseImage) ? items[j].ImageName : path, true, j, null);
                            }
                            catch(ex) {
                                Ti.API.debug('addItem-Coupon-Exception: ' + JSON.stringify(items[j]));
                            }
                        }
                    }
                    if(curSelectedGroup != 'Orders'){
                        if (ro.isiOS) {
    
                            //tblItems.data = [];
                            tblItems.data = itemsData;
                        }
                        else {
                            //Ti.API.debug('NOT IOS');
                            tblItems.setData(itemsData);
                        }
                    }
                    
                    itemsView.add(tblItems);
                    if (curSelectedGroup != 'Coupons') {
                        setVisibility(showOrd, loyaltyBln);
                    }
                    tblItems.scrollToIndex(0);
                }
                catch(e) {
                    ro.ui.alert('Error: ', 'RefreshNewItems\n' + e);
                }
            };

            if (Ti.App.RepeatLastOrder) {
                refreshGrp = 'Orders';
            }
            else {
                refreshGrp = itemViewCpnBoole ? Ti.App.cpnGrpIndex : Ti.App.grpIndex;
            }

            if (refreshGrp === 'Orders') {
                itemsView.add(ordTabView);
                //itemsView.add(tblHead);

            }
            else if (refreshGrp === 'Coupons') {
                var cpnTabs = [];
                function tabCpn(e) {
                    if (e.source.id == 0) {
                        if (!cpnTabs[0].ison) {
                            cpnTabs[0].toggle();
                            cpnTabs[1].toggle();
                        }
                    }
                    else {
                        if (!cpnTabs[1].ison) {
                            cpnTabs[1].toggle();
                            cpnTabs[0].toggle();
                        }
                    }
                    cpnVisibility((e.source.id === 0));
                };

                cpnTabs.push(ro.tabBar.createTab('Coupons', function(e) {
                    tabCpn(e);
                }, true, 0));

                cpnTabs.push(ro.tabBar.createTab(cpnCodeLittleTxt, function(e) {
                    tabCpn(e);
                }, false, 1));

                var cpnTabView = ro.tabBar.getTabView(cpnTabs);
                //itemsView.add(cpnTabView);
                
                itemsView.add(promoCodeBox);
                
            }

            //itemsView.add(tblItems);

            if (!curSelectedGroup == 'My Rewards') {
                //itemsView.add(noItemsLbl);
            }

            ro.ui.refreshNewItems(refreshGrp);

            mainView.add(itemsView);
            //mainView.add(customAlertView);
            mainView.addEventListener('postlayout', function(e) {

                try {
                    tblItems.scrollToIndex(0);
                }
                catch(ex) {
                    Ti.API.debug('postlayout Exception: ' + ex);
                }

            });
            return mainView;
        };
    };
    return {
        newitemsview: newitemsview
    };
}();
module.exports = NEWITEMSVIEW; 