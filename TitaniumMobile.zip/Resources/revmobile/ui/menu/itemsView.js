//Ti.include('/logic/menuUtils.js');
//Ti.include('/logic/menuHelper.js');
//Ti.include('/logic/couponHelper.js');

var ITEMSVIEW = function(){
	var itemsview = function(ro){
		ro.ui.createItemsView = function(_args){
		   
		   //GUEST ORDERS
		   var isGuest = false;
		   if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	         isGuest = true;
	      }
	      //GUEST ORDERS
		   var menuUtils = require('logic/menuUtils');
	         var menuHelper = require('logic/menuHelper');
		   //Ti.include('/logic/prevOrders.js');
		   //Ti.include('/controls/tabCtrl.js');
	      var itemsData =[];
	      var items = null;
	      var group = null;
	      var Coupons = [];
	      var updating = false;
	      var itmDisplayLen;
	      var curSelectedGroup = null;
	      var rs = {};
	      var prevOrdObj;
	      var ordTab = [];
	      var timeAtStore = menuUtils.getStoreTime(ro.app.Store.TimeZone);
	
	      function tabClick(e){
	         if(e.source.id == 0){
	            if(!ordTab[0].ison){
	               ordTab[0].toggle();
	               ordTab[1].toggle();
	            }
	         }
	         else{
	            if(!ordTab[1].ison){
	               ordTab[1].toggle();
	               ordTab[0].toggle();
	            }
	         }
	         toggleVisibility((e.source.id === 0));
	      };
	
	      ordTab.push(ro.tabBar.createTab('Favorite Orders', function(e){ tabClick(e); }, true, 0));
	
	      ordTab.push(ro.tabBar.createTab('Previous Orders', function(e){ tabClick(e); }, false, 1));
	
	      var ordTabView = ro.tabBar.getTabView(ordTab);
	      var itemsView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
	         name:'items',
	         layout:'vertical',
	         left:0,
	         right:0,
	         bottom:ro.ui.relY(45),
	         top:ro.ui.relY(75) + ro.ui.properties.topAfterNavbar
	      }));
	      var tblItems = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
	         data:[],
	         //height:Ti.UI.SIZE,//FILL
	         backgroundColor:'transparent',
	         height:Ti.UI.FILL,
	         rowHeight:Ti.UI.SIZE,
	         separatorColor:'gray',
	         minRowHeight:ro.ui.properties.menuRowHeight,
	         top:0,
	         bottom:ro.ui.relX(50),//ro.ui.relY(30)
	         right:ro.ui.relX(0),
	         left:ro.ui.relX(0)//,
	         //backgroundColor:'yellow'
	      }));
	      if(!ro.isiOS){
	      	delete tblItems.top;
	      delete tblItems.bottom;
	      }
	      
	
	
	      var noItemsLbl = Ti.UI.createLabel({
	      	font:{
	      	   fontSize:ro.ui.scaleFontY(11, 13),
	      	   fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	      	},
	      	textAlign:'center',
	      	width:ro.ui.relX(200),
	      	height:ro.ui.relY(50)
	      });
	
	      var lastDispRowId;
	      var interval;
	      
			if (!ro.isiOS) {
				tblItems.addEventListener('scroll', function(e) {
					if (interval > 0 || (items.length - e.totalItemCount === 0)) {
						return;
					}
					var endRow = e.firstVisibleItem + e.visibleItemCount;
					if (endRow <= lastDispRowId) {
						return;
					}
					endRow += itmDisplayableLen;
					if (endRow > items.length) {
						endRow = items.length;
					}
					interval = setTimeout(function() {
						try {
							if (lastDispRowId + 1 != items.length) {
								var path;
								for (var j = lastDispRowId + 1; j < endRow; j++) {
									if (curSelectedGroup == 'Orders') {
										addToPrev(j);
									} else if (curSelectedGroup != 'Coupons') {
										addItem(items[j].ReceiptName, formItmDesc(items[j]), items[j].HasImage ? items[j].ImageSource : path, false, j, menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx));
									} else {
										var x = j;
										addItem(items[j].RcptName, formCpnDesc(items[j]), (items[j].HasImage) ? items[j].ImageSource : ro.ui.properties.defaultPath + 'coupon.png', true, x, null);
									}
								}
								if (ro.isiOS) {
									tblItems.setData(itemsData);
								} else {
									tblItems.data = itemsData;
								}

								lastDispRowId = endRow - 1;
							}
							interval = 0;
						} catch(ex) {
							if (Ti.App.DEBUGBOOL) {
								Ti.API.debug('scroll exception caught: ' + ex);
							}
						}
					}, 20);
				});
			}

			else {
				//var lastDispRowId;
				//var interval;
				///var updating = false,
				var
				reachedEnd = false,
				    lastDistance = 0,
				    lastRow = 0;
				tblItems.style = Ti.UI.iOS.TableViewStyle.PLAIN;
				tblItems.addEventListener('scroll', function(e) {
					//Ti.API.info('reachedEnd: ' + reachedEnd);
					if (!reachedEnd) {
						var offset = e.contentOffset.y;
						var height = e.size.height;
						var total = offset + height;
						var theEnd = e.contentSize.height;
						var distance = theEnd - total;

						if (distance < lastDistance) {
							var nearEnd = theEnd * .75;
							if (!updating && (total >= nearEnd)) {
								beginUpdate();
							}
						}
						lastDistance = distance;
					}
				});

				function addRows(start, end) {

					if (curSelectedGroup.toLowerCase() == 'pick any' || curSelectedGroup.toLowerCase() == 'required item') {
						//var items = (curSelectedGroup.toLowerCase() == 'pick any') ? cpnHelper.getPickAnyItems() : cpnHelper.getRequireAnyItems();//group.Items;
						////Ti.API.debug('items: ' + JSON.stringify(items));
						for (var j = start; j < end; j++) {
							//var _gIdx = getMatchingIdx(items[j].ReportGrp, storeObj.Menu.Groups, 'ReportGrp');
							var _gIdx = items[j].PickAnyGrpIdx;
							var path;
							group = ro.app.Store.Menu.Groups[_gIdx];
							if (items[j].HasImage) {
								path = items[j].ImageSource;
							} else if (group.HasImage) {
								path = group.ImageSource;
							}
							//price = arrayToPrice(menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
							price = menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx);
							addItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, null, _gIdx);
						}
						tblItems.data = itemsData;
					} else if (curSelectedGroup == 'Orders') {
						//Check if there are any fav orders, if not highlight prev orders
						//toggleVisibility(true);
					} else if (curSelectedGroup != 'Coupons') {
						for (var j = start; j < end; j++) {
							var path;
							if (items[j].HasImage) {
								path = items[j].ImageSource;
							} else if (group.HasImage) {
								path = group.ImageSource;
							}
							price = menuHelper.getItemPrice(items[j], group, Ti.App.OrderObj.OrdTypePriceIdx);
							addItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), path, false, j, price);
							//addItem(items[j].DisplayName || items[j].ReceiptName || items[j].Name, formItmDesc(items[j]), items[j].HasImage?items[j].ImageSource:path, false, j, menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
						}
						tblItems.data = itemsData;
					}
					else {
						for (var j = start; j < end; j++) {
							var path;
							path = (Coupons[j].HasImage) ? Coupons[j].ImageSource : ro.ui.properties.defaultPath + 'coupon.png';
							price = null;
							addItem(Coupons[j].RcptName, formCpnDesc(Coupons[j]), path, true, j, price);
						}
						tblItems.data = itemsData;
					}
				}

				function beginUpdate() {
					updating = true;
					//Ti.API.info('lastRow: ' + lastRow);
					//Ti.API.info('visibleRowCount: ' + visibleRowCount);
					//Ti.API.info('items.length: ' + items.length);
					if ((lastRow + visibleRowCount) > items.length) {
						/*if(curSelectedGroup == 'Orders'){
						 for(var i= lastRow;i<items.length;i++){
						 addToPrev(i);
						 }
						 tblItems.data = itemsData;
						 }
						 else{*/
						addRows(lastRow, items.length);
						//}
						reachedEnd = true;
						lastRow = items.length;
					}
					else {
						/*if(curSelectedGroup == 'Orders'){
						 for(var i= lastRow;i<items.length;i++){
						 addToPrev(i);
						 }
						 tblItems.data = itemsData;
						 }
						 else{*/
						addRows(lastRow, (lastRow + visibleRowCount));
						//}
						lastRow += visibleRowCount;

					}
					setTimeout(endUpdate, 150);
				}

				function endUpdate() {
					updating = false;
				}

			}

	      tblItems.addEventListener('click', function(e){
	         var index;
	         /*for(var props in e){
	         	Ti.API.debug('e['+props+']: ' + JSON.stringify(e[props]));
	         }*/
	         //Ti.API.debug('e.row: ' + JSON.stringify(e.row));
	         ro.cpnHelper.setCpnBool((e.row.itmType == 'coupon')?true:false);
	         if(e.row.itmType == 'prev'){
	            if(!(ro.prevOrders.addToCart(prevOrdObj[e.row.index], ro.app.Store.Menu, Ti.App.OrderObj))){
	               ro.ui.alert('Error: ', 'This previous order is no longer available. Sorry for the inconvenience.');
	            }
	            else{
	              ro.ui.showCart();
	            }
	            return;
	         }
	      	else if(e.row.itmType == 'coupon'){
	      		try{
	      		   //Ti.API.debug('e.row.cpnKey: ' + e.row.cpnKey);
	      		   ////deb.ug(e, 'e');
	      		   ////deb.ug(e.row, 'e.row');
	      			//ca.showData(e.row.txtObj);
	      			for(var i=0, iMax=ro.app.Store.Menu.Cpns.length; i<iMax; i++){
	      			   if(ro.app.Store.Menu.Cpns[i].Key == e.row.cpnKey){
	      			      
	      			      //Ti.API.debug('ro.app.Store.Menu.Cpns['+i+']: ' + JSON.stringify(ro.app.Store.Menu.Cpns[i]));
	      			      if(ro.app.Store.Menu.Cpns[i].CpnScope === 1){
	      			         if(ro.cpnHelper.validatePctCpn(i)){
	      			            ro.cpnHelper.addPctCpn(ro.app.Store.Menu.Cpns[i]);
	      			         }
	      			         return;
	      			      }
	      			   }
	      			}
	      			
	      			ro.cpnHelper.setCpnBool(true);
	      			ro.utils.removeProp('SelectedCoupon');
	      			ro.ui.ordShowNext({ addView:true, showing:'cpnSelView', cpnKey:e.row.cpnKey});
	      		}
	      		catch(ex){
	      			Ti.API.debug('tblItems.click-Coupon-Exception: ' + ex);
	      			//ca.showData(e.row.txtObj);
	      		}
	      		return;
	      	}
	      	else{
	      		//Ti.API.debug('e.index: ' + e.index);
	      		//Ti.API.debug('group: ' + JSON.stringify(group));
	      		ro.app.itemSelected = group.Items[e.source.index];
	      		//ro.app.itemSelected = group.Items[e.index];
	      		itemIndex = e.source.index;
	      		//Ti.API.debug('ro.app.itemSelected: ' + JSON.stringify(ro.app.itemSelected));
	      		if(menuUtils.straightToCart()){
						//InitializeItemObj();
						var ITEMOBJ = require('logic/itemObj');
                        ITEMOBJ.itemobj(ro);
						ro.itemObj.InitializeItemObj();
						ro.itemObj.setNoSizes();
						menuUtils.addToCart(ro.app.Store, ro.itemObj.getItemObj(), true);
					}
					else{
		      		ro.ui.ordShowNext({ addView:true, showing:'itemDetails' });
		      	}
	      		/*ro.app.itemSelected = group.Items[e.index];
	      		itemIndex = e.index;
	      		ro.ui.ordShowNext({ addView:true, showing:'itemDetails' });*/
	      	}
	      });
	
	      function formItmDesc(Itm){
	      	var rtnDesc = "";
	      	if(Itm.ItemDesc){
	      	   rtnDesc = Itm.ItemDesc;
	      	}
	      	else{
	      		var preModsFound = false;
	      		if(Itm.PreMods){
	      			if(Itm.PreMods.length > 0){
	      				if(curSelectedGroup == "Pizza"){
	      			 		rtnDesc += "Our " + Itm.ReceiptName + " is topped with ";
	      				}
	      				else{
	      					rtnDesc += Itm.ReceiptName + " is served with ";
	      				}
	
	      				for(var i=0; i<Itm.PreMods.length; i++){
	      					if(group.Mods){
	      						for(var j=0; j<group.Mods.length; j++){
	      							if(Itm.PreMods[i].Name == group.Mods[j].Name){
	      								preModsFound = true;
	      								rtnDesc += group.Mods[j].ReceiptName;
	      								if(i != Itm.PreMods.length-1){
	      									rtnDesc += ", ";
	      								}
	      							}
	      						}
	      					}
	      				}
	
	      				if(preModsFound){
	      					rtnDesc += ".";
	      				}
	      				else{
	      					rtnDesc = "";
	      				}
	      			}
	      		}
	      	}
	      	var rtnObj = {};
	      	rtnObj.description = rtnDesc;
	      	rtnObj.txtObj = null;
	      	return rtnObj;
	      }
	
	      function formCpnDesc(coupon){
	      	var cpnObj = {};
	      	cpnObj.cpnKey = coupon.Key;
	      	var cpnDescription = "";
	      	var cpnInstructions = "";
	      	if(coupon.CpnScope == 3){
	      		var itms = [];
	      		var itmLngth = itms.length;
	      		var itmFound;
	      		var curItm;
	      		for(j=0; j<coupon.Items.length; j++){
	      			itmFound = false;
	      			curItm = {};
	      			curItm.MenuItem = coupon.Items[j].MenuItem;
	      			curItm.MenuSize = coupon.Items[j].MenuSize;
	      			curItm.MenuStyle = coupon.Items[j].MenuStyle;
	      			curItm.MenuGroup = coupon.Items[j].MenuGroup;
	      			curItm.Qty = 1;
	      			for(var k=0; k<itmLngth; k++){
	      				if(itms[k].MenuItem == curItm.MenuItem && itms[k].MenuSize == curItm.MenuSize && itms[k].MenuStyle == curItm.MenuStyle){
	      					itms[k].Qty += 1;
	      					itmFound = true;
	      					break;
	      				}
	      			}
	      			if(!itmFound){
	      				itms.push(curItm);
	      			}
	
	      		}
	      		var tempTxt;
	      		for(var j=0; j<itmLngth; j++){
	      			cpnDescription += itms[j].MenuGroup + ': ';
	      			cpnInstructions += (j+1) + '. ';
	      			if(itms[j].MenuSize == "All" && itms[j].MenuStyle == "All" && itms[j].MenuItem == "All"){
	   					cpnDescription += 'Any ' + itms[j].Qty + ' of your choice.';
	   					cpnInstructions += 'Add any '+ itms[j].Qty + ' ' + itms[j].MenuGroup + ' of your choice.';
	      			}
	      			else{
	      				tempTxt = 'Add '+ itms[j].Qty + ' ';
	      				cpnDescription += itms[j].Qty + ' ';
	
	      				if(itms[j].MenuSize != "All"){
	      					cpnDescription += itms[j].MenuSize + ' ';
	      					tempTxt += itms[j].MenuSize + ' ';
	      				}
	
	      				if(itms[j].MenuStyle != "All"){
	      					cpnDescription += itms[j].MenuStyle + ' ';
	      					tempTxt += itms[j].MenuStyle + ' ';
	      				}
	
	      				if(itms[j].MenuItem != "All"){
	      					cpnDescription += itms[j].MenuItem + '.';
	      					tempTxt += itms[j].MenuItem + '.';
	      				}
	      				else{
	      					cpnDescription = 'Any ' + cpnDescription + 'of your choice.';
	      					tempTxt += itms[j].MenuGroup + ' of your choice.';
	      				}
	      				cpnInstructions += tempTxt;
	      			}
	
	      			if(j != itmLngth-1){
	      				cpnDescription += '\n';
	      			}
	      			cpnInstructions += '\n';
	      		}
	      		cpnInstructions += (itmLngth+1) + '. ' + 'Proceed to Cart.' + '\n';
	      		cpnInstructions += (itmLngth+2) + '. ' + 'Click on Coupons.' + '\n';
	      		cpnInstructions += (itmLngth+3) + '. ' + 'Tap on ' + '"' + coupon.RcptName + '"' + ' to apply.';
	      	}
	      	else{
	      		cpnDescription = coupon.CpnDesc;
	      		cpnInstructions = "";
	      	}
	      	cpnTxt = {};
	      	cpnTxt.RcptName = coupon.RcptName;
	      	cpnTxt.cpnInstructions = cpnInstructions;
	
	      	cpnObj.description = coupon.CpnDesc;
	      	cpnObj.txtObj = cpnTxt;
	      	return cpnObj;
	      }
	
	      function addItem(receiptName, obj, imgPath, isCoupon, idx, itemPrice){
	         var hasImg = (imgPath && imgPath.length > 0);
	         var left = ro.ui.relX(7);
	         var cls = (hasImg?'item':'noitem');
	
				//Ti.API.debug('idx: ' + idx);
	
	         itemsData[idx] = Ti.UI.createTableViewRow({
	         	hasChild:false,
					className:cls,
					itmType:(isCoupon?'coupon':'item'),
					txtObj:obj.txtObj,
					index:idx,
					backgroundColor:'white',
					selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
				});
				if(ro.isiOS){
					itemsData[idx].height = ro.ui.relY(85);
					itemsData[idx].width = Ti.UI.FILL;
				}
				if(isCoupon){
					itemsData[idx].cpnKey = obj.cpnKey;
				}
	
				if(hasImg){//} || (group.ImageSource && group.ImageSource.length > 0)){
					left = ro.ui.relX(80);
				   itemsData[idx].add(Ti.UI.createImageView({
				      image:hasImg?imgPath:group.ImageSource,
				      defaultImage:ro.ui.properties.defaultImgPath,
				      width:ro.isiOS ? ro.ui.relX(70) : ro.ui.relX(70),
				      height:ro.isiOS ? ro.ui.relX(70) : ro.ui.relY(70),
				      left:5,
				      top:ro.isiOS ? null : ro.ui.relY(5),
						index:idx
				   }));
				}
	
				itemsData[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
	 				color:ro.ui.theme.contentsSmallTxtHead,
					text:(itemPrice != null)?receiptName+'\n'+itemPrice:receiptName,
					left:left,
					top:ro.ui.relY(2),
					font:{
	               fontSize:ro.ui.scaleFont(11),
	               fontWeight:'bold',
		            fontFamily:ro.ui.fontFamily
	   	      },
					index:idx
				})));
	
	
				itemsData[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
					color:ro.ui.theme.contentsSmallTxt,
					text:obj.description,
					height:Ti.UI.SIZE,
					width:Ti.UI.FILL,
					top:ro.ui.relY(28),
					bottom:ro.ui.relY(3),
					left:left,
	            ellipsize:true,
	            font:{
	               fontSize:ro.ui.scaleFont(10),
	            	fontFamily:ro.ui.fontFamily
	            },
					index:idx
				})));
	      }
	
	function addCoupons(){
		var j, k, CpnIdx, blnVis, deliveryType, curDate, UTCTime, startDt, ExpirDt;
	   var BtnIdx = 0;
	   var curOrdType = Ti.App.OrderObj.OrdType;
	   var cpnLngth = ro.app.Store.Menu.Cpns.length;
	
		for(CpnIdx = 0; CpnIdx < cpnLngth; CpnIdx++){
			if(!ro.app.Store.Menu.Cpns[CpnIdx].ReqValCode || ro.app.Store.Menu.Cpns[CpnIdx].VCSupress){//&& parseInt(ro.app.Store.Menu.Cpns[CpnIdx].CpnScope, 10) != 1){
				blnVis = false;
				curDate = new Date();
	         UTCTime = curDate.getTime() + (curDate.getTimezoneOffset() * 60000);
	
				if(ro.app.Store.Menu.Name == ro.app.Store.Menu.Cpns[CpnIdx].Menu || ro.app.Store.Menu.Cpns[CpnIdx].Menu == 'All'){
					blnVis = true;
					if(ro.app.Store.Menu.Cpns[CpnIdx].Name.toUpperCase() == 'FIRST ONLINE ORDER'){
						blnVis = false;
						continue;
					}
					/*if(ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true && isGuest){
						blnVis = false;
						continue;
					}*/
					
					if(ro.app.Store.Menu.Cpns[CpnIdx].SingleUse == true){// && isGuest){
	               ////deb.ug(ro.app.Store.Menu.Cpns[CpnIdx], 'ro.app.Store.Menu.Cpns[CpnIdx]');
	               	if(isGuest){
	                	blnVis = false;
	                	continue;
	                }
	               	else{
	                  var rs = ro.db.getCustObj(Ti.App.Username);
	                  if(!rs){
	                     rs = {};
	                  }
	                  if(!rs.CpnUsage){
	                     rs.CpnUsage = [];
	                  }
	                  else{
	                     rs.CpnUsage = rs.CpnUsage.split("-");
	                  }
	                  
	                  var shouldContinue = false;
	                  for(var cpnUsageIdx = 0, cpnUsageMax=rs.CpnUsage.length; cpnUsageIdx < cpnUsageMax; cpnUsageIdx++){
	                     //Ti.API.debug('rs.CpnUsage['+cpnUsageIdx+']: ' + rs.CpnUsage[cpnUsageIdx]);
	                     if(ro.app.Store.Menu.Cpns[CpnIdx].Key == rs.CpnUsage[cpnUsageIdx]){
	                        blnVis = false;
	                        shouldContinue = true;
	                        break;                  
	                     }
	                  }
	                  
	                  for(var currCpnIdx=0, currCpnMax=Ti.App.OrderObj&&Ti.App.OrderObj.Cpns&&Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0; currCpnIdx<currCpnMax; currCpnIdx++){
	                     if(Ti.App.OrderObj.Cpns[currCpnIdx].SingleUseKey == ro.app.Store.Menu.Cpns[CpnIdx].Key){
	                        blnVis = false;
	                        shouldContinue = true;
	                        break;
	                     }
	                  }
	                  
	                  if(shouldContinue){
	                     Ti.API.debug('continuing due to already having used this single use cpn...IT SHOULD NOT SHOW UP IN CPN LIST');
	                     continue;
	                  }
	               	}
	            }
					
				if (ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes && ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length && Ti.App.OrderObj && Ti.App.OrderObj.OrdType){
					for(var exclOrdIdx = 0; exclOrdIdx < ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length; i++){
						if(Ti.App.OrderObj.OrdType == ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[exclOrdIdx].ExcldOrdType){
							blnVis = false;
							continue;
						}
					}
				}

					if(ro.app.Store.Menu.Cpns[CpnIdx].HasStartDt){
						startDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].StartDtStr);
						if (startDt.getTime() > timeAtStore.getTime()) {
							blnVis = false;
							continue;
						}
					}
					if(ro.app.Store.Menu.Cpns[CpnIdx].HasExpirDt){
						ExpirDt = new Date(ro.app.Store.Menu.Cpns[CpnIdx].ExpirDtStr);
						var StoreDate = new Date(timeAtStore);
						ExpirDt.setHours(0, 0, 0, 0);
						StoreDate.setHours(0, 0, 0, 0);
						if (ExpirDt.getTime() < StoreDate.getTime()) {
							blnVis = false;
							continue;
						}
					}
					if(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays > 0){
						if(blnVis==true){
						   if(!menuUtils.WeekdayValid(ro.app.Store.Menu.Cpns[CpnIdx].Weekdays, timeAtStore)){
								blnVis=false;
								continue;
							}
						}
					}
					if(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx > 0){
						if(blnVis==true){
							//if(!menuUtils.IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTime, ro.app.Store.Menu.Cpns[CpnIdx].EndTime, timeAtStore)){
							   if(!menuUtils.IsTimeValid(ro.app.Store.Menu.Cpns[CpnIdx].TimeIdx, ro.app.Store.Menu.Cpns[CpnIdx].StartTimeStr, ro.app.Store.Menu.Cpns[CpnIdx].EndTimeStr, timeAtStore)){
								  blnVis=false;
								  continue;
							   }
							//}
						}
					}
					if(ro.app.Store.Menu.Cpns[CpnIdx].HasExcldOrdType){
						if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes){
							for(j=0;j<ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes.length;j++){
								if(ro.app.Store.Menu.Cpns[CpnIdx].ExcldOrdTypes[j] == curOrdType){
									blnVis=false;
									continue;
								}
							}
						}
					}
					if(blnVis){
						Coupons.push(ro.app.Store.Menu.Cpns[CpnIdx]);
					}
				}
			}
		}
	}
	function addToPrev(i){
	   var _idx = itemsData.length;
	   itemsData[_idx] = Ti.UI.createTableViewRow({
	      hasChild:false,
	      className:'ordItem',
	      itmType:'prev',
	      index:i,
	      //backgroundSelectedColor:ro.ui.theme.tblRowSelected,
	      layout:'vertical'
	   });
	   itemsData[_idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
	      text:prevOrdObj[i].Name?prevOrdObj[i].Name:'Order #'+(i+1),
	      left:ro.ui.relY(15),
	      top:ro.ui.relY(5),
	      height:Ti.UI.SIZE,
	      color:ro.ui.theme.contentsSmallTxtHead,
	      font:{
	         fontSize:ro.ui.scaleFont(11),
	         fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	      }
	   })));
	   itemsData[_idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
	      text:prevOrdObj[i].TimeString,
	      left:ro.ui.relX(15),
	      height:Ti.UI.SIZE,
	      color:ro.ui.theme.contentsSmallTxt,
	      font:{
	         fontSize:ro.ui.scaleFont(10),
	            fontFamily:ro.ui.fontFamily
	      }
	   })));
	   itemsData[_idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
	      text:formDescription(i),
	      left:ro.ui.relX(15),
	      top:ro.ui.relY(15),
	      height:Ti.UI.SIZE,
	      textAlign:'left',
	      color:ro.ui.theme.contentsSmallTxt,
	      font:{
	         fontSize:ro.ui.scaleFont(10),
	            fontFamily:ro.ui.fontFamily
	      }
	   })));
	}
	
	function formDescription(index){
	   var str = '';
	
	   for(var i=0; i<prevOrdObj[index].LastOrdItemCol.length; i++){
	      str = str +''+ prevOrdObj[index].LastOrdItemCol[i].Qty +' '+ prevOrdObj[index].LastOrdItemCol[i].RcptName;
	      if(i === prevOrdObj[index].LastOrdItemCol.length-1){
	
	      }
	      else{
	         str = str + ', ';
	      }
	   }
	   return str;
	}
	addCoupons();
	
	var th = ro.ui.properties.plHeight - ro.ui.relY(199);
	var tr = ro.ui.relY(20)+(60)*(ro.ui.properties.devDpi/160);
	var div = Math.ceil(th/tr);
	var itmDisplayableLen = ro.isiOS ? ((th%tr)==0? div +2:div+1) : ((th%tr)==0? div +1:div);
	if(ro.isiOS){
		itmDisplayableLen += 1;
	}
	var showFav = false;
	var visibleRowCount = itmDisplayableLen;
	
	
	function toggleVisibility(favVisibility){
	   try{
	      itemsData = [];
	      items = prevOrdObj;
	      showFav = false;
	      itmDisplayLen = items.length;
	      if(itmDisplayLen > itmDisplayableLen){
	         itmDisplayLen = itmDisplayableLen;
	      }
	      lastDispRowId = itmDisplayLen-1;
	
	      if(!favVisibility && prevOrdObj){
	         for(var i=0; i<itmDisplayLen; i++){
	            addToPrev(i);
	         }
	      }
	      else{
	         if(prevOrdObj){
	            for(var i=0;i<itmDisplayLen;i++){
	               if(!favVisibility || (favVisibility && prevOrdObj[i].Name)){
	                  addToPrev(i);
	               }
	            }
	         }
	      }
	
	      if(prevOrdObj){
	      	if(ro.isiOS){
	      		tblItems.setData(itemsData);
	      	}
	      	else{
	      		tblItems.data = itemsData;
	      	}
	         
	      }
	
	      setVisibility(true);
	   }
	   catch(e){
	
	   }
	}
	
	var previouslyWasLoyalty = false;
	var menuLoyaltyView;
	function setVisibility(showOrd, ltyBln){
	   if(!ltyBln && previouslyWasLoyalty){
	      previouslyWasLoyalty = false;
	      itemsView.remove(menuLoyaltyView);
	      menuLoyaltyView = null;
	   }
	   if(ltyBln){
	      previouslyWasLoyalty = true;
	      showOrd = false;
	      noItemsLbl.top = 0;
	      noItemsLbl.height = 0;
	      noItemsLbl.visible = false;
	   }
	   
	   if(showOrd){
	      ordTabView.show();
	      ordTabView.height = ro.ui.relY(50);
	   }
	   else{
	      ordTabView.hide();
	      ordTabView.height = 0;
	   }
	
	   if(itemsData.length>0){
	      //itemsView.add(tblItems);
	      tblItems.visible = true;
	      noItemsLbl.top = 0;
	      noItemsLbl.height = 0;
	      noItemsLbl.visible = false;
	      if(ro.isiOS){
	      	  tblItems.setData(itemsData);
	      }
	      else{
	      	 tblItems.data = itemsData;
	      }
	      
	      tblItems.scrollToIndex(0);
	   }
	   else{
	   	//Ti.API.info('REMOVING TBLITEMS')
	      //itemsView.remove(tblItems);
	      if(!ltyBln){
	         noItemsLbl.text=(curSelectedGroup=='Coupons'?'No coupons available.':'No items available under '+ curSelectedGroup +'.');
	         noItemsLbl.top = ro.ui.relY(90);
	         noItemsLbl.height = ro.ui.relY(50);
	         noItemsLbl.visible = true;
	         noItemsLbl.color = ro.ui.theme.textColor;
	      }
	      else{
	         
	      }
	   }
	}
	 //var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
	 ro.ui.refreshItems = function(curSelGroup){
	    try{
	    //	Ti.API.info('curSelGroup: ' + curSelGroup);
	    		reachedEnd = false;
	    		lastRow = 0;
	       itemsData = [];
	       curSelectedGroup = curSelGroup;
	
	       var showOrd = false;
	       var ordTabBool = false;
	       var loyaltyBln = false;
	       if(curSelectedGroup == 'My Rewards'){
	          var currentLoyalty = ro.REV_LOYALTY.getCurrentLoyalty();
	         menuLoyaltyView = currentLoyalty.getTabLoyaltyMenuView(ro.app.Store.ID, false, true);
	         itemsView.add(menuLoyaltyView);
	         loyaltyBln = true;
	       }
	       else if(curSelectedGroup == 'Orders'){
	          rs = ro.db.getCustObj(Ti.App.Username);
	          prevOrdObj = rs.PrevOrders;
	          showOrd = true;
	          if(prevOrdObj && prevOrdObj.length>0){
	             for(var i=0; i<prevOrdObj.length; i++){
	                if(prevOrdObj[i].Name){
	                   ordTabBool = true;
	                }
	             }
	
	             ro.prevOrders.fillItmRcptNames(prevOrdObj, ro.app.Store.Menu);
	             if(ordTabBool){
	               toggleVisibility(true);
	               //Added for trial
	               if(!ordTab[0].ison){
	                  ordTab[0].toggle();
	                  ordTab[1].toggle();
	               }
	               //Added for trial
	             }
	             else{
	                toggleVisibility(false);
	                if(!ordTab[1].ison){
	                   ordTab[1].toggle();
	                   ordTab[0].toggle();
	                }
	             }
	          }
	       }
	       else if(curSelectedGroup != 'Coupons'){
	          for(var i=0; i<ro.app.Store.Menu.Groups.length; i++){
	             if(ro.app.Store.Menu.Groups[i].Name == curSelectedGroup){
	                group = ro.app.Store.Menu.Groups[i];
	                ro.app.group = ro.app.Store.Menu.Groups[i];
	                break;
	             }
	          }
	          items = group.Items;
	          itmDisplayLen = items.length;
	
	          if(itmDisplayLen > itmDisplayableLen){
	             itmDisplayLen = itmDisplayableLen;
	          }
	          lastDispRowId = itmDisplayLen-1;
	          var path;
	          for(var j=0;j<itmDisplayLen;j++){
	          	 path = null;
	             if(items[j].HasImage){
	                path = items[j].ImageSource;
	             }
	             addItem(items[j].ReceiptName, formItmDesc(items[j]), path, false, j, menuHelper.getItemPrice(items[j],group,Ti.App.OrderObj.OrdTypePriceIdx));
	          }
	       }
	       else{
	          items = Coupons;
	          itmDisplayLen = Coupons?Coupons.length:0;
	
	          if(itmDisplayLen > itmDisplayableLen){
	             itmDisplayLen = itmDisplayableLen;
	          }
	          lastDispRowId = itmDisplayLen-1;
	          var path = ro.ui.properties.defaultPath + 'coupon.png';
	          for(var j=0; j<itmDisplayLen; j++){
	             var x = j;
	             addItem(items[j].RcptName,formCpnDesc(items[j]),(items[j].HasImage)?items[j].ImageSource:path,true,x, null);
	          }
	       }
	       //tblItems.data = itemsData;
	       if(ro.isiOS){
	       	//Ti.API.info('tblItems: ' + JSON.stringify(tblItems));
	      	  tblItems.setData(itemsData);
	      }
	      else{
	      	 tblItems.data = itemsData;
	      }
	       setVisibility(showOrd, loyaltyBln);
	    }
	    catch(e){
	       ro.ui.alert('Error: ', 'RefreshItems\n' + e);
	    }
	 };
	 
	   //var currentLoyalty = 
	   if(ro.REV_LOYALTY.getCurrentLoyalty().isHC){
	      //Ti.API.debug('ordTabView should be hiding if this prints....');
	      ordTabView.visible = false;
	      ordTabView.hide();
	      ordTabView.height = 0;
	   }
	
	   itemsView.add(ordTabView);
	   itemsView.add(tblItems);
	   itemsView.add(noItemsLbl);
	   return itemsView;
	   };
	};
	return {
		itemsview:itemsview
	};
}();
module.exports = ITEMSVIEW;