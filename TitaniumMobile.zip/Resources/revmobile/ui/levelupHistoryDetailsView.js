(function(){
   ro.ui.getLoyaltiesHistoryDetailsView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesHistoryDetails', 'LEVELUP', layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var loyaltiesHistoryDetailsView = Ti.UI.createScrollView({
         layout:'vertical',
         top:0,
         bottom:ro.ui.relY(110),
         backgroundColor:ro.ui.theme.lvlupHistoryDetailsBg
      });
      var order = _args.order;
      Ti.API.debug('order: ' + JSON.stringify(order));
      var isRefund = order.refunded_at ? true : false;

      var merchName = order.merchant_name;
      var chargedAmt = '$' + parseFloat(order.balance_amount/100, 10).toFixed(2).toString();

      //var ordTotal = '$' + parseFloat(order.total_amount/100, 10).toFixed(2).toString();
      var ordTotal = '$' + parseFloat((order.total_amount - order.credit_applied_amount)/100, 10).toFixed(2).toString();

      var tipAmt = '$' + parseFloat(order.tip_amount/100, 10).toFixed(2).toString();
      var transAmt = '$' + parseFloat((order.total_amount - order.tip_amount)/100, 10).toFixed(2).toString();

      //var spendAmt = '$' + parseFloat(order.spend_amount/100, 10).toFixed(2).toString();

      var credEarnedAmt = '$' + parseFloat(order.credit_earned_amount/100, 10).toFixed(2).toString();
      var credAppliedAmt = '$' + parseFloat(order.credit_applied_amount/100, 10).toFixed(2).toString();

      var uuid = order.uuid;

      /*var topImageBanner = Ti.UI.createView({//imageView once i have an image
         height:ro.ui.relY(175),
         top:0,
         backgroundColor:'yellow'
      });
      loyaltiesHistoryDetailsView.add(topImageBanner);*/

      var histDetailsTbl = Ti.UI.createTableView({
         top:0,
         left:ro.ui.relX(15),
         separatorColor:'gray',
         height:Ti.UI.SIZE
      });
      loyaltiesHistoryDetailsView.add(histDetailsTbl);


      var tblRows = [];
      var transactionRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL
      });
      var transLeftLbl = Ti.UI.createLabel({
         text:'Transaction Amount',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'black',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      var transRightLbl = Ti.UI.createLabel({
         text:transAmt,
         textAlign:'left',
         width:Ti.UI.SIZE,
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5),
         color:'black'
      });
      transactionRow.add(transLeftLbl);
      transactionRow.add(transRightLbl);

      tblRows.push(transactionRow);

      var tipRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL
      });
      var tipLeftLbl = Ti.UI.createLabel({
         text:'Tip',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'black',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      var tipRightLbl = Ti.UI.createLabel({
         text:tipAmt,
         textAlign:'left',
         width:Ti.UI.SIZE,
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5),
         color:'black'
      });
      tipRow.add(tipLeftLbl);
      tipRow.add(tipRightLbl);
      tblRows.push(tipRow);


      var credAppliedRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL
      });
      var credAppliedLeftLbl = Ti.UI.createLabel({
         text:'Credit Applied',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'black',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      var credAppliedRightLbl = Ti.UI.createLabel({
         text:credAppliedAmt,
         textAlign:'left',
         width:Ti.UI.SIZE,
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5),
         color:'black'
      });
      credAppliedRow.add(credAppliedLeftLbl);
      credAppliedRow.add(credAppliedRightLbl);
      tblRows.push(credAppliedRow);

      var totalRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL
      });

      var textColr = '#16e316', totalPrependStr = '', ordTotalString = 'Total Spent';
      if(isRefund){
         textColr = '#eb0029';
         //totalPrependStr = '-';
         ordTotalString = 'Total Refunded';
         ordTotal = transAmt;
         credEarnedAmt = '$0.00';
      }

      var totalLeftLbl = Ti.UI.createLabel({
         text:ordTotalString,
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:textColr,
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      var totalRightLbl = Ti.UI.createLabel({
         text:totalPrependStr + '' + ordTotal,
         textAlign:'left',
         width:Ti.UI.SIZE,
         right:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5),
         color:textColr
      });
      totalRow.add(totalLeftLbl);
      totalRow.add(totalRightLbl);
      tblRows.push(totalRow);

      var chargedRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL,
         leftImage:'/images/credit_card.png'
      });
      var chargedLeftLbl = Ti.UI.createLabel({
         text:chargedAmt + ' was charged to your card',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'gray',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      chargedRow.add(chargedLeftLbl);
      tblRows.push(chargedRow);

      var loyaltiesChargedRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL,
         leftImage:'/images/rewards.png'
      });
      var loyaltiesChargedLeftLbl = Ti.UI.createLabel({
         text:'Used ' + credAppliedAmt + ' in credit from your account',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'gray',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      loyaltiesChargedRow.add(loyaltiesChargedLeftLbl);
      tblRows.push(loyaltiesChargedRow);

      var loyaltiesEarnedRow = Ti.UI.createTableViewRow({
         height:ro.ui.relY(50),
         width:Ti.UI.FILL,
         leftImage:'/images/earned.png'
      });
      var loyaltiesEarnedLeftLbl = Ti.UI.createLabel({
         text:'You earned ' + credEarnedAmt + ' in credit at ' + merchName + ' with this purchase',
         textAlign:'left',
         width:Ti.UI.SIZE,
         left:ro.ui.relX(5),
         font:{
            fontSize:ro.ui.scaleFont(14),
            fontFamily:ro.ui.fontFamily
         },
         color:'gray',
         top:ro.ui.relY(5),
         bottom:ro.ui.relY(5)
      });
      loyaltiesEarnedRow.add(loyaltiesEarnedLeftLbl);
      tblRows.push(loyaltiesEarnedRow);

      histDetailsTbl.setData(tblRows);
      var feedbackBtn = layoutHelper.getBigButton('Feedback');
      feedbackBtn.top = ro.ui.relY(25);

      feedbackBtn.addEventListener('click', function(e){
         ro.ui.showLoader();
         ro.ui.settingsShowNext({addView:true, showing:'loyaltiesFeedback', uuid:uuid});
         ro.ui.hideLoader();
      });
      
      /*var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      levelUp.getOrderBreakdown(function(breakdown){
         //Ti.API.debug('breakdown: ' + JSON.stringify(breakdown));
      }, uuid);*/

      loyaltiesHistoryDetailsView.add(feedbackBtn);
      mainView.add(loyaltiesHistoryDetailsView);
      return mainView;
   };
})();