
var CARTSTK = function() {
    //Ti.include('/classes/suds.js');
    var cartstk = function(ro) {

        var cartStk = null;
        var shouldInclude = true;
        var CARTVIEW, NEWPAYMENTVIEW, SUGGESTVIEW, ADDPAYMENTVIEW, COUPONVIEW, GUESTDETAILS;

        function includeCartFiles() {
            CARTVIEW = CARTVIEW || require('revmobile/ui/cartView');
            CARTVIEW.cartview(ro);

            //NEWPAYMENTVIEW = NEWPAYMENTVIEW || require('revmobile/ui/tempPaymentView');
            //NEWPAYMENTVIEW.newpaymentview(ro);

            NEWPAYMENTVIEW = NEWPAYMENTVIEW || require('revmobile/ui/paymentView');
            NEWPAYMENTVIEW.newpaymentview(ro);

            SUGGESTVIEW = SUGGESTVIEW || require('revmobile/ui/suggestView');
            SUGGESTVIEW.suggestview(ro);

            ADDPAYMENTVIEW = ADDPAYMENTVIEW || require('revmobile/ui/addPayment');
            ADDPAYMENTVIEW.addpaymentview(ro);

            COUPONVIEW = COUPONVIEW || require('revmobile/ui/couponsView');
            COUPONVIEW.couponview(ro);

            GUESTDETAILS = GUESTDETAILS || require('revmobile/ui/guestDetails');
            GUESTDETAILS.guestdetails(ro);
            /*Ti.include('/revmobile/ui/cartView.js');      //DONE
            Ti.include('/revmobile/ui/newPaymentView.js');  //DONE
            Ti.include('/revmobile/ui/couponsView.js');     //DONE
            Ti.include('/revmobile/ui/giftCardView.js');    OLD
            Ti.include('/revmobile/ui/futureOrdView.js');   
            Ti.include('/revmobile/ui/levelupView.js');     
            Ti.include('/revmobile/ui/suggestView.js');     DONE
            Ti.include('/revmobile/ui/guestDetails.js');
            Ti.include('/revmobile/ui/addPayment.js');*/ // DONE    
            shouldInclude = false;
        };

        ro.ui.currentCartViewIdx = function() {
            return cartStk.currentIndex;
        };
        ro.ui.currentCartStkSize = function() {
            return cartStk.children.length;
        };
        ro.ui.cartStkViewID = function() {
            if (cartStk.hasOwnProperty('children') && cartStk.children.length) {
                return cartStk.children[0].hid;
            } else {
                return '';
            }
            //return cartStk.children[0].hid;
        };
        ro.ui.remCartStkChildren = function() {
            cartStk.removeAllChildren();
        };

        ro.ui.createCartStk = function(_args) {
            cartStk = ro.ui.createStackView({
                views: [],
                props: {
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0
                }
            });

            ro.ui.cartShowNext = function(e) {
                try {

                    if (shouldInclude) {
                        includeCartFiles();
                    }
                    var showOldCart = false;
                   /* if (Ti.App.serviceURL === 'https://hungryhowies.hungerrush.com/RevService.asmx' || Ti.App.serviceURL === 'https://hhtraining.hungerrush.com/RevService.asmx' || Ti.App.serviceURL === 'https://demo.hungerrush.com/RevService.asmx') {
                        showOldCart = false;
                    }*/

                    if (!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
                    ro.ui.showLoader();
                    var curIndex = cartStk.currentIndex;
                    var curView = cartStk.children[curIndex];
                    var nextView = null;
                    var interval = 400;
                    var childrenLength = cartStk.children.length;
                    cartStk.removeAllChildren();                    
                    if (e.addView) {
                        switch (e.showing) {
                            case 'Cart':
                                if (showOldCart) {
                                    nextView = ro.ui.oldcreateCartView();
                                } else {
                                    nextView = ro.ui.createCartView();                                    
                                }
                                //nextView = ro.ui.createCartView();

                                break;
                            case 'Suggest':
                                nextView = ro.ui.createSuggestView();
                                break;
                            case 'paymentScreen':
                                nextView = ro.ui.createNewPayView();
                                break;
                                /*case 'Payment':
                        nextView = ro.ui.createCreditCardPayView();
                        break;*/
                            case 'AddPayment':
                                /*try{
                                   nextView = ro.ui.createNewCreditCardPayView();
                                }
                                catch(e){
                                   alert(e);
                                }*/
                                break;
                            case 'Coupons':
                                nextView = ro.ui.createCouponsView();
                                break;
                            case 'GiftC':
                                nextView = ro.ui.addGiftCard();
                                break;
                            case 'futOrd':
                                nextView = ro.ui.createFutureOrdView();
                                break;
                            case 'levelup':
                                nextView = ro.ui.addLevelupView();
                                break;
                            case 'guestDetails':
                                nextView = ro.ui.createGuestDetailsView();
                                break;
                            case 'addPmt':
                                nextView = ro.ui.addPaymentView();
                                break;
                        }
                    } else {
                        switch (e.showing) {
                            case 'Cart':
                                ro.ui.changeTab({
                                    tabIndex: 0
                                });
                                break;
                            case 'Suggest':
                            case 'guestDetails':
                                nextView = ro.ui.createCartView();
                                break;
                            case 'paymentScreen':
                                //Ti.include('/controls/paymentControl.js');
                                Ti.App.atPayScrn = false;
                                //payControl.clearSpclInst();
                                ro.utils.removeProp('spclInst');
                                ro.utils.removeProp('delNote');
                                //payControl.clearGateCode();
                                ro.utils.removeProp('gateCode');
                                //nextView = ro.ui.createCartView();
                                if (showOldCart) {
                                    nextView = ro.ui.oldcreateCartView();
                                } else {
                                    nextView = ro.ui.createCartView();
                                }
                                break;
                            case 'levelup':
                                nextView = ro.ui.createNewPayView();
                                if (!ro.isiOS)
                                    ro.REV_LOYALTY.getCurrentLoyalty().releaseWebview();
                                break;
                            case 'Payment':
                            case 'GiftC':
                            case 'futOrd':
                                nextView = ro.ui.createNewPayView();
                                break;
                            case 'AddPayment':
                                /*Ti.include('/controls/ccControl.js');
                                if(ccControl.hasSavedCards()){
                                   //nextView = ro.ui.createCreditCardPayView();
                                }
                                else{
                                   nextView = ro.ui.createNewPayView();
                                }*/
                                break;
                            case 'Coupons':
                                //nextView = ro.ui.createCartView();
                                if (showOldCart) {
                                    nextView = ro.ui.oldcreateCartView();
                                } else {
                                    nextView = ro.ui.createCartView();
                                }
                                break;
                            case 'addPmt':
                                nextView = ro.ui.createNewPayView();
                                break;
                        }
                    }

                    if (nextView && nextView != null) {

                        try {
                            ro.app.GA.trackPageView(nextView.hid);
                        } catch (ex) {
                            if (Ti.App.DEBUGBOOL) {
                                Ti.API.debug('ro.app.GA.trackPageView(cartStk.js)-Exception: ' + ex);
                            }
                        }
                        cartStk.add(nextView);
                        cartStk.children[0].visible = true;

                        if (e.addView && e.showing == 'Cart') {
                            ro.ui.reloadCart();
                        } else if (!e.addView && (e.showing == 'paymentScreen' || e.showing == 'Coupons' || e.showing == 'Suggest' || e.showing == 'guestDetails')) {                            
                            ro.ui.reloadCart();
                        }
                        //tabBar.printStackSizes();
                        ro.ui.hideLoader();
                        ro.ui.hideHomeSelection(true);
                    }
                } catch (ex) {
                    ro.ui.alert('Navigation Error', 'Code:N300');
                    Ti.API.info('Navigation Error - Code:N300: ' + ex);
                    if (Ti.App.DEBUGBOOL) {
                        Ti.API.debug('Navigation Error - Code:N300: ' + ex);
                    }
                }
            };

            ro.ui.CartRemoveView = function(e) {
                cartStk.remove(e.view);
                cartStk.currentIndex--;
            };

            ro.ui.cartReset = function(e) {
                try {
                    Ti.API.debug('RO.UI.CARTRESET WAS CALLED!?!?!?!?');
                    ro.ui.cartShowNext({
                        addView: true,
                        showing: 'Cart'
                    });
                } catch (ex) {
                    ro.ui.alert('Navigation Error', 'Code:N302');
                }
            };
            return cartStk;
        };
    };
    return {
        cartstk: cartstk
    };
}();
module.exports = CARTSTK;