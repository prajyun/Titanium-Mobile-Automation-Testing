exports.getModsView = function(group, itemSelected, prefName, _cb, chosenPrefMods, chosenPrefNoMods, isEdit, isCpnEdit, usePrefGroupHalf){
	try{
		
		var menuUtils = require('logic/menuUtils');
		var Confg = {};
		if(ro.app.Store && ro.app.Store.Configuration){
			Confg = ro.app.Store.Configuration;
		}
		else if(Ti.App.Properties.hasProperty('Config')){
			Confg = JSON.parse(Ti.App.Properties.getString('Config'));
		}
		var AllowLite = Confg && Confg.AllowLite ? true : false;
		var UseModQtyTxt = Confg && Confg.USE_MOD_QTY_TXT ? true : false;
		
		var AllowHalf = group.AllowHalf;
		if(usePrefGroupHalf){
			AllowHalf = usePrefGroupHalf.AllowHalf;
		}
		//Ti.API.info('prefName: ' + prefName);
		var isPrefMods = prefName && prefName.name && prefName.name.length ? true : false;
		var gIdx = menuUtils.getGrpIdx(group.Name, ro.app.Store.Menu);
		var evenOddCtr = 0;
		var preCount = 0;
		var mdTable;
		var modsInfo = [];
		var mdRows = [];
	
		var modIndex = -1;
		var optionsData =[];
		var sortedMods = [];
	
		var optionsView = Ti.UI.createView();//POPUP BOX WITH FULL HALFONE AND HALFTWO OPTIONS
		var optionsTbl = Ti.UI.createTableView({//OPTIONS FULL HALFONE HALFTWO
			backgroundColor:'transparent',
			separatorColor:ro.ui.theme.separatorColor,
			mainview:null,
			name:'optionsTbl'
		});
		optionsView.add(optionsTbl);
		var modsView;
		if(isPrefMods){
			modsView = Ti.UI.createScrollView({
				//name:'Step ' + step++ + ': Please Select',
				layout:'vertical',
				edit:isEdit||isPrefMods ? reloadMods : null,
				cpnEdit:isCpnEdit ? editMods : null,
				disableBounce: ro.isiOS ? true : false,
                    //width:ro.ui.displayCaps.platformWidth -2,
                    contentWidth: Ti.UI.FILL,
				//top:ro.ui.relY(25),
				//left:ro.ui.relX(10),
				//right:ro.ui.relX(10),
				//height:'85%',
				height:Ti.UI.SIZE,
				zIndex:6
			});
		}
		else{
			modsView = Ti.UI.createView(/*ro.combine(ro.ui.properties.contentsSmallView, */{
				layout:'vertical',
				edit:isEdit ? reloadMods : null,
				cpnEdit:isCpnEdit ? editMods : null,
				height:Ti.UI.SIZE
			});//);
		}
		/*var titleTxt = 'Please select your toppings';
		var hdr = layoutMenuHelper.menuHeaders({text:titleTxt, leftRightBool:true});
		modsView.add(hdr);*/
	
		/*if(!itemObj.Mods){
			itemObj.Mods = [];
		}
		if(!itemObj.NoMods){
			itemObj.NoMods = [];
		}*/
	
		function sortMods(mod1, mod2){
			if(mod1.isPreselected && !mod2.isPreselected){
				return -1;
			}
			else
				if(!mod1.isPreselected && mod2.isPreselected){
					return 1;
				}
			return 0;
		}
		function sortModsPosPage(mod1, mod2){
	      
	      return mod1.isPreselected == mod2.isPreselected
	         ? parseInt(mod1.PosPage,10) - parseInt(mod2.PosPage,10)
	         : mod1.isPreselected < mod2.isPreselected;
	    }

	   var isReqMod = function(mod){
			if(itemSelected && itemSelected.ReqMods){
				var reqModCatKey;
				for(var i=0; i<itemSelected.ReqMods.length; i++){
					reqModCatKey = !isNaN(itemSelected.ReqMods[i].Key) ? itemSelected.ReqMods[i].Key : itemSelected.ReqMods[i];
					if(mod.ModCatKey == reqModCatKey){
						return true;
					}
				}
			}
			return false;
	   }
	
		var isValid = function(mod, size){
			var valid = isPrefMods ? true : !isReqMod(mod);
	
			if(valid){
				if(itemSelected.ExcldMods){
					for(var i=0; i<itemSelected.ExcldMods.length; i++){
						if(itemSelected.ExcldMods[i] == mod.Name){
							valid = false;
							break;
						}
					}
				}
			}
	
			if(valid && size && size !== null && mod.Sizes){
				valid = false; // Making it false since the service does not include the sizes with -0.86
				for(var i=0; i<mod.Sizes.length; i++){
					if(mod.Sizes[i].Name === size){
						var price = mod.Sizes[i].Price;
						if(group.UseOrdTypePricing && Ti.App.OrderObj.OrdTypePriceIdx > 0){
							switch(Ti.App.OrderObj.OrdTypePriceIdx){
								case 1:
									price = mod.Sizes[i].OrdTypePrice1;
									break;
								case 2:
									price = mod.Sizes[i].OrdTypePrice2;
									break;
							}
						}
						valid = (price !== -0.86);
						break;
					}
				}
			}
			return valid;
		};
	
		var formModsView = function(_cb){
			
			var startingIdx = 0;
			var nextTopValue = 0;
			//var mdTable;
			mdTable = null;
			var currentCatKey = -5;//sortedMods && sortedMods.length ? sortedMods[0].ModCatKey : 0;
			var headersOffset = 0;
			var defRowHidden = false;
			for(var i=0; i<sortedMods.length; i++){
				if(sortedMods[i].ModCatKey != currentCatKey){					
					if(i){
						for(var j=mdRows.length-1, jMin=0; j>=jMin; j--){
							if(mdRows[j].isHeader){
								var newRw = mdRows[j];
								newRw.endingIdx = mdRows.length;
								mdRows[j] = newRw;
								newRw = null;
								//Ti.API.debug('mdRows[j]:mdRows['+j+']: ' + JSON.stringify(mdRows[j]));
								break;
							}
						}
					}
					
					headersOffset++;
					currentCatKey = sortedMods[i].ModCatKey;
					//var modRow = Ti.UI.createTableViewRow({
					var modRow = Ti.UI.createView({
						height:ro.ui.relY(40),
						//height:Ti.UI.SIZE,
						width:Ti.UI.FILL,
						isHeader:true,
						//className:'modHdr',
						rowOffset:headersOffset,
						startingIdx:i+headersOffset,
						//endingIdx:endingIdx,
						isShowing:true//,
						//backgroundImage:'/images/invGrpBackground.png'
					});
					if(i){
					    modRow.top = ro.ui.relY(10);
					}
					
					if(!defRowHidden && i!=0){
						//defRowHidden = true;
					}
					modRow.add(Ti.UI.createImageView({
						touchEnabled:false,
						image:defRowHidden ? '/images/expandBtn.png' : '/images/collapseBtn.png',
						right:defRowHidden ? ro.ui.relX(5) : ro.ui.relX(5),
						//height:Ti.UI.FILL,
						//top:defRowHidden ? null : ro.ui.relY(5),
						//top:ro.ui.relY(5),
						width:defRowHidden ? ro.ui.relX(35) : ro.ui.relX(35),
						isOpen:defRowHidden ? false : true,
						zIndex:3
						//visible:defRowHidden ? true : false
					}));
					
					modRow.addEventListener('click', function(e){
						e.source.children[0].isOpen = !e.source.children[0].isOpen;
						e.source.children[0].image = !e.source.children[0].isOpen ? '/images/expandBtn.png' : '/images/collapseBtn.png';
						
						for(var j=e.source.startingIdx, jMax=e.source.endingIdx ? e.source.endingIdx : mdRows.length; j<jMax; j++){
							var tempHeight = mdRows[j].height;
							var tempTop = mdRows[j].top;
							
							mdRows[j].height = mdRows[j].oldHeight;
							mdRows[j].oldHeight = tempHeight; 
							
							mdRows[j].top = mdRows[j].oldTop;
							mdRows[j].oldTop = tempTop;
						}
					});
					var modCtIdx, rqMdKy;
					var modCats = group.ModCategories && group.ModCategories.length ? group.ModCategories : ro.app.Store.Menu.ModCategories;
						modCtIdx = ro.utils.getMatchingIdx(currentCatKey, modCats, 'Key');
					
					var hdrTxt = (isPrefMods ? (prefName.title + ' - ') : '') + 'Options';
					if(modCats[modCtIdx].Name && modCats[modCtIdx].Name.length && (modCats[modCtIdx].Name.toLowerCase() == 'none')){
						if(group.ModsHeader && group.ModsHeader.length){
							hdrTxt = isPrefMods ? prefName.title + ' - ' + group.ModsHeader : group.ModsHeader;
						}
					}
					else{
						if(modCats[modCtIdx].Msg && modCats[modCtIdx].Msg.length){
							hdrTxt = isPrefMods ? prefName.title + ' - ' + modCats[modCtIdx].Msg : modCats[modCtIdx].Msg;
						}
						else if(modCats[modCtIdx].Name && modCats[modCtIdx].Name.length){
							hdrTxt = isPrefMods ? prefName.title + ' - ' + modCats[modCtIdx].Name : modCats[modCtIdx].Name;
						}
					}
					
					var modHeader = ro.layout.getGenericMenuHdrRowWithHeader(hdrTxt, true);
					modHeader.top = 0;
					modHeader.bottom = 0;
					modHeader.height = Ti.UI.FILL;
					modHeader.touchEnabled = false;
					modRow.add(modHeader);
					
					var greyBar = Ti.UI.createView(ro.ui.properties.fullGreyBar);
					greyBar.bottom = 0;
					modRow.add(greyBar);
					mdRows.push(modRow);
					nextTopValue = -1;
					startingIdx = i;
				}
				
				//continue;
				
				var idx = 1;
				var isPreselected = sortedMods[i].isPreselected;
				var enable = false;
				var halfOptions = 1;
				if(sortedMods[i].isPreselected){
					idx = 0;
				}
				modIndex++;
				if(AllowHalf){
					enable = (sortedMods[i].NoHalf ? false:true);
					if(enable){
						if(idx != 0){
							idx = 3;
						}
						halfOptions = 3;
					}
				}
				if(halfOptions > 1){
					halfOptions = 4;
				}
				else{
				  halfOptions = 2;
				}
	
				var halfOptionsFlag = halfOptions;
				var defQtyAllowed = ro.app.Store.Menu.ExtraModMax > 0 ? ro.app.Store.Menu.ExtraModMax : 4;
				 
					if (sortedMods[i].ModMaxQty > 0){
						defQtyAllowed = sortedMods[i].ModMaxQty;
					}
				
				var dontGrow = !AllowLite && !enable && defQtyAllowed<2 ? true : false;
	
				var custModRowProps = {
					isPreselected:isPreselected,
					idx:idx,
					name:sortedMods[i].Name,
					halfOptionsFlag:halfOptionsFlag,
					remModIdx:AllowHalf ? 3 : 1,
					AllowHalf:enable,
					AllowLite:AllowLite,
					dontGrow:dontGrow,
					defQtyAllowed:defQtyAllowed
				};
				if(isPrefMods){
					custModRowProps.isPrefMods = true;
					custModRowProps.gIdx = gIdx;
					custModRowProps.prefName = prefName.name;
				}
				
				var isToppingBlockVisible = false;
				if(isPreselected){
					if(!dontGrow){
						isToppingBlockVisible = true;
					}
					preCount++;
				}
				var theRow = layoutMenuHelper.getPrefModRow(sortedMods[i], (i+headersOffset), (i+headersOffset), isPreselected, dontGrow, custModRowProps, layoutMenuHelper.getNewToppingsBlock(modClick, extraClick, sortedMods[i].Name, enable, null, defQtyAllowed, UseModQtyTxt, AllowLite, isToppingBlockVisible), defRowHidden);
				if(nextTopValue == -1){
				    theRow.top = 0;
				    theRow.oldTop = 0;
				    nextTopValue = 0;
				}
				if(evenOddCtr % 2){
                    theRow.backgroundColor = "#f6f6f6";
                }
                evenOddCtr++;
                mdRows.push(theRow);
			}
	
			mdTable = Ti.UI.createView({
				height:Ti.UI.SIZE,
				width:Ti.UI.FILL,
				layout:'vertical',
				clicked:preCount,
				backgroundColor:ro.ui.theme.tableBgColor,
				visible:true,
				prefName:isPrefMods&&prefName&&prefName.name ? prefName.name : '',
				disableBounce:ro.isiOS ? true : false,
				ignoreclick:true
			});
			if(isPrefMods){
				mdTable.gIdx = gIdx;
			}
			
			mdTable.addEventListener('click', function(e){
				var row = {};
				if(e.source.ignoreclick){
					Ti.API.debug('e.source.ignoreclick: ' + e.source.ignoreclick);
				}
				if(e.source.isHalfOptView || e.source.isHeader || e.source.ignoreclick){
					return;
				}
				
				
				if(e.source.isRowView){
					row = e.source.parent;
				}
				else if(e.source.isRow){
					row = e.source;
				}
				else{
					row = e.source.parent.parent;
				}
				
				try{
					if(row.isHeader){
						return;
					}
					if(mdTable.clicked){
					    if(layoutMenuHelper.newRowDeselected(row, row.clicked?true:false)){
					    	if(isPrefMods){
							   ro.itemObj.setPrefMods(row.name, row.remModIdx, row.isPreselected, 1, group, prefName.name);
						    }
						    else{
								ro.itemObj.setMods(row.name, row.remModIdx, row.isPreselected, 1);
							}
							mdTable.clicked--;
							return;
						}
					}
					mdTable.curIndex = layoutMenuHelper.newRowSelected(row);
					if(isPrefMods){
					   ro.itemObj.setPrefMods(row.name, 0, row.isPreselected, 1, group, prefName.name);
				    }
				    else{
						ro.itemObj.setMods(row.name, 0, row.isPreselected, 1);
					}
					mdTable.clicked++;
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('mods_new.js-mdTable.EVENT()-Exception: ' + ex); }
				}
			});
			
			mdTable.add(mdRows);
			
			modsView.add(mdTable);

			//_cb(modsView);
			return modsView;
		};
		function fieldSorter(fields) {
	      return function (a, b) {
	         return fields
	            .map(function (o) {
	               var dir = 1;
	               if(o[0] === '-'){
	                  dir = -1;
	                  o=o.substring(1);
	               }
	               if(a[o] > b[o]) return dir;
	               if(a[o] < b[o]) return -(dir);
	               return 0;
	            })
	            .reduce(function firstNonZeroValue (p,n) {
	               return p ? p : n;
	            }, 0);
	           /*.reduce(((p,n) => p ? p : n), 0);*/
	      };
	   }
	   
		var setModsPerSize = function(selectedSize, _cb){
			try{
				//itemObj.Mods = [];
	    	    mdRows = [];
				sortedMods = [];
				//modsView.removeAllChildren();
				//modsView.add(hdr);
				modIndex = -1;
	
				// ADDING GROUP MODS
				//var curMds = newMods && newMods.length ? newMods : group.Mods;
				var curMds = group.Mods;
	
				//var mdCategories = ro.app.Store.Menu.ModCategories ? ro.app.Store.Menu.ModCategories : [];
				//Ti.API.info('group.ModeCategories: ' + JSON.stringify(group.ModCategories));
				////Ti.API.info('ro.app.Store.Menu.ModCategories: ' + JSON.stringify(ro.app.Store.Menu.ModCategories));
				var mdCategories = group.ModCategories && group.ModCategories.length ? group.ModCategories : (ro.app.Store.Menu.ModCategories ? ro.app.Store.Menu.ModCategories : []);
				var differentSort = group.ModCategories && group.ModCategories.length ? true : false;
				
				
				if(differentSort){
					var foundSameCat = false;
					var catLen = ro.app.Store.Menu.ModCategories && ro.app.Store.Menu.ModCategories.length ? ro.app.Store.Menu.ModCategories.length : 0;
					storeModCats = ro.app.Store.Menu.ModCategories;
					for(var i=0, iMax=catLen; i<iMax; i++){
						foundSameCat = false;
						for(var j=0, jMax=group.ModCategories.length; j<jMax; j++){
							if(storeModCats[i].Key == group.ModCategories[j].Key){
								foundSameCat = true;
								break;
							}
						}
						if(!foundSameCat){
							mdCategories.push(storeModCats[i]);
						}
						
					}
				}
				
				//var gModsHash = menuUtils.getModsHash();
				for(var j=0, jMax=mdCategories.length; j<jMax; j++){
					//Ti.API.info('mdCategories['+j+']: ' + JSON.stringify(mdCategories[j]));
					for(var i=0; i<curMds.length; i++){
						if((curMds[i].ModCatKey == mdCategories[j].Key) && isValid(curMds[i], selectedSize)){
							
							//Ti.API.info('mdCategories['+j+'].Seq: ' +  mdCategories[j].Seq);
							var hdrTxt ='options';
							if(mdCategories[j].Name && mdCategories[j].Name.length && (mdCategories[j].Name.toLowerCase() == 'none')){
								if(group.ModsHeader && group.ModsHeader.length){
									hdrTxt = group.ModsHeader.toLowerCase();
								}
							}
							else{
								if(mdCategories[j].Msg && mdCategories[j].Msg.length){
									hdrTxt = mdCategories[j].Msg.toLowerCase();
								}
								else if(mdCategories[j].Name && mdCategories[j].Name.length){
									hdrTxt = mdCategories[j].Name.toLowerCase();
								}
							}
	
							var ExtraModMax = ro.app.Store.Menu.ExtraModMax > 0 ? ro.app.Store.Menu.ExtraModMax : 4;					
							if (curMds[i].ModMaxQty > 0){
								ExtraModMax = curMds[i].ModMaxQty;
							}
							sortedMods.push({
								Name:curMds[i].Name,
								NoHalf:curMds[i].NoHalf,
								isPreselected:false,
								ModCatKey:curMds[i].ModCatKey,
								ModMaxQty: ExtraModMax,
								//sortModCatKey: hdrTxt,
								sortModCatKey: differentSort ? mdCategories[j].Seq : hdrTxt,
								DisplayName:curMds[i].DisplayName,
								ReceiptName:curMds[i].ReceiptName,
								PosPage:curMds[i].PosPage,
								ndx:sortedMods.length,
								smallName:curMds[i].DisplayName ? curMds[i].DisplayName.toLowerCase() : (curMds[i].ReceiptName ? curMds[i].ReceiptName.toLowerCase() : (curMds[i].Name ? curMds[i].Name.toLowerCase() : ""))
							});					 		
						}
						else{
							
							//Ti.API.info('curMds['+i+'] is not valid: ' + JSON.stringify(curMds[i].Name));
							//Ti.API.info('curMds['+i+']: ' + JSON.stringify(curMds[i]));
						}
					}
				}
	
				if(itemSelected.PreMods){
					for(var j=0; j<itemSelected.PreMods.length; j++){
						for(var i=0; i<sortedMods.length; i++){
							if(itemSelected.PreMods[j].Name == sortedMods[i].Name){
								sortedMods[i].isPreselected = true;
								break;
							}
						}
					}
					if(!ro.app.Store.Configuration.SORT_MODS_PS){
					   sortedMods = sortedMods.sort(function(a, b) {
					   	/*if(differentSort){
					   		
					   	}*/
					   	var aSortKey = differentSort ? (a.sortModCatKey) : (a.sortModCatKey && a.sortModCatKey.length ? a.sortModCatKey.toLowerCase() : '');
					   	var bSortKey = differentSort ? (b.sortModCatKey) : (b.sortModCatKey && b.sortModCatKey.length ? b.sortModCatKey.toLowerCase() : '');
		              	  if(aSortKey > bSortKey) return 1;
		               	  else if(aSortKey < bSortKey) return -1;
		               	  else if(a.isPreselected > b.isPreselected) return -1;
		               	  else if(a.isPreselected < b.isPreselected) return 1;
		               	  else if(a.smallName > b.smallName) return 1;
		               	  else if(a.smallName < b.smallName) return -1;
		                  else return 0;
		               });
					}
				}
				
				if(ro.app.Store.Configuration.SORT_MODS_PS){
				   //sortedMods = sortedMods.sort(sortModsPosPage);
				   //sortedMods = sortedMods.sort(fieldSorter(['-isPreselected', 'PosPage']));
				   sortedMods = sortedMods.sort(function(a, b) {
				   		/*var aSortKey = a.sortModCatKey && a.sortModCatKey.length ? a.sortModCatKey.toLowerCase() : '';
					   	var bSortKey = b.sortModCatKey && b.sortModCatKey.length ? b.sortModCatKey.toLowerCase() : '';*/
					   	var aSortKey = differentSort ? (a.sortModCatKey) : (a.sortModCatKey && a.sortModCatKey.length ? a.sortModCatKey.toLowerCase() : '');
					   	var bSortKey = differentSort ? (b.sortModCatKey) : (b.sortModCatKey && b.sortModCatKey.length ? b.sortModCatKey.toLowerCase() : '');
		               /*if (a.ModCatKey > b.ModCatKey ) return -1;
		               else if (a.ModCatKey < b.ModCatKey ) return 1;*/
		              if (aSortKey > bSortKey) return 1;
		               else if (aSortKey < bSortKey) return -1;
		               else if (a.isPreselected > b.isPreselected ) return -1;
		               else if (a.isPreselected < b.isPreselected ) return 1;
		               else if (a.PosPage > b.PosPage ) return 1;
		               else if (a.PosPage < b.PosPage ) return -1;
		               else return 0;
		            });
				}
				
	
				if(!sortedMods.length){
					return -2;
				}
				
				if(selectedSize && selectedSize.length){
				   
				}
				else{
				   //formModsView(_cb);
				   return formModsView();
				}
			}
			catch(ex){
			   if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('setModsPerSize()-Exception: ' + ex); }
			}
		};
	
		function getHalfOptions(rw){
			var halfBlock = rw.children[1].children[0];
			var returnBool = 0;
			for(var i=0; i<halfBlock.children.length; i++){
				if(halfBlock.children[i].clicked){
					returnBool = halfBlock.children[i].idx;
					break;
				}
			}
			return returnBool;
		}
	
		function extraClick(e){
			try{
				var tblRow = e.source.parent.parent;
				var row = e.source.getSelectedRow(0);
	
				var name = e.source.name;
				var preSel = tblRow.isPreselected;
				var qty = row.index;
				var halfOptns = 0;
	
				try{
				   halfOptns = getHalfOptions(tblRow);
				}
				catch(ex){
				   halfOptns = 0;
				   if(Ti.App.DEBUGBOOL) { Ti.API.debug('extraQty-getHalfOptions()-Exception: ' + ex); }
				}
	
				if(isPrefMods){
					ro.itemObj.setPrefMods(name, halfOptns, preSel, qty, group, prefName.name);
				}
				else{
					ro.itemObj.setMods(name, halfOptns, preSel, qty);
				}
			}
			catch(ex){
				Ti.API.debug('extraClick()-Exception: ' + ex);
				//ro.ui.alert('Extra Click - Exception: ', ex);
			}
		}
	
		function modClick(e, cpnEdit, halfOptn, xtra, nm, pId, rIdx){
			try{
			   if(cpnEdit){
	               var row = e,
	                   rowName = nm,
	                   parentId = pId,
	                   index = rIdx,
	                   halfOpt = halfOptn,
	                   extraRowQty = xtra,
	                   preSel = false;
	           }
	           else{
	              var extraRowQty = 1;
	              var row = e.source.parent.parent.parent;
	              var rowName = row.name;
	              var preSel = row.isPreselected;
	              var parentId = row.parentId;
	              var extraPicker = e.source.parent.parent.children[0];
	              var index = row.idx;
	              var halfOpt = e.source.idx;
	              try{
	              	var maxQty = extraPicker.children && extraPicker.children.length ? extraPicker.children.length : 0;
	              	for(var i=0, iMax=maxQty; i<iMax; i++){
	              		if(extraPicker.children[i].clicked){
	              			//Ti.API.debug('i: ' + i);
	              			if(row.AllowLite){
	              				extraRowQty = i;
	              			}
	              			else{
	              				extraRowQty = i+1;
	              			}
	              			
	              			break;
	              		}
	              	}
	              	if(!maxQty){
	              		extraRowQty = 1;
	              	}
	              	 
	              }
	              catch(ex){
	                 extraRowQty = 1;
	              }
	           }
	           if(isPrefMods){
			      ro.itemObj.setPrefMods(rowName, halfOpt, preSel, extraRowQty, group, prefName.name);
			   }
			   else{
	           	  ro.itemObj.setMods(rowName, halfOpt, preSel, extraRowQty);
	           }
	     	}
			catch(ex){
				//ro.ui.alert('modclick',ex);
				Ti.API.debug('modClick()-Exception: ' + ex);
			}
		}
	
		function isPreselected(mod){
		   var rtnBool = false;
		   for(var i=0; i<itemSelected.PreMods.length; i++){
				if(itemSelected.PreMods[i].Name == mod){
					rtnBool = true;
					break;
				}
			}
			return rtnBool;
		}
	
		//setModsPerSize(null, _cb);
		//scrollViewData.push(modsView);
		//return modsView;
	}
	catch(ex){
		//Ti.API.debug('getModsView-Exception: ' + ex);
		ro.ui.alert('Modifiers','CODE 100');
	}
	
	function editMods(idx){
		try{
		   var cpnMods, cpnRowBool = false;
			var mdTable = mdTable || (this.children && this.children.length ? this.children[0] : []);
			var isPrefMods = mdTable.prefName && mdTable.prefName.length ? true : false;
	
		      cpnRowBool = false;
		      //var mRows = modsInfo[a].tbl.data[0].rows;
		      //var mRows = mdTable.data[0].rows;
		      var mRows = this.children[0].children;
		      var rowsCount = this.children[0].children.length;
		      var ctr = 0;
	
			  function doWork(){
			  	 var i = ctr;
			  	 if(mRows[i].isHeader){
					ctr += 1;
					setTimeout(doWork, 1);
				 }
				 else{
				 	cpnMods = ro.cpnHelper.chosenMods(mRows[i].name);
	
			         if(cpnMods.isChosen){
			            var mRow = mRows[i];
		
			            if(!mRow.clicked){
			               cpnRowBool = true;
			               layoutMenuHelper.newRowSelected(mRow);//Changes text, rowSize, backgroundImage, item customization control visibility
		
			               /*if(mRow.children[1].children[0].isHalf){
				               mRow.children[1].children[0].toggle(cpnMods.HalfStatus);
				               mRow.children[1].children[1].toggle(cpnMods.Qty, cpnMods.IsLite);
				            }
			               else{
			                  mRow.children[1].children[0].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              /*if(mRow.children[1].children[0].isHalf){
				               //mRow.children[1].children[1].toggle(cpnMods.HalfStatus);	index switched from above due to new layout...and i believe the following line is the new way to call
				               mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				               mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
				            }
			               else{
			                  mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				          mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
		
			               mdTable.clicked++;
			                
			               if(isPrefMods){
							  ro.itemObj.setPrefMods(mRow.name, cpnMods.HalfStatus, false, (cpnMods.IsLite ? 0 : cpnMods.Qty), ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
						   }
						   else{
			               	  ro.itemObj.setMods(mRow.name, cpnMods.HalfStatus, false, cpnMods.IsLite ? 0 : cpnMods.Qty);
			               }
			            }
			            else{//Row is clicked ( meaning it is preselected mod ) &&&& its returning true being in the mods collection ... this means it is preselected and the user chose extra
		
			              	//NOTE:
			              	//No need to check no mods here because this section will only occur when a preselected modifier was changed to extra! If so, the correct halfstatus is returned here as part of this mod and therefore we can properly set the itemObj with this information
			              	//NOTE:
		
			               cpnRowBool = true;
		
			               /*if(mRow.children[1].children[0].isHalf){
			                  mRow.children[1].children[0].toggle(cpnMods.HalfStatus);
			                  mRow.children[1].children[1].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }
			               else{
			                  mRow.children[1].children[0].toggle(cpnMods.Qty, cpnMods.IsLite);
			               }*/
			              mRow.topBlock.toggleHalfOpts(cpnMods.HalfStatus);
				          mRow.topBlock.toggleQty(cpnMods.Qty, cpnMods.IsLite);
		
						   if(isPrefMods){
							  ro.itemObj.setPrefMods(mRows[i].name, cpnMods.HalfStatus, true, (cpnMods.IsLite ? 0 : cpnMods.Qty), ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
						   }
						   else{
			               	  ro.itemObj.setMods(mRows[i].name, cpnMods.HalfStatus, true, cpnMods.IsLite ? 0 : cpnMods.Qty);
			               }
			            }
			         }
			         else{
			            if(mRows[i].clicked){
			               	var NoMd = ro.cpnHelper.getNoMods(mRows[i].name);
				               if(NoMd){
				               	cpnRowBool = true;
			                  	var mRow = mRows[i];
								var realHalfStatus = 0;
		
				                  if(NoMd.HalfStatus === 0){
				                  	realHalfStatus = mRow.remModIdx;
				                  }
				                  else if(NoMd.HalfStatus === 1){
				                  	realHalfStatus = 2;
				                  }
				                  else if(NoMd.HalfStatus === 2){
				                  	realHalfStatus = 1;
				                  }
		
		
								  if(isPrefMods){
									 ro.itemObj.setPrefMods(mRow.name, realHalfStatus, true, 1, ro.app.Store.Menu.Groups[mdTable.gIdx], mdTable.prefName);
								  }
								  else{
				                  	 ro.itemObj.setMods(mRow.name, realHalfStatus, true, 1);
				                  }
		
				                   /*if(mRow.children[1].children[0].isHalf){
					                  mRow.children[1].children[0].toggle(realHalfStatus);
					               }*/
					              mRow.topBlock.toggleHalfOpts(realHalfStatus);
		
				                  if(NoMd.HalfStatus == 0){
				                  	layoutMenuHelper.newRowDeselected(mRow, true);
			                  		mdTable.clicked--;
				                  }
				               }
				               else{
				               	//continue;
				               }
			            }
			         }
			         
			         ctr += 1;
					 if(ctr < rowsCount){
						setTimeout(doWork, 1);
					 }
				 }
			  }
			  setTimeout(doWork, 1);
		}
		catch(ex){
			if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('mods_new.js-EditMods()-Exception: ' + ex); }
		}
	}
	function reloadMods(addMods, addNoMods, _callback){
		try{
			var newModLength = addMods?addMods.length:0;
			var noModLength = addNoMods?addNoMods.length:0;
			
			var mdRows = this.children[0].children;
			
			var gIdx = this.children[0].gIdx;
			var prefName = this.children[0].prefName || '';
			var isPrefMods = prefName && prefName.length ? true : false;
			
			var rowsCount = mdRows.length;
			
			var ctr = 0;
				function doWork(){
					var i = ctr;
					var mRow = mdRows[i];
					if(mRow.isHeader){
						ctr += 1;
						setTimeout(doWork, 1);
					}
					else{
						for(var j=0; j<noModLength; j++){
							if(addNoMods[j].Name === mRow.name){
								var noModHalf = mRow.children[1].children[0];
								var noModQuant = mRow.children[1].children[1];
								var halfLength = addNoMods[j].HalfStatus;
							   //if(noModHalf.isHalf){
								   if(addNoMods[j].HalfStatus === 1){
					               	  	halfLength = 2;
					               }
					               if(addNoMods[j].HalfStatus === 2){
					               		halfLength = 1;
					               }
					               mRow.topBlock.toggleHalfOpts(halfLength);
				          		   mRow.topBlock.toggleQty(addNoMods[j].Qty, addNoMods[j].IsLite);
				                  //noModHalf.toggle(halfLength);
				                  //noModQuant.toggle(addNoMods[j].Qty, addNoMods[j].IsLite);
				               /*}
				               else{
				               	  mRow.topBlock.toggleQty(addNoMods[j].Qty, addNoMods[j].IsLite);
				                  //noModHalf.toggle(addNoMods[j].Qty, addNoMods[j].IsLite);
				               }*/
				               //var halfLength = addNoMods[j].HalfStatus;
				               
				               if(addNoMods[j].HalfStatus === 0){
				                  try{
				                     if(noModHalf.isHalf){
				                        halfLength = noModHalf.children.length || 1;
				                     }
				                     else{
				                     	if(AllowHalf){
				                     		halfLength = 3;
				                     	}
				                     	else{
				                        	halfLength = 1;
				                        }
				                     }
				                  }
				                  catch(ex){
				                     Ti.API.debug('halfLength-Exception: ' + ex);
				                     halfLength = 1;
				                  }
				                  layoutMenuHelper.newRowDeselected(mRow, true);
				               }
				               
				               
				               if(isPrefMods){
								  ro.itemObj.setPrefMods(mRow.name, halfLength, true, addNoMods[j].IsLite? 0 : addNoMods[j].Qty, ro.app.Store.Menu.Groups[gIdx], prefName);
							   }
							   else{
				               	  ro.itemObj.setMods(mRow.name, halfLength, true, addNoMods[j].IsLite ? 0 : addNoMods[j].Qty);
				               }
				               
				               noModHalf = null;
				               noModQuant = null;
							}
						}
						for(var j=0, jMax=newModLength; j<jMax; j++){
							if(addMods[j].Name === mRow.name){
								var half = mRow.children[1].children[0];
								var quant = mRow.children[1].children[1];
							   layoutMenuHelper.newRowSelected(mRow);
							   //if(half.isHalf){
							   	mRow.topBlock.toggleHalfOpts(addMods[j].HalfStatus);
				         		 mRow.topBlock.toggleQty(addMods[j].Qty, addMods[j].IsLite);
		
			                  	  //half.toggle(addMods[j].HalfStatus);
			                  	  //quant.toggle(addMods[j].Qty, addMods[j].IsLite);
			                   /*}
			               	   else{
			               	   	  mRow.topBlock.toggleQty(addMods[j].Qty, addMods[j].IsLite);
			                  	  //half.toggle(addMods[j].Qty, addMods[j].IsLite);
			                   }*/
			                   if(isPrefMods){
								  ro.itemObj.setPrefMods(mRow.name, addMods[j].HalfStatus, addMods[j].IsPreSel, addMods[j].IsLite ? 0 : addMods[j].Qty, ro.app.Store.Menu.Groups[gIdx], prefName);
							   }
							   else{
			                   	  ro.itemObj.setMods(mRow.name, addMods[j].HalfStatus, addMods[j].IsPreSel, addMods[j].IsLite ? 0 : addMods[j].Qty);
			                   }
			                   half = null;
			                   quant = null;
							}
						}
	
						ctr += 1;
						if(ctr < rowsCount){
							setTimeout(doWork, 1);
						}
					}
				}
				setTimeout(doWork, 1);
		}
		catch(ex){
			Ti.API.debug('reloadMods()-Exception: ' + ex);
		}
	}
	
	return setModsPerSize(null, _cb);
};

