(function(){
   ro.ui.addRewardsView = function(_args){
      Ti.App.Properties.setBool('lvlupBool', false);

      var registeringFromSettings = _args && _args.settingsBool ? true : false;

      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'rewards', hid:'rewards', layout:'vertical'}));
      var navBar = Ti.UI.createView(ro.ui.properties.navBar);

      /* if(ro.ui.theme.bannerImg){
         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
         navBar.add(headerImg);
      }
      else{
         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'LevelUp'}));
         navBar.add(headerLbl);
      } */

      var btnBack = layoutHelper.getBackBtn(registeringFromSettings?'SETTINGS':'ORDER TYPE');
      btnBack.addEventListener('click', function(e){
        if(registeringFromSettings){
           ro.ui.settingsShowNext({showing:mainView.hid});
        }
        else{
	        var Config = JSON.parse(Ti.App.Properties.getString('Config'));
	        if(!Config){
	           Config = {};
	        }
	        var companyName = Config.CompanyName;
            REV_CUSTOMER.changeEClubOptIn(2, true, function(){});

           ro.ui.alert('Rewards: ', 'You did not complete the rewards enrollment process. You may enroll in ' + companyName + ' rewards in the settings menu.');
           ro.ui.registerRewardsEnd();
        }
      });
      navBar.add(btnBack);

      var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      var webView = levelUp.getWebView(function(e){
         Ti.App.Properties.setBool('lvlupBool', true);
         if(registeringFromSettings){
            REV_CUSTOMER.changeEClubOptIn(1, false, function(){
              ro.ui.settingsShowNext({showing:mainView.hid});//Must go back to settings view since the customer may not have a store yet.
            });
            
         }
         else{
            ro.ui.registerRewardsEnd();
         }
      }, true);

      mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
      mainView.add(webView);
      return mainView;
   };
})();