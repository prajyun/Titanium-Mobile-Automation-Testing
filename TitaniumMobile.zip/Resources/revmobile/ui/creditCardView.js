var CREDITCARDVIEW = function(){
	var creditcardview = function(ro){
	   //try{
	   	  ro.ui.createCreditCardView = function(_args){
	   	  	 //Ti.include('/controls/ccControl.js');
	         var ccControl = require('controls/ccControl');
	         var rs = {};
	         //Ti.API.debug('Ti.App.Username: ' + Ti.App.Username);	         
	         
	         var CCinfo, cardObj, cardLastDigits, creditLbl;
	         
	         var view = Ti.UI.createScrollView(ro.combine(ro.ui.properties.contentsSmallView, {
	           top:ro.ui.relY(5),
	           layout:'vertical',
	           disableBounce:ro.isiOS ? true : false,
	   	  	   contentWidth:Ti.UI.FILL
	      	}));
	
	         var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'creditcard', hid:'creditCard', layout:'vertical'}));
	         var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	         var noCardLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'You do not have any saved credit cards'}));
	         
	         var addCCBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	         addCCBtn.addEventListener('click', function(e){
	            try{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'addCardBtn'});
	            }
	            catch(ex){
	               ro.ui.alert('Credit Card Error', 'Code:110' + ex);
	            }
	         });
	
	         var btnBack = layoutHelper.getBackBtn('SETTINGS');
	         btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'creditCard'}); });
	
	         navBar.add(btnBack);
	         //navBar.add(addCCBtn);
	         //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	         if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	         
	         
	         
			 var refreshView = function () {
				rs = ro.db.getAllCustCC(Ti.App.Username);
				var defCardCol = [];
				var otherCardCol = [];
                Ti.API.info("Refresh Curbside View Called");
                view.removeAllChildren();
	         	for(var i=0, iMax=rs&&rs.length?rs.length:0; i<iMax; i++){
			 	     	  //Ti.API.debug('rs[i]' + JSON.stringify(rs[i]));
				
	         			/*var ccObj = {
	         				customObj:{
	         					id:rs[i].rowid
	         				},
	         				formattedText:formattedString
	         			};
	         			CCinfo = ro.layout.getGenericRow(ccObj);
	         			if(i){
	         				CCinfo.top = ro.ui.relY(10);
	         			}
	         			CCinfo.addEventListener('click', function(e){
		     	          try{
		     	             ro.ui.showLoader();
		     	             ro.ui.settingsShowNext({addView:true, showing:'editCardView', rowid:e.source.id});
		     	          }
		     	          catch(ex){
		     	             ro.ui.alert('editCreditCardList Error', 'Code:110' + ex);
		     	          }
		     	       });*/
						var last4 = ccControl.getLastFour(rs[i].CCInfo.OLCardNum);
						var MaskedDisp;
						var maskedNum = null; 
						if(rs[i].CCInfo.TokenID && rs[i].CCInfo.TokenID.length){
							maskedNum = rs[i].CCInfo.MaskedNumber.toLowerCase();
							MaskedDisp = rs[i].CCInfo.MaskedNumber.toUpperCase();
						}else{
							MaskedDisp = rs[i].CCInfo.OLCardNum.length === 16 ? ('XXXX-XXXX-XXXX-' + last4) : ('XXXX-XXXXXX-X' + last4);
						}
						var formattedString = MaskedDisp + '\n' + rs[i].CCInfo.PayerName.toUpperCase() + '\n' + ccControl.getMonthNum(rs[i].CCInfo.OLExpMonth) + "/" + rs[i].CCInfo.OLExpYear;
	         			
						var CCObj = {
	         				customObj:{
	         					id:rs[i].rowid,
								last4 : last4,
								maskedNum : maskedNum
	         				}
	         			};					                    
             	           CCObj.formattedHdr = (rs[i].CCInfo.CardInfo.toUpperCase());
             	           CCObj.formattedText = formattedString;
             	           CCinfo = ro.layout.getSpecialRow(CCObj, true);
						   CCinfo.children[1].addEventListener('click', function(e){
								ro.ui.popup('Alert', ['Cancel', 'OK'], 'Are you sure you want to delete card ending in ' + e.source.parent.last4 + '?', function(x) {								
									if(e.source.parent.maskedNum){
										var req = {};                    				
                    					req.Email = Ti.App.Username;
                    					req.MaskedNumber = e.source.parent.maskedNum;
                    					ro.ui.showLoader();
										Ti.API.info("Delete Card request: " + JSON.stringify(req));
                    					ro.dataservice.postAPI(req, "DeleteCardToken", function (response) {
                    					    Ti.API.info("Delete Card response: " + JSON.stringify(response));
                    					    if (response.Success) {                    				        
                    					        if(ccControl.deleteCurrentCC(e.source.parent.id, ro)){
													ro.ui.alert('Success: ', 'Card was deleted.');
													refreshView();
												}
											  	else{
													ro.ui.alert('Error: ', 'Card was not deleted.');
												}                    				        
                    					        ro.ui.hideLoader();    

                        					}else {
                        					    ro.ui.alert('Error: ', 'Card was not deleted from server.');
                        					    ro.ui.hideLoader();                            
                        					}
                    					});
									}else{
										if(ccControl.deleteCurrentCC(e.source.parent.id, ro)){
											ro.ui.alert('Success: ', 'Card was deleted.');
											refreshView();
										}
										  else{
											ro.ui.alert('Error: ', 'Card was not deleted.');
										}
									}        
									
								});
							});

	         			if(ccControl.getDefaultCard(ro) == rs[i].rowid){
		     	          defCardCol.push(CCinfo);
		     	       }
		     	       else{
		     	          otherCardCol.push(CCinfo);
		     	       }
					
	         	}
			 
	         	if(!ccControl.hasSavedCards(ro)){
	         		var noCardHdr = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitleBg, {
			 	         text:'Credit Cards',
			 	         font:ro.ui.font.pathToMenuTitles
			 	      }));
	         		view.add(noCardHdr);
	         		noCardLbl.top = ro.ui.relY(10);
	         	   view.add(noCardLbl);
	         	}
	         	else{
	         		var otherCardLength = 0;
	         		if(defCardCol && defCardCol.length){
	         			view.add(ro.layout.getGenericHdrRow("Default Credit Card"));
	         			view.add(defCardCol[0]);
	         		}
	         		if(otherCardCol && otherCardCol.length){
	         			otherCardLength = otherCardCol.length;
	         			view.add(ro.layout.getGenericHdrRow("Previously Used"));
	         		}
	         		for(var i=0, iMax=otherCardLength; i<iMax; i++){
	         			view.add(otherCardCol[i]);
	         		}
	         	}
			}
			refreshView();
	        mainView.add(view);
	         return mainView;
	   	  };
	      ro.ui.oldcreateCreditCardView = function(_args){
	         //Ti.include('/controls/ccControl.js');
	         var ccControl = require('controls/ccControl');
	         var rs = {};
	         //Ti.API.debug('Ti.App.Username: ' + Ti.App.Username);
	         rs = ro.db.getAllCustCC(Ti.App.Username);
	         var CCinfo, cardObj, cardLastDigits, creditLbl;
	         var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView, {
	            layout:'vertical'
	         }));
	
	         var defLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(10),
	            left:ro.ui.relX(10),
	            top:ro.ui.contentsTop,
	            focusable:false
	         }));
	         defLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'DEFAULT CARD:',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	            }
	         })));
	
	         var otherLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(10),
	            left:ro.ui.relX(10),
	            top:ro.ui.halfContentsTop,
	            focusable:false
	         }));
	         otherLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	            text:'OTHER CARDS:',
	            font:{
	               fontSize:ro.ui.scaleFont(15, 0, 0),
	               fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	            }
	         })));
	
	         var defTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
	            //headerView:defLblView,
	            //top:ro.ui.contentsTop,
	            top:0,
	            //left:ro.ui.properties.hdrViewMargins.left,
	            //right:ro.ui.properties.hdrViewMargins.right,
	            //height:ro.ui.relY(67)
	            height:Ti.UI.SIZE
	         }));
	
	         var cardRows = ccControl.nonDefaultCards(ro)*41;
	         if(cardRows > 164){
	            cardRows = 164;
	         }
	
	         var otherTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
	            top:0,
	            height:Ti.UI.SIZE
	         }));
	         var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'creditcard', hid:'creditCard'}));
	         var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	         var noCardLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved cards'}));
	
	         var noneTbl = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
	            className:'noneRow',
	            height:ro.ui.relY(40),
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	         }));
	         var noneLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
	            text:'No Saved Cards',
	            color:ro.ui.theme.contentsTextColor
	         }));
	         noneTbl.add(noneLbl);
	         
	         /* if(ro.ui.theme.bannerImg){
	            var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	            navBar.add(headerImg);
	         }
	         else{
	            var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Credit Cards'}));
	            navBar.add(headerLbl);
	         } */
	         
	         //var addCCBtn = layoutHelper.getRightBtn('ADD CARD');
	         var addCCBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	         addCCBtn.addEventListener('click', function(e){
	            try{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'addCardBtn'});
	            }
	            catch(ex){
	               ro.ui.alert('Credit Card Error', 'Code:110' + ex);
	            }
	         });
	
	         var btnBack = layoutHelper.getBackBtn('SETTINGS');
	         btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'creditCard'}); });
	
	         navBar.add(btnBack);
	         navBar.add(addCCBtn);
	         mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			 try{
		         var ccLength = rs? rs.length:0;
		         for(var i=0; i<ccLength; i++){
		            cardObj = rs[i].CCInfo;
		            CCinfo = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
		               id:rs[i].rowid,
		               className:'card',
		               height:ro.ui.relY(40),
		               leftImage:'/images/' + cardObj.CardInfo.toLowerCase() + '.png'
		            }));
		            creditLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
		               //text:cardObj.CardInfo + '\t\t\t\t\t **-' + ccControl.getLastFour(cardObj.OLCardNum),
		               text:'**-' + ccControl.getLastFour(cardObj.OLCardNum, ro),
		               id:rs[i].rowid,
		               color:ro.ui.theme.contentsTextColor
		            }));
		
		            CCinfo.add(creditLbl);
		
		            CCinfo.addEventListener('click', function(e){
		               try{
		                  ro.ui.showLoader();
		                  ro.ui.settingsShowNext({addView:true, showing:'editCardView', rowid:e.source.id});
		               }
		               catch(ex){
		                  ro.ui.alert('editCreditCardList Error', 'Code:110' + ex);
		               }
		            });
		            if(ccControl.getDefaultCard(ro) == rs[i].rowid){
		               defTbl.appendRow(CCinfo);
		            }
		            else{
		               otherTbl.appendRow(CCinfo);
		            }
		         }
		      }
		      catch(ex){
		      	//Ti.API.debug('ex: ' + ex);
		      }
	
	         if(!ccControl.hasSavedCards(ro)){
	            view.add(noCardLbl);
	         }
	         else{
	            if(!defTbl.data.length){
	               defTbl.appendRow(noneTbl);
	            }
	            if(!otherTbl.data.length){
	               otherTbl.appendRow(noneTbl);
	            }
	            view.add(defLblView);
	            view.add(defTbl);
	
	            view.add(otherLblView);
	            view.add(otherTbl);
	         }
	
	         mainView.add(view);
	         return mainView;
	      };//End ro.ui.createCreditCardView()
	   /*}
	   catch(ex){
	      if(Ti.App.DEBUGBOOL) { Ti.API.debug('ro.ui.createCreditCardView()-Exception: ' + ex); }
	      //ro.ui.hideLoader();
	   }*/
	};
	return {
		creditcardview:creditcardview
	};
}();
module.exports = CREDITCARDVIEW;