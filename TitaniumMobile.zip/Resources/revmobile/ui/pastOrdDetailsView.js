(function(){
   try{
   	ro.ui.createPastOrdDetailsView = function(_args){
         var storeObj = ro.app.Store;
         var mainFont = {
         		fontSize:ro.ui.scaleFont(11,0,0),
         		fontWeight:'bold'
         };
         var OrderObj = {};
         try{
         	OrderObj = JSON.parse(db.getOrdByRowID(_args.rowid));
         }
         catch (ex){
         	ro.ui.alert('Past order details', 'Error occured. CODE:101.');
         }

         var mainFont = {fontSize:ro.ui.scaleFont(11,0,0),fontWeight:'bold'};
         var tableData;
         var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch,{name:'past order details', hid:'past order details'}));
         var itmTcktView =  Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
            top:ro.ui.relY(55)
         }));
         var navBar = Ti.UI.createView(ro.ui.properties.navBar);
         var logoutBtn = Ti.UI.createButton(ro.ui.properties.logoutBtn);
         logoutBtn.addEventListener('click',function(e){
            ro.ui.exitApp();
         });
         var btnBack = Ti.UI.createButton(ro.ui.properties.backBtn);
         btnBack.addEventListener('click',function(e){
            ro.ui.pastOrdShowNext({showing:'past order details'});
         });
         navBar.add(logoutBtn);
         navBar.add(btnBack);

         /* if(ro.ui.theme.bannerImg){
            var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
            navBar.add(headerImg);
         }
         else{
            var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Address'}));
            navBar.add(headerLbl);
         } */

         mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
         mainView.add(itmTcktView);

         var itemTable = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView,{
         	backgroundColor:'transparent',
         	separatorColor:'transparent',
         	top:ro.ui.relY(12),
         	bottom:ro.ui.relY(90)
         }));

         var noItems = Ti.UI.createImageView({
         	image:ro.ui.properties.defaultPath +  'cart.png',
         	width: ro.ui.relY(128),
         	height: ro.ui.relY(128)
         });
         itmTcktView.add(itemTable);
         itmTcktView.add(noItems);

         var totalsView = Ti.UI.createView(ro.ui.properties.grpBackgroundView);

         var subTotalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(5),
         	width: ro.ui.relX(50),
         	right: ro.ui.relX(70),
         	text: 'Subtotal:',
         	textAlign: 'right'
         }));
         var subTotalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(5),
         	width: ro.ui.relX(60),
         	right: ro.ui.relX(10),
         	textAlign: 'right'
         }));
         var taxLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(20),
         	width: ro.ui.relX(50),
         	right: ro.ui.relX(70),
         	text: 'Tax:',
         	textAlign: 'right'
         }));
         var taxValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(20),
         	width: ro.ui.relX(60),
         	right: ro.ui.relX(10),
         	textAlign: 'right'
         }));
         var delFeeLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(35),
         	width: ro.ui.relX(90),
         	right: ro.ui.relX(120),
         	textAlign: 'right'
         }));
         var totalLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(35),
         	width: ro.ui.relX(50),
         	right: ro.ui.relX(70),
         	text: 'Total:',
         	textAlign: 'right'
         }));
         var totalValue = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
         	top: ro.ui.relY(35),
         	width: ro.ui.relX(60),
         	right: ro.ui.relX(10),
         	textAlign: 'right'
         }));



         totalsView.add(subTotalLbl);
         totalsView.add(subTotalValue);
         totalsView.add(taxLbl);
         totalsView.add(taxValue);
         totalsView.add(delFeeLbl);
         totalsView.add(totalLbl);
         totalsView.add(totalValue);
         itmTcktView.add(totalsView);

         function setVisibility(){
         	var show = false;
         	if(OrderObj.Items){
         		if(OrderObj.Items.length>0){
         			show = true;
         		}
         	}
         	if(show){
         		itemTable.show();
         		noItems.visible = false;
         	}
         	else{
         		itemTable.hide();
         		noItems.visible = true;
         		subTotalValue.text='$0.00';
         		taxValue.text='$0.00';
         		totalValue.text='$0.00';
         	}
         	return show;
         }

function showTicket(){

	if(OrderObj.ordOnlineOptions.IsDelivery){
		delFeeLbl.text = '( Dlvy Fee incl. )';
	}
	else{
		delFeeLbl.text = '';
	}
	tableData =[];
	var childLevel = 3;
	for (var count = 0; count < OrderObj.Items.length; count++) {
		var itemObj = OrderObj.Items[count];
		var section = Ti.UI.createTableViewSection();
		var mainRow = Ti.UI.createTableViewRow({
						height:Ti.UI.SIZE,
						className:'mainRow',
						backgroundSelectedColor:ro.ui.theme.tblRowSelected
		});

		var qtyTxt = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			 		 text: '' + itemObj.Qty,
			  		 width:ro.ui.relX(30),
			  		 height:ro.ui.relY(25),
			  		 left:0
		}));

		mainRow.add(qtyTxt);

		var itmName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			text:(itemObj.Size == 'None' ? '' : itemObj.Size + ' ') + (itemObj.Style ? itemObj.Style + ' ' : '') + ' ' + itemObj.RcptName,
			width:ro.ui.relX(160),
			height:ro.ui.relY(25),
			left:ro.ui.relX(40),
			textAlign:'left'
		}));

		mainRow.add(itmName);

		var itmPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
			text:(itemObj.ActivePrice == 0 ? '': '$' + itemObj.ActivePrice.toFixed(2)),
			right:ro.ui.relX(8),
			height:ro.ui.relY(25),
			width:ro.ui.relX(60),
			textAlign:'right'
		}));


		mainRow.add(itmPriceLbl);
		section.add(mainRow);

		var row, lbl, priceLbl;
      if(itemObj.PrfMbrs){
         for(var i=0; i<itemObj.PrfMbrs.length; i++){
             row = Ti.UI.createTableViewRow({
						height: ro.ui.relY(20),
						indentionLevel: childLevel,
						className: 'subRow',
						backgroundSelectedColor:ro.ui.theme.tblRowSelected
					});
             lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl,{text: itemObj.PrfMbrs[i].RcptName}));
             priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl,{text: (itemObj.PrfMbrs[i].ActivePrice == 0 ? '': '$' + itemObj.PrfMbrs[i].ActivePrice.toFixed(2))}));
             row.add(lbl);
             row.add(priceLbl);
             section.add(row);
         };
     }

        if (itemObj.NoMods) {

            for (var j = 0; j < itemObj.NoMods.length; j++) {
                var noModName;
                switch (itemObj.NoMods[j].HalfStatus) {
                    case 0:
                        noModName = 'NO ' + itemObj.NoMods[j].RcptName;
                        break;
                    case 1:
                        noModName = 'H1- ' + 'NO '+ itemObj.NoMods[j].RcptName;
                        break;
                    case 2:
                        noModName = 'H2- ' + 'NO ' + itemObj.NoMods[j].RcptName;
                        break;
                }
                row = Ti.UI.createTableViewRow({
							height: ro.ui.relY(20),
							indentionLevel: childLevel,
							className: 'subRow',
							backgroundSelectedColor:ro.ui.theme.tblRowSelected
						});
				lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl,{text: noModName}));
                priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl,{text:''}));
                row.add(lbl);
                row.add(priceLbl);
                section.add(row);

            };
                    }

        if (itemObj.Mods) {

            for (var k = 0; k < itemObj.Mods.length; k++) {
                var modName;
                switch (itemObj.Mods[k].HalfStatus) {
                    case 0:
                        modName = (itemObj.Mods[k].Qty > 1?'2X ':'') + itemObj.Mods[k].RcptName;
                        break;
                    case 1:
                        modName = 'H1-' + (itemObj.Mods[k].Qty > 1?' 2X ':' ') + itemObj.Mods[k].RcptName;
                        break;
                    case 2:
                        modName = 'H2-' + (itemObj.Mods[k].Qty > 1?' 2X ':' ') + itemObj.Mods[k].RcptName;
                        break;
                }

                row = Ti.UI.createTableViewRow({
							height: ro.ui.relY(20),
							indentionLevel: childLevel,
							className: 'subRow',
								backgroundSelectedColor:ro.ui.theme.tblRowSelected
						});
				lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktLbl,{text: modName}));
				 var price = '$' + itemObj.Mods[k].ActivePrice.toFixed(2);
                if (!(itemObj.Mods[k].ActivePrice) || itemObj.Mods[k].ActivePrice == 0) {
                    price = ' ';
                }
                priceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.tktPriceLbl,{text:price}));
                row.add(lbl);
                row.add(priceLbl);
                section.add(row);

            }
        }

		tableData.push(section);

	}
	if (OrderObj.Cpns){
		for (var cpnIdx=0;cpnIdx<OrderObj.Cpns.length;cpnIdx++){
			var cpnSection = Ti.UI.createTableViewSection();
        	var cpnRow = Ti.UI.createTableViewRow({
                        height:Ti.UI.SIZE,
                        className:'cpnRow',
                        	backgroundSelectedColor:ro.ui.theme.tblRowSelected
        	});

        	var cpnName = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName,{
            	text: '[' + OrderObj.Cpns[cpnIdx].RcptName + ']',
            	color:'red',
				width: ro.ui.relX(160),
				height: ro.ui.relY(25),
				left: ro.ui.relX(40),
				textAlign: 'left'
        	}));

    	    cpnRow.add(cpnName);

        	var cpnPriceLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.lblCart,{
            	text: '- ' + OrderObj.Cpns[cpnIdx].CpnActiveValue.toFixed(2),
            	color: 'red',
						textAlign: 'right',
						right: ro.ui.relX(8),
						height: ro.ui.relY(25),
						width: ro.ui.relX(60)
        	}));

        	cpnRow.add(cpnPriceLbl);
        	cpnSection.add(cpnRow);
			tableData.push(cpnSection);

		}
	}
	itemTable.data = tableData;
	subTotalValue.text = '$' + OrderObj.Subtotal.toFixed(2) ;
	taxValue.text =  '$' + OrderObj.Tax.toFixed(2);
	totalValue.text =  '$' + OrderObj.ActiveTotal.toFixed(2);

}

if (setVisibility()){
	showTicket();
}
  return mainView;
};
}
catch(ex){
	ro.ui.alert('Past order details error', 'Please try again.');
}
}());
