var PROFILEVIEW = function(){
	var profileview = function(ro){
	
	   var rs = {};
	   ro.ui.createProfileView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      var forms = ro.forms;
	      //Ti.include('/formControls/profileForm.js');
	      var profileForm = require('formControls/profileForm');
	      var regexVal = require('validation/regexValidation');
		  var profileVal = require('validation/profileValidation');
		  
	      rs = ro.db.getCustObj(Ti.App.Username);
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:profileForm.getProForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	      form.setFields(rs);
			//form.top = ro.ui.relY(10);
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'profile', hid:'profile'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Profile'}));
	         navBar.add(headerLbl);
	      } */
	
	      //var resetBtn = layoutHelper.getRightBtn('RESET');
	      var resetBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      resetBtn.addEventListener('click', function(e){
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         ro.GlobalPicker.hidePicker();
	         form.setFields(rs);
	      });
	
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      btnBack.addEventListener('click', function(e){
	      	ro.GlobalPicker.hidePicker(); 
	      	ro.ui.settingsShowNext({showing:'profile'});
	      });
	      navBar.add(btnBack);
	      navBar.add(resetBtn);
	
	      var btnUpdate = layoutHelper.getBigButton('Update');
	      //btnUpdate.top = ro.ui.relY(15);
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnUpdate);
		  
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         ro.GlobalPicker.hidePicker();
	         //Ti.include('/validation/profileValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         var ltyNoEclubChange = false;
	         var loyaltyChange = false;
	         if(doLoyalty){
	         	loyaltyChange = ro.REV_LOYALTY.didChange();
	         }
	         if(doLoyaltyNoEclub){
	         	ltyNoEclubChange = ro.REV_LOYALTY.didLtyNoEclubChange();
	         }
	
	         var success = profileVal.profileValidate(values, rs, loyaltyChange, ltyNoEclubChange);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	
	            	if(doLoyalty){
	            		ro.REV_LOYALTY.setRequestObject(values);
	            	}
	            	if(doLoyaltyNoEclub){
	            		ro.REV_LOYALTY.setRequestObjectNoEclub(values);
	            	}
	            	Ti.API.debug('values: ' + JSON.stringify(values));
	
	               /*if(rs.AddressCol && rs.AddressCol.length > 0){
	                  formRequest(values);
	               }
	               else{*/
	                  altFormRequest(values);
	               //}
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
			var Config = JSON.parse(Ti.App.Properties.getString('Config'));
			if(!Config){
				Config = {};
			}
			var Cst = JSON.parse(Ti.App.Properties.getString('Customer'));
			if(!Cst){
				Cst = {};
			}
	
	      ro.REV_LOYALTY.init();
	      var doLoyalty = ro.REV_LOYALTY.isEnabled();
	      var doLoyaltyNoEclub = ro.REV_LOYALTY.isLoyaltyNoEClubEnabled();
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "My Profile"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
			//top:isiphonex ? (ro.ui.relY(110) + 40) : ro.ui.relY(110),
			//var hdr = ro.layout.getGenericHdrRowWithHeader("My Profile");
			//hdr.top = ro.isiphonex ? (ro.ui.relY(110) + 40) : ro.ui.relY(110);
	      //mainView.add(hdr);
	      //form.
	      var hdr = ro.layout.getGenericHdrRowWithHeader("My Profile", true);
	      hdr.bottom = ro.ui.relY(10);
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      
	      mainView.add(form);
			form.bottom = ro.ui.relY(70);
			
			if(doLoyalty){
	            var LoyaltyView = ro.REV_LOYALTY.getNewLoyaltyView();
	            form.container.add(LoyaltyView);
	      	}
	      	if(doLoyaltyNoEclub){
	       	   /*var newLoyaltyWebView = Ti.UI.createView({
	          	  height:0,
	              width:Ti.UI.FILL
	           });
	           mainView.add(newLoyaltyWebView);*/
	
	           var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(/*newLoyaltyWebView*/);
	           form.container.add(newLoyaltyView);
	        }
			
			form.container.add(btnWrapper);

			if(ro.isiOS){
				var delProfileLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.settingsTxt, {text:'Delete Account'}));
				btnWrapper.bottom = ro.ui.relY(20);
				form.container.add(delProfileLbl);
				
				delProfileLbl.addEventListener('click', function(){
					try{
						ro.ui.showLoader();
						ro.ui.settingsShowNext({addView:true, showing:"delProfile"});
						ro.ui.hideLoader();
					}
					catch(ex){
						ro.ui.alert('Settings', 'Code:100');
					}
				});
			}
	
	      return mainView;
	   };
	
	   function formRequest(profileChanges){
	      var req = {};
	      try{
	         var addr = rs.AddressCol[0].StNum + ' ' + rs.AddressCol[0].St + ' ' + rs.AddressCol[0].City + ' ' + rs.AddressCol[0].State + ' ' + rs.AddressCol[0].Zip;//IF THERE IS NO SAVED ADDRESS THEN THIS WILL CAUSE ERROR
	         if(!Ti.Network.online){
	            return;
	         }
	         else{
	            var xhrGeocode = Ti.Network.createHTTPClient();
	            xhrGeocode.setTimeout(120000);
	
	            xhrGeocode.onload = function(e){
	               var response = JSON.parse(this.responseText);
	               Ti.API.info('response:' + JSON.stringify(response));
	               Ti.API.info('response:' + JSON.stringify(response));
	               if(response.status == 'OK' && response.results != undefined && response.results.length > 0){
	                  req.UserName = Ti.App.Username;
	                  req.Pass = Ti.App.Password;
	                  req.FName = profileChanges['firstname'];
	                  req.LName = profileChanges['lastname'];
	                  req.Title = profileChanges['title'];
	                  req.Phone = profileChanges['phone'];
	                  req.Ext = profileChanges['extension'];
	                  req.RevKey = 'test';
	                  if(!isNaN(profileChanges['EClubOptIn'])){
	                  	req.EClubOptIn = profileChanges['EClubOptIn'];
	                  }
	                  if(!isNaN(profileChanges['LtyOptIn'])){
	                  	req.LtyOptIn = profileChanges['LtyOptIn'];
	                  }
	                  contactServer(req);
	               }
	               else{
	                  ro.ui.hideLoader();
	                  ro.ui.alert('Could not verify address. Please try again.', 'Error');
	               }
	            };
	            xhrGeocode.onerror = function(e){
	               ro.ui.hideLoader();
	               return;
	            };
	            var url = "http://maps.google.com/maps/api/geocode/json?address=" + addr.replace(' ', '+');
	            url += "&sensor=" + (Ti.Geolocation.locationServicesEnabled === true);
	            xhrGeocode.open("GET", url);
	            xhrGeocode.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
	            xhrGeocode.send();
	         }
	      }
	      catch(e){
	         ro.ui.alert('Error: ', e);
	      }
	   }
	   function altFormRequest(profileChanges){
	      var req = {};
	
	      req.UserName = Ti.App.Username;
	      req.Pass = Ti.App.Password;
	      req.FName = profileChanges['firstname'];
	      req.LName = profileChanges['lastname'];
	      req.Title = profileChanges['title'];
	      req.Phone = profileChanges['phone'];
	      req.Ext = profileChanges['extension'];
	      req.RevKey = 'test';
	
	      if(!isNaN(profileChanges['EClubOptIn'])){
	      	req.EClubOptIn = profileChanges['EClubOptIn'];
	      }
	      if(!isNaN(profileChanges['LtyOptIn'])){
	      	req.LtyOptIn = profileChanges['LtyOptIn'];
	      }
	
	      contactServer(req);
	   }
	   function contactServer(req){
	
		  var response;
		  var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
		  if (savedTokenObj && savedTokenObj.token) {
				req.CustomerDevice = {};
				req.CustomerDevice.DeviceID = Ti.Platform.id;
				req.CustomerDevice.DeviceToken = savedTokenObj.token;
				req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
		   }
	      ro.dataservice.post(req, 'UpdateProfile', function(response){
	         if(response){
	            if(response.Value){
	               saveCustomer(req);
	               ro.ui.settingsShowNext({showing:'profile', resetOrder:true});
	            }
	            ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
	         }
	      });
	   }
	
	   function saveCustomer(reqCust){
	      var customr = JSON.parse(Ti.App.Properties.getString('Customer'));
	      if(!customr){
	         customr = {};
	      }
	      customr.Ext = reqCust.Ext;
	      customr.Title = reqCust.Title;
	      customr.FirstName = reqCust.FName;
	      customr.LastName = reqCust.LName;
	      customr.Phone = reqCust.Phone;
	      
	      if(!isNaN(reqCust.EClubOptIn)){
	         customr.EClubOptIn = reqCust.EClubOptIn;
	      }
	      if(!isNaN(reqCust.LtyOptIn)){
	         customr.LtyOptIn = reqCust.LtyOptIn;
	      }
	      Ti.App.Properties.setString('Customer', JSON.stringify(customr));
	      ro.db.updateCustomerObj(Ti.App.Username, customr);
	   };
	};
	return {
		profileview:profileview
	};
}();
module.exports = PROFILEVIEW;