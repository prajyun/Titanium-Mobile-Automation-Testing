var logoStyleBln = Ti.App.logoStyle;
var STYLE = function(){
	var style = function(ro){
		var osname = Ti.Platform.osname;
		var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;
		ro.isiOS = isiOS;
		
		function isIphoneX() {
			Ti.API.debug('Ti.Platform.displayCaps.platformWidth: ' + Ti.Platform.displayCaps.platformWidth);
			Ti.API.debug('Ti.Platform.displayCaps.platformHeight: ' + Ti.Platform.displayCaps.platformHeight);
			Ti.API.debug('Ti.Platform.displayCaps.logicalDensityFactor: ' + Ti.Platform.displayCaps.logicalDensityFactor);
			return ro.isiOS && (Ti.Platform.displayCaps.platformWidth >= 375 && Ti.Platform.displayCaps.platformHeight >= 812 && (Ti.Platform.displayCaps.logicalDensityFactor >= 2));
		}
		ro.isiphonex = isIphoneX();
		/*Ti.API.info('ro.isiphonex: ' + ro.isiphonex);
		Ti.API.info('ro.isiphonex: ' + ro.isiphonex);
		Ti.API.info('ro.isiphonex: ' + ro.isiphonex);
		Ti.API.info('ro.isiphonex: ' + ro.isiphonex);*/
	   //Ti.API.debug('ro.isiOS: ' + ro.isiOS);
	   var pWidth = Ti.Platform.displayCaps.platformWidth;
	   var pHeight = Ti.Platform.displayCaps.platformHeight;
	   var ldf = Ti.Platform.displayCaps.logicalDensityFactor;
	   //var logoStyleBln = Ti.App.logoStyle;
	   Ti.API.debug('logoStyleBln: ' + logoStyleBln);
	   Ti.API.debug('Ti.App.logoStyle: ' + Ti.App.logoStyle);
	   Ti.API.debug('ldf: ' + ldf);
	   
	   
		
		
	   	var isiphonex = isIphoneX();
		
		var relZ = function(obj){
			//return obj;
			return ldf == 3 || isiphonex ? (obj * (34/32)) : (29/32)*obj;
			//return ldf == 3 ? (isiphonex ? (obj * 34/32) : ((25/32) * obj)) : (ldf == 2 ? (25/32)*obj : (29/32)*obj);
		};
		var scaleFontiOS = function(obj){
			    return ldf < 3 && !isiphonex ? (((14/16)*obj) + 'dp') : (obj+'dp');
		};
	
	    ro.ui.fontFamily = ro.os({
	      iphone:'RobotoCondensed-Regular',
	      android:'RobotoCondensed-Regular'
	   });
	
	    ro.ui.displayCaps = !isiOS ? {
	      platformWidth:(pWidth > pHeight) ? pHeight : pWidth,
	      platformHeight:(pWidth > pHeight) ? pWidth : pHeight
	   } : {
	   	  platformWidth:pWidth,
	      platformHeight:pHeight
	   };
	   
	
		ro.ui.relParent = function(obj, parentOld, parentNew){
			return parentNew * (obj / parentOld) * (Ti.Platform.displayCaps.dpi / 240);
		};
	
		ro.ui.relY = !isiOS ? function(obj){
			return (ldf <= 1.5) ? (obj * (72/80) * ldf) : (obj * ldf);
			/*if(ldf <= 1.5){
				obj *= (72/80);
			}
			return obj * ldf;*/
		} : relZ;
		ro.ui.relXX = function(obj){
		   if(obj === 1){
		      return 1;
		   }
		   return (ldf <= 1.5) ? (obj * (72/80) * ldf) : (obj * ldf);
		};
		ro.ui.relX = !isiOS ? function(obj){
		   if(obj === 1){
		      return 1;
		   }
		   return (ldf <= 1.5) ? (obj * (72/80) * ldf) : (obj * ldf);
			/*if(ldf <= 1.5){
				obj *= (72/80);
			}
			return obj * ldf;*/
		} : relZ;
	
		ro.ui.Font = function(obj){
			return obj;
		};
		ro.ui.scaleFont = !isiOS ? function(obj, x, y){
			return (ldf <= 1.5) ? ((obj *= (72/80))+ 'dp') : (obj + 'dp'); 
			/*if(ldf <= 1.5){
				return (obj *= (72/80))+ 'dp';
			}
			else{
				return obj + 'dp';
			}*/
		} : scaleFontiOS;
		ro.ui.scaleFontY = !isiOS ? function(obj, y){
			if(ldf <= 1.5){
				return (obj *= (72/80))+ 'dp';
			}
			else{
				return obj + 'dp';
			}
		} : scaleFontiOS;
	
		contHeight = (357 / 320) * ro.ui.displayCaps.platformWidth;
		contTop = contHeight*.2;
		ro.ui.contentsTop = contTop;// * 1.33;
		ro.ui.halfContentsTop = .30 * contTop;
	
	    ro.ui.loginTop = ro.ui.contentsTop;
		ro.ui.platHeight = pHeight;
		var localImg = Ti.App.websiteURL+'/content/images/menu-item.png';
	
	   //Ti.API.debug('ro.ui.displayCaps: ' + JSON.stringify(ro.ui.displayCaps));
	   var lightBorder = '#e4e4e4';
       var bgTxt = '#393839';
       var bgTxtLight = '#393839';
       var loginLittle = '#534A4A'; // "Remember Me" on newLoginView
       var loginTitle = '#a70000';//'#393839'; //#e11a17';
       var noWhateversLbl = '#aba58f';
       
       var mainColor = '#fafafa';//HH
       var mainBorder = mainColor;//HH
       var mainTxt = '#FFFFFF';//HH
       var navBtnsColor = '#000000';
       
       var minorColor = '#a70000';//HH
       var minorBorder = minorColor;//HH
       var minorTxt = 'white';//HH
       
       var mainBtnColor = '#a70000';//'#eb0029';//'#e0d1ba';
       var mainBtnBorder = mainBtnColor;//'#ef0804';
       var mainBtnTxt = '#fbfaf6';//'#fbfaf6'
       
       var secondaryBtnColor = '#a70000';//'#ffcb05';//'#e0d1ba';
       var secondaryBtnBorder = secondaryBtnColor;//'#ef0804';
       var secondaryBtnTxt = '#fbfaf6';//'#fbfaf6'
       
       var loginBtnColor = '#a70000';//'#eb0029';
       var loginBtnBorder = loginBtnColor;
       
       var beginOrderBtnColor = minorColor;//'#eb0029';
       var beginOrderBtnBorder = beginOrderBtnColor;
       var beginNewOrderText = 'white';
       
       var hhRed = '#eb0029';
       var notHH = '#3cabf8';
       var repeatOrderButtonColor = '#555555'; //mainColor;
       var forgotPwTxtColor = notHH;//'red = #eb0029' or blue = #3cabf8
       
       var menuBorderColors = '#aaaaaa'; //'#bc0301';
       var clearBtnBg = 'white';
       var settingsBtnBg = clearBtnBg;
       var storeRowBg = clearBtnBg;
       var mediumBtnBg = clearBtnBg;
       var genericRowBg = clearBtnBg;
	   
	   //********* See 'lvlupBtnBg' for button on same page as Begin New Order **********
	   
	   var screenWidthDecimal = (ro.ui.relX(325) / ro.ui.displayCaps.platformWidth);
	   
	   var screenWidthPct = ((parseFloat(screenWidthDecimal) * 100) / 100).toFixed(2);
	   
	   var wideViewWidth = ro.ui.displayCaps.platformWidth * .92;//.888671875;
	   
	   var GarageGothic_Black = ro.isiOS ? 'GarageGothic-Black' : 'GarageGothic Black.otf';
	   var GarageGothic_Bold = ro.isiOS ? 'GarageGothic-Bold' : 'GarageGothic Bold.otf';
	   var GarageGothic_Regular = ro.isiOS ? 'GarageGothic-Regular' : 'GarageGothic Regular.otf';
	   
	   var GothamBold = ro.isiOS ? 'Gotham-Bold' : 'Gotham-Bold.otf';
	   
	   var GothamMedium = ro.isiOS ? 'Gotham-Medium' : 'Gotham-Medium.otf';
	   var GothamBook = ro.isiOS ? 'Gotham-Book' : 'Gotham-Book.otf';
	   var GothamBookItalic = ro.isiOS ? 'Gotham-BookItalic' : 'Gotham-BookItalic.otf';
	   var GothamLight = ro.isiOS ? 'Gotham-Light' : 'Gotham-Light.otf';
	   
	   ro.ui.fontTest = {
	   	  GarageGothic:{
	   	  	black:GarageGothic_Black,
	   	  	bold:GarageGothic_Bold,
	   	  	regular:GarageGothic_Regular
	   	  },
	   	  Gotham:{
	   	  	bold:GothamBold,
	   	  	medium:GothamMedium,
	   	  	light:GothamLight
	   	  }
	   };	   
	   
		ro.ui.fonts = {
			//default:'',
			fontFamily:ro.ui.fontFamily,
			//test:'GothamBold',
			alerts:{
				title:GarageGothic_Bold,
				body:GothamBook
			},
			hugeTitles: GarageGothic_Black,
			titles:GarageGothic_Bold,
			orderTrackerBold:GarageGothic_Bold,
			orderTrackerNormal:GarageGothic_Regular,
			button:GarageGothic_Bold,
			notBoldButton:GarageGothic_Regular,
			settingsButton:GothamMedium,
			prices:{
				italic:GothamBookItalic,
				normal:GothamBook,//UNCONFIRMED
				newItemsView:GarageGothic_Bold
			},
			tabs:{
				//on:GothamMedium,
				on:GothamMedium,
				off:GothamBook
			},
			rewardsBubble:GothamBold,
			navBtns:GothamBook,
			policyText:GothamMedium,
			policyLink:GothamBookItalic,
			rowBodyTxt:GothamBook,
			rowHdrTxt:GothamMedium,
			storeStatusText:GothamMedium,
			textFields:GothamBook
			//rowDisclaimerTxt:
			
		};
		
		
	   
	   	ro.ui.font = {
	   		pathToMenuTitles:{
	   			fontSize: ro.ui.scaleFont(28),
            	fontFamily: ro.ui.fonts.titles
	   		}
	   	};
	   
		ro.ui.theme = {
			minorColor: minorColor,
			repeatOrderBtnTxt: 'white',
			repeatOrderButtonColor: repeatOrderButtonColor,
			bottomNavTabTxt:minorColor,
			popupHdrTxt:'#eb0029',
			popupMsgTxt:'#393839',
			storeSelectionBodyTxt:'#393839',
			storeSelectionHdrTxt:'#393839',
			settingsBtnBorder:'#e4e4e4',
			settingsBtnTxt:'#393839',
		
		   jetsdemo:menuBorderColors,
		   bannerImg:true,
		   menuItemImg:localImg,//Ti.App.websiteURL+'/content/images/menu-item.png',//'/images/menu-item.png',
	
		   nonPendingPointsTxt:mainTxt,
		   pendingPointsTxt:'white',//#006700
		   newAcctBtn:'#999999',
		   newAcctBtnTxt:'#eeece6',
		   newAcctArea:'#eeece6',
		   newAcctAreaTxt:'#999999',
		   
		   contentsTextColor:'#534A4A',              //Text color for contents.png
		   contentsSmallTxt:'black',					 //ContentsSmall.png text and the style below
		   textColor:'black',						    //All contentsSmall.png text that is not any of the styles below
		   totalLblCartColor:bgTxt,            //The totals subview at the bottom of the cart...text color
		   couponsViewTxtColor:bgTxt,
		   backgroundpngTxt:bgTxt,
		   noOptionsTxt:bgTxt,
	
		   btnTextColor:'black',						 //TextColor on the Buttons
		   grpItemColor:bgTxt,				       //This is the grpItem titles text && all the different modifiers/sizes/styles text in itemDetails
	       grpHeaderColor:'black',      			    //Menu Item Customization steps text - (Once group and item is chosen then the itemsDetailsView screen appears  --  This is the steps near the top of the screen)
		   contentsSmallTxtHead:'black',			 //ContentsSmall.png Text Titles/headers (#7C0000 is the maroonish color)
		   settingsHdrs:'#534A4A',			          //All form textField titles - These all appear on BACKGROUND.PNG - (newAccount, Add/Change Address and Credit Cards, Change Username, Change Password, Change Profile, Use GiftCard)
		   forgotPassHdrs:'#eb0029',
		   newGroupsBtnTxt:'#393839',            //used to be darkerGray
		   
		   specialInstructionBlue:'blue',				//Order Item Notes text color (cart.js)
		   orderItemNoteTxtItemDetailsView:'#eb0029',  		//"Click to add special instructions" text color (itemDetailsView.js)
		   
		   //newPayHeaderBackgroundColor:'#e11a17',					 //Background Color for Header Labels background on contensSmall.png - (NewPaymentView - 4 headers on this screen)
		   //newPayHeaderTitleTxt:'white',//'#C1AD60',           //Textcolor for Header Labels text on contentsSmall.png - (NewPaymentView - 4 headers on this screen)
		   
		   futureOrderTxt:bgTxt,
	      formsJsHeadersTxt:bgTxt,		        //Forgot Password Label text
	      orderTypeBgTxt:bgTxt,                  //Same as formsJsHeadersTxt usually..since they both are texts on background.png
	      
	      honeycombRewardSquare:minorColor,
	      honeycombRewardSquareTxt:'white',
	      honeycombProgressFiller:minorColor,
	      honeycombRuleSquare:'#eeece6',
	      honeycombRuleSquareTxt:'#393839',
	
	      headerBackgroundColor:mainBtnColor,//f2243b//'#eb0029',			 			//Background Color for Header Labels on tables.
	      headerBorderColor:mainBtnBorder,//'#B21210'							//Border Color for same Headers as above.
	      headerTitleTxt:mainBtnTxt,//'white',				       			//Text Color for same Headers as above.
	      tableBgColor:'white',
	      menuTableBgColor:'white',
	      
	      bottomNavbarBackgroundColor:mainColor,//'#e11a17',         //Top Appwide NavBar background color
	      bottomNavbarBorderColor:mainBorder,//'#e11a17',          //Top Appwide NavBar border color
	
	      navbarTxtColor:mainTxt,//'#F99B24',									//Text color for Top Appwide navBar where the background color is determined in the property below
	      navbarBackgroundColor:mainColor,//f2243b//'#e11a17',		   //Top Appwide NavBar background color
	      navbarBorderColor:mainBorder,//'#e11a17',	         //Top Appwide NavBar border color
	      btnTxtActive:mainTxt,//'#f2b300',					   //Top Appwide NavBar Btn Text Color
	      navBtns:navBtnsColor,//'#f2b300'					         //Top Appwide NavBar Btn Text Color
	
	      loginLittleTxt:loginLittle,//f2243b //'#534A4A',
	
			beginNewOrderBackground:beginOrderBtnColor,//'#744c41', //f2243b
			beginNewOrderBorder:beginOrderBtnBorder,//'#744c41',
			beginNewOrderText:beginNewOrderText,
	
			//MENU CONTROLS CSS		//MENU CONTROLS CSS		//MENU CONTROLS CSS		//MENU CONTROLS CSS
	
			sizeBtnBlockBgActive:minorColor,  //f2243b
			sizeBtnBlockBgDefault:'#eeece6',
			sizeBtnBlockTxtActive:'white',				//SizeBlock ALL text color ACTIVE for both texts below
			sizeBtnBlockNameTxtDefault:'#393839',			//SizeBlock SIZE NAME text NOT SELECTED
			sizeBtnBlockPriceTxtDefault:minorColor,		//f2243b //SizeBlock SIZE PRICE text NOT SELECTED
	
			newextraQtyBackgroundDefault:'transparent',
			newextraQtyBackgroundActive:minorColor,  //f2243b
			newextraQtyTxtActive:'white',
			newextraQtyTxtDefault:'#666', //f2243b
			newextraQtyBorder:'#e4e4e4', //f2243b
			
	      extraQtyBorder:minorColor, //f2243b
	      extraQtyBackgroundActive:minorColor,  //f2243b
	      extraQtyTxtActive:'white',
	      extraQtyBackgroundDefault:'white',
	      extraQtyTxtDefault:minorColor, //f2243b
	
			//MENU CONTROLS CSS		//MENU CONTROLS CSS		//MENU CONTROLS CSS		//MENU CONTROLS CSS
	
	      cpnRowTileColor:'transparent',
	      itemDetailsDescriptionTxt:bgTxt,     //itemDetailsView Item Name and Description text.
	
			editBtnActive:minorColor,//f2243b					//Edit Items button on couponSelectionView
			editTxtActive:'white',						//Edit Items button text on couponSelectionView
			editBtnDefault:'#ABA58F',
			editTxtDefault:'white',
	
			menuBtnBackground:'white',
			menuAddItemBackground:minorColor,//f2243b
			menuAddItemBorder:'black',             //Was btnBorderActive:'#ed7270' before I made its own style name
			menuAddItemText:'white',
			menuOtherBtnTxt:'#ABA58F',              //USED TO BE ro.ui.theme.loginGray
	
	      txtFldBg:'white',								//All textField Background Color
	      txtFldBrd:'#e4e4e4',							//All textField Border Color
      	  txtFldTxt:'#393839',							//All textField Text Color
		  txtFldHintTxt:'#989898',
	
			tipBorder:'#ABA58F',
	
			tipTxt:'black',
			tipBg:'transparent',
			tipTxtSel:'black',
			tipBgSel:'#AF181C',
			
			toptbBg:'#fff',									//All non-image tabs backgroundColor
	      toptbSelBg:minorColor,							//All non-image tabs selected background color
	      toptbBrd:"#e4e4e4",								//All non-image tabs border color
	      toptbTxt:'#393839',								//All non-image tabs text color
	      toptbSelTxt:'#fff',
	      tbBg:'#fff',									//All non-image tabs backgroundColor
	      tbSelBg:'#534A4A',							//All non-image tabs selected background color
	      tbBrd:'#ABA58F',								//All non-image tabs border color
	      tbTxt:'#ABA58F',								//All non-image tabs text color
	      tbSelTxt:'#fff',								//All non-image tabs selected text color
	
	      btnSel:minorColor,
	      btnBg:'#eeece6',
	
			prefHdrTxtClr:'black',						//Header text color for preference types on prefs.js
			prefBoxBorderClr:'gray',
			
			ewomTxtLbl:bgTxtLight,
			privacyPolicyTxtLbl:bgTxtLight,
	
	
	//		BIG BUTTONS LIKE LOGIN AND SUBMIT
	     
		bigBtnSecondaryTxt:secondaryBtnTxt,
		bigBtnSecondaryBackground:secondaryBtnColor,
		bigBtnSecondaryBorder:secondaryBtnBorder,
		
		ordTypeButtonColor:'#ffcf00',
		ordTypeBtnTxt:'white',
		
      guestOrderBtnBackground:loginBtnColor,
      guestOrderBtnBorder:loginBtnBorder,
      guestOrderBtnTxt:mainBtnTxt,

		loginBtnWhite:beginNewOrderText,//mainBtnTxt //This is the text color for button below
		bigBtnTxt:mainBtnTxt,//This is all the buttons that look like login btn ... except login btn...rule of thumb this should usually be the same color as the loginBtnBackground

		ordTrackerBtnBackground:'white',		//This is many things not just login button but it seems they all should change together
		loginBtnBackground:loginBtnColor,		//This is many things not just login button but it seems they all should change together
		bigBtnBackground:mainBtnColor,			//This is all the buttons that look like login btn ... except login btn...rule of thumb this should usually be the same color as the loginBtnBackground

		ordTrackerBtnBorder:lightBorder,//'#AF181C',
		loginBtnBorder:loginBtnBorder,//'#AF181C',
		bigBtnBorder:mainBtnBorder,//'#AF181C',//This is all the buttons that look like login btn ... except login btn...rule of thumb this should usually be the same color as the loginBtnBorder
//		BIG BUTTONS LIKE LOGIN AND SUBMIT
	
	
			loginTitleTxt:loginTitle,//bgTxt or minorColor
	
			lvlupBtnBg: '#71CB3A',//'#008fd2',  //"Scan for Points, Level Up, Etc.."   green = '#71CB3A', some type of blue #005c60
			lvlupCreditTxt:'#AF181C',
			lvlupHistoryTxt:'black',
			lvlupHistoryDetailsBg:'transparent',
			lvlupHistoryBg:'transparent',
	
			loginGray:'#999999',
	      btnDefault:'#eeece6',
	      btnBorderDefault:'#e4e4e4',
	      btnActive:'#FF0000',
	      btnBorderActive:'#e51734',
	      btnTxtDefault:'#666',
	
	      darkerGray:'#534A4A',
	
	      pickerColor:'#534A4A',
	      txtFieldInput:'black',						//All textField text colors - Likely will never need changing
		   txtFieldBrdrClr:'black',					//All textField border colors - Likely will never need changing
		   cpnColor:'#eb0029',								//Color of coupons added not the coupons on the menu - (cartScreen, pastOrder Detatils...etc...)
		   forgotPwTxt:forgotPwTxtColor,//'red = #eb0029'	//blue = #3cabf8	 //Text on login screen forgot password label
	
	      custAlertTxt:'white',						//Generally these are never changed
	      barColor:'#6BCEA1',							//Generally these are never changed
	      tblRowSelected:'#c56648',					//Generally these are never changed
	      separatorColor:'#eeece6',					//Generally these are never changed
	      separatorColorMenuTypeOne:'#eeece6',      //Generally these are never changed, this is for newGrpsItems MenuLayout==1, the side by side layout
	      rewardRulesCampaignColor:minorColor,     
	
	      contentsFont:{
	         fontSize:ro.ui.scaleFont(10,0,0),
	         fontFamily:ro.ui.fontFamily
	      },
	      titleFont:{
	         fontWeight:'bold',
	         fontSize:ro.ui.scaleFont(11.5,0,0),
	         fontFamily:ro.ui.fontFamily
	      },
	      paymentFont:{
	         fontFamily:ro.ui.fontFamily,
	         fontSize:ro.ui.scaleFont(11.5, 90, 30)
	      },
	      titleFontFT:{//titleFont FT=fourteen mods_new.js
	         fontWeight:'bold',
	         fontSize:ro.ui.scaleFont(14,0,0),
	         fontFamily:ro.ui.fontFamily
	      },
	      menuItemRowColors:{ //Menu items row background/foreground
	          background: '#f6f6f6', //#f6f6f6
	          altBackground: '#ffffff',
	          priceColor: '#555555', // Previously #999999 //Default Value (HH Gray = #b5b5b5',)
	          altPriceColor: '#555555', // Previously #999999 //Default Value (HH Gray = #b5b5b5',)
	          titleColor: '#393839',
              altTitleColor: '#393839'
	          
	      },
	      circleViewColors:{
	          background: '#e4e4e4',//#e4e4e4
	          altBackground: '#f6f6f6', //#f6f6f6
	          transparent: 'transparent'
	      },
	      itemPriceColor: '#eb0029'
	   };
		var ldfBool = ((ldf>=2)?true:false);
		ro.ui.properties = {
			wideViewWidth:wideViewWidth,
			isiPhoneX:isiphonex,
		   ldfBool:ldfBool,
			defaultPath:'/images/',
			defaultImgPath:'/images/default.png',
			defaultIconPath:'/icons/',
			platformWidth:ro.ui.displayCaps.platformWidth,
			platformHeight:ro.ui.displayCaps.platformHeight,
			menuRowHeight:ro.ui.relY(80),
			topAfterNavbar:(ro.ui.displayCaps.platformHeight * .15) + ro.ui.relY(5),
			plHeight:pHeight,
			plWidth:pWidth,
			devDpi:Ti.Platform.displayCaps.dpi,
			Window:{
				backgroundImage:'/images/backgroundImg.png',
				//backgroundColor:'#ffffff',
				//navBarHidden:true,
				windowSoftInputMode:!ro.isiOS ? Ti.UI.Android.SOFT_INPUT_ADJUST_PAN : null
			},
			defaultContents:{
				fontSize:ro.ui.scaleFont(9,0,0),
				fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
			},
	      contentsView:{
	
	      },
	      contentsViewLow:{
	         //backgroundImage:'/images/contents.png',
	         top:ro.ui.relY(60),
	         bottom:ro.ui.relY(60),
	         right:ro.ui.relX(9),
	         left:ro.ui.relX(9)
	      },
	      contentsViewHigh:{
	         //backgroundImage:'/images/contents.png',
	         itemTop:ro.ui.relY(65),//65
	         altItemTop:ro.ui.relY(85),
	         width:(302 / 320) * ro.ui.displayCaps.platformWidth,
	         height:(357 / 320) * ro.ui.displayCaps.platformWidth
	      },
			contentsSmallView:{
				//backgroundImage:'/images/contents_small.png',
				left:ro.ui.relX(5),
				right:ro.ui.relX(5),
				top:ro.ui.relY(130),
				bottom:ro.ui.relY(55)
			},
			couponSelectionView:{
			   height:Ti.UI.FILL,
			   layout:'vertical',
			   top:0,
	         bottom:ro.ui.relY(45)
	      },
			contentsTblView:{
				top:ro.ui.relY(75),
				left:ro.ui.relX(10),
				right:ro.ui.relX(10),
				bottom:ro.ui.relY(12),
				separatorColor:ro.ui.theme.separatorColor,
				backgroundColor:'white'
			},
			contentsSmallTblView:{
				top:ro.ui.relY(7),
				left:ro.ui.relX(10),
				right:ro.ui.relX(10),
				bottom:ro.ui.relY(10),
	         	backgroundColor:'white'
			},
			creditListScrollView:{
			   top:ro.ui.relY(20),
	         bottom:ro.ui.relY(105),
	         right:ro.ui.relX(9),
	         left:ro.ui.relX(9)
			},
			loginLbl:{
	    		width:(90 / 320) * pWidth,
	         height:(30 / 320) * pWidth,
	    		left:ro.ui.relX(5),
	    		font:ro.ui.theme.titleFont,
	    		color:ro.ui.theme.contentsTextColor
			},
			loginTxtField:{
	    		height:(30 / 320) * pWidth,
	         width:(175 / 320) * pWidth,
	    		right:ro.ui.relX(5),
	    		font:ro.ui.theme.contentsFont,
	    		borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED
			},
			ordType:{
	         width:ro.ui.relX(200),
	         height:ro.ui.relY(25),
	         top:ro.ui.relY(80),
	         left:ro.ui.relX(20)
	      },
			lblStoreDetails:{
				left:ro.ui.relX(15),
				font:{
				   fontSize:ro.ui.scaleFontY(11, 13),
					fontFamily:ro.ui.fontFamily
				},
				height:ro.ui.relY(13),
	         color:ro.ui.theme.contentsTextColor
			},
			lblStoreName:{
				left:ro.ui.relX(15),
				height:Ti.UI.SIZE,
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFontY(11.5, 14),
				   fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.contentsTextColor
			},
			newItemsDetails:{
				left:ro.ui.relX(10),
				font:{
				   fontSize:ro.ui.scaleFontY(11, 13),
					fontFamily:ro.ui.fontFamily
				},
				height:ro.ui.relY(13),
	         color:ro.ui.theme.contentsTextColor
			},
			newItemsName:{
				left:ro.ui.relX(10),
				height:Ti.UI.SIZE,
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFontY(11.5, 14),
				   fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.contentsTextColor
			},
			lblCart:{
				height:ro.ui.relY(15),
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFontY(11, 14),
				   fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.textColor
			},
			newLblCartTtlsLbls:{
				height:ro.ui.relY(25),
		        font:{
		            //fontWeight:'bold',
		            fontSize:ro.ui.scaleFont(16, 14),
		            fontFamily:ro.ui.fonts.rowBodyTxt
		         },
		       color:'#393839',
			   top:ro.ui.relY(5),
			   width:ro.ui.relX(110),
			   right:ro.ui.relX(90),			   
			   textAlign:'left'
			},
			newLblCartValuesLbls:{
			   height:ro.ui.relY(25),
		       font:{
		       	  //fontWeight:'bold',
		          fontSize:ro.ui.scaleFont(16, 14),
		          fontFamily:ro.ui.fonts.rowBodyTxt
		       },
		       color:'#393839',
			   width:ro.ui.relX(70),
			   right:ro.ui.relX(10),
			   textAlign:'right'
			},
			lblCartTtls:{
			   height:ro.ui.relY(15),
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFontY(11, 14),
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.totalLblCartColor
			},
			openLbl:{
				right:0,
				height:ro.ui.relY(16),
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFontY(10, 45, 16),
				   fontFamily:ro.ui.fontFamily
				},
				width:ro.ui.relX(45),
				textAlign:'right',
	         color:ro.ui.theme.contentsTextColor
			},
			hrsView:{
				borderWidth:3,
				borderColor:'green',
				right:ro.ui.relX(5),
				width:ro.ui.relX(100)
				//bottom:ro.ui.relY(5)
			},
			imgView:{
				height:ro.ui.relX(16),
				width:ro.ui.relX(16)
			},
			defaultStoreTblView:{
				top:ro.ui.relY(10),
				backgroundColor:'#ffffff',
				rowBackgroundColor:'#fff',
				left:ro.ui.relX(10),
				right:ro.ui.relX(10),
				separatorColor:'transparent',
				borderWidth:ro.ui.relY(2),
				borderColor:ro.ui.theme.txtFldBrd,
				borderRadius:ro.ui.relY(10)
			},
			animationDuration:500,//500
			stretch:{
				top:0,
				bottom:0,
				left:0,
				right:0
			},
			backBtn:{
				font:{
				   fontSize:ro.ui.scaleFont(11, 68, 32),
				   fontWeight:'bold',
					fontFamily:ro.ui.fontFamily
				},
				textAlign:'left',
				width:ro.ui.relX(78),//68
				height:ro.ui.relY(35),//32
				title:'Back',
				//backgroundImage:'/images/forward.png',
				//backgroundSelectedImage:'/images/forwardPress.png',
				left:ro.ui.relX(13)//5
				//color:ro.ui.theme.btnTxtActive
			},
			logoutBtn:{
				font:{
				   fontSize:ro.ui.scaleFont(11, 68, 32),
				   fontWeight:'bold',
				   fontFamily:ro.ui.fontFamily
				},
				width:ro.ui.relX(78),//68
				height:ro.ui.relY(32),//32
				title:'Logout',
				//backgroundImage:'/images/logout.png',
				//backgroundSelectedImage:'/images/logoutPress.png',
				right:ro.ui.relX(5)//5
				//color:ro.ui.theme.btnTxtActive
			},
			navRightBtn:{
	         font:{
	            fontSize:ro.ui.scaleFont(11, 68, 32),
	            fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
	         },
	         width:ro.ui.relX(68),
	         height:ro.ui.relY(32),
	         //backgroundImage:'/images/forward.png',
	         //backgroundSelectedImage:'/images/forwardPress.png',
	         right:ro.ui.relX(5),
	         color:ro.ui.theme.navBtns
	      },
			couponBtn:{
				font:{
				   fontSize:ro.ui.scaleFont(11, 68, 32),
				   fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
				},
				width:ro.ui.relX(68),
				height:ro.ui.relY(32),
				title:'Logout',
				backgroundImage:'/images/logout.png',
				backgroundSelectedImage:'/images/logoutPress.png',
				color:'#fff'
			},
			midBtn:{
				font:{
				   fontSize:ro.ui.scaleFont(11, 65, 25),
				fontFamily:ro.ui.fontFamily
				},
				width:ro.ui.relX(65),
				height:ro.ui.relY(25),
			},
			iosxNavParent:{
				top:0,
				height:(.5 * .30 * ro.ui.displayCaps.platformHeight),
				width:Ti.UI.FILL,
				backgroundColor:'transparent',
				//backgroundColor:ro.ui.theme.navbarBackgroundColor,
				layout:'vertical'
			},
			iosxTopNav:{
				height:.2 * (.5 * .30 * ro.ui.displayCaps.platformHeight),
				width:Ti.UI.FILL,
				backgroundColor:ro.ui.theme.navbarBackgroundColor
				//backgroundImage:'/images/loginBannerReflection.png'
			},
			iosxBottomNav:{
				height:.8 * (.5 * .30 * ro.ui.displayCaps.platformHeight),
				width:Ti.UI.FILL,
				backgroundColor:ro.ui.theme.navbarBackgroundColor
			},
			navBar:{
				left:0,
				top:0,
				width:ro.ui.displayCaps.platformWidth,
				height:logoStyleBln ? ro.ui.relY(35) : (isiphonex ? (.5 * .30 * ro.ui.displayCaps.platformHeight) : (.5 * .30 * ro.ui.displayCaps.platformHeight)),
				backgroundColor:ro.ui.theme.navbarBackgroundColor,
				//backgroundImage:'/images/loginBanner.png',
				borderColor:ro.ui.theme.navbarBorderColor,//'transparent',
				borderWidth:ro.ui.relX(1)
			},
			largeNavBar:{ //Background behind the logo on the login screen
				left:0,
				top:0,
				width:ro.ui.displayCaps.platformWidth,
				height:logoStyleBln ? ro.ui.relY(35) : (.28*ro.ui.displayCaps.platformHeight)/*ro.ui.relY(129)*/,
				backgroundColor:ro.ui.theme.navbarBackgroundColor,
				//backgroundImage:'/images/loginBanner.png',
				//borderColor:ro.ui.theme.navbarBorderColor,
				//borderWidth:ro.ui.relX(1)
			},
			navBarParent:{
				left:0,
				top:0,
				width:ro.ui.displayCaps.platformWidth,
				height:ro.ui.relY(55),
				backgroundColor:'transparent',
				borderWidth:ro.ui.relX(1)
			},
			bottomNavBar:{
				left:0,
				bottom:0,
				width:ro.ui.displayCaps.platformWidth,
				height:ro.ui.relY(49),
				backgroundColor:ro.ui.theme.bottomNavbarBackgroundColor,
				borderWidth:ro.ui.relX(1),
				borderColor:ro.ui.theme.bottomNavbarBorderColor
			},
			tktLbl:{
				left:ro.ui.relX(50),
	         height:ro.ui.relY(15),
	         width:ro.ui.relX(160),
	         font:{
	            fontSize:ro.ui.scaleFont(11, 160, 15),
				   fontFamily:ro.ui.fontFamily
	         },
	         top:0,
	         textAlign:'left',
	         color:ro.ui.theme.textColor
	      },
			tktPriceLbl:{
				right:ro.ui.relX(8),
	         height:ro.ui.relY(15),
	         width:ro.ui.relX(60),
	         font:{
	            fontSize:ro.ui.scaleFont(11, 60, 15),
				fontFamily:ro.ui.fontFamily
	         },
	         textAlign:'right',
	         top:0,
				color:ro.ui.theme.textColor
			},
			paymentLbl:{
				width:ro.ui.relX(60),
				height:ro.ui.relY(30),
				left:ro.ui.relX(15),
				font:{
				   fontWeight:'bold',
				   fontSize:ro.ui.scaleFont(11.5, 60, 30),
				   fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.textColor
			},
			newPayHdr:{
			   left:ro.ui.relX(15),
	         top:ro.ui.relY(5),
	         height:ro.ui.relY(25),
	         font:{
	            fontSize:ro.ui.scaleFont(14,0,0),
	            fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.darkerGray
			},
			newPayTxt:{
			   left:ro.ui.relX(15),
	         top:ro.ui.relY(5),
	         height:ro.ui.relY(25),
	         font:{
	            fontSize:ro.ui.scaleFont(12,0,0),
	            fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.contentsSmallTxt
			},
			headerLbl:{
				textAlign:'center',
				font:{
					fontSize:ro.ui.scaleFont(13, 120, 49),
					//fontWeight:'bold',
					fontFamily:ro.ui.fontFamily
				},
				color:ro.ui.theme.navbarTxtColor,
				width:ro.ui.relX(120)
			},
			noHeaderLbl:{
	         textAlign:'center',
	         font:{
	            fontSize:ro.ui.scaleFont(16, 120, 49),
	            //fontWeight:'bold',
				fontFamily:ro.ui.fonts.rowHdrTxt
	         },
	         color:ro.ui.theme.backgroundpngTxt,
	         width:wideViewWidth,
	         top:ro.ui.relY(100)
	      	},
			settingsTxt:{
				textAlign:'center',
				font:{
					fontSize:ro.ui.scaleFont(16, 120, 49),
					fontFamily:ro.ui.fonts.policyLink
				},
				color: ro.ui.theme.loginBtnBackground,
				width:wideViewWidth,
				top:ro.ui.relY(22),
				height: Ti.UI.SIZE,
				bottom: ro.ui.relY(22)
			},
			proView:{
			   borderColor:ro.ui.theme.loginGray,
	         borderWidth:ro.ui.relX(1),
	         width:ro.ui.relX(80),
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFontY(11,14),
	            fontFamily:ro.ui.fontFamily
	         }
	      },
	      proViewTxt:{
	         width: ro.ui.relX(170),
	         height:ro.ui.relY(50),
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFontY(11,14),
	            fontFamily:ro.ui.fontFamily
	         },
	         right:ro.ui.relX(10),
	         keyboardType:Ti.UI.KEYBOARD_TYPE_DEFAULT,
	         returnKeyType:Ti.UI.RETURNKEY_DONE
	      },
	      myAccountView:{
	      	contentWidth:Ti.UI.FILL,
	      	 disableBounce:ro.isiOS ? true : false,
	         width:wideViewWidth,
//	         top:isiphonex ? (ro.ui.relY(100) + 40) : ro.ui.relY(110),
	         top:(.5 * .30 * ro.ui.displayCaps.platformHeight) + ro.ui.relX(15),
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFontY(13, 14),
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.settingsHdrs
	      },
	      spclInst:{
	         scrollType:'vertical',
	         left:ro.ui.relX(8),
	         right:ro.ui.relX(8),
	         height:Ti.UI.SIZE,
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFontY(13, 14),
	            fontFamily:ro.ui.fontFamily
	         },
	         color:ro.ui.theme.contentsSmallTxt
	      },
	      dbListView:{//creditCard List and AddressList
	         width:ro.ui.relX(300),
	         height:ro.ui.relY(350),
	         bottom:ro.ui.relY(90),
	         top:ro.ui.relY(20)
	      },
	      defaultListView:{//creditCard List and AddressList
	         width:ro.ui.relX(300),
	         height:Ti.UI.SIZE,
	         top:ro.ui.relY(30)
	      },
	      settingsTbl:{
	         width:ro.ui.relX(300),
	         bottom:ro.ui.relY(65),
	         top:ro.ui.relY(60),
	         backgroundColor:'white'
	      },
	      defaultSwitch:{
	         value:false,
	         style:!ro.isiOS ? Ti.UI.Android.SWITCH_STYLE_CHECKBOX : null,
	         borderWidth:ro.ui.relX(1),
	         //borderColor:ro.ui.theme.loginGray,
	         //backgroundColor:'#e8e8e8',
	         textAlign:'left',
	         //width:ro.ui.relX(300),
	         color:ro.ui.theme.formsJsHeadersTxt,
	         font:{
	            fontSize:ro.ui.scaleFont(12.5, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }//,
	         //height:Ti.UI.SIZE,
	         //width:Ti.UI.SIZE
	      },
	      defaultEwomSwitch:{
	         value:false,
	         style:!ro.isiOS ? Ti.UI.Android.SWITCH_STYLE_CHECKBOX : null,
	         borderWidth:ro.ui.relX(1),
	         //borderColor:ro.ui.theme.loginGray,
	         //backgroundColor:'#A0B527',//'#f8f8f8',
	         textAlign:'left',
	         //width:ro.ui.relX(300),
	         color:'black',
	         font:{
	            fontSize:ro.ui.scaleFont(12.5, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         },
	         height:Ti.UI.SIZE,
	         width:Ti.UI.SIZE
	      },
	      ccDateStyle:{
	         width:ro.ui.relX(200),
	         right:ro.ui.relX(10),
	         height:ro.ui.relY(30),
	         borderColor:'#888',
	         borderRadius:6,
	         borderWidth:1,
	         backgroundColor:'#fff',
	         color:ro.ui.theme.textColor,
	         font:ro.ui.theme.paymentFont
	      },
	      chosenStoreStyle:{
	         height:ro.ui.relY(85)
	      },
	      /*newPayHeaderView:{
	         backgroundColor:ro.ui.theme.newPayHeaderBackgroundColor,
	         width:Ti.UI.FILL,
	         height:ro.ui.relY(25)
	      },*/
	      headerView:{
	         backgroundColor:ro.ui.theme.headerBackgroundColor,
	         width:Ti.UI.FILL,
	         height:ro.ui.relY(35),
	         borderColor:ro.ui.theme.headerBorderColor,
	         borderWidth:ro.ui.relX(1)
	      },
	      headerTitleBg:{
      		 textAlign:'center',
	      	 top:ro.ui.relY(15),
        	  height:Ti.UI.SIZE,
	          width:Ti.UI.FILL,
    	      color:ro.ui.theme.backgroundpngTxt
    	  },
	      headerTitle:{
	         color:ro.ui.theme.headerTitleTxt,
	         font:{
	            fontSize:ro.ui.scaleFont(16,0,0),
	            fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
	         },
	         left:ro.ui.relX(2)
	      },
	      grpBackgroundView:{
	         backgroundImage:'/images/grpBackground.png',
	         height:ro.ui.relY(70),
	         width:Ti.UI.FILL,
	         bottom:ro.ui.relY(10),
	         left:ro.ui.relX(25),
	         right:ro.ui.relX(25)
	      },
	      addressList:{
	         height:Ti.UI.SIZE,
	         left:ro.ui.relX(15),
	         top:ro.ui.relY(5),
	         color:ro.ui.theme.contentsSmallTxt,
	         font:{
	            fontSize:ro.ui.scaleFont(11.5,0,0),
	            fontWeight:'normal',
				fontFamily:ro.ui.fontFamily
	         }
	      },
	      addressListHdr:{
	         left:ro.ui.relX(15),
	         height:ro.ui.relY(15),
	         color:ro.ui.theme.contentsSmallTxtHead,
	         font:{
	            fontSize:ro.ui.scaleFont(12, 0, 0),
	            fontWeight:'bold',
				fontFamily:ro.ui.fontFamily
	         }
	      },
	      ccListTbl:{
	         layout:'vertical',
	         top:ro.ui.relY(120),
	         backgroundColor:'white'
	      },
	      hdrViewMargins:{//These are margins on newPay Views, Default Store Views, creditCard Views
	      	left:ro.ui.relX(10),
	         right:ro.ui.relX(10)
	      },
	      pickerTxtFieldLbl:{
	      	font:{
   				fontFamily:ro.ui.fonts.textFields,
   				fontSize:ro.ui.scaleFont(20)
   			},
	      	backgroundColor:ro.ui.theme.txtFldBg,
	      	color:ro.ui.theme.txtFldTxt
	      },
	      allTxtField:{
	      	font:{
   				fontFamily:ro.ui.fonts.textFields,
   				fontSize:ro.ui.scaleFont(17, 175, 30)
   			},
	      	backgroundColor:ro.ui.theme.txtFldBg,
	      	borderColor:ro.ui.theme.txtFldBrd,
	      	color:ro.ui.theme.txtFldTxt,
	      	borderWidth:ro.ui.relX(2),
    	  	borderRadius:ro.ui.relX(8),
	      	hintTextColor:ro.ui.theme.txtFldHintTxt,
	      	width:wideViewWidth,
	      	padding:{
				left:ro.ui.relX(9)
			}
	      },
	      futureOrdBtn:{
	      	backgroundColor:ro.ui.theme.btnDefault,
			   borderColor:ro.ui.theme.loginGray,
			   borderWidth:ro.ui.relX(1),
			   borderRadius:ro.ui.relX(1),
			   height:ro.ui.relY(40),
	         width:ro.ui.relX(310)
	      },
	      futureOrdBtnLbl:{
	      	font:{
	      		fontSize:ro.ui.scaleFont(12.5),
	      		fontFamily:ro.ui.fontFamily,
	      		fontWeight:'bold'
	      	},
	      	color:ro.ui.theme.darkerGray
	      },
	      tabViewParent:{
	         //backgroundImage:'/images/shadow.png',
	         width:Ti.UI.FILL,
	         height:ro.ui.relY(50)
	      },
	      loginNavBarLogo:{
      		image:'/images/loginLogo.png',
        	 top:logoStyleBln ? ro.ui.relY(1): (isiphonex ? ro.ui.relY(30) : ro.ui.relY(10)),
         	bottom:logoStyleBln ? ro.ui.relY(1): ro.ui.relY(10)//,
         //left:ro.ui.relX(75),
         //right:ro.ui.relX(75)
    	  },
	      navBarLogo:{
	      	//borderColor:'green',
	      	//borderWidth:1,
         	image:'/images/logo.png',
         	top:ro.isiOS ? (isiphonex ? ro.ui.relY(0) : ro.ui.relY(-3)) : ro.ui.relY(-1),
     	    //height:Ti.UI.FILL,
        	//top:logoStyleBln ? ro.ui.relY(1): ro.ui.relY(5),
       	 	//bottom:logoStyleBln ? ro.ui.relY(1): ro.ui.relY(10),
       	    left:ro.ui.relX(60),
      	    right:ro.ui.relX(60)
    	  },
	      guestOrLbl:{
	         height:ro.ui.relY(70),
	         width:Ti.UI.SIZE,
	         textAlign:'center',
	         font:{
	            fontWeight:'bold',
	            fontSize:ro.ui.scaleFont(19),
	            fontFamily:ro.ui.fontFamily
	         },
	         color:'black'
	      },
	      acctStatusScrollView:{
	      	contentWidth:Ti.UI.FILL,
	         height:Ti.UI.SIZE,
	         top:ro.ui.relY(5),
	         width:Ti.UI.FILL,
	         //backgroundColor:'brown',
	         visible:true,
	         layout:'vertical'
	      },
	      myRewardsScrollView:{
	         height:Ti.UI.FILL,
	         contentWidth:Ti.UI.FILL,
	         width:Ti.UI.FILL,
	         layout:'vertical',
	         //backgroundColor:'black',
	         visible:false,
	         bottom:ro.ui.relY(10)
	      },
	      noRewardsLbl:{
	         font:{
	            //fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(20)
	         },
	         color:noWhateversLbl,
	         textAlign:'center',
	         height:Ti.UI.FILL
	      },
	      //imageProgressView
	      honeycombImageProgressView:{
	         height:Ti.UI.SIZE,
	         width:Ti.UI.FILL,
	         layout:'vertical'
	      },
	      honeycombCustomProgressView:{
	         height:Ti.UI.SIZE,
	         width:Ti.UI.FILL,
	         layout:'vertical'
	      },
	      honeycombProgressImageView:{
	         height:Ti.UI.SIZE,
	         width:Ti.UI.FILL,
	         left:ro.ui.relX(35),
	         right:ro.ui.relX(35)
	      },
	      customProgressBar:{
	         width:Ti.UI.FILL,
	         height:ro.ui.relY(60),
	         layout:'horizontal',
	         backgroundColor:minorColor
	      },
	      customProgressBlock:{
	      	height:Ti.UI.FILL,
	      	width:'50%',
	      	borderColor:'black',
	      	borderWidth:ro.ui.relX(1),
	      	//layout:'vertical'
	      	//left:0
	      },
	      customProgressBlockTwo:{
	      	height:Ti.UI.FILL,
	      	width:'50%',
	      	borderColor:'black',
	      	borderWidth:ro.ui.relX(1),
	      	layout:'vertical'
	      	//left:0
	      },
	      customerDivider:{
	      	height:Ti.UI.FILL,
	      	width:'4%',
	      	backgroundColor:'black',
	      	//left:0
	      },
	      customProgressLbl:{
	      	 color:ro.ui.theme.nonPendingPointsTxt,
	      	 font:{
	      	 	fontSize:ro.ui.scaleFont(13),
	      	 	fontWeight:'bold',
	      	 	fontFamily:ro.ui.fontFamily
	      	 },
	      	 textAlign:'center',
	      	 //height:'49%',
	      	 height:Ti.UI.SIZE,
	      	 //top:ro.ui.relY(12),
	      	 width:Ti.UI.FILL
	      },
	      customProgressLblTwo:{
	      	 color:ro.ui.theme.nonPendingPointsTxt,
	      	 font:{
	      	 	fontSize:ro.ui.scaleFont(13),
	      	 	fontWeight:'bold',
	      	 	fontFamily:ro.ui.fontFamily
	      	 },
	      	 textAlign:'center',
	      	 //height:'49%',
	      	 height:Ti.UI.SIZE,
	      	 top:ro.ui.relY(12),
	      	 width:Ti.UI.FILL
	      },
	      customEarnedLbl:{
	      	 color:ro.ui.theme.nonPendingPointsTxt,
	       	 textAlign:'center',
	         height:Ti.UI.SIZE,
	         top:0,
	         width:Ti.UI.FILL,
	         font:{
	      	 	fontSize:ro.ui.scaleFont(13),
	      	 	//fontWeight:'bold',
	      	 	fontFamily:ro.ui.fonts.titles
	      	 }
	      },
	      customPointsLbl:{
	      	 color:ro.ui.theme.nonPendingPointsTxt,
	       	 textAlign:'center',
	         height:Ti.UI.SIZE,
	         top:0,
	         width:Ti.UI.FILL,
	         font:{
	      	 	fontSize:ro.ui.scaleFont(13),
	      	 	//fontWeight:'bold',
	      	 	fontFamily:ro.ui.fonts.titles
	      	 }
	      },
	      
	      
	      //
	      honeycombProgressView:{
	         height:ro.ui.relY(80),
	         width:Ti.UI.FILL,
	         //backgroundColor:'green',
	         layout:'vertical'
	      },
	      honeycombProgressBar:{
	         height:ro.ui.relY(50),
	         //left:ro.ui.relX(25),
	         //right:ro.ui.relX(25),
	         width:(pWidth - ro.ui.relX(50)),
	         backgroundColor:'#eeece6',
	         borderColor:'#666666',
	         borderWidth:ro.ui.relX(.5),
	         //borderRadius:ro.ui.relX(5),
	         top:ro.ui.relX(5),
	         zIndex:1
	      },
	      honeycombProgressBarLbl:{
	         font:{
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(15)
	         },
	         color:'#f2b300',
	         textAlign:'center',
	         height:Ti.UI.FILL,
	         zIndex:3
	      },
	      honeycombProgressLblView:{
	         //height:ro.ui.relY(50),
	         height:Ti.UI.FILL,
	         width:(pWidth - ro.ui.relX(50)),
	         //backgroundColor:'white',
	         //borderColor:'black',
	         //borderWidth:1,
	         top:0,
	         layout:'horizontal'
	      },
	      honeycombProgressLbl:{
	         font:{
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(15)
	         },
	         color:'#aba58f',
	         textAlign:'center',
	         height:Ti.UI.FILL,
	         width:'33%'
	      },
	      honeycombFullProgressBar:{
	         height:ro.ui.relY(50),
	         width:(pWidth - ro.ui.relX(50)),
	         //left:ro.ui.relX(25),
	         //right:ro.ui.relX(25),
	         backgroundColor:ro.ui.theme.honeycombProgressFiller,
	         zIndex:2
	         
	      },
	      honeycombCampaignView:{
	         height:Ti.UI.SIZE,
	         width:Ti.UI.FILL,
	         top:0,
	         bottom:ro.ui.relX(50),
	         layout:'vertical'//,
	         //backgroundColor:'blue'
	      },
	      campaignViewRow:{
	         width:Ti.UI.FILL,//FILL INSTEAD OF fill
	         //height:ro.ui.relY(60),
	         height:Ti.UI.SIZE,
	         top:ro.ui.relY(10)
	      },
	      honeycombCampaignSquare:{
	         //left:ro.ui.relX(15)
	         //width:'45%',
	         height:Ti.UI.SIZE,//ro.ui.relY(100),//250
	         borderColor:'#666666',
	         borderWidth:ro.ui.relX(.5),
	         //borderRadius:ro.ui.relX(5),
	         //backgroundColor:'black',
	         left:ro.ui.relX(10),
	         right:ro.ui.relX(10),
	         layout:'vertical'
	         //top:ro.ui.relY(5)
	      },
	      campaignSquareHdrLbl:{
	         top:ro.ui.relY(10),
	         height:Ti.UI.SIZE,//'40%',
	         width:Ti.UI.FILL,
	         font:{
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(17)//27
	         },
	         textAlign:'center',
	         color:ro.ui.theme.honeycombRuleSquareTxt,
	         touchEnabled:false
	      },
	      campaignSquareBodyLbl:{
	         top:ro.ui.relY(2),
	         right:ro.ui.relX(5),
	         left:ro.ui.relX(5),
	         bottom:ro.ui.relY(10),
	         height:Ti.UI.SIZE,//'40%',
	         width:Ti.UI.FILL,
	         font:{
	            //fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(13)//19
	         },
	         textAlign:'center',
	         color:ro.ui.theme.honeycombRuleSquareTxt,
	         touchEnabled:false
	      },
	      campaignSquareNoteLbl:{
	         top:ro.ui.relY(2),
	         right:ro.ui.relX(5),
	         left:ro.ui.relX(5),
	         height:Ti.UI.SIZE,//'20%',
	         width:Ti.UI.FILL,
	         font:{
	            //fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily,
	            fontSize:ro.ui.scaleFont(11)//14
	         },
	         textAlign:'center',
	         color:ro.ui.theme.honeycombRuleSquareTxt,
	         touchEnabled:false
	      },
	      noRulesToDisplayLbl:{
	      	 height:Ti.UI.FILL,
	      	 width:Ti.UI.FILL,
	      	 //top:ro.ui.relY(50),
	      	 textAlign:'center',
	      	 font:{
	      	 	fontSize:ro.ui.scaleFont(25),
	      	 	//fontWeight:'bold',
	      	 	fontFamily:ro.ui.fonts.rowHdrTxt
	      	 },
	      	 color:'black'
	      },
	      orderItemNoteOpaqueView:{
	      	height:Ti.UI.FILL,
	      	width:Ti.UI.FILL,
	      	opacity:.7,
	      	backgroundColor:'black',
	      	zIndex:5,
	      	id: 'popupWin'
	      },
	     prefModsOpaqueView:{
	     	layout:'vertical',
	      	height:Ti.UI.FILL,
	      	width:Ti.UI.FILL,
	      	opacity:.7,
	      	backgroundColor:'black',
	      	zIndex:5,
	      	id: 'popupWin'
	      },
	      prefModsFullView:{
	     	layout:'vertical',
	      	height:Ti.UI.FILL,
	      	width:Ti.UI.FILL,
	      	//opacity:.7,
	      	//backgroundColor:'black',
	      	zIndex:7//,
	      	//id: 'popupWin'
	      },
	      OpaqueView:{
	     	layout:'vertical',
	      	height:Ti.UI.FILL,
	      	width:Ti.UI.FILL,
	      	opacity:.2,
	      	backgroundColor:'black',
	      	zIndex:5,
	      	id: 'popupWin'
	      },
	      OpaqueFullView:{
	     	layout:'vertical',
	      	height:Ti.UI.FILL,
	      	width:Ti.UI.FILL,
	      	//opacity:.7,
	      	//backgroundColor:'black',
	      	zIndex:7//,
	      	//id: 'popupWin'
	      },
	      orderItemNoteBox:{
			width: ro.ui.relX(250),
			height: ro.ui.relY(105),//200
			borderColor: ro.ui.theme.headerBorderColor,
			borderRadius: ro.ui.relX(5),
			backgroundColor:'white',
			//backgroundImage:'/images/background.png',
			borderWidth: 3,
			zIndex:6,
			layout:'vertical'
			//opacity:1
	      },
	      orderItemNoteTextArea:{
	      	 height:ro.ui.relY(35),//130
	      	 width:Ti.UI.FILL,
	      	 color:'black',
	      	 font:{
	      	 	fontSize:ro.ui.scaleFont(15),
	      	 	fontFamily:ro.ui.fontFamily
	      	 },
	      	 maxLength:32,
	      	 //keyboardType:Ti.UI.KEYBOARD_EMAIL,
	      	 returnKeyType:Ti.UI.RETURNKEY_DONE
	      },
	      orderItemNoteSubmitBtn:{
	      	 height:Ti.UI.FILL,
	      	 width:Ti.UI.FILL,
	      	 backgroundColor:'gray'
	      },
	      orderItemNoteSubmitBtnTxt:{
	      	 text:'Save Special Instructions',
	      	 font:{
	      	 	fontSize:ro.ui.scaleFont(15),
	      	 	fontFamily:ro.ui.fontFamily
	      	 },
	      	 color:'black'
	      },
	      orderItemNoteTxt:{
			width: ro.ui.relX(150),
			height: Ti.UI.SIZE,
			top: ro.ui.relY(10),
			text: 'Special Instructions: ',
			color:'white',
			//backgroundColor: 'green',
			font:{
				fontSize: ro.ui.scaleFont(14),
				fontWeight: 'bold'
			}
		  },
		  noItemsLbl:{
	      	font:{
	      	   fontSize:ro.ui.scaleFontY(17, 13),
	            fontFamily:ro.ui.fontFamily
	      	},
	      	textAlign:'center',
	      	height:Ti.UI.SIZE,
	      	width:Ti.UI.SIZE,
	      	color:'#aba58f'
	     },
	     
	     btnWrapper:{
	     	//borderWidth:1,
	     	//borderColor:'blue',
	     	top:ro.ui.relY(10),
			height:ro.isiOS ? ro.ui.relY(130) : ro.ui.relY(120),
			//width:Ti.UI.FILL,
			width:ro.ui.relX(350),
			bottom:ro.ui.relX(55),
			layout:'vertical'
		},
		mediumButtonLblLgTxt:{
			height:Ti.UI.SIZE,
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#393839',
		    font:{
		       fontSize:ro.ui.scaleFont(30),
		       //fontSize:ro.isiOS ? ro.ui.scaleFont(30) : ro.ui.scaleFont(30),
		       fontFamily:ro.ui.fonts.button
		   	}
        },
        filledButtonTxt: {
            height: Ti.UI.SIZE,
            width: Ti.UI.FILL,
            textAlign: 'center',
            color: '#393839',
            font: {
                fontSize: ro.ui.scaleFont(20),
                fontFamily: ro.ui.fonts.settingsButton
            }
        },
        mediumButtonLblMdTxt: {
            height: Ti.UI.SIZE,
            width: Ti.UI.FILL,
            textAlign: 'center',
            color: '#393839',
            font: {
                fontSize: ro.ui.scaleFont(23),
                //fontSize:ro.isiOS ? ro.ui.scaleFont(30) : ro.ui.scaleFont(30),
                fontFamily: ro.ui.fonts.button
            }
        },
		mediumButtonLbl:{
	     	height:Ti.UI.SIZE,
	     	width:Ti.UI.FILL,
	     	textAlign:'center',
	     	color:'#393839',
		    font:{
		   	  //fontWeight:'bold',
		       fontSize:ro.ui.scaleFont(17),
		       fontFamily:ro.ui.fonts.button
		   	}
        },
        primaryButtonLbl: {
            height: Ti.UI.SIZE,
            width: Ti.UI.FILL,
            textAlign: 'center',
            color: '#393839',
            font: {
                //fontWeight:'bold',
                fontSize: ro.ui.scaleFont(15),
                fontFamily: ro.ui.fonts.rowHdrTxt
            }
		},
		secondaryButtonLbl: {
			height: Ti.UI.SIZE,
			width: Ti.UI.FILL,
			textAlign: 'center',
			color: '#393839',
			font: {
				//fontWeight:'bold',
				fontSize: ro.ui.scaleFont(13),
				fontFamily: ro.ui.fonts.settingsButton
			}
		},
        primaryButton: {
            height: ro.ui.relY(36),
            width: ro.ui.relX(185),
            top: ro.ui.relX(25),
            backgroundColor: '#FFFFFF',
            borderColor: '#e4e4e4',
            borderRadius: ro.ui.relX(18),
            borderWidth: ro.ui.relX(2)
		},
		secondaryButton: {
			height: ldfBool ? ro.ui.relY(36) : ro.ui.relY(30),
			width: ro.isiOS ? ro.ui.relX(116) : ro.ui.relX(136),
			top: ro.ui.relX(15),
			backgroundColor: mediumBtnBg,
			borderColor: '#e4e4e4',
			borderRadius: ldfBool ? ro.ui.relX(17.5) : ro.ui.relX(20),
			borderWidth: ro.ui.relX(2)
		},
	     mediumButton:{
		    height:ldfBool ? ro.ui.relY(55) : ro.ui.relY(50),
		    width:ro.isiOS ? ro.ui.relX(155) : ro.ui.relX(175),
		    top:ro.ui.relX(25),
	        backgroundColor:mediumBtnBg,
		    borderColor:'#e4e4e4',
		   	borderRadius:ldfBool ? ro.ui.relX(27.5) : ro.ui.relX(25),
	        borderWidth:ro.ui.relX(2)
            },
         smallButton: {
             height: ldfBool ? ro.ui.relY(30) : ro.ui.relY(25),
             width: ro.isiOS ? ro.ui.relX(105) : ro.ui.relX(125),
             top: ro.ui.relX(15),
             backgroundColor: mediumBtnBg,
             borderColor: '#e4e4e4',
             borderRadius: ldfBool ? ro.ui.relX(15) : ro.ui.relX(17.5),
             borderWidth: ro.ui.relX(1.5)
         },
         filledButton: {
             height: ldfBool ? ro.ui.relY(46) : ro.ui.relY(46),
             width: ro.isiOS ? ro.ui.relX(135) : ro.ui.relX(135),
             top: ro.ui.relX(25),
             backgroundColor: '#f6f6f6',
             borderColor: '#e4e4e4',
             borderRadius: ldfBool ? ro.ui.relX(22.5) : ro.ui.relX(20),
             borderWidth: ro.ui.relX(2)
         },
	     secondaryBigButton:{
	      height:ro.ui.relY(64),
	      //width:Ti.UI.FILL,
	      backgroundColor:ro.ui.theme.bigBtnSecondaryBackground,
	      borderColor:ro.ui.theme.bigBtnSecondaryBorder,
		  borderRadius:ro.ui.relY(32),
	      borderWidth:ro.ui.relX(1.5),
	      left:ro.ui.relX(10),
	      right:ro.ui.relX(10)
	   },
	   secondaryBigButtonLbl:{
	   	  height:Ti.UI.SIZE,
	   	  width:Ti.UI.FILL,
	      font:{//fontWeight:'bold',
	         fontSize:ro.ui.scaleFont(ro.isiOS ? 26 : 28),
	         fontFamily:ro.ui.fonts.button
	      },
	      color:ro.ui.theme.bigBtnSecondaryTxt,
	      textAlign:'center'
	   },
	     popupHdrLbl:{
	     	font:{
				fontSize:ro.ui.scaleFont(28, 120, 49),
				//fontWeight:'bold',
				fontFamily:ro.ui.fonts.alerts.title
			},
		    textAlign:'center',
		 	width:Ti.UI.SIZE,
		 	color:ro.ui.theme.popupHdrTxt
	     },
	     popupBodyLbl:{
	     	top:0,
			  left:ro.ui.relX(2),
			  width:Ti.UI.FILL,
			  //height:Ti.UI.FILL,
			  //height:ro.ui.relY(100),
			  textAlign:'center',
			  font:{
			  	  fontSize:ro.ui.scaleFontY(20, 49),
	            fontFamily:ro.ui.fonts.alerts.body
			  },
			  color:ro.ui.theme.popupMsgTxt
	     },
	     /*alerts:{
	    		title:GarageGothic_Bold,
	    		body:GothamBold
	    	},*/
	     popupContainer:{
			width:ro.ui.relX(290),
			height:ro.ui.relX(200),
			borderRadius:ro.ui.relY(20)//,
			//borderWidth:2
		 },
		 popupContainer2:{
			width:ro.ui.relX(290),
			height:ro.ui.relX(200),
			borderRadius:ro.ui.relY(15)//,
			//borderWidth:2
		 },
		 popupAlertView:{
			top:ro.ui.relY(1),
			bottom:ro.ui.relY(1),
			left:ro.ui.relX(1),
			right:ro.ui.relX(1),
			width:ro.ui.relX(288),
			height:ro.ui.relX(198),
			backgroundColor:'#fff',
			borderRadius:ro.ui.relY(20),
			layout:'vertical'
		 },
		 popupAlertView2ios:{
			
			width:wideViewWidth,
			height:Ti.UI.SIZE,
			backgroundColor:'#fff',
			borderRadius:ro.ui.relY(15),
			layout:'vertical'
		 },
		 popupAlertView2:{
			elevation:10,
			translationZ:10,
			//translationY:ro.ui.relY(20),
			width:wideViewWidth,
			//height:ro.ui.relX(200),
			height:Ti.UI.SIZE,
			//height:ro.ui.relX(198),
			backgroundColor:'#fff',
			borderRadius:ro.ui.relY(15),
			layout:'vertical'
		 },
		 popupShadow:{
			width:ro.ui.relX(290),
			height:ro.ui.relX(200),
			opacity:.3,
			borderRadius:ro.ui.relX(20),
			backgroundColor:'#787878'
		 },
		 shadowView2:{
		 	width:Ti.UI.FILL,
			top:ro.ui.relY(0),
			//left:ro.ui.relX(-20),
			//right:ro.ui.relX(-20),
			bottom:ro.ui.relY(0),
			backgroundColor:'black',
			opacity:.1
		 },
		 popupView2:{
		 	width:Ti.UI.FILL,
			top:ro.ui.relY(0),
			//left:ro.ui.relX(-20),
			//right:ro.ui.relX(-20),
			bottom:ro.ui.relY(0)
	    },
		 popupView:{
			top:0,
			left:0,
			right:0,
			bottom:0,
			backgroundColor:'transparent',
			visible:false
	    },
	    popupButton:{
	      	top:ro.ui.relY(10),
	    	    width:ro.ui.relX(180),
	 		height:ro.ui.relY(45),
	 		title:"Ok",
	 		borderRadius:ro.ui.relX(23),
	 		color:'#393839',
	        borderWidth:ro.ui.relX(2),
	      	backgroundColor:"transparent",
	      	borderColor:'#e4e4e4',
	      	bottom:ro.ui.relY(15),
	      	font:{
	      		//fontWeight:'bold',
	      		fontFamily:ro.ui.fonts.button,
	      		fontSize:ro.ui.scaleFont(30)
	      	}
		},
		 
		 
		 storeRow:{
			className:'storeSelRow',
			height:ro.ui.relY(90),
			width:Ti.UI.FILL,
			//layout:'horizontal',
			selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null,
			backgroundColor:storeRowBg
			//borderColor:ro.ui.theme.txtFldBrd,
			//borderWidth:ro.ui.relX(1),
			//borderRadius:ro.ui.relX(10)
		},
		storeRowView:{
			backgroundColor:storeRowBg,
			height:Ti.UI.SIZE,
			width:Ti.UI.FILL,
			//layout:'horizontal',
			borderColor:ro.ui.theme.txtFldBrd,
			borderWidth:ro.ui.relY(2),
			borderRadius:ro.ui.relX(10)
		},
		storeRowRow:{
			
			className:'storeSelRow',
			top:ro.ui.relY(10),
			height:ro.ui.relY(100),
			width:Ti.UI.FILL,
			layout:'horizontal',
			selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
			//borderColor:ro.ui.theme.txtFldBrd,
			//borderWidth:ro.ui.relX(1),
			//borderRadius:ro.ui.relX(10)
		},
		storeStatusView:{
			left:ro.ui.relX(3),
			layout:'vertical',
			width:ro.ui.relX(90),
			height:Ti.UI.FILL
		},
		storeStatusLbl:{
			font:{
			   fontSize:ro.ui.scaleFontY(13, 13),
			   //fontWeight:'bold',
				fontFamily:ro.ui.fonts.storeStatusText
			},
			width:Ti.UI.FILL,
			height:ro.ui.relY(15),
	     	textAlign:'center'
		},
		storeDistanceLbl:{
			font:{
			    fontSize:ro.ui.scaleFontY(11, 13),
				fontFamily:ro.ui.fonts.rowBodyTxt
			},
			width:Ti.UI.FILL,
			height:ro.ui.relY(15),
	     	color:ro.ui.theme.storeSelectionBodyTxt,
	     	textAlign:'center'
		},
		storeImageView:{
			top:ro.ui.relY(10),
			height:ro.ui.relY(40),
			image:'/images/location.png'
		},
		storeAddressHdr:{
			//top:ro.ui.relY(20),
			width:Ti.UI.FILL,
			font:{
			   fontSize:ro.ui.scaleFontY(14, 13),
			   //fontWeight:'bold',
				fontFamily:ro.ui.fonts.rowHdrTxt
			},
	     	color:ro.ui.theme.storeSelectionHdrTxt,
	     	textAlign:'left'
		},
		storeAddressBody:{
			font:{
			    fontSize:ro.ui.scaleFontY(13, 13),
				fontFamily:ro.ui.fonts.rowBodyTxt
			},
			width:Ti.UI.FILL,
	     	color:ro.ui.theme.storeSelectionBodyTxt,
	     	textAlign:'left'
		},
		settingsButton:{
	      height:ro.ui.relY(68),
	      width:wideViewWidth,//ro.ui.relX(350),
	      top:ro.ui.relX(10),
	      backgroundColor:settingsBtnBg,
	      borderColor:ro.ui.theme.settingsBtnBorder,
		  borderRadius:ro.ui.relX(34),
	      borderWidth:ro.ui.relX(2),
	      //layout:'horizontal'
	    },
	    settingsButtonLbl:{
	      left:ro.ui.relX(10),
	      height:Ti.UI.FILL,
	      font:{
	         //fontWeight:'bold',
	         fontSize:ro.ui.scaleFont(18),
	         fontFamily:ro.ui.fonts.settingsButton
	      },
	      color:ro.ui.theme.settingsBtnTxt,
	      textAlign:'center'
	   },
	   menuBox:{
	   	  layout:'vertical',
		  height:Ti.UI.SIZE,
		  width:'33%'
	   },
       
	   //GENERIC ROW STYLES
	   
	   genericRowView:{
	   		top:ro.ui.relY(0),
			height:ro.ui.relY(70),
			backgroundColor:genericRowBg,
			//width:ro.ui.relX(325),
			width:wideViewWidth,
			//width:Ti.UI.FILL,
			//layout:'horizontal',
			borderColor:ro.ui.theme.settingsBtnBorder,
			borderWidth:ro.ui.relY(2),
			borderRadius:ro.ui.relX(10)
		},
		genericTxtView:{
			width:ro.ui.relX(270),
			left:0,
			height:Ti.UI.FILL,
			touchEnabled:false
		},
		genericLbl:{
			textAlign:'left',
			font:{
				fontSize:ro.ui.scaleFont(15),
				fontFamily:ro.ui.fonts.rowBodyTxt
			},
			left:ro.ui.relX(35),
			touchEnabled:false,
			color:'#000000'
        },
        genericMediumLbl: {            
            font: {
                fontSize: ro.ui.scaleFont(13),
                fontFamily: ro.ui.fonts.rowBodyTxt
            },
            touchEnabled: false,
            color: '#403e40'
        },
        genericMediumBoldLbl: {
            font: {
                fontSize: ro.ui.scaleFont(13),
                fontFamily: ro.ui.fonts.rewardsBubble
            },
            touchEnabled: false,
            color: '#403e40'
        },
        guestInfoHeaderBoldLbl: {
            font: {
                fontSize: ro.ui.scaleFont(33),
                fontFamily: ro.ui.fonts.titles
            },
            touchEnabled: false,
            color: '#383938'
        },
		arrowView:{
			right:ro.ui.relX(10),
			width:ro.ui.relX(45),
			touchEnabled:false
		},
		//GENERIC ROW STYLES
		
		//Generic Row Style with Header Text
		genericRowViewWithHeader:{
	   		top:ro.ui.relY(0),
			height:ro.ui.relY(75),
			//width:ro.ui.relX(325),
			width:wideViewWidth,
			//width:Ti.UI.FILL,
			layout:'horizontal',
			borderColor:ro.ui.theme.settingsBtnBorder,
			borderWidth:ro.ui.relY(2),
			borderRadius:ro.ui.relX(10)
	   },
		genericTxtViewWithHeader:{
			width:wideViewWidth,
			left:0,
			height:Ti.UI.FILL,
			touchEnabled:false,
			layout:'vertical'
		},
		genericLblHdr:{
			textAlign:'left',
			font:{
				fontSize:ro.ui.scaleFont(14),
				fontFamily:ro.ui.fonts.rowHdrTxt
			},
			left:ro.ui.relX(25),
			touchEnabled:false,
			color:'#393839'
		},
		genericLblWithHeader:{
			textAlign:'left',
			font:{
				fontSize:ro.ui.scaleFont(14),
				fontFamily:ro.ui.fonts.rowBodyTxt
			},
			left:ro.ui.relX(25),
			touchEnabled:false,
			color:'#393839'
		},
		genericHdrLblWithHeader:{
			font:{
				//fontWeight:'bold',
				fontSize:ro.ui.scaleFont(20),
				fontFamily:ro.ui.fonts.titles
			},
			color:'#393839',
			left:ro.ui.relX(25),
			touchEnabled:false//,
			//bottom:ro.ui.relY(5)
        },
        genericHdrLblContent: {
            font: {
                fontSize: ro.ui.scaleFont(18),
                fontFamily: ro.ui.fonts.textFields
            },
            color: '#393839',
            touchEnabled: false//,
            //bottom:ro.ui.relY(5)
        },
		genericHdrLblWithHeaderLarge:{
			font:{
				//fontWeight:'bold',
				fontSize:ro.ui.scaleFont(28),
				fontFamily:ro.ui.fonts.titles
			},
			color:'#393839',
			left:ro.ui.relX(25),
			touchEnabled:false//,
			//bottom:ro.ui.relY(5)
        },
        genericHdrLblWithHeaderHuge: {
            textAlign: 'center',
            font: {
                //fontWeight:'bold',
                fontSize: ro.ui.scaleFont(33),
                fontFamily: ro.ui.fonts.hugeTitles
            },
            color: '#393839',
            touchEnabled: false,
            top:ro.ui.relY(10)
        },
		genericHdrRowViewWithHeader:{
			//top:ro.ui.relY(5),
			height:Ti.UI.SIZE,
			//width:ro.ui.relX(325),
			width:wideViewWidth,
			touchEnabled:false
		},
		
		
		genericMenuHdrRowViewWithHeader:{
		    layout:'vertical',
		    backgroundColor:'#f6f6f6',
            top:ro.ui.relY(5),
            height:Ti.UI.SIZE,
            //width:ro.ui.relX(325),
            width:Ti.UI.FILL,
            touchEnabled:false
        },
        genericMenuHdrLblWithHeader:{
            font:{
                //fontWeight:'bold',
                fontSize:ro.ui.scaleFont(28),
                fontFamily:ro.ui.fonts.titles
            },
            //top:ro.ui.relY(5),
            //bottom:ro.ui.relY(5),
            color:'#393839',
            left:ro.ui.relX(25),
            touchEnabled:false//,
            //bottom:ro.ui.relY(5)
        },
		//Generic Row Style with Header Text
		
		//GENERIC HEADER STYLES
		genericHdrRowView:{
			top:ro.ui.relY(5),
			height:ro.ui.relY(70),
			//width:ro.ui.relX(325),
			//backgroundColor:genericRowBg,
			width:wideViewWidth,
			touchEnabled:false
		},
		genericHdrLbl:{
			font:{
				//fontWeight:'bold',
				fontSize:ro.ui.scaleFont(25),
				fontFamily:ro.ui.fonts.titles
			},
			color:'#393839',
			left:ro.ui.relX(35),
			touchEnabled:false,
			bottom:ro.ui.relY(5)
        },
        specialHdrLbl: {
            font: {
                //fontWeight:'bold',
                fontSize: ro.ui.scaleFont(15),
                fontFamily: ro.ui.fonts.settingsButton
            },
            color: '#393839',
            left: ro.ui.relX(35),
            touchEnabled: false,
            bottom: ro.ui.relY(5)
        },
		//GENERIC HEADER STYLES
        ordTypeOrLbl: {
            font: {                
                fontSize: ro.ui.scaleFont(25),
                fontFamily: ro.ui.fonts.titles
            },
            color: '#9B9B9B',
            touchEnabled: false
		},
		surchargeLbl: {
			font: {
				fontSize: ro.ui.scaleFont(14),
				fontFamily: ro.ui.fonts.policyLink
			},
			color: '#EB0029',
			touchEnabled: false
		},
		greyBorder:{
		    top:ro.ui.relY(10),
		    height:ro.ui.relY(1.3),
		    width:(.9 * wideViewWidth),
		    backgroundColor:'#e4e4e4'
		},
		fullGreyBar:{
		    //top:ro.ui.relY(3),
            height:ro.ui.relY(1.3),
            width:Ti.UI.FILL,
            backgroundColor:'#e4e4e4',
            isHeader:true,
            touchEnabled:false
        },
        greySeperator: {
            top: ro.ui.relY(20),
            height: ro.ui.relY(2),
            width: (.95 * ro.ui.displayCaps.platformWidth),
            backgroundColor: '#e3e4e5'
        }   
	};
		ro.ui.properties.contentsView = (false && ldf===1)?ro.ui.properties.contentsViewLow:ro.ui.properties.contentsViewHigh;
	};
	return{
		style:style
	};
}();
module.exports = STYLE;
//var $$ = ro.ui.properties;