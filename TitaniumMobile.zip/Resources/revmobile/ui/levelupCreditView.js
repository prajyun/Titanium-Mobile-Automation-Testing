(function(){
   ro.ui.getLoyaltiesCreditView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesCredit', 'LEVELUP', null, null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var addCCBtn = layoutHelper.getRightBtn('CHANGE CARD');
      addCCBtn.addEventListener('click', function(e){
         try{
            ro.ui.showLoader();
            ro.ui.settingsShowNext({addView:true, showing:'loyaltiesCreateCard'});
         }
         catch(ex){
            ro.ui.alert('Credit Card Error', 'Code:110' + ex);
         }
      });
      mainView.children[0].add(addCCBtn);

      var loyaltiesCreditView =  Ti.UI.createScrollView({
         layout:'vertical',
         top:0,
         bottom:ro.ui.relY(110)
      });

      mainView.add(loyaltiesCreditView);

      var defLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
         right:ro.ui.relX(10),
         left:ro.ui.relX(10),
         top:ro.ui.contentsTop,
         focusable:false
      }));
      defLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
         text:'DEFAULT CARD:',
         font:{
            fontSize:ro.ui.scaleFont(15, 0, 0),
            fontWeight:'bold',
         fontFamily:ro.ui.fontFamily
         }
      })));

      var defTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
         top:0,
         height:Ti.UI.SIZE
      }));

      var otherTbl = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
         top:0,
         height:Ti.UI.SIZE
      }));
      var noCardLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved cards'}));

      var noneTbl = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
         className:'noneRow',
         height:ro.ui.relY(40)
      }));
      var noneLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
         text:'No Saved Cards',
         color:ro.ui.theme.contentsTextColor
      }));
      noneTbl.add(noneLbl);

      var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
      levelUp.getPaymentInfo(function(e){
         finishView(e);
      });

      function finishView(paymentInfo){
         var cardObj;
         var rs = [];
         var ccOne = {
            CardInfo:paymentInfo.payment_method.metadata.issuer,
            lastFour:paymentInfo.payment_method.metadata.last_4,
            month:paymentInfo.payment_method.metadata.expiration_month,
            year:paymentInfo.payment_method.metadata.expiration_year
         };
         rs.push(ccOne);
         /*paymentInfo.payment_method.metadata.issuer;
         paymentInfo.payment_method.metadata.last_4;
         paymentInfo.payment_method.metadata.expiration_month;
         paymentInfo.payment_method.metadata.expiration_year;*/

         var ccLength = rs? rs.length:0;
         for(var i=0; i<ccLength; i++){
            cardObj = rs[i];
            var CCinfo = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
               id:rs[i].rowid,
               className:'card',
               height:ro.ui.relY(60),
               width:Ti.UI.FILL,
               layout:'horizontal',
               leftImage:'/images/credit_card.png'
            }));

            var creditLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.newPayTxt, {
               left:ro.ui.relX(35),
               height:Ti.UI.FILL,
               right:ro.ui.relX(125),
               text:'****' + rs[i].lastFour + '\nEXP ' + cardObj.month + '/' + cardObj.year,
               color:ro.ui.theme.contentsTextColor
            }));
            delete creditLbl.top;

            CCinfo.add(creditLbl);
            /*CCinfo.addEventListener('click', function(e){
               try{
                  ro.ui.showLoader();
                  //ro.ui.settingsShowNext({addView:true, showing:'editCardView', rowid:e.soure.id});
                  ro.ui.hideLoader();
               }
               catch(ex){
                  ro.ui.alert('editCreditCardList Error', 'Code:110' + ex);
               }
            });*/
            defTbl.appendRow(CCinfo);
         }

         if(!defTbl.data.length){
            defTbl.setData(noneTbl);
         }
         loyaltiesCreditView.add(defLblView);
         loyaltiesCreditView.add(defTbl);
      }
      return mainView;
   };
})();