var USERNAMEVIEW = function(){
	var usernameview = function(ro){
	   ro.ui.updateUserNameView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/credentialsForm.js');
	      var forms = ro.forms;
	      var credentialsForm = require('formControls/credentialsForm');
	      var regexVal = require('validation/regexValidation');
	      var unVal = require('validation/usernameValidation');
	      
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:credentialsForm.getUpdateUsernameForm(),
	         settings:ro.ui.properties.myAccountView
	      });
	      //form.top = ro.ui.relY(10);
	
	      var mainView =  Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'username', hid:'username'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Update Username'}));
	         navBar.add(headerLbl);
	      } */
	      
	      //var clearBtn = layoutHelper.getRightBtn('CLEAR');
	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      clearBtn.addEventListener('click', function(e){ form.clearFields(); });
	
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'username'}); });
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
	
	      var btnUpdate = layoutHelper.getBigButton('Update');
	      var btnWrapper = ro.layout.getBtnWrapper();
	  	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         //Ti.include('/validation/usernameValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         var success = unVal.unValidate(values);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	
	               ro.dataservice.post(formRequest(values.email), 'UpdateUsername', function(response){
	                  if(response){
	                     if(response.Value){
	                        ro.db.updateUsername(Ti.App.Username, values.email);
	                        Ti.App.Username = values.email;
	                        ro.ui.settingsShowNext({showing:'username', resetOrder:true});
	                     }
	                     ro.ui.alert(response.Value?'Success:':'Error:', response.Message);
	                     ro.ui.hideLoader();
	                  }
	               });
	            }
	            else{
	               ro.ui.alert('Error: ', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error: ', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Update Email"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Contact Information", true);
	      hdr.bottom = ro.ui.relY(10);
			form.container.insertAt({
				view:hdr,
				position:0
			});
	      mainView.add(form);
	      return mainView;
	   };
	
	   function formRequest(newEmail){
	      var req = {};
	      req.UserName = Ti.App.Username;
	      req.Pass = Ti.App.Password;
	      req.RevKey = 'test';
		  req.UpdatedEmail = newEmail;
		  var savedTokenObj = JSON.parse(Ti.App.Properties.getString('PushNotificationTokenObj', '{}'));
		  if (savedTokenObj && savedTokenObj.token) {
			  req.CustomerDevice = {};
			  req.CustomerDevice.DeviceID = Ti.Platform.id;
			  req.CustomerDevice.DeviceToken = savedTokenObj.token;
			  req.CustomerDevice.DeviceType = ro.isiOS ? 1 : 2;
		   }
	      return req;
	   };
	};
	return {
		usernameview:usernameview
	};
}();
module.exports = USERNAMEVIEW;