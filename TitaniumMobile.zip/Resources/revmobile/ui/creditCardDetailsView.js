var CREDITCARDDETAILS = function(){
	var creditcarddetails = function(){
	   ro.ui.createCreditCardDetailsView = function(_args){
	      //Ti.include('/controls/ccControl.js');
	      var ccControl = require('controls/ccControl');
	      var creditCardForm = require('formControls/creditCardForm');
	      var regexVal = require('validation/regexValidation');
	      var ccHelper = require('logic/creditCard');
	      var credCardVal = require('validation/creditcardValidation');
	      var rs = ro.db.getAllCustCC(Ti.App.Username);
	      //Ti.API.debug('_args.rowid: ' + _args.rowid);
	      var rowid = _args.rowid;
	      var ccInfo;
	
	      for(i=0; i<rs.length; i++){
	         if(rs[i].rowid === rowid){
	            ccInfo = rs[i].CCInfo;
	            break;
	         }
	      }
	      //Ti.API.debug('ccInfo: ' + JSON.stringify(ccInfo));
	
	      var billFlg = 0;
	      if(ccInfo.AVSZipCode){
	      	billFlg = 1;
	      }
	      if(ccInfo.AVSStreetNum){
	      	billFlg = 2;
	      }
	
	      //var forms = require('/revmobile/ui/forms');
	      var forms = ro.forms;
	      //Ti.include('/formControls/creditCardForm.js');
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:creditCardForm.getCCForm({save:false, billingFlag:billFlg}),
	         settings:ro.ui.properties.myAccountView
	      });
	
	      ccInfo.ccDefault=(ccControl.getDefaultCard()==rowid)?true:false;
	
		  Ti.API.debug('ccInfo:' + JSON.stringify(ccInfo));
	      form.setFields(ccInfo);
	      form.fieldRefs.ccName.editable = false;
	      form.fieldRefs.ccNum.editable = false;
	      
           var ccVal = form.fieldRefs.ccNum.value;
           Ti.API.info("Saved Card: " + ccVal);
           //This line displays the complete credit card value
           //form.fieldRefs.ccNum.value = ccVal.length === 16 ? (ccVal.substr(0,4) + '-' + ccVal.substr(4,4) + '-' + ccVal.substr(8,4) + '-' + ccVal.substr(12)) : (ccVal.substr(0,4) + '-' + ccVal.substr(4,6) + '-' + ccVal.substr(10));

           //This just obscures it
           form.fieldRefs.ccNum.value = ccVal.length === 16 ? ('XXXX-XXXX-XXXX-' + ccVal.substr(12)) : ('XXXX-XXXXXX-X' + ccVal.substr(11));

           var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, { name: 'editcc', hid: 'creditCardView' }));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      
	      var resetBtn = layoutHelper.getNewRightBtn('Delete', null, "/images/navClear.png");
	      resetBtn.addEventListener('click', function(e){
	      	 ro.GlobalPicker.hidePicker();
	         //ro.ui.showLoader();
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var delSuccess;
	         
	         ro.ui.popup('Alert', ['Cancel', 'OK'], 'Are you sure you want to delete this Credit Card?', function(e) {
                
                if(ccControl.deleteCurrentCC(rowid, ro)){
                      ro.ui.alert('Success: ', 'Card was deleted.');
                      ro.ui.settingsShowNext({showing:'creditCardView'});
                   }
                   else{
                      ro.ui.alert('Error: ', 'Card was not deleted.');
                   }
            });
	         
	         /*var dlg = Ti.UI.createAlertDialog({
	            title:'Alert',
	            message:'Are you sure you want to delete this Credit Card?',
	            buttonNames:['Yes', 'No']
	         });
	         dlg.addEventListener('click', function(ev){
	            if(ev.index == 0){
	               if(ccControl.deleteCurrentCC(rowid, ro)){
	                  ro.ui.alert('Success: ', 'Card was deleted.');
	                  ro.ui.settingsShowNext({showing:'creditCardView'});
	               }
	               else{
	                  ro.ui.alert('Error: ', 'Card was not deleted.');
	               }
	            }
	            else{
	               return;
	            }
	            ro.ui.hideLoader();
	         });
	         dlg.show();*/
	         //ro.ui.hideLoader();
	      });
	
	      //var btnBack =  Ti.UI.createButton(ro.combine(ro.ui.properties.backBtn, {title:'Credit Cards'}));
	      var btnBack = layoutHelper.getBackBtn('CREDIT CARDS');
	      btnBack.addEventListener('click', function(e){ 
	      	ro.GlobalPicker.hidePicker();
	      	ro.ui.settingsShowNext({showing:'creditCardView'});
	      });
	      navBar.add(btnBack);
	      navBar.add(resetBtn);
	
	      //var btnUpdate = Ti.UI.createButton(ro.combine(ro.ui.properties.submitBtn, {title:'Save', bottom:ro.ui.relY(55)}));
	      //Ti.include('/logic/creditCard.js');
	      var btnUpdate = layoutHelper.getBigButton('Save');
	      var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	      	 ro.GlobalPicker.hidePicker();
	         ro.ui.showLoader();
	         //Ti.include('/validation/creditcardValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         Ti.API.info('values: ' + JSON.stringify(values));
             values.ccNum = ccVal;
	         var ccTypeStr = ccHelper.ValidateCC(values.ccNum);
	         Ti.API.info('ccTypeStr: ' + ccTypeStr);
	         
	         var temp = values;
	         temp.ccType = ccTypeStr;
	         temp.rowid = rowid;
	         
	         values = temp;
	         temp = null;
	         Ti.API.debug('values: ' + JSON.stringify(values));
	         //values.rowid = rowid;
	         var success = credCardVal.credCardValidate(values, ccInfo);
	         if(success.value){
	            //Ti.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               var ccSuccess = ccControl.updateExistingCard(ccControl.createCardObj(values), rowid, ro);
	               if(ccSuccess != -1){
	                  if(values.ccDefault){
	                     ccControl.setDefaultCard(rowid);
	                  }
	                  else{
	                     if(rowid == ccControl.getDefaultCard()){
	                        ccControl.delDefaultProperty();
	                     }
	                  }
	                  ro.ui.alert('Success:', 'Credit Card has been saved!');
	                  ro.ui.settingsShowNext({showing:'creditCardView'});
	               }
	               else{
	                  ro.ui.alert('Error: ', 'Card was not saved');
	                  ro.ui.hideLoader();
	               }
	            }
	            else{
	               ro.ui.alert('Error', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Card Details"));
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      var hdr = ro.layout.getGenericHdrRowWithHeader("Card Details", true);
	      hdr.bottom = ro.ui.relY(10);
	      //hdr.top = 0;
			form.container.insertAt({
				view:hdr,
				position:2
			});
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      mainView.add(form);
	      return mainView;
	   };
	};
	return {
		creditcarddetails:creditcarddetails
	};
}();
module.exports = CREDITCARDDETAILS;