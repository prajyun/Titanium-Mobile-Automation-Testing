var VALIDATEEMAILVIEW = function () {
    var validateemailview = function (ro) {
        ro.ui.createValidateEmailView = function () {

            var backButton = layoutHelper.getBackBtn('BACK');
            try {
                var mainView = layoutHelper.getMainView('validateEmailView'/*hid*/, 'Validate Email'/*Top Title*/, null/*right Button*/, backButton/*left button*/, true/*vertical or not*/);
            }
            catch (ex) {
                if (Ti.App.DEBUGBOOL) { Ti.API.debug('validateEmailView()-Exception: ' + ex); }
            }
            try {
                var validateEmailView = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView, {
                    layout: 'vertical',
                    height: Ti.UI.SIZE,
                    width: Ti.UI.FILL,
                    disableBounce: ro.isiOS ? true : false,
                    contentWidth: Ti.UI.FILL
                }));
                var headerLbl = Ti.UI.createLabel(ro.ui.properties.popupHdrLbl);

                var instructionsLbl = Ti.UI.createLabel(ro.ui.properties.popupBodyLbl);
                instructionsLbl.top = ro.ui.relY(15);

                headerLbl.text = "Email Verification";
                instructionsLbl.text = "Thank you for registering. Please verify your email before placing your order.";

                var linkLbl = Ti.UI.createLabel(ro.ui.properties.popupBodyLbl);
                linkLbl.top = ro.ui.relY(15);

                var linkString = "Please Click Here to resend the confirmation link.";

                var attributesCol = [];

                //Ti.API.debug('1finalString: ' + finalString);

                attributesCol.push({
                    type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                    value: '#eb0029',
                    range: [linkString.indexOf("Click Here"), ("Click Here").length]
                });
                attributesCol.push({
                    type: Ti.UI.ATTRIBUTE_UNDERLINES_STYLE,
                    value: Ti.UI.ATTRIBUTE_UNDERLINE_STYLE_SINGLE,
                    range: [linkString.indexOf("Click Here"), ("Click Here").length]
                });
                var attr = Ti.UI.createAttributedString({
                    text: linkString,
                    attributes: attributesCol
                });
                linkLbl.attributedString = attr;

                validateEmailView.add(headerLbl);
                validateEmailView.add(instructionsLbl);
                validateEmailView.add(linkLbl);

                //instructionsLbl.addEventListener('click', function (e) {
                //    var req = {};
                //    req.Email = Ti.App.Username;
                //    req.isJson = true;
                //    req.Url = ro.isiOS ? Ti.App.name + '://' : Ti.App.resetURL;
                //    Ti.API.info("req : " + JSON.stringify(req));
                //    ro.ui.showLoader();
                //    ro.dataservice.postAPI(req, "RequestEmail", function (response) {
                //        Ti.API.info("RequestEmail Response: " + JSON.stringify(response));
                //        if (response.Success) {
                //            ro.ui.alert('Email Sent', 'Please check your email to verify your account');
                //            ro.ui.hideLoader();
                //        } else {
                //            ro.ui.alert("Email Error : ", response.Message);
                //            ro.ui.hideLoader();
                //        }
                //    });
                //});

                linkLbl.addEventListener('click', function (e) {
                    var req = {};
                    req.Email = Ti.App.Username;
                    req.isJson = true;
                    req.Url = ro.isiOS ? Ti.App.name + '://' : Ti.App.websiteURL + 'Account/EmailValidation';
                    Ti.API.info("req : " + JSON.stringify(req));
                    ro.ui.showLoader();
                    ro.dataservice.postAPI(req, "RequestEmail", function (response) {
                        Ti.API.info("RequestEmail Response: " + JSON.stringify(response));
                        if (response.Success) {
                            ro.ui.alert('Email Sent', 'Please check your email to verify your account');
                            ro.ui.hideLoader();
                        } else {
                            ro.ui.alert("Email Error : ", response.Message);
                            ro.ui.hideLoader();
                        }
                    });
                });
            }
            catch (ex) {
                Ti.API.info('validateEmailView()-Exception: ' + ex);
            }
            mainView.add(validateEmailView);
            return mainView;
        };
    };
    return {
        validateemailview: validateemailview
    };
}();
module.exports = VALIDATEEMAILVIEW;