//Ti.include('/formControls/fullDateForm.js');
var DEFAULTSTOREVIEW = function(){
	var defaultstoreview = function(ro){
        ro.ui.createDefaultStoreView = function (_args) {
           
		   var dateForm = require('formControls/fullDateForm').dateForm(ro);
		   var otherLblViewTxt = 'Find Other Stores';
	       var useAddrHid = 'newAddrList';
		   
		   //GUEST ORDERS
		   var isGuest = false;
            if (ro.REV_GUEST_ORDER.getIsGuestOrder()) {
                isGuest = true;
                otherLblViewTxt = 'Find Store';
                useAddrHid = 'guestFindStore';
            } else {
                // Login again              
                ro.login(Ti.App.Username, Ti.App.Password, false);
                // End Login Again
            }
		   //GUEST ORDERS
		   
		    //Ti.App.OrderObj.ordOnlineOptions.IsDelivery = false;
		    var test = Ti.App.OrderObj;
		    test.ordOnlineOptions.IsDelivery = false;
		    Ti.App.OrderObj = test;
		    test = null;
		   
			var customer = null;
	 	 	var data = [];
	 		var lat, lon;
	
			try{
				var mainView = layoutHelper.getMainView('defaultStore', 'Stores', null, layoutHelper.getBackBtn('ORDER TYPE'), true);
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('defaultStoreView()-Exception: ' + ex); }
			}
	
	  		var rowIndex = 0;
	  		var data2 = [];
	  		var latitude, longitude, row1, row2, row3, data2 = [], tableView2, statusOfStore;
	
		   function addLabels(List,idx,tblViewIdx){
		  	 for(var i=0; i<List.length; i++){
			 	var top = ro.ui.relY(25);
				var bottom = ro.ui.relY(22);//18
		        if(tblViewIdx == 1){
					data[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
						text:List[i],
						top:top + (ro.ui.relY(15) * i),
						bottom:bottom - (ro.ui.relY(13) * i)
					})));
		        }
		        else{
					data2[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
						text:List[i],
						top:top + (ro.ui.relY(15) * i),
						bottom:bottom - (ro.ui.relY(13) * i)
					})));
		        }
			 };
			 return;
		  }
		  //ro.app.Store = null;
		  if(Ti.App.Properties.hasProperty('DefaultStore')){
		     var storeStr = Ti.App.Properties.getString('DefaultStore');
		     ro.app.Store = eval('('+storeStr+')');
		  }
	
		  var opened=false;
		  var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsView, {
		  	 top:0,
		     layout:'vertical'
		  }));
	
		  var tableView1 = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
			 left:ro.ui.properties.hdrViewMargins.left,
			 right:ro.ui.properties.hdrViewMargins.right,
	         backgroundColor:'white',
			 height:Ti.UI.SIZE,
			 minRowHeight:ro.ui.relY(40)
		  }));
	      var defLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	         right:ro.ui.relX(10),
	         left:ro.ui.relX(10),
	         top:ro.ui.contentsTop,
	         focusable:false
	      }));
	      defLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:'USE DEFAULT STORE:',
	         font:{
	            fontSize:ro.ui.scaleFont(15, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }
	      })));
	
			tableView2 = Ti.UI.createTableView(ro.combine(ro.ui.properties.defaultStoreTblView, {
				left:ro.ui.properties.hdrViewMargins.left,
				right:ro.ui.properties.hdrViewMargins.right,
	         backgroundColor:'white',
				height:Ti.UI.SIZE,
				minRowHeight:ro.ui.relY(40)
		  	}));
		  	var otherLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	            right:ro.ui.relX(10),
	            left:ro.ui.relX(10),
	            top:ro.ui.halfContentsTop,
	            focusable:false
	         }));
	      otherLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:otherLblViewTxt,//isGuest ? 'FIND STORE' : 'FIND ANOTHER STORE:',
	         font:{
	            fontSize:ro.ui.scaleFont(15, 0, 0),
	            fontWeight:'bold',
	         fontFamily:ro.ui.fontFamily
	         }
	      })));
	
			tableView2.addEventListener('click', function(e){
			   ro.ui.showLoader();
				var req = {};
				req.IsDelivery = false;
				req.RevKey = 'test';
				req.CompressResponse = false;
				switch(e.index){
					case 0:
						//req.Email = Ti.App.Username;
						//req.Password = Ti.App.Password;
						ro.ui.ordShowNext({ addView:true, showing:useAddrHid });
						break;
					case 1:
						try{
							if(ro.isiOS){
								
							}
							else{
								if(Ti.Geolocation.locationServicesEnabled == false){
								   Ti.API.debug('Ti.Platform.version: ' + Ti.Platform.version);
								   Ti.API.debug('Ti.Platform.version[0]: ' + Ti.Platform.version[0]);
								   if(Ti.Platform.version[0] >= 6){
		   						   Ti.Geolocation.requestLocationPermissions(null, function(e){
		   						      //Ti.API.debug('e: ' + JSON.stringify(e));
		   						      //alert('hi');
		   						      if(e && e.success){
		   						         //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
		                              Ti.Geolocation.getCurrentPosition(function(e){
		                                 if(!e.success || e.error){
		                                 	////Ti.API.debug('e - EXCEPTION: ' + JSON.stringify(e));
		                                    ro.ui.alert('Geolocation Error');
		                                    ro.ui.hideLoader();
		                                    return;
		                                 }
		                                 req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
		                                 req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
		                                 GetStoreLst(req);
		                              });
		   						      }
		   						      else{
		   						         ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
		                              ro.ui.hideLoader();
		   						      }
		   						   });
		   						}
		   						else{
		   						   ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
		                            ro.ui.hideLoader();
		   						}
									
								}
								else{
									//Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
									Ti.Geolocation.getCurrentPosition(function(e){
									   //Ti.API.debug('e: ' + JSON.stringify(e));
										if(!e.success || e.error){
										   ro.ui.alert('Geolocation Error');
										   ro.ui.hideLoader();
											return;
										}
										req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
										req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
										GetStoreLst(req);
									});
								}
							}
							break;
						}
						catch(ex){
							ro.ui.alert('geolocation', ex.message);
						}
				}
			});
			if(!isGuest){
			   view.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitleBg, {
			   	top:ro.ui.relY(10),
		          text:'Use Default Store',
		          font:ro.ui.font.pathToMenuTitles
		       })));
			   view.add(tableView1);
			}
	
			var findOtherLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitleBg, {
		         text:otherLblViewTxt,
		         top:ro.ui.relY(25),
		         font:ro.ui.font.pathToMenuTitles
		    }));
			view.add(findOtherLbl);
		      var useAddrBtn = layoutHelper.getBigButton('Use Address', true);
		      useAddrBtn.height = ro.ui.relY(64);
		      useAddrBtn.borderRadius = Ti.App.RoundedButtons ? ro.ui.relX(32) : 0;
		      useAddrBtn.addEventListener('click', function(){
		      	 ro.ui.showLoader();
		      	 ro.ui.ordShowNext({ addView:true, showing:useAddrHid });
		      });
		      useAddrBtn.top = ro.ui.relY(10);
		      useAddrBtn.bottom = null;
		      var currLocationBtn = ro.layout.getBigSecondaryButton('Current Location');
		      currLocationBtn.height = ro.ui.relY(64);
		      currLocationBtn.borderRadius = Ti.App.RoundedButtons ? ro.ui.relX(32) : 0;
		      currLocationBtn.top = ro.ui.relY(20);
		     
		      currLocationBtn.addEventListener('click', function(){
		      	var req = {};
				req.IsDelivery = false;
				req.RevKey = 'test';
				req.CompressResponse = false;
		      	if(ro.isiOS){
		      		if(Ti.Geolocation.locationServicesEnabled == false){
		      			ro.ui.alert('Geo Location', 'Location services is turned off on your device. Please turn it on to use this feature.');
		      		}
		      		else{
		      			//Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
		      			Ti.Geolocation.getCurrentPosition(function(e){
		      				if(e.coords && e.coords.longitude && e.coords.latitude){
		      					req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
		      					req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
		      					GetStoreLst(req);
		      				}
		      				else{
		      					ro.ui.alert('Geo Location', 'Unable to access your current location.');
		      				}
		      			});
		      		}
		      	}
		      	else{
			   	   	try{
			      		ro.ui.showLoader();
						if(Ti.Geolocation.locationServicesEnabled == false){
						   if(Ti.Platform.version[0] >= 6){
							   Ti.Geolocation.requestLocationPermissions(null, function(e){
							      if(e && e.success){
							         //Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
			                      	 Ti.Geolocation.getCurrentPosition(function(e){
			                            if(!e.success || e.error){
			                               ro.ui.alert('Geolocation Error');
			                               ro.ui.hideLoader();
			                               return;
			                            }
			                            req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
			                            req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
			                            GetStoreLst(req);
			                         });
							      }
							      else{
							         ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
			                     	 ro.ui.hideLoader();
							      }
							   });
							}
							else{
						  	   ro.ui.alert('Geo Location','Location services is turned off on your device. Please turn it on.');
		                	   ro.ui.hideLoader();
						    }
						}
						else{
							//Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_BEST;
							Ti.Geolocation.getCurrentPosition(function(e){
								if(!e.success || e.error){
								   ro.ui.alert('Geolocation Error');
								   ro.ui.hideLoader();
								   return;
								}
								req.Lon = Math.round(e.coords.longitude * 10000) / 10000;
								req.Lat = Math.round(e.coords.latitude * 10000) / 10000;
								GetStoreLst(req);
							});
						}
					}
					catch(ex){
						ro.ui.alert('geolocation', ex.message);
					}
				}
		      });
		      
		      view.add(useAddrBtn);
		      view.add(currLocationBtn);
		//view.add(tableView2);
	
			var theStore = null;
		 	ro.ui.refreshDefaultStore = function(){
		 		//var theStore = null;
			 	//if(ro.app.isSelectedStore){
			 		
			 		if(Ti.App.Properties.hasProperty('DefaultStore')){
			 			
			 			//theStore = eval('(' + Ti.App.Properties.getString('DefaultStore') + ')');
			 			theStore = JSON.parse(Ti.App.Properties.getString('DefaultStore'));
			 			//theStore.ISDEFAULTSTORE = true;
			 			Ti.App.Properties.setString('DefaultStore', JSON.stringify(theStore));
			 		}
			 	//}
				customer = JSON.parse(Ti.App.Properties.getString('Customer'));
			 	data = [];
			 	opened = (theStore!=null?ro.utils.isOpen(theStore):false);
	
			 	if(theStore && theStore.Configuration){
			 		statusOfStore = dateForm.storeStatus(opened, theStore?theStore:null, theStore.Configuration.AllowSameDayDefer, theStore.Configuration.AllowFutureOrders, null);
			 	}
			 	else{
			 		statusOfStore = {
			 			futureBool:false
			 		};
			 	}
	
				data[0] = Ti.UI.createTableViewRow({
					className:'defaultStore',
					left:ro.ui.relX(10),
					top:ro.ui.relY(30),
					font:{
					   fontSize:ro.ui.scaleFont(12),
						fontWeight:'bold',
	            			fontFamily:ro.ui.fontFamily
					},
					height:ro.ui.relY(70),
					isOpen:opened,
					//future:(!opened && theStore!=null && (theStore.Configuration.AllowFutureOrders || theStore.Configuration.AllowSameDayDefer) ? true : false),
					future:statusOfStore.futureBool,
                		selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
				});
	
				if(theStore!=null){
					Ti.API.info("Status of Store: " + JSON.stringify(statusOfStore));
					data[0] = ro.layout.getStoreRow(theStore, statusOfStore);
				}
				else{
					data[0].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
						text:'NO DEFAULT STORE',
						top:ro.ui.relY(5)
					})));
				}
	
				data2 = [];
			 	data2[0] = Ti.UI.createTableViewRow({
					className:'accountAddress',
					left:0,
					top:ro.ui.relY(5),
					height:ro.ui.relY(40),
					rightImage:'/images/details.png',
                		selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
				});
	
			 	data2[0].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
					text:'Use Address',
					top:ro.ui.relY(5),
					hasChild:true
				})));
	
				data2[1] = Ti.UI.createTableViewRow({
				   left:0,
					top:ro.ui.relY(5),
					rightImage:'/images/details.png',
					className:'currentLocation',
					height:ro.ui.relY(40),
                		selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
			   });
				data2[1].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreName, {
					text:'USE CURRENT LOCATION',
					top:ro.ui.relY(5),
					bottom:ro.ui.relY(5),
					color:ro.ui.theme.contentsTextColor
				})));
	
				/*var defLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
			         //right:ro.ui.relX(4),
			         top:ro.ui.contentsTop,
			         focusable:false
			      }));
			      defLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
			         text:'USE DEFAULT STORE:',
			         font:{
			            fontSize:ro.ui.scaleFont(12.5, 0, 0),
			            fontWeight:'bold',
		            	fontFamily:ro.ui.fontFamily
			         }
			      })));*/
				//tableView1.headerView = defLblView;
				tableView1.data = data;
	
				/*var otherLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
		         right:ro.ui.relX(4),
		         focusable:false
		      }));
				otherLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
		         text:'FIND ANOTHER STORE:',
		         font:{
		            fontSize:ro.ui.scaleFont(12.5, 0, 0),
		            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
		         }
				})));
				tableView2.headerView = otherLblView;*/
				tableView2.data = data2;
			};
	
	
		 	function GetStoreLst(req){
		      ro.dataservice.post(req, 'GetStores', function(response){
		         if(response){
		            if(response.Value){
		               if(response.Stores.length > 0){
		                  ro.ui.ordShowNext({addView:true, showing:'storeSelection', stores:response.Stores, geo:1});
		               }
		               else{
		               	ro.ui.hideLoader();
		                  ro.ui.alert('defaultStore', 'No Stores found for this location.');
		               }
		            }
		            else{
		            	ro.ui.hideLoader();
		               ro.ui.alert('defaultStore', response.Message + '\nCODE:500.');
		            }
		         }
		         else{
		            ro.ui.hideLoader();
		            ro.ui.alert('default Store', 'Error occured. CODE:100.');
		         }
		      });
			}
	
		   tableView1.addEventListener('click', function(e){
               ro.ui.showLoader();               
		  		if(theStore == null){
					var req = {};
					req.IsDelivery = false;
					req.RevKey = 'test';
					req.CompressResponse = false;
					req.Email = Ti.App.Username;
					req.Password = Ti.App.Password;
					ro.ui.ordShowNext({addView:true, showing:'newAddrList'});
					return;
				}
				
				ro.app.Store.ISDEFAULTSTORE = true;
	
				if(!theStore.IsMobile){
					ro.ui.alert(theStore.Name, 'The store doesn\'t allow mobile orders.');
					ro.ui.hideLoader();
					return;
				}
				
				
				if(!(REV_HEARTBEAT.checkHeartbeat(customer && customer.IsDefaultStoreOnline ? true : false, theStore.Configuration.HEARTBEAT_THRESHOLD, theStore.Configuration.HEARTBEAT_HDR, theStore.Configuration.HEARTBEAT_MSG)) || 
					!(REV_HEARTBEAT.checkOfflineOrdType(Ti.App.OrderObj.ordOnlineOptions.IsDelivery, theStore.Configuration.OFFLINE_ORDTYPE, theStore.Configuration.OFFLINE_ORDTYPE_HDR,  theStore.Configuration.OFFLINE_ORDTYPE_MSG))){
					ro.ui.hideLoader();
					return;
				}
	
				Ti.App.futureOnly = false;
				if(!e.row.isOpen && !e.row.future){
				   var message = ro.utils.nextOpenTime(theStore);
					ro.ui.alert('Store Closed',message);
					ro.ui.hideLoader();
					return;
				}
				else if(!e.row.isOpen && e.row.future){
					Ti.App.futureOnly = true;
				}
				Ti.API.debug('theStore.ID: ' + theStore.ID);
				if(ro.REV_STORES.willStoreChange(theStore.ID)){
					ro.REV_STORES.promptForChange(function(){
						ro.ui.clearCart();
						if(ro.app.isSelectedStore){
							ro.app.Store = eval('(' + Ti.App.Properties.getString('DefaultStore') + ')');
							ro.app.Store.ISDEFAULTSTORE = true;
							Ti.API.debug('ro.app.Store.ISDEFAULTSTORE: ' + ro.app.Store.ISDEFAULTSTORE);
						}
						ro.app.isSelectedStore = false;
			
						if(statusOfStore.futureBool){
							Ti.App.allowFuture = true;
							ro.ui.ordShowNext({addView:true, showing:'futOrd'});
						}
						else{
							Ti.App.allowFuture = false;
							ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
						}
					});
				}
				else{
					if(ro.app.isSelectedStore){
						
						ro.app.Store = eval('(' + Ti.App.Properties.getString('DefaultStore') + ')');
						ro.app.Store.ISDEFAULTSTORE = true;
						Ti.API.debug('ro.app.Store.ISDEFAULTSTORE: ' + ro.app.Store.ISDEFAULTSTORE);
					}
					ro.app.isSelectedStore = false;
		
					if(statusOfStore.futureBool){
						Ti.App.allowFuture = true;
						ro.ui.ordShowNext({addView:true, showing:'futOrd'});
					}
					else{
						Ti.App.allowFuture = false;
						ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
					}
				}
		  });
		  mainView.add(view);
		  return mainView;
	   };
	};
	return {
		defaultstoreview:defaultstoreview
	};
}();
module.exports = DEFAULTSTOREVIEW;
