var UI = function(){
	var getui = function(ro){
		var ui = {};
		ui.getNavBar = function(navBar, logoStyle, hdr, isLogin, dontAddEvent){
			//var navBar = Ti.UI.createView(ro.ui.properties.navBar);
			
			var addNavBarLogoToBar = function(navBarView){
				var useHdrBln = hdr && hdr.length ? true : false; 
				if(isLogin){
					var headerImg = Ti.UI.createImageView(ro.ui.properties.loginNavBarLogo);
					navBarView.add(headerImg);
				}
				else if(ro.ui.theme.bannerImg && !useHdrBln){
					var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
					if(!dontAddEvent){
					    headerImg.addEventListener('click', function(){
                           ro.ui.changeTab({
                                tabIndex:0
                             });
                        });
					}
					
					navBarView.add(headerImg);
				}
				else{
					var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl,{
					    color:'white',
					    text:hdr,
					    //top:ro.ui.relY(5),
					    font:{
					        fontSize:ro.ui.scaleFont(40),
					        fontFamily:ro.ui.fonts.titles
					    },
					    width:ro.ui.displayCaps.platformWidth / 2
					}));
					if(ro.isiphonex){
						//headerLbl.bottom = ro.ui.relY(20);
					}
		         	navBarView.add(headerLbl);
				}
			};
			
			if(logoStyle){
				var navBarParent = Ti.UI.createView(ro.ui.properties.navBarParent);
				
				//navBar.height = ro.ui.relY(35);
				navBarParent.add(navBar);
				addNavBarLogoToBar(navBarParent);
				return navBarParent;
			}
			else{
				addNavBarLogoToBar(navBar);
				return navBar;
			}
		};
		ui.getNavBarWithTitle = function(navBar, logoStyle, hdr){
			//var navBar = Ti.UI.createView(ro.ui.properties.navBar);
			
			var addNavBarLogoToBar = function(navBarView){
				var useHdrBln = hdr && hdr.length ? true : false; 
				if(false && ro.ui.theme.bannerImg && !useHdrBln){
					var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
					navBarView.add(headerImg);
				}
				else{
					var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
						color:'white',
						text:hdr,
						height:Ti.UI.FILL,
						font:{
							fontSize:ro.ui.scaleFont(17, 120, 49),
							fontWeight:'bold',
							fontFamily:ro.ui.fontFamily
						},
					}));
		         	navBarView.add(headerLbl);
				}
			};
			
			if(logoStyle){
				var navBarParent = Ti.UI.createView(ro.ui.properties.navBarParent);
				
				//navBar.height = ro.ui.relY(35);
				navBarParent.add(navBar);
				addNavBarLogoToBar(navBarParent);
				return navBarParent;
			}
			else{
				addNavBarLogoToBar(navBar);
				return navBar;
			}
		};
		ui.createStackView = function(_args){
			var stack = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, _args.props || {} ));
			stack.currentIndex = _args.currentIndex || 0;
			
			//populate stack
			for(var i=0; i<_args.views.length; i++){
				var w = _args.views[i];
				if(i == stack.currentIndex){
					w.visible = true;
				}
				else{
					w.visible = false;
				}
				stack.add(w);
			}
			stack.addEventListener('changeStkIndex', function(e){
				for(var j=0; j<e.source.children.length; j++){
					if(j == e.idx){
						e.source.children[j].visible = true;
						stack.currentIndex = j;
					}
					else{
						e.source.children[j].visible = false;										
					}
				}
				if(ro.app.isLogout){
					ro.ui.showDrawer(); 
				}
			});
			return stack;
		};
		ui.animateView = function(_args){
			try{ 
				if(_args.type == 'show'){
					_args.parent.fireEvent('changeStkIndex',{
					   idx:_args.idx
					});
					_args.view.animate({
					   duration:ro.ui.properties.animationDuration,
					   right:0
					},function(){
						ui.popView({
						   parent:_args.parent,
						   child:_args.parent.children[idx - 1]
						});					
					});
				}
				else{
					//Hide view with animation
					_args.view.animate({
					   duration:ro.ui.properties.animationDuration,
					   right:ro.ui.properties.platformWidth
					},function(){
						_args.parent.fireEvent('changeStkIndex', {
						   idx:_args.idx
						});
					});
				}
				return;
			}
			catch(ex){
				var a = Ti.UI.createAlertDialog();
				a.message = ex.message;
				a.title = 'animateView';
				a.show();
			}
		};
		ui.pushView = function(_args){
			try{
				_args.child.visible = false;
				_args.parent.add(_args.child);
			
			}
			catch(ex){
					ro.ui.alert('', ex.message);
			}
		};
		ui.popView = function(_args){
			try{
				_args.parent.remove(_args.child);
			}
			catch(ex){
				ro.ui.alert('', ex.message);
			}
		};
		ui.popViews = function(_args){
			try{
				var parent = _args.parent;
				var startIndex = _args.startIndex;
				for(var i=_args.count; i>0; i--){
					parent.remove(parent.children[startIndex]);
					startIndex--;
				}
				return parent;
			}
			catch(ex){
				ro.ui.alert('popViews', ex);	
			}
		};
		ui.emptyStack = function(_args){
			try{
				_args.source = null;
			}
			catch(ex){
				ro.ui.alert('ui', ex.message);
			}
		}; 
		ui.createFilmStripView = function(_args){//create a film strip like view
			var root = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, _args)),
			views = _args.views,
			container = Ti.UI.createView({
				top:0,
				left:0,
				bottom:0,
				width:ro.ui.properties.platformWidth * _args.views.length
			});
			for(var i=0, l=views.length; i<l; i++){
				var newView = Ti.UI.createView({
					top:0,
					bottom:0,
					left:ro.ui.properties.platformWidth * i,
					width:ro.ui.properties.platformWidth
				});
				newView.add(views[i]);
				container.add(newView);
			}
			root.add(container);
			
			//set the currently visible index
			root.addEventListener('changeIndex', function(e){
			   try{
			  	   var leftValue = ro.ui.properties.platformWidth * e.idx * -1;
				   container.animate({
					   duration:1,
					   left:leftValue
				   });
			   }
			   catch(e){
			  	   alert(e);
			   }	
			});
			return root;
		};
		ui.alert = function(/*String*/ _title, /*String*/ _message, customAlert, keepShowing){//shorthand for alert dialog
			//Ti.API.debug(_title + ' ' + _message);
			/*if(ro.isiOS){
				Ti.UI.createAlertDialog({
					title:_title, 
					message:_message
				}).show();
			}
			else{*/
				var style; 
		   		ro.windowpopup.clearWindowpopup();
		   		
		   		 style = ro.ui.properties;
		   	
		   	  	 var parentView = Ti.UI.createView(style.popupView2);
		   	  	 var shadowView = Ti.UI.createView(style.shadowView2);
		   	  	 parentView.add(shadowView);
			     //var containerView = Ti.UI.createView(style.popupContainer2);
				 var alertView = Ti.UI.createView(ro.isiOS ? style.popupAlertView2ios : style.popupAlertView2);
				 var headerLbl = Ti.UI.createLabel(style.popupHdrLbl);
				 headerLbl.top = ro.ui.relY(15);
				 alertView.add(headerLbl);
				
				 var instructionsLbl = Ti.UI.createLabel(style.popupBodyLbl);
				 alertView.add(instructionsLbl);
				
				 headerLbl.text = _title;
 				 instructionsLbl.text = _message;
				 parentView.show();
				
				 var ok = Ti.UI.createButton(style.popupButton);
				 ok.addEventListener('click', function(e) {
						//popup.hide();
						if(keepShowing){
                            ro.windowpopup.hideWindowpopup(true);
                        }
                        else{
                            ro.windowpopup.hideWindowpopup();
                        }
						//ro.windowpopup.hideWindowpopup();
				 });
				 alertView.add(ok);
				
			 	 //containerView.add(alertView);
				 //parentView.add(containerView);
				 if(customAlert){
				     parentView.add(customAlert);
				 }
				 else{
				     parentView.add(alertView);
				 }
				 
				 if(keepShowing){
				     parentView.KeepShowing = true;
				 }
				 
				 ro.ui.hideLoader();
				 ro.windowpopup.setWindowpopup(parentView, function(){
				 	//alertView.setTranslationZ(20);
				 });
				 
				 /*parentView.showAlert = function(ttl, msg){
					headerLbl.text = ttl;
					instructionsLbl.text = msg;
					parentView.show();
				 };*/
				 /*var popup = Ti.UI.createAlertDialog({
				 	androidView:parentView,
				 	width:Ti.UI.SIZE,
				 	borderRadius:ro.ui.relX(15),
				 	backgroundColor:'transparent'
				 });
				 popup.show();*/
				 /*var popup = Ti.UI.createWindow(style.popupView2);
				 popup.add(parentView);
				 popup.open();*/
			//}
			
		};
		ui.prompt = function(/*String*/ _title, /*String*/ _message){
			Ti.UI.createAlertDialog({
				title:_title, 
				message:_message
			}).show();
		};
		ui.chooseRow = function(row){
			row.hasChecked = true;
			row.rightImage = '/images/check.png';
		};
		ui.unChooseRow = function(row){
			row.hasChecked = false;
			row.rightImage = '';
		};
		ui.popup = function(title, btnArray, msg, eventFn, cancelFn, keepShowing, _specialBillingCb){
			
            /*var alertTable = Ti.UI.createTableView({
                data:alertRows,
                height:Ti.UI.SIZE,
                width:Ti.UI.FILL,
                backgroundColor:'white',
                separatorColor:'#e4e4e4'
            });*/
            
            var alertVw = Ti.UI.createView(ro.isiOS ? ro.ui.properties.popupAlertView2ios : ro.ui.properties.popupAlertView2);
            var headerRow = Ti.UI.createView({
                index:-1,
                height:Ti.UI.SIZE,
                top:0,
                width:Ti.UI.FILL,
				layout: 'vertical'
            });
            var hdrLbl = Ti.UI.createLabel({
                text:title,
                touchEnabled:false,
                font:{
                    fontFamily:ro.ui.fonts.alerts.title,
                    fontSize:ro.ui.scaleFont(35)
                },
                color:'#eb0029',
                height:ro.ui.relY(40),
                width:Ti.UI.FILL,
                //height:Ti.UI.SIZE,
                textAlign:'center',
                top:ro.ui.relY(5)
            });
            var bodyLbl = Ti.UI.createLabel({
                text:msg,
                touchEnabled:false,
                font:{
                    fontFamily:ro.ui.fonts.alerts.rowBodyTxt,
                    fontSize:ro.isiOS ? ro.ui.scaleFont(17) : ro.ui.scaleFont(19)
                },
                color:'#393839',
                height:Ti.UI.SIZE,
                left:ro.ui.relX(20),
                right:ro.ui.relX(20),
                width:Ti.UI.FILL,
                textAlign:'center',
                //top:msg&&msg.length&&msg.length > 120 ? ro.ui.relY(45) : ro.ui.relY(35),
                bottom:ro.ui.relY(10)
                
            });
            /*headerRow.add(Ti.UI.createView(ro.combine(ro.ui.properties.fullGreyBar, {
                    bottom:0,
                    touchEnabled:false
                })));*/
            headerRow.add(hdrLbl);
            headerRow.add(bodyLbl);
            alertVw.add(headerRow);
            
            if(_specialBillingCb){
                var billingTxtField = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
                    height:ro.ui.relY(40),
                    top:ro.ui.relY(10),
                    bottom:ro.ui.relY(25),//15
                    returnKeyType:Ti.UI.RETURNKEY_NEXT,
                    borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
                    width:ro.ui.properties.wideViewWidth * .85
                }));
                alertVw.add(billingTxtField);
            }
            
            //alertVw.add(alertTable);
            if(btnArray.length == 2){
            		alertVw.add(Ti.UI.createView(ro.combine(ro.ui.properties.fullGreyBar, {
            		//top:ro.ui.relY(5),
                    //bottom:0,
                    touchEnabled:false
                })));
            }
            
            var bottomButtonView = Ti.UI.createView({
                //backgroundColor:'#f2f2f2',
                //top:ro.ui.relY(5),
                width:Ti.UI.FILL,
                height:ro.ui.relY(60)//,
                //layout:'horizontal'
            });
            var btnWidth = Ti.UI.FILL;
            var bubbleBorderWidth = ro.ui.relX(2);
            var bubbleBorderColor = '#e4e4e4';
            if(btnArray.length == 2){
            	bubbleBorderWidth = 0;
            	bubbleBorderColor = 'white';
                btnWidth = '50%';//(100 * (10/21)) + "%";
                Ti.API.debug('btnWidth: ' + btnWidth);
                var cancel = Ti.UI.createView({
                    width:btnWidth,
                    height:Ti.UI.FILL,
                    left:0,
                    backgroundColor:'white'
                });
                var cancelBubble = Ti.UI.createView({
                	top:ro.ui.relY(10),
                	bottom:ro.ui.relY(10),
                	width:ro.ui.relX(95),
                	borderWidth:bubbleBorderWidth,
                	borderColor:bubbleBorderColor,
                	borderRadius:ro.ui.relY(20)
                });
                var cancelLbl = Ti.UI.createLabel({
                    touchEnabled:false,
                    text: 'Cancel',
                    textAlign:'center',
                    font:{
                        fontSize:ro.ui.scaleFont(25),
                        fontFamily:ro.ui.fonts.button
                    },
                    color:'#393839'
                });
                cancelBubble.add(cancelLbl);
                cancel.add(cancelBubble);
                if(cancelFn){
                    cancel.addEventListener('click', function(e){
                        if(keepShowing){
                            ro.windowpopup.hideWindowpopup(keepShowing);
                        }
                        else{
                            ro.windowpopup.hideWindowpopup();
                        }
                        
                        cancelFn(e);
                    });
                }
                else{
                    cancel.addEventListener('click', function(){
                        if(keepShowing){
                            ro.windowpopup.hideWindowpopup(true);
                        }
                        else{
                            ro.windowpopup.hideWindowpopup();
                        }
                    });
                }
                
                bottomButtonView.add(cancel);
                
                bottomButtonView.add(Ti.UI.createView({
                    height:Ti.UI.FILL,
                    width:ro.ui.relX(2),
                    backgroundColor:'#e4e4e4',
                    touchEnabled:false
                }));
                
            }
            var confirm;
            if(btnArray.length == 1){
            	   confirm = Ti.UI.createButton(ro.ui.properties.popupButton);
            }
            else{
            		confirm = Ti.UI.createView({
                    width:btnWidth,
                    height:Ti.UI.FILL,
                    right:0,
                    backgroundColor:'white'
                });
                var confirmBubble = Ti.UI.createView({
                	top:ro.ui.relY(10),
                	bottom:ro.ui.relY(10),
                	width:ro.ui.relX(65),
                	borderWidth:bubbleBorderWidth,
                	borderColor:bubbleBorderColor,
                	borderRadius:ro.ui.relY(20)
                });
                var confirmLbl = Ti.UI.createLabel({
                    touchEnabled:false,
                    text:'Ok',
                    textAlign:'center',
                    font:{
                        fontSize:ro.ui.scaleFont(25),
                        fontFamily:ro.ui.fonts.button
                    },
                    color:'#393839'
                });
                confirmBubble.add(confirmLbl);
                confirm.add(confirmBubble);
            }
            
                if(_specialBillingCb){
                    confirm.addEventListener('click', function(e){
                        _specialBillingCb(billingTxtField.value, function(ee){
                            if(keepShowing){
                                ro.windowpopup.hideWindowpopup(true);
                            }
                            else{
                                ro.windowpopup.hideWindowpopup();
                            }
                            eventFn(e);
                        });
                    });
                }
                else{
                    confirm.addEventListener('click', function(e){
                        //ro.windowpopup.hideWindowpopup();
                        if(keepShowing){
                                ro.windowpopup.hideWindowpopup(true);
                            }
                            else{
                                ro.windowpopup.hideWindowpopup();
                            }
                            eventFn(e);
                    });
                }
                
                bottomButtonView.add(confirm);
            
            
            alertVw.add(bottomButtonView);
            //alertVw.addEventListener('click', eventFn);
            //return alertVw;
	      
	      
	      ro.ui.alert(null, null, alertVw, keepShowing);
		};
		var test = ro;
		test.ui = {};
		test.ui = ui;
		
		//ro.ui = ui;
		
		var LOGIN = require('revmobile/ui/newAppLayout/newLoginView');
		LOGIN.loginview(test);
		
		var DB = require('classes/database');
		DB.getdb(test);
		
		var STYLE = require("revmobile/ui/style");
		STYLE.style(test);
		
		var FORMS = require("revmobile/ui/forms");
		FORMS.forms(test);
		
		var LAYOUT = require("revmobile/ui/sharedLayouts/newLayout");
		LAYOUT.layout(test);
		
		var GUEST = require("REV_GUEST");
		GUEST.guest(test);
		
		var DRAWER = require("revmobile/ui/dView");
		DRAWER.drawer(test);
		
		var POPUP = require('logic/REV_POPUP');
		POPUP.getpopup(test);
		
		//var CUSTOMALERTVIEW

		//var ORDTYPESTK
		
		//var CARTSTK
		var LOADING = require("revmobile/ui/loadingView");
		LOADING.loading(test);
		
		var APPWINDOW = require("revmobile/ui/applicationWindow");
		APPWINDOW.appwindow(test);
		
		
		
		
		ro = test;
		test = null;
	};
	return {
		getui:getui
	};
}();
module.exports = UI;
//var isKiosk = KIOSK.isKiosk();

/*Ti.include(
   '/revmobile/ui/style.js',	//DONE
   '/revmobile/ui/dView.js',	//DONE
   '/revmobile/ui/customAlertView.js',	//TODO
   '/revmobile/ui/ordTypeStk.js',	//DONE
   '/revmobile/ui/cartStk.js',	//DONE
   '/revmobile/ui/applicationWindow.js',	//DONE
    isKiosk ? '/revmobile/ui/kiosk/kioskLoginView.js' : (Ti.App.NewHungryHowiesLayout?'/revmobile/ui/newAppLayout/newLoginView.js':'/revmobile/ui/loginView.js'),	//DONE
   '/revmobile/ui/loadingView.js',	//DONE
   '/revmobile/ui/settingsStk.js',	//DONE
   '/revmobile/ui/rewardsStk.js',	//DONE
   '/logic/itemObj.js',	//DONE
   '/logic/pricing.js',	//DONE
   '/classes/database.js',	//DONE
   '/classes/ro.dataservice.js',	//DONE
   '/classes/aes.js',	//DONE
   '/classes/cryptoHelpers.js',	//DONE
   '/classes/printInfo.js'	//TODO
);*/