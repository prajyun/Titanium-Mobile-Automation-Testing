var CUSTOMALERTVIEW = function(){
	var customalertview = function(ro){
		ro.ca = (function(){
			var customView = {};
			var parentView;
			var headerLbl;
			var instructionsLbl;
			var alertView;
			var scroller;
			var ok;
			var verBilling;
			var btn;
			customView.createCustomAlert = function(){
			   parentView = Ti.UI.createView({
					top:0,
					left:0,
					right:0,
					bottom:0,
					backgroundColor:'transparent',
					visible:false
			   });
				alertView = Ti.UI.createView({
					width:ro.ui.relX(290),
					height:Ti.UI.SIZE,
					backgroundColor:'#fff',
					borderRadius:8,
					borderWidth:2,
					borderColor:'black',
					layout:'vertical'
				});
			 	topNavBar = Ti.UI.createView({
					height:ro.ui.relY(42),
					right:ro.ui.relX(2),
					left:ro.ui.relX(2),
					top:ro.ui.relY(2),
					borderRadius:4,
					backgroundColor:ro.ui.theme.headerBackgroundColor
			   });
				headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {
				   text:'',
				 	width:Ti.UI.SIZE,
				 	color:ro.ui.theme.custAlertTxt
				}));
		
				topNavBar.add(headerLbl);
				alertView.add(topNavBar);
		
				scroller = Ti.UI.createScrollView({
					//contentHeight:ro.ui.relY(200),
					//contentWidth:ro.ui.relX(283),
					height:ro.ui.relY(100),
					width:ro.ui.relX(283),
					showVerticalScrollIndicator:true,
					//top:ro.ui.relY(25),
					backgroundColor:'transparent'
				});
				instructionsLbl = Ti.UI.createLabel({
				  top:0,
				  left:ro.ui.relX(2),
				  text:'',
				  width:ro.ui.relX(283),
				  height:Ti.UI.FILL,
				  textAlign:'left',
				  font:{
				  	  fontSize:ro.ui.scaleFontY(13, 49),
		            fontFamily:ro.ui.fontFamily
				  },
				  color:'black'
				});
				scroller.add(instructionsLbl);
				alertView.add(scroller);
		
				ok = Ti.UI.createButton({
							width:ro.ui.relX(100),
							top:ro.ui.relY(5),
							height:ro.ui.relY(35),
							bottom:ro.ui.relY(5),
							color: ro.ui.theme.btnTextColor,
							title:'OK',
							backgroundImage:ro.ui.properties.defaultPath + 'normalBtn.png',
							backgroundSelectedImage:ro.ui.properties.defaultPath + 'normalBtnPress.png'
				});
				ok.addEventListener('click', function(e) {
						parentView.hide();
				});
				alertView.add(ok);
				//parentView.add(containerView);
				parentView.add(alertView);
				return parentView;
			};
		
			customView.show = function(){
			   parentView.show();
			};
		
			customView.hide = function(){
			   parentView.hide();
			};
		
			customView.showData = function(txt){
			   headerLbl.text = txt.RcptName;
			   instructionsLbl.text = txt.cpnInstructions;
			   customView.show();
			};
			customView.showQuestion = function(txxt, callBk){
				headerLbl.text = txxt;
				try{
					alertView.remove(scroller);
					alertView.remove(ok);
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('customView.showQuestion() - Removing scroller and ok - Exception: ' + ex); }
				}
		
				try{
					if(verBilling){
						alertView.remove(verBilling);
						verBilling = null;
					}
					if(btn){
						alertView.remove(btn);
						btn = null;
					}
				}
				catch(ex){
					if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('customView.showQuestion() - Removing verBilling and btn - Exception: ' + ex); }
				}
		
			   verBilling = Ti.UI.createTextField(ro.combine(ro.ui.properties.allTxtField, {
				   height:ro.ui.relY(35),
				   width:Ti.UI.FILL,
				   font:{
				      fontSize:ro.ui.scaleFont(12.5, 175, 30),
				      fontFamily:ro.ui.fontFamily
				   },
				   borderColor:ro.ui.theme.txtFldBrd,
				   borderWidth:ro.ui.relX(1),
				   borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
				   keyboardType:Ti.UI.KEYBOARD_EMAIL,
				   returnKeyType:Ti.UI.RETURNKEY_NEXT,
				   minimumFontSize:4,
				   passwordMask:'false'
				}));
				alertView.add(verBilling);
				//var sharedLayout = require('revmobile/ui/sharedLayouts/mainView');
				btn = layoutHelper.getBigButton('OK');
				btn.backgroundColor = ro.ui.theme.btnDefault;
				btn.children[0].color = ro.ui.theme.loginGray;
				btn.bottom = 0;
				btn.width = Ti.UI.FILL;
				/*btn = Ti.UI.createButton({
					width:ro.ui.relX(100),
					top:ro.ui.relY(5),
					height:ro.ui.relY(35),
					bottom:ro.ui.relY(5),
					color: ro.ui.theme.btnTextColor,
					title:'OK',
					backgroundImage:ro.ui.properties.defaultPath + 'normalBtn.png',
					backgroundSelectedImage:ro.ui.properties.defaultPath + 'normalBtnPress.png'
				});*/
				alertView.add(btn);
				//alertView.height = Ti.UI.SIZE;
				customView.show();
				callBk(btn, verBilling);
			};
		
		    return customView;
		}());
	};
	return {
		customalertview:customalertview
	};
}();
module.exports = CUSTOMALERTVIEW;
