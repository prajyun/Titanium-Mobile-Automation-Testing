
//Ti.include('/controls/timePicker.js');
var appStyle = $$;//require('/styles/style');//Ti.App.HRushStyles;
appStyle.color = {};
appStyle.font = {};
var futureTimeView = Ti.UI.createView({
   height:Ti.UI.SIZE,
   width:Ti.UI.SIZE
});
var slide_in =  Titanium.UI.createAnimation({bottom:0});
var slide_out =  Titanium.UI.createAnimation({bottom:-251});
var boundaries;
//var curTab = Ti.UI.currentTab;
//var win = Ti.UI.currentWindow;
	
var pickerView = Titanium.UI.createView({
		bottom: -251,
		height: 251
	});
	
var futureTimePicker = Titanium.UI.createPicker({
		top: 43,
		selectionIndicator: true,
		name: 'expPicker'
	});	
	
var dayCol = Titanium.UI.createPickerColumn();
var hrCol = Titanium.UI.createPickerColumn();
var minCol = Titanium.UI.createPickerColumn();
var dayArray = [];
var minArray = [];
var hrArray = [];


formDateTime(null, function (){
	if(dayArray.length){
	boundaries = dayArray[0];
	for (var i = 0; i < minArray.length; i++) {
		
		minCol.addRow(Titanium.UI.createPickerRow({
			title: minArray[i].toString(),
			id: i
		}));
	}
	
	for (var i = 0; i < hrArray.length; i++) {
		
		hrCol.addRow(Titanium.UI.createPickerRow({
			title: hrArray[i].disp,
			val: hrArray[i].val,
			id: i
		}));
	}
	
	for (var i = 0; i < dayArray.length; i++) {
			
			dayCol.addRow(Titanium.UI.createPickerRow({
				title: dayArray[i].disp,
				obj: dayArray[i],
				id: i
			}));
		}
		
		futureTimePicker.add([dayCol, hrCol, minCol]);

		pickerView.add(futureTimePicker);
		
	}
			
	});

var data = [];
var headerView = Ti.UI.createView(appStyle.headerView);
var ordTimeHeader = Ti.UI.createLabel(ro.combine(appStyle.headerTitle,{
	text:'CHOOSE YOUR ORDER TIME:',
	//font:appStyle.font.mediumTxtHeaderB,
   left:15,
   // /bottom:5,
   //color:appStyle.color.headerTitleText
  }));
headerView.add(ordTimeHeader); 	


var row1 = Ti.UI.createTableViewRow({
   //title:'Now',					
	hasChild:true,
	//className:'ordTime',
	IsDelivery:false,
	height:50,
	selectedBackgroundColor:appStyle.color.tblRowSelected,
	
});
var now = Ti.UI.createLabel({
	text: 'NOW',
	left:15,
  // top:5,
   //bottom: 5,
  // height:20,
  font:appStyle.font.mediumTxtHeaderB,
		color: appStyle.color.tblViewHead
});
row1.add(now);


if(!Ti.App.futureOnly){
data.push(row1);
data.push(createBorderRow());
}
var row2 = Ti.UI.createTableViewRow({
	      //title:'Future',
			hasChild:true,
			className:'ordTime',
			IsDelivery:true,
			height:50,
			selectedBackgroundColor:appStyle.color.tblRowSelected,
			
		});
	var futr = Ti.UI.createLabel({
	text: 'FUTURE',
	left:15,
  // top:5,
   //bottom: 5,
  // height:20,
  font:appStyle.font.mediumTxtHeaderB,
		color:appStyle.color.tblViewHead//'#534a4a'
});
row2.add(futr);
	var futureTime = Ti.UI.createLabel({
		text: '',
		font:appStyle.font.mediumTxtHeaderB,
		color: appStyle.color.headerBackgroundColor,
		visible: false,
		right: 10
	});
if(dayArray.length){
	
	row2.add(futureTime);
	data.push(row2);
}
						
var tblOrdTime = Ti.UI.createTableView({//"Choose Order Type" screen: CSS
   data:data,
   //style:Ti.UI.iPhone.TableViewStyle.PLAIN,					
	//backgroundColor:'black',//'transparent',
	rowBackgroundColor:'white',
	scrollable:false,
	height:Ti.UI.SIZE,
	 //separatorStyle: Ti.UI.iPhone.TableViewSeparatorStyle.NONE,
	//separatorColor: appStyle.color.separatorColor,
	//headerView: headerView,
	//width:270
	//left: 10,
	//right: 10,
	borderColor: appStyle.color.tblBorderColor,
	borderRadius: 1
 });
 
var futureView = Ti.UI.createView({
	layout: 'vertical',
	height: Ti.UI.SIZE,
	left: 10,
	right: 10
}); 
futureView.add(headerView);
futureView.add(tblOrdTime);
futureTimeView.add(futureView);

futureTimePicker.addEventListener('change', function(e){
	
	if(e.columnIndex === 0){
		boundaries = dayArray[e.rowIndex];
		if(futureTimePicker.getSelectedRow(1).id < boundaries.minHrIndex || futureTimePicker.getSelectedRow(1).id > boundaries.maxHrIndex){
				
				futureTimePicker.setSelectedRow(1, boundaries.minHrIndex, true);
				futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
			}
			
		else if(futureTimePicker.getSelectedRow(1).id === boundaries.minHrIndex){
			futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
		}
		
		else if(futureTimePicker.getSelectedRow(1).id === boundaries.maxHrIndex){
			futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
		}	
			
				
			
	}
	if(e.columnIndex === 1){
		if(e.rowIndex < boundaries.minHrIndex){
			futureTimePicker.setSelectedRow(1, boundaries.minHrIndex, true);
		}
		if(e.rowIndex > boundaries.maxHrIndex){
			futureTimePicker.setSelectedRow(1, boundaries.maxHrIndex, true);
		}
		if(e.rowIndex === boundaries.minHrIndex){
			futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
		}
		if(e.rowIndex === boundaries.maxHrIndex){
			futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
		}
		
	}
	if(e.columnIndex === 2){
		
		if(e.rowIndex < boundaries.minMinIndex && boundaries.minHrIndex === futureTimePicker.getSelectedRow(1).id){
			futureTimePicker.setSelectedRow(2, boundaries.minMinIndex, true);
		}
		if(e.rowIndex > boundaries.maxMinIndex && boundaries.maxHrIndex === futureTimePicker.getSelectedRow(1).id){
			futureTimePicker.setSelectedRow(2, boundaries.maxMinIndex, true);
		}
	}
	futureTime.setText(displayTime(futureTimePicker.getSelectedRow(0).id, futureTimePicker.getSelectedRow(1).id, futureTimePicker.getSelectedRow(2).id));
});




function displayTime(dateIndex, hrIndex, minIndex){
	var hr = hrArray[hrIndex].disp.split(' ')[0];
	var min = minArray[minIndex].toString()+' '+hrArray[hrIndex].disp.split(' ')[1];
	return dayArray[dateIndex].disp + ', ' + hr +':' + min;
}

function createBorderRow(){
	var BorderRow = Ti.UI.createTableViewRow({
		backgroundColor: '#ABA58F',
		height: 1,
		width: Ti.UI.FILL,
		//bottom: 0
	});
	return BorderRow;
}

