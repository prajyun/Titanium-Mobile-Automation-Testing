var ADDRESSVIEW = function(){
	var addressview = function(ro){
		ro.ui.createAddressView = function(){
			var aInfo, numRows;
	      	var rs = ro.db.getCustObj(Ti.App.Username);
	
	      	var view = Ti.UI.createScrollView(ro.combine(ro.ui.properties.contentsSmallView, {
	           top:ro.ui.relY(5),
	           layout:'vertical',
	           disableBounce:ro.isiOS ? true : false,
	   	  		contentWidth:Ti.UI.FILL,
	   	  		bottom:ro.ui.relY(70)
	      	}));
	      	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:'address', layout:'vertical'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      var noAddrLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved addresses.'}));
	
	      var addAddrBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	      addAddrBtn.addEventListener('click', function(e){
	         try{
	            if(rs.AddressCol && rs.AddressCol.length >= 5){
	               ro.ui.alert('Error: ', 'Only five addresses may be saved at any given time');
	            }
	            else{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'newAddress'});
	            }
	         }
	         catch(ex){
	            ro.ui.alert('Address Error', 'Code:110' + ex);
	         }
	      });
	      
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'address'}); });
	
	      navBar.add(btnBack);
	      navBar.add(addAddrBtn);
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, "Address List"));
	      
	      
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	
	      if(rs.AddressCol && rs.AddressCol.length > 0){
	         numRows = rs.AddressCol.length;
	      }
	      else{
	         numRows = 0;
	      }
	      
	      for(var i=0, iMax=numRows; i<iMax; i++){
	      	  var addrObject = {};
	      	  
	      	  var formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
	      	  if(rs.AddressCol[i].hasOwnProperty('SUD') && rs.AddressCol[i].SUD && rs.AddressCol[i].SUD.length){
	      	 	formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + ', #' + rs.AddressCol[i].SUD + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
	      	  }
	      	  
	      	  addrObject.formattedText = formattedAddress;
	      	  //addrObject.id = i;
	      	  addrObject.customObj = {
	      	  	id:i
	      	  };
	      	  
	      	  
	      	  view.add(ro.layout.getGenericHdrRow(rs.AddressCol[i].Label));
	      	  
	      	  var addressRow = ro.layout.getGenericRow(addrObject);
	      	  addressRow.addEventListener('click', function(e){
	      	  	try{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'editAddress', rowid:e.source.id});
	            }
	            catch(ex){
	               ro.ui.alert('Address Error', 'Code:110' + ex);
	            }
	      	  });
	      	  view.add(addressRow);
	      }
	      
	      
	      if(!rs.AddressCol.length){
	         view.add(noAddrLbl);
	      }
	
	      mainView.add(view);
	      return mainView;
		};
	   ro.ui.oldCreateAddressView = function(_args){
	      var aInfo, numRows;
	      var rs = ro.db.getCustObj(Ti.App.Username);
	
	      var view = Ti.UI.createView(ro.combine(ro.ui.properties.contentsSmallView, {
	         top:ro.ui.relY(5),
	         layout:'vertical'
	      }));
	
	
	      //var addrView =
	      var addressInfo = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
	         height:Ti.UI.SIZE,
	         top:0,
	         separatorColor:ro.ui.theme.separatorColor,
	         borderColor:ro.ui.theme.loginGray,
	         borderWidth:ro.ui.relX(1),
	         minRowHeight:ro.ui.relY(40),
	         backgroundColor:'#fff'
	      }));
	      var selectAddrLblView = Ti.UI.createView(ro.combine(ro.ui.properties.headerView, {
	         right:ro.ui.relX(10),
	         left:ro.ui.relX(10),
	         top:ro.ui.relY(12),
	         focusable:false
	      }));
	      selectAddrLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	         text:'SELECT YOUR ADDRESS:',
	         font:{
	            fontSize:ro.ui.scaleFont(15, 0, 0),
	            fontWeight:'bold',
	            fontFamily:ro.ui.fontFamily
	         }
	      })));
	         //addressInfo.headerView = selectAddrLblView;
	
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:'address', layout:'vertical'}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	      var noAddrLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:'There are no saved addresses.'}));
	
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Address'}));
	         navBar.add(headerLbl);
	      } */
	      
	      //var addAddrBtn = layoutHelper.getRightBtn('ADD ADDRESS');
	      var addAddrBtn = layoutHelper.getNewRightBtn('Add', null, "/images/addBtn.png");
	      addAddrBtn.addEventListener('click', function(e){
	         try{
	            if(rs.AddressCol && rs.AddressCol.length >= 5){
	               ro.ui.alert('Error: ', 'Only five addresses may be saved at any given time');
	            }
	            else{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'newAddress'});
	            }
	         }
	         catch(ex){
	            ro.ui.alert('Address Error', 'Code:110' + ex);
	         }
	      });
	
	      //var btnBack =  Ti.UI.createButton(ro.combine(ro.ui.properties.backBtn, {title:'Settings'}));
	      var btnBack = layoutHelper.getBackBtn('SETTINGS');
	      btnBack.addEventListener('click', function(e){ ro.ui.settingsShowNext({showing:'address'}); });
	
	      navBar.add(btnBack);
	      navBar.add(addAddrBtn);
	      mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	
	      if(rs.AddressCol && rs.AddressCol.length > 0){
	         numRows = rs.AddressCol.length;
	      }
	      else{
	         numRows = 0;
	      }
	
	      var data = [];
	
	      for(var i=0; i<numRows; i++){
	      	 var formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
	      	 //if(rs.AddressCol[i].Unit)
	      	 //Ti.API.debug('rs.AddressCol[i]: ' + JSON.stringify(rs.AddressCol[i]));
	      	 if(rs.AddressCol[i].hasOwnProperty('SUD') && rs.AddressCol[i].SUD && rs.AddressCol[i].SUD.length){
	      	 	formattedAddress = rs.AddressCol[i].StNum + ' ' + rs.AddressCol[i].St + ', #' + rs.AddressCol[i].SUD + '\n' + rs.AddressCol[i].City + ', ' + rs.AddressCol[i].State + ', ' + rs.AddressCol[i].Zip;
	      	 }
	      	 
	      	 
	         aInfo = Ti.UI.createTableViewRow(ro.combine(ro.ui.properties.proView, {
	            layout:'vertical',
	            className:'addrRow',
	            id:i,
	            height:ro.ui.relY(60),
                selectionStyle : ro.isiOS ? Titanium.UI.iOS.TableViewCellSelectionStyle.NONE : null
	         }));
	         aInfo.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.addressListHdr, {
	            text:rs.AddressCol[i].Label,
	            id:i
	         })));
	         aInfo.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.addressList, {
	            text:formattedAddress,
	            id:i
	         })));
	
	         aInfo.addEventListener('click', function(e){
	            try{
	               ro.ui.showLoader();
	               ro.ui.settingsShowNext({addView:true, showing:'editAddress', rowid:e.source.id});
	            }
	            catch(ex){
	               ro.ui.alert('Address Error', 'Code:110' + ex);
	            }
	         });
	         data.push(aInfo);
	      }
	      addressInfo.setData(data);
	
	      if(!rs.AddressCol.length){
	         view.add(noAddrLbl);
	      }
	      else{
	         view.add(selectAddrLblView);
	         view.add(addressInfo);
	      }
	
	      mainView.add(view);
	      return mainView;
	   };
	};
	return {
		addressview:addressview
	};
}();
module.exports = ADDRESSVIEW;