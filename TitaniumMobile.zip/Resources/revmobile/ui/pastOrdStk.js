(function(){
	var pastOrdStk = null;
	var shouldInclude = true;
	
	function includePastOrdFiles(){
		Ti.include('/revmobile/ui/pastOrdersView.js');
		Ti.include('/revmobile/ui/pastOrdDetailsView.js');
		shouldInclude = false;
	}
	
	ro.ui.currentPastOrdViewIdx=function(){
		return pastOrdStk.currentIndex;
	};
    ro.ui.pastOrdStkViewID = function () {
        if (pastOrdStk.hasOwnProperty('children') && pastOrdStk.children.length) {
            return pastOrdStk.children[0].hid;
        }
        else {
            return '';
        }
	   //return pastOrdStk.children[0].hid;
	};
	ro.ui.pastOrdStkSize = function(){
      return pastOrdStk.children.length;
   };
   ro.ui.remPastOrdChildren = function(){
      pastOrdStk.removeAllChildren();
   };
	
	ro.ui.createPastOrdStk = function(_args){
		 pastOrdStk = ro.ui.createStackView({
			views:[],
			props:{
				top:0,
				left:0,
				right:0,
				bottom:0
			}
		});
		
		ro.ui.pastOrdShowNext = function(e){
		  try{
		  	
		  	if(shouldInclude){
		  		includePastOrdFiles();
		  	}
		  	
		   if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
		   ro.ui.showLoader();
			var curIndex = pastOrdStk.currentIndex;
         var curView = pastOrdStk.children[curIndex];
         var nextView = null;
         var interval = 400;
         var childrenLength = pastOrdStk.children.length;
         pastOrdStk.removeAllChildren();
			
			if(e.addView){
				switch(e.showing){
				   case 'past orders':
				      nextView = ro.ui.createPastOrdersView();
				      break;
					case 'past order details':
						nextView = ro.ui.createPastOrdDetailsView({rowid:e.rowid});
						break;
				}
			}
			else{
			   switch(e.showing){
			      case 'past orders':
			         ro.ui.changeTab({
                     tabIndex:0
                  });
                  break;
               case 'past order details':
                  nextView = ro.ui.createPastOrdersView();
                  break;
			   }
			}
			
			if(nextView && nextView!=null){
            pastOrdStk.add(nextView);
            pastOrdStk.children[0].visible = true;
            ro.ui.hideLoader();
         }
		 }
		 catch(ex){
		    ro.ui.alert('Navigation Error','Code:N200');
		 }
	 };
		
		ro.ui.pastOrdRemoveView = function(e){
			pastOrdStk.remove(e.view);
			pastOrdStk.currentIndex--;
		};
		ro.ui.pastOrdReset = function(e){
			try{
				if(pastOrdStk.currentIndex!=0){
					pastOrdStk.children[0].animate({duration:50,right:0});
			 		pastOrdStk = ro.ui.popViews({
						parent: pastOrdStk,
						startIndex: pastOrdStk.children.length-1,
						count: pastOrdStk.children.length - 2
					});
					
					pastOrdStk.children[1].animate({duration:50,right:0});
					pastOrdStk.fireEvent('changeStkIndex',{idx:0});	
					}
					
			}					
		 	catch(ex){
		 		ro.ui.alert('Navigation Error','Code:N202');
			 }	 
		};
		return pastOrdStk;
	};
}());