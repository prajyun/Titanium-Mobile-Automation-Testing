(function(){
   ro.ui.getLoyaltiesGiftView = function(_args){
      try{
         var mainView = layoutHelper.getMainView('loyaltiesGift', 'LEVELUP', layoutHelper.getLogoutBtn(), null, true);
      }
      catch(ex){
         if(Ti.App.DEBUGBOOL) { Ti.API.debug('loyaltiesView()-Exception: ' + ex); }
      }
      var backBtn = layoutHelper.getBackBtn('BACK');
      backBtn.addEventListener('click', function(e){
         ro.ui.settingsShowNext({showing:mainView.hid});
      });
      mainView.children[0].add(backBtn);

      var loyaltiesGiftcardView = Ti.UI.createScrollView({
         //layout:'vertical',
         top:0,
         bottom:ro.ui.relY(110)
      });

      var forms = require('/revmobile/ui/forms');
      Ti.include('/formControls/levelupGiftcardForm.js');
      var form = forms.createForm({
         style:forms.STYLE_LABEL,
         fields:levelupGcForm.getLevelupGcForm(),
         settings:ro.ui.properties.myAccountView
      });
      form.top = ro.ui.relY(10);
      
      
      var submitBtn = layoutHelper.getBigButton('BUY AND SEND GIFT CARD');
      submitBtn.addEventListener('click', function(e){
         ro.ui.showLoader();
         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
         var values = forms.getValues(form);
         Ti.include('/validation/levelupGiftcardValidation.js');
         var success = levelupGcVal.levelupGcValidate(values);
         if(success.value){
            Ti.include('/validation/regexValidation.js');
            success = regexVal.regExValidate(values);
            if(success.value){
               req = {
                  gift_card_value_order:{
                     //merchant_id:lvlup.LU_MERCHANT_ID,       //THIS CAN BE ENABLED TO ENSURE THE GIFTCARD IS ONLY FOR THIS STORE THROUGH LEVELUP...OTHERWISE ITS A GIFT CARD USABLE THROUGH LEVELUP IN GENERAL...
                     recipient_email:values.email,
                     recipient_message:values.levelupGcMessage,
                     recipient_name:values.firstname,
                     value_amount:(values.dollarAmt*100)
                  }
               };
               var levelUp = ro.REV_LOYALTY.getCurrentLoyalty();
               levelUp.sendGift(req, function(giftcardResponse){
                  ro.ui.alert('Thank You', 'You\'ve just sent a $' + parseInt(giftcardResponse.gift_card_value_order.added_value_amount/100, 10).toFixed(2).toString() + ' Gift Card to ' + values.firstname + ' at ' + values.email + '.');
                  ro.ui.settingsShowNext({showing:mainView.hid});
               });
            }
            else{
               ro.ui.alert('Error', success.issues[0]);
               ro.ui.hideLoader();
            }
         }
         else{
            ro.ui.alert('Error', success.issues[0]);
            ro.ui.hideLoader();
         }
      });
      loyaltiesGiftcardView.add(form);
      loyaltiesGiftcardView.add(submitBtn);
      mainView.add(loyaltiesGiftcardView);
      return mainView;
   };
})();