var GUESTFINDSTOREVIEW = function(){
	var guestfindstoreview = function(ro){
	   ro.ui.getGuestFindStoreView = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      //Ti.include('/formControls/addressForm.js');
	      
	      var forms = ro.forms;
	      var addressForm = require('formControls/addressForm');
	      var addrVal = require('validation/addressValidation');
	      
	      var hid = 'guestFindStore';
	      var defaultCustomer, Id;
	      var bigBtnTxt = 'FIND STORE';
	      var backBtnTxt = 'BACK';
	      var defaultCustomer = null;
	      var Id = null;
	
	      var form = forms.createForm({
	         style:forms.STYLE_LABEL,
	         fields:addressForm.getAddrForm({guest:true}),
	         settings:ro.ui.properties.myAccountView
	      });
	
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'guestAddr', hid:hid}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);

	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      clearBtn.addEventListener('click', function(e){ form.clearFields(); });
	
	      var btnBack = layoutHelper.getBackBtn(backBtnTxt);
	      btnBack.addEventListener('click', function(e){
	         ro.ui.ordShowNext({showing:hid});
	      });
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
	
	      var btnUpdate = layoutHelper.getBigButton(bigBtnTxt);
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         //Ti.include('/validation/addressValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = forms.getValues(form);
	         ////deb.ug(values, 'values');
	         
	         var success = addrVal.addrValidate(values, null, true);
	         if(success.value){
	            formRequest(values);
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	      if(ro.isiphonex){
				var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
				var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
				var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
				navParent.add(topNav);
				bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
				navParent.add(bottomNav);
				mainView.add(navParent);
			}
			else{
				mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
			}
	      //mainView.add(btnUpdate);
	      form.container.add(btnUpdate);
	      mainView.add(form);
	      return mainView;
	   };
	   function formRequest(modifyAddrObj){
	      var req  = {}, AddressObj = {};
	      //Ti.API.debug('modifyAddrObj: ' + JSON.stringify(modifyAddrObj));
	      try{
	         var addr = modifyAddrObj.useCity ? modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.CountryCode : modifyAddrObj.zip + ', ' + modifyAddrObj.CountryCode;//', US';
	         
	         //var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.zip + ', US';
	         var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	      	if(!cfg){
	      	   cfg = {};
	      	}
	      	var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
	         
	         
			//Ti.include('/app.geo.js');
			var hrush = {
				geo:require('app.geo')
			};
			hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy/*storeObj.Configuration.AllowPCAccuracy*/);
			hrush.geo.geocode2(addr, function(addresses){
				//Ti.API.debug('addresses: ' + JSON.stringify(addresses));
				if(!addresses || !addresses.data || !addresses.data.length){//}|| !addresses.data.StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
			      	ro.ui.hideLoader();
			      	var msg = 'Please check address';
			      	if(addresses && addresses.message){
			      		msg = addresses.message;
			      	}
			      	ro.ui.alert('Error: ', msg);
			      	return;
			    }
			    
			    function getReq(addrIdx){
				    //Ti.include('/controls/addrControl.js');
				    var addrControl = require('controls/addrControl');
		              AddressObj = addrControl.formAddrObj(modifyAddrObj);
		              //AddressObj.Lat = response.results[0].geometry.location.lat;
		              //AddressObj.Lon = response.results[0].geometry.location.lng;
		              AddressObj.Lat = addresses.data[addrIdx].Lat;
		              AddressObj.Lon = addresses.data[addrIdx].Lon;
		              addrControl.getStoreList(addrControl.formRequestGS(AddressObj));
				 }
				 var GEO = require('geo');
	           	if(addresses.data.length > 1){
	           		GEO.displayList(addresses.data, getReq);
	           	}
	           	else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
	           		GEO.displayList(addresses.data, getReq);
	           	}
	           	else{
	           		getReq(0);
	           	}
	           	
			}, false, GOOG_MAPS_KEY);
			return;
	      }
	      catch(e){
	         ro.ui.alert('Error: ', e);
	      }
	   };
	};
	return {
		guestfindstoreview:guestfindstoreview
	};
}();
module.exports = GUESTFINDSTOREVIEW;