var ORDTYPENEWADDRVIEW = function(){
	var ordtypenewaddrview = function(ro){
	   var defaultCustomer = {}, Id, storeReq = {};
	   ro.ui.addNewAddr = function(_args){
	      //var forms = require('/revmobile/ui/forms');
	      var hasCustChangedToDeliveryAndNowNeedsAddress = false;
	      if(REV_ORD_TYPE.IsDeliveryWithoutAddress()){
            
            hasCustChangedToDeliveryAndNowNeedsAddress = true;
            //Ti.API.info('hasCustChangedToDeliveryAndNowNeedsAddress: ' + hasCustChangedToDeliveryAndNowNeedsAddress);
          }
          
          if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
              //Ti.API.info('Ti.App.OrderObj.Items.length: ' + Ti.App.OrderObj.Items.length);
              ro.updateCartCount(Ti.App.OrderObj.Items.length);
          }
          else{
              ro.updateCartCount(0);
          }
	      
	      var addrControl = require('controls/addrControl');
	      //ro.include('/formControls/addressForm.js');
	      var addressForm = require('formControls/addressForm');
	      var addrVal = require('validation/addressValidation');
		  var regexVal = require('validation/regexValidation');
	      
	      var hid = 'addNewAddr';
	      var saveAddrBln = true;
	      var defaultCustomer, Id;
	      var bigBtnTxt = 'SAVE & CONTINUE';
	      var backBtnTxt = 'ADDRESS SELECTION';
	      
	      //GUEST ORDERS
	      var isGuest = false;
	      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	         hid = 'newAddrList';
	         saveAddrBln = false;
	         bigBtnTxt = 'CONTINUE';
	         backBtnTxt = 'BACK';
	         isGuest = true;
	         defaultCustomer = null;
	         Id = null;
	      }//GUEST ORDERS
	      else{
	         defaultCustomer = ro.db.getCustObj(Ti.App.Username);
	         Id = defaultCustomer.AddressCol.length;
	      }
	
	      var form = ro.forms.createForm({
	         style:ro.forms.STYLE_LABEL,
	         fields:addressForm.getAddrForm({save:saveAddrBln}),
	         settings:ro.ui.properties.myAccountView
	      });
          if(!ro.isiOS){
              //form.top += ro.ui.relY(10);
          }
	      var mainView = Ti.UI.createView(ro.combine(ro.ui.properties.stretch, {name:'address', hid:hid}));
	      var navBar = Ti.UI.createView(ro.ui.properties.navBar);
	       Ti.API.info('navBar.height: ' + JSON.stringify(navBar.height));
	      /* if(ro.ui.theme.bannerImg){
	         var headerImg = Ti.UI.createImageView(ro.ui.properties.navBarLogo);
	         navBar.add(headerImg);
	      }
	      else{
	         var headerLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.headerLbl, {text:'Address Details'}));
	         navBar.add(headerLbl);
	      } */
	
	      //var clearBtn = layoutHelper.getRightBtn('CLEAR');
	      var clearBtn = layoutHelper.getNewRightBtn('Clear', null, "/images/navClear.png");
	      clearBtn.addEventListener('click', function(e){ form.clearFields(); });
	
	      var btnBack = layoutHelper.getBackBtn(backBtnTxt);
	      btnBack.addEventListener('click', function(e){
	         ro.ui.ordShowNext({showing:hid});
	      });
	      navBar.add(btnBack);
	      navBar.add(clearBtn);
			
			
			
	      var btnUpdate = layoutHelper.getBigButton(bigBtnTxt);
	      var btnWrapper = ro.layout.getBtnWrapper();
      	  btnWrapper.add(btnUpdate);
	      
	      btnUpdate.addEventListener('click', function(e){
	         ro.ui.showLoader();
	         //ro.include('/validation/addressValidation.js');
	         if(!ro.isiOS) Ti.UI.Android.hideSoftKeyboard();
	         var values = ro.forms.getValues(form);
	         var success = addrVal.addrValidate(values, defaultCustomer);
	         if(success.value){
	            //ro.include('/validation/regexValidation.js');
	            success = regexVal.regExValidate(values);
	            if(success.value){
	               formRequest(values);
	            }
	            else{
	               ro.ui.alert('Error', success.issues[0]);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	            ro.ui.alert('Error', success.issues[0]);
	            ro.ui.hideLoader();
	         }
	      });
	
	      //mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
	      
	      if(ro.isiphonex){
                var topNav = Ti.UI.createView(ro.ui.properties.iosxTopNav);
                var bottomNav = Ti.UI.createView(ro.ui.properties.iosxBottomNav);
                var navParent = Ti.UI.createView(ro.ui.properties.iosxNavParent);
                navParent.add(topNav);
                bottomNav.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
                navParent.add(bottomNav);
                mainView.add(navParent);
            }
            else{
                mainView.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle));
            }
	      
	      //mainView.add(btnUpdate);
	      form.container.add(btnWrapper);
	      mainView.add(form);
	      
	      function formRequest(modifyAddrObj){
              var req  = {}, AddressObj = {};
              try{
                 var addr = modifyAddrObj.stnumname + ', ' + modifyAddrObj.city + ', ' + modifyAddrObj.state + ', ' + modifyAddrObj.zip + ', ' + modifyAddrObj.CountryCode;//', US';
        
                var cfg = JSON.parse(Ti.App.Properties.getString('Config'));
                if(!cfg){
                   cfg = {};
                }
                var GOOG_MAPS_KEY = cfg.GOOG_MAPS_KEY ? cfg.GOOG_MAPS_KEY : null;
        
                var hrush = {
                    geo:require('app.geo')
                };
                //ro.include('/app.geo.js');
                hrush.geo.setStreetType(Ti.App.AllowLongSt, Ti.App.AllowPCAccuracy/*storeObj.Configuration.AllowPCAccuracy*/);
                hrush.geo.geocode2(addr, function(addresses){
                    //Ti.API.debug('addresses: ' + JSON.stringify(addresses));
                    if(!addresses || !addresses.data || !addresses.data.length){//}|| !addresses.data.StNumber.length || !addresses[0].Street || !addresses[0].Street.length){
                        ro.ui.hideLoader();
                        //ro.ui.alert('Error: ', 'Please check address');
                        var msg = 'Please check address';
                        if(addresses && addresses.message){
                            msg = addresses.message;
                        }
                        ro.ui.alert('Error: ', msg);
                        return;
                    }
                    
                    function getReq(addrIdx){
                        if(!addresses.data[addrIdx].StNumber || !addresses.data[addrIdx].StNumber.length){
                           ro.ui.hideLoader();
                           ro.ui.alert('Error: ', 'Street # is required');
                           return;
                        }
                        modifyAddrObj.stnum = addresses.data[addrIdx].StNumber;
                          modifyAddrObj.stname = addresses.data[addrIdx].Street;
        
                          if(addresses.data[addrIdx].City && addresses.data[addrIdx].City.length){
                            modifyAddrObj.city = addresses.data[addrIdx].City;
                          }
        
                          if(addresses.data[addrIdx].State && addresses.data[addrIdx].State.length){
                            modifyAddrObj.state = addresses.data[addrIdx].State;
                          }
        
                          if(addresses.data[addrIdx].Zip && addresses.data[addrIdx].Zip.length){
                            modifyAddrObj.zip = addresses.data[addrIdx].Zip;
                          }
                          var addrControl = require('controls/addrControl');
                        //ro.include('/controls/addrControl.js');
                      AddressObj = addrControl.formAddrObj(modifyAddrObj);
                      AddressObj.Lat = addresses.data[addrIdx].Lat;
                      AddressObj.Lon = addresses.data[addrIdx].Lon;
        
                      if(!modifyAddrObj.addrSave){
                         ro.REV_GUEST_ORDER.setGuestAddr(AddressObj);
                        addrControl.getStoreList(addrControl.formRequestGS(AddressObj), hasCustChangedToDeliveryAndNowNeedsAddress);
                      }
                      else{
                        req.UserName = Ti.App.Username;
                          req.Pass = Ti.App.Password;
                          req.RevKey = 'test';
                          req.GetStores = true;//NOT REQUIRED - BUT IS IT?
                          req.IsDelivery = Ti.App.OrderObj.ordOnlineOptions.IsDelivery;//NOT REQUIRED - BUT IS IT?
                          req.Address = AddressObj;
                          addrControl.newAddrGetStoreList(req, hasCustChangedToDeliveryAndNowNeedsAddress);
                       }
                        
                    }
                    
                    var GEO = require('geo');
                    if(addresses.data.length > 1){
                        GEO.displayList(addresses.data, getReq);
                    }
                    else if(addresses.data.length == 1 && addresses.data[0].PartialMatch){
                        GEO.displayList(addresses.data, getReq);
                    }
                    else{
                        getReq(0);
                    }
                    
                }, true, GOOG_MAPS_KEY);
                return;
              }
              catch(e){
                 ro.ui.alert('Error: ', e);
              }
           }
	      
	      return mainView;
	   };
	
	   
	};
	return {
		ordtypenewaddrview:ordtypenewaddrview
	};
}();
module.exports = ORDTYPENEWADDRVIEW;