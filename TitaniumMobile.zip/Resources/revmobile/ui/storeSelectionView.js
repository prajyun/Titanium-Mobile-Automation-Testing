//Ti.include('/formControls/fullDateForm.js');
var STORESELECTIONVIEW = function(){
	var storeselectionview = function(ro){
		ro.ui.createStoreSelectionView = function(_args){
			
			if(Ti.App.OrderObj && Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
                  //Ti.API.info('Ti.App.OrderObj.Items.length: ' + Ti.App.OrderObj.Items.length);
                  ro.updateCartCount(Ti.App.OrderObj.Items.length);
              }
              else{
                  ro.updateCartCount(0);
              }
			
			var dateForm = require('formControls/fullDateForm').dateForm(ro);
			
			var hid = _args.geo?'newAddrList':'storeSelection';
			var backBtnTxt = 'ADDRESS SELECTION';
			
			//GUEST ORDERS
	      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	         hid = 'addNewAddr';
	         
	         backBtnTxt = 'BACK';	         
	      }
	      //GUEST ORDERS
			
			
			var data = [];
			var stores = _args.stores;
			
			var checkMatchingStore = _args && _args.checkMatchingStore;
			//Ti.API.info('checkMatchingStore: ' + checkMatchingStore);
			
			if(checkMatchingStore){
				
				if(ro.app.Store){
					try{
						var foundMatchingStore = false;
						var tempZoneName, tempAddDelFee;
						//Ti.API.info('ro.app.Store: ' + JSON.stringify(ro.app.Store));
						for(var i=0, iMax=stores&&stores.length ? stores.length:0; i<iMax; i++){
							//Ti.API.info('stores['+i+']: ' + JSON.stringify(stores[i]));
							if(ro.app.Store.ID == stores[i].ID){
								tempZoneName = stores[i].ZoneName;
								tempAddDelFee = stores[i].AddDelFee;
								foundMatchingStore = true;
								break;
							}
						}
						
						if(!foundMatchingStore){
							//ro.ui.popup
							ro.ui.popup('Error', ['OK'], 'The store you had previously selected does not deliver to this address. Your cart has been cleared.', function(e) {
		                          ro.ui.clearCart();
		       
                                   ro.updateCartCount(0);
			                	}, function(){
			                    
			                }, true);
							
						}
						else{
							//store.AddDelFee, row.store.ZoneName
							var tempStore = ro.app.Store;
						  	tempStore.Menu.OnlineOptions.DelivOpts.AddDelFee = tempAddDelFee;
						  	tempStore.Menu.OnlineOptions.DelivOpts.ZoneName = tempZoneName;
						 	ro.app.Store = tempStore;
							
							REV_ORD_TYPE.setOrderObj();
						}
					}
					catch(ex){
						Ti.API.info('checkMatchingStore - Ex: ' + ex);
					}
				}
				else{
					
				}
			}
	
			try{
				var mainView = layoutHelper.getMainView(hid, 'Store Selection', null, layoutHelper.getBackBtn(backBtnTxt), true);
				mainView.bottom = ro.ui.relY(55);
				//mainView.borderColor = 'purple';
				//mainView.borderWidth = 3;
			}
			catch(ex){
				if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('defaultStoreView()-Exception: ' + ex); }
			}
	
			function addLabels(List, idx){
				var top = ro.ui.relY(25);
				var bottom = ro.ui.relY(18);
	
				for (var j=0; j<List.length; j++){
					data[idx].add(Ti.UI.createLabel(ro.combine(ro.ui.properties.lblStoreDetails, {
					   color:ro.ui.theme.contentsSmallTxt,
						text:List[j],
						top:top + (ro.ui.relY(16) * j),
						bottom:bottom - (ro.ui.relY(12) * j)
					})));
				};
				return;
			}
	
			try{
				var view = Ti.UI.createView({
					//borderColor:'blue',
					//borderWidth:3,
					width:Ti.UI.FILL,
					height:Ti.UI.SIZE,
					top:0
				});
				var store, opened;
				
					data = [];
				for(var i=0; i<stores.length; i++){
				
					opened = ro.utils.isOpen(stores[i]);
					//Ti.API.debug(i + ' is opened: ' + opened);
					//var statusOfStore = dateForm.storeStatus(opened, null, null, null, store.AllowDefer);
					/*var theRow = ro.layout.getStoreRowStoreSelect(stores[i], dateForm.storeStatus(opened, null, null, null, stores[i].AllowDefer));
					
					var statusOfStore = dateForm.storeStatus(opened, null, null, null, store.AllowDefer);
					theRow.applyProperties({
						store:stores[i],
						isOpen:opened,
						future:statusOfStore.futureBool,
						isMobile:store.IsMobile,
						storeName:store.Name
					});*/
					
					data.push(ro.layout.getStoreRowStoreSelect(stores[i], dateForm.storeStatus(opened, null, null, null, stores[i].AllowDefer)));
				}
			}
			catch(ex){
				ro.ui.alert('storeSelection', 'Error occured.' + ' CODE 200');
			}
	
	
	
			var tableView1 = Ti.UI.createTableView(ro.combine(ro.ui.properties.contentsSmallTblView, {
				data:data,
				separatorColor:'transparent',
				//borderWidth:ro.ui.relX(1),
	         //minRowHeight:ro.ui.relY(40),
	        	top:ro.ui.relY(10),
	         	backgroundColor:'transparent',
	         	left:ro.ui.relX(10),
	         	right:ro.ui.relX(10),
	         	//borderColor:ro.ui.theme.loginGray,
	         	//height:Ti.UI.SIZE
			}));
			/*var selectLblView = Ti.UI.createView({
	           right:ro.ui.relX(10),
	           left:ro.ui.relX(10),
	           focusable:false
	      	});*/
	        /*selectLblView.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.headerTitle, {
	           text:'Store Selection',
	           font:{
	              fontSize:ro.ui.scaleFont(15, 0, 0),
	              fontWeight:'bold',
	              fontFamily:ro.ui.fontFamily
	           }
	        })));*/
	         //ableView1.headerView = selectLblView;
	
			function GetStoreMenuSuccess(useSelectedStore, isStoreOnline, AddDelFee, ZoneName){
				try{
					
					if(!useSelectedStore && ro.app.isSelectedStore){
						Ti.API.debug('Chose The Default');
						ro.app.Store = eval('(' + Ti.App.Properties.getString('DefaultStore') + ')');
						
						
						
						ro.app.isSelectedStore = false;
					}
					
					
					var test = ro.app.Store;
						test.Menu.OnlineOptions.DelivOpts.AddDelFee = AddDelFee;
						test.Menu.OnlineOptions.DelivOpts.ZoneName = ZoneName;
						ro.app.Store = test;
						test = null;
						
						ro.REV_STORES.setDefaultStore(ro.app.Store, true);
					
	
				var continueToOrderTime = true;
	
	            if(Ti.App.RepeatLastOrder){
	               //Ti.include('/logic/prevOrders.js');
	                //var prevOrdRS = db.getCustObj(Ti.App.Username);
	                //var prevOrdObj = prevOrdRS.PrevOrders;
	                var prevOrdObj = Ti.App.PrevOrders;
	                if(!(prevOrders.addToCart(prevOrdObj[Ti.App.prevIdx], ro.app.Store.Menu, Ti.App.OrderObj))){
	                   ro.ui.alert('Error: ', 'This previous order is not available at this location. Try Selecting a different location.');
	                   continueToOrderTime = false;
	                }
	                else{
	                   Ti.App.RepeatLastOrder = false;
	                   ro.ui.showCart();
	                }
	                ro.ui.hideLoader();
	            }
					else if(dateForm.toFuture(ro.app.Store)){
						Ti.App.allowFuture = true;
						ro.ui.ordShowNext({addView:true, showing:'futOrd'});
					}
					else{
						Ti.App.allowFuture = false;
						ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
					}
				}
				catch(ex){
					try{
						Ti.App.allowFuture = false;
						ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
					}
					catch(eex){
						ro.ui.hideLoader();
						ro.ui.alert('storeSelection', 'Error occured.'+ 'CODE 201');
					}
				}
			}
	
			function GetStoreMenu(storeID, RevKey, isStoreOnline, AddDelFee, ZoneName){
				var req = {};
				req.RevKey = RevKey;
				req.StoreID = storeID;
				req.CompressResponse = false;
	
	         ro.dataservice.post(req, 'GetStore_Json', function(response){
	            if(response){
	               if(response.Value && response.Store){
	               	  if(!(REV_HEARTBEAT.checkHeartbeat(isStoreOnline, response.Store.Configuration.HEARTBEAT_THRESHOLD, response.Store.Configuration.HEARTBEAT_HDR, response.Store.Configuration.HEARTBEAT_MSG)) ||
					  !(REV_HEARTBEAT.checkOfflineOrdType(Ti.App.OrderObj.ordOnlineOptions.IsDelivery, response.Store.Configuration.OFFLINE_ORDTYPE, response.Store.Configuration.OFFLINE_ORDTYPE_HDR,  response.Store.Configuration.OFFLINE_ORDTYPE_MSG))){
					  	 ro.ui.hideLoader();
						 Ti.App.futureOnly = false;
						 return;
					  }
					  
					  var temp = response.Store;
					  temp.Menu.OnlineOptions.DelivOpts.AddDelFee = AddDelFee;
					  temp.Menu.OnlineOptions.DelivOpts.ZoneName = ZoneName; 
					  response.Store = temp;
					  temp = null;
					  
	                  ro.app.Store = response.Store;
					  if (response.Store.Configuration) {
						Ti.App.Properties.setString('Config', JSON.stringify(response.Store.Configuration));
					  }
	                  ro.utils.setStrProp('Store', response.Store);
	                  ro.app.isSelectedStore = true;
	                  //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
	                  GetStoreMenuSuccess(true, isStoreOnline, AddDelFee, ZoneName);
	               }
	               else{
	                  ro.ui.hideLoader();
	                  ro.ui.alert('storeSelection', response.Message + '\nCODE:500');
	               }
	            }
	            else{
	               ro.ui.hideLoader();
	               ro.ui.alert('storeSelection', 'Error occured. CODE:100.');
	            }
	         });
			}
			//view.add(selectLblView);
			view.add(Ti.UI.createLabel({
				top:ro.ui.relY(10),
				height:Ti.UI.SIZE,
	           text:'Store Selection',
	           textAlign:'center',
	           color:'#393839',
	           font:ro.ui.font.pathToMenuTitles
	        }));
			//view.add(tableView1);
			
			
			var test = Ti.App.OrderObj;
			if(!test){
				test = {};
			}
			if(!test.Customer){
				test.Customer = {};
			}
			Ti.App.OrderObj = test;
			test = null;
	
			tableView1.addEventListener('click', function(e){
				ro.ui.showLoader();
				var row = e.row;
	
				Ti.App.futureOnly = false;
				if(!row.isOpen && !row.future){
					var message = ro.utils.nextOpenTime(row.store);
					Ti.API.debug('message: ' + message);
					ro.ui.hideLoader();
					ro.ui.alert('Store Closed', message);
					return;
				}
				else if(!row.isOpen && row.future){
					Ti.App.futureOnly = true;
				}
				
	
				if(!row.isMobile){
					ro.ui.hideLoader();
					ro.ui.alert(row.storeName, 'The store doesn\'t allow mobile orders.');
					return;
				}
				/*if(!(REV_HEARTBEAT.checkHeartbeat(isStoreOnline, Store.Configuration.HEARTBEAT_THRESHOLD, Store.Configuration.HEARTBEAT_HDR, Store.Configuration.HEARTBEAT_MSG)) ||
					!()){
					ro.ui.hideLoader();
					Ti.App.futureOnly = false;
					return;
				}*/
				if(Ti.App.Properties.hasProperty('DefaultStore')){
					var defStoreObj = JSON.parse(Ti.App.Properties.getString('DefaultStore'));
					var customer = JSON.parse(Ti.App.Properties.getString('Customer'));
					/*Ti.API.debug('customer.IsDefaultStoreOnline: ' + customer.IsDefaultStoreOnline);
					Ti.API.debug('row.store.IsStoreOnline: ' + row.store.IsStoreOnline);
					Ti.API.debug('row.store: ' + JSON.stringify(row.store));*/
					if(row.store.ID == defStoreObj.ID){
						Ti.API.debug('choseTheDefaultStore');
						////deb.ug(defStoreObj, 'defStoreObj');
						if(!(REV_HEARTBEAT.checkHeartbeat(customer && customer.IsDefaultStoreOnline, defStoreObj.Configuration.HEARTBEAT_THRESHOLD, defStoreObj.Configuration.HEARTBEAT_HDR, defStoreObj.Configuration.HEARTBEAT_MSG)) ||
						!(REV_HEARTBEAT.checkOfflineOrdType(Ti.App.OrderObj.ordOnlineOptions.IsDelivery, defStoreObj.Configuration.OFFLINE_ORDTYPE, defStoreObj.Configuration.OFFLINE_ORDTYPE_HDR,  defStoreObj.Configuration.OFFLINE_ORDTYPE_MSG))){
							ro.ui.hideLoader();
							Ti.App.futureOnly = false;
							return;
						}
					}
				}
	
				var contactServer = true;
				//Ti.API.debug('//ro')
				////deb.ug(row, 'row');
				////deb.ug(row.store, 'row.store');
				if(ro.REV_STORES.willStoreChange(row.store.ID)){
					ro.REV_STORES.promptForChange(function(){
						ro.ui.clearCart();
						if(Ti.App.Properties.hasProperty('DefaultStore')){
							if(row.store.ID == eval('(' + Ti.App.Properties.getString('DefaultStore') + ')').ID){
								//selected is the same as default store.
								contactServer = false;
								ro.app.Store = JSON.parse(Ti.App.Properties.getString('DefaultStore'));
							}
						}
						
						var tests = Ti.App.OrderObj;
						tests.Customer.Distance = row.store.Distance;
						Ti.App.OrderObj = tests;
						tests = null;
						
						if(!contactServer && !ro.REV_GUEST_ORDER.getIsGuestOrder()){
							GetStoreMenuSuccess(false, row.store.IsStoreOnline, row.store.AddDelFee, row.store.ZoneName);
						}
						else{
							GetStoreMenu(row.store.ID, 'test', row.store.IsStoreOnline, row.store.AddDelFee, row.store.ZoneName);
						}
					});
				}
				else{
					if(Ti.App.Properties.hasProperty('DefaultStore')){
						if(row.store.ID == eval('(' + Ti.App.Properties.getString('DefaultStore') + ')').ID){
							//selected is the same as default store.
							contactServer = false;
							ro.app.Store = JSON.parse(Ti.App.Properties.getString('DefaultStore'));
						}
					}
					
					var tests = Ti.App.OrderObj;
					tests.Customer.Distance = row.store.Distance;
					Ti.App.OrderObj = tests;
					tests = null;
					
					if(!contactServer && !ro.REV_GUEST_ORDER.getIsGuestOrder()){
						GetStoreMenuSuccess(false, row.store.IsStoreOnline, row.store.AddDelFee, row.store.ZoneName);
					}
					else{
						GetStoreMenu(row.store.ID, 'test', row.store.IsStoreOnline, row.store.AddDelFee, row.store.ZoneName);
					}
				}
				
			});
			
			var bannerView = REV_BANNERS.getDefaultBannerView("location.png");
            bannerView.top = ro.ui.relY(5);
			
			//mainView.add(bannerView);
			
			mainView.add(view);
			mainView.add(tableView1);
			return mainView;
		};
	};
	return {
		storeselectionview:storeselectionview
	};
}();
module.exports = STORESELECTIONVIEW;