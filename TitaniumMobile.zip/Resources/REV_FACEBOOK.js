var REV_FACEBOOK = function(){
   var Init = function(){

   };
   return {
      Init: Init
   };
}();
module.exports = REV_FACEBOOK;