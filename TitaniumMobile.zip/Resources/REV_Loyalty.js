var LOYALTY = function(){
   var Loyalty = function(ro){
	   var LTY_NO_ECLUB = false; 
	   var cfg;
	   var ECLUB = {
	      EClubOptIn:0,
	      EMAIL_CLUB:false,
	      EMAIL_CLUB_TEXT:'',
	      customerDidRegister:false,
	      
	      LtyOptIn:0,
	      LTY_ENROLL_TXT:'',
	      LTY_TERMS_TXT:'',
	      LTY_ENROLL_HDR:'',
	      LTY_NO_ECLUB:false,
	      LTY_DEF_CHK:false,
	      LtyTermsChanged:false,
	      
	      LTY_LAYOUT:0,
	      LTY_PTS_EARN_HEADER:'',
	      LTY_REWARDS_EARN_HEADER:''
	   },
	   noLoyalty = false,
	   /*currentLoyalty = {
	      hasAfterAccountCreation:function(){
	         return false;
	      }
	   },*/
	   currentLoyalty = {},
	   ewomValcodes = [],
	   loyaltyCheckbox,
	   init = function(isNewAccount){
	   	  //HC_API_KEY
	      noLoyalty = false;
	      if(ro.REV_GUEST_ORDER.getIsGuestOrder()){
	         noLoyalty = true;
	      }
	      
	      ECLUB = {
	      	 //LtyOptIn:0,
	         EClubOptIn:0,
	         EMAIL_CLUB:false,
	         EMAIL_CLUB_TEXT:'',
	         customerDidRegister:false,
	         
	          LtyOptIn:0,
			  LTY_ENROLL_TXT:'',
			  LTY_TERMS_TXT:'',
			  LTY_ENROLL_HDR:'',
			  LTY_NO_ECLUB:false,
			  LTY_DEF_CHK:false,
			  LtyTermsChanged:false,
	      
		      LTY_LAYOUT:0,
		      LTY_PTS_EARN_HEADER:'',
		      LTY_REWARDS_EARN_HEADER:''
	      };
	
	      loyaltyCheckbox = null;
	      //need to reset everything when this is called since i am calling this function at New Account, Profile, and NewPayment views.
	      var EClubOptIn = 0, LtyOptIn = 0, LtyTermsChanged;
	      if(!isNewAccount){
	         var cst = JSON.parse(Ti.App.Properties.getString('Customer'));
	         if(!cst){
	            cst = {};
	         }
	         EClubOptIn = cst.EClubOptIn;
	         LtyOptIn = cst.LtyOptIn;
	         LtyTermsChanged = cst.LtyTermsChanged ? cst.LtyTermsChanged : false;
	         //Ti.API.debug('cst.EClubOptIn: ' + cst.EClubOptIn);
	      }
	      
	      if(ro.app.Store && ro.app.Store.Configuration){
	         cfg = ro.app.Store.Configuration;
	      }
	      else{
	         cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	         if(!cfg){
	            cfg = {};
	         }
	      }
	      ECLUB.EMAIL_CLUB = cfg.EMAIL_CLUB ? true : false;
	      ECLUB.EMAIL_CLUB_TEXT = cfg.EMAIL_CLUB_TEXT && cfg.EMAIL_CLUB_TEXT.length ? cfg.EMAIL_CLUB_TEXT : '';
	      ECLUB.EClubOptIn = EClubOptIn && EClubOptIn>0 ? EClubOptIn : 0;
		  
		  ECLUB.LtyOptIn = LtyOptIn && LtyOptIn>0 ? LtyOptIn : 0;
	      ECLUB.LTY_ENROLL_TXT = cfg.LTY_ENROLL_TXT && cfg.LTY_ENROLL_TXT.length ? cfg.LTY_ENROLL_TXT : '';
	      ECLUB.LTY_TERMS_TXT = cfg.LTY_TERMS_TXT && cfg.LTY_TERMS_TXT.length ? cfg.LTY_TERMS_TXT : '';
	      ECLUB.LTY_ENROLL_HDR = cfg.LTY_ENROLL_HDR && cfg.LTY_ENROLL_HDR.length ? cfg.LTY_ENROLL_HDR : '';
	      ECLUB.LTY_NO_ECLUB = cfg.LTY_NO_ECLUB ? true : false;
	      ECLUB.LTY_DEF_CHK = cfg.LTY_DEF_CHK ? true : false;
	      ECLUB.LtyTermsChanged = LtyTermsChanged;
	      
	      ECLUB.LTY_LAYOUT = cfg.LTY_LAYOUT || 0;
	      ECLUB.LTY_PTS_EARN_HEADER = cfg.LTY_PTS_EARN_HEADER && cfg.LTY_PTS_EARN_HEADER.length ? cfg.LTY_PTS_EARN_HEADER : '';
	      ECLUB.LTY_REWARDS_EARN_HEADER = cfg.LTY_REWARDS_EARN_HEADER && cfg.LTY_REWARDS_EARN_HEADER.length ? cfg.LTY_REWARDS_EARN_HEADER : '';
		  
		  
		  //Ti.API.debug('LTY_NO_ECLUB: ' + LTY_NO_ECLUB);
		  //Ti.API.debug('ECLUB: ' + JSON.stringify(ECLUB));
	   },
	   setOptOut = function(ecluboptin){
	      var test = Ti.App.OrderObj;
	      if(!test.Customer){
	         test.Customer = {};
	      }
	      test.Customer.OptOut = ecluboptin==2 ? true : false;
	      //test.OptOut =
	      Ti.App.OrderObj = test;
	      test = null;
	   },
	   setOrderObject = function(){
	      var test = Ti.App.OrderObj;
	      if(!test.Customer){
	         test.Customer = {};
	      }
	      test.Customer.OptOut = loyaltyCheckbox.theValue ? false : true;
	      Ti.App.OrderObj = test;
	      test = null;
	   },
	   setRequestObject = function(req){
	      req.EClubOptIn = loyaltyCheckbox && loyaltyCheckbox.theValue ? 1 : 2;
	      ECLUB.customerDidRegister = req.EClubOptIn;
	   },
	   getNewLoyaltyView = function(defaultChecked, LTY_ENROLL_TYPE, LtyStores){
	      /*
	      -fullView-
	               |__ -loyaltyView-
	
	       -loyaltyView-
	                  |__ -loyaltyCheckbox-  __  -loyaltyLbl-
	      */
	      //Ti.API.debug('LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	      //Ti.API.debug('LtyStores - getNewLoyaltyView(): ' + LtyStores);
	     ////Ti.API.debug('ro.ui.theme: ' + JSON.stringify(ro.ui.theme));
	      fullView = Ti.UI.createView({
	         height:ro.ui.relY(120),
	         layout:'vertical',
	         top:ro.ui.relY(15),
	         //width:ro.ui.relX(325)
	         width:ro.ui.properties.wideViewWidth
	      });
	      
	      if(isNaN(LTY_ENROLL_TYPE)){
	      	LTY_ENROLL_TYPE = 0;
	      }
	      
	      //Ti.API.debug('LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	     
	      //if(parseInt(LTY_ENROLL_TYPE,10) !== 1){
		      loyaltyView = Ti.UI.createView({
		         height:Ti.UI.FILL,
		         width:Ti.UI.FILL,
		         layout:'horizontal'
		      });
			//Ti.API.debug('ro.ui.properties.defaultEwomSwitch: ' + JSON.stringify(ro.ui.properties.defaultEwomSwitch));
			var defVal = ECLUB.EClubOptIn&&ECLUB.EClubOptIn == 1 ? true : false;
			
		      loyaltyCheckbox = Ti.UI.createView({
		      	top:ro.ui.relY(5),
		         width:ro.ui.relX(20),
         		 height:ro.ui.relY(20),
         		 borderRadius:ro.ui.relX(10),
                 borderColor:'#f2f2f2',
                 borderWidth:ro.ui.relX(2),
		         //bottom:ro.ui.relY(5),
		         //theValue:defVal,
		         OrigValue:defVal,//ECLUB.EClubOptIn&&ECLUB.EClubOptIn == 1 ? true : false
		         theValue:defVal,
		         backgroundImage:((ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1) ? "/images/switch_on.png" : "/images/switch_offFAKE.png")
		      });
		      if(defaultChecked && defaultChecked == true){
		         loyaltyCheckbox.theValue = true;
		         loyaltyCheckbox.OrigValue = true;
		         loyaltyCheckbox.backgroundImage = "/images/switch_on.png";
		      }
		      var lblColor = ro.ui.theme.privacyPolicyTxtLbl;
			  
		      var loyaltyLbl = Ti.UI.createLabel({
                text:'',
                //attributedString:attr,
                font:{
                    fontSize:ro.ui.scaleFont(16),
                    //fontWeight:'bold',
                    fontFamily:ro.ui.fonts.policyText
                },
                 height:Ti.UI.SIZE,
                 width:Ti.UI.FILL,
                 color:lblColor,
                 left:ro.ui.relX(10),
                 top:ro.ui.relX(5)
             });
		     //backgroundImage:((ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1) ? "/images/switch_on.png" : "/images/switch_offFAKE.png")
		      loyaltyLbl.addEventListener('click', function(e){
		         loyaltyCheckbox.theValue = !loyaltyCheckbox.theValue;
		         loyaltyCheckbox.backgroundImage = loyaltyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
		      });
		      loyaltyCheckbox.addEventListener('click', function(){
		      	loyaltyCheckbox.theValue = !loyaltyCheckbox.theValue;
		      	loyaltyCheckbox.backgroundImage = loyaltyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
		      });
		      var finalString = (ECLUB.EMAIL_CLUB_TEXT).replace(/(\r\n|\n|\r)/gm," ");
		      
		      var attributesCol = [];
               
		      //Ti.API.debug('1finalString: ' + finalString);
                if (finalString && finalString.length && finalString.toLowerCase().indexOf("e-mail club") >= 0) {
                    //Ti.API.debug('11finalString: ' + finalString);
                    attributesCol.push({
                        type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                        value: '#eb0029',
                        range: [finalString.toLowerCase().indexOf("e-mail club"), ("e-mail club").length]
                    });
                    var attr = Ti.UI.createAttributedString({
                        text: finalString,
                        attributes: attributesCol
                    });
                    loyaltyLbl.attributedString = attr;
                }
                else {
                    loyaltyLbl.text = finalString;
                }


		      //loyaltyLbl.attributedString = attr;
		      //loyaltyLbl.text = 
		      
		      var leftVw, rightVw;
			leftVw = Ti.UI.createView({
				//borderColor:'blue',
				//borderWidth:1,
				top:0,
				left:0,
				width:ro.ui.relX(40),
         		height:ro.ui.relY(120),
				//height:Ti.UI.FILL
			});
			
			rightVw = Ti.UI.createView({
				//borderColor:'green',
				//borderWidth:1,
				top:0,
				left:0,
				width:ro.ui.relX(274)//,
				//height:Ti.UI.FILL
			});
			
			leftVw.add(loyaltyCheckbox);
			rightVw.add(loyaltyLbl);
			
			loyaltyView.add(leftVw);
			loyaltyView.add(rightVw);
		      //loyaltyView.add(loyaltyCheckbox);
		      //loyaltyView.add(loyaltyLbl);
		      
		      
		      fullView.add(loyaltyView);
		      
		      if(parseInt(LTY_ENROLL_TYPE,10) === 1){
		      	
		      	loyaltyCheckbox.visible = false;
		      }
		      
		      if(LTY_ENROLL_TYPE && LtyStores && LtyStores.length){
		      	 var pRows = getPickerRows(LtyStores);
			  	 var LtyPicker = Ti.UI.createPicker({
					type:Ti.UI.PICKER_TYPE_PLAIN,
					height:ro.ui.relY(40),
					width:ro.ui.relX(250),
					backgroundColor:ro.ui.theme.pickerColor,
			    	bottom:ro.ui.relY(25),
			    	focusable:true,
			    	selectionOpens:true
				});
				var rowTtl = "";
				for (var i=0, iMax = pRows && pRows.length ? pRows.length : 0; i<iMax; i++) {
					//rowTtl = "";
					//Ti.API.debug('pRows['+i+']: ' + JSON.stringify(pRows[i]));
					LtyPicker.add(Ti.UI.createPickerRow({title:pRows[i].Name, id:pRows[i].Id}));
				}
			   	LtyPicker.setSelectedRow(0,0);
				
				fullView.add(LtyPicker);
			  }
		      
		  //}
		  
		  /*if(LTY_ENROLL_TYPE && LtyStores && LtyStores.length){
		  	 var LtyPicker = Ti.UI.createPicker({
				type:Ti.UI.PICKER_TYPE_PLAIN,
				height:ro.ui.relY(40),
				width:ro.ui.relX(250),
				backgroundColor:ro.ui.theme.pickerColor,
		    	bottom:ro.ui.relY(25),
		    	focusable:true,
		    	selectionOpens:true
			});
			
			for (var i=0, iMax = LtyStores && LtyStores.length ? LtyStores.length : 0; i<iMax; i++) {
				LtyPicker.add(Ti.UI.createPickerRow({title:field.data[i]}));
			}
		   	LtyPicker.setSelectedRow(0,0);
			
			fullView.add(LtyPicker);
		  }*/
		  
		  
	      
	
	      
	      return fullView;
	   },
	   isEnabled = function(){
	      return !noLoyalty && ECLUB.EMAIL_CLUB;
	   },
	   isEnabledAtPayment = function(){
	      return !noLoyalty && (ECLUB.EClubOptIn == 0 && !getCurrentLoyalty().isLU);
	   },
	   didChange = function(){
	      return (loyaltyCheckbox.theValue !== loyaltyCheckbox.OrigValue);
	   },
	   setCurrentLoyalty = function(){//DETERMINE WHICH LOYALTY PROGRAM TO USE
	   	//Ti.API.debug('noLoyalty: ' + noLoyalty);
	      if(noLoyalty){
	         /*currentLoyalty = {
	            hasAfterAccountCreation:function(){
	               return false;
	            }
	         };*/
	         currentLoyalty = {};
	         return;
	      }
		   var HC = require('REV_HONEYCOMB');
		   if(HC.Init()){
		   	//Ti.API.debug('HC it is: ' + JSON.stringify(HC));
		   	  if(!ro.app.Store && !Ti.App.Properties.hasProperty('DefaultStore')){
		   	  	 //return;
		   	  }
		   	  //var storeObj = JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}'));
		   	  
		      currentLoyalty = HC;
		      ro.utils.removeProp('LU_ACCESS_TOKEN');
		      return;
		   }
		   else{
		   	HC = null;
		   }
	      
	      var levelup = require('LevelUp');
	      levelup.Init();
	      
	      if(levelup.isSiteRewardsCapable()){
	         currentLoyalty = levelup;
	      }
	      else{
	         levelup = null;
	         currentLoyalty = require('EWOM');
	      }
	   },
	   getCurrentLoyalty = function(){
	      if(noLoyalty){
	         return {
	         	isValidCode: function(){
	         		return false;
	         	}
	         };
	      }
	      
	      if(ECLUB.EMAIL_CLUB || ECLUB.LTY_NO_ECLUB){
	         return currentLoyalty;
	      }
	      else{
	         return {
	         	isValidCode: function(){
	         		return false;
	         	}
	         };
	      }
	   },
	   
	   afterAccountCreation = function(){//WHAT TO DO AFTER NEW ACCOUNT CREATION...DEFAULT IS FIRING THE LOGIN EVENT
	      try{
	         if(isEnabled() && ECLUB.customerDidRegister == 1 && currentLoyalty.afterAccount){//currentLoyalty && currentLoyalty.hasAfterAccountCreation && currentLoyalty.hasAfterAccountCreation()){   
	            //Ti.API.debug('in the ifffff');
	            currentLoyalty.afterAccount();
	         }
	         else{
	         	//Ti.API.debug('in the elseeeee');
	            //Ti.API.debug('currentLoyalty.afterAccount: '  + currentLoyalty.afterAccount);
	            //Ti.API.debug('currentLoyalty.afterAccount: '  + currentLoyalty.hasAfterAccountCreation);
	            Ti.App.fireEvent('app:login.success');
	         }
	      }
	      catch(ex){
	         Ti.API.debug('ex: ' + ex);
	         Ti.App.fireEvent('app:login.success');
	      }
	   },
	   getEClubOptIn = function(){
	      var cust = JSON.parse(Ti.App.Properties.getString('Customer'));
	      if(!cust){
	         cust = {};
	      }
	      return cust.EClubOptIn || 0;
	   },
	   codeCheck = function(code){
	   	  if(Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length>0){
	         for(var idx=0, max=Ti.App.OrderObj.Cpns.length; idx<max; idx++){
	            if (Ti.App.OrderObj.Cpns[idx].hasOwnProperty('LoyaltyCode') && Ti.App.OrderObj.Cpns[idx].LoyaltyCode.toLowerCase() == code.toLowerCase()){
	               /*a.title = 'Reward Applied';
	                a.message = 'Reward has already been applied to your order.';
	                a.show();*/
	               ro.ui.alert('Reward Applied', 'Reward has already been applied to your order.');
	               return false;
	            }
	         }
	      }
	      if(Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
	      	 //Ti.API.debug('code: ' + code);
	      	 for(var i=0, iMax=Ti.App.OrderObj.Items.length; i<iMax; i++){
	      	 	//Ti.API.debug('Ti.App.OrderObj.Items[i].CpnObj.LoyaltyCode: ' + Ti.App.OrderObj.Items[i].CpnObj.LoyaltyCode);
	      	 	if(Ti.App.OrderObj.Items[i].hasOwnProperty('CpnObj') && Ti.App.OrderObj.Items[i].CpnObj.hasOwnProperty('LoyaltyCode') && Ti.App.OrderObj.Items[i].CpnObj.LoyaltyCode.toLowerCase() == code.toLowerCase()){
	      	 		
	      	 		ro.ui.alert('Reward Applied', 'Reward has already been applied to your order.');
	                return false;
	      	 	}
	      	 }
	      }
	      return true;
	   },
	   cpnObjCheck = function(obj){
	   	  if(Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length>0){
	         for(var idx=0, max=Ti.App.OrderObj.Cpns.length; idx<max; idx++){
	            if (Ti.App.OrderObj.Cpns[idx].CpnType == 2 && obj.CpnType == 2) {
	               /*a.title = 'Coupon Not Valid';
	               a.message = obj.Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.';
	               a.show();*/
	               ro.ui.alert('Reward Not Valid', obj.Name + ' cannot be applied to your order. Only one percent off coupon allowed per order.');
	               return false;
	            }
	         }
	      }
	      if(Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length){
	      	 for(var i=0, iMax=Ti.App.OrderObj.Items.length; i<iMax; i++){
	      	 	if(Ti.App.OrderObj.Items[i].hasOwnProperty('CpnObj') && Ti.App.OrderObj.Items[i].CpnObj.CpnType == 2 && obj.CpnType == 2){
	      	 		ro.ui.alert('Reward Not Valid', 'Reward has already been applied to your order.');
	                return false;
	      	 	}
	      	 }
	      }
	      return true;
	   },
	   isValidCode = function(code){
	       if(cfg.CP_APIKEY && cfg.CP_APIKEY.length && code && code.length>2){
	           var testCode = code[0] + code[1];
	           if(testCode.toLowerCase() != "hc" && testCode.toLowerCase() != "ew"){
	               return true;
	           }
	       }
	       
	   	  if(getCurrentLoyalty().isEWOM){
	   	  	 if(code.length <= 10){
		        return false;
		     }	
		     var ewTest = code[code.length-2] + code[code.length-1];
		     if(ewTest.toLowerCase() != 'ew'){
		        return false;
		     }
		     return true;
	   	  }
	   	  else if(getCurrentLoyalty().isHC){
	   	  	 if(!code || !code.length){
			    //Ti.API.debug('!code: ' + code);
		 	    return false;
		     }
	         var hcTest = code[0] + code[1];
	      	 //Ti.API.debug('code: ' + JSON.stringify(code));
	      	 //Ti.API.debug('hcTest: ' + JSON.stringify(hcTest));
	      	 
	 	     //var hcTest = code[0] + code[1];
	      
	    	 if(hcTest.toLowerCase() != 'hc'){
	        	return false;
	      	 }
	      	 return true;
	   	  }
	   	  else{
	   	  	return false;
	   	  }
	   },
	   validateCoupon = function(code, storeid, _callback, isCouponViewFromCart, _callbackTwo, _callbackThree){
	   	  if(!codeCheck(code)){
	         ro.ui.hideLoader();
	         return;
	      }
	      
	      var errorHdr, errorOne, errorTwo;
	      var successOne;
	      var setLtyCode;
	   	
	   	  var currLoyalty = getCurrentLoyalty();
	   	  //var isHC = currLoyalty.isHC;
	   	  
	   	  var req = {
	         RevKey:'test',
	         CompressResponse:false,
	         CouponCode:code,
	         StoreID:storeid,
	         LtyDiscountType:1
	      };
	      setLtyCode = function(){
	          
	      };
	      if(currLoyalty.isHC){
	      	 req.Email = Ti.App.Username;
	         req.Ord = Ti.App.OrderObj;
	         
	         errorHdr = 'Reward Not Valid';
	         errorOne = 'No Reward Found';
	         errorTwo = 'No Reward Found';
	         
	         successOne = 'Reward was added to your order!';
	         
	         setLtyCode = currLoyalty.setHcCode || function(){
	             
	         };
	      }
	      else if(currLoyalty.isEWOM){
	      	 errorHdr = 'Coupon Not Valid';
		     errorOne = 'No eWordOfMouth coupon found';
		     errorTwo = 'No eWordOfMouth coupon found';
		     
		     successOne = 'Coupon was added to your order!';
		     
		     setLtyCode = currLoyalty.setEwomCode || function(){
                 
             };
	      }
	      var dynamicCodeFallback = false;
	      if(cfg.CP_APIKEY != null && cfg.CP_APIKEY.length){
	          var hcTest = code[0] + code[1];
              if(hcTest.toLowerCase() != 'hc' && hcTest.toLowerCase() != 'ew'){
                 req.LtyDiscountType = 3;
                 dynamicCodeFallback = _callbackThree;
              }
	      }
	      
	      ro.dataservice.post(req, 'ValidateCoupon', function(response){
	      	//Ti.API.debug('response: ' + JSON.stringify(response));
	         if(response){
	            Obj = response;
	            if(Obj.Value){
	            	if(Obj.hasOwnProperty('CpnObj')){
	            	   if(!cpnObjCheck(Obj.CpnObj)){
		               	  ro.ui.hideLoader();
		               	  return;
		               }
		               Obj.CpnObj.LoyaltyCode = code;
		               
		               setLtyCode(/*Obj.CpnObj.ValCode*/code);
		               
		               var test = Ti.App.OrderObj;
		               if(!test.Cpns){
		                  test.Cpns = [];
		               }
		               test.Cpns.push(Obj.CpnObj);
		               Ti.App.OrderObj = test;
		               test = null;
		
		               if(isCouponViewFromCart){
		               	ro.ui.hideLoader();
		                  
                                ro.ui.popup('Success: ', ['OK'], successOne, function(e) {
                                    if (e.source.index === -1 || e.index === -1) {
                                        return;
                                    }

                                    if (e.index === 0) {
                                        ro.ui.reloadCart();
                                        ro.ui.cartShowNext({
                                            showing: 'Coupons',
                                            reprice: true
                                        });
                                    }
                                    ro.windowpopup.hideWindowpopup();
                                }); 

		               }
		               else{
		               	  ro.ui.hideLoader();
		                  ro.ui.alert('Success', successOne);
		                  if(_callback){
		                  	 _callback();
		                  }
		               }
	            	}
	            	else{
	            		
		            	setLtyCode(/*Obj.ValCode*/code);
		            	if(currLoyalty.isHC && _callbackTwo){
		            		_callbackTwo(Obj.ValCode && Obj.ValCode.length ? Obj.ValCode : "", code);
		            	}
		            	else{
		               	   _callback(Obj.ValCode, code);
		                }
		            }
	            }
	            else{
	                if(dynamicCodeFallback){
	                    dynamicCodeFallback();
	                    ro.ui.hideLoader();
	                    return;
	                }
	               if(Obj.hasOwnProperty('Message')){
	               	  errorOne = Obj.Message;
	               }
	               ro.ui.alert(errorHdr, errorOne);
	               ro.ui.hideLoader();
	            }
	         }
	         else{
	             if(dynamicCodeFallback){
                        dynamicCodeFallback();
                        ro.ui.hideLoader();
                        return;
                    }
	         	ro.ui.alert(errorHdr, errorTwo);
	            ro.ui.hideLoader();
	         }
	      });
	      
	   },
	   //DEV
	   newLoyaltyPolicyCheckbox,
	   LtyPicker,
	   theView,
	   webWindowNeedsClear = false,
	   needsRst = false,
	   webView,
	   setLtyStoreID = function(req, LTY_ENROLL_TYPE){
	   	  //if(LtyPicker){
	   	  	if(LTY_ENROLL_TYPE == 1){
	   	  		//var selRow = LtyPicker.getSelectedRow(0);
	   	  		var selRow = ro.forms.getValues(LtyPicker);
	   	  		Ti.API.debug("selRow: " + JSON.stringify(selRow));
	   	  		if(selRow && selRow.ltyStoreData && selRow.ltyStoreData.IsValidRow){
	   	  			req.LtyStoreID = selRow.ltyStoreData.id;
	   	  			req.LtyOptIn = 1;
	   	  		}
	   	  		else{
	   	  			//if(req.LtyOptIn)
	   	  				req.LtyOptIn = 2;
	   	  				//delete req.LtyOptIn;
	   	  		}
	   	  		//req.LtyStoreID = LtyPicker.getSelectedRow(0);
	   	  	}
	   	  	else if(LTY_ENROLL_TYPE == 2){
	   	  		
	   	  		//alert("selRow: " + JSON.stringify(selRow));
	   	  		if(newLoyaltyPolicyCheckbox.theValue && LtyPicker.visible){
	   	  			//var selRow = LtyPicker.getSelectedRow(0);
	   	  			var selRow = ro.forms.getValues(LtyPicker);
	   	  			Ti.API.debug("selRow: " + JSON.stringify(selRow));
	   	  			if(selRow && selRow.ltyStoreData && selRow.ltyStoreData.IsValidRow){
	   	  				req.LtyStoreID = selRow.ltyStoreData.id;
	   	  				req.LtyOptIn = 1;
	   	  			}
	   	  			else{
	   	  				//if(req.LtyOptIn)
	   	  					req.LtyOptIn = 2;
	   	  					//delete req.LtyOptIn;
	   	  			}
	   	  		}
	   	  		else{
	   	  			
	   	  		}
	   	  	}
	   	  	 
	   	  //}
	   },
	   setRequestObjectNoEclub = function(req){
	      req.LtyOptIn = newLoyaltyPolicyCheckbox && newLoyaltyPolicyCheckbox.theValue ? 1 : 2;
	      ECLUB.customerDidRegister = req.LtyOptIn;
	   },
	   getLtyOptIn = function(){
	      var cust = JSON.parse(Ti.App.Properties.getString('Customer'));
	      if(!cust){
	         cust = {};
	      }
	      return cust.LtyOptIn || 0;
	   },
	   getNewLoyaltyPolicyView = function(thisView, isNewAccount, isPaymentScreen, LTY_ENROLL_TYPE, LtyStores, updateCust, dontRoundCorners){
	   	  
	   	  var pWidth = Ti.Platform.displayCaps.platformWidth;
	   	  var pHeight = Ti.Platform.displayCaps.platformHeight;
	   	  
	   	  var fullViewBg, fullViewTop, switchLeft;
	   	  if(Ti.Platform.name === 'iPhone OS'){
	   	  	 /*var appStyle = require('/styles/style');
	   	  	 var ro = {
	   	  	 	ui:appStyle
	   	  	 };
	   	  	 fullViewBg = '#eeece6';
	   	  	 alert(ro.ui.relX(5));*/
	   	  }
	   	  else{
	   	  	
	   	  	 fullViewBg = ro.ui.theme.btnDefault;
	   	  }
	   	  
	   	  
	   	  
	   	  var isChecked = false;
	   	  var switchDict;
	      if(isNewAccount){
	      	 isChecked = ECLUB.LTY_DEF_CHK ? true : false;
	      	 switchDict = {
		         top:ro.ui.relY(5),
		         width:ro.ui.relX(20),
         		 height:ro.ui.relY(20),
         		 borderRadius:ro.ui.relX(10),
                 borderColor:'#f2f2f2',
                 borderWidth:ro.ui.relX(2),
		         theValue:isChecked,
		         backgroundImage:(isChecked ? "/images/switch_on.png" : "/images/switch_offFAKE.png")
		      };
	      }
	      else if(isPaymentScreen){
	      	 switchDict ={
		         top:ro.ui.relY(5),
		         width:ro.ui.relX(20),
         		 height:ro.ui.relY(20),
         		 borderRadius:ro.ui.relX(10),
                 borderColor:'#f2f2f2',
                 borderWidth:ro.ui.relX(2),
		         theValue:false,
		         OrigValue:false,
		         backgroundImage:"/images/switch_offFAKE.png"
		      };
	      }
	      else{
	      	 switchDict = {
		         top:ro.ui.relY(5),
		         width:ro.ui.relX(20),
        		 height:ro.ui.relY(20),
        		 borderRadius:ro.ui.relX(10),
                 borderColor:'#f2f2f2',
                 borderWidth:ro.ui.relX(2),
		         theValue:((ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1) ? true : false),
		         OrigValue:((ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1) ? true : false),
		         backgroundImage:((ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1) ? "/images/switch_on.png" : "/images/switch_offFAKE.png")
		      };
	      }
	   	  
	   	  /*var switchDict = ro.combine(ro.ui.properties.defaultSwitch, {
	         height:Ti.UI.FILL,
	         left:ro.ui.relX(5),
	         theValue:ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1 ? true : false,
	         OrigValue:ECLUB.LtyOptIn&&ECLUB.LtyOptIn == 1 ? true : false
	      });*/
	      var fullViewDict = {
	      	 height:ro.ui.relY(120),
	         layout:'vertical',
	         top:ro.ui.relY(15),
	         width:ro.ui.properties.wideViewWidth
	         //width:ro.ui.relX(325)
	      };
	   	  
	   	  theView = thisView;
	      var newLoyaltyPolicyView = Ti.UI.createView({
	         height:ro.ui.relY(120),
	         width:Ti.UI.FILL,
	         layout:'horizontal'
	      });
	
	      
		  
	      newLoyaltyPolicyCheckbox = Ti.UI.createView(switchDict);
	      
	      if(updateCust){
	      	newLoyaltyPolicyCheckbox.addEventListener('change', function(e){
	      		REV_CUSTOMER.changeLtyOptIn(e.theValue ? 1 : 2, true, function(){});
	      	});
	      	
		   }
	      
	      var newLoyaltyPolicyLbl = getFixedLabel();
	      newLoyaltyPolicyLbl.addEventListener('link', function(e){
	      	 needsRst = true;
	      	 var url = Ti.App.websiteURL + 'Common/LtyTermsPolicy';
	      	 //Ti.API.debug('url: ' + url);
	      	 openWebview(url);
	      });
	      
				      
			//newLoyaltyPolicyView.add(newLoyaltyPolicyCheckbox);
			//newLoyaltyPolicyView.add(newLoyaltyPolicyLbl);
			var leftVw, rightVw;
			leftVw = Ti.UI.createView({
				//borderColor:'blue',
				//borderWidth:1,
				top:0,
				left:0,
				width:ro.ui.relX(40),
         		height:ro.ui.relY(120),
				//height:Ti.UI.FILL
			});
			
			rightVw = Ti.UI.createView({
				//borderColor:'green',
				//borderWidth:1,
				top:0,
				left:0,
				width:ro.ui.relX(274)//,
				//height:Ti.UI.FILL
			});
			
			leftVw.add(newLoyaltyPolicyCheckbox);
			rightVw.add(newLoyaltyPolicyLbl);
			
			newLoyaltyPolicyView.add(leftVw);
			newLoyaltyPolicyView.add(rightVw);
			
	      fullView = Ti.UI.createView(fullViewDict);
	      
	      //Ti.API.debug('b4 - LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	      //Ti.API.debug('LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	      if(isNaN(LTY_ENROLL_TYPE)){
	      	LTY_ENROLL_TYPE = 0;
	      }
	      
	      //Ti.API.debug('after - LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	      fullView.add(newLoyaltyPolicyView);
	      
	      if(parseInt(LTY_ENROLL_TYPE,10) === 1){
	      	
	      	newLoyaltyPolicyCheckbox.visible = false;
	      	newLoyaltyPolicyCheckbox.theValue = true;
	      	isChecked = true;
	      }
	      else{
	      	newLoyaltyPolicyLbl.addEventListener('click', function(e){
		    	newLoyaltyPolicyCheckbox.theValue = !newLoyaltyPolicyCheckbox.theValue;
		    	//loyaltyCheckbox.theValue = !loyaltyCheckbox.theValue;
		      	newLoyaltyPolicyCheckbox.backgroundImage = newLoyaltyPolicyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
		    });
		    newLoyaltyPolicyCheckbox.addEventListener('click', function(e){
		    	newLoyaltyPolicyCheckbox.theValue = !newLoyaltyPolicyCheckbox.theValue;
		    	//loyaltyCheckbox.theValue = !loyaltyCheckbox.theValue;
		      	newLoyaltyPolicyCheckbox.backgroundImage = newLoyaltyPolicyCheckbox.theValue ? "/images/switch_on.png" : "/images/switch_offFAKE.png";
		    });
	      }
	      
	      ////Ti.API.debug('LTY_ENROLL_TYPE: ' + LTY_ENROLL_TYPE);
	      	////Ti.API.debug('LtyStores: ' + LtyStores);
	      
	      if(LTY_ENROLL_TYPE && LtyStores && LtyStores.length){
	          var _plF = function(){
	              newLoyaltyPolicyLbl.removeEventListener('postlayout', _plF);
	              leftVw.height = newLoyaltyPolicyLbl.rect.height + ro.ui.relY(10);
	              rightVw.height = newLoyaltyPolicyLbl.rect.height + ro.ui.relY(10);
	              newLoyaltyPolicyView.height = newLoyaltyPolicyLbl.rect.height + ro.ui.relY(10);
	          };
	      	newLoyaltyPolicyLbl.addEventListener('postlayout', _plF);
	      	 
	      	 
	      	 //var pRows = getPickerRows(LtyStores);
	      	 Ti.API.info('LOOOOK HERE LtyStores: ' + JSON.stringify(LtyStores));
	      	 var LtyStoresForm = require('formControls/loyaltyStoresForm').getForm(getPickerRows(LtyStores));
	      	 LtyPicker = ro.forms.createForm({
		         style:ro.forms.STYLE_LABEL,
		         fields:LtyStoresForm,
		         settings:ro.ui.properties.myAccountView
		      });
		      LtyPicker.height = Ti.UI.SIZE;
		      LtyPicker.bottom = null;
		      LtyPicker.top = ro.ui.relY(5);
		  	 /*LtyPicker = Ti.UI.createPicker({
		  	     top:ro.ui.relY(10),
				type:Ti.UI.PICKER_TYPE_PLAIN,
				height:isChecked ? ro.ui.relY(40) : 0,
				width:ro.ui.relX(250),
				backgroundColor:ro.ui.theme.pickerColor,
		    	//bottom:ro.ui.relY(25),
		    	focusable:true,
		    	selectionOpens:true,
		    	visible:isChecked
			});*/
			var rowTtl = "";
			/*for (var i=0, iMax = pRows && pRows.length ? pRows.length : 0; i<iMax; i++) {
				LtyPicker.add(Ti.UI.createPickerRow({title:pRows[i].Name, id:pRows[i].Id, IsValidRow:pRows[i].IsValidRow}));
			}*/
		   	//LtyPicker.setSelectedRow(0,0);
			
			newLoyaltyPolicyCheckbox.addEventListener('change', function(e){
				//Ti.API.debug('e: ' + JSON.stringify(e));
				////deb.ug(e, 'e');
	      		
	      		LtyPicker.height = e.theValue ? ro.ui.relY(40) : 0;
	      		LtyPicker.visible = e.theValue;
	        });
			fullView.height = Ti.UI.SIZE;
			fullView.add(LtyPicker);
		  }
	      
	      
	      
	      
	      //Ti.API.debug('returning');
	      //fullView.add(linkView);
	      return fullView;
	   },
	   getPickerRows = function(LtyStores){
	   	  var rows = [];
	   	  var rowObj = {
	   	  	Name:"",
	   	  	Id:null,
	   	  	IsValidRow:false
	   	  };
	   	  
	   	  var defString = cfg && cfg.LTY_STORES_HDR && cfg.LTY_STORES_HDR.length ? cfg.LTY_STORES_HDR : "--Select your home store --";
	   	  rowObj.Name = defString;
	   	  rowObj.Id = -1;
	   	  rowObj.IsValidRow = false;
	   	  
	   	  rows.push(rowObj);
	   	  for (var i=0, iMax = LtyStores && LtyStores.length ? LtyStores.length : 0; i<iMax; i++) {
	   	  	 //rowString = "";
	   	  	 rowObj = {
	   	  	 	Name:"",
	   	  	 	Id:null,
	   	  	 	IsValidRow:false
	   	  	 };
	   	  	 rowObj.Name = LtyStores[i].Name;
	   	  	 rowObj.Id = LtyStores[i].ID;
	   	  	 rowObj.IsValidRow = true;
	   	  	 rows.push(rowObj);
	   	  }
	   	  
	   	  return rows;
	   },
	   openWebview = function(url){
	   		try{
	   			var webWindow, openWindow = false;
	   			if(theView){
	   				webWindowNeedsClear = true;
	   				//Ti.API.debug('theView: ' + JSON.stringify(theView));
	   				webWindow = theView;
	   				webWindow.height = Ti.UI.FILL;
	   				
	   			}
	   			else{
	   				openWindow = true;
	   				/*webWindow = Ti.UI.createWindow(ro.combine(ro.ui.properties.stretch, {
						layout:'vertical'
					}));*/
					webWindow = Ti.UI.createWindow({
						layout:'vertical',
						top:0,
						bottom:0,
						right:0,
						left:0
					});
	   			}
				webView = Ti.UI.createWebView({url:url});
				
				if(ro.isiOS){
				}
				else{
					var navBar = Ti.UI.createView(ro.ui.properties.navBar);
					webWindow.add(ro.ui.getNavBar(navBar, Ti.App.logoStyle, ECLUB.LTY_ENROLL_HDR));
					
					webWindow.addEventListener('androidback', function(e){
						webView.release();
						if(openWindow){
							webWindow.close();
						}
						else{
							webWindow.height = 0;
						}
						
					});
				}
				
				webWindow.add(webView);
				if(openWindow){
					webWindow.open();
				}
			}
			catch(ex){
				Ti.API.debug('openWebview() - Exception: ' + ex);
			}
		},
	   getFixedLabel = function(){
	   	   var strObj = splitLtyString(ECLUB.LTY_TERMS_TXT);
	   	   //Ti.API.debug('strObj: ' + JSON.stringify(strObj));
	   	   var beforeLength = strObj.beforeTxt.length;
	   	   var linkLength = strObj.linkTxt.length;
	   	   var finalString = strObj.beforeTxt + strObj.linkTxt + strObj.afterTxt;
		   
	       //Ti.API.debug('finalString: ' + finalString);
	       var attributesCol = [{
	            type:Ti.UI.ATTRIBUTE_LINK,
	            value:'',
	            range: [beforeLength, linkLength]
	       }];
	       attributesCol.push({
	          type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                value: '#eb0029',
                range: [beforeLength, linkLength] 
	       });
	       attributesCol.push({
              type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                value: '#eb0029',
                range: [beforeLength, linkLength] 
           });
           attributesCol.push({
                type: Ti.UI.ATTRIBUTE_FONT,
                value: {
                    fontSize: ro.ui.scaleFont(16),
                    fontFamily:ro.ui.fonts.policyLink
                    //fontWeight: 'normal'
                },
                range: [beforeLength, linkLength]
            });
            //Ti.API.debug('2finalString: ' + finalString);
            if(cfg.LTY_ENROLL_HDR && cfg.LTY_ENROLL_HDR.length && finalString && finalString.length && finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase()) >= 0){
                attributesCol.push({
                  type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
                    value: '#eb0029',
                    range: [finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase()), cfg.LTY_ENROLL_HDR.length] 
               });
            }
            
            //Ti.API.debug('22finalString: ' + finalString);
            //Ti.API.debug('cfg.LTY_ENROLL_HDR: ' +  cfg.LTY_ENROLL_HDR);
            //Ti.API.debug('finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase(): ' + finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase()));
                       // Ti.API.debug('finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase(): ' + JSON.stringify(finalString.toLowerCase().indexOf(cfg.LTY_ENROLL_HDR.toLowerCase())));
            
            
	       var attr = Ti.UI.createAttributedString({
		      text:finalString,
		      attributes:attributesCol
		   });
		   
		   var lblColor;
		    if(false && Ti.Platform.name === 'iPhone OS'){
		    	/*var appStyle = require('styles/style');
		    	var ro = {
		   	  	 	ui:appStyle
		   	  	};
		   	  	lblColor = 'black';
		   	  	alert('lblColor: ' + lblColor);*/
			}
			else{
				lblColor = ro.ui.theme.privacyPolicyTxtLbl;
			}
	   	  
	   	  var lbl = Ti.UI.createLabel({
	      	//text:'',
	      	attributedString:attr,
	      	font:{
	      		fontSize:ro.ui.scaleFont(16),
	      		//fontWeight:'bold',
	      		fontFamily:ro.ui.fonts.policyText
	      	},
	         height:Ti.UI.SIZE,
	         width:Ti.UI.FILL,
	         color:lblColor,
	         left:ro.ui.relX(10),
	         //right:ro.ui.relX(5),
	         top:ro.ui.relX(5),
	         //bottom:ro.ui.relX(5)
	      });
	      
	      
	      return lbl;
	   },
	   splitLtyString = function(str){
	   	  var returnObj = {
	   	  	 beforeTxt:'',
	   	  	 linkTxt:'',
	   	  	 afterTxt:''
	   	  };
	   	  
	   	  if(str.indexOf('[') == -1 && str.indexOf(']') == -1){
	   	  	str += '[]';
	   	  }
	   	  
	   	  if(str && str.length){
	   	  	//str.indexOf('[')
	   	  	var openBracketIdx, closeBracketIdx;
	   	  	openBracketIdx = str.indexOf('['); 
	   	  	closeBracketIdx = str.indexOf(']');
	   	  	
	   	  	var enrollTxt = ECLUB.LTY_ENROLL_TXT && ECLUB.LTY_ENROLL_TXT.length ? ECLUB.LTY_ENROLL_TXT : '';
	   	  	//split string into three parts:
	   	  	var strOne, strTwo, strThree;
	   	  	
	   	  	//The first part will be from beginning of string to the open bracket [
	   	  	if(haveTermsChanged()){
	   	  		strOne = str.slice(0, openBracketIdx);
	  		}
	  		else{
	  			strOne = enrollTxt + ' ' + str.slice(0, openBracketIdx);
	  		}
	   	  	
	   	  	//The second part will be from the open bracket [ to the close bracket ]
	   	  	strTwo = str.slice(openBracketIdx+1, closeBracketIdx);
	   	  	
	   	  	//The third part will be from the close bracket ] to the end of the string 
	   	  	strThree = str.slice(closeBracketIdx+1, str.length);
	   	  	
	   	  	returnObj.beforeTxt = strOne;
	   	  	returnObj.linkTxt = strTwo;
	   	  	returnObj.afterTxt = strThree;
	   	  }
	   	  else{
	   	  	 if(ECLUB.LTY_ENROLL_TXT && ECLUB.LTY_ENROLL_TXT.length){
	   	  	 	var enrollTxt = ECLUB.LTY_ENROLL_TXT;
	   	  	 	returnObj.beforeTxt = enrollTxt;
	   	  		returnObj.linkTxt = '';
	   	  		returnObj.afterTxt = '';
	   	  	 }
	   	  	 
	   	  	 //var enrollTxt = ECLUB.LTY_ENROLL_TXT && ECLUB.LTY_ENROLL_TXT.length ? ECLUB.LTY_ENROLL_TXT : '';
	   	  }
	   	  
	   	  return returnObj;
	   },
	   /*getNewLoyaltyPolicyLbl = function(){
	      var loyaltyPolicyText = '';
	      loyaltyPolicyText = cfg.LTY_ENROLL_TXT + ' ' + cfg.LTY_TERMS_TXT;
		  //Ti.API.debug('loyaltyPolicyText: ' + loyaltyPolicyText);
	      
	      return loyaltyPolicyText;
	   },*/
	   isLoyaltyNoEClubEnabled = function(){
	   	if(false && Ti.Platform.name === 'iPhone OS'){
	   		
	   	}
	   	else{
	   		return !noLoyalty && ECLUB.LTY_NO_ECLUB;
	   	}
	   },
	   isLoyaltyNoEClubEnabledAtPayment = function(){
	   	  if(false && Ti.Platform.name === 'iPhone OS'){
		   		
		  }
		  else{
	      	 return !noLoyalty && (ECLUB.LtyOptIn == 0 && !getCurrentLoyalty().isLU);
	      }
	   },
	   HasSelectedStore = function(ltyStoresFoundBln){
	   	  var HasSelectedBln = false;
	   	  var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
	   	  if(cfg && cfg.LTY_ENROLL_TYPE && cfg.LTY_ENROLL_TYPE==2 && ltyStoresFoundBln && LtyPicker && newLoyaltyPolicyCheckbox.theValue){
	   	  	//var row = LtyPicker.getSelectedRow(0);
	   	  	var row = ro.forms.getValues(LtyPicker);
	   	  	Ti.API.debug('row: ' + JSON.stringify(row));
	   	  	 if(row && row.ltyStoreData && (row.ltyStoreData.id >= 0)){
	   	  	 	HasSelectedBln = true;
	   	  	 }
	   	  	 else{
	   	  	 	ro.ui.alert('', 'Must select a location to enroll.');
	   	  	 	HasSelectedBln = false;
	   	  	 }
	   	  }
	   	  else{
	   	  	HasSelectedBln = true;
	   	  }
	   	  
	   	  return HasSelectedBln;
	   },
	   HasSelectedStoreOneClick = function(ltyStoresFoundBln){
	   	  var HasSelectedBln = false;
	   	  var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
	   	  if(cfg && cfg.LTY_ENROLL_TYPE && ltyStoresFoundBln && LtyPicker){
	   	  	var row = LtyPicker.getSelectedRow(0);
	   	  	 if(row && (row.id >= 0)){
	   	  	 	HasSelectedBln = true;
	   	  	 }
	   	  	 else{
	   	  	 	ro.ui.alert('', 'Must select a location to enroll.');
	   	  	 	HasSelectedBln = false;
	   	  	 }
	   	  }
	   	  else{
	   	  	HasSelectedBln = true;
	   	  }
	   	  
	   	  return HasSelectedBln;
	   },
	   didLtyNoEClubChange = function(){
	       return newLoyaltyPolicyCheckbox && (newLoyaltyPolicyCheckbox.theValue !== newLoyaltyPolicyCheckbox.OrigValue);
	       
	       
	           
	   },
	   setNoEClubOrderObject = function(){
	   	  var test = Ti.App.OrderObj;
	      if(!test.Customer){
	         test.Customer = {};
	      }
	      test.Customer.LtyOptOut = newLoyaltyPolicyCheckbox && newLoyaltyPolicyCheckbox.theValue ? false : true;
	      Ti.App.OrderObj = test;
	      test = null;
	      return Ti.App.OrderObj.Customer.LtyOptOut ? 2 : 1;
	   },
	   setNoEClubOptOut = function(ltyoptin){
	      var test = Ti.App.OrderObj;
	      if(!test.Customer){
	         test.Customer = {};
	      }
	      test.Customer.LtyOptOut = ltyoptin==2 ? true : false;
	      //test.OptOut =
	      Ti.App.OrderObj = test;
	      test = null;
	   },
	   haveTermsChanged = function(){
	   	  if(ECLUB.LtyOptIn == 1){
	   	  	 return ECLUB.LtyTermsChanged;
	   	  }
	   	  else{
	   	  	return false;
	   	  }
	   },
	   needsReset = function(){
	   	return needsRst==true?true:false;
	   },
	   reset = function(){
	   	  if(Ti.Platform.name === 'iPhone OS'){
		   	 
		  }
		  else{
		     needsRst = false;
		   	 theView.height = ro.ui.relY(0);
		   	 theView.removeAllChildren();
		   	 releaseWebview();
		  }
	  },
	   releaseWebview = function(){
	  	 if(ro.isiOS){
		    		
		 }
		 else{
		   	if(!webWindowNeedsClear){
		   		return;
		   	}
			webView.release();
			webWindowNeedsClear = false;
		 }
	   },
	   didLtyNoEclubChange = function(){
	   	  return newLoyaltyPolicyCheckbox && (newLoyaltyPolicyCheckbox.theValue !== newLoyaltyPolicyCheckbox.OrigValue);
	   },
	   getLoyaltyPicker = function(LtyStores){
	   	  var LtyPicker = Ti.UI.createPicker({
				type:Ti.UI.PICKER_TYPE_PLAIN,
				height:ro.ui.relY(40),
				width:ro.ui.relX(250),
				backgroundColor:ro.ui.theme.pickerColor,
		    	bottom:ro.ui.relY(25),
		    	focusable:true,
		    	selectionOpens:true
			});
	   	  
	   	  return LtyPicker;
	   },
	   DoRegisterStores = function(_cb){
	   	  var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
	   	  if(!cfg.LTY_ENROLL_TYPE) _cb();
	   	  
			REV_CUSTOMER.getCurrentLoc(
		  	 	function(req){
		  	 		//THIS CALLBACK IS FOR THE SUCCESFULL GEOLOCATION AND NOW ITS TIME TO MAKE THE NEW API CALL
		  	 		//alert('req: ' + JSON.stringify(req));
		  	 		
		  	 		ro.dataservice.post(req, 'GetLtyStores', function(response){
				       if(response){
				          if(response.Value){
				          	 //Ti.API.debug('AAAAAAAAAresponse: ' + JSON.stringify(response));
				          	 //ro.ui.showNewAccount(response);
				          	 ShowRegisterStores(response, _cb);
				          }
				          else{
				          	//Ti.API.debug('response: ' + JSON.stringify(response));
				          	_cb();
				          	//ro.ui.showNewAccount();
				          }
				       }
				       else{
				         //Ti.API.debug('ERROR');
				         _cb();
				       	 //ro.ui.showNewAccount();
				       }
				    });
		  	 	}, 
		  	 	function(req){
		  	 		//THIS CALLBACK IS FOR ANY ERRORS SO THE NEW API CALL CAN STILL BE CALLED BUT WITHOUT COORDINATES
		  	 		//Ti.API.debug('req: ' + JSON.stringify(req));
		  	 		
		  	 		ro.dataservice.post(req, 'GetLtyStores', function(response){
				       if(response){
				          if(response.Value){
				          	 //Ti.API.debug('BBBBBBBBBresponse: ' + JSON.stringify(response));
				          	 ShowRegisterStores(response, _cb);
				          	 //ro.ui.showNewAccount(response);
				          }
				          else{
				          	//Ti.API.debug('response: ' + JSON.stringify(response));
				          	_cb();
				          	//ro.ui.showNewAccount();
				          }
				       }
				       else{
				         //Ti.API.debug('ERROR');
				         _cb();
				       	 //ro.ui.showNewAccount();
				       }
				    });
		  	 		
		  	 	}
		  	);
	   	  
	   },
	   getBigButtonBar = function(cancelTxt, confirmTxt){
		   var borderRadius = null;
		   if(Ti.App.RoundedButtons){
		   	  borderRadius = ro.ui.relX(125);
		   }
		   var thisBtnBar = Ti.UI.createView({
		   	  top:0,//ro.ui.relY(),
		      height:ro.ui.relY(40),
		      width:Ti.UI.FILL,
		      left:ro.ui.relX(2),
			  right:ro.ui.relX(2),
		      //bottom:ro.ui.relY(55),
		      backgroundColor:'transparent',
		      //borderColor:ro.ui.theme.bigBtnBorder,
			  borderRadius:borderRadius,
		      //borderWidth:ro.ui.relX(1),
		      //layout:'horizontal'
		   });
		   
		   var cancelBtn, confirmBtn;
		   
		   cancelBtn = Ti.UI.createView({
		   	width:'49.75%',
		   	left:'0',
		   	height:Ti.UI.FILL,
		   	backgroundColor:ro.ui.theme.sizeBtnBlockBgDefault
		   	//left:0
		   });
		   cancelBtn.add(Ti.UI.createLabel({
		   	height:Ti.UI.FILL,
		   	width:Ti.UI.FILL,
		   	textAlign:'center',
		   	text:cancelTxt,
		   	color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
		   	font:{
		         fontSize:ro.ui.scaleFont(16),
		         fontFamily:ro.ui.fontFamily
		    }
		   }));
		   
		   
		   confirmBtn = Ti.UI.createView({
		   	width:'49.75%',
		    right:0,
		   	backgroundColor:ro.ui.theme.sizeBtnBlockBgDefault,
		   	height:Ti.UI.FILL//,
		   	//right:0
		   });
		   confirmBtn.add(Ti.UI.createLabel({
		   	height:Ti.UI.FILL,
		   	width:Ti.UI.FILL,
		   	textAlign:'center',
		   	text:confirmTxt,
		   	color:ro.ui.theme.sizeBtnBlockNameTxtDefault,
		   	font:{
		         fontSize:ro.ui.scaleFont(16),
		         fontFamily:ro.ui.fontFamily
		    }
		   }));
		   
		   /*thisBtn.add(Ti.UI.createLabel({
		      text:ttl?ttl.toUpperCase() : ttl,
		      font:{
		         fontWeight:'bold',
		         fontSize:ro.ui.scaleFont(20),
		         fontFamily:ro.ui.fontFamily
		      },
		      color:ro.ui.theme.bigBtnTxt,
		      textAlign:'center'
		   }));*/
		   
		   thisBtnBar.add(cancelBtn);
		   thisBtnBar.add(confirmBtn);
		   return thisBtnBar;
		},
		menuHeaders = function(e){
			try{
				var hdrTxt = e.text;
				if(!hdrTxt){
					hdrTxt = '';
				}
				hdrTxt = hdrTxt.toUpperCase();
				var lft = ro.ui.relX(10);
				var rgt = ro.ui.relX(10);
				if(e.leftRightBool){
				   lft = ro.ui.relX(2);
				   rgt = ro.ui.relX(2);
				}
		
				var hdrView = Ti.UI.createView({
					width:Ti.UI.FILL,
					right:rgt,
					left:lft,
					height:ro.ui.relY(50),
					backgroundColor:e.backgroundColor?e.backgroundColor:ro.ui.theme.headerBackgroundColor,
					//borderColor:e.borderColor?e.borderColor:ro.ui.theme.headerBorderColor,
					//borderWidth:ro.ui.relX(1),
					iAm:'view',
					isHeader:true
				});
				//alert('e.txtClr: ' + e.txtClr);
				//alert('ro.ui.theme.headerTitleTxt: ' + ro.ui.theme.headerTitleTxt);
				//alert("e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt: " + e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt);
				var hdrLbl = Ti.UI.createLabel({
					text:hdrTxt,
					color:e.txtClr?e.txtClr:ro.ui.theme.headerTitleTxt,
					font:{
						fontSize:e.smallerFont ? ro.ui.scaleFont(13) : ro.ui.scaleFont(20),
						fontWeight:'bold',
						fontFamily:ro.ui.fontFamily
					},
					textAlign:'center',
					//left:ro.ui.relX(5),
					touchEnabled:false,
					iAm:'label',
					isHeader:true
				});
				hdrView.add(hdrLbl);
			}
			catch(ex){
				if(false){ Ti.API.debug('menuHeaders()-Exception: ' + ex); }
			}
			return hdrView;
		},
	   ShowRegisterStores = function(storesResp, _cb){
	   	if(!storesResp || !storesResp.Stores || !storesResp.Stores.length) {_cb(); return; };
	   
	   	var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
	   	//if(!cfg.LTY_ENROLL_TYPE) _cb();
	   
	   	var LtyStores = storesResp.Stores;
	  	var registerStoresWin = layoutMenuHelper.modalSuggWin();
	  	registerStoresWin.addEventListener('close', function(){
	  		//_callback(passthroughIndex);
			ro.App.openWindows.pop();
	  		registerStoresWin = null;
	  	});
	    
	    var confirmTxt = "Enroll";
	    var cancelTxt = "Cancel";
	
	    var data = [];
	    
	    var regView = Ti.UI.createView({
	    	layout:'vertical',
			top:ro.ui.relY(25),
			left:ro.ui.relX(10),
			right:ro.ui.relX(10),
			height:Ti.UI.SIZE,
			zIndex:6
	    });
	    registerStoresWin.children[0].add(regView);
	    
	    var LTY_ENROLL_HDR = cfg && cfg.LTY_ENROLL_HDR && cfg.LTY_ENROLL_HDR.length ? cfg.LTY_ENROLL_HDR : "LOYALTY";
	    var registerStoresHdr = menuHeaders({text:LTY_ENROLL_HDR, leftRightBool:true});
	    registerStoresWin.children[0].add(registerStoresHdr);
	    switch(parseInt(cfg.LTY_ENROLL_TYPE,10)){
	   	  case 1:
	   	  	//dropdown only
	   	  	/*var LoyaltyPicker = ro.REV_LOYALTY.getLoyaltyPicker(LtyStores);
			form.container.add(LoyaltyPicker);*/
			var newLoyaltyWebView = Ti.UI.createView({
	          	height:0,
	          	width:Ti.UI.FILL
	          });
	          registerStoresWin.children[0].add(newLoyaltyWebView);
	
	          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true, false, 1, LtyStores, false, true);
	          newLoyaltyView.top = 0;
	          registerStoresWin.children[0].add(newLoyaltyView);
			
	   	  	break;
	   	  case 2:
	   	  	//dropdown and checkbox
			
			/*var LoyaltyPicker = ro.REV_LOYALTY.getLoyaltyPicker(LtyStores);
			form.container.add(LoyaltyPicker);*/
			
			var newLoyaltyWebView = Ti.UI.createView({
	          	height:0,
	          	width:Ti.UI.FILL
	          });
	          registerStoresWin.children[0].add(newLoyaltyWebView);
	
	          var newLoyaltyView = ro.REV_LOYALTY.getNewLoyaltyPolicyView(newLoyaltyWebView, true, false, 2, LtyStores, false, strue);
	          newLoyaltyView.top = 0;
	         registerStoresWin.children[0].add(newLoyaltyView);
			
	   	  	break;
	   }
	    
	   var regViewBtnBar = getBigButtonBar(cancelTxt, confirmTxt);
	   regViewBtnBar.children[0].addEventListener('click', function(){
	   	  registerStoresWin.close();
	   });
	   	regViewBtnBar.children[1].addEventListener('click', function(){
	   		var selStore = "";
	   		if(!HasSelectedStoreOneClick(LtyStores && LtyStores.length)){
	     		ro.ui.hideLoader();
	     		return;
	     	}
	     	var selRow = LtyPicker.getSelectedRow(0);
	   	  _cb(true, selRow.id, selRow.title);
	   	  registerStoresWin.close();
	   });
	   regViewBtnBar.width = newLoyaltyView.width;
	   
	   registerStoresWin.children[0].add(regViewBtnBar);
	   ro.App.openWindows.push(registerStoresWin);
	    registerStoresWin.open();
	   };
	   
	   ro.REV_LOYALTY = {
	      init: init,
	      setOptOut: setOptOut,
	      setOrderObject: setOrderObject,
	      setRequestObject: setRequestObject,
	      getNewLoyaltyView: getNewLoyaltyView,
	      isEnabled: isEnabled,
	      isEnabledAtPayment: isEnabledAtPayment,
	      didChange: didChange,
	      
	      setCurrentLoyalty: setCurrentLoyalty,
	      getCurrentLoyalty: getCurrentLoyalty, 
	      
	      afterAccountCreation: afterAccountCreation,
	      getEClubOptIn: getEClubOptIn,
	      
	      isValidCode: isValidCode,
	      validateCoupon: validateCoupon,
	      
	      //Dev
	      getLtyOptIn: getLtyOptIn,
	      getNewLoyaltyPolicyView: getNewLoyaltyPolicyView,
	      isLoyaltyNoEClubEnabled: isLoyaltyNoEClubEnabled,
	      isLoyaltyNoEClubEnabledAtPayment: isLoyaltyNoEClubEnabledAtPayment,
	      didLtyNoEClubChange: didLtyNoEClubChange,
	      setRequestObjectNoEclub: setRequestObjectNoEclub,
	      setNoEClubOrderObject: setNoEClubOrderObject,
	      setNoEClubOptOut: setNoEClubOptOut,
	      haveTermsChanged: haveTermsChanged,
	      needsReset: needsReset,
	      reset: reset,
	      didLtyNoEclubChange: didLtyNoEclubChange,
	      getLoyaltyPicker: getLoyaltyPicker,
	      HasSelectedStore: HasSelectedStore,
	      setLtyStoreID: setLtyStoreID,
	      DoRegisterStores: DoRegisterStores,
	      ShowRegisterStores: ShowRegisterStores
	   };
   };
   
   return {
   	  Loyalty:Loyalty
   };
}();
module.exports = LOYALTY;