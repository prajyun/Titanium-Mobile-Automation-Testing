ro = {};
var osname = Ti.Platform.osname;
var isiOS = (osname == 'iphone' || osname == 'ipad') ? true : false;
ro.isiOS = isiOS;

var revmobile = require("revmobile/revmobile");
ro = revmobile.createNamespace();

Ti.App.JETSDEMO = false;
Ti.App.dev = false;
Ti.App.RoundedButtons = true;

var REV_STORES = require('controls/REV_STORES');
ro.REV_STORES = REV_STORES.rev_stores(ro);

Ti.App.logoStyle = false;
Ti.App.picklemansStyle = false;
Ti.App.NewHungryHowiesLayout = true;


var titles = ['Ms.','Mrs.','Mr.'];
var addrTypes = ['House','School','Business','Apartment','Hotel'];

var states = [{StateAbbreviation:'AL', CountryCode:'US'},{StateAbbreviation:'AK', CountryCode:'US'},{StateAbbreviation:'AZ', CountryCode:'US'},{StateAbbreviation:'AR', CountryCode:'US'},{StateAbbreviation:'CA', CountryCode:'US'},{StateAbbreviation:'CO', CountryCode:'US'},{StateAbbreviation:'CT', CountryCode:'US'},{StateAbbreviation:'DE', CountryCode:'US'},{StateAbbreviation:'DC', CountryCode:'US'},{StateAbbreviation:'FL', CountryCode:'US'},{StateAbbreviation:'GA', CountryCode:'US'},{StateAbbreviation:'HI', CountryCode:'US'},{StateAbbreviation:'ID', CountryCode:'US'},{StateAbbreviation:'IL', CountryCode:'US'},{StateAbbreviation:'IN', CountryCode:'US'},{StateAbbreviation:'IA', CountryCode:'US'},{StateAbbreviation:'KS', CountryCode:'US'},{StateAbbreviation:'KY', CountryCode:'US'},{StateAbbreviation:'LA', CountryCode:'US'},{StateAbbreviation:'ME', CountryCode:'US'},{StateAbbreviation:'MD', CountryCode:'US'},{StateAbbreviation:'MA', CountryCode:'US'},{StateAbbreviation:'MI', CountryCode:'US'},{StateAbbreviation:'MN', CountryCode:'US'},{StateAbbreviation:'MS', CountryCode:'US'},{StateAbbreviation:'MO', CountryCode:'US'},{StateAbbreviation:'MT', CountryCode:'US'},{StateAbbreviation:'NE', CountryCode:'US'},{StateAbbreviation:'NV', CountryCode:'US'},{StateAbbreviation:'NH', CountryCode:'US'},{StateAbbreviation:'NJ', CountryCode:'US'},{StateAbbreviation:'NM', CountryCode:'US'},{StateAbbreviation:'NY', CountryCode:'US'},{StateAbbreviation:'NC', CountryCode:'US'},{StateAbbreviation:'ND', CountryCode:'US'},{StateAbbreviation:'OH', CountryCode:'US'},{StateAbbreviation:'OK', CountryCode:'US'},{StateAbbreviation:'OR', CountryCode:'US'},{StateAbbreviation:'PA', CountryCode:'US'},{StateAbbreviation:'RI', CountryCode:'US'},{StateAbbreviation:'SC', CountryCode:'US'},{StateAbbreviation:'SD', CountryCode:'US'},{StateAbbreviation:'TN', CountryCode:'US'},{StateAbbreviation:'TX', CountryCode:'US'},{StateAbbreviation:'UT', CountryCode:'US'},{StateAbbreviation:'VT', CountryCode:'US'},{StateAbbreviation:'VA', CountryCode:'US'},{StateAbbreviation:'WA', CountryCode:'US'},{StateAbbreviation:'WV', CountryCode:'US'},{StateAbbreviation:'WI', CountryCode:'US'},{StateAbbreviation:'WY', CountryCode:'US'}];

Ti.App.SignReqAndResp = false;
Ti.App.isLogout = false;
Ti.App.focusOnceBln = false;
Ti.App.atPayScrn = false;
Ti.App.allowFuture = false;
Ti.App.reqAddr = true;
Ti.App.newMenu = 0;
Ti.App.grpIndex = null;
Ti.App.cpnGrpIndex = null;
Ti.App.passChanged = null;
Ti.App.DEBUGBOOL = true;//See if I can add some branching logic via extending the Ti.API.debug class that checks this value...
Ti.App.OnceOnly = false;
Ti.App.futureOnly = false;
Ti.App.RepeatLastOrder = false;
Ti.App.Cpon = null;
Ti.App.prevIdx = 0;
Ti.App.Username = '';
ro.App = {};
ro.App.edit = {
	editMode:false,
	editIndex:null 
};

ro.App.sugg = {
	suggMode:false,
	itmIndx:null,
	grpIndx:null,
	SuggSizeName:null,
	SuggStyleName:null
};

ro.App.cpnCodeMode = {
	Flg:false,
	Key:null,
	LoyaltyCode:null
};

Ti.App.CpnUsageString = [];
ro.App.openWindows = [];
Ti.App.AllowLongSt = false;
Ti.App.AllowPCAccuracy = false;


Ti.App.websiteURL = 'https://demo.hungerrush.com/';


Ti.App.serviceURL = Ti.App.websiteURL + 'RevService.asmx';
Ti.App.resetURL = Ti.App.websiteURL + 'Account/ResetPassword';
Ti.App.REV_APP_ID = Ti.App.id;
ro.App.isSecure = !Ti.App.websiteURL.includes("hunger-rush");

Ti.App.loginGreeting = 'Log In to your Hungry Profile';
Ti.Geolocation.purpose = 'This app wants to use your location.';

Ti.App.ItemsSplit = false;
Ti.App.firstOLOrdCpnApplied = false;
Ti.App.NeedToCheckForAppUpdate = true;

Ti.App.Properties.setList('titles', titles);
Ti.App.Properties.setList('addrTypes', addrTypes);
Ti.App.Properties.setList('states', states);

try{	//Checks for and removes if found, the following potentially persistent properties
	ro.utils.removeProp('digest');
	ro.utils.removeProp('Store');
	ro.utils.removeProp('storeList');
	ro.utils.removeProp('Config');
	ro.utils.removeProp('SelectedCoupon');
	ro.utils.removeProp('nrq');//pickAny
    ro.utils.removeProp('rq');//RequiredAny
	ro.utils.removeProp('cpnKey');
	ro.utils.removeProp('Customer');
	ro.utils.removeProp('lvlupBool');
	ro.utils.removeProp('ValCode');
	ro.utils.removeProp('tempLoyaltyCode');
	ro.utils.removeProp('promos');
	ro.utils.removeProp('ordTrackObj');
	ro.utils.removeProp('promoDigest');
	ro.utils.removeProp('futureTimeObj');
	ro.utils.removeProp('mktConfig');
	ro.utils.removeProp('applePayConfig');
	
	var defaultMultiPmts = {DoMultiPmts:false, MultiPmts:[]};
	Ti.App.Properties.setString("MultiPmts", JSON.stringify(defaultMultiPmts));
}
catch(ex){
	if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('RemovingPersistentPropertiesAtRuntime-Exception: ' + ex); }
}

global.layoutHelper = require('revmobile/ui/sharedLayouts/mainView');	   //Global module that makes different UI elements available (ie: Nav Left and Right buttons, submit buttons, mainView shell with navbar included)
global.layoutMenuHelper = require('revmobile/ui/menu/sharedMenuLayouts');  //Global module that makes different MENU specific UI elements available (ie: Menu styled tableViewrows, buttonblock (whole, half1, half2), extraClick block)

//var EWOM = require('EWOM'); //EWOM Module
//var levelUp = require('LevelUp'); //LevelUp Module
global.privacyPolicy = require('PrivacyPolicy'); //PrivacyPolicy Module
global.GEO = require('geo'); //GOOGLE GEOCODING MODULE
global.GA = require('ga'); //GOOGLE ANALYTICS MODULE
global.PN = require('pushNotifications'); //PUSH NOTIFICATIONS MODULE
global.REV_Suggest = require('Suggest'); //Suggest Module
global.CC_TIPS = require('ccTips'); //Credit Card Tips Module

global.REV_LOYALTY = require('REV_Loyalty');//NEW LOYALTY MODULE...HANDLES EWOM AND LEVELUP AND SOON HONEYCOMB
REV_LOYALTY.Loyalty(ro);

global.REV_CUSTOMER = require('controls/Customer');//Module for all things customer
global.REV_API = require('REV_API');//EVENTUALLY WILL HOUSE ALL API CALLS TO MAKE THEM REUSABLE WITHOUT BEING REWRITTEN EVERY TIME
global.REV_GUEST_ORDER = require('REV_GUEST');
global.REV_BANNERS = require('REV_BANNERS');
global.REV_ADS = require('REV_ADS');
global.REV_ORD_TYPE = require('controls/REV_ORD_TYPE');
global.REV_HEARTBEAT = require('controls/REV_HEARTBEAT');
//var cpnsHelper = require('logic/couponsHelper').cpnhelper();
//var cache = require('REV_REMOTEIMAGE').Utils;
//var CC_SCAN = require('CardScanner'); //Credit Card Scan Module
//CC_SCAN.Init();


Ti.App.REV_INSTALL_ID = "410332291";
Ti.App.appStoreURL = 'http://itunes.apple.com/us/app/id' + Ti.App.REV_INSTALL_ID + '?mt=8';


////////////////////      GOOGLE ANALYTICS MODULE           ////////////////////
// pass true if you want to enable debug mode
// This will log info events
//GA.init('HHTraining', true);  //THIS STRING IS CLIENT SPECIFIC AND MUST CHANGE PER APP.
//GA.init('UA-58261433-1', false);	//THIS STRING IS CLIENT SPECIFIC AND MUST CHANGE PER APP.

////////////////////      GOOGLE ANALYTICS MODULE           ////////////////////


//ro.app.applicationWindow.open();

var getConfig = function(_cb){
 	try{
 		Ti.App.OnceOnly = true;
		Ti.App.reqAddr = true;
		var req = {
			RevKey:'test',
		   CompressResponse:false
		};
		ro.dataservice.post(req, 'GetAppConfig', function(response){
	      if(response){
	         if(response.Value){
	         	Ti.API.info("GetAppConfig Response : " + JSON.stringify(response));
	            if(response.Config){
	                Ti.App.SignReqAndResp = response.Config.REQ_API_SIGN || false;
	            	Ti.App.Properties.setString('Config', JSON.stringify(response.Config));
					Ti.App.getConfigTime = new Date();
	            	Ti.App.menuLayout = response.Config.MenuLayout || 0;
	            	Ti.App.AllowLongSt = response.Config.AllowLongSt || false;
	            	Ti.App.AllowPCAccuracy = response.Config.ALLOW_PC_ACCURACY || false;
	            	
	            	var gaString = "";
		            if(response.Config.GOOG_ANALYTICS_ID && response.Config.GOOG_ANALYTICS_ID.length){
		         		//GOOG_ANALYTICS_ID
		         		//GA.init(Obj.Config.GOOG_ANALYTICS_ID, false);
		         		gaString = response.Config.GOOG_ANALYTICS_ID;
		         	}

                    var PN_API_KEY = "";
                    if (response.Config.PN_API_KEY && response.Config.PN_API_KEY.length) {
                        PN_API_KEY = response.Config.PN_API_KEY;
                    }
	            	
	            	if(response.Config.States && response.Config.States.length){
			           Ti.App.Properties.setList('states', response.Config.States);
			        }

	            	var cfg = response.Config;
	            	//levelUp.Init(cfg.LU_STORE_PMT, cfg.LU_SANDBOX, cfg.LU_API_KEY, cfg.LU_SECRET, cfg.LU_STORE_ID, cfg.LU_MERCHANT_ID, cfg.LU_MERCHANT_TOKEN/*, cfg.LUToken ? cfg.LUToken : null*/);

	         		if(response.Config.ReqAddress === true || response.Config.ReqAddress === false){
	         			Ti.App.reqAddr = response.Config.ReqAddress;
	         		}
	         		if(response.Config.CardTypes && response.Config.CardTypes.length > 0){
	         			Ti.App.Properties.setList('creditcards', response.Config.CardTypes);
	         		}
	         		if(response.Config.MenuLayout && parseInt(response.Config.MenuLayout, 10) > 0){
	         			Ti.App.newMenu = parseInt(response.Config.MenuLayout, 10);
	         		}
	         		
	         		ro.REV_LOYALTY.setCurrentLoyalty();
	         		
	         	}
	         	if(response.Promos){
	         		Ti.App.Properties.setString('promos', JSON.stringify(response.Promos));
	         	}
	         	else{
	         		Ti.App.Properties.setString('promos', '{}');
	         	}
	         	
	         	if(response.States && response.States.length){
	         		var uniqueCountryCol = {uniqueCountryCount:0};
	         		for(var i=0, iMax=response.States.length; i<iMax; i++){
						response.States[i].clone = null;
	         			if(!uniqueCountryCol[response.States[i].CountryCode]){
	         				uniqueCountryCol[response.States[i].CountryCode] = true;
	         				uniqueCountryCol.uniqueCountryCount += 1;
	         			}
	         		}
	         		
	         		ro.App.ZipCodeNumbersOnlyKeyboard = uniqueCountryCol.uniqueCountryCount > 1 ? false : true;
	         		
	         		if(ro.App.ZipCodeNumbersOnlyKeyboard){
	         		    if(response.States[0].CountryCode && response.States[0].CountryCode.length && response.States[0].CountryCode.toLowerCase() == "ca"){
	         		        ro.App.ZipCodeNumbersOnlyKeyboard = false;
	         		    }
	         		}	         		
			        Ti.App.Properties.setList('states', response.States);					
	         	}
	         	
	         	if(response.Titles && response.Titles.length){
			        Ti.App.Properties.setList('titles', response.Titles);
			    }

				if(response.MktConfig){
					Ti.App.Properties.setString('mktConfig', JSON.stringify(response.MktConfig));
				}	         	
	         	
				if(response.ApplePayConfig){
					Ti.App.Properties.setString('applePayConfig', JSON.stringify(response.ApplePayConfig));
				}
				else{
					Ti.App.Properties.setString('applePayConfig', '{}');
				}

	         	if(_cb){
                      _cb(gaString, PN_API_KEY);
	         	}
	         	
	         }
	         else{
	            
	            if(_cb){
	         		_cb();
	         	}
	         	ro.ui.hideLoader();
	            if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('GetAppConfig Failed' + JSON.stringify(response)); }
	         }
	      }
	      else{
	      	if(_cb){
         		_cb();
         	}
	         ro.ui.hideLoader();
	         if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('GetAppConfig Failed' + JSON.stringify(response)); }
	      }
	   });
	}
	catch(ex){
		/*if(_cb){
     		_cb();
     	}*/
		ro.ui.hideLoader();
		if(Ti.App.DEBUGBOOL)	{ Ti.API.debug('GetAppConfig-Exception: ' + ex); }
	}
}

ro.getAppConfig = getConfig;
global.REV_UPDATE = require('REV_UPDATE');

function appConfigCallback(gaString, PN_API_KEY){
	Ti.API.info('In the config callback!!!!');
	
	GA.googleanalytics(ro);
	
	if(gaString && gaString.length){
		ro.GA.init(gaString, false);	//THIS STRING IS CLIENT SPECIFIC AND MUST CHANGE PER APP.
	}
	else{
		ro.GA.init('UA-aaaa', true);	//THIS STRING IS CLIENT SPECIFIC AND MUST CHANGE PER APP.
    }

    PN.pushNotifications(ro);    
    if (PN_API_KEY && PN_API_KEY.length) {
        ro.PN.init();
    }
	
	
	/*Ti.App.addEventListener('GA_trackPageview', function (e) {
	    ro.GA.trackScreen(e.name);
	});
	Ti.App.addEventListener('GA_trackEvent', function (e) {
	    ro.GA.trackEvent(e.category, e.action, e.label, e.value);
	});
	Ti.App.addEventListener('GA_trackTransaction', function (e) {
	    ro.GA.trackTransaction(e.transactionId, e.storeName, e.total, e.tax, e.delivFee, e.currency);
	});
	Ti.App.addEventListener('GA_setUser', function (e) {
	    ro.GA.setUser(e.userId, e.category, e.action);
	});*/
	ro.app.GA = {
	   trackPageView: function (name){
	      //Ti.App.fireEvent('GA_trackPageview', { name: name });
//	      ro.GA.trackScreen(name);
	   },
	   trackEvent: function (category, action, label, value){
//	   	ro.GA.trackEvent(category, action, label, value);
	     // Ti.App.fireEvent('GA_trackEvent', { category: category, action: action, label: label, value: value });
	   },
	   setUser: function (userId, category, action){
//	   		ro.GA.setUser(userId, category, action);
	      //Ti.App.fireEvent('GA_setUser', { userId: userId, category: category, action: action });
	   },
	   trackTransaction: function (transactionId, storeName, total, tax, delivFee, currency){
//	   	ro.GA.trackTransaction(transactionId, storeName, total, tax, delivFee, currency);
	      //Ti.App.fireEvent('GA_trackTransaction', { transactionId: transactionId, storeName: storeName, total: total, tax: tax, delivFee: delivFee, currency: currency });
	   }
	};
	try{
		ro.app.applicationWindow = null;
		ro.app.applicationWindow = /*ro.app.applicationWindow || */ro.ui.createApplicationWindow();
	}
	catch(ex){
		ro.ui.alert('Error ', 'Error');
	}
    ro.app.applicationWindow.orientationModes = [Ti.UI.PORTRAIT, Ti.UI.UPSIDE_PORTRAIT];
    ro.app.applicationWindow.open();
}
function clearCacheDirectory() {
    try {
      Ti.API.info("clearCache function called");        
      var currDate = new Date().getTime();
      var cacheTime = Ti.App.Properties.getDouble('CacheResetTime', 0);
      if(cacheTime == 0 || cacheTime < currDate){      	
      	var temp = Ti.Filesystem.getApplicationCacheDirectory();
      	var cacheDir = Titanium.Filesystem.getFile(temp);
      	cacheDir.deleteDirectory(true);
      	Ti.API.info("Cache Cleared");
      	Ti.App.Properties.setDouble('CacheResetTime', currDate + 86400000);      	
      }     
   } catch(exc) {
    Ti.API.info("Cache error = " + exc);
   }
}
//setTimeout(clearCacheDirectory, 15000);
getConfig(appConfigCallback);
