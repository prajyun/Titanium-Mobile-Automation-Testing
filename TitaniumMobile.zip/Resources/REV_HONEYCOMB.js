var HONEYCOMB = function(){
   var IS_ANDROID = true;
   var HC = {
   	  HC_API_KEY:'',
   	  HC_API_SECRET:'',
   	  LTY_LAYOUT:0,
      LTY_PTS_EARN_HEADER:'',
      LTY_REWARDS_EARN_HEADER:'',
        
        showSquares:true,
        showMenuGroup:false,
        LTY_STATUS_IMG:false
        
   };
   var hcValcodes = [];
   var Init = function(){
      try{
      	   HC = {
		   	  HC_API_KEY:'',
		   	  HC_API_SECRET:'',
		   	  LTY_LAYOUT:0,
		      LTY_PTS_EARN_HEADER:'',
		      LTY_REWARDS_EARN_HEADER:'',
        
        	  showSquares:true,
        	  showMenuGroup:false,
        	  LTY_STATUS_IMG:false
        
		   };
		   var cfg;
	      if(ro.app.Store){
        	   //Ti.API.debug('ro.app.Store.Configuration: ' + JSON.stringify(ro.app.Store.Configuration));
        	   cfg = ro.app.Store.Configuration;
     	   }
     	   else if(Ti.App.Properties.hasProperty('DefaultStore')){
     	   	   //cfg = JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}')).Configuration;
     	   	   cfg = ro.REV_STORES.getDefaultStore().Configuration;
     	   }
		   else{
	 		   cfg = JSON.parse(Ti.App.Properties.getString('Config'));
	 		   ////deb.ug(cfg, 'cfg');
	         /*if(!cfg){
	            cfg = {};
	         }*/
	        //cfg = {};
	      }
	      //Ti.API.debug('cfg: ' + JSON.stringify(cfg));
	      //Ti.API.debug('cfg: ' + JSON.stringify(cfg));
	      HC.HC_API_KEY = cfg.HC_API_KEY?cfg.HC_API_KEY:'';
	      HC.HC_API_SECRET = cfg.HC_API_SECRET?cfg.HC_API_SECRET:'';
	      
	      HC.LTY_LAYOUT = !isNaN(parseInt(cfg.LTY_LAYOUT, 10)) ? parseInt(cfg.LTY_LAYOUT, 10) : 0;
      	  HC.LTY_PTS_EARN_HEADER = cfg.LTY_PTS_EARN_HDR && cfg.LTY_PTS_EARN_HDR.length ? cfg.LTY_PTS_EARN_HDR : 'Reward Points Earned';
      	  HC.LTY_REWARDS_EARN_HEADER = cfg.LTY_REWARDS_EARN_HDR && cfg.LTY_REWARDS_EARN_HDR.length ? cfg.LTY_REWARDS_EARN_HDR : 'Rewards Available';
      	          
          //HC.showSquares = true;
          //HC.showMenuGroup = false;
          HC.showMenuGroup = (cfg.LTY_IN_MENU && (cfg.LTY_IN_MENU == true)) ? true : false;
      	    if(!cfg.hasOwnProperty("LTY_IN_MENU")){
      	    	HC.showMenuGroup = false;
      	    }
      	    HC.showSquares = (cfg.LTY_RULES_AS_TXT && (cfg.LTY_RULES_AS_TXT == true)) ? false : true;
      	    if(!cfg.hasOwnProperty("LTY_RULES_AS_TXT")){
      	    	HC.showSquares = true;
      	    }
      	    HC.LTY_STATUS_IMG = (cfg.LTY_STATUS_IMG && (cfg.LTY_STATUS_IMG == true)) ? true : false;
      	    
        
	      
	      ////deb.ug(HC, 'HC');
	      //Ti.API.debug('HC.HC_API_KEY.length && HC.HC_API_SECRET.length: ' + HC.HC_API_KEY.length && HC.HC_API_SECRET.length);
	      return HC.HC_API_KEY.length && HC.HC_API_SECRET.length;
	   }
	   catch(ex){
	   	Ti.API.debug('Honeycomb.Init()-Exception: ' + ex);
	   }
   },
   showMenuGroup = function(){
   	  return HC.showMenuGroup;
   },
   setHcCode = function(code){
      hcValcodes.push(code);
   },
   addLoyaltyCodes = function(cpnCol, itmCpnCol){
      if(!cpnCol){
         cpnCol = [];
      }
      if(!hcValcodes){
         hcValcodes = [];
      }

      var test = Ti.App.OrderObj;
      test.LoyaltyCodes = [];
      Ti.App.OrderObj = test;
      test = null;

      for(var i=0; i<cpnCol.length; i++){
         var valCode = (cpnCol[i].LoyaltyCode && cpnCol[i].LoyaltyCode.length) ? (cpnCol[i].LoyaltyCode) : (cpnCol[i].ValCode && cpnCol[i].ValCode.length ? cpnCol[i].ValCode : '');
         for(var j=0; j<hcValcodes.length; j++){
            if(valCode.toLowerCase() == hcValcodes[j].toLowerCase()){
               var test = Ti.App.OrderObj;
               if(!test.LoyaltyCodes){
                  test.LoyaltyCodes = [];
               }
               test.LoyaltyCodes.push(hcValcodes[j]);
               Ti.App.OrderObj = test;
               test = null;
               break;
            }
         }
      }
      for(var i=0, iMax=itmCpnCol&&itmCpnCol.length ? itmCpnCol.length : 0; i<iMax; i++){
      	 var valCode = itmCpnCol[i].CpnObj && itmCpnCol[i].CpnObj.ValCode && itmCpnCol[i].CpnObj.ValCode.length ? itmCpnCol[i].CpnObj.ValCode : '';
      	 if(valCode == ''){
      	 	continue;
      	 }
      	 for(var j=0, jMax=hcValcodes && hcValcodes.length ? hcValcodes.length : 0; j<jMax; j++){
      	 	if(valCode.toLowerCase() == hcValcodes[j].toLowerCase()){
      	 	   var test = Ti.App.OrderObj;
      	 	   if(!test.LoyaltyCodes){
                  test.LoyaltyCodes = [];
               }
               //Ti.API.debug('valCode: ' + valCode);
               //Ti.API.debug('itmCpnCol[i].CpnObj.ValCode: ' + itmCpnCol[i].CpnObj.ValCode);
               //Ti.API.debug('hcValcodes[j]: ' + hcValcodes[j]);
               //Ti.API.debug('itmCpnCol[i].CpnObj: ' + JSON.stringify(itmCpnCol[i].CpnObj));
               test.LoyaltyCodes.push(itmCpnCol[i].CpnObj.LoyaltyCode);
               Ti.App.OrderObj = test;
               test = null;
               break;
      	 	}
      	 } 
      }
//      Ti.API.debug('AFTER - Ti.App.OrderObj: ' + JSON.stringify(Ti.App.OrderObj));
      //Ti.API.debug('///AFTER')
      ////deb.ug(Ti.App.OrderObj, 'AFTER-ORDEROBJ');
   },
   getCustomerDetails = function(username, pass, responseFunc){
      
      var auth = 'basic ';
      var authHash = Ti.Utils.base64encode(username+':'+pass);//This http request header "Authorization" must be sent with every server call and the value must be the base 64 encoded string of username+':'+password
      var authFinal = auth+authHash;

      Ti.App.Properties.setString('authToken', authFinal);
      
      var req = {
         Email: Ti.App.Username
      };

      var url = 'http://r-enterprise.com/api/v1/honeycomb/GetCustomerDetails';
      //var url = 'http://r-enterprise.com/api/v1/honeycomb/GetLtyCustomerDetails';
      
      try{
         var xhr = Ti.Network.createHTTPClient();
         xhr.setTimeout(120000);

         xhr.onload = function(e){
            var responseObject = JSON.parse(this.responseText);
            response = responseObject;
            responseFunc.apply(null, [response]);
         };

         xhr.onerror = function(error){
            Ti.API.debug('ro.dataservice.post - error');
            Ti.API.debug('error: ' + JSON.stringify(error));
         };

         xhr.open('POST', url);

         var timeStamp = parseInt(new Date().getTime() / 1000, 10);

         var sig = HC.HC_API_KEY+''+timeStamp+''+url+'POST';

         /*Ti.include('/classes/crypto.js');
         Ti.include('/classes/crypto64.js');
         var hash = CryptoJS.HmacSHA256(sig, HC.HC_API_SECRET);
         var sigHash = CryptoJS.enc.Base64.stringify(hash);

         xhr.setRequestHeader('X-PSK', HC.HC_API_KEY);
         xhr.setRequestHeader('X-Stamp', timeStamp);
         xhr.setRequestHeader('X-Signature', sigHash);*/
         //xhr.setRequestHeader('Authorization', authFinal);
         //xhr.setRequestHeader('X-Store', 1);

         if(req){
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(JSON.stringify(req));
         }
         else{
            xhr.send();
         }
      }
      catch(ex){
         Ti.API.debug('ro.dataservice.post()-Exception: ' + ex);
         response.Message = 'Error: \n' + ex;
         responseFunc.apply(null, [response]);
      }
   };
   var getLtyCustomerDetails = function(username, storeid, _callback){
      var req = {
         Email: username,
         //StoreID:storeid,
         RevKey:'test',
         CompressResponse:false
      };
      if(storeid){
      	req.StoreID = storeid;
      }

      ro.dataservice.post(req, 'GetLtyCustomerDetails', function(response){
      	//deb.ug(response, 'response');
         _callback(response);
         if(response){
            if(response.Value){
               //setEwomCode(Obj.ValCode);
               _callback(response);
            }
            else{
               //ro.ui.alert('Coupon Not Valid', 'No eWordOfMouth coupon found');
               ro.ui.hideLoader();
            }
         }
         else{
            //ro.ui.alert('Coupon Not Valid', 'No eWordOfMouth coupon found');
            ro.ui.hideLoader();
         }
      });
   };
   var getCampaignSquare = function(sty, hdrTxt, bodyTxt, noteTxt, _callback, hcCode, cpnEvtBln){
      //Ti.API.debug('cpnEvtBln: ' + cpnEvtBln);
      var campaignRowView = Ti.UI.createView(ro.ui.properties.campaignViewRow);
      
      var test;
      if(!HC.showSquares){
      	 test = sty;
      	 test.bgClr = 'transparent';
      	 test.txt = 'black';
      	 sty = test;
      	 test = null;
      	 //Ti.API.debug('DO NOT SHOW SQUARES!!!');      	
      }
      
      var campaignSquare = Ti.UI.createView(ro.combine(ro.ui.properties.honeycombCampaignSquare, {
         backgroundColor:sty.bgClr
      }));
      if(!HC.showSquares){
      	campaignSquare.borderColor = 'transparent';
      	campaignSquare.borderWidth = 0;
      }
      var hdrLbl, bodyLbl, noteLbl;
      hdrLbl = Ti.UI.createLabel(ro.combine((sty.hdrDict ? sty.hdrDict : ro.ui.properties.campaignSquareHdrLbl), {
         text:hdrTxt//'POINT RULE TITLE'
      }));
      bodyLbl = Ti.UI.createLabel(ro.combine((sty.hdrDict ? sty.bodyDict : ro.ui.properties.campaignSquareBodyLbl), {
         text:bodyTxt//'POINT RULE DESCRIPTION'
      }));
      if(sty.txt && sty.txt.length){
      	hdrLbl.color = sty.txt;
      	bodyLbl.color = sty.txt;
      }
      campaignSquare.add(hdrLbl);
      campaignSquare.add(bodyLbl);
      if(noteTxt && noteTxt.length){
      	noteLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.campaignSquareNoteLbl, {
	         text:noteTxt//'POINT RULE DESCRIPTION'
	      }));
	      if(sty.txt && sty.txt.length){
	      	noteLbl.color = sty.txt;
	      }
	      campaignSquare.add(noteLbl);
      }
      else{
         if(!_callback){
            //bodyLbl.height = '60%';
         }
      }
      if(_callback && !cpnEvtBln){
         noteLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.campaignSquareNoteLbl, {
            text:'*Click To Apply'//'POINT RULE DESCRIPTION'
         }));
         campaignSquare.add(noteLbl);
      	campaignSquare.addEventListener('click', _callback);
      	campaignSquare.hcCode = hcCode;
      }
      
      campaignRowView.add(campaignSquare);
      return campaignRowView;
   };
   var getDefaultProgressView = function(rewards){
   	  //getPendingPointsMsg(10);
   	  var totalPointsForReward = rewards.Customers[0].MinPointsForReward;
      var pointsAlreadyEarned = rewards.Customers[0].PointsBalance;
      
      
   	  var progressView = Ti.UI.createView(ro.ui.properties.honeycombProgressView);
      var progressBar = Ti.UI.createView(ro.ui.properties.honeycombProgressBar);
      
      var ptsEarnedMsg = '';
      var pendingPoints = rewards.Customers[0].PointsPending && (parseInt(rewards.Customers[0].PointsPending, 10) > 0) ? parseInt(rewards.Customers[0].PointsPending, 10) : 0;
      //var newBeginLength = 0;
      //var newEndLength = 0;
      var ptHdr = HC.LTY_PTS_EARN_HEADER;
      if(pendingPoints){
      	 pointsAlreadyEarned += pendingPoints;
      	 var firstMsg = ptHdr + ': ' + pointsAlreadyEarned + '*\n';
      	 //newBeginLength = firstMsg.length;
      	 ptsEarnedMsg = firstMsg + getPendingPointsMsg(pendingPoints);
      	 //newEndLength = ptsEarnedMsg.length;
      }
      else{
	     ptsEarnedMsg = ptHdr + ': ' + pointsAlreadyEarned;
      }
      var completedPct = ((pointsAlreadyEarned / totalPointsForReward)*100);
      
      var progressBarLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.honeycombProgressBarLbl, {
         text:ptsEarnedMsg
      }));
      progressBar.add(progressBarLbl);
      var completedProgressBar = Ti.UI.createView(ro.ui.properties.honeycombFullProgressBar);
      //Ti.API.debug('completed pct inverse: ' + (-(100 - completedPct)+'%'));
      var newLeft;
      if(!totalPointsForReward){
      	 newLeft = '-100%';
      } 
      else{
      	 newLeft = -(100 - completedPct)+'%';
      }
      completedProgressBar.left = newLeft; 
      progressBar.add(completedProgressBar);
      
      var progressBarLblView = Ti.UI.createView(ro.ui.properties.honeycombProgressLblView);
      var leftLbl, midLbl, rightLbl;
      leftLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.honeycombProgressLbl, {
         text:'0',
         textAlign:'left'
      }));
      midLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.honeycombProgressLbl, {
         text:(totalPointsForReward/2)+''
      }));
      rightLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.honeycombProgressLbl, {
         text:totalPointsForReward+'',
         textAlign:'right'
      }));
      progressBarLblView.add(leftLbl);
      progressBarLblView.add(midLbl);
      progressBarLblView.add(rightLbl);
      
      progressView.add(progressBar);
      progressView.add(progressBarLblView);
      
      return progressView;
   };
   var getImageProgressView = function(rewards){
   	  var totalPointsForReward = rewards.Customers[0].MinPointsForReward;
      var pointsAlreadyEarned = rewards.Customers[0].PointsBalance;
      var completedPct = ((pointsAlreadyEarned / totalPointsForReward)*100);
   	  var progressView = Ti.UI.createView(ro.ui.properties.honeycombImageProgressView);
   	  var progressRowOne = Ti.UI.createView({
   	  	height:ro.ui.relY(60),
   	  	width:Ti.UI.FILL,
   	  	layout:'horizontal'
   	  });
   	  var progressRowTwo = Ti.UI.createView({
   	  	height:ro.ui.relY(60),
   	  	width:Ti.UI.FILL,
   	  	layout:'horizontal'
   	  });
   	  var half = totalPointsForReward / 2;
   	  var currImg = '/images/missingSlice.png';
   	  for(var i=0, iMax=totalPointsForReward; i<iMax; i++){
   	  	 if(i<pointsAlreadyEarned){
   	  	 	currImg = '/images/pizzaSlice.png';
   	  	 }
   	  	 else{
   	  	 	currImg = '/images/missingSlice.png';
   	  	 }
   	  	 if(i<half){
   	  	 	progressRowOne.add(Ti.UI.createImageView({
   	  	 		image:currImg,
   	  	 		//height:Ti.UI.FILL,
   	  	 		width:'22%',
   	  	 		left:'2%'
   	  	 	}));
   	  	 }
   	  	 else{
   	  	 	progressRowTwo.add(Ti.UI.createImageView({
   	  	 		image:currImg,
   	  	 		//height:Ti.UI.FILL,
   	  	 		width:'22%',
   	  	 		left:'2%'
   	  	 	}));
   	  	 }
   	  }
   	  progressView.add(progressRowOne);
   	  progressView.add(progressRowTwo);
   	  
   	  return progressView; 
   };
   var getOvalView = function(txt){
   	 var ovalView = Ti.UI.createView({
   	 	//width:Ti.UI.FILL,
   	 	top:ro.ui.relY(8),
   	 	height:ro.ui.relY(45),
   	 	borderRadius:ro.ui.relY(22.5),
   	 	backgroundColor:ro.ui.theme.minorColor,
   	 	width:'65%'
   	 });
   	 var lbl = Ti.UI.createLabel({
   	 	text:txt,
   	 	color:'white',
   	 	font:{
   	 		fontFamily:ro.ui.fonts.GothamBold,
   	 		fontSize:ro.ui.scaleFont(24)
   	 	},
   	 	textAlign:'center'
   	 });
   	 ovalView.add(lbl);
   	 return ovalView;
   };
   var getRoundedCustomProgressView = function(rewards){
      //rewards.Customers[0].RewardsMeterUrl
      var progressViewDict, progressImageViewDict, progressBarDict, progressBlockDict, progressBlockDictTwo, dividerDict, lblDict, ptsLblDict, rewardsLblDict, lblDictTwo;
      if(IS_ANDROID){
      	var width = (ro.ui.displayCaps.platformWidth / 2) * .79;
      	var leftOrRight = (ro.ui.displayCaps.platformWidth / 2) * .2;
      	progressViewDict = ro.ui.properties.honeycombCustomProgressView;
      	progressImageViewDict = {
	       height:Ti.UI.SIZE,
	       width:Ti.UI.FILL,
	       left:ro.ui.relX(110),
	       right:ro.ui.relX(110)
	    };
      	progressBarDict = {
	       width:Ti.UI.FILL,
	       height:ro.ui.relY(130),
	       layout:'horizontal',
	       backgroundColor:'white'
	    };
      	progressBlockDictOne = {
	    	height:Ti.UI.FILL,
	      	width:width,
	      	layout:'vertical',
	      	//borderColor:'brown',
	      	//borderWidth:5,
	      	left:leftOrRight
	      	//left:0
	    };
      	progressBlockDictTwo = {
	    	height:Ti.UI.FILL,
	      	width:width,
	      	layout:'vertical',
	      	//borderColor:'orange',
	      	//borderWidth:5,
	      	right:leftOrRight
	    };
      	dividerDict = ro.ui.properties.customDivider;
      	lblDict = {
      		color:'#393839',
      		font:{
      			fontFamily:ro.ui.fonts.titles,
      			fontSize:ro.ui.scaleFont(24)
      		},
      		textAlign:'center',
      		width:Ti.UI.FILL,
      		top:ro.ui.relX(12)
      	};
      	lblDictTwo = {
      		color:'#393839',
      		font:{
      			fontFamily:ro.ui.fonts.titles,
      			fontSize:ro.ui.scaleFont(24)
      		},
      		textAlign:'center',
      		width:Ti.UI.FILL,
      		top:ro.ui.relX(12)
      	};
      	ptsLblDict = ro.ui.properties.customPointsLbl;
      	rewardsLblDict = ro.ui.properties.customEarnedLbl;
      }
      else{
      	progressViewDict = {
	       height:Ti.UI.SIZE,
	       width:Ti.UI.FILL,
	       layout:'vertical'
	    };
	    progressImageViewDict = {
	       height:Ti.UI.SIZE,
	       width:Ti.UI.FILL,
	       left:ro.ui.relX(75),
	       right:ro.ui.relX(75)
	    };
	    progressBarDict = {
	       width:Ti.UI.FILL,
	       height:80,
	       layout:'horizontal',
	       backgroundColor:'#eb0029'
	    };
	    progressBlockDict = {
	    	height:Ti.UI.FILL,
	      	width:'48%',
	      	left:0
	    };
	    dividerDict = {
	    	height:Ti.UI.FILL,
	      	width:'4%',
	      	backgroundColor:'black',
	      	left:0
	    };
	    lblDict = {
	       color:'#f2b300',
	       textAlign:'center',
	       height:Ti.UI.FILL,
	       width:Ti.UI.FILL,
	       font:{
	       	  fontWeight:'bold',
	       	  fontSize:15//,
	       	  //fontFamily:ro.ui.properties.font.fontFamily
	       }
	    };
	    ptsLblDict = {
	       color:'#f2b300',
	       textAlign:'center',
	       height:Ti.UI.FILL,
	       width:Ti.UI.FILL,
	       font:{
	       	  fontWeight:'bold',
	       	  fontSize:15//,
	       	  //fontFamily:ro.ui.properties.font.fontFamily
	       }
	    };
      }
      
      if(!rewards.Customers[0].hasOwnProperty('RewardsMeterUrl') || !rewards.Customers[0].RewardsMeterUrl.length){
      	 return getDefaultProgressView(rewards);
      }
      
      
      var totalPointsForReward = rewards.Customers[0].MinPointsForReward;
      var pointsAlreadyEarned = rewards.Customers[0].PointsBalance;
      //
      var ptsEarnedMsg = '';
      var pendingPoints = rewards.Customers[0].PointsPending && (parseInt(rewards.Customers[0].PointsPending, 10) > 0) ? parseInt(rewards.Customers[0].PointsPending, 10) : 0;
      if(pendingPoints){
      	 pointsAlreadyEarned += pendingPoints;
      	 ptsEarnedMsg = getPendingPointsMsg(pendingPoints);
      	 progressImageViewDict.image = rewards.Customers[0].RewardsMeterUri;
      	 //lblDict.top = null;
      	 //delete lblDict.top;
      }
      else{
      	//lblDict.top = ro.ui.relX(12);
	     progressImageViewDict.image = rewards.Customers[0].RewardsMeterUrl;
      }
      var completedPct = ((pointsAlreadyEarned / totalPointsForReward)*100);
   	  
   	  var progressView = Ti.UI.createView(progressViewDict);
   	  var progressImageView = Ti.UI.createImageView(progressImageViewDict);
   	  progressView.add(progressImageView);
   	  
   	  var progressBar = Ti.UI.createView(progressBarDict);
   	  
   	  var progressBlockOne, progressBlockTwo;
   	  progressBlockOne = Ti.UI.createView(progressBlockDictOne);
   	  progressBlockTwo = Ti.UI.createView(progressBlockDictTwo);
   	  
   	  progressBar.add(progressBlockOne);
   	  
   	  progressBar.add(progressBlockTwo);
   	  
   	  //HC.LTY_PTS_EARN_HEADER = cfg.LTY_PTS_EARN_HEADER && cfg.LTY_PTS_EARN_HEADER.length ? cfg.LTY_PTS_EARN_HEADER : 'Points Earned';
      //HC.LTY_REWARDS_EARN_HEADER
      
      var blockOneFullView = Ti.UI.createView({
      	height:Ti.UI.SIZE,
      	width:Ti.UI.FILL,
      	layout:'vertical'
      });
      
      function replaceLast(x, y, z){
      	  Ti.API.debug('x: ' + x);
		  var a = x.split("");
		  Ti.API.debug('a: ' + JSON.stringify(a));
		  a[x.lastIndexOf(y)] = z;
		  Ti.API.debug('a.join(""): ' + a.join(""));
		  return a.join("");
		}
		
		replaceLast("Hello world!", "l", "x");
      
   	  var lbl, lbl2, ptsLbl, earnedRewardsLbl;
   	  lbl = Ti.UI.createLabel(lblDict);
   	  //lbl.text = HC.LTY_PTS_EARN_HEADER.toUpperCase();
   	  lbl.text = replaceLast(HC.LTY_PTS_EARN_HEADER, " ", "\n");
   	  //progressBlockOne.add(lbl);
   	  blockOneFullView.add(lbl);
   	  
   	  
   	  //ptsLblDict.text = pointsAlreadyEarned + ' / ' + totalPointsForReward;
   	  var ptsLblTxt = pointsAlreadyEarned + ' / ' + totalPointsForReward;//+ '\n';
   	  if(pendingPoints){
   	  	 ptsLblTxt = pointsAlreadyEarned + '* / ' + totalPointsForReward;// + '\n';
   	  }
   	  var newEndString =  ptsEarnedMsg;
   	  var newBeginIdx = ptsLblTxt.length;
   	  var newEndLength = 0;
   	  if(pendingPoints){
   	  	 ptsLblTxt += newEndString;
   	  	 newEndLength = newEndString.length;
   	  }
   	  
   	  
   	  var beginLength = pointsAlreadyEarned.toString().length;
    	var attributesCol = [];
    	
        
        /*if(pendingPoints){
        	beginLength+=1;
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [0, beginLength]
	        });
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [newBeginIdx, newEndLength]
	        });
	        attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FONT,
	            value: {
	            	fontSize:ro.ui.scaleFont(10)
	            },
	            range: [newBeginIdx, newEndLength]
	        });
        }
        else{
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [0, beginLength]
	        });
        }*/
        
	/*var attr = Ti.UI.createAttributedString({
      text:ptsLblTxt,
      attributes:attributesCol
    });
    ptsLblDict.attributedString = attr;*/
   	  //ptsLbl = Ti.UI.createLabel(ptsLblDict);
   	  //progressBlockOne.add(ptsLbl);
   	  blockOneFullView.add(getOvalView(ptsLblTxt));
   	  progressBlockOne.add(blockOneFullView);
   	  
   	  lbl2 = Ti.UI.createLabel(lblDictTwo);
   	  lbl2.text = replaceLast(HC.LTY_REWARDS_EARN_HEADER, " ", "\n");//HC.LTY_REWARDS_EARN_HEADER.toUpperCase();
   	  progressBlockTwo.add(lbl2);
   	  
   	  var numRewards = rewards.Customers[0].Rewards && rewards.Customers[0].Rewards.length ? rewards.Customers[0].Rewards.length : 0;
   	  rewardsLblDict.text = numRewards;
   	  //ptsLblDict.attributedString = null;
   	  rewardsLblDict.color = ro.ui.theme.pendingPointsTxt;
   	  numRewardsLbl = Ti.UI.createLabel(rewardsLblDict);
   	  progressBlockTwo.add(getOvalView(numRewards));
   	  progressBlockTwo.addEventListener('click', function(){
   	  	  var obj = {
		  	 source:{
		  	 	id:1
		  	 }
		  };
		  progressView.parent.parent.changeTab(obj);
   	  });
   	  
   	  progressView.add(progressBar);
   	  
   	  return progressView;
   };
   var getCustomProgressView = function(rewards){
      //rewards.Customers[0].RewardsMeterUrl
      var progressViewDict, progressImageViewDict, progressBarDict, progressBlockDict, progressBlockDictTwo, dividerDict, lblDict, ptsLblDict, rewardsLblDict, lblDictTwo;
      if(IS_ANDROID){
      	progressViewDict = ro.ui.properties.honeycombCustomProgressView;
      	progressImageViewDict = ro.ui.properties.honeycombProgressImageView;
      	progressBarDict = ro.ui.properties.customProgressBar;
      	progressBlockDictOne =  ro.ui.properties.customProgressBlock;
      	progressBlockDictTwo = ro.ui.properties.customProgressBlockTwo;
      	dividerDict = ro.ui.properties.customDivider;
      	lblDict = ro.ui.properties.customProgressLbl;
      	lblDictTwo = ro.ui.properties.customProgressLblTwo;
      	ptsLblDict = ro.ui.properties.customPointsLbl;
      	rewardsLblDict = ro.ui.properties.customEarnedLbl;
      }
      else{
      	progressViewDict = {
	       height:Ti.UI.SIZE,
	       width:Ti.UI.FILL,
	       layout:'vertical'
	    };
	    progressImageViewDict = {
	       height:Ti.UI.SIZE,
	       width:Ti.UI.FILL,
	       left:35,
	       right:35
	    };
	    progressBarDict = {
	       width:Ti.UI.FILL,
	       height:80,
	       layout:'horizontal',
	       backgroundColor:'#eb0029'
	    };
	    progressBlockDict = {
	    	height:Ti.UI.FILL,
	      	width:'48%',
	      	left:0
	    };
	    dividerDict = {
	    	height:Ti.UI.FILL,
	      	width:'4%',
	      	backgroundColor:'black',
	      	left:0
	    };
	    lblDict = {
	       color:'#f2b300',
	       textAlign:'center',
	       height:Ti.UI.FILL,
	       width:Ti.UI.FILL,
	       font:{
	       	  fontWeight:'bold',
	       	  fontSize:15//,
	       	  //fontFamily:ro.ui.properties.font.fontFamily
	       }
	    };
	    ptsLblDict = {
	       color:'#f2b300',
	       textAlign:'center',
	       height:Ti.UI.FILL,
	       width:Ti.UI.FILL,
	       font:{
	       	  fontWeight:'bold',
	       	  fontSize:15//,
	       	  //fontFamily:ro.ui.properties.font.fontFamily
	       }
	    };
      }
      
      if(!rewards.Customers[0].hasOwnProperty('RewardsMeterUrl') || !rewards.Customers[0].RewardsMeterUrl.length){
      	 return getDefaultProgressView(rewards);
      }
      
      
      var totalPointsForReward = rewards.Customers[0].MinPointsForReward;
      var pointsAlreadyEarned = rewards.Customers[0].PointsBalance;
      //
      var ptsEarnedMsg = '';
      var pendingPoints = rewards.Customers[0].PointsPending && (parseInt(rewards.Customers[0].PointsPending, 10) > 0) ? parseInt(rewards.Customers[0].PointsPending, 10) : 0;
      if(pendingPoints){
      	 pointsAlreadyEarned += pendingPoints;
      	 ptsEarnedMsg = getPendingPointsMsg(pendingPoints);
      	 progressImageViewDict.image = rewards.Customers[0].RewardsMeterUri;
      	 lblDict.top = null;
      	 //delete lblDict.top;
      }
      else{
      	lblDict.top = ro.ui.relX(12);
	     progressImageViewDict.image = rewards.Customers[0].RewardsMeterUrl;
      }
      var completedPct = ((pointsAlreadyEarned / totalPointsForReward)*100);
   	  
   	  var progressView = Ti.UI.createView(progressViewDict);
   	  var progressImageView = Ti.UI.createImageView(progressImageViewDict);
   	  progressView.add(progressImageView);
   	  
   	  var progressBar = Ti.UI.createView(progressBarDict);
   	  
   	  var progressBlockOne, progressBlockTwo, blockDivider;
   	  //progressBlockDictOne.top = 0;
   	  progressBlockOne = Ti.UI.createView(progressBlockDictOne);
   	  progressBlockTwo = Ti.UI.createView(progressBlockDictTwo);
   	  blockDivider = Ti.UI.createView(dividerDict);
   	  progressBar.add(progressBlockOne);
   	  //progressBar.add(blockDivider);
   	  progressBar.add(progressBlockTwo);
   	  
   	  //HC.LTY_PTS_EARN_HEADER = cfg.LTY_PTS_EARN_HEADER && cfg.LTY_PTS_EARN_HEADER.length ? cfg.LTY_PTS_EARN_HEADER : 'Points Earned';
      //HC.LTY_REWARDS_EARN_HEADER
      
      var blockOneFullView = Ti.UI.createView({
      	height:Ti.UI.SIZE,
      	width:Ti.UI.FILL,
      	layout:'vertical'//,
      	//top:0
      });
      
   	  var lbl, lbl2, ptsLbl, earnedRewardsLbl;
   	  lbl = Ti.UI.createLabel(lblDict);
   	  lbl.text = HC.LTY_PTS_EARN_HEADER.toUpperCase();
   	  //progressBlockOne.add(lbl);
   	  blockOneFullView.add(lbl);
   	  
   	  
   	  //ptsLblDict.text = pointsAlreadyEarned + ' / ' + totalPointsForReward;
   	  var ptsLblTxt = pointsAlreadyEarned + ' / ' + totalPointsForReward + '\n';
   	  if(pendingPoints){
   	  	 ptsLblTxt = pointsAlreadyEarned + '* / ' + totalPointsForReward + '\n';
   	  }
   	  var newEndString =  ptsEarnedMsg;
   	  var newBeginIdx = ptsLblTxt.length;
   	  var newEndLength = 0;
   	  if(pendingPoints){
   	  	 ptsLblTxt += newEndString;
   	  	 newEndLength = newEndString.length;
   	  }
   	  
   	  
   	  var beginLength = pointsAlreadyEarned.toString().length;
    	var attributesCol = [];
    	
        
        if(pendingPoints){
        	beginLength+=1;
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [0, beginLength]
	        });
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [newBeginIdx, newEndLength]
	        });
	        attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FONT,
	            value: {
	            	fontSize:ro.ui.scaleFont(10)
	            },
	            range: [newBeginIdx, newEndLength]
	        });
        }
        else{
        	attributesCol.push({
	        	type: Ti.UI.ATTRIBUTE_FOREGROUND_COLOR,
	            value: ro.ui.theme.pendingPointsTxt,
	            range: [0, beginLength]
	        });
        }
        
	var attr = Ti.UI.createAttributedString({
      text:ptsLblTxt,
      attributes:attributesCol
    });
    ptsLblDict.attributedString = attr;
   	  ptsLbl = Ti.UI.createLabel(ptsLblDict);
   	  //progressBlockOne.add(ptsLbl);
   	  blockOneFullView.add(ptsLbl);
   	  progressBlockOne.add(blockOneFullView);
   	  
   	  lbl2 = Ti.UI.createLabel(lblDictTwo);
   	  lbl2.text = HC.LTY_REWARDS_EARN_HEADER.toUpperCase();
   	  progressBlockTwo.add(lbl2);
   	  
   	  var numRewards = rewards.Customers[0].Rewards && rewards.Customers[0].Rewards.length ? rewards.Customers[0].Rewards.length : 0;
   	  rewardsLblDict.text = numRewards;
   	  //ptsLblDict.attributedString = null;
   	  rewardsLblDict.color = ro.ui.theme.pendingPointsTxt;
   	  numRewardsLbl = Ti.UI.createLabel(rewardsLblDict);
   	  progressBlockTwo.add(numRewardsLbl);
   	  progressBlockTwo.addEventListener('click', function(){
   	  	  var obj = {
		  	 source:{
		  	 	id:1
		  	 }
		  };
		  progressView.parent.parent.changeTab(obj);
   	  });
   	  
   	  progressView.add(progressBar);
   	  
   	  return progressView;
   };
   var getCustomAcctStatusView = function(rewards){//DEALS THE NEWEST SLEAK YELLOW HUNGRY HOWIES LOOK
      var acctStatusView = Ti.UI.createScrollView(ro.ui.properties.acctStatusScrollView);
      var progressView;
      switch(HC.LTY_LAYOUT){
      	 case 0: case 1: case 2: default:
      	 	if(!HC.LTY_STATUS_IMG){
      	 		//acctStatusView.backgroundImage = '/images/invGrpBackground.png';
      	 	}
      	 	progressView = getDefaultProgressView(rewards);	//DEFAULT LOOK
      	    break;
      	 case 3:
      	 	
      	 	progressView = getRoundedCustomProgressView(rewards);	//COLORFUL PIZZA SLICE PER POINT EARNED AND BLACKED OUT PIZZA SLICE FOR EACH POINT STILL NEEDED
      	 	break;
      }
      //progressView.borderColor = 'green';
      //progressView.borderWidth = 5;
      acctStatusView.add(progressView);
      
      var campaigns = [];
      var ptRules = rewards.PointRules;
      if(!ptRules || !ptRules.length){
         ptRules = [];
      }
      var rewardRules = rewards.RewardRules;
      if(!rewardRules || !rewardRules.length){
         rewardRules = [];
      }
      
      var campaignView = Ti.UI.createView(ro.ui.properties.honeycombCampaignView);
      //campaignView.borderColor = 'blue';
      //campaignView.borderWidth = 5;
      
      
		var hdrDict = {
			top : ro.ui.relY(10),
			height : Ti.UI.SIZE, //'40%',
			width : Ti.UI.FILL,
			font : {
				//fontWeight : 'bold',
				fontFamily : ro.ui.fonts.titles,
				fontSize : ro.ui.scaleFont(22)//27
			},
			textAlign : 'center',
			color : ro.ui.theme.honeycombRuleSquareTxt,
			touchEnabled : false
		};
		var bodyDict = {
			top : ro.ui.relY(2),
			right : ro.ui.relX(5),
			left : ro.ui.relX(5),
			bottom : ro.ui.relY(10),
			height : Ti.UI.SIZE, //'40%',
			width : Ti.UI.FILL,
			font : {
				//fontWeight:'bold',
				fontFamily : ro.ui.fonts.policyText,
				fontSize : ro.ui.scaleFont(14)//19
			},
			textAlign : 'center',
			color : ro.ui.theme.honeycombRuleSquareTxt,
			touchEnabled : false
		}; 

      for(var i=0, iMax=ptRules.length; i<iMax; i++){
         campaignView.add(getCampaignSquare({bgClr:ro.ui.theme.honeycombRuleSquare, hdrDict:hdrDict, bodyDict:bodyDict}, getHdrTxt(ptRules[i].Header, true), getDescriptionTxt(ptRules[i].Description, true), getNoteTxt(ptRules[i].Notes)));
      }
      for(var i=0, iMax=rewardRules.length; i<iMax; i++){
        campaignView.add(getCampaignSquare({bgClr:ro.ui.theme.honeycombRewardSquare, hdrDict:hdrDict, bodyDict:bodyDict, txt:ro.ui.theme.honeycombRewardSquareTxt}, getHdrTxt(rewardRules[i].Header, true), getDescriptionTxt(rewardRules[i].Description, true), ''));
      }
      
      acctStatusView.add(campaignView);
      
      return acctStatusView;
   };
   var getAcctStatusView = function(rewards){//DEALS WITH THE OLDER TWO ACCT STATUS VIEW LOOKS
      var acctStatusView = Ti.UI.createScrollView(ro.ui.properties.acctStatusScrollView);
      var progressView;
      
      switch(HC.LTY_LAYOUT){
      	 case 0: case 1: case 2: default:
      	 	if(!HC.LTY_STATUS_IMG){
      	 		acctStatusView.backgroundImage = '/images/invGrpBackground.png';
      	 	}
      	 	progressView = getDefaultProgressView(rewards);	//DEFAULT LOOK
      	    break;
      	 case 3:
      	 	progressView = getCustomProgressView(rewards);	//COLORFUL PIZZA SLICE PER POINT EARNED AND BLACKED OUT PIZZA SLICE FOR EACH POINT STILL NEEDED
      	 	break;
      }
      acctStatusView.add(progressView);
      
      var campaigns = [];
      var ptRules = rewards.PointRules;
      if(!ptRules || !ptRules.length){
         ptRules = [];
      }
      var rewardRules = rewards.RewardRules;
      if(!rewardRules || !rewardRules.length){
         rewardRules = [];
      }
      
      var campaignView = Ti.UI.createView(ro.ui.properties.honeycombCampaignView);
      
      for(var i=0, iMax=ptRules.length; i<iMax; i++){
         campaignView.add(getCampaignSquare({bgClr:ro.ui.theme.honeycombRuleSquare}, getHdrTxt(ptRules[i].Header), getDescriptionTxt(ptRules[i].Description), getNoteTxt(ptRules[i].Notes)));
      }
      for(var i=0, iMax=rewardRules.length; i<iMax; i++){
        campaignView.add(getCampaignSquare({bgClr:ro.ui.theme.honeycombRewardSquare, txt:ro.ui.theme.honeycombRewardSquareTxt}, getHdrTxt(rewardRules[i].Header), getDescriptionTxt(rewardRules[i].Description), ''));
      }
      
      acctStatusView.add(campaignView);
      /*acctStatusView.add(Ti.UI.createView({
      	height:ro.ui.relY(50)
      }));*/
      
      return acctStatusView;
   };
   
   var getHdrTxt = function(pointHdr, dontCapitalize){
      //var hdrTxt = '';
      //hdrTxt += ('1 order = ' + rule.Points + ' point').toUpperCase();
      var hdrTxt = dontCapitalize ? (pointHdr + '') : (pointHdr + '').toUpperCase();
      
      return hdrTxt;
   };
   var getDescriptionTxt = function(pointDesc, dontCapitalize){
      //var bodyTxt = '';
      //bodyTxt += ('Earn ' + rule.Points + ' point for every order of $' + rule.Min + '.00 or more').toUpperCase();
      var bodyTxt = dontCapitalize ? (pointDesc+'') : (pointDesc+'').toUpperCase();
      
      return bodyTxt;
   };
   var getNoteTxt = function(pointNote){
      //var bodyTxt = '';
      //bodyTxt += ('Earn ' + rule.Points + ' point for every order of $' + rule.Min + '.00 or more').toUpperCase();
      var noteTxt = pointNote&&pointNote.length ? ('*'+pointNote+'').toUpperCase() : '';
      
      return noteTxt;
   };
   /*var getPointHdrTxt = function(rule){
      var hdrTxt = '';
      hdrTxt += ('1 order = ' + rule.Points + ' point').toUpperCase();
      
      return hdrTxt;
   };
   var getPointBodyTxt = function(rule){
      var bodyTxt = '';
      bodyTxt += ('Earn ' + rule.Points + ' point for every order of $' + rule.Min + '.00 or more').toUpperCase();
      
      return bodyTxt;
   };
   var getRewardHdrTxt = function(rule){
      var hdrTxt = '';
      hdrTxt += (rule.MinReq + ' POINTS = ' + rule.UserFriendlyName.toUpperCase());
      
      return hdrTxt;
   };
   var getRewardBodyTxt = function(rule){
      var bodyTxt = '';
      bodyTxt += ('Get ' + rule.UserFriendlyName + ' each time you accumulate ' + rule.MinReq + ' points!').toUpperCase();
      
      return bodyTxt;
   };*/
   var getNoRewardsLbl = function(pointsRequired){
   	  var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  var defReward = cfg.LTY_NO_REWARDS && cfg.LTY_NO_REWARDS.length ? cfg.LTY_NO_REWARDS : (parseInt(pointsRequired, 10) === 1 ? 'You Are ' + pointsRequired + ' Point Away From Getting A Reward' : 'You Are ' + pointsRequired + ' Points Away From Getting A Reward');
   	  
   	  var noRewardsLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noHeaderLbl, {text:defReward}));
      return noRewardsLbl;
   };
   var getExpirDate = function(currReward){
   	  //Ti.API.debug('currReward.expirDt: ' + JSON.stringify(currReward.ExpirDt));
   	  var expirationTxt = '';
   	  var expDt = new Date(currReward.ExpirDt);
   	  var currDt = new Date();
   	  if(currDt < expDt){
   	  	  expirationTxt = 'Exp ' + (expDt.getMonth()+1) + '/' + expDt.getDate() + '/' + expDt.getFullYear(); //expDt.getYear();
   	  }
   	  
   	  //Ti.API.debug('expirationTxt: ' + expirationTxt);
   	  return expirationTxt;
   };
   var setTempCode = function(code){
   	  Ti.App.Properties.setString('tempLoyaltyCode', code);
   };
   var getTempCode = function(){
   	  var returnCode = Ti.App.Properties.getString('tempLoyaltyCode', '');
   	  setTempCode('');
   	  return returnCode;
   };
   var getNewReward = function(myView, currReward, cpnEvtBln){
    	//didAddSomeRewards = true;
    	var url = currReward.Url && currReward.Url.length ? currReward.Url : ro.ui.properties.defaultPath + 'coupon.png';
        myView.add(getNewCampaignSquare(ro.ui.theme.honeycombRewardSquare, getEarnedHdr(currReward), getEarnedBody(currReward), '', function(e){
        	ro.ui.showLoader();
        	////deb.ug(e, 'e');
        	if(ro.REV_LOYALTY.isValidCode(e.source.hcCode)){
        		if(cpnEvtBln){
        			setTempCode(e.source.hcCode);
        			ro.ui.changeTab({
						tabIndex:0
					});
        		}
        		else{
        			var menuUtils = require('logic/menuUtils');
		     		ro.REV_LOYALTY.validateCoupon(e.source.hcCode, ro.app.Store.ID, function(){
		     			  ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
		     			  ro.ui.hideLoader();
		     		}, null, function(cpnCode, LoyaltyCode){
		     			menuUtils.testCpnCode(cpnCode, true, true, LoyaltyCode, function(msg){
		     				var title = 'Success!';
		     				ro.ui.alert(title, msg);
		     				ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
		     			});
		     		});
		     	}
	     	}
	     	else{
	     		ro.ui.hideLoader();
	     	}
        }, currReward.RewardID, cpnEvtBln, url, getExpirDate(currReward)));
     };
     var getHowieReward = function(myViewCol, currReward, cpnEvtBln){
    	//didAddSomeRewards = true;
    	var url = Ti.App.websiteURL + '/content/images/myltyaccount.png';
    	//icurrReward.Url && currReward.Url.length ? currReward.Url : ro.ui.properties.defaultPath + 'coupon.png';
        myViewCol.push(getHowieCampaignSquare(ro.ui.theme.honeycombRewardSquare, getEarnedHdr(currReward), getEarnedBody(currReward), '', function(e){
        	ro.ui.showLoader();
        	////deb.ug(e, 'e');
        	if(ro.REV_LOYALTY.isValidCode(e.source.hcCode)){
        		if(cpnEvtBln){
        			setTempCode(e.source.hcCode);
        			ro.ui.changeTab({
						tabIndex:0
					});
        		}
        		else{
        			var menuUtils = require('logic/menuUtils');
		     		ro.REV_LOYALTY.validateCoupon(e.source.hcCode, ro.app.Store.ID, function(){
		     			  ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
		     			  ro.ui.hideLoader();
		     		}, null, function(cpnCode, LoyaltyCode){
		     			menuUtils.testCpnCode(cpnCode, true, true, LoyaltyCode, function(msg){
		     				var title = 'Success!';
		     				ro.ui.alert(title, msg);
		     				ro.ui.ordShowNext({addView:true, showing:'grpsItems'});
		     			});
		     		});
		     	}
	     	}
	     	else{
	     		ro.ui.hideLoader();
	     	}
        }, currReward.RewardID, cpnEvtBln, url, getExpirDate(currReward)));
     };
     
     var getHowieCampaignSquare = function(bgClr, hdrTxt, bodyTxt, noteTxt, _callback, hcCode, cpnEvtBln, url, currRewardExpirTxt){
      var campaignRowVw = ro.layout.getEmptyGenericRow();
      campaignRowVw.hcCode = hcCode;
      var imageHolderWidth = ro.ui.relX(40);
      
      var imagePadding = ro.ui.relX(6);
      var fontSize = ro.ui.scaleFont(15);
      var imageHolder = Ti.UI.createView({
      	left:imagePadding,
      	width:imageHolderWidth,
      	height:Ti.UI.FILL,
      	touchEnabled:false
      });
      imageHolder.add(Ti.UI.createImageView({
      	image:url,
      	touchEnabled:false
      }));
      var labelHolder = Ti.UI.createView({
      	left:imageHolderWidth + (2*imagePadding),
      	right:ro.ui.relX(50),
      	height:Ti.UI.SIZE,
      	layout:'vertical',
      	touchEnabled:false
      });
      var topLblHolder, bottomLblHolder;
      
     var topLbl = Ti.UI.createLabel({
     	height:Ti.UI.SIZE,
      	touchEnabled:false,
      	color:'#393839',
      	font:{
      		fontFamily:ro.ui.fonts.rowHdrTxt,
      		fontSize:fontSize
      	},
      	text:hdrTxt,
      	left:0
     });
      
      var bottomLblHolder = Ti.UI.createView({
      	touchEnabled:false,
      	width:Ti.UI.FILL,
      	layout:'horizontal',
      	height:Ti.UI.SIZE
      });
      bottomLblHolder.add(Ti.UI.createLabel({
      	touchEnabled:false,
      	color:'#393839',
      	font:{
      		fontFamily:ro.ui.fonts.rowBodyTxt,
      		fontSize:fontSize
      	},
      	text:bodyTxt + ' ' + noteTxt,
      	left:0
      }));
      bottomLblHolder.add(Ti.UI.createLabel({
      	touchEnabled:false,
      	color:'#393839',
      	font:{
      		fontFamily:ro.ui.fonts.rowBodyTxt,
      		fontSize:fontSize
      	},
      	text:currRewardExpirTxt || "",
      	left:ro.ui.relX(10)
      }));
      
      //labelHolder.add(topLblHolder);
      labelHolder.add(topLbl);
      //labelHolder.add(bottomLblHolder);
      
      campaignRowVw.add(imageHolder);
      campaignRowVw.add(labelHolder);
      
      if(_callback){
		campaignRowVw.addEventListener('click', _callback);
	  }
      return campaignRowVw;
   };
     
     var getNewCampaignSquare = function(bgClr, hdrTxt, bodyTxt, noteTxt, _callback, hcCode, cpnEvtBln, url, currRewardExpirTxt){
      var campaignRowView = Ti.UI.createView({
      		hcCode:hcCode,
         	height:ro.ui.relY(100)
      });
      
      	var hasImg = true;//(imgPath && imgPath.length > 0);
         var left = ro.ui.relX(7);
         var cls = 'item';//(hasImg?'item':'noitem');
         var hasRightImg = false;

			var rowVw = Ti.UI.createView({
				height:Ti.UI.FILL,
				width:Ti.UI.FILL,
				top:ro.ui.relY(1),
				bottom:ro.ui.relY(1),
				touchEnabled:false//,
				//backgroundImage:'/images/menuItemBg.png'//,//Ti.App.websiteURL+'/content/images/menu-item.png',//ro.ui.theme.menuItemImg

			});
			var backgroundImg = Ti.UI.createImageView({
					image:Ti.App.websiteURL+'/content/images/menu-item.png',
					defaultImage:'/images/menuItemBg.png',
					height: Ti.UI.FILL,
					width: Ti.UI.FILL,
					zIndex: -1000,
					touchEnabled: false
				});
				rowVw.add(backgroundImg);

			if(hasImg){
			   left = Ti.App.picklemansStyle ? ro.ui.relX(110) : ro.ui.relX(105); //80
			   rowVw.add(Ti.UI.createImageView({
			   	  touchEnabled:false,
			      image:url,//hasImg?imgPath:group.ImageSource,
			      width:Ti.App.picklemansStyle ? ro.ui.relX(110) : ro.ui.relX(70), //70
			      height:Ti.App.picklemansStyle ? Ti.UI.FILL : ro.ui.relY(70),
			      left:Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(5),
			      top:Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(15),
			      bottom:Ti.App.picklemansStyle ? ro.ui.relX(0) : ro.ui.relX(15)
			      
			   }));
			}
         var labelVw = Ti.UI.createView({
         	touchEnabled:false,
            height:Ti.UI.SIZE,
            width:Ti.UI.SIZE,
            right:ro.ui.relX(10),
            layout:'vertical',
            left:left
         });
         

		//var dateTxt = '';
		//dateTxt = getExpirDate(currReward)
		//Ti.API.debug('currReward: ' + currReward);
		//var expDate = new Date(currReward.)
		//if()

         var finalString = hdrTxt;

       var attributesCol = [];
        var attr = Ti.UI.createAttributedString({
	      text:finalString,
	      attributes:attributesCol
	    });
				
			labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsName, {
				touchEnabled:false,
 				color:ro.ui.theme.newGroupsBtnTxt,
				attributedString:attr,
				width:Ti.UI.SIZE,
				top:Ti.App.picklemansStyle ? ro.ui.relY(10) : ro.ui.relY(3),
				font:{
               		fontSize:ro.ui.scaleFont(16),//11
               		fontWeight:'bold',
            		fontFamily:ro.ui.fontFamily
           		}
			})));


			labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsDetails, {
				touchEnabled:false,
				color:ro.ui.theme.contentsSmallTxt,
				text:bodyTxt + ' ' + noteTxt,
				height:Ti.UI.SIZE,
				width:Ti.UI.SIZE,
				top:ro.ui.relY(2),
	            font:{
	               fontSize:ro.ui.scaleFont(11.5),
	            	fontFamily:ro.ui.fontFamily//10
	            }
			})));
			
			if(currRewardExpirTxt && currRewardExpirTxt.length){
				labelVw.add(Ti.UI.createLabel(ro.combine(ro.ui.properties.newItemsDetails, {
					touchEnabled:false,
					color:'#eb0029',
					text:currRewardExpirTxt,
					height:Ti.UI.SIZE,
					width:Ti.UI.SIZE,
					top:ro.ui.relY(2),
		            font:{
		               fontSize:ro.ui.scaleFont(11.5),
		            	fontFamily:ro.ui.fontFamily//10
		            }
				})));
			}
			
			rowVw.add(labelVw);
			/*if(hasRightImg){
            var rowChk = Ti.UI.createImageView({
               //left:ro.ui.relX(5),
               right:ro.ui.relX(3),
               image:'/images/check.png'//,
               //visible:false
            });
            rowVw.checkMark = rowChk;
            rowVw.add(rowVw.checkMark);
         }*/
			campaignRowView.add(rowVw);
			//if()
			//if(_callback && !cpnEvtBln){
			if(_callback){
				//Ti.API.debug('added Event');
				campaignRowView.addEventListener('click', _callback);
			}
      
      return campaignRowView;
   };
   
	var getCustomMyNewRewardsView = function(rewards, cpnEvtBln) {
		var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
		var numRewards = rewards.Customers[0].Rewards && rewards.Customers[0].Rewards.length ? rewards.Customers[0].Rewards.length : 0;
		var lastDispRowId = 10;
		var itmDisplayableLen = 10;
		var myRewardsView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.myRewardsScrollView, {
			top:ro.ui.relY(5),
			//bottom : null,//cpnEvtBln ? ro.ui.relY(50) : null,
			totalItemCount : lastDispRowId,
			firstVisibleItem : 0,
			visibleItemCount : itmDisplayableLen
		}));
		var interval;

		if (!numRewards) {//No currently earned rewards available so I tell them how many more points are needed until the next reward

			myRewardsView.add(getNoRewardsLbl(rewards.Customers[0].PointsReqForReward));
		}
		else {
			var didAddSomeRewards = false;
			var myRewardsViewCol = [];

			for (var i = 0, iMax = numRewards; i < iMax; i++) {
				var skipThisReward = false;
				var currReward = rewards.Customers[0].Rewards[i];
				var orderCpnsCnt = Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0;
				for (var j = 0, jMax = orderCpnsCnt; j < jMax; j++) {
					if (Ti.App.OrderObj.Cpns[j].LoyaltyCode && Ti.App.OrderObj.Cpns[j].LoyaltyCode.toLowerCase() == currReward.RewardID.toLowerCase()) {
						skipThisReward = true;
						break;
					}
				}
				var orderItmsCnt = Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
				for (var j = 0,
				    jMax =
				    orderItmsCnt; j < jMax; j++) {
					if (Ti.App.OrderObj.Items[j].CpnObj && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode.toLowerCase() == currReward.RewardID.toLowerCase()) {
						skipThisReward = true;
						break;
					}
				}
				if (!skipThisReward) {
					getHowieReward(myRewardsViewCol, currReward, cpnEvtBln);
					didAddSomeRewards = true;
				}
			}

			if (!didAddSomeRewards) {
				myRewardsView.add(getNoRewardsLbl(rewards.Customers[0].PointsReqForReward, cfg.LTY_NO_REWARDS));
			}
			else{
				//rewardsHeader
				var hdr = ro.layout.getGenericHdrRow("Your Rewards");
				//hdr.top = ro.ui.relY(5);
				hdr.height = Ti.UI.SIZE;
				//hdr.borderColor = 'brown';
				//hdr.borderWidth = 1;
				myRewardsView.add(hdr);
				myRewardsViewCol[0].top = ro.ui.relY(5);
				myRewardsView.add(myRewardsViewCol);
				//myRewardsView.children.splice(0, 0, ro.layout.getGenericHdrRow("Your Rewards"));
			}
		}
//myRewardsView.borderColor = 'green',
//myRewardsView.borderWidth = 5;
		return myRewardsView;
	}; 

   var getMyNewRewardsView = function(rewards, cpnEvtBln){
   	var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  var numRewards = rewards.Customers[0].Rewards && rewards.Customers[0].Rewards.length ? rewards.Customers[0].Rewards.length : 0;
   	  var lastDispRowId = 10;
   	  var itmDisplayableLen = 10;
      var myRewardsView = Ti.UI.createScrollView(ro.combine(ro.ui.properties.myRewardsScrollView, {
      	 bottom:cpnEvtBln ? ro.ui.relY(50) : null,
      	 totalItemCount:lastDispRowId,
      	 firstVisibleItem:0,
      	 visibleItemCount:itmDisplayableLen
      }));
      var interval;
      
      if(!numRewards){//No currently earned rewards available so I tell them how many more points are needed until the next reward
         
         myRewardsView.add(getNoRewardsLbl(rewards.Customers[0].PointsReqForReward));
      }
      else{
      	 var didAddSomeRewards = false;
         
         for(var i=0, iMax=numRewards; i<iMax; i++){
         	var skipThisReward = false;
            var currReward = rewards.Customers[0].Rewards[i];
            var orderCpnsCnt = Ti.App.OrderObj.Cpns && Ti.App.OrderObj.Cpns.length ? Ti.App.OrderObj.Cpns.length : 0;
            for(var j=0, jMax=orderCpnsCnt; j<jMax; j++){
            	//if(Ti.App.OrderObj.Cpns[j].ReqValCode){
            		if(Ti.App.OrderObj.Cpns[j].LoyaltyCode && Ti.App.OrderObj.Cpns[j].LoyaltyCode.toLowerCase() == currReward.RewardID.toLowerCase()){
            			skipThisReward = true;
            			break;
            		}
            	//}
            }
            var orderItmsCnt = Ti.App.OrderObj.Items && Ti.App.OrderObj.Items.length ? Ti.App.OrderObj.Items.length : 0;
            for(var j=0, jMax=orderItmsCnt; j<jMax; j++){
            	if(Ti.App.OrderObj.Items[j].CpnObj && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode && Ti.App.OrderObj.Items[j].CpnObj.LoyaltyCode.toLowerCase() == currReward.RewardID.toLowerCase()){
        			skipThisReward = true;
        			break;
        		}
            }
            if(!skipThisReward){
            		getNewReward(myRewardsView, currReward, cpnEvtBln);
            	didAddSomeRewards = true;
	         }
         }
         
         if(!didAddSomeRewards){
         	myRewardsView.add(getNoRewardsLbl(rewards.Customers[0].PointsReqForReward, cfg.LTY_NO_REWARDS));
         }
      }
      
      return myRewardsView;
   };
  var getEarnedHdr = function(reward){
   	  //Ti.API.debug('reward-getEarnedHdr(): ' + JSON.stringify(reward));
      var hdrTxt = '';
      hdrTxt += reward.RewardName;
      return hdrTxt;
   };
   var getEarnedBody = function(reward){
   	//Ti.API.debug('reward-getEarnedBody(): ' + JSON.stringify(reward));
   	//Ti.API.debug('reward.RewardID: ' + reward.RewardID);
      var bodyTxt = '';
      bodyTxt += 'Code: ' + reward.RewardID;
      return bodyTxt;
   };
   var getNoRulesDisplayView = function(){
   	  //var noRulesToDisplayView = Ti.UI.createView();
   	  var noRulesToDisplayLbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noRulesToDisplayLbl, {
   	  	 text:'You must place an order before you begin accumulating rewards.'
   	  }));
   	  return noRulesToDisplayLbl;
   };
   var getTabLoyaltyMenuView = function(storeid, cpnEvtBln, noBottomBln){
   	  var cfg = ro.app.Store ? ro.app.Store.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}'));
      var myRewardsTabHdr = cfg.LTY_REWARDS_HDR && cfg.LTY_REWARDS_HDR.length ? cfg.LTY_REWARDS_HDR : 'My Rewards';
      var LTY_BARCODE_BLN = cfg.LTY_BARCODE_TXT && cfg.LTY_BARCODE_TXT.length ? true : false;
      //var LTY_DEF_REWARDS = cfg.LTY_DEF_REWARDS;
      
      var acctTabDef = true, barcodeDef = false;
   	  cpnEvtBln = cpnEvtBln ? true : false;
      
      var loyaltyViewCol = [];
      
      var loyaltyMenuView = Ti.UI.createView({
         height:Ti.UI.FILL,
         width:ro.ui.displayCaps.platformWidth,
         layout:'vertical',
         bottom:noBottomBln ? 0 : 0//ro.ui.relY(50)
      });
      
      //Ti.include('/controls/tabCtrl.js');
      var ordTab = [];
      function tabClick(e){
      	//showLoader();
         if(e.source.id == 0){
            if(!ordTab[0].ison){
               if(ordTab[1].ison){
               	  ordTab[1].toggle();
               }
               else{
                  if(LTY_BARCODE_BLN){
               	  	ordTab[2].toggle();
               	  }
               }
               statusText.text = "Account Status";
               ordTab[0].toggle();
               
              
               
               
               
               loyaltySwitchView.children[1].visible = false;
               if(LTY_BARCODE_BLN){
               	  loyaltySwitchView.children[2].visible = false;
               }
               setTimeout(function(){
               loyaltySwitchView.children[0].visible = true;
               },10);
            }
         }
         else if(e.source.id == 1){
            if(!ordTab[1].ison){
            	if(ordTab[0].ison){
               	  ordTab[0].toggle();
               }
               else{
               	  if(LTY_BARCODE_BLN){
               	  	ordTab[2].toggle();
               	  }
               }
               statusText.text = myRewardsTabHdr;
               ordTab[1].toggle();
               
               
              	
               	 //loyaltySwitchView.children[1].reset();	
               	 //setTimeout(function(){
               	 	if(LTY_BARCODE_BLN){
               	 		loyaltySwitchView.children[2].visible = false;
               	 	}
                 	loyaltySwitchView.children[0].visible = false;
               	 //}, 100);
               	 loyaltySwitchView.children[1].visible = true;
            }
         }
         else{
         	if(!LTY_BARCODE_BLN){
         		return;
         	}
         		
         	if(!ordTab[2].ison){
         		if(ordTab[0].ison){
               	  ordTab[0].toggle();
               }
               else{
               	  ordTab[1].toggle();
               }
         		ordTab[2].toggle();

              statusText.text = 'Scan Loyalty';
               loyaltySwitchView.children[0].visible = false;
               loyaltySwitchView.children[1].visible = false;
                loyaltySwitchView.children[2].visible = true;
         	}
         }
      };
     
     
     
     
     var numTabs = 2;
     var tabWidth = ro.ui.relX(150);
     
     if(LTY_BARCODE_BLN){
     	numTabs = 3;
     	tabWidth = ro.ui.relX(110);
     	
     }
     
     ordTab.push(ro.tabBar.createTab('Acct Status', function(e){ tabClick(e); }, acctTabDef, 0, tabWidth, numTabs));
      ordTab.push(ro.tabBar.createTab(myRewardsTabHdr, function(e){ tabClick(e); }, false, 1, tabWidth,  numTabs));
      if(LTY_BARCODE_BLN){
      	ordTab.push(ro.tabBar.createTab('Scan Loyalty', function(e){ tabClick(e); }, barcodeDef, 2, tabWidth,  numTabs));
      }

      var loyaltyTabView = ro.tabBar.getTabView(ordTab, tabWidth,  numTabs);
      //loyaltyTabView.top = ro.ui.relY(10);
      var loyaltyTopTabView = Ti.UI.createView({
         height:Ti.UI.SIZE,
         width:Ti.UI.FILL,
         top:0,
         layout:'vertical'
      });
      loyaltyTabView.backgroundImage = null;
      /*if(HC.LTY_STATUS_IMG){
      	 var statusImage = Ti.UI.createImageView({
      	 	top:ro.ui.relY(10),
      	 	height:ro.ui.relY(80),
      	 	image:Ti.App.websiteURL+'/content/images/myltylogo.png'
      	 });
      	 loyaltyTopTabView.add(statusImage);
      	 
      }*/
      var statusText = Ti.UI.createLabel({
      	top:ro.ui.relY(10),
      	height:Ti.UI.SIZE,//ro.ui.relY(80),
      	width:ro.ui.properties.wideViewWidth,
      	font:{
      		fontFamily:ro.ui.fonts.titles,
      		fontSize:ro.ui.scaleFont(38)
      	},
      	textAlign:'center',
      	text:"Account Status",
      	color:'#eb0029'
      });
      loyaltyTopTabView.add(statusText);
      loyaltyTopTabView.add(loyaltyTabView);
      
      var loyaltySwitchView = Ti.UI.createView({
         height:Ti.UI.FILL,
         width:Ti.UI.FILL,
         top:0
      });
      var showRewardsFirst = false;
      getLtyCustomerDetails(Ti.App.Username, storeid, function(response){
         if(response.Success){
         	 if(cfg.LTY_DEF_REWARDS && response.Customers[0].Rewards && response.Customers[0].Rewards.length){
         	 	//acctTabDef = false;
         	 	showRewardsFirst = true;
         	 }
		     loyaltyMenuView.add(loyaltyTopTabView);
		     loyaltyMenuView.add(loyaltySwitchView);
		     
		     if(true){
		     	
		     	 loyaltySwitchView.add(getCustomAcctStatusView(response));
			     loyaltySwitchView.children[0].visible = acctTabDef;
			     loyaltySwitchView.add(getCustomMyNewRewardsView(response, cpnEvtBln));//
	
			     loyaltySwitchView.children[1].visible = false;
			     if(LTY_BARCODE_BLN){
			     	loyaltySwitchView.add(getQrView(response.Customers[0].LoyaltyID));
			     	loyaltySwitchView.children[2].visible = barcodeDef;
			     }
			     /*if(LTY_BARCODE_BLN){
			     	loyaltySwitchView.add(getQrView(response.Customers[0].LoyaltyID));
			     	loyaltySwitchView.children[2].visible = barcodeDef;
			     }*/
		     }
		     else{
			     loyaltySwitchView.add(getAcctStatusView(response));
			     loyaltySwitchView.children[0].visible = acctTabDef;
			     loyaltySwitchView.add(getMyNewRewardsView(response, cpnEvtBln));
	
			     loyaltySwitchView.children[1].visible = false;
			     if(LTY_BARCODE_BLN){
			     	loyaltySwitchView.add(getQrView(response.Customers[0].LoyaltyID));
			     	loyaltySwitchView.children[2].visible = barcodeDef;
			     }
			 }
		     
		     
		     loyaltySwitchView.changeTab = tabClick;
		     if(showRewardsFirst){
		     	statusText.text = myRewardsTabHdr;
		     	var obj = {
				   source:{
				      id:1
				   }
				};
		     	loyaltySwitchView.changeTab(obj);
		     }
		     if(barcodeDef){
		     	statusText.text = 'Scan Loyalty';
		     }
		 }
		 else{
		 	loyaltyMenuView.add(getNoRulesDisplayView());
		 }
      });
      return loyaltyMenuView;
   };
   var getQrView = function(loyaltyID){
   	  var localCfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
      var url = 'http://r-enterprise.com/common/getbarcode?data='+loyaltyID+'&Format=' + (localCfg && localCfg.LTY_BARCODE_FMT >= 0 ? localCfg.LTY_BARCODE_FMT : 4) + '&ImageFormat=1&height='+urlHeight+'&width=' + urlWidth;
   	  
   	  
   	  var ldf = Ti.Platform.displayCaps.logicalDensityFactor;
      var qrHeight = 300;
      var qrWidth = 300;
      var urlHeight = qrHeight * ldf;
      var urlWidth = qrWidth * ldf;
   	  
   	  var qrView = Ti.UI.createImageView({
   	  	 image:url,
   	  	 //width:ro.ui.relX(175),
   	  	 width:ro.ui.relX(qrWidth),
   	  	 height:ro.ui.relY(qrHeight),
   	  	 visible:false
   	  });
   	  
   	  return qrView;
   };
   var showHcTab = function(useThisConfig){
   	  var custIsOptedIn = false, foundDefStore = false, foundKeys = false;
   	  //var defStr = JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}'));
   	  var defStr = ro.REV_STORES.getDefaultStore();//JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}'));
   	  var cfg = useThisConfig ? useThisConfig : (defStr && defStr.Configuration ? defStr.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}')));
   	  Ti.API.debug('useThisConfig: ' + JSON.stringify(useThisConfig));
   	  //if(defStr && defStr.Configuration){
   	  if(cfg){
   	  	//Ti.API.debug('defStr.Configuration: ' + JSON.stringify(defStr.Configuration));
   	  	 foundDefStore = true;
   	  	 //if(defStr.Configuration.HC_API_KEY && defStr.Configuration.HC_API_KEY.length && defStr.Configuration.HC_API_SECRET && defStr.Configuration.HC_API_SECRET.length){
   	  	 if(cfg.HC_API_KEY && cfg.HC_API_KEY.length && cfg.HC_API_SECRET && cfg.HC_API_SECRET.length){
   	  	 	foundKeys = true;
   	  	 }
   	  }
   	  else{
   	  	cfg = {};
   	  }
   	  
	  //Ti.API.debug('cfgggggg: ' + JSON.stringify(cfg));
	  if(cfg.LTY_NO_ECLUB){
	  	  var ltyoptin = ro.REV_LOYALTY.getLtyOptIn();
		  if(ltyoptin === 1){
		  	 custIsOptedIn = true;
		  }
	  }
	  else{
	   	  var ecluboptin = ro.REV_LOYALTY.getEClubOptIn();
		  if(ecluboptin === 1){
		  	 custIsOptedIn = true;
		  }
	  }
   	  //is EclubOptin on
   	  //is there a default store
   	  //does the default store have hc keys
   	  //Ti.API.debug('custIsOptedIn: ' + custIsOptedIn);
   	  //Ti.API.debug('foundDefStore: ' + foundDefStore);
   	  //foundKeys
   	  //Ti.API.debug('foundKeys: ' + foundKeys);
   	  return custIsOptedIn && foundDefStore && foundKeys;
   };
   var offerLoyaltyView = function(){
   		var strString ='DefaultStore';
   	    var store = JSON.parse(Ti.App.Properties.getString(strString));
   	    
   		var offerLoyaltyView = Ti.UI.createView({
   			height:Ti.UI.FILL,
   			width:Ti.UI.FILL
   		});
   		/*var lbl = Ti.UI.createLabel({
   			text:'Please Re-enable ' + store.Configuration.CompanyName + ' Rewards in the settings tab. You will need to navigate to the profile section and check the box near the bottom, agreeing to our terms.',
   			height:Ti.UI.SIZE,
   			width:Ti.UI.SIZE,
   			color:ro.ui.theme.backgroundpngTxt,
   			font:{
   				fontSize:ro.ui.scaleFont(16),
   				fontWeight:'bold',
   				fontFamily:ro.ui.fontFamily
   			}
   		});*/
   		
   		var custIsOptedIn = false;//, foundDefStore = false, foundKeys = false;
   	  var defStr = ro.REV_STORES.getDefaultStore();//JSON.parse(Ti.App.Properties.getString('DefaultStore', '{}'));
   	  var cfg = (defStr && defStr.Configuration ? defStr.Configuration : JSON.parse(Ti.App.Properties.getString('Config', '{}')));
   	  //if(!cfg){
   	  	//cfg = {};
   	  //}
   	  //else{
   	  	
   	  //}
   	  var rewardsMsg = 'This location does not participate in our rewards program.';
	  //Ti.API.debug('cfgggggg: ' + JSON.stringify(cfg));
	  if(cfg){
	  	if(cfg.LTY_NO_ECLUB){
		  	  var ltyoptin = ro.REV_LOYALTY.getLtyOptIn();
			  if(ltyoptin === 1){
			  	 custIsOptedIn = true;
			  }
			  else{
			  	rewardsMsg = 'You must be enrolled in our rewards program to view your rewards.';
			  }
		  }
		  else{
		   	  var ecluboptin = ro.REV_LOYALTY.getEClubOptIn();
			  if(ecluboptin === 1){
			  	 custIsOptedIn = true;
			  }
			  else{
			  	rewardsMsg = 'You must be enrolled in our rewards program to view your rewards.';
			  }
		  }
	  }
	  
   		
   		var lbl = Ti.UI.createLabel(ro.combine(ro.ui.properties.noRulesToDisplayLbl, {
   	  	   text:rewardsMsg
   	    }));
   		offerLoyaltyView.add(lbl);
   		
   		return offerLoyaltyView;
   };
   var hideMask = function(){
   	  var hideMaskBln = false;
   	  var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  if(cfg && cfg.HC_HIDE_MASK){
   	  	 hideMaskBln = true;
   	  }
   	  //Ti.API.debug('cfg.HC_HIDE_MASK: ' + cfg.HC_HIDE_MASK);
   	  //Ti.API.debug('hideMaskBln: ' + hideMaskBln);
   	  return hideMaskBln;
   };
   var getPendingPointsMsg = function(pts){
   	  var pendingPointsMsg = 'Includes Pending Points: []';
   	  var cfg = JSON.parse(Ti.App.Properties.getString('Config', '{}'));
   	  if(cfg && cfg.LTY_PENDING_PTS_MSG && cfg.LTY_PENDING_PTS_MSG.length){
   	  	 pendingPointsMsg = cfg.LTY_PENDING_PTS_MSG;
   	  }
   	  
   	  return '*' + pendingPointsMsg.replace("[]", pts);
   	  //pendingPointsFormatter(pendingPointsMsg, pts);
   };
   return {
      Init: Init,
      //isValidCode: isValidCode,
      //validateCode: validateCode,
      setHcCode: setHcCode,
      addLoyaltyCodes: addLoyaltyCodes,
      getCustomerDetails: getCustomerDetails,
      getLtyCustomerDetails: getLtyCustomerDetails,
      getTabLoyaltyMenuView: getTabLoyaltyMenuView,
      showHcTab: showHcTab,
      offerLoyaltyView: offerLoyaltyView,
      hideMask: hideMask,
      //hcPreCheck: hcPreCheck,
      //hcPostCheck: hcPostCheck,
      isHC: true,
      getTempCode: getTempCode,
      showMenuGroup: showMenuGroup
   };
}();
module.exports = HONEYCOMB;